from pathlib import Path
import datetime, hashlib, json, urllib.request, urllib.error

BASE = Path(__file__).parent
URL = 'https://openrouter.ai/api/v1/models/openai/gpt-6-sol/endpoints'

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, 'redirect denied', headers, fp)

receipt = {'url': URL, 'method': 'GET', 'credentials_loaded': False, 'retries': 0, 'redirects_allowed': False, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
try:
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    request = urllib.request.Request(URL, headers={'Accept': 'application/json', 'User-Agent': 'omne-first-definition-readonly/1'})
    with opener.open(request, timeout=20) as response:
        body = response.read(4 * 1024 * 1024 + 1)
        if len(body) > 4 * 1024 * 1024:
            raise ValueError('measurement cap exceeded')
        (BASE / 'sol-endpoints.body').write_bytes(body)
        receipt.update(status=response.status, bytes=len(body), sha256=hashlib.sha256(body).hexdigest(), final_url=response.url)
except Exception as error:
    receipt.update(error_type=type(error).__name__, error=str(error))
receipt['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(BASE / 'sol-endpoints.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
if 'error' in receipt:
    raise SystemExit(1)
