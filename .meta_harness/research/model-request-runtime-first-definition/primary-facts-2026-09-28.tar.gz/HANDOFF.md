# A0b 首模型交接（受阻）

2026-09-28；worktree /data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-m1-first-definition；branch panqiwei/model-request-runtime-m1-first-definition；源码 HEAD 3f63bdf66ffdde9e4d3cbdcebe13f476de48ce0e。未改产品源码；无source commit。采用输入完整 SHA256/bytes 在 ADOPTED-INPUTS.json。D082精确v4 SHA 13f0bdfe97c885fd521da924b6c1d432577d1f669c22081ea5eafd147f61ceda、D076/v3 SHA 297d42b6eb6b8841169724d3922bd9be4f1114a8432c498aa27cba4b9f75e0cd、rev7排期SHA b79d551ca1df9c96078fc2c8e196e340dd60e7c263e26af5b88c061c8c57d88b 均认回。

## 最小阻断表

| 受阻字段/行为 | 事实与精确采用坐标 | 当前无法选择的值/行为 | 需要派发者/owner补齐 |
| --- | --- | --- | --- |
| capabilities.inputConstraints.maxImageBytes | profile3 S-9；D082 v4 ND-G1；官方image-doc.md Image input requirements只给512MB总请求/1500图/30000patch每图 | 缺席或{}表示上游无该限制，不能表示未知；没有逐图byte精确来源 | profile/core语义owner定位未知表达或已接受供给范围；模型事实owner给逐图上界依据。不能从总payload换算或删image |
| routes.openai.parameters.temperature/topP | D082 v4 参数支持与处置的最小表达（复杂/跨项条件须报缺口）；GPT6 guide明确effort非none去掉这两项 | 相同单项值在none/high下条件不同；per-item pass/select不能区分。全drop是供给选择，不能自选 | transport投影owner给接受的条件映射或明确供给采用依据；共享实现/root负责。此task不得改shared或spec |
| 非空tools与reasoningEffort组合 | D076/v3固定OpenRouter chat-completions；RT5 S57三拒绝集合；Sol官方型号页函数调用only effort=none | 当前ModelRoute无工具条件。公共plan把非空tools与reasoning high原样序列化；没有现行具名拒绝/转换采用依据 | transport/runtime语义与投影owner明确已有采用或必要窄接续。tools=[]的M1不消除完整可复用定义的条件 |
| seed/stop/penalties以及extra支持/处置表 | endpoint名字清单不是全域；D082 pass须全域依据、drop不能替代能力调查 | seed整数完整域、stop长度/所有字符串数组、penalties精确支持、extra复杂形状尚不能从所读文档闭合。原生effort核心五值有明文，但桥接全域未实测 | 模型供给owner明确供给处置采用范围；事实尚未知的项不能填wildcard或drop假闭合 |

前三项是已能定位的表达/映射缺口；最后一项分离剩余事实与供给选择。只有真正采用更新后才恢复定义实施，不把研究事实自动作为政策。

## 已确定与未确定

已确定：固定modelId=openai/gpt-6-sol、provider/tag=openai、text/image输入及text输出、独立输入922000/输出128000、完整精确价格含overrides；OpenAI提醒developer和G22 maxOutputTokens=pass沿现行采用保持；自动缓存合法values形状为 {cache:{mode:"automatic"}}，此形状不是已冻结完整配置/binding。

新endpoint body完整原字节SHA 01a5532f0e23e9cf1c7109d42adbdf650dca3a58b029a1401a3e94c2ed423db1。价格见research正文和原件，不用flex/fast。无完整ModelDefinition、revision/configuration来源或profile/binding；known-facts.json是带状态研究值，不可拿去register。

未知：以上阻断字段、实际bridge条件兑现、媒体承载、自动缓存命中/TTL、正式供给范围及37认证。无隐藏默认策略、无模型替换。

## FD验收状态

| 条目 | 实际状态与范围 |
| --- | --- |
| FD1 | 未通过，输入采用/62旧原件及新第一方字节核对完成；最小字段缺口未闭 |
| FD2 | 未执行，不能在非法完整值上声称reader/Schema/interpreter/profile judge通过 |
| FD3 | 未执行，合法全定义尚未冻结。生产plan源路径已读；没有抓线或cache命中声称 |
| FD4 | 未执行，未建lease/贡献，零隐式推广，factory默认保持现行显式定义要求 |
| FD5 | 未执行，未建模型源码/对应测试或双语公开示例；无源码改动因此未安装/构建/跑全仓。research交接及完整性检查完成 |

## 实际命令/结果

- git branch --show-current / git rev-parse HEAD / git status --short：指定分支/基线，初始clean。
- tar -xzf 既有first-two archive到本树授权tmp；PRIOR-INTEGRITY.json逐工件byte/SHA：62 checked、0 mismatches，原manifest保留。
- python3 tmp/model-request-runtime/m1-first-definition/refresh-endpoint.py：一次GET HTTP200，8010 bytes；02:46:33 UTC，无Authorization/重试/重定向/环境加载。
- OpenAI documentation MCP search gpt-6-sol image bytes temperature；fetch型号页/GPT6 guide/image guide：完整工具JSON与派生Markdown保全，未补独立时间戳。
- 事实包恢复及hash验证：见 ARCHIVE-VERIFICATION.json；adopted inputs全值hash见 ADOPTED-INPUTS.json。
- 没有失败测试或修复，因为事实门在实施前阻断；无pnpm、真实模型POST或paid步骤。

原件/正式事实包归本树.meta_harness/research/model-request-runtime-first-definition/。root决定后续record evidence归档与采用。ignored tmp包含解包旧事实、交接、hash输入与抓线接续；退休前保全独有内容。

## 接续边界与资源

当前没有存活server、连接池、模型lease、流或计费请求；只有已完成文档/GET的冻结字节。未读取.env或key，新增付费0。根入口将来需要新模型导出时交root写index；不能让factory默认装入。恢复前核最新输入、上述裁决及公共共享机制版本，再在原授权叶子路径实施。不得签M1或official认证。
