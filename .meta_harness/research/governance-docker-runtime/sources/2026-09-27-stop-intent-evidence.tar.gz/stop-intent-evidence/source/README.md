# Fixed Moby source slices for R5 stop-intent feasibility

Retrieved from the official `moby/moby` repository at peeled Engine 29.1.3 commit `fbf3ed25f893e6ce21336f1101590e40a13934f4` on 2026-09-26 UTC. Each saved file's SHA-256 and filesystem retrieval time are in `../manifest.json`. Only the directly needed call and write path was fetched:

| Local file | Official source URL | Relevant lines |
| --- | --- | --- |
| `container.go` | https://github.com/moby/moby/blob/fbf3ed25f893e6ce21336f1101590e40a13934f4/daemon/container/container.go | `toDisk`, `CheckpointTo`, `WriteHostConfig`, `ConfigPath`, `GetRunningTask`, `ExitOnNext` |
| `view.go` | https://github.com/moby/moby/blob/fbf3ed25f893e6ce21336f1101590e40a13934f4/daemon/container/view.go | `ViewDB.Save` is an in-memory transaction |
| `daemon_container.go` | https://github.com/moby/moby/blob/fbf3ed25f893e6ce21336f1101590e40a13934f4/daemon/container.go | `NewBaseContainer(id, filepath.Join(daemon.repository, id))` |
| `daemon.go` | https://github.com/moby/moby/blob/fbf3ed25f893e6ce21336f1101590e40a13934f4/daemon/daemon.go | `daemon.repository = filepath.Join(cfgStore.Root, "containers")` |
| `atomicwriter.go` | https://github.com/moby/moby/blob/fbf3ed25f893e6ce21336f1101590e40a13934f4/vendor/github.com/moby/sys/atomicwriter/atomicwriter.go | `New` creates a temporary file in the destination directory; `Close` renames it |

The task's preexisting pinned archive supplies `daemon/kill.go` and its original source manifest. This directory is a static source snapshot, not runtime evidence.
