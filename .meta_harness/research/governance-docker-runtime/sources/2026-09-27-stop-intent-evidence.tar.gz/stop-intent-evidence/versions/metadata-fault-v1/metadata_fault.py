#!/usr/bin/env python3
"""One private Engine checkpoint-failure case; static draft until separately released.

The read-only bind stays mounted through destruction of this run's private DinD.
There is deliberately no application release or unmount before that destruction.
"""

import argparse
import json
import re
import secrets
import signal
import sys
import time
from datetime import datetime, timezone

import oracle
from driver import Experiment, stable_state, utc, write_json


def mount_entries(raw, path):
    entries = []
    for line in raw.splitlines():
        before, separator, _after = line.partition(" - ")
        fields = before.split()
        if separator and len(fields) >= 6 and fields[4] == path:
            entries.append({"options": fields[5].split(","), "optional": fields[6:]})
    return entries


def private_mount(entry):
    return not any(tag.startswith(("shared:", "master:")) for tag in entry["optional"])


class MetadataFault(Experiment):
    def __init__(self, run_id):
        super().__init__(run_id)
        self.metadata_dir = None

    def read_config(self):
        record = self.outer("exec", self.dind, "cat", self.metadata_dir + "/config.v2.json")
        value = json.loads(record["stdout"])
        if type(value.get("HasBeenManuallyStopped")) is not bool:
            raise RuntimeError("on-disk manual-stop flag is missing or not boolean")
        return record["number"], value["HasBeenManuallyStopped"]

    def check_scope(self, identifier):
        if not re.fullmatch(r"[0-9a-f]{64}", identifier):
            raise RuntimeError("refusing metadata path without exact private container ID")
        info = self.inner("info", "--format", "{{.DockerRootDir}}")
        if info["stdout"].strip() != "/var/lib/docker":
            raise RuntimeError("private daemon root differs from fixed metadata path")
        self.metadata_dir = "/var/lib/docker/containers/" + identifier
        inspected = self.outer("container", "inspect", self.dind)
        dind = json.loads(inspected["stdout"])[0]
        if dind["Config"]["Labels"].get("omne.r5.stop-intent") != self.run_id:
            raise RuntimeError("private DinD ownership label changed")
        mounts = [mount for mount in dind["Mounts"] if mount.get("Destination") == "/var/lib/docker"]
        if len(mounts) != 1 or mounts[0].get("Type") != "volume" or mounts[0].get("Name") != self.volumes[2] or mounts[0].get("Propagation") != "rprivate":
            raise RuntimeError("private daemon-data volume or propagation is not isolated")
        dockerd_pid = self.outer("exec", self.dind, "pidof", "dockerd")
        pids = dockerd_pid["stdout"].split()
        if len(pids) != 1 or not pids[0].isdigit():
            raise RuntimeError("cannot identify exactly one private dockerd process")
        namespaces = self.outer("exec", self.dind, "sh", "-c",
                                'readlink "/proc/$1/ns/mnt"; readlink /proc/self/ns/mnt',
                                "namespace-check", pids[0])
        if len(namespaces["stdout"].splitlines()) != 2 or len(set(namespaces["stdout"].splitlines())) != 1:
            raise RuntimeError("exec and private dockerd do not share a mount namespace")
        resolved = self.outer("exec", self.dind, "readlink", "-f", self.metadata_dir)
        if resolved["stdout"].strip() != self.metadata_dir:
            raise RuntimeError("container metadata directory resolves outside exact path")
        before = self.outer("exec", self.dind, "cat", "/proc/self/mountinfo")
        roots = mount_entries(before["stdout"], "/var/lib/docker")
        if (len(roots) != 1 or "rw" not in roots[0]["options"] or not private_mount(roots[0]) or
                mount_entries(before["stdout"], self.metadata_dir)):
            raise RuntimeError("private daemon mount propagation or metadata mount is unexpected")
        self.stage("metadata_fault", container_id=identifier, metadata_dir=self.metadata_dir,
                   docker_root_command=info["number"], dind_inspect_command=inspected["number"],
                   dockerd_pid_command=dockerd_pid["number"],
                   namespaces_command=namespaces["number"], resolved_path_command=resolved["number"],
                   mountinfo_before_command=before["number"])

    def inject_and_observe(self):
        identifier = self.make_case("metadata-fault", 0)
        before_state_command, before_state = self.start_case(identifier)
        self.check_scope(identifier)
        before_config_command, old_flag = self.read_config()
        self.stage("metadata_fault", before_state_command=before_state_command,
                   config_before_command=before_config_command, old_manual_stop_flag=old_flag)
        if old_flag is not False or not stable_state(before_state["State"]):
            raise RuntimeError("private running fixture does not start with an unset disk flag")

        # A failed remount can leave a writable self-bind. Either way, teardown
        # destroys only this private DinD mount namespace before any app release.
        self.data["fault_injection"]["checkpoint_failure"] = "private_metadata_mount_attempted"
        self.stage("metadata_fault", mount_attempted=True)
        mounted = self.outer("exec", self.dind, "sh", "-c",
                             'mount --bind "$1" "$1" && mount -o remount,bind,ro "$1"',
                             "metadata-mount", self.metadata_dir, checked=False)
        self.stage("metadata_fault", mount_command=mounted["number"])
        if mounted.get("returncode") != 0:
            raise RuntimeError("private metadata read-only bind/remount failed")
        after_mount = self.outer("exec", self.dind, "cat", "/proc/self/mountinfo")
        entries = mount_entries(after_mount["stdout"], self.metadata_dir)
        roots_after = mount_entries(after_mount["stdout"], "/var/lib/docker")
        self.stage("metadata_fault", mountinfo_after_command=after_mount["number"])
        if (len(entries) != 1 or "ro" not in entries[0]["options"] or not private_mount(entries[0]) or
                len(roots_after) != 1 or "rw" not in roots_after[0]["options"] or
                not private_mount(roots_after[0])):
            raise RuntimeError("read-only metadata mount not confirmed in private namespace")

        ack = self.api("/containers/" + identifier + "/kill?signal=SIGTERM")
        self.stage("metadata_fault", term_api_command=ack["number"], term_api_status=ack["http_status"])
        deadline = time.monotonic() + 3
        while True:
            marker = self.outer("exec", self.control, "test", "-f",
                                "/stop-intent/metadata-fault/term-seen", checked=False)
            if marker.get("returncode") == 0:
                break
            if time.monotonic() >= deadline:
                raise RuntimeError("fixture did not record TERM while metadata was read-only")
            time.sleep(0.1)
        held_command, held = self.inspect_inner(identifier)
        disk_command, disk_flag = self.read_config()
        logs = None
        warning = False
        for _attempt in range(10):
            logs = self.outer("logs", self.dind, checked=False)
            message = logs["stdout"] + logs["stderr"]
            warning = ("error checkpointing container state" in message and
                       identifier in message and "read-only file system" in message.lower())
            if warning:
                break
            time.sleep(0.2)
        self.stage("metadata_fault", term_marker_command=marker["number"],
                   held_inspect_command=held_command, config_after_command=disk_command,
                   disk_manual_stop_flag_after_ack=disk_flag, warning_logs_command=logs["number"],
                   warning_observed=warning)
        if ack["http_status"] != 204 or not stable_state(held["State"]) or disk_flag is not False or not warning:
            raise RuntimeError("ack/warning/old-disk-flag contrast not established")
        self.data["fault_injection"]["checkpoint_failure"] = "warning_ack_old_disk_flag_observed"
        self.save()
        # No release and no unmount: later successful checkpoints cannot replace
        # the old on-disk flag before the private namespace is destroyed.

    def destroy_owned_outer(self):
        order = [("container", self.dind), ("container", self.control)] + [
            ("volume", name) for name in self.volumes]
        for kind, name in order:
            inspected = self.outer(kind, "inspect", name, timeout=10, checked=False)
            if inspected.get("returncode") != 0:
                self.data["cleanup"].append({"kind": kind, "name": name, "absent_before_remove": True})
                self.save()
                continue
            try:
                value = json.loads(inspected["stdout"])[0]
                labels = value["Config"]["Labels"] if kind == "container" else value["Labels"]
                if labels.get("omne.r5.stop-intent") != self.run_id:
                    self.data["cleanup"].append({"kind": kind, "name": name,
                                                 "error": "foreign_label_refused"})
                    self.save()
                    continue
                target = value["Id"] if kind == "container" else name
                args = ("rm", "-f", target) if kind == "container" else ("volume", "rm", name)
                removed = self.outer(*args, timeout=40, checked=False)
                after = self.outer(kind, "inspect", name, timeout=10, checked=False)
                self.data["cleanup"].append({"kind": kind, "name": name,
                                             "remove_command": removed["number"],
                                             "remove_returncode": removed.get("returncode"),
                                             "absent_after": after.get("returncode") not in (0, None)})
            except (ValueError, KeyError, TypeError, IndexError):
                self.data["cleanup"].append({"kind": kind, "name": name,
                                             "error": "inspect_unparseable"})
            self.save()
        containers = self.outer("ps", "-aq", "--filter", "label=" + self.label, checked=False)
        volumes = self.outer("volume", "ls", "-q", "--filter", "label=" + self.label, checked=False)
        self.stage("metadata_cleanup", containers_query_command=containers["number"],
                   volumes_query_command=volumes["number"])

    def run_fault(self):
        if self.out.exists():
            raise RuntimeError("refusing to overwrite private run evidence")
        self.out.mkdir(mode=0o700, parents=True)
        self.data["started_utc"] = utc()
        self.data["status"] = "running"
        self.data["run_scope"] = "checkpoint_failure_only"
        self.save()
        try:
            self.setup()
            self.inject_and_observe()
            self.data["status"] = "checkpoint_observation_recorded"
        except BaseException as error:
            self.data["status"] = "experiment_failed"
            self.data["error"] = {"type": type(error).__name__, "message": str(error)}
            self.save()
            try:
                self.failure_snapshot()
            except BaseException as snapshot_error:
                self.data["failure_snapshot_error"] = {"type": type(snapshot_error).__name__,
                                                       "message": str(snapshot_error)}
        finally:
            # Preserve the mount through private daemon destruction. Its inner
            # container cannot be removed individually after the daemon is gone.
            try:
                self.destroy_owned_outer()
            except BaseException as cleanup_error:
                self.data["cleanup_error"] = {"type": type(cleanup_error).__name__,
                                              "message": str(cleanup_error)}
            self.data["finished_utc"] = utc()
            self.save()
        return self.data["status"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("plan", "selftest", "run"))
    parser.add_argument("--allow-docker", action="store_true")
    args = parser.parse_args()
    if args.action == "plan":
        print(json.dumps({"scope": "one labelled private DinD, one control, three volumes, one inner PID1",
                          "injection": "read-only self-bind of exact private container metadata directory",
                          "teardown": "no release/unmount; destroy private DinD while read-only, then own labelled resources",
                          "run_requires": "separate mainline release and --allow-docker"}, indent=2))
        return 0
    if args.action == "selftest":
        sample = "12 13 0:1 / /var/lib/docker ro,relatime - ext4 /dev/a ro\n"
        assert mount_entries(sample, "/var/lib/docker") == [{"options": ["ro", "relatime"], "optional": []}]
        assert private_mount(mount_entries(sample, "/var/lib/docker")[0])
        assert not private_mount({"options": ["ro"], "optional": ["shared:12"]})
        print("metadata mount parser selftest passed; no Docker contacted")
        return 0
    if not args.allow_docker:
        parser.error("private Docker fault run requires separate mainline release and --allow-docker")
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dt%H%M%Sz") + "-" + secrets.token_hex(4)
    experiment = MetadataFault(run_id)
    status = experiment.run_fault()
    import metadata_oracle
    assessed = metadata_oracle.assess(experiment.out)
    write_json(experiment.out / "metadata-oracle.json", assessed)
    print(json.dumps({"status": status, "run_dir": str(experiment.out),
                      "oracle_overall": assessed["overall"]}))
    return 0 if (status, assessed["overall"]) == (
        "checkpoint_observation_recorded", "limited_checkpoint_failure_observed") else 1


if __name__ == "__main__":
    signal.signal(signal.SIGINT, lambda *_args: (_ for _ in ()).throw(KeyboardInterrupt()))
    signal.signal(signal.SIGTERM, lambda *_args: (_ for _ in ()).throw(KeyboardInterrupt()))
    sys.exit(main())
