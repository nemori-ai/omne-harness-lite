#!/usr/bin/env python3
"""Synthetic success and false-positive checks for the checkpoint oracle; offline."""

import json
import pathlib
import tempfile
import unittest

import metadata_oracle


RUN_ID = "20260926t000000z-12345678"
PREFIX = "omne-r5-sb-" + RUN_ID
IDENTIFIER = "a" * 64
METADATA = "/var/lib/docker/containers/" + IDENTIFIER
ROOT_MOUNT = "12 1 0:1 / /var/lib/docker rw,relatime - ext4 /dev/a rw\n"
READONLY_MOUNT = "13 12 0:1 / " + METADATA + " ro,relatime - ext4 /dev/a ro\n"
RUNNING = {"State": {"Running": True, "Restarting": False, "Pid": 27}, "RestartCount": 0}


def record(number, stdout="", argv=None, returncode=0):
    return {"number": number, "argv": argv or ["fixture-command", str(number)],
            "returncode": returncode, "stdout": stdout, "stderr": ""}


def fixture():
    dind = PREFIX + "-dind"
    control = PREFIX + "-control"
    volumes = [PREFIX + "-" + suffix for suffix in ("socket", "data", "daemon")]
    mounts = [{"Destination": "/var/lib/docker", "Type": "volume", "Name": volumes[2],
               "Propagation": "rprivate"}]
    commands = {
        1: record(1, "/var/lib/docker\n"),
        2: record(2, json.dumps([{"Config": {"Labels": {"omne.r5.stop-intent": RUN_ID}},
                                  "Mounts": mounts}])),
        3: record(3, "mnt:[42]\nmnt:[42]\n", ["docker", "exec", PREFIX + "-dind",
                                                   "sh", "-c", "readlink namespaces", "namespace-check", "101"]),
        4: record(4, METADATA + "\n"),
        5: record(5, ROOT_MOUNT),
        6: record(6, json.dumps([RUNNING])),
        7: record(7, json.dumps({"ID": IDENTIFIER, "HasBeenManuallyStopped": False})),
        8: record(8, argv=["docker", "exec", dind, "sh", "-c",
                           'mount --bind "$1" "$1" && mount -o remount,bind,ro "$1"',
                           "metadata-mount", METADATA]),
        9: record(9, ROOT_MOUNT + READONLY_MOUNT),
        10: record(10, "HTTP/1.1 204 No Content\r\n\r\n",
                   ["curl", "http://localhost/v1.52/containers/" + IDENTIFIER + "/kill?signal=SIGTERM"]),
        11: record(11),
        12: record(12, json.dumps([RUNNING])),
        13: record(13, json.dumps({"ID": IDENTIFIER, "HasBeenManuallyStopped": False})),
        14: record(14, "error checkpointing container state container=" + IDENTIFIER +
                   " error=read-only file system\n"),
        15: record(15),
        16: record(16),
        17: record(17),
        18: record(18),
        19: record(19),
        20: record(20),
        21: record(21),
        22: record(22),
        23: record(23, "101\n"),
    }
    cleanup = [{"kind": kind, "name": name, "remove_command": number,
                "remove_returncode": 0, "absent_after": True}
               for number, (kind, name) in enumerate(
                   [("container", dind), ("container", control)] +
                   [("volume", volume) for volume in volumes], start=15)]
    result = {
        "run_id": RUN_ID, "status": "checkpoint_observation_recorded",
        "outer_intents": [{"kind": kind, "name": name} for kind, name in
                          [("container", dind), ("container", control)] +
                          [("volume", volume) for volume in volumes]],
        "cleanup": cleanup,
        "commands": [{"number": number, "path": "commands/%04d.json" % number}
                     for number in commands],
        "stages": {
            "metadata_fault": {
                "container_id": IDENTIFIER, "metadata_dir": METADATA,
                "docker_root_command": 1, "dind_inspect_command": 2,
                "dockerd_pid_command": 23, "namespaces_command": 3,
                "resolved_path_command": 4,
                "mountinfo_before_command": 5, "before_state_command": 6,
                "config_before_command": 7, "mount_command": 8,
                "mountinfo_after_command": 9, "term_api_command": 10,
                "term_marker_command": 11, "held_inspect_command": 12,
                "config_after_command": 13, "warning_logs_command": 14,
            },
            "metadata_cleanup": {"containers_query_command": 21, "volumes_query_command": 22},
        },
    }
    return result, commands


def save(directory, result, commands):
    (directory / "commands").mkdir()
    (directory / "result.json").write_text(json.dumps(result))
    for number, command in commands.items():
        (directory / "commands" / ("%04d.json" % number)).write_text(json.dumps(command))


class MetadataOracleSelfTest(unittest.TestCase):
    def assess(self, mutate=None):
        with tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).resolve().parent) as temporary:
            directory = pathlib.Path(temporary)
            result, commands = fixture()
            if mutate:
                mutate(result, commands)
            save(directory, result, commands)
            return metadata_oracle.assess(directory)

    def test_complete_private_checkpoint_observation(self):
        observed = self.assess()
        self.assertEqual(observed["overall"], "limited_checkpoint_failure_observed")
        self.assertTrue(all(observed["checks"].values()))

    def test_rejects_shared_mount_or_writable_target(self):
        def shared(_result, commands):
            item = json.loads(commands[2]["stdout"])
            item[0]["Mounts"][0]["Propagation"] = "rshared"
            commands[2]["stdout"] = json.dumps(item)
        self.assertEqual(self.assess(shared)["overall"], "failed_observation")
        self.assertEqual(self.assess(lambda _result, commands: commands[9].update(stdout=ROOT_MOUNT))[
            "overall"], "failed_observation")

    def test_rejects_ack_without_old_disk_flag_or_warning(self):
        self.assertEqual(self.assess(lambda _result, commands: commands[13].update(
            stdout=json.dumps({"ID": IDENTIFIER, "HasBeenManuallyStopped": True})))["overall"],
            "failed_observation")
        self.assertEqual(self.assess(lambda _result, commands: commands[14].update(stdout=""))[
            "overall"], "failed_observation")
        self.assertEqual(self.assess(lambda _result, commands: commands[10].update(
            stdout="HTTP/1.1 500 Internal Server Error\r\n\r\n"))["overall"], "failed_observation")

    def test_rejects_unmount_before_destroy_or_cleanup_residue(self):
        self.assertEqual(self.assess(lambda _result, commands: commands[16].update(
            argv=["docker", "exec", PREFIX + "-dind", "umount", METADATA]))["overall"],
            "failed_observation")
        self.assertEqual(self.assess(lambda _result, commands: commands[21].update(stdout="residual-id\n"))[
            "overall"], "failed_observation")


if __name__ == "__main__":
    unittest.main(verbosity=2)
