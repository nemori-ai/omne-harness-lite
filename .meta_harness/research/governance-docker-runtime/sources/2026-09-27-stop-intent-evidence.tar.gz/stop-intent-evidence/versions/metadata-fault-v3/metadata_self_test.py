#!/usr/bin/env python3
"""Offline success and false-positive checks for localized private-mount fault."""

import json
import pathlib
import tempfile
import unittest

import metadata_oracle


RUN_ID = "20260926t000000z-12345678"
PREFIX = "omne-r5-sb-" + RUN_ID
IDENTIFIER = "a" * 64
METADATA = "/var/lib/docker/containers/" + IDENTIFIER
ROOT_SHARED = "12 1 0:1 / /var/lib/docker rw,relatime shared:22 master:1 - ext4 /dev/a rw\n"
ROOT_PRIVATE = "12 1 0:1 / /var/lib/docker rw,relatime - ext4 /dev/a rw\n"
CHILD_SHARED = "13 12 0:2 / /var/lib/docker/rootfs/overlayfs/demo rw,relatime shared:25 - overlay overlay rw\n"
TARGET_READONLY = "14 12 0:1 / " + METADATA + " ro,relatime - ext4 /dev/a ro\n"
RUNNING = {"State": {"Running": True, "Restarting": False, "Pid": 27}, "RestartCount": 0}


def record(number, stdout="", argv=None, returncode=0):
    return {"number": number, "argv": argv or ["fixture-command", str(number)],
            "returncode": returncode, "stdout": stdout, "stderr": ""}


def fixture():
    dind = PREFIX + "-dind"
    control = PREFIX + "-control"
    volumes = [PREFIX + "-" + suffix for suffix in ("socket", "data", "daemon")]
    dind_inspect = json.dumps([{
        "Id": "d" * 64,
        "Config": {"Labels": {"omne.r5.stop-intent": RUN_ID}},
        "Mounts": [{"Destination": "/var/lib/docker", "Type": "volume",
                    "Name": volumes[2], "Propagation": ""}],
    }])
    namespace_command = ["docker", "exec", dind, "sh", "-c", "readlink namespaces",
                         "namespace-check", "101"]
    commands = {
        1: record(1, "/var/lib/docker\n"),
        2: record(2, dind_inspect),
        3: record(3, "101\n"),
        4: record(4, "mnt:[42]\nmnt:[42]\n", namespace_command),
        5: record(5, METADATA + "\n"),
        6: record(6, ROOT_SHARED + CHILD_SHARED),
        7: record(7, "CapEff:\t0000000000200000\n"),
        8: record(8, json.dumps([RUNNING])),
        9: record(9, json.dumps({"ID": IDENTIFIER, "HasBeenManuallyStopped": False})),
        10: record(10, argv=["docker", "exec", dind, "mount", "--make-private", "/var/lib/docker"]),
        11: record(11, dind_inspect),
        12: record(12, "101\n"),
        13: record(13, "mnt:[42]\nmnt:[42]\n", namespace_command),
        14: record(14, ROOT_PRIVATE + CHILD_SHARED),
        15: record(15, argv=["docker", "exec", dind, "sh", "-c",
                             'mount --bind "$1" "$1" && mount -o remount,bind,ro "$1"',
                             "metadata-mount", METADATA]),
        16: record(16, ROOT_PRIVATE + CHILD_SHARED + TARGET_READONLY),
        17: record(17, "HTTP/1.1 204 No Content\r\n\r\n",
                   ["curl", "http://localhost/v1.52/containers/" + IDENTIFIER + "/kill?signal=SIGTERM"]),
        18: record(18),
        19: record(19, json.dumps([RUNNING])),
        20: record(20, json.dumps({"ID": IDENTIFIER, "HasBeenManuallyStopped": False})),
        21: record(21, "error checkpointing container state container=" + IDENTIFIER +
                   " error=read-only file system\n"),
        22: record(22),
        23: record(23),
        24: record(24),
        25: record(25),
        26: record(26),
        27: record(27),
        28: record(28),
    }
    outer = [("container", dind), ("container", control)] + [
        ("volume", volume) for volume in volumes]
    cleanup = [{"kind": kind, "name": name, "remove_command": number,
                "remove_returncode": 0, "absent_after": True}
               for number, (kind, name) in enumerate(outer, start=22)]
    result = {
        "run_id": RUN_ID, "status": "checkpoint_observation_recorded",
        "outer_intents": [{"kind": kind, "name": name} for kind, name in outer],
        "cleanup": cleanup,
        "commands": [{"number": number, "path": "commands/%04d.json" % number}
                     for number in commands],
        "stages": {
            "metadata_fault": {
                "container_id": IDENTIFIER, "metadata_dir": METADATA,
                "docker_root_command": 1, "dind_inspect_command": 2,
                "dockerd_pid_command": 3, "namespaces_command": 4,
                "resolved_path_command": 5, "mountinfo_before_command": 6,
                "capabilities_command": 7, "before_state_command": 8,
                "config_before_command": 9, "make_private_command": 10,
                "dind_inspect_after_private_command": 11,
                "dockerd_pid_after_private_command": 12,
                "namespaces_after_private_command": 13,
                "mountinfo_after_private_command": 14,
                "mount_command": 15, "mountinfo_after_command": 16,
                "term_api_command": 17, "term_marker_command": 18,
                "held_inspect_command": 19, "config_after_command": 20,
                "warning_logs_command": 21,
            },
            "metadata_cleanup": {"containers_query_command": 27, "volumes_query_command": 28},
        },
    }
    return result, commands


def save(directory, result, commands):
    (directory / "commands").mkdir()
    (directory / "result.json").write_text(json.dumps(result))
    for number, command in commands.items():
        (directory / "commands" / ("%04d.json" % number)).write_text(json.dumps(command))


class MetadataOracleSelfTest(unittest.TestCase):
    def assess(self, mutate=None):
        with tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).resolve().parent) as temporary:
            directory = pathlib.Path(temporary)
            result, commands = fixture()
            if mutate:
                mutate(result, commands)
            save(directory, result, commands)
            return metadata_oracle.assess(directory)

    def expect_failure(self, mutate):
        self.assertEqual(self.assess(mutate)["overall"], "failed_observation")

    def test_private_parent_then_exact_readonly_bind(self):
        observed = self.assess()
        self.assertEqual(observed["overall"], "limited_checkpoint_failure_observed")
        self.assertTrue(all(observed["checks"].values()))
        self.assertEqual(self.assess(lambda _result, commands: commands[6].update(
            stdout=ROOT_PRIVATE + CHILD_SHARED))["overall"],
            "limited_checkpoint_failure_observed")

    def test_rejects_wrong_or_recursive_propagation_change(self):
        self.expect_failure(lambda _result, commands: commands[10]["argv"].__setitem__(-1, "/"))
        self.expect_failure(lambda _result, commands: commands[10]["argv"].__setitem__(4, "--make-rprivate"))
        self.expect_failure(lambda _result, commands: commands[14].update(
            stdout=ROOT_SHARED + CHILD_SHARED))
        self.expect_failure(lambda _result, commands: commands[14].update(
            stdout=ROOT_PRIVATE + CHILD_SHARED.replace("shared:25", "")))

    def test_rejects_missing_capability_or_changed_identity(self):
        self.expect_failure(lambda _result, commands: commands[7].update(
            stdout="CapEff:\t0000000000000000\n"))
        self.expect_failure(lambda _result, commands: commands[13].update(
            stdout="mnt:[99]\nmnt:[99]\n"))
        self.expect_failure(lambda _result, commands: commands[12].update(stdout="102\n"))
        def wrong_volume(_result, commands):
            item = json.loads(commands[11]["stdout"])
            item[0]["Mounts"][0]["Name"] = "foreign-volume"
            commands[11]["stdout"] = json.dumps(item)
        self.expect_failure(wrong_volume)

    def test_rejects_missing_checkpoint_contrast_or_cleanup(self):
        self.expect_failure(lambda _result, commands: commands[20].update(
            stdout=json.dumps({"ID": IDENTIFIER, "HasBeenManuallyStopped": True})))
        self.expect_failure(lambda _result, commands: commands[21].update(stdout=""))
        self.expect_failure(lambda _result, commands: commands[21].update(
            stdout="error checkpointing container state container=" + "b" * 64 +
            " error=read-only file system\n"))
        self.expect_failure(lambda _result, commands: commands[21].update(
            stdout="error checkpointing container state\ncontainer=" + IDENTIFIER +
            "\nread-only file system\n"))
        self.expect_failure(lambda _result, commands: commands[17].update(
            stdout="HTTP/1.1 500 Internal Server Error\r\n\r\n"))
        self.expect_failure(lambda _result, commands: commands[27].update(stdout="residual-id\n"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
