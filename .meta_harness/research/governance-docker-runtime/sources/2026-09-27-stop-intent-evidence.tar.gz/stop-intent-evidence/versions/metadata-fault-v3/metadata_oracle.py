#!/usr/bin/env python3
"""Read-only raw-evidence oracle for one private checkpoint-failure case."""

import argparse
import json
import pathlib

import oracle


def mount_entries(raw, path):
    entries = []
    for line in raw.splitlines():
        before, separator, _after = line.partition(" - ")
        fields = before.split()
        if separator and len(fields) >= 6 and fields[4] == path:
            entries.append({"id": fields[0], "options": fields[5].split(","),
                            "optional": fields[6:]})
    return entries


def descendant_mounts(raw, root):
    entries = []
    for line in raw.splitlines():
        before, separator, _after = line.partition(" - ")
        fields = before.split()
        if separator and len(fields) >= 6 and fields[4].startswith(root + "/"):
            entries.append((fields[0], fields[4], tuple(fields[6:])))
    return sorted(entries)


def private(entry):
    return not any(tag.startswith(("shared:", "master:")) for tag in entry["optional"])


def disk_config(record):
    try:
        value = json.loads(record["stdout"])
        return value if isinstance(value, dict) else None
    except (KeyError, TypeError, ValueError):
        return None


def effective_sys_admin(record):
    try:
        values = [line.split()[1] for line in record["stdout"].splitlines()
                  if line.startswith("CapEff:")]
        return (record.get("returncode") == 0 and len(values) == 1 and
                (int(values[0], 16) & (1 << 21)) != 0)
    except (KeyError, IndexError, TypeError, ValueError):
        return False


def assess(directory):
    evidence = oracle.Evidence(directory)
    data = evidence.data
    stage = data.get("stages", {}).get("metadata_fault") or {}
    cleanup_stage = data.get("stages", {}).get("metadata_cleanup") or {}
    identifier = stage.get("container_id")
    metadata_dir = stage.get("metadata_dir")
    root = evidence.command(stage.get("docker_root_command"))
    dind_record = evidence.command(stage.get("dind_inspect_command"))
    dind_inspect = oracle.inspect_state(dind_record)
    dockerd_pid = evidence.command(stage.get("dockerd_pid_command"))
    namespaces = evidence.command(stage.get("namespaces_command"))
    resolved = evidence.command(stage.get("resolved_path_command"))
    before_mount = evidence.command(stage.get("mountinfo_before_command"))
    capabilities = evidence.command(stage.get("capabilities_command"))
    make_private = evidence.command(stage.get("make_private_command"))
    dind_after_record = evidence.command(stage.get("dind_inspect_after_private_command"))
    dind_after = oracle.inspect_state(dind_after_record)
    dockerd_pid_after = evidence.command(stage.get("dockerd_pid_after_private_command"))
    namespaces_after = evidence.command(stage.get("namespaces_after_private_command"))
    private_mountinfo = evidence.command(stage.get("mountinfo_after_private_command"))
    mount_command = evidence.command(stage.get("mount_command"))
    after_mount = evidence.command(stage.get("mountinfo_after_command"))
    before_config_record = evidence.command(stage.get("config_before_command"))
    before_config = disk_config(before_config_record)
    after_config_record = evidence.command(stage.get("config_after_command"))
    after_config = disk_config(after_config_record)
    ack = evidence.command(stage.get("term_api_command"))
    marker = evidence.command(stage.get("term_marker_command"))
    held_record = evidence.command(stage.get("held_inspect_command"))
    held = oracle.inspect_state(held_record)
    held = held.get("State") if held else None
    logs = evidence.command(stage.get("warning_logs_command"))
    cleanup = data.get("cleanup", [])
    dind_name = "omne-r5-sb-" + str(data.get("run_id", "")) + "-dind"
    expected_outer = {(intent.get("kind"), intent.get("name")) for intent in data.get("outer_intents", [])}
    actual_outer = {(entry.get("kind"), entry.get("name")) for entry in cleanup}
    removal = next((entry for entry in cleanup if entry.get("kind") == "container" and
                    entry.get("name") == dind_name), {})
    containers = evidence.command(cleanup_stage.get("containers_query_command"))
    volumes = evidence.command(cleanup_stage.get("volumes_query_command"))
    commands = [evidence.command(item.get("number")) for item in data.get("commands", [])]
    all_argv = [part for command in commands for part in command.get("argv", [])]
    before_roots = mount_entries(before_mount.get("stdout", ""), "/var/lib/docker")
    before_target = mount_entries(before_mount.get("stdout", ""), metadata_dir)
    private_roots = mount_entries(private_mountinfo.get("stdout", ""), "/var/lib/docker")
    private_target = mount_entries(private_mountinfo.get("stdout", ""), metadata_dir)
    after_roots = mount_entries(after_mount.get("stdout", ""), "/var/lib/docker")
    after_target = mount_entries(after_mount.get("stdout", ""), metadata_dir)
    expected_dir = "/var/lib/docker/containers/" + str(identifier)
    mount_argv = mount_command.get("argv", [])
    ack_argv = ack.get("argv", [])
    log_text = logs.get("stdout", "") + logs.get("stderr", "")
    dind_mounts = dind_inspect.get("Mounts", []) if dind_inspect else []
    if not isinstance(dind_mounts, list):
        dind_mounts = []
    data_mounts = [mount for mount in dind_mounts if mount.get("Destination") == "/var/lib/docker"]
    after_dind_mounts = dind_after.get("Mounts", []) if dind_after else []
    if not isinstance(after_dind_mounts, list):
        after_dind_mounts = []
    after_data_mounts = [mount for mount in after_dind_mounts
                         if mount.get("Destination") == "/var/lib/docker"]
    expected_volume = "omne-r5-sb-" + str(data.get("run_id", "")) + "-daemon"
    namespace_lines = namespaces.get("stdout", "").splitlines()
    namespace_after_lines = namespaces_after.get("stdout", "").splitlines()
    pids = dockerd_pid.get("stdout", "").split()
    changed_argv = make_private.get("argv", [])
    exact_change_argv = ["docker", "exec", dind_name, "mount", "--make-private", "/var/lib/docker"]
    checks = {
        "fixed_private_root": root.get("returncode") == 0 and root.get("stdout", "").strip() == "/var/lib/docker" and
                              metadata_dir == expected_dir,
        "private_volume_identity": dind_record.get("returncode") == 0 and dind_inspect is not None and
                                    dind_inspect.get("Config", {}).get("Labels", {}).get("omne.r5.stop-intent") == data.get("run_id") and
                                    len(data_mounts) == 1 and data_mounts[0].get("Type") == "volume" and
                                    data_mounts[0].get("Name") == expected_volume and
                                    data_mounts[0].get("Propagation") in ("", "rprivate"),
        "shared_private_mount_namespace": dockerd_pid.get("returncode") == 0 and
                                          len(pids) == 1 and pids[0].isdigit() and
                                          namespaces.get("returncode") == 0 and
                                          namespaces.get("argv", [])[-1:] == pids and
                                          len(namespace_lines) == 2 and len(set(namespace_lines)) == 1,
        "exact_resolved_path": resolved.get("returncode") == 0 and
                               resolved.get("stdout", "").strip() == metadata_dir,
        "pre_change_scope_and_capability": before_mount.get("returncode") == 0 and
                                           len(before_roots) == 1 and "rw" in before_roots[0]["options"] and
                                           not before_target and effective_sys_admin(capabilities),
        "exact_nonrecursive_make_private": make_private.get("returncode") == 0 and
                                           changed_argv == exact_change_argv and
                                           sum(part == "--make-private" for part in all_argv) == 1 and
                                           not any("--make-rprivate" in part for part in all_argv) and
                                           private_mountinfo.get("returncode") == 0 and
                                           type(stage.get("mountinfo_before_command")) is int and
                                           type(stage.get("make_private_command")) is int and
                                           type(stage.get("mountinfo_after_private_command")) is int and
                                           stage["mountinfo_before_command"] < stage["make_private_command"] <
                                           stage["mountinfo_after_private_command"] and
                                           len(private_roots) == 1 and len(before_roots) == 1 and
                                           private_roots[0]["id"] == before_roots[0]["id"] and
                                           "rw" in private_roots[0]["options"] and private(private_roots[0]) and
                                           not private_target and
                                           descendant_mounts(private_mountinfo.get("stdout", ""), "/var/lib/docker") ==
                                           descendant_mounts(before_mount.get("stdout", ""), "/var/lib/docker"),
        "identity_stable_after_private": dind_after_record.get("returncode") == 0 and
                                         dind_after is not None and dind_inspect is not None and
                                         dind_after.get("Id") == dind_inspect.get("Id") and
                                         dind_after.get("Config", {}).get("Labels", {}).get("omne.r5.stop-intent") == data.get("run_id") and
                                         len(after_data_mounts) == 1 and
                                         after_data_mounts[0].get("Type") == "volume" and
                                         after_data_mounts[0].get("Name") == expected_volume and
                                         after_data_mounts[0].get("Propagation") in ("", "rprivate") and
                                         dockerd_pid_after.get("returncode") == 0 and
                                         dockerd_pid_after.get("stdout", "").split() == pids and
                                         namespaces_after.get("returncode") == 0 and
                                         namespaces_after.get("argv", [])[-1:] == pids and
                                         namespace_after_lines == namespace_lines,
        "read_only_exact_bind": mount_command.get("returncode") == 0 and mount_argv[-1:] == [metadata_dir] and
                                any("mount --bind" in part and "remount,bind,ro" in part for part in mount_argv) and
                                after_mount.get("returncode") == 0 and
                                type(stage.get("make_private_command")) is int and
                                type(stage.get("mount_command")) is int and
                                stage["make_private_command"] < stage["mount_command"] and
                                len(after_target) == 1 and "ro" in after_target[0]["options"] and private(after_target[0]) and
                                len(after_roots) == 1 and "rw" in after_roots[0]["options"] and private(after_roots[0]),
        "running_before_term": evidence.command(stage.get("before_state_command")).get("returncode") == 0 and
                               oracle.running(evidence.state(stage.get("before_state_command"))),
        "old_disk_flag_before": before_config_record.get("returncode") == 0 and
                                before_config is not None and before_config.get("ID") == identifier and
                                before_config.get("HasBeenManuallyStopped") is False,
        "explicit_term_ack": ack.get("returncode") == 0 and oracle.http_status(ack.get("stdout", "")) == 204 and
                             any("/containers/" + str(identifier) + "/kill?signal=SIGTERM" in part for part in ack_argv),
        "pid1_received_term_and_held": marker.get("returncode") == 0 and
                                       held_record.get("returncode") == 0 and oracle.running(held),
        "checkpoint_warning": logs.get("returncode") == 0 and any(
            "error checkpointing container state" in line and str(identifier) in line and
            "read-only file system" in line.lower() for line in log_text.splitlines()),
        "old_disk_flag_after_ack": after_config_record.get("returncode") == 0 and
                                   after_config is not None and after_config.get("ID") == identifier and
                                   after_config.get("HasBeenManuallyStopped") is False,
        "no_release_or_unmount": not any("/stop-intent/metadata-fault/release" in part or
                                         "umount" in part for part in all_argv),
        "private_daemon_destroyed_first": bool(cleanup) and cleanup[0].get("name") == dind_name and
                                          removal.get("remove_returncode") == 0 and
                                          removal.get("absent_after") is True and
                                          type(removal.get("remove_command")) is int and
                                          type(stage.get("config_after_command")) is int and
                                          removal["remove_command"] > stage["config_after_command"],
        "all_owned_outer_absent": len(expected_outer) == 5 and expected_outer <= actual_outer and
                                  all(entry.get("error") is None and entry.get("remove_returncode") == 0 and
                                      entry.get("absent_after") is True for entry in cleanup) and
                                  containers.get("returncode") == 0 and not containers.get("stdout", "").strip() and
                                  volumes.get("returncode") == 0 and not volumes.get("stdout", "").strip(),
        "driver_complete": data.get("status") == "checkpoint_observation_recorded" and
                           data.get("cleanup_error") is None,
    }
    overall = "limited_checkpoint_failure_observed" if all(checks.values()) else "failed_observation"
    return {"overall": overall, "checks": checks,
            "term_api_status": oracle.http_status(ack.get("stdout", "")),
            "disk_manual_stop_before": before_config.get("HasBeenManuallyStopped") if before_config else None,
            "disk_manual_stop_after_ack": after_config.get("HasBeenManuallyStopped") if after_config else None,
            "scope": "one private metadata I/O failure at ack; no cross-daemon persistence or shutdown claim"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_directory", type=pathlib.Path)
    args = parser.parse_args()
    print(json.dumps(assess(args.run_directory), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
