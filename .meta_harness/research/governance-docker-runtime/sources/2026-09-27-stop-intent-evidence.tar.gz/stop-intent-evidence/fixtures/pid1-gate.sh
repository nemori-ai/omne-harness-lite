#!/bin/sh
# Disposable BusyBox PID 1 fixture. All paths are in this experiment's volume.
set -eu
case_name=$1
exit_code=$2
mode=$3
case "$case_name" in *[!a-z0-9_-]*|'') exit 64;; esac
case "$exit_code" in 0|1|17) ;; *) exit 64;; esac
case "$mode" in gate|immediate|crash) ;; *) exit 64;; esac
case_dir="/stop-intent/$case_name"
printf 'started %s\n' "$(date +%s)" >> "$case_dir/events"
if [ "$mode" = immediate ] || [ "$mode" = crash ]; then
  printf 'natural-exit %s\n' "$exit_code" >> "$case_dir/events"
  exit "$exit_code"
fi
term_seen=0
on_term() {
  term_seen=1
  printf 'term-seen %s\n' "$(date +%s)" >> "$case_dir/events"
  : > "$case_dir/term-seen"
}
trap on_term TERM
while [ "$term_seen" -eq 0 ]; do sleep 0.1; done
while [ ! -e "$case_dir/release" ]; do sleep 0.1; done
printf 'released-exit %s\n' "$exit_code" >> "$case_dir/events"
exit "$exit_code"
