// Disposable receipt-loss fixture. One forwarded Engine POST, no replay.
import fs from 'node:fs';
import http from 'node:http';

const socketPath = process.env.ENGINE_SOCKET;
const containerId = process.env.TARGET_ID;
const logPath = process.env.PROXY_LOG;
if (!socketPath || !/^[0-9a-f]{64}$/.test(containerId ?? '') || !logPath) {
  process.exit(64);
}
let forwarded = false;
const server = http.createServer((request, response) => {
  if (request.url === '/health') {
    response.writeHead(200).end('ready');
    return;
  }
  if (request.method !== 'POST' || request.url !== '/trigger' || forwarded) {
    response.writeHead(409).end();
    return;
  }
  forwarded = true;
  const upstream = http.request({
    socketPath,
    method: 'POST',
    path: `/v1.52/containers/${containerId}/kill?signal=SIGTERM`,
  }, (reply) => {
    const chunks = [];
    reply.on('data', (chunk) => chunks.push(chunk));
    reply.on('end', () => {
      fs.appendFileSync(logPath, JSON.stringify({
        event: 'upstream_completed',
        status: reply.statusCode,
        body: Buffer.concat(chunks).toString('utf8'),
        containerId,
        at: new Date().toISOString(),
      }) + '\n');
      // The caller receives no HTTP status or body even though Engine replied.
      response.socket?.destroy();
    });
  });
  upstream.on('error', (error) => {
    fs.appendFileSync(logPath, JSON.stringify({ event: 'upstream_error', code: error.code ?? null }) + '\n');
    response.socket?.destroy();
  });
  upstream.end();
});
server.listen(18765, '127.0.0.1');
