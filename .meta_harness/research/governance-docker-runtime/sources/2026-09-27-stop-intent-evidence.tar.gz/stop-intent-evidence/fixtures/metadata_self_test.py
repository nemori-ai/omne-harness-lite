#!/usr/bin/env python3
"""Offline success and false-positive checks for localized private-mount fault."""

import json
import pathlib
import tempfile
import unittest

import metadata_fault
import metadata_oracle


RUN_ID = "20260926t000000z-12345678"
PREFIX = "omne-r5-sb-" + RUN_ID
IDENTIFIER = "a" * 64
METADATA = "/var/lib/docker/containers/" + IDENTIFIER
ROOT_SHARED = "12 1 0:1 / /var/lib/docker rw,relatime shared:22 master:1 - ext4 /dev/a rw\n"
ROOT_PRIVATE = "12 1 0:1 / /var/lib/docker rw,relatime - ext4 /dev/a rw\n"
CHILD_SHARED = "13 12 0:2 / /var/lib/docker/rootfs/overlayfs/demo rw,relatime shared:25 - overlay overlay rw\n"
TARGET_READONLY = "14 12 0:1 / " + METADATA + " ro,relatime - ext4 /dev/a ro\n"
TARGET_WRITABLE = "14 12 0:1 / " + METADATA + " rw,relatime - ext4 /dev/a rw\n"
PROC_WRITABLE = "/dev/a " + METADATA + " ext4 rw,relatime 0 0\n"
PROC_READONLY = "/dev/a " + METADATA + " ext4 ro,relatime 0 0\n"
MOUNT_HELP = ("BusyBox v1.37.0 (fixed image) multi-call binary.\n"
              "Usage: mount [OPTIONS] [-o OPT] DEVICE NODE\n"
              "\t[r]bind\t\tBind a file or directory\n"
              "\tremount\t\tRemount a mounted filesystem\n"
              "\tro\t\tSame as -r\n")
RUNNING = {"State": {"Running": True, "Restarting": False, "Pid": 27}, "RestartCount": 0}


def record(number, stdout="", argv=None, returncode=0, stderr=""):
    return {"number": number, "argv": argv or ["fixture-command", str(number)],
            "returncode": returncode, "stdout": stdout, "stderr": stderr}


def fixture():
    dind = PREFIX + "-dind"
    control = PREFIX + "-control"
    volumes = [PREFIX + "-" + suffix for suffix in ("socket", "data", "daemon")]
    dind_inspect = json.dumps([{
        "Id": "d" * 64,
        "Config": {"Labels": {"omne.r5.stop-intent": RUN_ID}},
        "Mounts": [{"Destination": "/var/lib/docker", "Type": "volume",
                    "Name": volumes[2], "Propagation": ""}],
    }])
    namespace_command = ["docker", "exec", dind, "sh", "-c", "readlink namespaces",
                         "namespace-check", "101"]
    commands = {
        1: record(1, "/var/lib/docker\n"),
        2: record(2, dind_inspect),
        3: record(3, "101\n"),
        4: record(4, "mnt:[42]\nmnt:[42]\n", namespace_command),
        5: record(5, METADATA + "\n"),
        6: record(6, ROOT_SHARED + CHILD_SHARED),
        7: record(7, "CapEff:\t0000000000200000\n"),
        8: record(8, json.dumps([RUNNING])),
        9: record(9, json.dumps({"ID": IDENTIFIER, "HasBeenManuallyStopped": False})),
        10: record(10, argv=["docker", "exec", dind, "mount", "--make-private", "/var/lib/docker"]),
        11: record(11, dind_inspect),
        12: record(12, "101\n"),
        13: record(13, "mnt:[42]\nmnt:[42]\n", namespace_command),
        14: record(14, ROOT_PRIVATE + CHILD_SHARED),
        15: record(15, argv=["docker", "exec", dind, "mount", "--bind", METADATA, METADATA]),
        16: record(16, ROOT_PRIVATE + CHILD_SHARED + TARGET_WRITABLE),
        17: record(17, PROC_WRITABLE),
        18: record(18, "", ["docker", "exec", dind, "mount", "--version"]),
        19: record(19, "", ["docker", "exec", dind, "mount", "--help"], stderr=MOUNT_HELP),
        20: record(20, argv=["docker", "exec", dind, "mount", "-o", "remount,bind,ro",
                             METADATA, METADATA]),
        21: record(21, ROOT_PRIVATE + CHILD_SHARED + TARGET_READONLY),
        22: record(22, PROC_READONLY),
        23: record(23, "HTTP/1.1 204 No Content\r\n\r\n",
                   ["curl", "http://localhost/v1.52/containers/" + IDENTIFIER + "/kill?signal=SIGTERM"]),
        24: record(24),
        25: record(25, json.dumps([RUNNING])),
        26: record(26, json.dumps({"ID": IDENTIFIER, "HasBeenManuallyStopped": False})),
        27: record(27, "error checkpointing container state container=" + IDENTIFIER +
                   " error=read-only file system\n"),
        28: record(28),
        29: record(29),
        30: record(30),
        31: record(31),
        32: record(32),
        33: record(33),
        34: record(34),
    }
    outer = [("container", dind), ("container", control)] + [
        ("volume", volume) for volume in volumes]
    cleanup = [{"kind": kind, "name": name, "remove_command": number,
                "remove_returncode": 0, "absent_after": True}
               for number, (kind, name) in enumerate(outer, start=28)]
    result = {
        "run_id": RUN_ID, "status": "checkpoint_observation_recorded",
        "outer_intents": [{"kind": kind, "name": name} for kind, name in outer],
        "cleanup": cleanup,
        "commands": [{"number": number, "path": "commands/%04d.json" % number}
                     for number in commands],
        "stages": {
            "metadata_fault": {
                "container_id": IDENTIFIER, "metadata_dir": METADATA,
                "docker_root_command": 1, "dind_inspect_command": 2,
                "dockerd_pid_command": 3, "namespaces_command": 4,
                "resolved_path_command": 5, "mountinfo_before_command": 6,
                "capabilities_command": 7, "before_state_command": 8,
                "config_before_command": 9, "make_private_command": 10,
                "dind_inspect_after_private_command": 11,
                "dockerd_pid_after_private_command": 12,
                "namespaces_after_private_command": 13,
                "mountinfo_after_private_command": 14,
                "bind_command": 15, "bind_mountinfo_command": 16,
                "bind_proc_mounts_command": 17, "mount_version_command": 18,
                "mount_help_command": 19, "remount_command": 20,
                "mountinfo_after_command": 21, "remount_proc_mounts_command": 22,
                "term_api_command": 23, "term_marker_command": 24,
                "held_inspect_command": 25, "config_after_command": 26,
                "warning_logs_command": 27,
            },
            "metadata_cleanup": {"containers_query_command": 33, "volumes_query_command": 34},
        },
    }
    return result, commands


def save(directory, result, commands):
    (directory / "commands").mkdir()
    (directory / "result.json").write_text(json.dumps(result))
    for number, command in commands.items():
        (directory / "commands" / ("%04d.json" % number)).write_text(json.dumps(command))


class MetadataOracleSelfTest(unittest.TestCase):
    def assess(self, mutate=None):
        with tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).resolve().parent) as temporary:
            directory = pathlib.Path(temporary)
            result, commands = fixture()
            if mutate:
                mutate(result, commands)
            save(directory, result, commands)
            return metadata_oracle.assess(directory)

    def expect_failure(self, mutate):
        self.assertEqual(self.assess(mutate)["overall"], "failed_observation")

    def test_private_parent_then_exact_readonly_bind(self):
        observed = self.assess()
        self.assertEqual(observed["overall"], "limited_checkpoint_failure_observed")
        self.assertTrue(all(observed["checks"].values()))
        self.assertTrue(metadata_fault.fixed_busybox_mount_help(record(19, stderr=MOUNT_HELP)))
        self.assertFalse(metadata_fault.fixed_busybox_mount_help(record(19, stderr="")))
        self.assertEqual(self.assess(lambda _result, commands: commands[6].update(
            stdout=ROOT_PRIVATE + CHILD_SHARED))["overall"],
            "limited_checkpoint_failure_observed")
        self.assertEqual(self.assess(lambda _result, commands: commands[18].update(
            returncode=1, stdout="", stderr=""))["overall"],
            "limited_checkpoint_failure_observed")

    def test_rejects_wrong_or_recursive_propagation_change(self):
        self.expect_failure(lambda _result, commands: commands[10]["argv"].__setitem__(-1, "/"))
        self.expect_failure(lambda _result, commands: commands[10]["argv"].__setitem__(4, "--make-rprivate"))
        self.expect_failure(lambda _result, commands: commands[14].update(
            stdout=ROOT_SHARED + CHILD_SHARED))
        self.expect_failure(lambda _result, commands: commands[14].update(
            stdout=ROOT_PRIVATE + CHILD_SHARED.replace("shared:25", "")))

    def test_rejects_missing_capability_or_changed_identity(self):
        self.expect_failure(lambda _result, commands: commands[7].update(
            stdout="CapEff:\t0000000000000000\n"))
        self.expect_failure(lambda _result, commands: commands[13].update(
            stdout="mnt:[99]\nmnt:[99]\n"))
        self.expect_failure(lambda _result, commands: commands[12].update(stdout="102\n"))
        def wrong_volume(_result, commands):
            item = json.loads(commands[11]["stdout"])
            item[0]["Mounts"][0]["Name"] = "foreign-volume"
            commands[11]["stdout"] = json.dumps(item)
        self.expect_failure(wrong_volume)

    def test_rejects_missing_checkpoint_contrast_or_cleanup(self):
        self.expect_failure(lambda _result, commands: commands[26].update(
            stdout=json.dumps({"ID": IDENTIFIER, "HasBeenManuallyStopped": True})))
        self.expect_failure(lambda _result, commands: commands[27].update(stdout=""))
        self.expect_failure(lambda _result, commands: commands[27].update(
            stdout="error checkpointing container state container=" + "b" * 64 +
            " error=read-only file system\n"))
        self.expect_failure(lambda _result, commands: commands[27].update(
            stdout="error checkpointing container state\ncontainer=" + IDENTIFIER +
            "\nread-only file system\n"))
        self.expect_failure(lambda _result, commands: commands[23].update(
            stdout="HTTP/1.1 500 Internal Server Error\r\n\r\n"))
        self.expect_failure(lambda _result, commands: commands[33].update(stdout="residual-id\n"))

    def test_rejects_bind_or_remount_without_exact_independent_evidence(self):
        self.expect_failure(lambda _result, commands: commands[15].update(returncode=1))
        self.expect_failure(lambda _result, commands: commands[16].update(
            stdout=ROOT_PRIVATE + CHILD_SHARED))
        self.expect_failure(lambda _result, commands: commands[16].update(
            stdout=ROOT_PRIVATE + CHILD_SHARED + TARGET_READONLY))
        self.expect_failure(lambda _result, commands: commands[17].update(stdout=""))
        self.expect_failure(lambda _result, commands: commands[19].update(returncode=None))
        self.expect_failure(lambda _result, commands: commands[19].update(stderr=""))
        self.expect_failure(lambda _result, commands: commands[19].update(
            stderr=MOUNT_HELP.replace("v1.37.0", "v1.36.0")))
        self.expect_failure(lambda _result, commands: commands[19].update(
            stderr=MOUNT_HELP.replace("[r]bind", "other")))
        self.expect_failure(lambda _result, commands: commands[20].update(returncode=1))
        self.expect_failure(lambda _result, commands: commands[20]["argv"].pop())
        self.expect_failure(lambda _result, commands: commands[21].update(
            stdout=ROOT_PRIVATE + CHILD_SHARED + TARGET_WRITABLE))
        self.expect_failure(lambda _result, commands: commands[21].update(
            stdout=ROOT_PRIVATE + CHILD_SHARED + TARGET_READONLY.replace("14 12", "15 12")))
        self.expect_failure(lambda _result, commands: commands[22].update(stdout=PROC_WRITABLE))
        def term_before_verified_remount(result, commands):
            commands[22], commands[23] = commands[23], commands[22]
            commands[22]["number"], commands[23]["number"] = 22, 23
            result["stages"]["metadata_fault"].update(
                term_api_command=22, remount_proc_mounts_command=23)
        self.expect_failure(term_before_verified_remount)


if __name__ == "__main__":
    unittest.main(verbosity=2)
