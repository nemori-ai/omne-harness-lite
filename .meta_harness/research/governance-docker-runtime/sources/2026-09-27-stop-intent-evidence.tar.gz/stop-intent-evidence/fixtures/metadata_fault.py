#!/usr/bin/env python3
"""One private Engine checkpoint-failure case; static draft until separately released.

The read-only bind stays mounted through destruction of this run's private DinD.
There is deliberately no application release or unmount before that destruction.
"""

import argparse
import json
import re
import secrets
import signal
import sys
import time
from datetime import datetime, timezone

import oracle
from driver import Experiment, stable_state, utc, write_json


def mount_entries(raw, path):
    entries = []
    for line in raw.splitlines():
        before, separator, _after = line.partition(" - ")
        fields = before.split()
        if separator and len(fields) >= 6 and fields[4] == path:
            entries.append({"id": fields[0], "options": fields[5].split(","),
                            "optional": fields[6:]})
    return entries


def descendant_mounts(raw, root):
    entries = []
    for line in raw.splitlines():
        before, separator, _after = line.partition(" - ")
        fields = before.split()
        if separator and len(fields) >= 6 and fields[4].startswith(root + "/"):
            entries.append((fields[0], fields[4], tuple(fields[6:])))
    return sorted(entries)


def private_mount(entry):
    return not any(tag.startswith(("shared:", "master:")) for tag in entry["optional"])


def proc_mount_entries(raw, path):
    return [fields for line in raw.splitlines() if (fields := line.split()) and
            len(fields) >= 4 and fields[1] == path]


def fixed_busybox_mount_help(record):
    help_text = record.get("stdout", "") + record.get("stderr", "")
    return record.get("returncode") == 0 and all(part in help_text for part in (
        "BusyBox v1.37.0", "Usage: mount [OPTIONS] [-o OPT] DEVICE NODE",
        "[r]bind", "\tremount", "\tro"))


class MetadataFault(Experiment):
    def __init__(self, run_id):
        super().__init__(run_id)
        self.metadata_dir = None
        self.dind_id = None
        self.dockerd_pid = None
        self.mount_namespace = None
        self.mountinfo_before = None
        self.mountinfo_after_private = None

    def read_config(self):
        record = self.outer("exec", self.dind, "cat", self.metadata_dir + "/config.v2.json")
        value = json.loads(record["stdout"])
        if type(value.get("HasBeenManuallyStopped")) is not bool:
            raise RuntimeError("on-disk manual-stop flag is missing or not boolean")
        return record["number"], value["HasBeenManuallyStopped"]

    def check_scope(self, identifier):
        if not re.fullmatch(r"[0-9a-f]{64}", identifier):
            raise RuntimeError("refusing metadata path without exact private container ID")
        info = self.inner("info", "--format", "{{.DockerRootDir}}")
        if info["stdout"].strip() != "/var/lib/docker":
            raise RuntimeError("private daemon root differs from fixed metadata path")
        self.metadata_dir = "/var/lib/docker/containers/" + identifier
        inspected = self.outer("container", "inspect", self.dind)
        dind = json.loads(inspected["stdout"])[0]
        if dind["Config"]["Labels"].get("omne.r5.stop-intent") != self.run_id:
            raise RuntimeError("private DinD ownership label changed")
        self.dind_id = dind["Id"]
        mounts = [mount for mount in dind["Mounts"] if mount.get("Destination") == "/var/lib/docker"]
        if (len(mounts) != 1 or mounts[0].get("Type") != "volume" or
                mounts[0].get("Name") != self.volumes[2] or
                mounts[0].get("Propagation") not in ("", "rprivate")):
            raise RuntimeError("private daemon-data volume identity or propagation is unexpected")
        dockerd_pid = self.outer("exec", self.dind, "pidof", "dockerd")
        pids = dockerd_pid["stdout"].split()
        if len(pids) != 1 or not pids[0].isdigit():
            raise RuntimeError("cannot identify exactly one private dockerd process")
        self.dockerd_pid = pids[0]
        namespaces = self.outer("exec", self.dind, "sh", "-c",
                                'readlink "/proc/$1/ns/mnt"; readlink /proc/self/ns/mnt',
                                "namespace-check", pids[0])
        if len(namespaces["stdout"].splitlines()) != 2 or len(set(namespaces["stdout"].splitlines())) != 1:
            raise RuntimeError("exec and private dockerd do not share a mount namespace")
        self.mount_namespace = namespaces["stdout"].splitlines()[0]
        resolved = self.outer("exec", self.dind, "readlink", "-f", self.metadata_dir)
        if resolved["stdout"].strip() != self.metadata_dir:
            raise RuntimeError("container metadata directory resolves outside exact path")
        before = self.outer("exec", self.dind, "cat", "/proc/self/mountinfo")
        roots = mount_entries(before["stdout"], "/var/lib/docker")
        if (len(roots) != 1 or "rw" not in roots[0]["options"] or
                mount_entries(before["stdout"], self.metadata_dir)):
            raise RuntimeError("private daemon mount identity or metadata mount is unexpected")
        capabilities = self.outer("exec", self.dind, "cat", "/proc/self/status")
        effective = [line.split()[1] for line in capabilities["stdout"].splitlines()
                     if line.startswith("CapEff:")]
        if len(effective) != 1 or int(effective[0], 16) & (1 << 21) == 0:
            raise RuntimeError("private injector lacks effective CAP_SYS_ADMIN")
        self.mountinfo_before = before["stdout"]
        self.stage("metadata_fault", container_id=identifier, metadata_dir=self.metadata_dir,
                   docker_root_command=info["number"], dind_inspect_command=inspected["number"],
                   dockerd_pid_command=dockerd_pid["number"],
                   namespaces_command=namespaces["number"], resolved_path_command=resolved["number"],
                   mountinfo_before_command=before["number"],
                   capabilities_command=capabilities["number"])

    def make_private_and_check(self):
        self.data["fault_injection"]["propagation"] = "exact_private_mount_attempted"
        self.save()
        changed = self.outer("exec", self.dind, "mount", "--make-private", "/var/lib/docker",
                             checked=False)
        self.stage("metadata_fault", make_private_command=changed["number"])
        if changed.get("returncode") != 0:
            raise RuntimeError("nonrecursive make-private of private daemon-data mount failed")
        after_inspect = self.outer("container", "inspect", self.dind)
        dind = json.loads(after_inspect["stdout"])[0]
        mounts = [mount for mount in dind["Mounts"] if mount.get("Destination") == "/var/lib/docker"]
        if (dind["Id"] != self.dind_id or
                dind["Config"]["Labels"].get("omne.r5.stop-intent") != self.run_id or
                len(mounts) != 1 or mounts[0].get("Type") != "volume" or
                mounts[0].get("Name") != self.volumes[2] or
                mounts[0].get("Propagation") not in ("", "rprivate")):
            raise RuntimeError("private daemon or named volume identity changed after make-private")
        after_pid = self.outer("exec", self.dind, "pidof", "dockerd")
        if after_pid["stdout"].split() != [self.dockerd_pid]:
            raise RuntimeError("private dockerd PID changed after make-private")
        after_namespace = self.outer("exec", self.dind, "sh", "-c",
                                     'readlink "/proc/$1/ns/mnt"; readlink /proc/self/ns/mnt',
                                     "namespace-check", self.dockerd_pid)
        if after_namespace["stdout"].splitlines() != [self.mount_namespace, self.mount_namespace]:
            raise RuntimeError("private dockerd/injector mount namespace changed")
        after = self.outer("exec", self.dind, "cat", "/proc/self/mountinfo")
        roots_before = mount_entries(self.mountinfo_before, "/var/lib/docker")
        roots_after = mount_entries(after["stdout"], "/var/lib/docker")
        self.stage("metadata_fault", dind_inspect_after_private_command=after_inspect["number"],
                   dockerd_pid_after_private_command=after_pid["number"],
                   namespaces_after_private_command=after_namespace["number"],
                   mountinfo_after_private_command=after["number"])
        if (len(roots_after) != 1 or roots_after[0]["id"] != roots_before[0]["id"] or
                "rw" not in roots_after[0]["options"] or not private_mount(roots_after[0]) or
                mount_entries(after["stdout"], self.metadata_dir) or
                descendant_mounts(after["stdout"], "/var/lib/docker") !=
                descendant_mounts(self.mountinfo_before, "/var/lib/docker")):
            raise RuntimeError("exact daemon-data mount did not become private without subtree changes")
        self.mountinfo_after_private = after["stdout"]

    def inject_and_observe(self):
        identifier = self.make_case("metadata-fault", 0)
        before_state_command, before_state = self.start_case(identifier)
        self.check_scope(identifier)
        before_config_command, old_flag = self.read_config()
        self.stage("metadata_fault", before_state_command=before_state_command,
                   config_before_command=before_config_command, old_manual_stop_flag=old_flag)
        if old_flag is not False or not stable_state(before_state["State"]):
            raise RuntimeError("private running fixture does not start with an unset disk flag")

        self.make_private_and_check()

        # A failed remount can leave a writable self-bind. Teardown destroys
        # only this private DinD mount namespace before any app release.
        self.data["fault_injection"]["checkpoint_failure"] = "private_metadata_mount_attempted"
        self.stage("metadata_fault", mount_attempted=True)
        bound = self.outer("exec", self.dind, "mount", "--bind", self.metadata_dir,
                           self.metadata_dir, checked=False)
        bind_mountinfo = self.outer("exec", self.dind, "cat", "/proc/self/mountinfo", checked=False)
        bind_proc_mounts = self.outer("exec", self.dind, "cat", "/proc/self/mounts", checked=False)
        mount_version = self.outer("exec", self.dind, "mount", "--version", checked=False)
        mount_help = self.outer("exec", self.dind, "mount", "--help", checked=False)
        self.stage("metadata_fault", bind_command=bound["number"],
                   bind_mountinfo_command=bind_mountinfo["number"],
                   bind_proc_mounts_command=bind_proc_mounts["number"],
                   mount_version_command=mount_version["number"],
                   mount_help_command=mount_help["number"])
        # Compare against the already verified private-parent snapshot, not
        # against the command's exit code or mount's own output.
        previous = mount_entries(self.mountinfo_after_private, self.metadata_dir)
        previous_roots = mount_entries(self.mountinfo_after_private, "/var/lib/docker")
        bind_entries = mount_entries(bind_mountinfo.get("stdout", ""), self.metadata_dir)
        bind_roots = mount_entries(bind_mountinfo.get("stdout", ""), "/var/lib/docker")
        proc_bind = proc_mount_entries(bind_proc_mounts.get("stdout", ""), self.metadata_dir)
        if (bound.get("returncode") != 0 or bind_mountinfo.get("returncode") != 0 or
                bind_proc_mounts.get("returncode") != 0 or previous or len(bind_entries) != 1 or
                len(bind_roots) != 1 or len(previous_roots) != 1 or
                bind_roots[0]["id"] != previous_roots[0]["id"] or
                "rw" not in bind_roots[0]["options"] or
                not private_mount(bind_roots[0]) or
                bind_entries[0]["id"] == bind_roots[0]["id"] or
                "rw" not in bind_entries[0]["options"] or not private_mount(bind_entries[0]) or
                len(proc_bind) != 1 or "rw" not in proc_bind[0][3].split(",")):
            raise RuntimeError("exact writable metadata self-bind not confirmed; no TERM")
        # This BusyBox mount accepts --version with rc 0 and no output. Its
        # fixed-image help is the capability check; both raw probes are kept.
        if not fixed_busybox_mount_help(mount_help):
            raise RuntimeError("fixed BusyBox mount help does not confirm bind/remount; no TERM")

        remounted = self.outer("exec", self.dind, "mount", "-o", "remount,bind,ro",
                               self.metadata_dir, self.metadata_dir, checked=False)
        after_mount = self.outer("exec", self.dind, "cat", "/proc/self/mountinfo", checked=False)
        remount_proc_mounts = self.outer("exec", self.dind, "cat", "/proc/self/mounts", checked=False)
        entries = mount_entries(after_mount["stdout"], self.metadata_dir)
        roots_after = mount_entries(after_mount["stdout"], "/var/lib/docker")
        proc_remount = proc_mount_entries(remount_proc_mounts.get("stdout", ""), self.metadata_dir)
        self.stage("metadata_fault", remount_command=remounted["number"],
                   mountinfo_after_command=after_mount["number"],
                   remount_proc_mounts_command=remount_proc_mounts["number"])
        if (remounted.get("returncode") != 0 or after_mount.get("returncode") != 0 or
                remount_proc_mounts.get("returncode") != 0 or
                len(entries) != 1 or entries[0]["id"] != bind_entries[0]["id"] or
                "ro" not in entries[0]["options"] or not private_mount(entries[0]) or
                len(roots_after) != 1 or roots_after[0]["id"] != bind_roots[0]["id"] or
                "rw" not in roots_after[0]["options"] or
                not private_mount(roots_after[0]) or len(proc_remount) != 1 or
                "ro" not in proc_remount[0][3].split(",")):
            raise RuntimeError("read-only metadata remount not confirmed; no TERM")

        ack = self.api("/containers/" + identifier + "/kill?signal=SIGTERM")
        self.stage("metadata_fault", term_api_command=ack["number"], term_api_status=ack["http_status"])
        deadline = time.monotonic() + 3
        while True:
            marker = self.outer("exec", self.control, "test", "-f",
                                "/stop-intent/metadata-fault/term-seen", checked=False)
            if marker.get("returncode") == 0:
                break
            if time.monotonic() >= deadline:
                raise RuntimeError("fixture did not record TERM while metadata was read-only")
            time.sleep(0.1)
        held_command, held = self.inspect_inner(identifier)
        disk_command, disk_flag = self.read_config()
        logs = None
        warning = False
        for _attempt in range(10):
            logs = self.outer("logs", self.dind, checked=False)
            message = logs["stdout"] + logs["stderr"]
            warning = any("error checkpointing container state" in line and
                          identifier in line and "read-only file system" in line.lower()
                          for line in message.splitlines())
            if warning:
                break
            time.sleep(0.2)
        self.stage("metadata_fault", term_marker_command=marker["number"],
                   held_inspect_command=held_command, config_after_command=disk_command,
                   disk_manual_stop_flag_after_ack=disk_flag, warning_logs_command=logs["number"],
                   warning_observed=warning)
        if ack["http_status"] != 204 or not stable_state(held["State"]) or disk_flag is not False or not warning:
            raise RuntimeError("ack/warning/old-disk-flag contrast not established")
        self.data["fault_injection"]["checkpoint_failure"] = "warning_ack_old_disk_flag_observed"
        self.save()
        # No release and no unmount: later successful checkpoints cannot replace
        # the old on-disk flag before the private namespace is destroyed.

    def destroy_owned_outer(self):
        order = [("container", self.dind), ("container", self.control)] + [
            ("volume", name) for name in self.volumes]
        for kind, name in order:
            inspected = self.outer(kind, "inspect", name, timeout=10, checked=False)
            if inspected.get("returncode") != 0:
                self.data["cleanup"].append({"kind": kind, "name": name, "absent_before_remove": True})
                self.save()
                continue
            try:
                value = json.loads(inspected["stdout"])[0]
                labels = value["Config"]["Labels"] if kind == "container" else value["Labels"]
                if labels.get("omne.r5.stop-intent") != self.run_id:
                    self.data["cleanup"].append({"kind": kind, "name": name,
                                                 "error": "foreign_label_refused"})
                    self.save()
                    continue
                target = value["Id"] if kind == "container" else name
                args = ("rm", "-f", target) if kind == "container" else ("volume", "rm", name)
                removed = self.outer(*args, timeout=40, checked=False)
                after = self.outer(kind, "inspect", name, timeout=10, checked=False)
                self.data["cleanup"].append({"kind": kind, "name": name,
                                             "remove_command": removed["number"],
                                             "remove_returncode": removed.get("returncode"),
                                             "absent_after": after.get("returncode") not in (0, None)})
            except (ValueError, KeyError, TypeError, IndexError):
                self.data["cleanup"].append({"kind": kind, "name": name,
                                             "error": "inspect_unparseable"})
            self.save()
        containers = self.outer("ps", "-aq", "--filter", "label=" + self.label, checked=False)
        volumes = self.outer("volume", "ls", "-q", "--filter", "label=" + self.label, checked=False)
        self.stage("metadata_cleanup", containers_query_command=containers["number"],
                   volumes_query_command=volumes["number"])

    def run_fault(self):
        if self.out.exists():
            raise RuntimeError("refusing to overwrite private run evidence")
        self.out.mkdir(mode=0o700, parents=True)
        self.data["started_utc"] = utc()
        self.data["status"] = "running"
        self.data["run_scope"] = "checkpoint_failure_only"
        self.save()
        try:
            self.setup()
            self.inject_and_observe()
            self.data["status"] = "checkpoint_observation_recorded"
        except BaseException as error:
            self.data["status"] = "experiment_failed"
            self.data["error"] = {"type": type(error).__name__, "message": str(error)}
            self.save()
            try:
                self.failure_snapshot()
            except BaseException as snapshot_error:
                self.data["failure_snapshot_error"] = {"type": type(snapshot_error).__name__,
                                                       "message": str(snapshot_error)}
        finally:
            # Preserve the mount through private daemon destruction. Its inner
            # container cannot be removed individually after the daemon is gone.
            try:
                self.destroy_owned_outer()
            except BaseException as cleanup_error:
                self.data["cleanup_error"] = {"type": type(cleanup_error).__name__,
                                              "message": str(cleanup_error)}
            self.data["finished_utc"] = utc()
            self.save()
        return self.data["status"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("plan", "selftest", "run"))
    parser.add_argument("--allow-docker", action="store_true")
    args = parser.parse_args()
    if args.action == "plan":
        print(json.dumps({"scope": "one labelled private DinD, one control, three volumes, one inner PID1",
                          "isolation": "nonrecursive make-private of existing exact /var/lib/docker mount inside DinD; verify same namespace and private mountinfo",
                          "injection": "separate exact-metadata self-bind and two-path read-only remount; raw rc, mountinfo and proc mounts after each; no TERM unless both verified",
                          "teardown": "no release/unmount; destroy private DinD while read-only, then own labelled resources",
                          "run_requires": "separate mainline release and --allow-docker"}, indent=2))
        return 0
    if args.action == "selftest":
        sample = "12 13 0:1 / /var/lib/docker ro,relatime - ext4 /dev/a ro\n"
        assert mount_entries(sample, "/var/lib/docker") == [
            {"id": "12", "options": ["ro", "relatime"], "optional": []}]
        assert private_mount(mount_entries(sample, "/var/lib/docker")[0])
        assert not private_mount({"options": ["ro"], "optional": ["shared:12"]})
        assert descendant_mounts(sample, "/var/lib/docker") == []
        assert proc_mount_entries("/dev/a /var/lib/docker ext4 ro,relatime 0 0\n", "/var/lib/docker") == [
            ["/dev/a", "/var/lib/docker", "ext4", "ro,relatime", "0", "0"]]
        print("metadata mount parser selftest passed; no Docker contacted")
        return 0
    if not args.allow_docker:
        parser.error("private Docker fault run requires separate mainline release and --allow-docker")
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dt%H%M%Sz") + "-" + secrets.token_hex(4)
    experiment = MetadataFault(run_id)
    status = experiment.run_fault()
    import metadata_oracle
    assessed = metadata_oracle.assess(experiment.out)
    write_json(experiment.out / "metadata-oracle.json", assessed)
    print(json.dumps({"status": status, "run_dir": str(experiment.out),
                      "oracle_overall": assessed["overall"]}))
    return 0 if (status, assessed["overall"]) == (
        "checkpoint_observation_recorded", "limited_checkpoint_failure_observed") else 1


if __name__ == "__main__":
    signal.signal(signal.SIGINT, lambda *_args: (_ for _ in ()).throw(KeyboardInterrupt()))
    signal.signal(signal.SIGTERM, lambda *_args: (_ for _ in ()).throw(KeyboardInterrupt()))
    sys.exit(main())
