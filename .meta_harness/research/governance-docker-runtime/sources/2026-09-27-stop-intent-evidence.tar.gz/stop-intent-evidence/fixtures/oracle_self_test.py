#!/usr/bin/env python3
"""Synthetic counterexamples for the read-only Engine oracle; no Docker calls."""

import json
import pathlib
import tempfile
import unittest

import oracle


RUNNING = {"Running": True, "Restarting": False, "Pid": 20, "ExitCode": 0}
EXIT0 = {"Running": False, "Restarting": False, "Pid": 0, "ExitCode": 0}
EXIT1 = {"Running": False, "Restarting": False, "Pid": 0, "ExitCode": 1}


def inspect(state, restart_count=0):
    return {"stdout": json.dumps([{"State": state, "RestartCount": restart_count}]), "returncode": 0}


class FakeEvidence:
    def __init__(self, stage_name, stage, commands, directory=None):
        self.data = {"stages": {stage_name: stage}}
        self.commands = commands
        self.directory = directory or pathlib.Path("/nonexistent")

    def command(self, number):
        return self.commands.get(number, {})

    def container(self, number):
        return oracle.inspect_state(self.command(number))

    def state(self, number):
        item = self.container(number)
        return item["State"] if item else None


class OracleSelfTest(unittest.TestCase):
    def gate(self):
        stage = {
            "container_id": "a" * 64,
            "before_inspect_command": 1, "term_command": 2, "term_marker_command": 3,
            "hold_inspect_command": 4, "hold_waiter_ps_command": 5,
            "hold_gate_events_command": 6, "final_gate_events_command": 7,
            "exit_inspect_command": 8, "after_daemon_inspect_command": 9,
            "waiter": {"pid": 123}, "waiter_final": {"returncode": 0, "stdout": "0\n"},
            "waiter_pending_after_term": True, "hold_waiter_pending": True,
            "hold_seconds": 32.1, "restart_count_before": 0, "restart_count_after": 0,
        }
        commands = {
            1: inspect(RUNNING), 2: {"returncode": 0, "argv": ["docker", "kill", "--signal=SIGTERM"]},
            3: {"returncode": 0}, 4: inspect(RUNNING),
            5: {"returncode": 0, "stdout": "123 S docker wait"},
            6: {"stdout": "term-seen 10\n"}, 7: {"stdout": "term-seen 10\nreleased-exit 0\n"},
            8: inspect(EXIT0), 9: inspect(EXIT0),
        }
        return stage, commands

    def test_gate_rejects_short_hold_early_wait_and_restart(self):
        stage, commands = self.gate()
        observed = oracle.gate_case(FakeEvidence("gate_exit-zero", stage, commands), "exit-zero", 0)
        self.assertEqual(observed["verdict"], "pass")
        stage["hold_seconds"] = 30
        self.assertEqual(oracle.gate_case(FakeEvidence("gate_exit-zero", stage, commands), "exit-zero", 0)["verdict"], "fail")
        stage["hold_seconds"] = 32.1
        stage["hold_waiter_pending"] = False
        self.assertEqual(oracle.gate_case(FakeEvidence("gate_exit-zero", stage, commands), "exit-zero", 0)["verdict"], "fail")
        stage["hold_waiter_pending"] = True
        commands[9] = inspect(RUNNING, 1)
        self.assertEqual(oracle.gate_case(FakeEvidence("gate_exit-zero", stage, commands), "exit-zero", 0)["verdict"], "fail")

    def test_exited_apis_report_status_without_signal_claim(self):
        stage = {"before_inspect_command": 1, "after_inspect_command": 2,
                 "stop_api_command": 3, "kill_api_command": 4,
                 "stop_cli_command": 5, "kill_cli_command": 6, "signal_sent_claim": False}
        commands = {1: inspect(EXIT0), 2: inspect(EXIT0),
                    3: {"stdout": "HTTP/1.1 304 Not Modified\r\n\r\n"},
                    4: {"stdout": "HTTP/1.1 409 Conflict\r\n\r\n"},
                    5: {"returncode": 0}, 6: {"returncode": 1}}
        observed = oracle.already_exited(FakeEvidence("already_exited", stage, commands))
        self.assertEqual(observed["verdict"], "pass")
        self.assertEqual((observed["stop_api_status"], observed["kill_api_status"]), (304, 409))
        self.assertEqual(observed["signal_sent"], "not_inferred")
        commands[4]["stdout"] = "no HTTP status"
        self.assertEqual(oracle.already_exited(FakeEvidence("already_exited", stage, commands))["verdict"], "fail")

    def test_restart_requires_actual_restarting_and_later_start_event(self):
        with tempfile.TemporaryDirectory(dir=pathlib.Path(__file__).resolve().parent) as directory:
            root = pathlib.Path(directory)
            event = {"Action": "start", "Actor": {"ID": "a" * 64}, "timeNano": 2000000000}
            created = {"Action": "create", "Actor": {"ID": "a" * 64}, "timeNano": 100000000}
            def write_events():
                (root / "events.jsonl").write_text(json.dumps(created) + "\n" + json.dumps(event) + "\n")
            write_events()
            stage = {"container_id": "a" * 64, "create_event_replayed": True,
                     "restarting_inspect_command": 1, "term_api_command": 2,
                     "after_term_inspect_command": 3, "after_daemon_inspect_command": 4,
                     "events_file": "events.jsonl"}
            commands = {1: inspect({"Running": False, "Restarting": True, "Pid": 0}, 2),
                        2: {"stdout": "HTTP/1.1 409 Conflict\r\n\r\n",
                            "started_utc": "1970-01-01T00:00:01+00:00",
                            "finished_utc": "1970-01-01T00:00:01.500000+00:00"},
                        3: inspect(RUNNING, 3), 4: inspect(EXIT1, 3)}
            evidence = FakeEvidence("restart_window", stage, commands, root)
            self.assertEqual(oracle.restart_window(evidence)["verdict"], "request_rejected")
            commands[1] = inspect(RUNNING, 2)
            self.assertEqual(oracle.restart_window(evidence)["verdict"], "fail")
            commands[1] = inspect({"Running": False, "Restarting": True, "Pid": 0}, 2)
            event["timeNano"] = 500000000
            write_events()
            commands[2]["stdout"] = "HTTP/1.1 204 No Content\r\n\r\n"
            self.assertEqual(oracle.restart_window(evidence)["verdict"], "counterexample")
            commands[3] = inspect(EXIT1, 3)
            self.assertEqual(oracle.restart_window(evidence)["verdict"], "limited_pass")
            event["timeNano"] = 2000000000
            event["Actor"]["ID"] = "b" * 64
            write_events()
            self.assertEqual(oracle.restart_window(evidence)["verdict"], "limited_pass")
            event["Actor"]["ID"] = "a" * 64
            write_events()
            self.assertEqual(oracle.restart_window(evidence)["verdict"], "counterexample")
            event["timeNano"] = 1200000000
            write_events()
            self.assertEqual(oracle.restart_window(evidence)["start_events_during_request"], 1)
            self.assertEqual(oracle.restart_window(evidence)["verdict"], "limited_pass")
            stage["create_event_replayed"] = False
            self.assertEqual(oracle.restart_window(evidence)["verdict"], "fail")

    def test_lost_receipt_keeps_caller_unknown(self):
        stage = {"caller_command": 1, "proxy_log_command": 2,
                 "hold_inspect_command": 3, "later_exit_inspect_command": 4,
                 "caller_outcome": "unknown_even_if_later_exited"}
        commands = {1: {"returncode": 52, "stdout": ""},
                    2: {"stdout": json.dumps({"event": "upstream_completed", "status": 204}) + "\n"},
                    3: inspect(RUNNING), 4: inspect(EXIT0)}
        evidence = FakeEvidence("lost_receipt", stage, commands)
        observed = oracle.lost_receipt(evidence)
        self.assertEqual(observed["verdict"], "pass")
        self.assertEqual(observed["caller_result"], "unknown")
        commands[1]["returncode"] = 0
        self.assertEqual(oracle.lost_receipt(evidence)["verdict"], "fail")

    def test_abandoned_waiter_keeps_unknown(self):
        stage = {"term_api_command": 1, "hold_inspect_command": 2,
                 "later_exit_inspect_command": 3, "waiter_pending_before_exit": True,
                 "waiter": {"pid": 123},
                 "caller_termination": {"pid": 123, "signal": "SIGTERM", "sent": True},
                 "waiter_final": {"returncode": 0, "stdout": ""}, "caller_wait_result": "unknown"}
        commands = {1: {"stdout": "HTTP/1.1 204 No Content\r\n\r\n"},
                    2: inspect(RUNNING), 3: inspect(EXIT0)}
        evidence = FakeEvidence("waiter_abandon", stage, commands)
        self.assertEqual(oracle.waiter_abandon(evidence)["verdict"], "pass")
        stage["waiter_final"]["returncode"] = -15
        self.assertEqual(oracle.waiter_abandon(evidence)["verdict"], "pass")
        stage["waiter_final"]["returncode"] = 0
        stage["waiter_final"]["stdout"] = "0\n"
        self.assertEqual(oracle.waiter_abandon(evidence)["verdict"], "fail")
        stage["waiter_final"]["stdout"] = ""
        stage["caller_termination"]["sent"] = False
        self.assertEqual(oracle.waiter_abandon(evidence)["verdict"], "fail")
        stage["caller_termination"]["sent"] = True
        commands[3] = inspect(RUNNING)
        self.assertEqual(oracle.waiter_abandon(evidence)["verdict"], "fail")

    def test_overall_never_promotes_restart_counterexample_to_pass(self):
        stages = {"gate_exit_zero": {"verdict": "pass"},
                  "restart_window": {"verdict": "counterexample"}}
        self.assertEqual(oracle.overall_status(stages, True), "candidate_counterexample")
        stages["restart_window"]["verdict"] = "request_rejected"
        self.assertEqual(oracle.overall_status(stages, True), "restart_window_request_rejected")
        stages["restart_window"]["verdict"] = "limited_pass"
        self.assertEqual(oracle.overall_status(stages, True), "limited_mechanism_observed")


if __name__ == "__main__":
    unittest.main(verbosity=2)
