#!/usr/bin/env python3
"""One-shot private Engine 29.1.3 stop-intent experiment.

Static delivery only. --run creates Docker resources and requires later mainline
authorization. --plan and --selftest never contact Docker.
"""

import argparse
import hashlib
import json
import os
import pathlib
import re
import secrets
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone


HERE = pathlib.Path(__file__).resolve().parent
RUNS = HERE / "runs"
V0C = pathlib.Path("/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-fixtures/tmp/docker-product-fixtures/v0c")
TAR = V0C / "busybox-1.37.0.tar"
TAR_SHA = "39986e21f0fa8fface4e8c16b0ecf138573e1f0b2b9efe6cecc99a8c40f86045"
DIND_IMAGE = "docker:29.1.3-dind"
DIND_ID = "sha256:20cca7e2a7da287ded85087ce88d443a5347163eebf6a9ed0c27bc4cabe90ae7"
CONTROL_IMAGE = "omne-m0-v0-control-tools:20260926-fc30a6d4"
CONTROL_ID = "sha256:825773f9776113d54fb23a5de9511d5b6c7bc7550d891f7a3584bfe71c0795f6"
SOCKET_PATH = "/opt/omne-private-docker/docker.sock"
SOCKET_URL = "unix://" + SOCKET_PATH
BUSYBOX = "busybox:1.37.0"
HOLD_SECONDS = 32.0  # strictly greater than the supplied 31-second oracle


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(part)
    return digest.hexdigest()


def write_json(path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    encoded = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    temporary = path.with_name(path.name + ".new-" + secrets.token_hex(4))
    descriptor = os.open(str(temporary), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as output:
        output.write(encoded)
        output.flush()
        os.fsync(output.fileno())
    os.replace(temporary, path)


def parse_http_status(text):
    match = re.search(r"^HTTP/1\.[01] ([0-9]{3})(?: |\r?$)", text, re.MULTILINE)
    return int(match.group(1)) if match else None


def stable_state(state):
    return state.get("Running") is True and state.get("Restarting") is False and type(state.get("Pid")) is int and state["Pid"] > 0


def stopped_state(state, code):
    return state.get("Running") is False and state.get("Restarting") is False and state.get("ExitCode") == code


class Experiment:
    def __init__(self, run_id):
        if not re.fullmatch(r"[0-9]{8}t[0-9]{6}z-[0-9a-f]{8}", run_id):
            raise ValueError("invalid private run ID")
        self.run_id = run_id
        self.prefix = "omne-r5-sb-" + run_id
        self.label = "omne.r5.stop-intent=" + run_id
        self.out = RUNS / run_id
        self.dind = self.prefix + "-dind"
        self.control = self.prefix + "-control"
        self.volumes = [self.prefix + "-" + suffix for suffix in ("socket", "data", "daemon")]
        self.inner_ids = []
        self.waiters = []
        self.inner_image = None
        self.sequence = 0
        self.data = {
            "run_id": run_id, "label": self.label, "status": "not_started", "started_utc": None,
            "finished_utc": None, "commands": [], "outer_intents": [], "inner": [],
            "stages": {}, "cleanup": [], "fault_injection": {
                "checkpoint_failure": "not_executed_no_reliable_stock_Engine_injection",
                "concurrent_shutdown": "not_executed_no_deterministic_shuttingDown_barrier",
            },
        }

    def save(self):
        write_json(self.out / "result.json", self.data)

    def command(self, argv, timeout=60, stdin_path=None, checked=False):
        self.sequence += 1
        record = {"number": self.sequence, "argv": list(argv), "started_utc": utc(), "timeout_seconds": timeout}
        source = None
        try:
            if stdin_path is not None:
                record["stdin_source"] = str(stdin_path)
                record["stdin_sha256"] = sha(stdin_path)
                source = open(stdin_path, "rb")
            done = subprocess.run(argv, stdin=source, capture_output=True, timeout=timeout, check=False)
            record.update(returncode=done.returncode, stdout=done.stdout.decode("utf-8", "replace"),
                          stderr=done.stderr.decode("utf-8", "replace"))
        except subprocess.TimeoutExpired as error:
            record.update(returncode=None, timed_out=True,
                          stdout=(error.stdout or b"").decode("utf-8", "replace"),
                          stderr=(error.stderr or b"").decode("utf-8", "replace"))
        except OSError as error:
            record.update(returncode=None, local_error=type(error).__name__, stdout="", stderr="")
        finally:
            if source is not None:
                source.close()
        record["finished_utc"] = utc()
        path = self.out / "commands" / ("%04d.json" % self.sequence)
        write_json(path, record)
        self.data["commands"].append({"number": self.sequence, "path": str(path.relative_to(self.out))})
        self.save()
        if checked and record.get("returncode") != 0:
            raise RuntimeError("command %d failed or timed out" % self.sequence)
        return record

    def outer(self, *args, timeout=60, checked=True):
        return self.command(["docker", *args], timeout=timeout, checked=checked)

    def inner(self, *args, timeout=60, checked=True):
        return self.command(["docker", "exec", self.dind, "docker", "--host", SOCKET_URL, *args],
                            timeout=timeout, checked=checked)

    def api(self, path):
        record = self.command(["docker", "exec", self.control, "curl", "--http1.1", "--unix-socket",
                               SOCKET_PATH, "--silent", "--show-error", "--include", "--max-time", "20",
                               "--request", "POST", "http://localhost/v1.52" + path], timeout=25)
        record["http_status"] = parse_http_status(record.get("stdout", ""))
        # The raw command file remains unmodified; the separate stage records parsed status.
        return record

    def stage(self, name, **facts):
        self.data["stages"].setdefault(name, {}).update(facts)
        self.save()

    def preflight(self):
        require = lambda truth, message: None if truth else (_ for _ in ()).throw(RuntimeError(message))
        require(TAR.is_file() and sha(TAR) == TAR_SHA, "fixed BusyBox tar changed or missing")
        self.stage("preflight", tar={"path": str(TAR), "sha256": TAR_SHA, "bytes": TAR.stat().st_size})
        version = self.outer("version", "--format", "{{json .}}")
        parsed = json.loads(version["stdout"])
        require(parsed["Server"]["Version"] == "29.1.3" and parsed["Server"]["Os"] == "linux"
                and parsed["Server"]["Arch"] == "arm64", "outer Engine version/platform changed")
        self.stage("preflight", outer_engine={key: parsed["Server"].get(key) for key in ("Version", "Os", "Arch", "ApiVersion")})
        for image, expected in ((DIND_IMAGE, DIND_ID), (CONTROL_IMAGE, CONTROL_ID)):
            observed = self.outer("image", "inspect", "--format", "{{.Id}}|{{.Os}}|{{.Architecture}}", image)
            require(observed["stdout"].strip() == expected + "|linux|arm64", "cached image identity changed: " + image)
        for kind, names in (("container", [self.dind, self.control]), ("volume", self.volumes)):
            for name in names:
                observed = self.outer(kind, "inspect", name, checked=False)
                require(observed.get("returncode") not in (0, None), "resource name not safely absent: " + name)

    def create_outer(self, kind, name, argv):
        self.data["outer_intents"].append({"kind": kind, "name": name, "created": False})
        self.save()  # ownership intent precedes a possibly lost create receipt
        observed = self.command(argv, timeout=100, checked=True)
        self.data["outer_intents"][-1]["created"] = True
        self.data["outer_intents"][-1]["receipt"] = observed["stdout"].strip()
        self.save()

    def setup(self):
        self.preflight()
        for name in self.volumes:
            self.create_outer("volume", name, ["docker", "volume", "create", "--label", self.label, name])
        self.create_outer("container", self.dind,
                          ["docker", "run", "-d", "--pull", "never", "--name", self.dind,
                           "--label", self.label, "--network", "none", "--privileged",
                           "-e", "DOCKER_HOST=" + SOCKET_URL, "-e", "DOCKER_TLS_CERTDIR=",
                           "-v", self.volumes[0] + ":/opt/omne-private-docker",
                           "-v", self.volumes[1] + ":/stop-intent",
                           "-v", self.volumes[2] + ":/var/lib/docker", DIND_IMAGE,
                           "--host", SOCKET_URL, "--tls=false"])
        self.create_outer("container", self.control,
                          ["docker", "run", "-d", "--pull", "never", "--name", self.control,
                           "--label", self.label, "--network", "none",
                           "--entrypoint", "/bin/sh",
                           "-v", self.volumes[0] + ":/opt/omne-private-docker",
                           "-v", self.volumes[1] + ":/stop-intent",
                           CONTROL_IMAGE, "-c", "while :; do sleep 3600; done"])
        for name in (self.dind, self.control):
            item = json.loads(self.outer("container", "inspect", name)["stdout"])[0]
            if item["Config"]["Labels"].get("omne.r5.stop-intent") != self.run_id or any(
                mount.get("Type") == "bind" or mount.get("Source", "").endswith("docker.sock") for mount in item["Mounts"]
            ):
                raise RuntimeError("outer private-container ownership or mount check failed")
            self.stage("setup", **{name: {"Id": item["Id"], "Mounts": item["Mounts"], "NetworkMode": item["HostConfig"]["NetworkMode"]}})
        self.ready()
        self.command(["docker", "exec", "-i", self.dind, "docker", "--host", SOCKET_URL, "load"],
                     timeout=120, stdin_path=TAR, checked=True)
        image = json.loads(self.inner("image", "inspect", BUSYBOX)["stdout"])[0]
        if image["Os"] != "linux" or image["Architecture"] != "arm64":
            raise RuntimeError("private BusyBox platform mismatch")
        self.inner_image = image["Id"]
        self.stage("setup", inner_busybox={"Id": image["Id"], "Layers": image["RootFS"]["Layers"]})
        for source, target in ((HERE / "pid1-gate.sh", "/stop-intent/pid1-gate.sh"),
                               (HERE / "lossy-proxy.mjs", "/tmp/lossy-proxy.mjs")):
            self.command(["docker", "exec", "-i", self.control, "tee", target], stdin_path=source, checked=True)
        self.outer("exec", self.control, "chmod", "0755", "/stop-intent/pid1-gate.sh")

    def ready(self):
        deadline = time.monotonic() + 40
        while time.monotonic() < deadline:
            record = self.inner("version", "--format", "{{json .}}", timeout=7, checked=False)
            if record.get("returncode") == 0:
                try:
                    version = json.loads(record["stdout"])
                    if version["Server"]["Version"] == "29.1.3":
                        self.stage("setup", private_engine_version=version)
                        return
                except (ValueError, KeyError, TypeError):
                    pass
            time.sleep(0.5)
        raise RuntimeError("private Engine did not become ready")

    def inspect_inner(self, identifier):
        record = self.inner("container", "inspect", identifier)
        return record["number"], json.loads(record["stdout"])[0]

    def wait_state(self, identifier, predicate, seconds=20, interval=0.2):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            number, item = self.inspect_inner(identifier)
            if predicate(item["State"]):
                return number, item
            time.sleep(interval)
        raise RuntimeError("inner state condition not reached: " + identifier)

    def make_case(self, case, code, mode="gate", restart="unless-stopped"):
        if not re.fullmatch(r"[a-z0-9_-]+", case):
            raise ValueError("invalid fixture name")
        self.outer("exec", self.control, "sh", "-c",
                   "mkdir -p /stop-intent/%s && chown 10001:10001 /stop-intent/%s" % (case, case))
        name = self.prefix + "-" + case
        self.data["inner"].append({"case": case, "name": name, "id": None})
        self.save()
        made = self.inner("create", "--name", name, "--label", self.label,
                          "--network", "none", "--user", "10001:10001",
                          "--restart", restart, "--stop-signal", "SIGTERM",
                          "-v", "/stop-intent:/stop-intent", self.inner_image,
                          "sh", "/stop-intent/pid1-gate.sh", case, str(code), mode)
        identifier = made["stdout"].strip()
        if not re.fullmatch(r"[0-9a-f]{64}", identifier):
            raise RuntimeError("inner create did not return exact container ID")
        self.data["inner"][-1]["id"] = identifier
        self.save()
        return identifier

    def start_case(self, identifier, stable=True):
        self.inner("start", identifier)
        if stable:
            return self.wait_state(identifier, stable_state)
        return self.wait_state(identifier, lambda state: state.get("Running") is False)

    def release(self, case):
        self.outer("exec", self.control, "touch", "/stop-intent/" + case + "/release")

    def start_waiter(self, identifier, label):
        argv = ["docker", "exec", self.dind, "docker", "--host", SOCKET_URL, "wait", identifier]
        started = utc()
        process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.waiters.append(process)
        self.stage(label, waiter={"argv": argv, "started_utc": started, "pid": process.pid})
        return process

    def finish_waiter(self, process, label, timeout=90):
        stdout, stderr = process.communicate(timeout=timeout)
        if process in self.waiters:
            self.waiters.remove(process)
        fact = {"returncode": process.returncode, "stdout": stdout.decode("utf-8", "replace"),
                "stderr": stderr.decode("utf-8", "replace"), "finished_utc": utc()}
        self.stage(label, waiter_final=fact)
        return fact

    def restart_private_daemon(self, label):
        before = self.outer("container", "inspect", self.dind)
        self.outer("restart", "--time", "10", self.dind, timeout=45)
        self.ready()
        after = self.outer("container", "inspect", self.dind)
        self.stage(label, daemon_before_command=before["number"], daemon_after_command=after["number"])

    def gate_case(self, case, code):
        label = "gate_" + case
        identifier = self.make_case(case, code)
        before_command, before = self.start_case(identifier)
        waiter = self.start_waiter(identifier, label)
        time.sleep(0.25)
        if waiter.poll() is not None:
            raise RuntimeError("waiter ended before TERM")
        requested = self.inner("kill", "--signal=SIGTERM", identifier)
        acknowledged = time.monotonic()
        self.stage(label, container_id=identifier, before_inspect_command=before_command,
                   before=before["State"],
                   term_command=requested["number"], waiter_pending_after_term=waiter.poll() is None)
        if waiter.poll() is not None:
            raise RuntimeError("waiter ended at TERM receipt")
        term_deadline = time.monotonic() + 3
        while True:
            term_marker = self.outer("exec", self.control, "test", "-f",
                                     "/stop-intent/" + case + "/term-seen", checked=False)
            if term_marker.get("returncode") == 0:
                self.stage(label, term_marker_command=term_marker["number"])
                break
            if time.monotonic() >= term_deadline:
                raise RuntimeError("PID1 did not record SIGTERM receipt")
            time.sleep(0.1)
        time.sleep(HOLD_SECONDS)
        elapsed = time.monotonic() - acknowledged
        hold_command, held = self.inspect_inner(identifier)
        ps = self.command(["ps", "-p", str(waiter.pid), "-o", "pid=,stat=,command="], checked=False)
        self.stage(label, hold_seconds=elapsed, hold_inspect_command=hold_command,
                   hold_state=held["State"], hold_waiter_pending=waiter.poll() is None,
                   hold_waiter_ps_command=ps["number"])
        events = self.outer("exec", self.control, "cat", "/stop-intent/" + case + "/events")
        self.stage(label, hold_gate_events_command=events["number"])
        if elapsed <= 31 or waiter.poll() is not None or not stable_state(held["State"]):
            raise RuntimeError("TERM request was mistaken for actual exit")
        self.release(case)
        waited = self.finish_waiter(waiter, label)
        end_command, ended = self.wait_state(identifier, lambda state: stopped_state(state, code), seconds=20)
        self.stage(label, exit_inspect_command=end_command, exit_state=ended["State"],
                   wait_result=waited["stdout"].strip(), restart_count_before=ended["RestartCount"])
        events = self.outer("exec", self.control, "cat", "/stop-intent/" + case + "/events")
        self.stage(label, final_gate_events_command=events["number"])
        self.restart_private_daemon(label)
        after_command, after = self.inspect_inner(identifier)
        self.stage(label, after_daemon_inspect_command=after_command, after_daemon_state=after["State"],
                   restart_count_after=after["RestartCount"])
        if waited["stdout"].strip() != str(code) or not stopped_state(after["State"], code) or after["RestartCount"] != ended["RestartCount"]:
            raise RuntimeError("gate exit/wait/daemon persistence mismatch")

    def exited_api_case(self):
        identifier = self.make_case("already-exited", 0, mode="immediate", restart="no")
        self.start_case(identifier, stable=False)
        before_command, before = self.inspect_inner(identifier)
        stop = self.api("/containers/" + identifier + "/stop?t=-1")
        kill = self.api("/containers/" + identifier + "/kill?signal=SIGTERM")
        stop_cli = self.inner("stop", "--time=-1", identifier, checked=False)
        kill_cli = self.inner("kill", "--signal=SIGTERM", identifier, checked=False)
        after_command, after = self.inspect_inner(identifier)
        self.stage("already_exited", container_id=identifier, before_inspect_command=before_command,
                   before_state=before["State"], stop_api_command=stop["number"],
                   stop_api_status=stop["http_status"], kill_api_command=kill["number"],
                   kill_api_status=kill["http_status"], stop_cli_command=stop_cli["number"],
                   kill_cli_command=kill_cli["number"], after_inspect_command=after_command,
                   after_state=after["State"], signal_sent_claim=False)

    def restart_window_case(self):
        events_since = utc()  # create must be replayed before the restart-window request
        identifier = self.make_case("restart-window", 17, mode="crash")
        event_path = self.out / "restart-events.jsonl"
        event_error = self.out / "restart-events.stderr"
        with open(event_path, "wb") as output, open(event_error, "wb") as errors:
            argv = ["docker", "exec", self.dind, "docker", "--host", SOCKET_URL,
                    "events", "--since", events_since, "--filter", "container=" + identifier,
                    "--format", "{{json .}}"]
            listener = subprocess.Popen(argv, stdout=output, stderr=errors)
            self.stage("restart_window", container_id=identifier, events_argv=argv,
                       events_since=events_since, events_pid=listener.pid)
            try:
                ready_deadline = time.monotonic() + 10
                while True:
                    output.flush()
                    try:
                        replayed = [json.loads(line) for line in event_path.read_text().splitlines() if line.strip()]
                    except ValueError:
                        replayed = []
                    if any(isinstance(event, dict) and event.get("Action") == "create" and
                           isinstance(event.get("Actor"), dict) and event["Actor"].get("ID") == identifier
                           for event in replayed):
                        self.stage("restart_window", create_event_replayed=True)
                        break
                    if listener.poll() is not None or time.monotonic() >= ready_deadline:
                        raise RuntimeError("private event reader did not replay this container's create event")
                    time.sleep(0.1)
                self.inner("start", identifier)
                deadline = time.monotonic() + 30
                while True:
                    sample_command, sample = self.inspect_inner(identifier)
                    if sample["State"].get("Restarting") is True and sample["RestartCount"] >= 2:
                        break
                    if time.monotonic() >= deadline:
                        raise RuntimeError("actual restart backoff was not observed")
                    time.sleep(0.05)
                self.stage("restart_window", restarting_inspect_command=sample_command,
                           restarting_state=sample["State"], restart_count_before=sample["RestartCount"])
                term = self.api("/containers/" + identifier + "/kill?signal=SIGTERM")
                self.stage("restart_window", term_api_command=term["number"], term_api_status=term["http_status"])
                # The restart may proceed or stop; capture both without assuming either.
                time.sleep(3)
                after_command, after = self.inspect_inner(identifier)
                self.stage("restart_window", after_term_inspect_command=after_command,
                           after_term_state=after["State"], restart_count_after=after["RestartCount"])
                self.restart_private_daemon("restart_window")
                daemon_command, daemon_after = self.inspect_inner(identifier)
                self.stage("restart_window", after_daemon_inspect_command=daemon_command,
                           after_daemon_state=daemon_after["State"],
                           restart_count_after_daemon=daemon_after["RestartCount"])
            finally:
                listener.terminate()
                try:
                    listener.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    listener.kill()  # only the event-reader client, never the test application
                    listener.wait(timeout=5)
                self.stage("restart_window", events_client_returncode=listener.returncode,
                           events_file=str(event_path.relative_to(self.out)))

    def lossy_receipt_case(self):
        identifier = self.make_case("lost-receipt", 0)
        self.start_case(identifier)
        proxy_log = "/tmp/" + self.run_id + "-proxy.jsonl"
        self.outer("exec", "-d", "-e", "ENGINE_SOCKET=" + SOCKET_PATH,
                   "-e", "TARGET_ID=" + identifier, "-e", "PROXY_LOG=" + proxy_log,
                   self.control, "node", "/tmp/lossy-proxy.mjs")
        deadline = time.monotonic() + 10
        while True:
            ready = self.outer("exec", self.control, "curl", "--silent", "--show-error", "--max-time", "1",
                               "http://127.0.0.1:18765/health", checked=False)
            if ready.get("returncode") == 0 and ready["stdout"] == "ready":
                break
            if time.monotonic() >= deadline:
                raise RuntimeError("lossy proxy not ready")
            time.sleep(0.2)
        client = self.outer("exec", self.control, "curl", "--silent", "--show-error", "--max-time", "15",
                            "--request", "POST", "http://127.0.0.1:18765/trigger", checked=False)
        proxy = self.outer("exec", self.control, "cat", proxy_log)
        held_command, held = self.inspect_inner(identifier)
        self.stage("lost_receipt", container_id=identifier, caller_command=client["number"],
                   caller_returncode=client.get("returncode"), proxy_log_command=proxy["number"],
                   proxy_log=proxy["stdout"], hold_inspect_command=held_command, hold_state=held["State"],
                   caller_outcome="unknown_even_if_later_exited")
        try:
            relay = [json.loads(line) for line in proxy["stdout"].splitlines() if line.strip()]
        except ValueError:
            relay = []
        if (client.get("returncode") == 0 or len(relay) != 1 or
                relay[0].get("event") != "upstream_completed" or relay[0].get("status") != 204 or
                not stable_state(held["State"])):
            raise RuntimeError("lost-receipt proxy/caller contrast not established")
        self.release("lost-receipt")
        end_command, ended = self.wait_state(identifier, lambda state: stopped_state(state, 0))
        self.stage("lost_receipt", later_exit_inspect_command=end_command, later_exit_state=ended["State"])

    def waiter_abandon_case(self):
        identifier = self.make_case("waiter-abandon", 0)
        self.start_case(identifier)
        ack = self.api("/containers/" + identifier + "/kill?signal=SIGTERM")
        waiter = self.start_waiter(identifier, "waiter_abandon")
        time.sleep(0.3)
        pending = waiter.poll() is None
        termination = {"pid": waiter.pid, "signal": "SIGTERM", "sent": False, "at_utc": utc()}
        if pending:
            try:
                os.kill(waiter.pid, signal.SIGTERM)  # only the host-side wait client
                termination["sent"] = True
            except OSError as error:
                termination["error"] = type(error).__name__
        self.stage("waiter_abandon", caller_termination=termination)
        abandoned = self.finish_waiter(waiter, "waiter_abandon", timeout=10)
        held_command, held = self.inspect_inner(identifier)
        self.stage("waiter_abandon", container_id=identifier, term_api_command=ack["number"],
                   term_api_status=ack["http_status"], waiter_pending_before_exit=pending,
                   abandoned_waiter_returncode=abandoned["returncode"], hold_inspect_command=held_command,
                   hold_state=held["State"], caller_wait_result="unknown")
        if (ack["http_status"] != 204 or not pending or not termination["sent"] or
                abandoned["stdout"].strip() or not stable_state(held["State"])):
            raise RuntimeError("acknowledged TERM and abandoned waiter contrast not established")
        self.release("waiter-abandon")
        end_command, ended = self.wait_state(identifier, lambda state: stopped_state(state, 0))
        self.stage("waiter_abandon", later_exit_inspect_command=end_command, later_exit_state=ended["State"])

    def failure_snapshot(self):
        # Best effort at every failure stage, including failures before ready.
        for name in (self.dind, self.control):
            for command in (("container", "inspect", name), ("logs", name)):
                observed = self.outer(*command, timeout=15, checked=False)
                self.data.setdefault("failure_snapshot", []).append(observed["number"])
                self.save()
        if any(item["name"] == self.dind for item in self.data["outer_intents"]):
            observed = self.inner("ps", "-a", "--no-trunc", timeout=10, checked=False)
            self.data.setdefault("failure_snapshot", []).append(observed["number"])
            for item in self.data["inner"]:
                target = item.get("id") or item["name"]
                for operation in (("container", "inspect", target), ("logs", target)):
                    value = self.inner(*operation, timeout=10, checked=False)
                    self.data.setdefault("failure_snapshot", []).append(value["number"])
            self.save()

    def cleanup(self):
        for waiter in self.waiters:
            if waiter.poll() is None:
                waiter.terminate()  # only a host-side waiter client
            try:
                waiter.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                waiter.kill()
                waiter.communicate(timeout=5)
            self.data["cleanup"].append({"kind": "waiter_client", "pid": waiter.pid,
                                         "returncode": waiter.returncode})
        self.waiters.clear()
        self.save()
        for item in reversed(self.data["inner"]):
            target = item.get("id") or item["name"]
            inspect = self.inner("container", "inspect", target, timeout=10, checked=False)
            if inspect.get("returncode") == 0:
                try:
                    value = json.loads(inspect["stdout"])[0]
                    if value["Config"]["Labels"].get("omne.r5.stop-intent") == self.run_id:
                        removed = self.inner("rm", "-f", value["Id"], timeout=30, checked=False)
                        after = self.inner("container", "inspect", value["Id"], timeout=10, checked=False)
                        self.data["cleanup"].append({"kind": "inner", "id": value["Id"],
                                                     "command": removed["number"],
                                                     "remove_returncode": removed.get("returncode"),
                                                     "absent_after": after.get("returncode") not in (0, None)})
                    else:
                        self.data["cleanup"].append({"kind": "inner", "id": value["Id"],
                                                     "error": "foreign_label_refused"})
                except (ValueError, KeyError, TypeError, IndexError):
                    self.data["cleanup"].append({"kind": "inner", "id": target, "error": "inspect_unparseable"})
            else:
                self.data["cleanup"].append({"kind": "inner", "id": target, "error": "private_daemon_unavailable"})
            self.save()
        for intent in reversed(self.data["outer_intents"]):
            kind, name = intent["kind"], intent["name"]
            inspect = self.outer(kind, "inspect", name, timeout=10, checked=False)
            if inspect.get("returncode") != 0:
                self.data["cleanup"].append({"kind": kind, "name": name, "absent_before_remove": True})
                continue
            try:
                value = json.loads(inspect["stdout"])[0]
                labels = value["Config"]["Labels"] if kind == "container" else value["Labels"]
                if labels.get("omne.r5.stop-intent") != self.run_id:
                    self.data["cleanup"].append({"kind": kind, "name": name, "error": "foreign_label_refused"})
                    continue
                identifier = value["Id"] if kind == "container" else name
                args = ("rm", "-f", identifier) if kind == "container" else ("volume", "rm", name)
                removed = self.outer(*args, timeout=40, checked=False)
                after = self.outer(kind, "inspect", name, timeout=10, checked=False)
                self.data["cleanup"].append({"kind": kind, "name": name, "remove_command": removed["number"],
                                             "remove_returncode": removed.get("returncode"),
                                             "absent_after": after.get("returncode") not in (0, None)})
            except (ValueError, KeyError, TypeError, IndexError):
                self.data["cleanup"].append({"kind": kind, "name": name, "error": "inspect_unparseable"})
            self.save()

    def run(self, waiter_only=False):
        if self.out.exists():
            raise RuntimeError("refusing to overwrite private run evidence")
        self.out.mkdir(mode=0o700, parents=True)
        self.data["started_utc"] = utc()
        self.data["run_scope"] = "waiter_only" if waiter_only else "normal_matrix"
        self.data["status"] = "running"
        self.save()
        try:
            self.setup()
            if waiter_only:
                self.waiter_abandon_case()
                self.data["status"] = "waiter_observation_complete"
            else:
                self.gate_case("exit-zero", 0)
                self.gate_case("exit-one", 1)
                self.exited_api_case()
                self.restart_window_case()
                self.lossy_receipt_case()
                self.waiter_abandon_case()
                self.data["status"] = "observations_complete_with_uncovered_fault_injection"
        except BaseException as error:
            self.data["status"] = "experiment_failed"
            self.data["error"] = {"type": type(error).__name__, "message": str(error)}
            self.save()
            try:
                self.failure_snapshot()
            except BaseException as snapshot_error:
                self.data["failure_snapshot_error"] = {"type": type(snapshot_error).__name__,
                                                       "message": str(snapshot_error)}
        finally:
            try:
                self.cleanup()
            except BaseException as cleanup_error:
                self.data["cleanup_error"] = {"type": type(cleanup_error).__name__,
                                              "message": str(cleanup_error)}
            self.data["finished_utc"] = utc()
            self.save()
        return self.data["status"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("plan", "selftest", "run", "run-waiter"))
    parser.add_argument("--allow-docker", action="store_true")
    args = parser.parse_args()
    if args.action == "selftest":
        assert parse_http_status("HTTP/1.1 204 No Content\r\n\r\n") == 204
        assert parse_http_status("HTTP/1.1 304 Not Modified\r\n\r\n") == 304
        assert parse_http_status("not an HTTP response") is None
        assert stable_state({"Running": True, "Restarting": False, "Pid": 10})
        assert not stable_state({"Running": True, "Restarting": True, "Pid": 10})
        assert stopped_state({"Running": False, "Restarting": False, "ExitCode": 1}, 1)
        print("driver pure selftest passed; no Docker contacted")
        return 0
    if args.action == "plan":
        print(json.dumps({"scope": "one private DinD plus one private control container and three named volumes",
                          "outer_images": {DIND_IMAGE: DIND_ID, CONTROL_IMAGE: CONTROL_ID},
                          "busybox_tar_sha256": TAR_SHA, "private_socket": SOCKET_PATH,
                          "network": "none for outer and inner containers",
                          "normal_term": "SIGTERM only, never SIGKILL as a result claim",
                          "negative_injection": "checkpoint/shutdown not executable without reliable private fault barrier",
                          "run_requires": "later mainline review and explicit --allow-docker"}, indent=2))
        return 0
    if not args.allow_docker:
        parser.error("Docker run disabled without --allow-docker and mainline release")
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dt%H%M%Sz") + "-" + secrets.token_hex(4)
    experiment = Experiment(run_id)
    waiter_only = args.action == "run-waiter"
    status = experiment.run(waiter_only=waiter_only)
    import oracle  # independent read-only assessment of the saved raw commands/events
    assessed = oracle.assess_waiter(experiment.out) if waiter_only else oracle.assess(experiment.out)
    write_json(experiment.out / "oracle.json", assessed)
    print(json.dumps({"status": status, "run_dir": str(experiment.out),
                      "stages": list(experiment.data["stages"]),
                      "cleanup_count": len(experiment.data["cleanup"]),
                      "oracle_overall": assessed["overall"]}))
    accepted = ("waiter_observation_complete", "targeted_waiter_observed") if waiter_only else (
        "observations_complete_with_uncovered_fault_injection", "limited_mechanism_observed")
    return 0 if (status, assessed["overall"]) == accepted else 1


if __name__ == "__main__":
    signal.signal(signal.SIGINT, lambda *_args: (_ for _ in ()).throw(KeyboardInterrupt()))
    signal.signal(signal.SIGTERM, lambda *_args: (_ for _ in ()).throw(KeyboardInterrupt()))
    sys.exit(main())
