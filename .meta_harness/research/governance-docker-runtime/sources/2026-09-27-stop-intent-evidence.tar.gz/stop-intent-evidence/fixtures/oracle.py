#!/usr/bin/env python3
"""Read-only oracle for one private Engine stop-intent run.

It reads preserved command stdout/exit and raw event lines. A driver status or
callback alone never makes a scenario pass. Missing evidence fails closed.
"""

import argparse
import json
import pathlib
from datetime import datetime


def http_status(text):
    for line in text.splitlines():
        if line.startswith("HTTP/1."):
            fields = line.split()
            if len(fields) >= 2 and fields[1].isdigit():
                return int(fields[1])
    return None


def inspect_state(record):
    try:
        value = json.loads(record["stdout"])[0]
        return value if isinstance(value, dict) else None
    except (KeyError, ValueError, TypeError, IndexError):
        return None


def stopped(state, code):
    return (isinstance(state, dict) and state.get("Running") is False and
            state.get("Restarting") is False and state.get("ExitCode") == code)


def running(state):
    return (isinstance(state, dict) and state.get("Running") is True and
            state.get("Restarting") is False and type(state.get("Pid")) is int and state["Pid"] > 0)


def checks_verdict(checks):
    return "pass" if checks and all(checks.values()) else "fail"


class Evidence:
    def __init__(self, directory):
        self.directory = pathlib.Path(directory)
        self.data = json.loads((self.directory / "result.json").read_text())

    def command(self, number):
        if type(number) is not int:
            return {}
        path = self.directory / "commands" / ("%04d.json" % number)
        try:
            value = json.loads(path.read_text())
            return value if value.get("number") == number else {}
        except (OSError, ValueError):
            return {}

    def state(self, number):
        value = inspect_state(self.command(number))
        return value.get("State") if value and isinstance(value.get("State"), dict) else None

    def container(self, number):
        return inspect_state(self.command(number))


def gate_case(evidence, name, expected_exit):
    stage = evidence.data.get("stages", {}).get("gate_" + name)
    if not isinstance(stage, dict):
        return {"verdict": "not_executed"}
    term = evidence.command(stage.get("term_command"))
    before = evidence.state(stage.get("before_inspect_command"))
    held = evidence.state(stage.get("hold_inspect_command"))
    exited = evidence.state(stage.get("exit_inspect_command"))
    after_item = evidence.container(stage.get("after_daemon_inspect_command"))
    after = after_item.get("State") if after_item else None
    ps = evidence.command(stage.get("hold_waiter_ps_command"))
    term_marker = evidence.command(stage.get("term_marker_command"))
    hold_events = evidence.command(stage.get("hold_gate_events_command"))
    final_events = evidence.command(stage.get("final_gate_events_command"))
    waiter = stage.get("waiter_final") or {}
    checks = {
        "started_running": running(before),
        "term_cli_ack": term.get("returncode") == 0 and "--signal=SIGTERM" in term.get("argv", []),
        "pid1_term_seen": term_marker.get("returncode") == 0 and "term-seen " in hold_events.get("stdout", ""),
        "wait_pending_after_ack": stage.get("waiter_pending_after_term") is True,
        "hold_longer_than_31s": type(stage.get("hold_seconds")) in (int, float) and stage["hold_seconds"] > 31,
        "hold_process_running": running(held),
        "hold_waiter_alive": stage.get("hold_waiter_pending") is True and ps.get("returncode") == 0
                             and str((stage.get("waiter") or {}).get("pid", "")) in ps.get("stdout", ""),
        "released_exit_marker": ("released-exit %d" % expected_exit) in final_events.get("stdout", ""),
        "wait_exit_matches": waiter.get("returncode") == 0 and waiter.get("stdout", "").strip() == str(expected_exit),
        "inspect_exit_matches": stopped(exited, expected_exit),
        "post_daemon_still_stopped": stopped(after, expected_exit),
        "no_restart_across_daemon": (after_item is not None and
                                     stage.get("restart_count_before") == stage.get("restart_count_after") ==
                                     after_item.get("RestartCount")),
    }
    return {"verdict": checks_verdict(checks), "checks": checks,
            "container_id": stage.get("container_id"), "wait_stdout": waiter.get("stdout"),
            "hold_seconds": stage.get("hold_seconds")}


def already_exited(evidence):
    stage = evidence.data.get("stages", {}).get("already_exited")
    if not isinstance(stage, dict):
        return {"verdict": "not_executed"}
    before = evidence.state(stage.get("before_inspect_command"))
    after = evidence.state(stage.get("after_inspect_command"))
    stop = evidence.command(stage.get("stop_api_command"))
    kill = evidence.command(stage.get("kill_api_command"))
    stop_cli = evidence.command(stage.get("stop_cli_command"))
    kill_cli = evidence.command(stage.get("kill_cli_command"))
    checks = {
        "exited_before_both_apis": stopped(before, 0),
        "raw_stop_http_status": http_status(stop.get("stdout", "")) is not None,
        "raw_kill_http_status": http_status(kill.get("stdout", "")) is not None,
        "stop_cli_recorded": type(stop_cli.get("returncode")) is int,
        "kill_cli_recorded": type(kill_cli.get("returncode")) is int,
        "still_exited": stopped(after, 0),
        "no_signal_claim": stage.get("signal_sent_claim") is False,
    }
    return {"verdict": checks_verdict(checks), "checks": checks,
            "stop_api_status": http_status(stop.get("stdout", "")),
            "kill_api_status": http_status(kill.get("stdout", "")),
            "stop_cli_returncode": stop_cli.get("returncode"),
            "kill_cli_returncode": kill_cli.get("returncode"),
            "signal_sent": "not_inferred"}


def restart_window(evidence):
    stage = evidence.data.get("stages", {}).get("restart_window")
    if not isinstance(stage, dict):
        return {"verdict": "not_executed"}
    pre = evidence.container(stage.get("restarting_inspect_command"))
    post = evidence.container(stage.get("after_term_inspect_command"))
    after_daemon = evidence.container(stage.get("after_daemon_inspect_command"))
    request = evidence.command(stage.get("term_api_command"))
    raw_events = evidence.directory / stage.get("events_file", "missing-events")
    try:
        events = [json.loads(line) for line in raw_events.read_text().splitlines() if line.strip()]
    except (OSError, ValueError):
        events = []
    try:
        started = datetime.fromisoformat(request["started_utc"])
        finished = datetime.fromisoformat(request["finished_utc"])
        if started.tzinfo is None or finished.tzinfo is None:
            raise ValueError("request timestamps lack timezone")
        started_ns = int(started.timestamp()) * 1_000_000_000 + started.microsecond * 1_000
        finished_ns = int(finished.timestamp()) * 1_000_000_000 + finished.microsecond * 1_000
    except (KeyError, TypeError, ValueError):
        started_ns = None
        finished_ns = None
    container_id = stage.get("container_id")
    starts = [event for event in events if isinstance(event, dict) and event.get("Action") == "start" and
              isinstance(event.get("Actor"), dict) and event["Actor"].get("ID") == container_id and
              type(event.get("timeNano")) is int]
    starts_during_request = [event for event in starts if started_ns is not None and finished_ns is not None and
                             started_ns <= event["timeNano"] <= finished_ns]
    starts_after_ack = [event for event in starts if finished_ns is not None and
                        event["timeNano"] > finished_ns]
    pre_state = pre.get("State") if pre else None
    checks = {
        "event_stream_well_formed": bool(events) and all(isinstance(event, dict) for event in events),
        "event_reader_replayed_create": stage.get("create_event_replayed") is True and
                                        any(isinstance(event, dict) and event.get("Action") == "create" and
                                            isinstance(event.get("Actor"), dict) and
                                            event["Actor"].get("ID") == container_id for event in events),
        "actual_restart_window": isinstance(pre_state, dict) and pre_state.get("Restarting") is True and
                                 pre.get("RestartCount", 0) >= 2,
        "term_api_raw_status": http_status(request.get("stdout", "")) is not None,
        "request_time_boundaries": started_ns is not None and finished_ns is not None and finished_ns >= started_ns,
        "post_request_inspect": post is not None and isinstance(post.get("State"), dict),
        "cross_daemon_inspect": after_daemon is not None and isinstance(after_daemon.get("State"), dict),
    }
    status = http_status(request.get("stdout", ""))
    post_state = post.get("State") if post else None
    after_state = after_daemon.get("State") if after_daemon else None
    if not all(checks.values()):
        verdict = "fail"
    elif status != 204:
        verdict = "request_rejected"
    elif (starts_after_ack or post_state.get("Running") is True or post_state.get("Restarting") is True or
          after_state.get("Running") is True or after_state.get("Restarting") is True):
        verdict = "counterexample"
    elif (post_state.get("Running") is False and post_state.get("Restarting") is False and
          after_state.get("Running") is False and after_state.get("Restarting") is False):
        verdict = "limited_pass"
    else:
        verdict = "undetermined"
    return {"verdict": verdict, "observation_checks": checks,
            "term_api_status": status,
            "start_events_during_request": len(starts_during_request),
            "start_events_after_ack": len(starts_after_ack),
            "pre_daemon_state": post_state,
            "after_daemon_state": after_daemon.get("State") if after_daemon else None,
            "after_daemon_restart_count": after_daemon.get("RestartCount") if after_daemon else None}


def lost_receipt(evidence):
    stage = evidence.data.get("stages", {}).get("lost_receipt")
    if not isinstance(stage, dict):
        return {"verdict": "not_executed"}
    client = evidence.command(stage.get("caller_command"))
    proxy = evidence.command(stage.get("proxy_log_command"))
    held = evidence.state(stage.get("hold_inspect_command"))
    exited = evidence.state(stage.get("later_exit_inspect_command"))
    try:
        upstream = [json.loads(line) for line in proxy.get("stdout", "").splitlines() if line.strip()]
    except ValueError:
        upstream = []
    checks = {
        "exactly_one_upstream_ack": len(upstream) == 1 and isinstance(upstream[0], dict) and
                                    upstream[0].get("event") == "upstream_completed" and
                                    upstream[0].get("status") == 204,
        "caller_no_receipt": type(client.get("returncode")) is int and client["returncode"] != 0 and
                             http_status(client.get("stdout", "")) is None,
        "process_running_after_ack": running(held),
        "later_real_exit": stopped(exited, 0),
        "caller_remains_unknown": stage.get("caller_outcome") == "unknown_even_if_later_exited",
    }
    return {"verdict": checks_verdict(checks), "checks": checks,
            "caller_returncode": client.get("returncode"),
            "server_http_status": upstream[0].get("status") if upstream and isinstance(upstream[0], dict) else None,
            "caller_result": "unknown"}


def waiter_abandon(evidence):
    stage = evidence.data.get("stages", {}).get("waiter_abandon")
    if not isinstance(stage, dict):
        return {"verdict": "not_executed"}
    ack = evidence.command(stage.get("term_api_command"))
    held = evidence.state(stage.get("hold_inspect_command"))
    exited = evidence.state(stage.get("later_exit_inspect_command"))
    waiter = stage.get("waiter_final") or {}
    termination = stage.get("caller_termination") or {}
    checks = {
        "raw_term_ack": http_status(ack.get("stdout", "")) == 204,
        "waiter_was_pending": stage.get("waiter_pending_before_exit") is True,
        "caller_termination_sent": termination.get("sent") is True and termination.get("signal") == "SIGTERM" and
                                   termination.get("pid") == (stage.get("waiter") or {}).get("pid"),
        "waiter_client_exited": type(waiter.get("returncode")) is int,
        "no_wait_exit_result": isinstance(waiter.get("stdout"), str) and not waiter["stdout"].strip(),
        "application_still_running": running(held),
        "later_real_exit": stopped(exited, 0),
        "caller_remains_unknown": stage.get("caller_wait_result") == "unknown",
    }
    return {"verdict": checks_verdict(checks), "checks": checks,
            "caller_wait_result": "unknown", "waiter_returncode": waiter.get("returncode"),
            "waiter_stdout": waiter.get("stdout")}


def overall_status(stages, cleanup_complete):
    if any(stage["verdict"] == "fail" for stage in stages.values()):
        return "failed_observation"
    if stages["restart_window"]["verdict"] == "counterexample":
        return "candidate_counterexample"
    if stages["restart_window"]["verdict"] == "request_rejected":
        return "restart_window_request_rejected"
    if any(stage["verdict"] not in ("pass", "limited_pass") for stage in stages.values()):
        return "incomplete_observation"
    if not cleanup_complete:
        return "cleanup_unconfirmed"
    return "limited_mechanism_observed"


def assess(directory):
    evidence = Evidence(directory)
    stages = {
        "gate_exit_zero": gate_case(evidence, "exit-zero", 0),
        "gate_exit_one": gate_case(evidence, "exit-one", 1),
        "already_exited": already_exited(evidence),
        "restart_window": restart_window(evidence),
        "lost_receipt": lost_receipt(evidence),
        "waiter_abandon": waiter_abandon(evidence),
    }
    cleanup = evidence.data.get("cleanup", [])
    outer_cleanup = {(entry.get("kind"), entry.get("name")) for entry in cleanup
                     if entry.get("kind") in ("container", "volume")}
    inner_cleanup = {entry.get("id") for entry in cleanup if entry.get("kind") == "inner"}
    all_targets_recorded = all(
        (intent.get("kind"), intent.get("name")) in outer_cleanup
        for intent in evidence.data.get("outer_intents", [])
    ) and all(
        (item.get("id") or item.get("name")) in inner_cleanup
        for item in evidence.data.get("inner", [])
    )
    cleanup_complete = bool(cleanup) and all_targets_recorded and evidence.data.get("cleanup_error") is None and all(
        entry.get("error") is None and
        entry.get("remove_returncode", 0) == 0 and
        (entry.get("absent_after") is True or entry.get("absent_before_remove") is True or
         (entry.get("kind") == "waiter_client" and type(entry.get("returncode")) is int))
        for entry in cleanup
    )
    overall = overall_status(stages, cleanup_complete)
    if evidence.data.get("status") != "observations_complete_with_uncovered_fault_injection" and overall == "limited_mechanism_observed":
        overall = "driver_failed"
    return {"overall": overall, "driver_status": evidence.data.get("status"),
            "stages": stages, "cleanup_complete": cleanup_complete,
            "checkpoint_failure": "not_covered",
            "concurrent_daemon_shutdown": "not_covered",
            "scope": "private Engine fixture only; not product helper or D-067 adoption"}


def assess_waiter(directory):
    full = assess(directory)
    stage = full["stages"]["waiter_abandon"]
    if stage["verdict"] != "pass":
        overall = "failed_observation"
    elif not full["cleanup_complete"]:
        overall = "cleanup_unconfirmed"
    elif full["driver_status"] != "waiter_observation_complete":
        overall = "driver_failed"
    else:
        overall = "targeted_waiter_observed"
    return {"overall": overall, "driver_status": full["driver_status"],
            "waiter_abandon": stage, "cleanup_complete": full["cleanup_complete"],
            "scope": "targeted private waiter fixture only; prior five observations are separate"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_directory", type=pathlib.Path)
    args = parser.parse_args()
    result = assess(args.run_directory)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["overall"] == "limited_mechanism_observed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
