# R5 S-B 采用前 Engine 实验 · V1

执行仓库 /Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-stop-intent，分支 pandazki/agent-work-loop-docker-stop-intent，基线06ab4fc0。第一步 cd 并核 branch/HEAD。你不是独自工作，不撤别人修改。根主检出与HUB不可写。只写本spoke tmp/docker-stop-intent/**；无产品/设计修改、无commit/push、无OpenRouter请求。编码由 verification-developer GPT-6 Sol xhigh，root设计、复核和接受。

## 输入与目标

HUB绝对路径 /Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish。读其未接受候选 .meta_harness/design/record/proposals/governance-docker-deployment/stop-r5.md，SHA ac3a700fea0a8e03185022999d0c69faf4b3208b7ca2a58ae896bc1e8d7a1d1d，以及 research/governance-docker-runtime 的2026-09-27-engine-stop-source报告/归档，D067、EC3/HT3相关停止责任。不要据此改有效D067。

目标仅测 Engine29.1.3 显式 SIGTERM API 与人工停止标记/实际退出的关系，为S-B取舍提供事实。不把Engine夹具当最终helper/产品验收。复用已通过V0c的私有DinD模式与本地固定image，参考 ../agent-work-loop-docker-fixtures/tmp/docker-product-fixtures/ 下脚本（只读），不复制其复杂IOgate为本次必要依赖。外层Docker只管理本轮唯一标签资源；不得重启用户daemon、挂用户socket给内层、删除他人资源、pull变动tag或接触密钥。保留资源name/id/完整命令、版本、退出和时间原件，失败也采inspect/log，再清理自有资源。

## 验收矩阵与边界

1. PID1接SIGTERM后持有闸门>31s；kill --signal=SIGTERM返回后wait仍pending、进程未退出；释放后实际exit0和exit1分别wait/inspect一致，再重启私有daemon仍停止。不得正常路径SIGKILL或外层超时冒充应用结束。
2. 已经退出样本：原样记录stop API与kill(SIGTERM) API的HTTP状态/响应，并给CLI状态；不推断这次发出了信号。
3. 实际restart backoff窗口发送TERM，记录请求、后续start事件和跨daemon状态。必须捕获Restarting=true或等价原始事件证据，不能只启动正常运行者后声称测到。若不支持必须交反例，不删场景。可补读固定上游GetRunningTask/ExitOnNext源码并保存出处/版本。
4. caller回执丢失、ack后waiter退出：代理或测量夹具可在确认转发/响应后主动断开，保存服务端可见与调用者可见的不同事实；不自动重发，不从后来的exited清除unknown。明确哪些是协议观测、哪些是拟议helper将来要验证的行为。
5. checkpoint失败与并发shutdown条件负例：先设计最小可执行注入，只限私有daemon。如果无法可靠注入/区分机制，明确未覆盖并交主线，不编造“负例通过”。不得为注入修改产品源码；若要定制Engine或外部下载先回报成本，先做可行性草案。

## 波次

当前只释放静态阶段：环境/资源/清理计划、完整driver、独立oracle、离线自测和逐文件SHA。脚本必须在任意阶段失败时捕获足够原始证据，不能只等ready后删除现场。所有Docker实际运行、image构建、daemon重启实验留到root静态复核后单次放行。可读现有文件/镜像metadata，不启动资源。

root审核后才一轮实际实验；失败停止，不自动修改/重跑。报告区分通过/失败/未覆盖；采用由root在独立评审后新决定，不由测量作者决定。保留失败原件与hash，证据不能只有成功截图或结论。复杂歧义、输入hash不符、环境缺失则停依赖分支并报告，其余独立静态工作可继续。
