#!/usr/bin/env python3
"""Check that probe evidence distinguishes wait, forced kill, and restart."""

import json
from pathlib import Path
import sys


run = Path(sys.argv[1]).resolve()
results = json.loads((run / "results.json").read_text())
events = json.loads((run / "daemon-events-and-cleanup.json").read_text())
checks = {}


def check(name, condition):
    checks[name] = bool(condition)


for key in ("p1_engine_infinite", "p2_compose_flag", "p3_grace_default_stop", "p3_grace_default_down"):
    r = results[key]
    check(key + "-waited", r.get("started") and r.get("term_seen")
          and r.get("command_pending_after_16s") and r.get("running_after_16s")
          and r.get("restart_count_after_16s") == 0)
    check(key + "-released", r.get("returncode") == 0
          and r.get("release_returncode") == 0 and r.get("released_in_followed_logs"))
    if key != "p3_grace_default_down":
        check(key + "-exit0", r.get("exit_code") == 0 and r.get("running_after_stop") is False)
for key in ("p3_grace_default_stop", "p3_grace_default_down"):
    check(key + "-engine-timeout", results[key].get("stop_timeout") == -1)
check("p3-down-removed", "Removed" in results["p3_grace_default_down"].get("stderr", ""))

negative = results["negative_engine_short"]
check("negative-kill", negative.get("term_seen") and negative.get("returncode") == 0
      and negative.get("exit_code") == 137 and not negative.get("released_in_followed_logs"))

explicit = results["p4_explicit_stop"]
check("p4-explicit-stays-stopped", explicit.get("returncode") == 0
      and explicit.get("running_after_12s_stopped") is False
      and explicit.get("restart_count_after_12s_stopped") == 0)

nonzero = results["p4_nonzero_restart"]
daemon_events = events["p4_nonzero_restart"]["events"]
die23 = next((i for i, event in enumerate(daemon_events)
              if event["action"] == "die" and event["exitCode"] == "23"), None)
restarted = die23 is not None and any(event["action"] == "start"
                                       for event in daemon_events[die23 + 1:])
logs = (run / "p4_nonzero_restart" / "logs-after-restart.txt").read_text()
check("p4-nonzero-restarts", nonzero.get("restart_observed")
      and nonzero.get("restart_count") == 1 and restarted
      and logs.count('"event":"START"') == 2)

for kind in ("ps", "network", "volume"):
    check("cleanup-" + kind, events["remaining_" + kind]["returncode"] == 0
          and not events["remaining_" + kind]["matches"])

output = {"checks": checks, "passed": sum(checks.values()), "total": len(checks)}
(run / "checks.json").write_text(json.dumps(output, indent=2) + "\n")
print(json.dumps(output, indent=2))
sys.exit(0 if all(checks.values()) else 1)
