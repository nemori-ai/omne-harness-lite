#!/usr/bin/env python3
"""Hash the probe folder for evidence handoff (excluding this generated manifest)."""

import hashlib
import json
from pathlib import Path


root = Path(__file__).resolve().parent
files = []
for path in sorted(root.rglob("*")):
    if path.is_file() and path.name != "manifest.json":
        content = path.read_bytes()
        files.append({"path": str(path.relative_to(root)), "bytes": len(content),
                      "sha256": hashlib.sha256(content).hexdigest()})
manifest = {"files": files, "count": len(files), "total_bytes": sum(f["bytes"] for f in files)}
(root / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"count": manifest["count"], "total_bytes": manifest["total_bytes"]}))
