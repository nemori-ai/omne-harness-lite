#!/usr/bin/env python3
"""Capture daemon events and surviving probe resources for one finished run."""

from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import subprocess
import sys


run = Path(sys.argv[1]).resolve()
run_id = run.name
start = datetime.strptime(run_id[:16], "%Y%m%dT%H%M%SZ").replace(tzinfo=timezone.utc)
since = (start - timedelta(seconds=5)).isoformat()
until = datetime.now(timezone.utc).isoformat()
prefix = "omne-m0-docker-probe-" + run_id.lower().replace("t", "-").replace("z", "")
summary = {}
for case in sorted(p for p in run.iterdir() if p.is_dir()):
    name = prefix + "-" + case.name.replace("_", "-")
    args = ["docker", "events", "--since", since, "--until", until,
            "--filter", "container=" + name, "--format", "{{json .}}"]
    cp = subprocess.run(args, capture_output=True, text=True, timeout=20)
    (case / "docker-events.jsonl").write_text(cp.stdout)
    (case / "docker-events.stderr.txt").write_text(cp.stderr)
    events = [json.loads(line) for line in cp.stdout.splitlines() if line]
    summary[case.name] = {
        "command": args, "returncode": cp.returncode,
        "events": [{"action": e["Action"], "timeNano": e["timeNano"],
                    "exitCode": e["Actor"]["Attributes"].get("exitCode")}
                   for e in events],
    }
for kind in ("ps", "network", "volume"):
    args = ["docker", kind, "ls"] if kind != "ps" else ["docker", "ps", "-a"]
    args += ["--format", "{{json .}}"]
    cp = subprocess.run(args, capture_output=True, text=True, timeout=20)
    records = [json.loads(line) for line in cp.stdout.splitlines() if line]
    matches = [record for record in records if run_id.lower().replace("t", "").replace("z", "").replace("-", "") in json.dumps(record).lower().replace("-", "") or prefix in json.dumps(record)]
    summary["remaining_" + kind] = {"command": args, "returncode": cp.returncode,
                                    "matches": matches, "stderr": cp.stderr}
(run / "daemon-events-and-cleanup.json").write_text(json.dumps(summary, indent=2) + "\n")
print(run / "daemon-events-and-cleanup.json")
