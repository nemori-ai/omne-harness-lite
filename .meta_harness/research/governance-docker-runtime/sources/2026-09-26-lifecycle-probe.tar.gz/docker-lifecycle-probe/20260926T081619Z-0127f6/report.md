# M0-V2 Docker 生命周期机制探针

本次结果只属于 Docker Desktop 4.55.0（Engine 29.1.3、Linux arm64、kernel 6.12.54-linuxkit）、Docker CLI 29.1.3（macOS arm64）、Compose v2.40.3-desktop.1 与本地 `node:24.21.0`。源码工作树是 `pandazki/agent-work-loop-docker-probe`，HEAD `2cb236db7da15e78bb1e96dd8220ee68b6eceb75`，执行前干净。镜像 RepoDigest 为 `node@sha256:64af3819f9275802414d7cdc38c27e9d82bd564dec4d4da87d008255d36c63b4`，Linux/arm64 镜像 ID 为 `sha256:7e6ba96b9576ae44872bdb57bc0665a70fd87bbc7c8a019ab849429c6c69ef44`。`inputs.json` 保存原始工具输出、完整夹具正文及其 SHA-256 `356523594b9dd1c798faccce1c0bc1382b0bf8d7766c69203c2b54d68475bb79`。

判据来自已接受的 `composition.governance-center-entry/v3#S-59`：正常关闭须等在途工作与资源真实收场，不能用有限期限冒充完成；以及 `realization/apps/tenancy-host/maintenance-binding.md` 的 30 秒诊断、继续等待候选。D055 的 `acceptance.json` 与 registry 已接受 EC3 v3 S-1～S-59；冻结契约页首保留的 candidate 字样是旧稿痕迹。Docker/Compose 部署机制本身仍待设计采用，本报告没有采用权。官方 [Docker stop 参考](https://docs.docker.com/reference/cli/docker/container/stop/)明确 `--timeout -1` 不应用超时；[Compose service 参考](https://docs.docker.com/reference/compose-file/services/)定义 `stop_grace_period` 和 `restart: on-failure`，但未承诺负 duration 表示无限等待；后者以本次实测为准。

运行命令：在指定 worktree 执行 `python3 tmp/docker-lifecycle-probe/probe.py`，再执行 `python3 tmp/docker-lifecycle-probe/capture_events.py tmp/docker-lifecycle-probe/20260926T081619Z-0127f6` 与 `python3 tmp/docker-lifecycle-probe/check_results.py tmp/docker-lifecycle-probe/20260926T081619Z-0127f6`。每个 case 的 `stop-result.json` 保留完整停止命令、单调时钟耗时、命令退出码与 inspect 判据；`commands.jsonl` 保留创建、inspect、日志、释放和清理命令及原始 stdout/stderr。`inspect-*.json` 是完整 Engine JSON，`logs-*.txt` 是带时间戳的容器日志。夹具以 `node -e` 作为容器命令，日志报告 `pid:1`，每例 `inspect-before-stop.json` 保留镜像入口与命令；TERM 后只等容器内 `/tmp/probe-release` 门，释放由 `docker exec ... touch` 完成。容器和 Compose 项目均有唯一的本次前缀，网络为 `none`，无卷，无外部服务。

| 条款/场景 | 原始结果 | 有限判定 |
| --- | --- | --- |
| P1 Engine `docker stop --timeout -1` | TERM 已入日志；16 秒时停止命令未返回、`State.Running=true`、`RestartCount=0`；释放门后命令 0、容器退出码 0 | 当前 Engine 上跨过 Linux 默认 10 秒仍等待，未强杀 |
| 负对照 Engine `--timeout 2` | TERM 已入日志，门未释放；约 2.06 秒后停止命令 0、容器退出码 137，无 RELEASED | 检出强杀，说明测量可区分超时与正常结束；CLI 的命令码 0 不代表容器退出码 0 |
| P2 `compose stop --timeout -1` | 容器创建时 `Config.StopTimeout=1`；TERM 后 16 秒仍运行且命令未返回；释放后命令 0、容器退出码 0 | 当前 Compose 的显式 -1 参数覆盖创建配置并等待；创建配置的 1 未被误报为无限 |
| P3 `stop_grace_period: -1s` + 默认 `compose stop` | `compose config` 接受；Engine `Config.StopTimeout=-1`；TERM 后 16 秒仍运行且命令未返回；释放后命令 0、容器退出码 0 | 当前 Compose 可用该字段表达本路径的正常等待 |
| P3 同配置 + 默认 `compose down` | `compose config` 接受；Engine `Config.StopTimeout=-1`；TERM 后 16 秒仍运行且命令未返回；跟随日志见 RELEASED，随后 Compose 输出 Stopped、Removed，命令 0 | 当前 Compose down 在释放后才移除；移除后无法再 inspect 退出码，不能把该行写成独立测得退出码 0 |
| P4 `restart: on-failure` + 显式 `compose stop --timeout -1` | TERM 后 16 秒仍运行；释放后容器退出码 0；再观察 12 秒仍 stopped、`RestartCount=0` | 本次有意停止未自行重启 |
| P4 同策略 + 程序非零退出 | 11.5 秒后日志给出 EXIT_NONZERO，Docker daemon 事件独立记录 `die exitCode=23` 后 `start`；inspect `RestartCount=1`，两次 START 日志均为 PID 1；随后显式停止第二次运行 | 本次异常退出确实触发一次重启；第二次运行受控停止，未制造无限循环 |

测量自检见 `checks.json`：20/20 条通过。它同时要求负对照为 137、P4 daemon 事件里的 23 后有 start、P3 在 Engine inspect 中为 -1，避免只依赖夹具自己打印的“成功”。`daemon-events-and-cleanup.json` 的事件回看只取到了最近的 P4 非零事件；早期容器事件已无法从 daemon 回看，故早期判断使用当时保存的 inspect、跟随日志与停止进程状态。P3 `down` 的容器退出码因容器已移除而未读取。探针没有测 daemon 重启、宿主崩溃、IO 不进展、跨版本、真实业务备份与资源所有权；16 秒观察只是超过 Linux 默认 10 秒的有限反例，不能证明任意长时间都不会强杀，也不能替代产品验收或形式证明。

每例的 `commands.jsonl` 均记录自建容器的 `docker rm -f` 或本项目的 `compose down` 及随后的 inspect 不存在结果。最终资源核对 `daemon-events-and-cleanup.json` 显示本次前缀的容器、网络与卷均为零。未删除镜像、修改全局 Docker 设置或触及他人资源。
