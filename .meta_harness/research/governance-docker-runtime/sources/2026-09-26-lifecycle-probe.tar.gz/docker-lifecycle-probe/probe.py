#!/usr/bin/env python3
"""Run bounded Docker lifecycle observations; writes only beside this script."""

import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
import time
from datetime import datetime, timezone


ROOT = Path(__file__).resolve().parent
RUN_ID = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(3)
RUN = ROOT / RUN_ID
RUN.mkdir(mode=0o700)
PREFIX = "omne-m0-docker-probe-" + RUN_ID.lower().replace("t", "-").replace("z", "")
IMAGE = "node:24.21.0"
FIXTURE = r"""
const fs = require('node:fs');
const mode = process.env.PROBE_MODE || 'wait';
console.log(JSON.stringify({event:'START', pid:process.pid, mode, at:new Date().toISOString()}));
if (mode === 'fail-once' && !fs.existsSync('/tmp/probe-first-run')) {
  fs.writeFileSync('/tmp/probe-first-run', '1');
  setTimeout(() => {
    console.log(JSON.stringify({event:'EXIT_NONZERO', code:23, at:new Date().toISOString()}));
    process.exit(23);
  }, 11500);
}
process.on('SIGTERM', () => {
  console.log(JSON.stringify({event:'TERM', pid:process.pid, at:new Date().toISOString()}));
  const poll = setInterval(() => {
    if (fs.existsSync('/tmp/probe-release')) {
      clearInterval(poll);
      console.log(JSON.stringify({event:'RELEASED', at:new Date().toISOString()}));
      process.exit(0);
    }
  }, 100);
});
setInterval(() => {}, 1000);
""".strip()


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def command(case, label, args, timeout=30):
    started = time.monotonic()
    try:
        cp = subprocess.run(args, text=True, capture_output=True, timeout=timeout)
        result = {"label": label, "command": args, "at": utc(), "elapsed_s": time.monotonic()-started,
                  "returncode": cp.returncode, "stdout": cp.stdout, "stderr": cp.stderr}
    except subprocess.TimeoutExpired as exc:
        result = {"label": label, "command": args, "at": utc(), "elapsed_s": time.monotonic()-started,
                  "timeout_s": timeout, "stdout": str(exc.stdout), "stderr": str(exc.stderr)}
    with (case / "commands.jsonl").open("a") as out:
        out.write(json.dumps(result, ensure_ascii=False) + "\n")
    return result


def inspect(case, name, label):
    r = command(case, "inspect-"+label, ["docker", "inspect", name])
    if r.get("returncode") == 0:
        write_json(case / ("inspect-"+label+".json"), json.loads(r["stdout"]))
        return json.loads(r["stdout"])[0]
    return None


def logs(case, name, label):
    r = command(case, "logs-"+label, ["docker", "logs", "--timestamps", name])
    (case / ("logs-"+label+".txt")).write_text(r.get("stdout", "") + r.get("stderr", ""))
    return r.get("stdout", "") + r.get("stderr", "")


def wait_for(case, name, needle, seconds=12):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if needle in logs(case, name, "poll"):
            return True
        time.sleep(0.3)
    return False


def compose_args(case, project):
    return ["docker", "compose", "-p", project, "-f", str(case / "compose.yaml")]


def make_compose(case, name, restart=None, grace=None, mode="wait"):
    lines = ["services:", "  probe:", "    image: " + IMAGE, "    pull_policy: never",
             "    network_mode: none", "    container_name: " + name,
             "    environment:", "      PROBE_MODE: " + mode,
             "    command: [\"node\", \"-e\", " + json.dumps(FIXTURE) + "]"]
    if restart is not None:
        lines.append("    restart: " + json.dumps(restart))
    if grace is not None:
        lines.append("    stop_grace_period: " + json.dumps(grace))
    (case / "compose.yaml").write_text("\n".join(lines) + "\n")


def start_cli(case, name, restart=None, mode="wait"):
    args = ["docker", "run", "-d", "--name", name, "--network", "none",
            "--label", "omne.m0.probe="+RUN_ID]
    if restart:
        args += ["--restart", restart]
    args += ["-e", "PROBE_MODE="+mode, IMAGE, "node", "-e", FIXTURE]
    r = command(case, "run", args)
    return r.get("returncode") == 0 and wait_for(case, name, '"event":"START"')


def start_compose(case, name, project, restart=None, grace=None, mode="wait"):
    make_compose(case, name, restart, grace, mode)
    c = compose_args(case, project)
    conf = command(case, "compose-config", c + ["config"])
    if conf.get("returncode") != 0:
        return False, "config-rejected"
    up = command(case, "compose-up", c + ["up", "-d"])
    if up.get("returncode") != 0:
        return False, "up-failed"
    return wait_for(case, name, '"event":"START"'), "started"


def stop_observation(case, name, args, negative=False):
    before = inspect(case, name, "before-stop")
    follower = subprocess.Popen(["docker", "logs", "--follow", "--timestamps", name],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    time.sleep(0.2)
    start = time.monotonic()
    started_at = utc()
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    term_seen = wait_for(case, name, '"event":"TERM"', 6)
    if not negative:
        time.sleep(max(0, 16 - (time.monotonic() - start)))
        middle = inspect(case, name, "after-16s")
        still_waiting = proc.poll() is None
        release = command(case, "release", ["docker", "exec", name, "touch", "/tmp/probe-release"])
    else:
        middle = None
        still_waiting = None
        release = None
    try:
        stdout, stderr = proc.communicate(timeout=15)
        rc = proc.returncode
    except subprocess.TimeoutExpired:
        stdout, stderr, rc = "", "stop command exceeded 15s after release", None
    try:
        followed_stdout, followed_stderr = follower.communicate(timeout=2)
    except subprocess.TimeoutExpired:
        follower.terminate()
        followed_stdout, followed_stderr = follower.communicate(timeout=3)
    (case / "logs-follow-stop.txt").write_text(followed_stdout + followed_stderr)
    result = {"command": args, "started_at": started_at, "elapsed_s": time.monotonic()-start,
              "returncode": rc, "stdout": stdout, "stderr": stderr,
              "term_seen": term_seen, "command_pending_after_16s": still_waiting,
              "running_after_16s": middle["State"]["Running"] if middle else None,
              "restart_count_after_16s": middle["RestartCount"] if middle else None,
              "release_returncode": release.get("returncode") if release else None,
              "follower_returncode": follower.returncode,
              "released_in_followed_logs": '"event":"RELEASED"' in followed_stdout,
              "exit_code": None}
    after = inspect(case, name, "after-stop")
    if after:
        result["exit_code"] = after["State"]["ExitCode"]
        result["running_after_stop"] = after["State"]["Running"]
        result["restart_count_after_stop"] = after["RestartCount"]
    logs(case, name, "after-stop")
    write_json(case / "stop-result.json", result)
    return result


def clean_cli(case, name):
    command(case, "cleanup-rm", ["docker", "rm", "-f", name])
    command(case, "cleanup-check", ["docker", "inspect", name])


def clean_compose(case, project, name):
    command(case, "cleanup-down", compose_args(case, project) + ["down", "--remove-orphans"])
    command(case, "cleanup-check", ["docker", "inspect", name])


results = {}
environment = {
    "run_id": RUN_ID, "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "git_branch": subprocess.check_output(["git", "branch", "--show-current"], text=True).strip(),
    "fixture_sha256": hashlib.sha256(FIXTURE.encode()).hexdigest(), "fixture": FIXTURE,
    "image": IMAGE,
}
for label, args in [("docker_version", ["docker", "version", "--format", "{{json .}}"]),
                    ("compose_version", ["docker", "compose", "version", "--format", "json"]),
                    ("image_inspect", ["docker", "image", "inspect", IMAGE]),
                    ("platform", ["uname", "-a"])]:
    environment[label] = command(RUN, label, args)
if environment["image_inspect"].get("returncode") == 0:
    image_details = json.loads(environment["image_inspect"]["stdout"])[0]
    environment["image_digest"] = image_details["RepoDigests"]
    environment["image_id"] = image_details["Id"]
write_json(RUN / "inputs.json", environment)


def case_dir(key):
    p = RUN / key
    p.mkdir(mode=0o700)
    return p


def perform(key, action):
    case = case_dir(key)
    try:
        results[key] = action(case)
    except Exception as exc:
        results[key] = {"exception": repr(exc)}
    write_json(RUN / "results.json", results)


def cli_case(case, key, timeout, negative=False):
    name = PREFIX + "-" + key.replace("_", "-")
    started = start_cli(case, name)
    try:
        if not started:
            return {"started": False}
        return {"started": True, **stop_observation(case, name,
                ["docker", "stop", "--timeout", str(timeout), name], negative)}
    finally:
        clean_cli(case, name)


perform("p1_engine_infinite", lambda c: cli_case(c, "p1_engine_infinite", -1))
perform("negative_engine_short", lambda c: cli_case(c, "negative_engine_short", 2, True))


def compose_case(case, key, command_tail, grace=None):
    name = PREFIX + "-" + key.replace("_", "-")
    project = PREFIX.replace("-", "") + key.replace("_", "")
    started, reason = start_compose(case, name, project, grace=grace)
    try:
        if not started:
            return {"started": False, "reason": reason}
        actual = inspect(case, name, "created")
        result = stop_observation(case, name, compose_args(case, project) + command_tail)
        return {"started": True, "stop_timeout": actual["Config"]["StopTimeout"], **result}
    finally:
        clean_compose(case, project, name)


perform("p2_compose_flag", lambda c: compose_case(c, "p2_compose_flag", ["stop", "--timeout", "-1"]))
perform("p3_grace_default_stop", lambda c: compose_case(c, "p3_grace_default_stop", ["stop"], "-1s"))
perform("p3_grace_default_down", lambda c: compose_case(c, "p3_grace_default_down", ["down"], "-1s"))


def restart_explicit(case):
    key = "p4_explicit_stop"
    name = PREFIX + "-" + key.replace("_", "-")
    project = PREFIX.replace("-", "") + key.replace("_", "")
    started, reason = start_compose(case, name, project, restart="on-failure")
    try:
        if not started:
            return {"started": False, "reason": reason}
        result = stop_observation(case, name, compose_args(case, project) + ["stop", "--timeout", "-1"])
        time.sleep(12)
        after = inspect(case, name, "after-12s-stopped")
        logs(case, name, "after-12s-stopped")
        return {"started": True, **result,
                "running_after_12s_stopped": after["State"]["Running"],
                "restart_count_after_12s_stopped": after["RestartCount"]}
    finally:
        clean_compose(case, project, name)


def restart_nonzero(case):
    key = "p4_nonzero_restart"
    name = PREFIX + "-" + key.replace("_", "-")
    project = PREFIX.replace("-", "") + key.replace("_", "")
    started, reason = start_compose(case, name, project, restart="on-failure", mode="fail-once")
    try:
        if not started:
            return {"started": False, "reason": reason}
        first = inspect(case, name, "first-start")
        deadline = time.monotonic() + 35
        second = None
        while time.monotonic() < deadline:
            current = inspect(case, name, "restart-poll")
            if current and current["RestartCount"] >= 1 and current["State"]["Running"]:
                second = current
                break
            time.sleep(0.5)
        logs(case, name, "after-restart")
        if not second:
            return {"started": True, "restart_observed": False}
        stop = stop_observation(case, name, compose_args(case, project) + ["stop", "--timeout", "-1"])
        return {"started": True, "restart_observed": True,
                "first_started_at": first["State"]["StartedAt"],
                "second_started_at": second["State"]["StartedAt"],
                "restart_count": second["RestartCount"], "cleanup_stop": stop}
    finally:
        clean_compose(case, project, name)


perform("p4_explicit_stop", restart_explicit)
perform("p4_nonzero_restart", restart_nonzero)
print(str(RUN))
