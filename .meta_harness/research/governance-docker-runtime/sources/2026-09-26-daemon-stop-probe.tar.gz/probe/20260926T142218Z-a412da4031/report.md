# M0-V2d 隔离 Docker daemon 重启矩阵

本次在**唯一一次**具名 Docker-in-Docker（DinD）实例的 stop/start 上，R3/R4/R5 四格均得到预设观察。测试只说明当前 Docker Engine restart manager 对 BusyBox 夹具的有限行为，未运行产品中心、Compose 部署或宿主 systemd；Docker 部署候选仍由主线裁决，不能据此宣称产品验收。

执行工作树 `/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-probe`，分支 `pandazki/agent-work-loop-docker-probe`，HEAD `2cb236db7da15e78bb1e96dd8220ee68b6eceb75`。脚本 `tmp/docker-daemon-stop-probe/probe.py` SHA-256 `47c82e0821c29e452b34f824a6bbbf56d2ca5e1e59e97e1e49ee399d36c7fe62`。先执行 `python3 tmp/docker-daemon-stop-probe/probe.py --self-test`，纯本地自检通过；再执行一次 `python3 tmp/docker-daemon-stop-probe/probe.py`，退出码 0。`self-test.json` 检查了旧反例 `Running=true, Status=restarting, Pid=0` 必须拒绝稳定态，也检查已停容器的退出码/身份/重启计数、START 日志、进程启动 ticks 与各格独立 verdict。

只使用本机已有镜像，没有 pull：DinD `docker:29.1.3-dind` RepoDigest `docker@sha256:173f284a4299164772a90f52b373e73e087583c0963f1334c9995f190ef6f3f5`；BusyBox `busybox:1.37.0` RepoDigest `busybox@sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e`。BusyBox 由宿主 `docker image save` 后流式载入私有 daemon，tar SHA-256 `39986e21f0fa8fface4e8c16b0ecf138573e1f0b2b9efe6cecc99a8c40f86045`；内层镜像的 Linux/arm64 与 RootFS 层核对宿主镜像，ID 表示差异原样记录在 `inputs.json` 与两侧 image inspect。内层 `docker version` 实测 Engine 29.1.3、Linux/arm64。DinD `HostConfig.Binds` 为空，没有挂宿主 Docker socket或用户目录，privileged 仅用于该具名实例，内层夹具 `--network none`。

| 格 | daemon 停止前 | 私有 daemon 一次 stop/start 后 | 本次结果 |
| --- | --- | --- | --- |
| `unless-stopped`，运行中 | `Status=running`、`Pid=823`，`StartedAt=2026-09-26T14:22:35.519938172Z`，`/proc/1/stat` 启动 ticks `24377661` | 有界等待取得稳定 `running`，12 秒后仍稳定；`Pid=661`，`StartedAt=2026-09-26T14:23:18.744007845Z`，启动 ticks `24381985` | **通过**：开始时间与实际进程启动 ticks 均改变，恢复为新进程 |
| `unless-stopped`，显式 stop→exit 0 | Docker stop 命令 0；容器 `ExitCode=0`，12 秒后仍停止，基线 `StartedAt=2026-09-26T14:22:35.684358213Z`、`RestartCount=0` | `Status=exited`、`Pid=0`、`ExitCode=0`；`StartedAt` 与 `RestartCount` 均未变 | **通过**：显式停机未因 daemon 重启恢复 |
| `unless-stopped`，显式 stop→exit 1 | Docker stop 命令 0；容器 `ExitCode=1`，12 秒后仍停止，基线 `StartedAt=2026-09-26T14:22:35.857359922Z`、`RestartCount=0` | `Status=exited`、`Pid=0`、`ExitCode=1`；`StartedAt` 与 `RestartCount` 均未变 | **通过**：有意停止后的非零退出仍未恢复 |
| `on-failure`，重启前运行中 | `Status=running`；`StartedAt=2026-09-26T14:22:36.057416589Z`，日志恰一次 START | `Status=exited`、`Pid=0`、`ExitCode=0`；`StartedAt` 未变；日志增加 `TERM_EXIT0`，没有第二次 START | **通过**：本次 daemon 重启不自动拉起该对照 |

四格均在创建后等待至少 11 秒，再核 `Status=running`、`Running=true`、`Restarting=false`、`Pid>0`，避免把 restart 过渡态当作稳定运行。R3 两个 stop 格又独立观察 12 秒才进入 daemon 重启；每格判据及错误单独存放于 `results.json`，没有用无关计数阻断另一格。外层 DinD 停止、启动命令均退出 0；其 `StartedAt` 从 `2026-09-26T14:22:18.88239997Z` 变为 `2026-09-26T14:23:02.469393629Z`，外层 PID 从 `1224628` 变为 `1227525`。完整命令、退出码、超时标志、stdout/stderr 在 `commands.jsonl`；逐步 Engine inspect 在各 `*.json`；`on-failure-logs-before.txt` 和 `on-failure-logs-after.txt` 保存原始日志。

资源清理 `cleanup.json` 为 `complete=true`：自建内层容器逐一清理，外层具名 DinD 执行 `docker rm -f -v` 返回 0，随后 inspect 确认容器不存在、匿名卷不存在，具名前缀的容器列表为空。没有停止、重启或修改用户实际 Docker daemon，也没有触及其他实例、网络、卷或镜像。官方 [Docker restart policy 文档](https://docs.docker.com/engine/containers/start-containers-automatically/)给出这些策略的预期区别；本报告的结论限于上述一次实际组合。此前 M0-V2c 的 R2 `die exitCode=23`/`start` 事件事实保留在旧证据目录，本轮没有复跑 R2，也不把旧整轮的测量失败改标通过。
