#!/usr/bin/env python3
"""One private-daemon restart matrix for Docker restart policies (R3/R4/R5)."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import secrets
import subprocess
import sys
import tarfile
import time


WORKTREE = Path("/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-probe")
ROOT = Path(__file__).resolve().parent
EXPECTED_HEAD = "2cb236db7da15e78bb1e96dd8220ee68b6eceb75"
EXPECTED_BRANCH = "pandazki/agent-work-loop-docker-probe"
DIND_IMAGE = "docker:29.1.3-dind"
DIND_DIGEST = "docker@sha256:173f284a4299164772a90f52b373e73e087583c0963f1334c9995f190ef6f3f5"
WORK_IMAGE = "busybox:1.37.0"
WORK_DIGEST = "busybox@sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e"
EXIT_ZERO = "trap 'echo TERM_EXIT0; exit 0' TERM; echo START; while :; do sleep 1; done"
EXIT_ONE = "trap 'echo TERM_EXIT1; exit 1' TERM; echo START; while :; do sleep 1; done"
CELL_KEYS = ("running", "stop_zero", "stop_one", "on_failure")


class ProbeError(Exception):
    pass


def decode_output(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def command_succeeded(result):
    return not result["timed_out"] and result["returncode"] == 0


def require_success(result):
    if not command_succeeded(result):
        raise ProbeError("command failed: " + result["label"])
    return result["stdout"]


def stable_running(state):
    status = state["State"]
    return (status["Status"] == "running" and status["Running"] is True
            and status["Restarting"] is False and status["Pid"] > 0)


def stopped_state(state):
    status = state["State"]
    return (status["Status"] == "exited" and status["Running"] is False
            and status["Restarting"] is False and status["Pid"] == 0)


def unchanged_stopped(state, baseline, exit_code):
    return (stopped_state(state) and state["State"]["ExitCode"] == exit_code
            and state["State"]["StartedAt"] == baseline["started_at"]
            and state["RestartCount"] == baseline["restart_count"])


def start_log_count(logs):
    return sum(line.strip().endswith(" START") for line in logs.splitlines())


def process_start_ticks(stat_line):
    # /proc/<pid>/stat field 22 is index 19 after the closing comm parenthesis.
    fields = stat_line.rsplit(") ", 1)[1].split()
    return int(fields[19])


def cell_verdict(checks, missing=False):
    if missing:
        return "unverified"
    return "pass" if checks and all(checks.values()) else "fail"


def self_test():
    running = {"State": {"Status": "running", "Running": True,
                          "Restarting": False, "Pid": 42}}
    transition = {"State": {"Status": "restarting", "Running": True,
                             "Restarting": True, "Pid": 0}}
    transition_without_flag = {"State": {"Status": "restarting", "Running": True,
                                          "Restarting": False, "Pid": 0}}
    running_without_pid = {"State": {"Status": "running", "Running": True,
                                     "Restarting": False, "Pid": 0}}
    stopped = {"State": {"Status": "exited", "Running": False,
                          "Restarting": False, "Pid": 0, "ExitCode": 1,
                          "StartedAt": "first"}, "RestartCount": 0}
    assert stable_running(running)
    assert not stable_running(transition)
    assert not stable_running(transition_without_flag)
    assert not stable_running(running_without_pid)
    assert stopped_state(stopped) and not stopped_state(transition)
    baseline = {"started_at": "first", "restart_count": 0}
    assert unchanged_stopped(stopped, baseline, 1)
    assert not unchanged_stopped(stopped, baseline, 0)
    assert not unchanged_stopped({**stopped, "RestartCount": 1}, baseline, 1)
    assert not unchanged_stopped({**stopped, "State": {**stopped["State"],
                                  "StartedAt": "second"}}, baseline, 1)
    assert start_log_count("t1 START\nt2 TERM_EXIT0\n") == 1
    assert start_log_count("t1 START\nt2 START\n") == 2
    assert process_start_ticks("1 (sh with spaces) S " + " ".join(str(i) for i in range(4, 25))) == 22
    assert decode_output(b"ok\n") == "ok\n"
    assert not command_succeeded({"returncode": None, "timed_out": True})
    assert cell_verdict({"a": True}) == "pass"
    assert cell_verdict({"a": False}) == "fail"
    assert cell_verdict({}, missing=True) == "unverified"
    return {"result": "pass", "checks": ["restarting transition rejected",
        "stopped state and unchanged identity", "start log count", "process start ticks",
        "timeout rejection", "independent cell verdicts"]}


class Probe:
    def __init__(self):
        self.run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(5)
        self.run_dir = ROOT / self.run_id
        self.run_dir.mkdir(mode=0o700)
        suffix = self.run_id.lower().replace("t", "-").replace("z", "")
        self.prefix = "omne-m0-daemon-stop-" + suffix
        self.outer = self.prefix + "-dind"
        self.names = {key: self.prefix + "-" + key.replace("_", "-") for key in CELL_KEYS}
        self.mounted_volumes = []
        self.result = {"run_id": self.run_id, "status": "preparing",
                       "cells": {key: {"checks": {}, "errors": []} for key in CELL_KEYS}}

    def write_json(self, name, value):
        (self.run_dir / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")

    def record(self):
        self.write_json("results.json", self.result)

    def command(self, label, args, timeout=60, stdin_path=None):
        timestamp = datetime.now(timezone.utc).isoformat()
        started = time.monotonic()
        source = stdin_path.open("rb") if stdin_path else None
        try:
            try:
                proc = subprocess.run(args, stdin=source, capture_output=True,
                                      cwd=WORKTREE, timeout=timeout)
                result = {"label": label, "args": args, "host_utc": timestamp,
                          "elapsed_s": time.monotonic()-started, "timeout_s": timeout,
                          "returncode": proc.returncode, "timed_out": False,
                          "stdout": decode_output(proc.stdout), "stderr": decode_output(proc.stderr)}
            except subprocess.TimeoutExpired as exc:
                result = {"label": label, "args": args, "host_utc": timestamp,
                          "elapsed_s": time.monotonic()-started, "timeout_s": timeout,
                          "returncode": None, "timed_out": True,
                          "stdout": decode_output(exc.stdout), "stderr": decode_output(exc.stderr)}
        finally:
            if source:
                source.close()
        with (self.run_dir / "commands.jsonl").open("a") as log:
            log.write(json.dumps(result, ensure_ascii=False) + "\n")
        return result

    def inner(self, label, args, timeout=60, stdin_path=None):
        return self.command(label, ["docker", "exec"] + (["-i"] if stdin_path else []) +
            [self.outer, "docker", "--host", "unix:///var/run/docker.sock"] + args,
            timeout, stdin_path)

    def outer_inspect(self, label, required=True):
        result = self.command(label, ["docker", "inspect", self.outer])
        if not command_succeeded(result):
            if required:
                raise ProbeError(label + ": outer inspect failed")
            return None
        state = json.loads(result["stdout"])[0]
        self.write_json(label + ".json", state)
        return state

    def inner_inspect(self, key, label, required=True, save=True):
        result = self.inner(label, ["inspect", self.names[key]])
        if not command_succeeded(result):
            if required:
                raise ProbeError(label + ": inner inspect failed")
            return None
        state = json.loads(result["stdout"])[0]
        if save:
            self.write_json(label + ".json", state)
        return state

    def wait_ready(self, seconds=45):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            result = self.inner("dind-ready", ["info", "--format", "{{.ServerVersion}}"], 10)
            if command_succeeded(result):
                return
            time.sleep(1)
        raise ProbeError("private daemon did not become ready")

    def wait_stable(self, key, seconds=25):
        deadline = time.monotonic() + seconds
        last = None
        while time.monotonic() < deadline:
            last = self.inner_inspect(key, "poll-" + key, required=False, save=False)
            if last is not None and stable_running(last):
                return last
            time.sleep(0.5)
        return last

    def cell_check(self, key, name, condition):
        self.result["cells"][key]["checks"][name] = bool(condition)
        self.record()

    def cell_error(self, key, message):
        self.result["cells"][key]["errors"].append(message)
        self.record()

    def preflight(self):
        if ROOT != WORKTREE / "tmp/docker-daemon-stop-probe":
            raise ProbeError("script is outside the assigned worktree path")
        head = require_success(self.command("git-head", ["git", "rev-parse", "HEAD"])).strip()
        branch = require_success(self.command("git-branch", ["git", "branch", "--show-current"])).strip()
        if head != EXPECTED_HEAD or branch != EXPECTED_BRANCH:
            raise ProbeError("worktree branch or baseline changed")
        self.result["git"] = {"head": head, "branch": branch}
        self.result["host_version_before"] = self.command("host-version-before",
            ["docker", "version", "--format", "{{json .}}"])
        require_success(self.result["host_version_before"])
        images = {}
        for key, image, digest in (("dind", DIND_IMAGE, DIND_DIGEST),
                                   ("workload", WORK_IMAGE, WORK_DIGEST)):
            item = json.loads(require_success(self.command("host-image-" + key,
                ["docker", "image", "inspect", image])))[0]
            self.write_json("host-image-" + key + ".json", item)
            if digest not in item["RepoDigests"] or item["Os"] != "linux" or item["Architecture"] != "arm64":
                raise ProbeError("cached image digest or platform differs: " + key)
            images[key] = item
        archive = self.run_dir / "busybox-image.tar"
        require_success(self.command("save-workload", ["docker", "image", "save", "-o",
            str(archive), WORK_IMAGE], 90))
        archive_hash = hashlib.sha256(archive.read_bytes()).hexdigest()
        with tarfile.open(archive) as tar:
            manifest = json.load(tar.extractfile("manifest.json"))
            config = tar.extractfile(manifest[0]["Config"]).read()
        if "sha256:" + hashlib.sha256(config).hexdigest() != images["workload"]["Id"]:
            raise ProbeError("saved workload archive config differs from cached image")
        self.result["inputs"] = {"dind_repo_digests": images["dind"]["RepoDigests"],
            "dind_image_id": images["dind"]["Id"], "busybox_repo_digests": images["workload"]["RepoDigests"],
            "busybox_image_id": images["workload"]["Id"], "archive_sha256": archive_hash,
            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "exit_zero_sha256": hashlib.sha256(EXIT_ZERO.encode()).hexdigest(),
            "exit_one_sha256": hashlib.sha256(EXIT_ONE.encode()).hexdigest()}
        self.write_json("inputs.json", self.result["inputs"])
        self.record()
        return images, archive

    def start_dind(self, images, archive):
        absence = self.command("unique-name-absent", ["docker", "inspect", self.outer])
        if absence["timed_out"] or absence["returncode"] == 0:
            raise ProbeError("private dind name is not demonstrably absent")
        require_success(self.command("create-private-dind", ["docker", "run", "-d", "--privileged",
            "--name", self.outer, "--label", "omne.m0.daemon-stop=" + self.run_id,
            "-e", "DOCKER_TLS_CERTDIR=", "--network", "bridge", DIND_IMAGE,
            "--host=unix:///var/run/docker.sock", "--iptables=false", "--bridge=none"], 90))
        outer = self.outer_inspect("outer-created")
        self.mounted_volumes = [m["Name"] for m in outer["Mounts"] if m["Type"] == "volume"]
        if outer["HostConfig"]["Binds"] or not outer["HostConfig"]["Privileged"]:
            raise ProbeError("private dind resource boundary differs from plan")
        self.wait_ready()
        version_result = self.inner("inner-version-before", ["version", "--format", "{{json .}}"])
        version = json.loads(require_success(version_result))
        self.result["inner_version_before"] = version
        if (version["Server"]["Version"] != "29.1.3" or version["Server"]["Os"] != "linux"
                or version["Server"]["Arch"] != "arm64"):
            raise ProbeError("inner Engine version or platform differs")
        require_success(self.inner("load-workload", ["load"], 90, archive))
        loaded = json.loads(require_success(self.inner("inner-image-workload",
            ["image", "inspect", WORK_IMAGE])))[0]
        self.write_json("inner-image-workload.json", loaded)
        if (loaded["RootFS"]["Layers"] != images["workload"]["RootFS"]["Layers"]
                or loaded["Os"] != images["workload"]["Os"]
                or loaded["Architecture"] != images["workload"]["Architecture"]):
            raise ProbeError("inner workload content or platform differs")
        self.result["inputs"]["inner_busybox_image_id"] = loaded["Id"]
        self.write_json("inputs.json", self.result["inputs"])
        self.record()

    def launch_cells(self):
        definitions = {"running": ("unless-stopped", EXIT_ZERO),
                       "stop_zero": ("unless-stopped", EXIT_ZERO),
                       "stop_one": ("unless-stopped", EXIT_ONE),
                       "on_failure": ("on-failure", EXIT_ZERO)}
        for key, (policy, script) in definitions.items():
            result = self.inner("run-" + key, ["run", "-d", "--pull", "never",
                "--name", self.names[key], "--network", "none", "--restart", policy,
                WORK_IMAGE, "sh", "-c", script])
            if not command_succeeded(result):
                self.cell_error(key, "container creation failed")
                continue
            state = self.inner_inspect(key, key + "-created", required=False)
            if state is None:
                self.cell_error(key, "container could not be inspected after creation")
                continue
            self.cell_check(key, "restart-policy", state["HostConfig"]["RestartPolicy"]["Name"] == policy)
        # Docker documents that a policy starts monitoring only after 10 seconds.
        time.sleep(11)
        for key in CELL_KEYS:
            if self.result["cells"][key]["errors"]:
                continue
            stable = self.wait_stable(key)
            if stable is None:
                self.cell_error(key, "container unavailable before daemon restart")
                continue
            self.write_json(key + "-stable-before-actions.json", stable)
            self.cell_check(key, "stable-before-actions", stable_running(stable))
            self.result["cells"][key]["baseline"] = {
                "started_at": stable["State"]["StartedAt"], "pid": stable["State"]["Pid"],
                "restart_count": stable["RestartCount"]}
            if key in ("running", "on_failure") and stable_running(stable):
                token = self.process_token(key, "process-token-before-" + key)
                if token is not None:
                    self.result["cells"][key]["baseline"]["process_start_ticks"] = token
                else:
                    self.cell_error(key, "process start ticks unavailable before daemon restart")
            self.record()

    def process_token(self, key, label):
        result = self.inner(label, ["exec", self.names[key], "cat", "/proc/1/stat"])
        if not command_succeeded(result):
            return None
        try:
            return process_start_ticks(result["stdout"].strip())
        except (IndexError, ValueError):
            return None

    def observe_manual_stops(self):
        for key, expected_code in (("stop_zero", 0), ("stop_one", 1)):
            cell = self.result["cells"][key]
            if not cell["checks"].get("stable-before-actions"):
                self.cell_error(key, "stop prerequisite was not stable")
                continue
            stopped = self.inner("explicit-stop-" + key,
                ["stop", "--timeout", "3", self.names[key]])
            self.cell_check(key, "stop-command-returned", command_succeeded(stopped))
            state = self.inner_inspect(key, key + "-immediately-stopped", required=False)
            if state is None:
                self.cell_error(key, "post-stop inspect unavailable")
                continue
            self.cell_check(key, "explicit-exit-code", state["State"]["ExitCode"] == expected_code)
            self.cell_check(key, "immediately-stopped", stopped_state(state))
        time.sleep(12)
        for key in ("stop_zero", "stop_one"):
            state = self.inner_inspect(key, key + "-after-12s-stop", required=False)
            if state is None:
                self.cell_error(key, "12-second stopped state unavailable")
                continue
            self.cell_check(key, "stopped-after-12s", stopped_state(state))
        for key in ("running", "on_failure"):
            state = self.inner_inspect(key, key + "-before-daemon-stop", required=False)
            if state is None:
                self.cell_error(key, "running control unavailable before daemon stop")
                continue
            self.cell_check(key, "stable-before-daemon-stop", stable_running(state))
        logs_before = self.inner("on-failure-logs-before-daemon-stop",
            ["logs", "--timestamps", self.names["on_failure"]])
        if command_succeeded(logs_before):
            (self.run_dir / "on-failure-logs-before.txt").write_text(logs_before["stdout"])
            self.result["cells"]["on_failure"]["baseline_start_log_count"] = start_log_count(logs_before["stdout"])
            self.cell_check("on_failure", "one-start-log-before-daemon-stop",
                            start_log_count(logs_before["stdout"]) == 1)
        else:
            self.cell_error("on_failure", "pre-restart logs unavailable")
        self.record()

    def restart_private_daemon(self):
        before = self.outer_inspect("outer-before-stop")
        stop_result = self.command("stop-private-dind", ["docker", "stop", "--timeout", "45", self.outer], 65)
        require_success(stop_result)
        stopped = self.outer_inspect("outer-stopped")
        if stopped["State"]["Running"] or stopped["State"]["ExitCode"] != 0:
            raise ProbeError("private dind did not stop cleanly")
        require_success(self.command("start-private-dind", ["docker", "start", self.outer], 65))
        self.wait_ready()
        after = self.outer_inspect("outer-restarted")
        if (not after["State"]["Running"] or
                after["State"]["StartedAt"] == before["State"]["StartedAt"]):
            raise ProbeError("private daemon restart not observable")
        version_result = self.inner("inner-version-after", ["version", "--format", "{{json .}}"])
        self.result["inner_version_after"] = json.loads(require_success(version_result))
        self.result["private_daemon_restart"] = {
            "outer_started_before": before["State"]["StartedAt"],
            "outer_started_after": after["State"]["StartedAt"],
            "outer_pid_before": before["State"]["Pid"],
            "outer_pid_after": after["State"]["Pid"]}
        self.record()

    def observe_after_restart(self):
        # Readiness of the running cell is separate from the three stopped cells.
        candidate = self.wait_stable("running", 30)
        if candidate is not None:
            self.write_json("running-after-restart-stability-wait.json", candidate)
        self.cell_check("running", "reached-stable-after-daemon-restart",
                        candidate is not None and stable_running(candidate))
        time.sleep(12)
        for key in CELL_KEYS:
            cell = self.result["cells"][key]
            state = self.inner_inspect(key, key + "-after-daemon-restart", required=False)
            if state is None:
                self.cell_error(key, "post-restart inspect unavailable")
                continue
            cell["after"] = {"status": state["State"]["Status"],
                "running": state["State"]["Running"],
                "restarting": state["State"]["Restarting"],
                "pid": state["State"]["Pid"],
                "started_at": state["State"]["StartedAt"],
                "exit_code": state["State"]["ExitCode"],
                "restart_count": state["RestartCount"]}
            if key == "running":
                self.cell_check(key, "stable-after-daemon-restart", stable_running(state))
                baseline = cell.get("baseline", {})
                self.cell_check(key, "new-started-at", state["State"]["StartedAt"] != baseline.get("started_at"))
                token = self.process_token(key, "process-token-after-" + key) if stable_running(state) else None
                cell["after"]["process_start_ticks"] = token
                self.cell_check(key, "new-process-start-ticks", token is not None
                                and token != baseline.get("process_start_ticks"))
            elif key in ("stop_zero", "stop_one"):
                baseline = cell.get("baseline")
                expected_code = 0 if key == "stop_zero" else 1
                self.cell_check(key, "unchanged-stopped-after-daemon-restart",
                                baseline is not None and unchanged_stopped(state, baseline, expected_code))
            else:
                self.cell_check(key, "stopped-after-daemon-restart", stopped_state(state))
                baseline = cell.get("baseline", {})
                self.cell_check(key, "unchanged-started-at",
                                state["State"]["StartedAt"] == baseline.get("started_at"))
                logs_after = self.inner("on-failure-logs-after-daemon-restart",
                    ["logs", "--timestamps", self.names["on_failure"]])
                if command_succeeded(logs_after):
                    (self.run_dir / "on-failure-logs-after.txt").write_text(logs_after["stdout"])
                    self.cell_check(key, "no-new-start-log", start_log_count(logs_after["stdout"])
                                    == cell.get("baseline_start_log_count") == 1)
                else:
                    self.cell_error(key, "post-restart logs unavailable")
            self.record()
        ps = self.inner("inner-ps-after-restart", ["ps", "-a", "--format", "{{json .}}"])
        self.result["inner_ps_after_restart"] = ps
        self.record()

    def finish_cells(self):
        for key, cell in self.result["cells"].items():
            expected = {"running": ("stable-before-actions", "stable-before-daemon-stop",
                                    "reached-stable-after-daemon-restart", "stable-after-daemon-restart",
                                    "new-started-at", "new-process-start-ticks"),
                        "stop_zero": ("stable-before-actions", "stop-command-returned", "explicit-exit-code",
                                      "immediately-stopped", "stopped-after-12s",
                                      "unchanged-stopped-after-daemon-restart"),
                        "stop_one": ("stable-before-actions", "stop-command-returned", "explicit-exit-code",
                                     "immediately-stopped", "stopped-after-12s",
                                     "unchanged-stopped-after-daemon-restart"),
                        "on_failure": ("stable-before-actions", "stable-before-daemon-stop",
                                       "one-start-log-before-daemon-stop", "stopped-after-daemon-restart",
                                       "unchanged-started-at", "no-new-start-log")}[key]
            missing = any(name not in cell["checks"] for name in expected)
            cell["verdict"] = cell_verdict(cell["checks"], missing or bool(cell["errors"]))
        self.record()

    def cleanup(self):
        audit = {"inner_removals": {}, "volumes": []}
        outer = self.outer_inspect("outer-before-cleanup", required=False)
        if outer and outer.get("Config", {}).get("Labels", {}).get("omne.m0.daemon-stop") == self.run_id:
            self.mounted_volumes = [m["Name"] for m in outer["Mounts"] if m["Type"] == "volume"]
            if outer["State"]["Running"]:
                try:
                    self.wait_ready(5)
                    for key, name in self.names.items():
                        audit["inner_removals"][key] = self.inner("cleanup-" + key,
                            ["rm", "-f", name], 20)
                except ProbeError as exc:
                    audit["inner_error"] = str(exc)
            audit["outer_remove"] = self.command("cleanup-own-dind", ["docker", "rm", "-f", "-v", self.outer], 65)
        elif outer:
            audit["ownership_mismatch"] = True
        absent = self.command("cleanup-check-outer", ["docker", "inspect", self.outer])
        audit["outer_absent"] = not absent["timed_out"] and absent["returncode"] != 0
        for volume in self.mounted_volumes:
            checked = self.command("cleanup-check-volume-" + volume[:12],
                ["docker", "volume", "inspect", volume])
            audit["volumes"].append({"name": volume,
                "absent": not checked["timed_out"] and checked["returncode"] != 0})
        remaining = self.command("cleanup-prefix-containers", ["docker", "ps", "-a",
            "--filter", "name=" + self.prefix, "--format", "{{json .}}"])
        audit["prefix_containers"] = remaining
        audit["complete"] = (audit["outer_absent"] and all(x["absent"] for x in audit["volumes"])
                             and command_succeeded(remaining) and not remaining["stdout"].strip()
                             and not audit.get("ownership_mismatch"))
        self.result["cleanup"] = audit
        self.result["host_version_after"] = self.command("host-version-after",
            ["docker", "version", "--format", "{{json .}}"])
        self.write_json("cleanup.json", audit)
        self.record()

    def execute(self):
        try:
            images, archive = self.preflight()
            self.start_dind(images, archive)
            self.launch_cells()
            self.observe_manual_stops()
            self.restart_private_daemon()
            self.observe_after_restart()
            self.finish_cells()
            self.result["status"] = "observed"
        except Exception as exc:
            self.result["status"] = "incomplete"
            self.result["error"] = repr(exc)
        finally:
            self.cleanup()
        if not self.result["cleanup"]["complete"]:
            self.result["status"] = "cleanup-incomplete"
            self.record()
        return self.result


if __name__ == "__main__":
    if sys.argv[1:] == ["--self-test"]:
        result = self_test()
        (ROOT / "self-test.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result))
    elif not sys.argv[1:]:
        probe = Probe()
        result = probe.execute()
        print(probe.run_dir)
        sys.exit(0 if result["status"] == "observed" and
                 all(cell.get("verdict") == "pass" for cell in result["cells"].values()) else 1)
    else:
        print("usage: probe.py [--self-test]", file=sys.stderr)
        sys.exit(64)
