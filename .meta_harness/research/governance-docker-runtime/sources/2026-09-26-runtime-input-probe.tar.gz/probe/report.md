# M0-V3 Compose 运行输入机制探针

本次在 Docker Desktop 4.55.0、Engine 29.1.3（Linux/arm64）、Compose v2.40.3-desktop.1 上，三格实际容器观察均通过：`env_file: {path, format: raw}` 将 `$` 与引号原样送入容器，显式 `environment` 覆盖同名项；UID 10001 与 10002 各自的 tmpfs 目录具有指定 owner/mode、可写且实挂 `nosuid,nodev,noexec`；不含 `serve.env` 的独立 maintenance Compose 文件能单独 config/run，所属项目仅有 maintenance 容器。这只是缓存 BusyBox 夹具的机制实验，未运行产品中心或备份命令，不能代替 Docker 部署设计采用和产品验收。

执行工作树 `/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-probe`，分支 `pandazki/agent-work-loop-docker-probe`，HEAD `2cb236db7da15e78bb1e96dd8220ee68b6eceb75`，tracked 状态干净。无 pull；镜像 `busybox:1.37.0` RepoDigest `busybox@sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e`、本机 Linux/arm64 image ID `sha256:ad4f11f7c85f87c0a6d6c0fe492ad53f9cdcff6e8c88b881360c70eff701c67b`。最终脚本 `probe.py` SHA-256 `5373426778dd021a0a870f1802a0129097953f60e587b18e698bd872d3df0f4a`。先执行 `python3 tmp/docker-runtime-input-probe/probe.py --self-test`，纯输入/解析自检通过；然后运行脚本，成功轮退出 0，证据目录 `20260926T143609Z-b73e06a0e9/`。所有原始 Compose YAML 与 dummy `serve.env` 按格保留，文件哈希在该轮 `results.json#input_hashes`；各命令、退出码、stdout/stderr 在 `commands.jsonl`；解析前的 `config.json`、完整 Engine `inspect.json`、`proc-mounts.txt` 和维护项目 `project-ps.jsonl` 均保留。

第一次尝试 `20260926T143419Z-1dffe861ca/` **在任何容器创建前失败并保留原始结果**：测量器把 Compose `config --format json` 中的 `$` 转义表示 `$$` 误当成运行时值变化，因 `uid10001: Compose config did not preserve raw env/override` 停止；该轮 `cleanup=true`。实际 config 原文中 `RAW_DOLLAR="$$OMNE_PROBE_UNSET"`、`RAW_BRACES="$${OMNE_PROBE_UNSET}"`，覆盖值和带引号值正常。修正仅区分当前版本的 config 序列化投影与实际容器值：config 层严格检查双 `$`，Engine `Config.Env` 和容器进程仍严格检查原始单 `$`。成功轮由**原始** `compose.yaml`/`serve.env` 启动，未把 config 输出作为二次配置输入；三格各只创建一次。

| 格 | 可观察判据与结果 |
| --- | --- |
| raw env 与覆盖（两格） | `serve.env` 原文含 `RAW_DOLLAR=$OMNE_PROBE_UNSET`、`RAW_BRACES=${OMNE_PROBE_UNSET}`、`RAW_QUOTES="double ' single"`、`OVERRIDE_ME=raw_$OMNE_PROBE_UNSET`。两格 Engine `Config.Env` 及进程内逐项读取均为原始单 `$`/原始引号；同名 `OVERRIDE_ME=from_environment`。 |
| UID 10001 tmpfs | Engine `Config.User=10001:10001`；进程 `id -u/-g` 均 10001。首条业务夹具命令即可向 `/run/omne-tenancy/startup` 写入；`stat -c %u:%g:%a` 为 `10001:10001:700`，同 UID 再写成功，UID 10002 跨用户写入退出 1。`HostConfig.Tmpfs` 含 `mode=0700,uid=10001,gid=10001,nosuid,nodev,noexec`；容器 `/proc/mounts` 的实际 tmpfs flags 也含这三项。 |
| UID 10002 tmpfs | 同形，`Config.User=10002:10002`、进程 UID/GID 10002、`stat=10002:10002:700`、同 UID 写成功、UID 10001 跨用户写入退出 1；实际挂载 flags 含 `nosuid,nodev,noexec`。 |
| 独立 maintenance | `maintenance/` 下不存在 `serve.env`；该目录的独立 `compose.yaml` 原文和解析后的 service 均不含 `env_file`、`secrets`、`ports`，config 返回 0，up 返回 0。所属 Compose 项目只观察到一个 `maintenance` 容器，没有创建 center 服务。 |

成功轮三个 `up` 各出现一次，无重建/重试。`cleanup.json` 为 `complete=true`：只对本轮三个唯一 Compose 项目执行 `down`，其标签下剩余容器为零，三个项目标签下剩余网络为零；未改变宿主 Docker daemon、其他容器、网络、卷或镜像。中心夹具使用 `network_mode: none`，没有任何发布端口。官方 [Compose services 文档](https://docs.docker.com/reference/compose-file/services/)说明 raw env、`environment` 优先级与 tmpfs 格式；[Docker tmpfs 文档](https://docs.docker.com/engine/storage/tmpfs/)说明挂载选项。本次测试只给上述精确版本和短时运行的可观察结果，不证明任意镜像、版本、宿主或实际产品资源生命周期成立。
