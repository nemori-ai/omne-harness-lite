#!/usr/bin/env python3
"""Bounded Compose raw-env, tmpfs, and independent-maintenance probe."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import secrets
import subprocess
import sys
import time


WORKTREE = Path("/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-probe")
ROOT = Path(__file__).resolve().parent
EXPECTED_HEAD = "2cb236db7da15e78bb1e96dd8220ee68b6eceb75"
EXPECTED_BRANCH = "pandazki/agent-work-loop-docker-probe"
IMAGE = "busybox:1.37.0"
DIGEST = "busybox@sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e"
RAW_ENV = ("RAW_DOLLAR=$OMNE_PROBE_UNSET\n"
           "RAW_BRACES=${OMNE_PROBE_UNSET}\n"
           "RAW_QUOTES=\"double ' single\"\n"
           "OVERRIDE_ME=raw_$OMNE_PROBE_UNSET\n")
EXPECTED_ENV = {"RAW_DOLLAR": "$OMNE_PROBE_UNSET",
                "RAW_BRACES": "${OMNE_PROBE_UNSET}",
                "RAW_QUOTES": "\"double ' single\"",
                "OVERRIDE_ME": "from_environment"}
EXPECTED_CONFIG_ENV = {name: value.replace("$", "$$") for name, value in EXPECTED_ENV.items()}
TMPFS_PATH = "/run/omne-tenancy"
REQUIRED_FLAGS = {"nosuid", "nodev", "noexec"}


class ProbeFailure(Exception):
    pass


def decode_output(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def successful(result):
    return result["returncode"] == 0 and not result["timed_out"]


def require(result):
    if not successful(result):
        raise ProbeFailure("command failed: " + result["label"])
    return result["stdout"]


def env_map(items):
    return {key: value for key, value in (item.split("=", 1) for item in items if "=" in item)}


def mount_flags(mounts):
    for line in mounts.splitlines():
        parts = line.split()
        if len(parts) >= 4 and parts[1] == TMPFS_PATH:
            return {"device": parts[0], "type": parts[2], "flags": set(parts[3].split(","))}
    return None


def center_yaml(uid, run_id):
    return ("services:\n"
            "  center:\n"
            "    image: busybox:1.37.0\n"
            "    pull_policy: never\n"
            "    network_mode: none\n"
            "    user: \"" + str(uid) + ":" + str(uid) + "\"\n"
            "    env_file:\n"
            "      - path: ./serve.env\n"
            "        format: raw\n"
            "    environment:\n"
            "      OVERRIDE_ME: from_environment\n"
            "    tmpfs:\n"
            "      - \"/run/omne-tenancy:mode=0700,uid=" + str(uid) + ",gid=" + str(uid) + ",nosuid,nodev,noexec\"\n"
            "    labels:\n"
            "      omne.m0.runtime-input-probe: \"" + run_id + "\"\n"
            "    command: [\"sh\", \"-c\", \"printf startup > /run/omne-tenancy/startup && exec sleep 600\"]\n")


def maintenance_yaml(run_id):
    return ("services:\n"
            "  maintenance:\n"
            "    image: busybox:1.37.0\n"
            "    pull_policy: never\n"
            "    network_mode: none\n"
            "    labels:\n"
            "      omne.m0.runtime-input-probe: \"" + run_id + "\"\n"
            "    command: [\"sh\", \"-c\", \"exec sleep 600\"]\n")


def self_test():
    assert env_map(["A=$X", "B=\"q\"", "C=x=y"])["C"] == "x=y"
    assert env_map(["A=$X"])["A"] == "$X"
    assert EXPECTED_CONFIG_ENV["RAW_DOLLAR"] == "$$OMNE_PROBE_UNSET"
    assert EXPECTED_CONFIG_ENV["RAW_BRACES"] == "$${OMNE_PROBE_UNSET}"
    assert EXPECTED_CONFIG_ENV["RAW_QUOTES"] == EXPECTED_ENV["RAW_QUOTES"]
    mounts = "tmpfs /run/omne-tenancy tmpfs rw,nosuid,nodev,noexec,relatime 0 0\n"
    parsed = mount_flags(mounts)
    assert parsed["type"] == "tmpfs" and REQUIRED_FLAGS <= parsed["flags"]
    assert not REQUIRED_FLAGS <= mount_flags("tmpfs /run/omne-tenancy tmpfs rw,nosuid,nodev 0 0\n")["flags"]
    assert "format: raw" in center_yaml(10001, "dummy")
    assert "uid=10002,gid=10002" in center_yaml(10002, "dummy")
    assert all(term not in maintenance_yaml("dummy") for term in ("env_file", "secrets", "ports", "center"))
    assert not successful({"returncode": None, "timed_out": True})
    return {"result": "pass", "checks": ["raw fixture", "config dollar serialization",
                                         "env split", "mount flag parser",
                                         "two UIDs", "maintenance isolation", "timeout gate"]}


class Probe:
    def __init__(self):
        self.run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(5)
        self.run_dir = ROOT / self.run_id
        self.run_dir.mkdir(mode=0o700)
        suffix = self.run_id.lower().replace("t", "").replace("z", "").replace("-", "")
        self.projects = {key: "omnem0runtimeinput" + suffix + key.replace("_", "")
                         for key in ("uid10001", "uid10002", "maintenance")}
        self.started = set()
        self.result = {"run_id": self.run_id, "status": "preparing", "cases": {}, "projects": self.projects}

    def write_json(self, name, value):
        (self.run_dir / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")

    def record(self):
        self.write_json("results.json", self.result)

    def command(self, label, args, cwd=None, timeout=45):
        started = time.monotonic()
        timestamp = datetime.now(timezone.utc).isoformat()
        try:
            completed = subprocess.run(args, cwd=cwd or WORKTREE, capture_output=True, timeout=timeout)
            result = {"label": label, "args": args, "cwd": str(cwd or WORKTREE),
                      "at_utc": timestamp, "elapsed_s": time.monotonic()-started,
                      "timeout_s": timeout, "returncode": completed.returncode,
                      "timed_out": False, "stdout": decode_output(completed.stdout),
                      "stderr": decode_output(completed.stderr)}
        except subprocess.TimeoutExpired as exc:
            result = {"label": label, "args": args, "cwd": str(cwd or WORKTREE),
                      "at_utc": timestamp, "elapsed_s": time.monotonic()-started,
                      "timeout_s": timeout, "returncode": None,
                      "timed_out": True, "stdout": decode_output(exc.stdout),
                      "stderr": decode_output(exc.stderr)}
        with (self.run_dir / "commands.jsonl").open("a") as out:
            out.write(json.dumps(result, ensure_ascii=False) + "\n")
        return result

    def compose(self, key, label, args, timeout=45):
        case_dir = self.run_dir / key
        return self.command(label, ["docker", "compose", "-p", self.projects[key],
            "-f", str(case_dir / "compose.yaml")] + args, case_dir, timeout)

    def input_files(self):
        for key, uid in (("uid10001", 10001), ("uid10002", 10002)):
            case_dir = self.run_dir / key
            case_dir.mkdir(mode=0o700)
            (case_dir / "compose.yaml").write_text(center_yaml(uid, self.run_id))
            (case_dir / "serve.env").write_text(RAW_ENV)
        maintenance = self.run_dir / "maintenance"
        maintenance.mkdir(mode=0o700)
        (maintenance / "compose.yaml").write_text(maintenance_yaml(self.run_id))
        if (maintenance / "serve.env").exists():
            raise ProbeFailure("maintenance directory unexpectedly contains serve.env")
        self.result["input_hashes"] = {
            str(path.relative_to(self.run_dir)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in self.run_dir.rglob("*") if path.is_file() and path.name in ("compose.yaml", "serve.env")}
        self.result["script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        self.record()

    def preflight(self):
        if ROOT != WORKTREE / "tmp/docker-runtime-input-probe":
            raise ProbeFailure("script is outside assigned worktree path")
        head = require(self.command("git-head", ["git", "rev-parse", "HEAD"])).strip()
        branch = require(self.command("git-branch", ["git", "branch", "--show-current"])).strip()
        if head != EXPECTED_HEAD or branch != EXPECTED_BRANCH:
            raise ProbeFailure("worktree branch or baseline changed")
        docker_version = json.loads(require(self.command("docker-version",
            ["docker", "version", "--format", "{{json .}}"])))
        compose_version = json.loads(require(self.command("compose-version",
            ["docker", "compose", "version", "--format", "json"])))
        image = json.loads(require(self.command("busybox-image",
            ["docker", "image", "inspect", IMAGE])))[0]
        if (docker_version["Server"]["Version"] != "29.1.3"
                or compose_version["version"] != "v2.40.3-desktop.1"
                or DIGEST not in image["RepoDigests"] or image["Os"] != "linux"
                or image["Architecture"] != "arm64"):
            raise ProbeFailure("tool or cached image version differs")
        self.write_json("image-inspect.json", image)
        self.result["environment"] = {"head": head, "branch": branch,
            "docker_server": docker_version["Server"], "compose": compose_version,
            "image_repo_digests": image["RepoDigests"], "image_id": image["Id"]}
        self.input_files()

    def config_case(self, key):
        output = require(self.compose(key, "config-" + key, ["config", "--format", "json"]))
        (self.run_dir / key / "config.json").write_text(output)
        config = json.loads(output)
        expected_service = "maintenance" if key == "maintenance" else "center"
        if set(config.get("services", {})) != {expected_service}:
            raise ProbeFailure(key + ": config service set differs")
        service = config["services"][expected_service]
        if key == "maintenance":
            if any(field in service for field in ("env_file", "secrets", "ports")):
                raise ProbeFailure("maintenance config acquired forbidden input or port")
        else:
            configured = service.get("environment", {})
            if not all(configured.get(name) == value for name, value in EXPECTED_CONFIG_ENV.items()):
                raise ProbeFailure(key + ": Compose config raw-env projection/override differs")
            uid = int(key.replace("uid", ""))
            if service.get("user") != str(uid) + ":" + str(uid):
                raise ProbeFailure(key + ": configured runtime user differs")
        self.result["cases"][key] = {"config": "pass", "project": self.projects[key]}
        self.record()

    def container_id(self, key, service):
        value = require(self.compose(key, "ps-id-" + key, ["ps", "-q", service])).strip()
        if len(value.splitlines()) != 1:
            raise ProbeFailure(key + ": expected exactly one container ID")
        return value

    def inspect(self, key, container_id):
        state = json.loads(require(self.command("inspect-" + key,
            ["docker", "inspect", container_id])))[0]
        self.write_json(key + "/inspect.json", state)
        if not state["State"]["Running"]:
            raise ProbeFailure(key + ": container did not remain running")
        if state["Config"]["Labels"].get("omne.m0.runtime-input-probe") != self.run_id:
            raise ProbeFailure(key + ": ownership label missing")
        return state

    def center_case(self, key, uid):
        self.started.add(key)
        require(self.compose(key, "up-" + key, ["up", "-d"], 60))
        container_id = self.container_id(key, "center")
        state = self.inspect(key, container_id)
        actual_env = env_map(state["Config"]["Env"])
        if not all(actual_env.get(name) == value for name, value in EXPECTED_ENV.items()):
            raise ProbeFailure(key + ": Engine env differs from raw/override values")
        if state["Config"]["User"] != str(uid) + ":" + str(uid):
            raise ProbeFailure(key + ": Engine user differs")
        runtime_uid = require(self.command("runtime-uid-" + key,
            ["docker", "exec", container_id, "id", "-u"])).strip()
        runtime_gid = require(self.command("runtime-gid-" + key,
            ["docker", "exec", container_id, "id", "-g"])).strip()
        if runtime_uid != str(uid) or runtime_gid != str(uid):
            raise ProbeFailure(key + ": actual process UID/GID differs")
        for name, expected in EXPECTED_ENV.items():
            runtime_value = require(self.command("runtime-env-" + key + "-" + name,
                ["docker", "exec", container_id, "sh", "-c", 'printf "%s" "$' + name + '"']))
            if runtime_value != expected:
                raise ProbeFailure(key + ": process env differs for " + name)
        tmpfs = state["HostConfig"].get("Tmpfs") or {}
        if TMPFS_PATH not in tmpfs:
            raise ProbeFailure(key + ": Engine HostConfig lacks tmpfs")
        marker = require(self.command("startup-marker-" + key,
            ["docker", "exec", container_id, "cat", TMPFS_PATH + "/startup"]))
        if marker != "startup":
            raise ProbeFailure(key + ": startup write did not confirm pre-exec mount")
        stat = require(self.command("stat-" + key,
            ["docker", "exec", container_id, "stat", "-c", "%u:%g:%a", TMPFS_PATH])).strip()
        if stat != str(uid) + ":" + str(uid) + ":700":
            raise ProbeFailure(key + ": actual tmpfs owner/mode differs")
        mounts = require(self.command("proc-mounts-" + key,
            ["docker", "exec", container_id, "cat", "/proc/mounts"]))
        (self.run_dir / key / "proc-mounts.txt").write_text(mounts)
        mount = mount_flags(mounts)
        if mount is None or mount["type"] != "tmpfs" or not REQUIRED_FLAGS <= mount["flags"]:
            raise ProbeFailure(key + ": actual tmpfs flags differ")
        write = self.command("owned-write-" + key,
            ["docker", "exec", container_id, "sh", "-c",
             "test -w /run/omne-tenancy && printf owned > /run/omne-tenancy/owned"])
        require(write)
        if require(self.command("read-owned-" + key,
            ["docker", "exec", container_id, "cat", TMPFS_PATH + "/owned"])) != "owned":
            raise ProbeFailure(key + ": same UID write missing")
        other_uid = 10002 if uid == 10001 else 10001
        cross = self.command("cross-uid-write-" + key,
            ["docker", "exec", "--user", str(other_uid) + ":" + str(other_uid),
             container_id, "sh", "-c", "printf cross > /run/omne-tenancy/cross"])
        if cross["timed_out"] or cross["returncode"] == 0:
            raise ProbeFailure(key + ": other UID wrote to 0700 tmpfs")
        self.result["cases"][key].update({"runtime": "pass", "container_id": container_id,
            "env": {name: actual_env[name] for name in EXPECTED_ENV}, "stat": stat,
            "host_config_tmpfs": tmpfs[TMPFS_PATH], "mount": {"type": mount["type"],
            "flags": sorted(mount["flags"])}, "cross_uid_write_returncode": cross["returncode"]})
        self.record()

    def maintenance_case(self):
        key = "maintenance"
        self.started.add(key)
        require(self.compose(key, "up-maintenance", ["up", "-d"], 60))
        container_id = self.container_id(key, "maintenance")
        state = self.inspect(key, container_id)
        if state["Config"]["Labels"].get("com.docker.compose.service") != "maintenance":
            raise ProbeFailure("maintenance container service label differs")
        project_ps = require(self.command("maintenance-project-ps",
            ["docker", "ps", "-a", "--filter",
             "label=com.docker.compose.project=" + self.projects[key], "--format", "{{json .}}"])).splitlines()
        (self.run_dir / key / "project-ps.jsonl").write_text("\n".join(project_ps) + "\n")
        if len(project_ps) != 1 or json.loads(project_ps[0]).get("Names") != state["Name"].lstrip("/"):
            raise ProbeFailure("maintenance project created more than its own service")
        self.result["cases"][key].update({"runtime": "pass", "container_id": container_id,
            "serve_env_absent": not (self.run_dir / key / "serve.env").exists(),
            "project_container_count": len(project_ps), "center_created": False})
        self.record()

    def cleanup(self):
        audit = {"projects": {}, "remaining_containers": None, "remaining_networks": {}}
        for key in self.started:
            audit["projects"][key] = self.compose(key, "down-" + key,
                ["down", "--timeout", "2", "--remove-orphans"], 60)
        containers = self.command("remaining-own-containers",
            ["docker", "ps", "-a", "--filter", "label=omne.m0.runtime-input-probe=" + self.run_id,
             "--format", "{{json .}}"])
        audit["remaining_containers"] = containers
        for key, project in self.projects.items():
            audit["remaining_networks"][key] = self.command("remaining-network-" + key,
                ["docker", "network", "ls", "--filter", "label=com.docker.compose.project=" + project,
                 "--format", "{{json .}}"])
        audit["complete"] = (all(successful(item) for item in audit["projects"].values())
            and successful(containers) and not containers["stdout"].strip()
            and all(successful(item) and not item["stdout"].strip()
                    for item in audit["remaining_networks"].values()))
        self.result["cleanup"] = audit
        self.write_json("cleanup.json", audit)
        self.record()

    def execute(self):
        try:
            self.preflight()
            for key in ("uid10001", "uid10002", "maintenance"):
                self.config_case(key)
            self.center_case("uid10001", 10001)
            self.center_case("uid10002", 10002)
            self.maintenance_case()
            self.result["status"] = "observed"
        except Exception as exc:
            self.result["status"] = "failed"
            self.result["error"] = repr(exc)
        finally:
            self.cleanup()
        if not self.result["cleanup"]["complete"]:
            self.result["status"] = "cleanup-incomplete"
            self.record()
        return self.result


if __name__ == "__main__":
    if sys.argv[1:] == ["--self-test"]:
        result = self_test()
        (ROOT / "self-test.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result))
    elif not sys.argv[1:]:
        probe = Probe()
        result = probe.execute()
        print(probe.run_dir)
        sys.exit(0 if result["status"] == "observed" else 1)
    else:
        print("usage: probe.py [--self-test]", file=sys.stderr)
        sys.exit(64)
