#!/usr/bin/env python3
"""M0-V0 one-shot Linux control-host dependency gate; no product assertions."""

import hashlib
import json
import pathlib
import shutil
import signal
import subprocess
import sys
from datetime import datetime, timezone


HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE / "pilot-output"
PREFIX = "omne-m0-v0-20260926-fc30a6d4"
LABEL = f"omne.m0.v0=20260926-fc30a6d4"
IMAGE = "omne-maintenance-systemd-probe:20260925"
IMAGE_ID = "sha256:1e6bd25c12d9da8a88666720682cca7c3372928448953dc41e015c8fe5617675"
NETWORK = f"{PREFIX}-net"
VOLUMES = [f"{PREFIX}-{name}" for name in ("data", "socket", "daemon-data")]
CONTROL = f"{PREFIX}-control"
REQUIRED = ("jq", "flock", "curl", "openssl", "node", "systemctl", "stat", "sh")

commands = []
created = []
result = {"pilot": "M0-V0 control dependency gate", "prefix": PREFIX, "started_utc": None,
          "status": "not_started", "missing_tools": [], "created": created,
          "commands": commands, "cleanup": []}


def utc():
    return datetime.now(timezone.utc).isoformat()


def save():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def run(argv, timeout=30):
    entry = {"argv": argv, "started_utc": utc(), "timeout_seconds": timeout}
    try:
        completed = subprocess.run(argv, text=True, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, timeout=timeout, check=False)
        entry.update(returncode=completed.returncode, stdout=completed.stdout,
                     stderr=completed.stderr)
    except subprocess.TimeoutExpired as exc:
        def decode(value):
            return value.decode("utf-8", "replace") if isinstance(value, bytes) else (value or "")
        entry.update(returncode=None, timed_out=True, stdout=decode(exc.stdout),
                     stderr=decode(exc.stderr))
    entry["finished_utc"] = utc()
    commands.append(entry)
    save()
    return entry


def require_ok(entry):
    if entry.get("returncode") != 0:
        raise RuntimeError(f"command failed: {entry['argv']!r}, rc={entry.get('returncode')}")
    return entry["stdout"]


def check_absent(kind, name):
    cmd = {"container": ["docker", "container", "inspect", name],
           "volume": ["docker", "volume", "inspect", name],
           "network": ["docker", "network", "inspect", name]}[kind]
    observed = run(cmd)
    if observed.get("returncode") == 0:
        raise RuntimeError(f"refusing to use pre-existing {kind}: {name}")
    if observed.get("returncode") is None:
        raise RuntimeError(f"could not check {kind}: {name}")


def on_signal(signum, _frame):
    raise KeyboardInterrupt(f"signal {signum}")


def main():
    if OUT.exists():
        raise RuntimeError(f"refusing to overwrite pilot output: {OUT}")
    OUT.mkdir()
    result["started_utc"] = utc()
    save()
    if shutil.which("docker") is None:
        raise RuntimeError("Docker executable absent on macOS test host")
    for kind, name in [("network", NETWORK), *(('volume', v) for v in VOLUMES),
                       ("container", CONTROL), ("container", f"{PREFIX}-dind")]:
        check_absent(kind, name)

    version = require_ok(run(["docker", "version", "--format", "{{json .}}"])).strip()
    result["outer_docker_version"] = json.loads(version)
    inspect = json.loads(require_ok(run(["docker", "image", "inspect", IMAGE])))[0]
    result["control_image"] = {key: inspect.get(key) for key in ("Id", "RepoTags", "RepoDigests", "Os", "Architecture")}
    if inspect.get("Id") != IMAGE_ID or inspect.get("Os") != "linux" or inspect.get("Architecture") != "arm64":
        raise RuntimeError("fixed control image identity/platform differs from plan")

    created.append(("network", NETWORK))
    save()
    require_ok(run(["docker", "network", "create", "--label", LABEL, NETWORK]))
    for volume in VOLUMES:
        created.append(("volume", volume))
        save()
        require_ok(run(["docker", "volume", "create", "--label", LABEL, volume]))

    argv = ["docker", "run", "-d", "--name", CONTROL, "--label", LABEL,
            "--network", NETWORK, "--privileged", "--cgroupns=private",
            "--tmpfs", "/run", "--tmpfs", "/run/lock", "--tmpfs", "/tmp",
            "-v", f"{VOLUMES[0]}:/var/lib/omne-tenancy",
            "-v", f"{VOLUMES[1]}:/opt/omne-private-docker",
            IMAGE]
    created.append(("container", CONTROL))
    save()
    require_ok(run(argv, timeout=90))
    state = json.loads(require_ok(run(["docker", "container", "inspect", CONTROL])))[0]
    result["control_inspect"] = {"Id": state.get("Id"), "Image": state.get("Image"),
                                 "State": state.get("State"), "Mounts": state.get("Mounts")}
    if state["State"].get("Running") is not True:
        raise RuntimeError("systemd control container is not running")

    result["systemd_version"] = require_ok(run(["docker", "exec", CONTROL,
                                                 "systemctl", "--version"]))
    result["pid1_comm"] = require_ok(run(["docker", "exec", CONTROL,
                                          "cat", "/proc/1/comm"]))
    if result["pid1_comm"].strip() != "systemd":
        raise RuntimeError("control PID1 is not systemd")
    require_ok(run(["docker", "exec", CONTROL, "systemctl", "list-units", "--no-pager"]))
    for tool in REQUIRED:
        entry = run(["docker", "exec", CONTROL, "sh", "-c", f"command -v {tool}"])
        if entry.get("returncode") != 0:
            result["missing_tools"].append(tool)
    if result["missing_tools"]:
        result["status"] = "blocked_missing_linux_tools"
        return
    result["status"] = "control_dependency_gate_passed"


def cleanup():
    for kind, name in reversed(created):
        cmd = {"container": ["docker", "rm", "-f", name],
               "volume": ["docker", "volume", "rm", name],
               "network": ["docker", "network", "rm", name]}[kind]
        result["cleanup"].append({"kind": kind, "name": name, "remove": run(cmd, timeout=60)})
    for kind, name in created:
        cmd = {"container": ["docker", "container", "inspect", name],
               "volume": ["docker", "volume", "inspect", name],
               "network": ["docker", "network", "inspect", name]}[kind]
        entry = run(cmd)
        result["cleanup"].append({"kind": kind, "name": name, "absent": entry.get("returncode") != 0,
                                  "inspect": entry})
    result["finished_utc"] = utc()
    save()


if __name__ == "__main__":
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, on_signal)
    if OUT.exists():
        print(f"refusing to overwrite pilot output: {OUT}", file=sys.stderr)
        sys.exit(2)
    try:
        main()
    except BaseException as exc:
        result["status"] = "pilot_failed"
        result["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        cleanup()
    print(json.dumps({"status": result["status"], "missing_tools": result["missing_tools"],
                      "error": result.get("error"), "output": str(OUT)}, sort_keys=True))
    sys.exit(0 if result["status"] == "control_dependency_gate_passed" else 1)
