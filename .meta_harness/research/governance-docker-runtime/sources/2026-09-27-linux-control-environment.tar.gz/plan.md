# M0-V0 single-pilot resource plan

Source: HUB `tmp/next-iteration/tasks/docker-product-fixtures.md` and `docker-delivery.md` V0, read 2026-09-26. Worktree branch `pandazki/agent-work-loop-docker-fixtures`, initial HEAD `fc30a6d48cb6f8a71c18115116faad434e04db48`.

The first pilot is a dependency gate for the Linux control image. The only outer resources it may create are these uniquely named, labelled resources:

| Resource | Name | Intended use |
| --- | --- | --- |
| network | `omne-m0-v0-20260926-fc30a6d4-net` | private test network |
| volume | `omne-m0-v0-20260926-fc30a6d4-data` | later identical-path control/DinD data |
| volume | `omne-m0-v0-20260926-fc30a6d4-socket` | later private DinD socket |
| volume | `omne-m0-v0-20260926-fc30a6d4-daemon-data` | later DinD state |
| container | `omne-m0-v0-20260926-fc30a6d4-control` | Linux root systemd control host |
| container | `omne-m0-v0-20260926-fc30a6d4-dind` | reserved for isolated daemon, only if control gate passes |

All use label `omne.m0.v0=20260926-fc30a6d4`. Control image is the already cached `omne-maintenance-systemd-probe:20260925`, expected image ID `sha256:1e6bd25c12d9da8a88666720682cca7c3372928448953dc41e015c8fe5617675` and `linux/arm64`. No pull. The outer Docker socket is never mounted into the control container; only the reserved private socket volume may later be shared with DinD. The control container needs `--privileged`, private cgroup namespace, and disposable `/run`, `/run/lock`, `/tmp` tmpfs for systemd. No ports or host directory are mounted by this first gate.

Preflight rejects any resource name that already exists, image ID/platform mismatch, or missing Docker executable. The run creates one network, three volumes, and one control container at most once. It checks systemd and Linux tools `jq`, `flock`, `curl`, `openssl`, `node`, `systemctl`, `stat`, `sh`; missing tools or a failed systemd start end this pilot immediately. It records each command, stdout, stderr, return code, image identity, and cleanup results. No DinD, timer, data ownership, or TLS result can be inferred from a control-tool failure.

Cleanup removes only resources that this run created: force-remove the named control container, remove the three named volumes and network, then inspect each name for absence. It never stops or configures the user's Docker daemon or other containers. A hard kill can bypass Python's `finally`; use `docker ps -a --filter label=omne.m0.v0=20260926-fc30a6d4`, `docker volume ls --filter label=...`, and `docker network ls --filter label=...` to audit before any manual, name-specific cleanup. No old spoke resource is in scope.

If `jq` is absent, the required isolated derivative is a pinned build from the recorded control image ID, with Debian `jq` package added. If `flock` is absent, add Debian `util-linux`; other missing names must be mapped from actual evidence. Do not install anything on macOS. Parent coordination is required before making that derivative and retrying a pilot; this run does not fix and rerun.
