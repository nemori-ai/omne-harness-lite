#!/usr/bin/env python3
"""Pure V0-c measurement checks; never creates a Docker resource."""

import ast
import hashlib
import importlib.util
import json
import pathlib
import tarfile

HERE = pathlib.Path(__file__).resolve().parent
SCRIPT = HERE / "pilot.py"


def main():
    source = SCRIPT.read_text()
    tree = ast.parse(source)
    spec = importlib.util.spec_from_file_location("v0c_pilot_static", SCRIPT)
    pilot = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pilot)
    checks = {}

    checks["stable_running"] = pilot.is_stable_state({"Running": True, "Restarting": False, "Pid": 42})
    checks["reject_restarting"] = not pilot.is_stable_state({"Running": True, "Restarting": True, "Pid": 42})
    checks["reject_pid_zero"] = not pilot.is_stable_state({"Running": True, "Restarting": False, "Pid": 0})
    before = {"ExecMainStartTimestampMonotonic": "100"}
    finished = {"ExecMainStartTimestampMonotonic": "200", "ExecMainExitTimestampMonotonic": "230",
                "ActiveState": "inactive", "Result": "success"}
    checks["new_completed_run"] = pilot.completed_after(before, finished)
    checks["reject_stale_result"] = not pilot.completed_after(
        before, {**finished, "ExecMainStartTimestampMonotonic": "100"})
    checks["reject_unfinished_run"] = not pilot.completed_after(
        before, {**finished, "ExecMainExitTimestampMonotonic": "0"})
    checks["reject_activating"] = not pilot.completed_after(
        before, {**finished, "ActiveState": "activating"})
    checks["reject_absent_timestamp"] = not pilot.completed_after(
        before, {**finished, "ExecMainExitTimestampMonotonic": "n/a"})

    fetch = json.loads((HERE / "compose-fetch-result.json").read_text())
    compose_hash = hashlib.sha256(pilot.COMPOSE_ASSET.read_bytes()).hexdigest()
    checks["official_compose_hash"] = (fetch["status"] == "verified" and
                                       fetch["asset"]["official_sha256"] == compose_hash ==
                                       pilot.COMPOSE_SHA256)
    checks["container_compose_version"] = fetch["container_version"]["stdout"].strip() == \
        "Docker Compose version v2.40.3"

    old_tar = HERE.parent / "v0b" / "busybox-1.37.0.tar"
    with tarfile.open(old_tar) as archive:
        saved_manifest = json.load(archive.extractfile("manifest.json"))[0]
        config_path = saved_manifest["Config"]
        config_hash = hashlib.sha256(archive.extractfile(config_path).read()).hexdigest()
    checks["tar_config_is_outer_id"] = config_path == f"blobs/sha256/{config_hash}" and \
        f"sha256:{config_hash}" == pilot.BUSYBOX_ID
    checks["id_equality_not_required"] = "image[\"Id\"] != BUSYBOX_ID" not in source
    checks["stream_load_not_tmp_copy"] = ('"exec", "-i", DIND, "docker", "--host", SOCKET, "load"' in source and
                                           'f"{DIND}:/tmp/busybox.tar"' not in source)

    unit = (HERE / pilot.SERVICE).read_text()
    timer = (HERE / pilot.TIMER).read_text()
    checks["unit_private_exec_no_start_dependency"] = (
        f"--host {pilot.SOCKET} exec {pilot.OWNERS[0]}" in unit and
        not any(key in unit for key in ("Requires=", "Wants=", "BindsTo=")))
    checks["timer_unit_target"] = f"Unit={pilot.SERVICE}" in timer and "OnActiveSec=2s" in timer

    tls_function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "tls")
    assignments = {target.id: ast.literal_eval(node.value)
                   for node in tls_function.body if isinstance(node, ast.Assign)
                   for target in node.targets if isinstance(target, ast.Name) and target.id in ("server", "cert_cmd")}
    checks["static_tls_server_matches"] = (HERE / "tls-server-static.mjs").read_text() == assignments["server"]
    checks["static_cert_command_matches"] = (HERE / "cert-command-static.sh").read_text() == \
        assignments["cert_cmd"] + "\n"
    checks["tmp_transfer_uses_exec_stream"] = ('"exec", "-i", CONTROL, "tee", "/tmp/tls-server.mjs"' in source and
                                                'docker("exec", CONTROL, "cat", "/tmp/tls/ca.crt")' in source)
    checks["v0c_names_only"] = "v0b" not in source
    return {"status": "pass" if all(checks.values()) else "fail", "checks": checks,
            "pilot_sha256": hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
            "compose_sha256": compose_hash, "old_tar_config_sha256": config_hash}


if __name__ == "__main__":
    print(json.dumps(main(), indent=2, sort_keys=True))
