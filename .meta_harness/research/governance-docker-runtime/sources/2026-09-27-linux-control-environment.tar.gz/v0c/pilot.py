#!/usr/bin/env python3
"""Proposed V0-c isolated Docker/systemd pilot; static only until mainline review."""

import hashlib
import json
import pathlib
import re
import signal
import socket
import subprocess
import sys
import tarfile
import time
from datetime import datetime, timezone

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE / "pilot-output"
PREFIX = "omne-m0-v0c-20260927-fc30a6d4"
LABEL = "omne.m0.v0c=20260927-fc30a6d4"
CONTROL_IMAGE = "omne-m0-v0-control-tools:20260926-fc30a6d4"
CONTROL_ID = "sha256:825773f9776113d54fb23a5de9511d5b6c7bc7550d891f7a3584bfe71c0795f6"
DIND_IMAGE = "docker:29.1.3-dind"
DIND_ID = "sha256:20cca7e2a7da287ded85087ce88d443a5347163eebf6a9ed0c27bc4cabe90ae7"
BUSYBOX_IMAGE = "busybox:1.37.0"
BUSYBOX_ID = "sha256:ad4f11f7c85f87c0a6d6c0fe492ad53f9cdcff6e8c88b881360c70eff701c67b"
COMPOSE_SHA256 = "d26373b19e89160546d15407516cc59f453030d9bc5b43ba7faf16f7b4980137"
COMPOSE_ASSET = HERE / "docker-compose-linux-aarch64"
SOCKET = "unix:///opt/omne-private-docker/docker.sock"
NETWORK = f"{PREFIX}-net"
VOLUMES = [f"{PREFIX}-{part}" for part in ("data", "socket", "daemon-data")]
CONTROL = f"{PREFIX}-control"
DIND = f"{PREFIX}-dind"
OWNERS = [f"{PREFIX}-owner-a", f"{PREFIX}-owner-b"]
SERVICE = "omne-v0c-probe.service"
TIMER = "omne-v0c-probe.timer"

result = {"status": "not_started", "started_utc": None, "commands": [],
          "created": [], "cleanup": [], "checks": {}, "input_images": {}}


def utc():
    return datetime.now(timezone.utc).isoformat()


def save():
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def run(argv, timeout=60, stdin_path=None):
    record = {"argv": argv, "started_utc": utc(), "timeout_seconds": timeout}
    source = stdin_path.open("rb") if stdin_path else None
    if stdin_path:
        record["stdin_path"] = str(stdin_path)
        record["stdin_sha256"] = hashlib.sha256(stdin_path.read_bytes()).hexdigest()
    try:
        done = subprocess.run(argv, stdin=source, text=True, capture_output=True,
                              timeout=timeout, check=False)
        record.update(returncode=done.returncode, stdout=done.stdout, stderr=done.stderr)
    except subprocess.TimeoutExpired as exc:
        def decode(data):
            return data.decode("utf-8", "replace") if isinstance(data, bytes) else (data or "")
        record.update(returncode=None, timed_out=True, stdout=decode(exc.stdout),
                      stderr=decode(exc.stderr))
    finally:
        if source:
            source.close()
    record["finished_utc"] = utc()
    result["commands"].append(record)
    save()
    return record


def ok(argv, timeout=60, stdin_path=None):
    record = run(argv, timeout, stdin_path)
    if record.get("returncode") != 0:
        raise RuntimeError(f"command failed rc={record.get('returncode')}: {argv!r}")
    return record["stdout"]


def docker(*args, timeout=60):
    return ok(["docker", *args], timeout)


def inner(*args, timeout=60):
    return docker("exec", DIND, "docker", "--host", SOCKET, *args, timeout=timeout)


def absent(kind, name):
    action = {"network": "network", "volume": "volume", "container": "container"}[kind]
    observed = run(["docker", action, "inspect", name])
    if observed.get("returncode") == 0 or observed.get("returncode") is None:
        raise RuntimeError(f"resource name not safely absent: {kind} {name}")


def image_identity(name, expected):
    image = json.loads(docker("image", "inspect", name))[0]
    if (image["Id"], image["Os"], image["Architecture"]) != (expected, "linux", "arm64"):
        raise RuntimeError(f"cached image identity/platform mismatch: {name}")
    result["input_images"][name] = {key: image.get(key) for key in
                                    ("Id", "RepoTags", "RepoDigests", "Os", "Architecture")}
    save()


def create(kind, name, argv, timeout=90):
    # Names are checked absent before creation. Record ownership before a possibly timed-out create.
    result["created"].append([kind, name])
    save()
    ok(argv, timeout)


def wait_for(label, probe, timeout=30, interval=0.5):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        observed = probe()
        if observed:
            result["checks"][label] = observed
            save()
            return observed
        time.sleep(interval)
    raise RuntimeError(f"timed out waiting for {label}")


def dind_ready():
    observed = run(["docker", "exec", DIND, "docker", "--host", SOCKET,
                    "version", "--format", "{{json .}}"], timeout=8)
    if observed.get("returncode") != 0:
        return None
    try:
        value = json.loads(observed["stdout"])
        if value["Server"]["Version"] == "29.1.3":
            return value
    except (ValueError, KeyError, TypeError):
        pass
    return None


def inner_inspect(name):
    return json.loads(inner("container", "inspect", name))[0]


def is_stable_state(state):
    return (state.get("Running") is True and state.get("Restarting") is False and
            isinstance(state.get("Pid"), int) and state["Pid"] > 0)


def stable_owner(name):
    try:
        state = inner_inspect(name)["State"]
        if is_stable_state(state):
            return {"Running": state["Running"], "Restarting": state["Restarting"],
                    "Pid": state["Pid"], "StartedAt": state["StartedAt"]}
    except (RuntimeError, KeyError, ValueError):
        pass
    return None


def deploy_cli():
    path = docker("exec", DIND, "sh", "-c", "command -v docker").strip()
    if not path.startswith("/"):
        raise RuntimeError("fixed DinD image has no absolute Docker CLI path")
    bin_dir = HERE / "extracted-bin"
    bin_dir.mkdir()
    docker("cp", f"{DIND}:{path}", str(bin_dir / "docker"))
    result["checks"]["cli_binary_sha256"] = hashlib.sha256((bin_dir / "docker").read_bytes()).hexdigest()
    docker("cp", str(bin_dir / "docker"), f"{CONTROL}:/usr/local/bin/docker")
    docker("exec", CONTROL, "chmod", "0755", "/usr/local/bin/docker")
    version = json.loads(docker("exec", CONTROL, "docker", "--host", SOCKET,
                                "version", "--format", "{{json .}}"))
    if version["Client"]["Version"] != "29.1.3" or version["Server"]["Version"] != "29.1.3":
        raise RuntimeError("control Docker CLI/private Engine version mismatch")
    result["checks"]["control_private_docker"] = {"source_path": path, "version": version}
    save()

    # v5 in the DinD image is deliberately ignored. This is the verified v2.40.3 Linux asset.
    if hashlib.sha256(COMPOSE_ASSET.read_bytes()).hexdigest() != COMPOSE_SHA256:
        raise RuntimeError("official Compose binary changed after static verification")
    docker("exec", CONTROL, "mkdir", "-p", "/usr/local/lib/docker/cli-plugins")
    docker("cp", str(COMPOSE_ASSET),
           f"{CONTROL}:/usr/local/lib/docker/cli-plugins/docker-compose")
    docker("exec", CONTROL, "chmod", "0755", "/usr/local/lib/docker/cli-plugins/docker-compose")
    observed = run(["docker", "exec", CONTROL, "docker", "compose", "version"])
    version = observed.get("stdout", "").strip()
    result["checks"]["compose"] = {"source_asset": str(COMPOSE_ASSET),
                                     "sha256": COMPOSE_SHA256,
                                     "returncode": observed.get("returncode"), "version": version,
                                     "exact_2_40_3": observed.get("returncode") == 0 and
                                     bool(re.search(r"\bv?2\.40\.3\b", version))}
    if not result["checks"]["compose"]["exact_2_40_3"]:
        raise RuntimeError("control Linux Compose is not exact 2.40.3")
    save()


def load_busybox():
    tar = HERE / "busybox-1.37.0.tar"
    docker("image", "save", "-o", str(tar), BUSYBOX_IMAGE, timeout=120)
    host_image = json.loads(docker("image", "inspect", BUSYBOX_IMAGE))[0]
    with tarfile.open(tar) as archive:
        manifest = json.load(archive.extractfile("manifest.json"))[0]
        config_path = manifest["Config"]
        config = archive.extractfile(config_path).read()
        config_sha = "sha256:" + hashlib.sha256(config).hexdigest()
    result["checks"]["busybox_tar"] = {"path": str(tar), "bytes": tar.stat().st_size,
                                        "sha256": hashlib.sha256(tar.read_bytes()).hexdigest(),
                                        "config_path": config_path, "config_sha256": config_sha,
                                        "host_image_id": host_image["Id"],
                                        "host_rootfs_layers": host_image["RootFS"]["Layers"]}
    if config_sha != host_image["Id"] or config_path != "blobs/sha256/" + config_sha.removeprefix("sha256:"):
        raise RuntimeError("saved tar config does not identify the cached host image")
    save()
    # The tar exists on macOS only. -i supplies its bytes to the CLI process in the
    # named DinD container; that CLI sends them to its explicitly selected private daemon.
    ok(["docker", "exec", "-i", DIND, "docker", "--host", SOCKET, "load"],
       timeout=120, stdin_path=tar)
    image = json.loads(inner("image", "inspect", BUSYBOX_IMAGE))[0]
    result["checks"]["inner_busybox"] = {"Id": image["Id"], "Os": image["Os"],
                                          "Architecture": image["Architecture"],
                                          "RootFS.Layers": image["RootFS"]["Layers"]}
    if (image["RootFS"]["Layers"] != host_image["RootFS"]["Layers"] or
            image["Os"] != host_image["Os"] or
            image["Architecture"] != host_image["Architecture"]):
        raise RuntimeError("inner BusyBox content/platform differs from cached host image")
    save()


def data_paths():
    app = "/var/lib/omne-tenancy/app"
    docker("exec", CONTROL, "sh", "-c",
           f"install -d -m 0700 -o 10001 -g 10001 {app} && "
           f"printf 'v0c-root-marker\\n' > {app}/root-marker && chown 10001:10001 {app}/root-marker")
    views = {}
    for label, outer in (("control", CONTROL), ("dind", DIND)):
        stat = docker("exec", outer, "stat", "-c", "%i:%u:%g:%a", app).strip()
        marker = docker("exec", outer, "cat", f"{app}/root-marker").strip()
        views[label] = {"stat": stat, "marker": marker}
    if views["control"] != views["dind"] or not views["control"]["stat"].endswith(":10001:10001:700"):
        raise RuntimeError("control/DinD data inode, UID, mode or marker mismatch")
    for index, name in enumerate(OWNERS):
        inner("run", "-d", "--pull", "never", "--name", name, "--network", "none",
              "--user", "10001:10001", "--restart", "no",
              "-v", f"{app}:{app}", BUSYBOX_IMAGE, "sh", "-c",
              f"printf owner-{index} > {app}/owner-{index}; sleep 300")
        wait_for(f"owner_{index}_stable", lambda n=name: stable_owner(n), timeout=15)
    for index, name in enumerate(OWNERS):
        views[name] = {"stat": inner("exec", name, "stat", "-c", "%i:%u:%g:%a", app).strip(),
                       "uid": inner("exec", name, "id", "-u").strip(),
                       "root_marker": inner("exec", name, "cat", f"{app}/root-marker").strip(),
                       "other_marker": inner("exec", name, "cat", f"{app}/owner-{1-index}").strip()}
        if views[name]["stat"] != views["control"]["stat"] or views[name]["uid"] != "10001":
            raise RuntimeError(f"inner owner {index} does not see same inode/UID/mode")
    result["checks"]["shared_data_views"] = views
    save()


def timer_snapshot():
    text = docker("exec", CONTROL, "systemctl", "show", SERVICE,
                  "-p", "ActiveState", "-p", "Result", "-p", "ExecMainStatus",
                  "-p", "InvocationID", "-p", "ExecMainStartTimestampMonotonic",
                  "-p", "ExecMainExitTimestampMonotonic")
    return dict(line.split("=", 1) for line in text.splitlines() if "=" in line)


def completed_after(before, observed):
    try:
        previous_start = int(before["ExecMainStartTimestampMonotonic"])
        start = int(observed["ExecMainStartTimestampMonotonic"])
        end = int(observed["ExecMainExitTimestampMonotonic"])
    except (KeyError, TypeError, ValueError):
        return False
    return (start > previous_start and start > 0 and end >= start and
            observed.get("ActiveState") in ("inactive", "failed"))


def last_trigger():
    return docker("exec", CONTROL, "systemctl", "show", TIMER,
                  "-p", "LastTriggerUSec", "--value").strip()


def fire_timer(label, previous):
    before = timer_snapshot()
    if before.get("ActiveState") == "failed":
        docker("exec", CONTROL, "systemctl", "reset-failed", SERVICE)
    docker("exec", CONTROL, "systemctl", "restart", TIMER)
    trigger = wait_for(f"{label}_trigger", lambda: (value if (value := last_trigger()) != previous
                                                    and value not in ("", "n/a") else None),
                       timeout=20)
    # A changed timer trigger alone cannot certify this service's completion.
    # The main process must start anew and reach a recorded exit in this systemd boot.
    snap = wait_for(f"{label}_service", lambda: (value if completed_after(before, value := timer_snapshot())
                                                else None), timeout=15)
    result["checks"][label] = {"trigger": trigger, "service_before": before,
                                "service_after": snap}
    save()
    return trigger, snap


def systemd_timer():
    unit = (HERE / SERVICE).read_text()
    timer = (HERE / TIMER).read_text()
    if ("Requires=" in unit or "Wants=" in unit or "BindsTo=" in unit or
            f"--host {SOCKET} exec {OWNERS[0]}" not in unit or
            f"Unit={SERVICE}" not in timer):
        raise RuntimeError("static timer/service fixture differs from private exec plan")
    ok(["docker", "exec", "-i", CONTROL, "tee", f"/etc/systemd/system/{SERVICE}"],
       stdin_path=HERE / SERVICE)
    ok(["docker", "exec", "-i", CONTROL, "tee", f"/etc/systemd/system/{TIMER}"],
       stdin_path=HERE / TIMER)
    docker("exec", CONTROL, "systemctl", "daemon-reload")
    previous = last_trigger()
    trigger, snap = fire_timer("timer_running_target", previous)
    if snap.get("Result") != "success" or snap.get("ExecMainStatus") != "0":
        raise RuntimeError("real timer did not execute existing running inner target")
    marker = docker("exec", CONTROL, "stat", "-c", "%i:%s", "/var/lib/omne-tenancy/app/timer-ran").strip()
    result["checks"]["timer_running_target"]["marker"] = marker
    save()
    if not marker.endswith(":1"):
        raise RuntimeError("running-target timer did not write one marker byte")
    before = inner_inspect(OWNERS[0])
    inner("stop", "-t", "2", OWNERS[0], timeout=20)
    stopped = inner_inspect(OWNERS[0])
    if stopped["State"]["Running"] is not False:
        raise RuntimeError("inner target did not actually stop")
    trigger, snap = fire_timer("timer_stopped_target", trigger)
    after = inner_inspect(OWNERS[0])
    result["checks"]["timer_stopped_target"].update({
        "target_before": before["State"], "target_stopped": stopped["State"],
        "target_after": after["State"],
        "marker_after": docker("exec", CONTROL, "stat", "-c", "%i:%s",
                               "/var/lib/omne-tenancy/app/timer-ran").strip()})
    save()
    if (snap.get("Result") == "success" or snap.get("ExecMainStatus") == "0" or
            after["State"]["Running"] is not False or
            after["State"]["StartedAt"] != stopped["State"]["StartedAt"] or
            result["checks"]["timer_stopped_target"]["marker_after"] != marker):
        raise RuntimeError("stopped-target timer result/target state failed")
    docker("stop", "-t", "10", DIND, timeout=30)
    dind_before = json.loads(docker("container", "inspect", DIND))[0]
    if dind_before["State"]["Running"] is not False:
        raise RuntimeError("isolated daemon did not stop")
    _, snap = fire_timer("timer_daemon_unreachable", trigger)
    dind_after = json.loads(docker("container", "inspect", DIND))[0]
    result["checks"]["timer_daemon_unreachable"].update({
        "dind_before": dind_before["State"], "dind_after": dind_after["State"],
        "marker_after": docker("exec", CONTROL, "stat", "-c", "%i:%s",
                               "/var/lib/omne-tenancy/app/timer-ran").strip()})
    save()
    if (snap.get("Result") == "success" or snap.get("ExecMainStatus") == "0" or
            dind_after["State"]["Running"] is not False or
            dind_after["State"]["StartedAt"] != dind_before["State"]["StartedAt"] or
            dind_after["RestartCount"] != dind_before["RestartCount"] or
            result["checks"]["timer_daemon_unreachable"]["marker_after"] != marker):
        raise RuntimeError("daemon-unreachable timer result/daemon state failed")
    result["checks"]["timer_journal"] = docker("exec", CONTROL, "journalctl", "-u", SERVICE,
                                                "--no-pager", "-n", "60")
    save()


def tls():
    server = ("import https from 'node:https';\n"
              "import fs from 'node:fs';\n"
              "const server = https.createServer({ key: fs.readFileSync('/tmp/tls/leaf.key'), "
              "cert: fs.readFileSync('/tmp/tls/leaf.crt') }, (_req, res) => "
              "{ res.writeHead(200, {'content-type': 'text/plain'}); res.end('v0c-tls-ok\\n'); });\n"
              "server.listen(8443, '0.0.0.0');\n")
    (HERE / "tls-server.mjs").write_text(server)
    ok(["docker", "exec", "-i", CONTROL, "tee", "/tmp/tls-server.mjs"],
       stdin_path=HERE / "tls-server.mjs")
    cert_cmd = ("set -eu; mkdir -p /tmp/tls; "
                "openssl req -x509 -newkey rsa:2048 -sha256 -nodes -days 1 "
                "-subj '/CN=M0 V0c Test CA' -keyout /tmp/tls/ca.key -out /tmp/tls/ca.crt; "
                "openssl req -newkey rsa:2048 -sha256 -nodes -subj '/CN=localhost' "
                "-keyout /tmp/tls/leaf.key -out /tmp/tls/leaf.csr; "
                "printf 'subjectAltName=DNS:localhost,IP:127.0.0.1\\n' > /tmp/tls/ext; "
                "openssl x509 -req -in /tmp/tls/leaf.csr -CA /tmp/tls/ca.crt "
                "-CAkey /tmp/tls/ca.key -CAcreateserial -out /tmp/tls/leaf.crt "
                "-days 1 -sha256 -extfile /tmp/tls/ext")
    docker("exec", CONTROL, "sh", "-c", cert_cmd)
    result["checks"]["tls_verify"] = docker("exec", CONTROL, "openssl", "verify", "-CAfile",
                                              "/tmp/tls/ca.crt", "/tmp/tls/leaf.crt").strip()
    result["checks"]["tls_san"] = docker("exec", CONTROL, "openssl", "x509", "-in",
                                           "/tmp/tls/leaf.crt", "-noout", "-ext", "subjectAltName").strip()
    if ("DNS:localhost" not in result["checks"]["tls_san"] or
            "IP Address:127.0.0.1" not in result["checks"]["tls_san"] or
            not result["checks"]["tls_verify"].endswith(": OK")):
        raise RuntimeError("test leaf CA/SAN verification failed")
    ca_pem = docker("exec", CONTROL, "cat", "/tmp/tls/ca.crt")
    (HERE / "tls-ca.crt").write_text(ca_pem)
    docker("exec", "-d", CONTROL, "node", "/tmp/tls-server.mjs")
    def connected():
        response = run(["docker", "exec", CONTROL, "curl", "--noproxy", "*", "--fail",
                        "--silent", "--show-error", "--cacert", "/tmp/tls/ca.crt",
                        "--resolve", "localhost:8443:127.0.0.1",
                        "--connect-timeout", "2", "--max-time", "4", "https://localhost:8443"], timeout=6)
        return response["stdout"] if response.get("returncode") == 0 else None
    linux = wait_for("tls_linux_response", connected, timeout=15)
    mac = ok(["curl", "--noproxy", "*", "--fail", "--silent", "--show-error",
              "--cacert", str(HERE / "tls-ca.crt"), "--resolve", "localhost:18443:127.0.0.1",
              "--connect-timeout", "2", "--max-time", "6",
              "https://localhost:18443"], timeout=8)
    result["checks"]["tls_mac_response"] = mac
    untrusted = run(["curl", "--noproxy", "*", "--silent", "--show-error",
                     "--resolve", "localhost:18443:127.0.0.1",
                     "--connect-timeout", "2", "--max-time", "6",
                     "https://localhost:18443"], timeout=8)
    result["checks"]["tls_mac_without_ca"] = {"returncode": untrusted.get("returncode"),
                                                "stderr": untrusted.get("stderr")}
    if linux != "v0c-tls-ok\n" or mac != "v0c-tls-ok\n":
        raise RuntimeError("TLS response marker mismatch")
    if untrusted.get("returncode") in (0, None):
        raise RuntimeError("Mac TLS client accepted throwaway CA without trust input")
    result["checks"]["tls_ca_sha256"] = hashlib.sha256((HERE / "tls-ca.crt").read_bytes()).hexdigest()
    save()


def main():
    if OUT.exists():
        raise RuntimeError("refusing to overwrite V0-c pilot evidence")
    OUT.mkdir()
    result["started_utc"] = utc()
    save()
    fetch = json.loads((HERE / "compose-fetch-result.json").read_text())
    if (fetch.get("status") != "verified" or
            fetch.get("asset", {}).get("official_sha256") != COMPOSE_SHA256 or
            hashlib.sha256(COMPOSE_ASSET.read_bytes()).hexdigest() != COMPOSE_SHA256):
        raise RuntimeError("official Compose v2.40.3 asset preflight failed")
    result["checks"]["compose_asset_preflight"] = {
        "official_sha256": COMPOSE_SHA256, "ELF": fetch["asset"]["elf"],
        "container_version": fetch["container_version"]}
    save()
    for kind, name in [("network", NETWORK), *(('volume', v) for v in VOLUMES),
                       ("container", CONTROL), ("container", DIND)]:
        absent(kind, name)
    for image, expected in ((CONTROL_IMAGE, CONTROL_ID), (DIND_IMAGE, DIND_ID),
                            (BUSYBOX_IMAGE, BUSYBOX_ID)):
        image_identity(image, expected)
    with socket.socket() as port:
        port.bind(("127.0.0.1", 18443))
    result["checks"]["loopback_port_preflight"] = "127.0.0.1:18443 free"
    create("network", NETWORK, ["docker", "network", "create", "--label", LABEL, NETWORK])
    for volume in VOLUMES:
        create("volume", volume, ["docker", "volume", "create", "--label", LABEL, volume])
    create("container", CONTROL,
           ["docker", "run", "-d", "--name", CONTROL, "--label", LABEL, "--network", NETWORK,
            "--privileged", "--cgroupns=private", "-p", "127.0.0.1:18443:8443",
            "--tmpfs", "/run", "--tmpfs", "/run/lock", "--tmpfs", "/tmp",
            "-v", f"{VOLUMES[0]}:/var/lib/omne-tenancy",
            "-v", f"{VOLUMES[1]}:/opt/omne-private-docker", CONTROL_IMAGE])
    control_inspect = json.loads(docker("container", "inspect", CONTROL))[0]
    result["checks"]["control_mounts_ports"] = {
        "Mounts": control_inspect["Mounts"], "PortBindings": control_inspect["HostConfig"]["PortBindings"],
        "CgroupnsMode": control_inspect["HostConfig"]["CgroupnsMode"]}
    if any(mount.get("Type") == "bind" or mount.get("Source", "").endswith("docker.sock")
           for mount in control_inspect["Mounts"]):
        raise RuntimeError("control has forbidden host bind/socket mount")
    root = docker("exec", CONTROL, "id", "-u").strip()
    pid1 = docker("exec", CONTROL, "cat", "/proc/1/comm").strip()
    systemd = docker("exec", CONTROL, "systemctl", "--version")
    if root != "0" or pid1 != "systemd":
        raise RuntimeError("control host is not root systemd")
    result["checks"]["control_root_systemd"] = {"uid": root, "pid1": pid1, "version": systemd}
    tools = {}
    for tool in ("jq", "flock", "curl", "openssl", "node", "systemctl", "stat", "tee"):
        observed = run(["docker", "exec", CONTROL, "sh", "-c", f"command -v {tool}"])
        tools[tool] = {"returncode": observed.get("returncode"), "path": observed.get("stdout", "").strip()}
    result["checks"]["control_tools"] = tools
    save()
    if any(value["returncode"] != 0 for value in tools.values()):
        raise RuntimeError("derived control image still lacks required tools")
    result["checks"]["control_dpkg"] = docker("exec", CONTROL, "dpkg-query", "-W",
                                               "-f=${binary:Package} ${Version}\\n", "jq", "curl", "openssl")
    create("container", DIND,
           ["docker", "run", "-d", "--name", DIND, "--label", LABEL, "--network", NETWORK,
            "--privileged", "-e", f"DOCKER_HOST={SOCKET}", "-e", "DOCKER_TLS_CERTDIR=",
            "-v", f"{VOLUMES[0]}:/var/lib/omne-tenancy",
            "-v", f"{VOLUMES[1]}:/opt/omne-private-docker",
            "-v", f"{VOLUMES[2]}:/var/lib/docker", DIND_IMAGE,
            "--host", SOCKET, "--tls=false"], timeout=90)
    dind_inspect = json.loads(docker("container", "inspect", DIND))[0]
    result["checks"]["dind_mounts"] = dind_inspect["Mounts"]
    if any(mount.get("Type") == "bind" or mount.get("Source", "").endswith("docker.sock")
           for mount in dind_inspect["Mounts"]):
        raise RuntimeError("DinD has forbidden host bind/socket mount")
    try:
        result["checks"]["inner_docker_version"] = wait_for("inner_docker_ready", dind_ready, timeout=40)
    except RuntimeError:
        result["checks"]["dind_logs_on_failure"] = docker("logs", DIND)
        save()
        raise
    deploy_cli()
    load_busybox()
    data_paths()
    systemd_timer()
    tls()
    result["status"] = "pilot_completed"


def cleanup():
    for kind, name in reversed(result["created"]):
        args = {"container": ["docker", "rm", "-f", name],
                "volume": ["docker", "volume", "rm", name],
                "network": ["docker", "network", "rm", name]}[kind]
        result["cleanup"].append({"kind": kind, "name": name, "remove": run(args, timeout=90)})
    for kind, name in result["created"]:
        args = {"container": ["docker", "container", "inspect", name],
                "volume": ["docker", "volume", "inspect", name],
                "network": ["docker", "network", "inspect", name]}[kind]
        observed = run(args)
        result["cleanup"].append({"kind": kind, "name": name,
                                  "absent": observed.get("returncode") not in (0, None)})
    result["finished_utc"] = utc()
    save()


def on_signal(signum, _frame):
    raise KeyboardInterrupt(f"signal {signum}")


if __name__ == "__main__":
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, on_signal)
    if OUT.exists():
        print(f"refusing to overwrite prior pilot: {OUT}", file=sys.stderr)
        sys.exit(2)
    try:
        main()
    except BaseException as exc:
        result["status"] = "pilot_failed"
        result["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        cleanup()
    print(json.dumps({"status": result["status"], "error": result.get("error"),
                      "checks": list(result["checks"]), "output": str(OUT)}, sort_keys=True))
    sys.exit(0 if result["status"] == "pilot_completed" else 1)
