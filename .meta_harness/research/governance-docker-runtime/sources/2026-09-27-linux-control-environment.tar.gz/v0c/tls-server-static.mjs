import https from 'node:https';
import fs from 'node:fs';
const server = https.createServer({ key: fs.readFileSync('/tmp/tls/leaf.key'), cert: fs.readFileSync('/tmp/tls/leaf.crt') }, (_req, res) => { res.writeHead(200, {'content-type': 'text/plain'}); res.end('v0c-tls-ok\n'); });
server.listen(8443, '0.0.0.0');
