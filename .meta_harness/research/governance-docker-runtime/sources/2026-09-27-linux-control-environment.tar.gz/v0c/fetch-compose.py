#!/usr/bin/env python3
"""Fetch and check the fixed official Linux Compose asset; no full environment pilot."""

import hashlib
import json
import pathlib
import re
import struct
import subprocess
import sys
from datetime import datetime, timezone

HERE = pathlib.Path(__file__).resolve().parent
BASE = "https://github.com/docker/compose/releases/download/v2.40.3"
ASSET = "docker-compose-linux-aarch64"
CONTROL_IMAGE = "omne-m0-v0-control-tools:20260926-fc30a6d4"
CONTROL_ID = "sha256:825773f9776113d54fb23a5de9511d5b6c7bc7550d891f7a3584bfe71c0795f6"
NAME = "omne-m0-v0c-compose-version-20260926-fc30a6d4"
RESULT = HERE / "compose-fetch-result.json"


def utc():
    return datetime.now(timezone.utc).isoformat()


def cmd(argv, timeout=180):
    started = utc()
    try:
        done = subprocess.run(argv, text=True, capture_output=True, timeout=timeout, check=False)
        return {"argv": argv, "started_utc": started, "finished_utc": utc(),
                "returncode": done.returncode, "stdout": done.stdout, "stderr": done.stderr}
    except subprocess.TimeoutExpired as exc:
        def decode(value):
            return value.decode("utf-8", "replace") if isinstance(value, bytes) else (value or "")
        return {"argv": argv, "started_utc": started, "finished_utc": utc(),
                "returncode": None, "timed_out": True, "stdout": decode(exc.stdout),
                "stderr": decode(exc.stderr)}


def save(result):
    RESULT.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


def need(record):
    if record.get("returncode") != 0:
        raise RuntimeError(f"command failed rc={record.get('returncode')}: {record['argv']!r}")
    return record["stdout"]


def main():
    if RESULT.exists() or (HERE / ASSET).exists() or (HERE / f"{ASSET}.sha256").exists():
        raise RuntimeError("refusing to overwrite Compose download/evidence")
    result = {"status": "started", "started_utc": utc(), "source_release":
              "https://github.com/docker/compose/releases/tag/v2.40.3", "commands": [],
              "version_probe_attempted": False}
    save(result)
    try:
        image = cmd(["docker", "image", "inspect", CONTROL_IMAGE], 30)
        result["commands"].append(image)
        if json.loads(need(image))[0]["Id"] != CONTROL_ID:
            raise RuntimeError("derived control image ID changed")
        for suffix in (".sha256", ""):
            path = HERE / f"{ASSET}{suffix}"
            command = cmd(["curl", "--proto", "=https", "--tlsv1.2", "-fL", "--silent",
                           "--show-error", "--max-time", "180", "--write-out",
                           "%{http_code} %{url_effective}\\n", "--output", str(path),
                           f"{BASE}/{ASSET}{suffix}"], 190)
            result["commands"].append(command)
            save(result)
            need(command)
        checksum = (HERE / f"{ASSET}.sha256").read_text().strip()
        match = re.fullmatch(r"([0-9a-fA-F]{64})(?:\s+\*?docker-compose-linux-aarch64)?", checksum)
        if match is None:
            raise RuntimeError(f"unexpected official checksum file format: {checksum!r}")
        expected = match.group(1).lower()
        data = (HERE / ASSET).read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        result["asset"] = {"path": str(HERE / ASSET), "bytes": len(data),
                           "official_checksum_text": checksum, "official_sha256": expected,
                           "actual_sha256": actual}
        if actual != expected:
            raise RuntimeError("official asset checksum mismatch")
        if data[:4] != b"\x7fELF" or data[4] != 2 or data[5] != 1:
            raise RuntimeError("asset is not little-endian ELF64")
        machine = struct.unpack_from("<H", data, 18)[0]
        result["asset"]["elf"] = {"class": "ELF64", "endianness": "little", "e_machine": machine}
        if machine != 183:
            raise RuntimeError("ELF machine is not AArch64")
        (HERE / ASSET).chmod(0o755)
        before = cmd(["docker", "container", "inspect", NAME], 30)
        result["commands"].append(before)
        if before.get("returncode") in (0, None):
            raise RuntimeError("version-probe name is not demonstrably absent")
        result["version_probe_attempted"] = True
        save(result)
        version = cmd(["docker", "run", "--rm", "--name", NAME,
                       "--label", "omne.m0.v0c=20260926-fc30a6d4", "--network", "none",
                       "--read-only", "--tmpfs", "/tmp", "--user", "10001:10001",
                       "-v", f"{HERE / ASSET}:/usr/local/lib/docker/cli-plugins/docker-compose:ro",
                       "--entrypoint", "/usr/local/lib/docker/cli-plugins/docker-compose",
                       CONTROL_IMAGE, "version"], 90)
        result["commands"].append(version)
        result["container_version"] = {"returncode": version.get("returncode"),
                                       "stdout": version.get("stdout"), "stderr": version.get("stderr")}
        need(version)
        if not re.search(r"\bv?2\.40\.3\b", version["stdout"]):
            raise RuntimeError("container Compose version is not 2.40.3")
        after = cmd(["docker", "container", "inspect", NAME], 30)
        result["commands"].append(after)
        if after.get("returncode") in (0, None):
            raise RuntimeError("version-probe container not removed")
        result["status"] = "verified"
    except BaseException as exc:
        result["status"] = "failed"
        result["error"] = f"{type(exc).__name__}: {exc}"
    if result["version_probe_attempted"]:
        observed = cmd(["docker", "container", "inspect", NAME], 30)
        result["commands"].append(observed)
        if observed.get("returncode") == 0:
            container = json.loads(observed["stdout"])[0]
            if container.get("Config", {}).get("Labels", {}).get("omne.m0.v0c") == "20260926-fc30a6d4":
                result["commands"].append(cmd(["docker", "rm", "-f", NAME], 30))
        final = cmd(["docker", "container", "inspect", NAME], 30)
        result["commands"].append(final)
        result["version_probe_absent"] = final.get("returncode") not in (0, None)
    result["finished_utc"] = utc()
    save(result)
    print(json.dumps({"status": result["status"], "error": result.get("error"),
                      "asset": result.get("asset"), "container_version": result.get("container_version")},
                     sort_keys=True))
    return 0 if result["status"] == "verified" else 1


if __name__ == "__main__":
    sys.exit(main())
