# V0-b one-build, one-pilot resource plan

The original V0 tool-failure run remains unchanged. This run uses a new local image tag `omne-m0-v0-control-tools:20260926-fc30a6d4` built once with `--pull=false --no-cache` from a verified local `omne-maintenance-systemd-probe:20260925` ID `sha256:1e6bd25c12d9da8a88666720682cca7c3372928448953dc41e015c8fe5617675`. The Dockerfile prints and validates Debian 12 os-release and apt source files before `apt-get update`, then installs only `jq curl openssl` with `--no-upgrade --no-install-recommends`. Build logs, actual dpkg versions, source and derived image IDs are evidence. The derived image may remain as a named local cache; it is not pushed. Its non-version-pinned apt inputs mean a later rebuild is a different input until package versions and apt metadata are recorded and pinned.

The single environment pilot uses label `omne.m0.v0b=20260926-fc30a6d4` on these reserved resources, and refuses any name already in use:

| Resource | Name | Purpose |
| --- | --- | --- |
| network | `omne-m0-v0b-20260926-fc30a6d4-net` | isolated network |
| volume | `omne-m0-v0b-20260926-fc30a6d4-data` | shared `/var/lib/omne-tenancy` |
| volume | `omne-m0-v0b-20260926-fc30a6d4-socket` | private `/opt/omne-private-docker` socket |
| volume | `omne-m0-v0b-20260926-fc30a6d4-daemon-data` | isolated DinD `/var/lib/docker` |
| container | `omne-m0-v0b-20260926-fc30a6d4-control` | privileged, private-cgroup systemd host |
| container | `omne-m0-v0b-20260926-fc30a6d4-dind` | privileged Docker 29.1.3 daemon, no host socket |

The control container may publish only `127.0.0.1:18443:8443` for a throwaway CA/SAN TLS endpoint. Port availability is checked before creating resources; a collision ends this single pilot without choosing another port.

DinD input is cached `docker:29.1.3-dind` RepoDigest `docker@sha256:173f284a4299164772a90f52b373e73e087583c0963f1334c9995f190ef6f3f5`, image ID `sha256:20cca7e2a7da287ded85087ce88d443a5347163eebf6a9ed0c27bc4cabe90ae7`, linux/arm64. BusyBox input is cached `busybox:1.37.0` RepoDigest `busybox@sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e`, image ID `sha256:ad4f11f7c85f87c0a6d6c0fe492ad53f9cdcff6e8c88b881360c70eff701c67b`.

The pilot may copy a Linux Docker CLI and Compose plugin only from that already fixed DinD image via its own running named DinD container into its own control container. Each executable must report Docker 29.1.3/Compose 2.40.3 and work against the private socket. Missing exact Compose stops that gate; no latest pull. The inner daemon loads the fixed BusyBox tar exported from the outer cache, not by registry pull. Paths/UID/inode/timer/TLS checks proceed only after version and tool gates. Failing a gate produces a clear partial result and triggers cleanup; the pilot is not edited and rerun.

Cleanup removes only this run's named control/DinD containers, volumes and network. The derived control image is the sole allowed retained cache. The user's actual Docker socket is never mounted in the control container, and its daemon is never stopped or reconfigured. A hard kill requires checking the specific label before manual name-specific cleanup.
