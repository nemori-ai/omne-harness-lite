#!/usr/bin/env python3
"""Build the one allowed V0-b Linux control image and retain raw evidence."""

import hashlib
import json
import pathlib
import subprocess
import sys
from datetime import datetime, timezone

HERE = pathlib.Path(__file__).resolve().parent
BASE = "omne-maintenance-systemd-probe:20260925"
BASE_ID = "sha256:1e6bd25c12d9da8a88666720682cca7c3372928448953dc41e015c8fe5617675"
TARGET = "omne-m0-v0-control-tools:20260926-fc30a6d4"


def utc():
    return datetime.now(timezone.utc).isoformat()


def run(argv, timeout):
    started = utc()
    try:
        done = subprocess.run(argv, text=True, capture_output=True, timeout=timeout, check=False)
        return {"argv": argv, "started_utc": started, "finished_utc": utc(),
                "returncode": done.returncode, "stdout": done.stdout, "stderr": done.stderr}
    except subprocess.TimeoutExpired as exc:
        def decoded(value):
            return value.decode("utf-8", "replace") if isinstance(value, bytes) else (value or "")
        return {"argv": argv, "started_utc": started, "finished_utc": utc(),
                "returncode": None, "timed_out": True, "stdout": decoded(exc.stdout),
                "stderr": decoded(exc.stderr)}


def main():
    result_path = HERE / "build-result.json"
    if result_path.exists() or (HERE / "build.stdout.log").exists() or (HERE / "build.stderr.log").exists():
        raise RuntimeError("refusing to overwrite prior V0-b build evidence")
    result = {"started_utc": utc(), "status": "preflight", "source": BASE,
              "expected_source_id": BASE_ID, "target": TARGET,
              "dockerfile_sha256": hashlib.sha256((HERE / "Dockerfile.control-tools").read_bytes()).hexdigest()}
    try:
        source = run(["docker", "image", "inspect", BASE], 30)
        result["source_inspect"] = source
        if source["returncode"] != 0:
            raise RuntimeError("source image missing")
        image = json.loads(source["stdout"])[0]
        if (image.get("Id"), image.get("Os"), image.get("Architecture")) != (BASE_ID, "linux", "arm64"):
            raise RuntimeError("source image ID/platform mismatch")
        target = run(["docker", "image", "inspect", TARGET], 30)
        result["target_preflight"] = target
        if target["returncode"] == 0 or target["returncode"] is None:
            raise RuntimeError("target image tag already exists or could not be checked")
        result["status"] = "building"
        result_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
        cmd = ["docker", "build", "--pull=false", "--no-cache", "--progress=plain",
               "-t", TARGET, "-f", str(HERE / "Dockerfile.control-tools"), str(HERE)]
        build = run(cmd, 900)
        (HERE / "build.stdout.log").write_text(build.pop("stdout"))
        (HERE / "build.stderr.log").write_text(build.pop("stderr"))
        result["build"] = build
        if build["returncode"] != 0:
            raise RuntimeError(f"single derivative build failed, rc={build['returncode']}")
        derived = run(["docker", "image", "inspect", TARGET], 30)
        result["derived_inspect"] = derived
        if derived["returncode"] != 0:
            raise RuntimeError("cannot inspect derived image")
        parsed = json.loads(derived["stdout"])[0]
        result["derived_identity"] = {key: parsed.get(key) for key in
                                      ("Id", "RepoTags", "RepoDigests", "Os", "Architecture")}
        source_after = run(["docker", "image", "inspect", BASE], 30)
        result["source_after"] = source_after
        if source_after["returncode"] != 0 or json.loads(source_after["stdout"])[0]["Id"] != BASE_ID:
            raise RuntimeError("source tag changed across build")
        result["status"] = "built"
    except BaseException as exc:
        result["status"] = "failed"
        result["error"] = f"{type(exc).__name__}: {exc}"
    result["finished_utc"] = utc()
    result_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": result["status"], "error": result.get("error"),
                      "derived_identity": result.get("derived_identity")}, sort_keys=True))
    return 0 if result["status"] == "built" else 1


if __name__ == "__main__":
    sys.exit(main())
