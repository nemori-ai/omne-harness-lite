# M0-V2c 单次 DinD 重启策略测量

**本轮未通过，且按全局一次运行预算不重跑。**内层 Docker daemon 从未进入停止/再启动阶段：R2 的测量器在过渡态 `State.Status="restarting"`、`Pid=0` 时把 `RestartCount=1` 与 `State.Running=true` 当作第二次运行已稳定，立即保存了旧 `StartedAt`，使 `r2-one-restart` 判据失败。已保存的 daemon 事件另行显示同一容器先 `die exitCode=23`、再 `start`，夹具日志有 `FIRST`、`FAIL23`、`SECOND`；这些是有限的 R2 机制观察，不能把失败的整轮报告为通过。R3 显式 stop exit0/exit1、R4 隔离 daemon 重启、R5 `on-failure` 对照均**未执行**。

执行位置：`/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-probe`，分支 `pandazki/agent-work-loop-docker-probe`，HEAD `2cb236db7da15e78bb1e96dd8220ee68b6eceb75`，tracked 状态干净。先执行 `python3 tmp/docker-restart-probe-r2/probe.py --self-test`（`self-test.json` 通过），然后只执行一次 `python3 tmp/docker-restart-probe-r2/probe.py`，退出码 1，运行目录 `20260926T141123Z-6f65748cb1/`。测量器 SHA-256 `02f33a78d0c91b426881940d22418d90976dc8156bc3ff3bc3a8bff847bd1d90`。全部调用参数、退出码、超时标志与原始 stdout/stderr 在该目录 `commands.jsonl`；`inputs.json` 保存镜像 digest、夹具归档哈希和脚本哈希；完整 Docker inspect 与事件/日志分别保存。

| 项目 | 本次证据与状态 |
| --- | --- |
| R1 隔离环境 | 官方 `docker:29.1.3-dind` RepoDigest `docker@sha256:173f284a4299164772a90f52b373e73e087583c0963f1334c9995f190ef6f3f5`；实际内层 Engine 29.1.3、Linux/arm64。外层容器 `HostConfig.Binds` 为空，没有挂宿主 Docker socket，只有自身匿名数据卷。 |
| 夹具来源 | 缓存 `busybox:1.37.0` RepoDigest `busybox@sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e`；宿主 save tar SHA-256 `39986e21f0fa8fface4e8c16b0ecf138573e1f0b2b9efe6cecc99a8c40f86045`。内层 load 后 OS/架构及 RootFS 层与宿主镜像一致；宿主/内层 image ID 表示不同，保留原值，不冒称相等。 |
| R2 非零退出 | 内层容器 `unless-stopped`；首次日志 14:11:40 `FIRST`，14:11:51 `FAIL23`，14:11:51 `SECOND`。内层 daemon `events` 命令退出码 0，`r2-events.json` 给同一容器 `die exitCode=23`（`timeNano=1790431911453877221`）随后 `start`（`1790431911614278471`）。`RestartCount=1`。测量器取到的第二份 inspect 仍是 `Status=restarting`、`Pid=0`、旧 `StartedAt`，因此当前 `r2-one-restart=false`；该过渡态快照不能当第二次启动完成证据。 |
| 时间源 | `r2-inner-epoch-before=1790431900`；事件查询 `--since 1790431899 --until 1790431913`，`until` 取内层 Linux 当前 epoch `1790431914` 再减 1，命令正常结束并解析为四条 JSON 事件。没有用宿主 UTC 作为 Docker 事件查询上界。 |
| R3 / R4 / R5 | R2 判据失败即停，均未执行；不推断 `unless-stopped` 的显式停机跨 daemon 恢复，也不推断 `on-failure` 的 daemon 重启行为。官方 [Docker restart policy 说明](https://docs.docker.com/engine/containers/start-containers-automatically/)仅是机制资料，不替代本地实测。 |
| R6 清理 | `cleanup.json` 中具名 DinD `docker rm -f -v` 退出码 0，外层 inspect 失败，记录的匿名卷 inspect 失败，前缀容器列表为空，`complete=true`。没有停止或配置用户实际 Docker daemon，没有创建专属网络，也没有删除共享镜像缓存。 |

静态复核旧脚本发现超时后用 `str(bytes)` 包装输出、未检 returncode 即解析，以及宿主时钟用于内层事件 `until`；新脚本在本地自检中覆盖了二进制解码、超时/非零拒绝、`die` 后 `start` 的事件判据和内层 epoch 窗口。本次 R2 失败揭示另一测量错误：`RestartCount` 上升和 `State.Running=true` 可与 `Status=restarting`、`Pid=0` 同时出现。若以后有新的运行授权，等待第二次启动的判据须要求实际 `Status=running`、`Pid>0`、`StartedAt` 改变，再用事件与日志交叉核对。本轮不改判据重跑，不把机制部分事实升级为部署采用、产品验收或无限性质证明。
