#!/usr/bin/env python3
"""One-run Docker restart-policy probe against a private Docker-in-Docker daemon."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import secrets
import subprocess
import sys
import tarfile
import time


ROOT = Path(__file__).resolve().parent
DAEMON_IMAGE = "docker:29.1.3-dind"
DAEMON_DIGEST = "docker@sha256:173f284a4299164772a90f52b373e73e087583c0963f1334c9995f190ef6f3f5"
WORK_IMAGE = "busybox:1.37.0"
WORK_DIGEST = "busybox@sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e"
CRASH_ONCE = "if [ -e /probe-once ]; then trap 'exit 0' TERM; echo SECOND; while :; do sleep 1; done; fi; touch /probe-once; echo FIRST; sleep 11; echo FAIL23; exit 23"
EXIT_ZERO = "trap 'echo TERM_EXIT0; exit 0' TERM; echo START; while :; do sleep 1; done"
EXIT_ONE = "trap 'echo TERM_EXIT1; exit 1' TERM; echo START; while :; do sleep 1; done"


class ProbeFailure(Exception):
    pass


def decode_output(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def require_success(result):
    if result["timed_out"] or result["returncode"] != 0:
        raise ProbeFailure("command failed: " + result["label"])
    return result["stdout"]


def parse_events(result):
    raw = require_success(result)
    return [json.loads(line) for line in raw.splitlines() if line.strip()]


def has_die_then_start(events, container_id, exit_code):
    died = False
    for event in events:
        if event.get("Actor", {}).get("ID") != container_id:
            continue
        if event.get("Action") == "die" and event.get("Actor", {}).get("Attributes", {}).get("exitCode") == str(exit_code):
            died = True
        elif died and event.get("Action") == "start":
            return True
    return False


def event_window(start_epoch, current_epoch):
    since, until = start_epoch - 1, current_epoch - 1
    if until <= since + 10:
        raise ProbeFailure("inner daemon event window is too short")
    return str(since), str(until)


def self_test():
    example = {"Action": "die", "Actor": {"ID": "own", "Attributes": {"exitCode": "23"}}}
    restarted = {"Action": "start", "Actor": {"ID": "own", "Attributes": {}}}
    good = {"label": "fixture", "timed_out": False, "returncode": 0,
            "stdout": json.dumps(example) + "\n" + json.dumps(restarted) + "\n"}
    assert has_die_then_start(parse_events(good), "own", 23)
    assert not has_die_then_start(parse_events(good), "own", 0)
    assert not has_die_then_start([restarted, example], "own", 23)
    assert decode_output(b'{"event":1}\n') == '{"event":1}\n'
    timed_out = {"label": "fixture-timeout", "timed_out": True, "returncode": None,
                 "stdout": decode_output(b'{"Action":"die"}\n')}
    try:
        parse_events(timed_out)
    except ProbeFailure:
        pass
    else:
        raise AssertionError("timed-out command was accepted as evidence")
    assert event_window(100, 114) == ("99", "113")
    return {"result": "pass", "checks": ["bytes decode", "nonzero/timeout gate",
                                         "die-before-start oracle", "inner epoch window"]}


class Probe:
    def __init__(self):
        self.run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(5)
        self.run_dir = ROOT / self.run_id
        self.run_dir.mkdir(mode=0o700)
        suffix = self.run_id.lower().replace("t", "-").replace("z", "")
        self.prefix = "omne-m0-restart-" + suffix
        self.outer = self.prefix + "-daemon"
        self.names = {key: self.prefix + "-" + key.replace("_", "-")
                      for key in ("crash", "running", "stop_zero", "stop_one", "on_failure")}
        self.outer_mounted_volumes = []
        self.result = {"run_id": self.run_id, "status": "incomplete", "checks": {}}

    def write_json(self, name, value):
        (self.run_dir / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")

    def command(self, label, args, timeout=60, stdin_path=None):
        start = time.monotonic()
        timestamp = datetime.now(timezone.utc).isoformat()
        source = stdin_path.open("rb") if stdin_path else None
        try:
            try:
                cp = subprocess.run(args, stdin=source, capture_output=True, timeout=timeout)
                result = {"label": label, "args": args, "at_host_utc": timestamp,
                          "elapsed_s": time.monotonic()-start, "timeout_s": timeout,
                          "timed_out": False, "returncode": cp.returncode,
                          "stdout": decode_output(cp.stdout), "stderr": decode_output(cp.stderr)}
            except subprocess.TimeoutExpired as exc:
                result = {"label": label, "args": args, "at_host_utc": timestamp,
                          "elapsed_s": time.monotonic()-start, "timeout_s": timeout,
                          "timed_out": True, "returncode": None,
                          "stdout": decode_output(exc.stdout), "stderr": decode_output(exc.stderr)}
        finally:
            if source:
                source.close()
        with (self.run_dir / "commands.jsonl").open("a") as log:
            log.write(json.dumps(result, ensure_ascii=False) + "\n")
        return result

    def inner(self, label, args, timeout=60, stdin_path=None):
        return self.command(label, ["docker", "exec"] + (["-i"] if stdin_path else []) +
                            [self.outer, "docker", "--host", "unix:///var/run/docker.sock"] + args,
                            timeout, stdin_path)

    def inspect_outer(self, label, required=True):
        result = self.command(label, ["docker", "inspect", self.outer])
        if result["returncode"] != 0 or result["timed_out"]:
            if required:
                raise ProbeFailure(label + ": outer inspect failed")
            return None
        value = json.loads(require_success(result))[0]
        self.write_json(label + ".json", value)
        return value

    def inspect_inner(self, key, label, required=True, save=True):
        result = self.inner(label, ["inspect", self.names[key]])
        if result["returncode"] != 0 or result["timed_out"]:
            if required:
                raise ProbeFailure(label + ": inner inspect failed")
            return None
        value = json.loads(require_success(result))[0]
        if save:
            self.write_json(label + ".json", value)
        return value

    def inner_epoch(self, label):
        result = self.command(label, ["docker", "exec", self.outer, "date", "+%s"])
        return int(require_success(result).strip())

    def wait_ready(self, seconds=45):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            result = self.inner("inner-ready", ["info", "--format", "{{.ServerVersion}}"], 10)
            if not result["timed_out"] and result["returncode"] == 0:
                return
            time.sleep(1)
        raise ProbeFailure("isolated daemon was not ready")

    def wait_restart(self, key, seconds=35):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            state = self.inspect_inner(key, "poll-" + key, save=False)
            if state["RestartCount"] >= 1 and state["State"]["Running"]:
                return state
            time.sleep(0.5)
        raise ProbeFailure(key + " did not restart within observation window")

    def wait_running(self, key, seconds=35):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            state = self.inspect_inner(key, "poll-" + key, save=False)
            if state["State"]["Running"]:
                return state
            time.sleep(0.5)
        raise ProbeFailure(key + " did not run after daemon restart")

    def expect(self, name, condition):
        self.result["checks"][name] = bool(condition)
        self.write_json("results.json", self.result)
        if not condition:
            raise ProbeFailure("observation failed: " + name)

    def preflight(self):
        self.result["head"] = require_success(self.command("git-head", ["git", "rev-parse", "HEAD"])).strip()
        self.result["branch"] = require_success(self.command("git-branch", ["git", "branch", "--show-current"])).strip()
        self.result["host_version_before"] = self.command("host-version-before", ["docker", "version", "--format", "{{json .}}"])
        require_success(self.result["host_version_before"])
        self.result["host_uname"] = require_success(self.command("host-uname", ["uname", "-a"])).strip()
        images = {}
        for key, image, digest in (("daemon", DAEMON_IMAGE, DAEMON_DIGEST),
                                   ("workload", WORK_IMAGE, WORK_DIGEST)):
            info = json.loads(require_success(self.command("host-image-" + key,
                ["docker", "image", "inspect", image])))[0]
            self.write_json("host-image-" + key + ".json", info)
            self.expect("cached-" + key + "-digest", digest in info["RepoDigests"])
            self.expect("cached-" + key + "-platform", info["Os"] == "linux" and info["Architecture"] == "arm64")
            images[key] = info
        self.result["host_image_digests"] = {key: images[key]["RepoDigests"] for key in images}
        archive = self.run_dir / "busybox-image.tar"
        require_success(self.command("save-workload-image", ["docker", "image", "save", "-o",
                                                         str(archive), WORK_IMAGE], 90))
        self.result["workload_archive_sha256"] = hashlib.sha256(archive.read_bytes()).hexdigest()
        with tarfile.open(archive) as tar:
            manifest = json.load(tar.extractfile("manifest.json"))
            config_bytes = tar.extractfile(manifest[0]["Config"]).read()
        self.expect("archive-config-matches-host", "sha256:" + hashlib.sha256(config_bytes).hexdigest() == images["workload"]["Id"])
        self.result["workload_archive_manifest"] = manifest
        self.result["harness_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        self.write_json("inputs.json", {key: self.result[key] for key in
            ("head", "branch", "host_uname", "host_image_digests", "workload_archive_sha256",
             "workload_archive_manifest", "harness_sha256")})
        return images, archive

    def launch_daemon(self, images, archive):
        absent = self.command("unique-name-absent", ["docker", "inspect", self.outer])
        self.expect("unique-outer-name", not absent["timed_out"] and absent["returncode"] != 0)
        started = self.command("run-private-dind", ["docker", "run", "-d", "--privileged",
            "--name", self.outer, "--label", "omne.m0.restart=" + self.run_id,
            "-e", "DOCKER_TLS_CERTDIR=", "--network", "bridge", DAEMON_IMAGE,
            "--host=unix:///var/run/docker.sock", "--iptables=false", "--bridge=none"], 90)
        require_success(started)
        outer = self.inspect_outer("outer-created")
        self.outer_mounted_volumes = [m["Name"] for m in outer["Mounts"] if m["Type"] == "volume"]
        self.expect("private-dind-no-host-binds", not outer["HostConfig"]["Binds"] and outer["HostConfig"]["Privileged"])
        self.wait_ready()
        self.result["inner_version_before"] = self.inner("inner-version-before", ["version", "--format", "{{json .}}"])
        version = json.loads(require_success(self.result["inner_version_before"]))
        self.expect("inner-engine-29.1.3-linux-arm64", version["Server"]["Version"] == "29.1.3"
                    and version["Server"]["Os"] == "linux" and version["Server"]["Arch"] == "arm64")
        self.result["inner_epoch_initial"] = self.inner_epoch("inner-epoch-initial")
        require_success(self.inner("load-workload", ["load"], 90, archive))
        loaded = json.loads(require_success(self.inner("inner-image-workload", ["image", "inspect", WORK_IMAGE])))[0]
        self.write_json("inner-image-workload.json", loaded)
        self.result["inner_workload_image_id"] = loaded["Id"]
        self.expect("loaded-workload-content", loaded["RootFS"]["Layers"] == images["workload"]["RootFS"]["Layers"]
                    and loaded["Architecture"] == images["workload"]["Architecture"]
                    and loaded["Os"] == images["workload"]["Os"])

    def run_inner_container(self, key, policy, script):
        require_success(self.inner("run-" + key, ["run", "-d", "--pull", "never", "--name", self.names[key],
                     "--network", "none", "--restart", policy, WORK_IMAGE, "sh", "-c", script]))
        state = self.inspect_inner(key, key + "-initial")
        self.expect(key + "-started", state["State"]["Running"] and
                    state["HostConfig"]["RestartPolicy"]["Name"] == policy)
        return state

    def observe_r2(self):
        start_epoch = self.inner_epoch("r2-inner-epoch-before")
        first = self.run_inner_container("crash", "unless-stopped", CRASH_ONCE)
        second = self.wait_restart("crash")
        self.write_json("crash-after-restart.json", second)
        time.sleep(3)
        current_epoch = self.inner_epoch("r2-inner-epoch-after")
        since, until = event_window(start_epoch, current_epoch)
        self.result["r2_event_window"] = {"since_inner_epoch": since, "until_inner_epoch": until,
                                          "current_inner_epoch": current_epoch}
        event_result = self.inner("r2-docker-events", ["events", "--since", since, "--until", until,
            "--filter", "container=" + self.names["crash"], "--format", "{{json .}}"], 20)
        (self.run_dir / "r2-docker-events.raw.txt").write_text(event_result["stdout"])
        events = parse_events(event_result)
        self.write_json("r2-events.json", events)
        log_result = self.inner("r2-container-logs", ["logs", "--timestamps", self.names["crash"]])
        logs = require_success(log_result)
        (self.run_dir / "r2-container-logs.txt").write_text(logs)
        self.result["r2"] = {"first_started_at": first["State"]["StartedAt"],
                             "second_started_at": second["State"]["StartedAt"],
                             "restart_count": second["RestartCount"],
                             "container_id": first["Id"]}
        self.expect("r2-one-restart", second["RestartCount"] == 1 and
                    second["State"]["StartedAt"] != first["State"]["StartedAt"])
        self.expect("r2-daemon-die23-then-start", has_die_then_start(events, first["Id"], 23))
        self.expect("r2-fixture-two-starts", "FIRST" in logs and "FAIL23" in logs and "SECOND" in logs)
        require_success(self.inner("stop-crash-after-r2", ["stop", "--timeout", "3", self.names["crash"]]))
        self.inspect_inner("crash", "crash-manually-stopped")

    def observe_r3(self):
        for key, policy, script in (("running", "unless-stopped", EXIT_ZERO),
                                    ("stop_zero", "unless-stopped", EXIT_ZERO),
                                    ("stop_one", "unless-stopped", EXIT_ONE),
                                    ("on_failure", "on-failure", EXIT_ZERO)):
            self.run_inner_container(key, policy, script)
        time.sleep(11)
        before = {key: self.inspect_inner(key, key + "-before-stop") for key in
                  ("running", "stop_zero", "stop_one", "on_failure")}
        self.expect("r3-all-monitored-running", all(x["State"]["Running"] for x in before.values()))
        for key, code in (("stop_zero", 0), ("stop_one", 1)):
            require_success(self.inner("explicit-stop-" + key,
                ["stop", "--timeout", "3", self.names[key]]))
            stopped = self.inspect_inner(key, key + "-just-stopped")
            self.expect("r3-" + key + "-exit", not stopped["State"]["Running"]
                        and stopped["State"]["ExitCode"] == code)
        time.sleep(12)
        final = {key: self.inspect_inner(key, key + "-after-12s-stop") for key in
                 ("running", "stop_zero", "stop_one", "on_failure")}
        self.expect("r3-exit0-stays-stopped", not final["stop_zero"]["State"]["Running"]
                    and final["stop_zero"]["RestartCount"] == 0)
        self.expect("r3-exit1-stays-stopped", not final["stop_one"]["State"]["Running"]
                    and final["stop_one"]["RestartCount"] == 0)
        self.expect("r3-controls-running", final["running"]["State"]["Running"]
                    and final["on_failure"]["State"]["Running"])
        self.result["pre_restart_states"] = {key: {"running": value["State"]["Running"],
              "exit_code": value["State"]["ExitCode"], "started_at": value["State"]["StartedAt"]}
              for key, value in final.items()}

    def observe_r4_r5(self):
        outer_before = self.inspect_outer("outer-before-daemon-stop")
        self.result["inner_epoch_before_daemon_stop"] = self.inner_epoch("inner-epoch-before-daemon-stop")
        require_success(self.command("stop-private-dind", ["docker", "stop", "--timeout", "45", self.outer], 65))
        outer_stopped = self.inspect_outer("outer-daemon-stopped")
        self.expect("private-daemon-really-stopped", not outer_stopped["State"]["Running"]
                    and outer_stopped["State"]["ExitCode"] == 0)
        require_success(self.command("start-private-dind", ["docker", "start", self.outer], 65))
        self.wait_ready()
        outer_after = self.inspect_outer("outer-daemon-restarted")
        self.expect("private-daemon-new-start", outer_after["State"]["Running"]
                    and outer_after["State"]["StartedAt"] != outer_before["State"]["StartedAt"])
        self.result["inner_version_after"] = self.inner("inner-version-after", ["version", "--format", "{{json .}}"])
        require_success(self.result["inner_version_after"])
        recovered = self.wait_running("running")
        self.write_json("running-recovered.json", recovered)
        time.sleep(12)
        after = {key: self.inspect_inner(key, key + "-after-daemon-restart") for key in
                 ("running", "stop_zero", "stop_one", "on_failure")}
        self.result["inner_epoch_after_daemon_restart"] = self.inner_epoch("inner-epoch-after-daemon-restart")
        self.expect("r4-running-unless-stopped-recovers", after["running"]["State"]["Running"]
                    and after["running"]["State"]["StartedAt"] != self.result["pre_restart_states"]["running"]["started_at"])
        self.expect("r4-explicit-exit0-stays-stopped", not after["stop_zero"]["State"]["Running"])
        self.expect("r4-explicit-exit1-stays-stopped", not after["stop_one"]["State"]["Running"])
        self.expect("r5-on-failure-stays-stopped", not after["on_failure"]["State"]["Running"])
        self.result["post_restart_states"] = {key: {"running": value["State"]["Running"],
              "exit_code": value["State"]["ExitCode"], "started_at": value["State"]["StartedAt"],
              "restart_count": value["RestartCount"]} for key, value in after.items()}
        self.result["inner_ps_after"] = self.inner("inner-ps-after", ["ps", "-a", "--format", "{{json .}}"])
        require_success(self.result["inner_ps_after"])

    def cleanup(self):
        audit = {"inner_removals": {}, "anonymous_volumes": []}
        outer = self.inspect_outer("outer-before-cleanup", required=False)
        if outer and outer.get("Config", {}).get("Labels", {}).get("omne.m0.restart") == self.run_id:
            self.outer_mounted_volumes = [m["Name"] for m in outer["Mounts"] if m["Type"] == "volume"]
            if outer["State"]["Running"]:
                try:
                    self.wait_ready(5)
                    for key, name in self.names.items():
                        audit["inner_removals"][key] = self.inner("cleanup-inner-" + key,
                            ["rm", "-f", name], 20)
                except ProbeFailure as exc:
                    audit["inner_cleanup_error"] = str(exc)
            audit["outer_removal"] = self.command("cleanup-own-dind", ["docker", "rm", "-f", "-v", self.outer], 65)
        elif outer:
            audit["ownership_mismatch"] = True
        absent = self.command("cleanup-outer-absent", ["docker", "inspect", self.outer])
        audit["outer_absent"] = not absent["timed_out"] and absent["returncode"] != 0
        for volume in self.outer_mounted_volumes:
            checked = self.command("cleanup-volume-" + volume[:12], ["docker", "volume", "inspect", volume])
            audit["anonymous_volumes"].append({"name": volume, "absent": not checked["timed_out"]
                                                and checked["returncode"] != 0})
        remaining = self.command("cleanup-prefix-containers", ["docker", "ps", "-a", "--filter",
            "name=" + self.prefix, "--format", "{{json .}}"])
        audit["prefix_containers"] = remaining
        audit["complete"] = (audit["outer_absent"]
                             and all(item["absent"] for item in audit["anonymous_volumes"])
                             and not remaining["timed_out"] and remaining["returncode"] == 0
                             and not remaining["stdout"].strip()
                             and not audit.get("ownership_mismatch"))
        if not audit["complete"]:
            self.result["status"] = "failed"
            self.result["cleanup_error"] = "private Docker resources remain or could not be checked"
        self.result["cleanup"] = audit
        self.result["host_version_after"] = self.command("host-version-after", ["docker", "version", "--format", "{{json .}}"])
        self.write_json("cleanup.json", audit)
        self.write_json("results.json", self.result)

    def execute(self):
        try:
            images, archive = self.preflight()
            self.launch_daemon(images, archive)
            self.observe_r2()
            self.observe_r3()
            self.observe_r4_r5()
            self.result["status"] = "observed"
        except Exception as exc:
            self.result["status"] = "failed"
            self.result["error"] = repr(exc)
        finally:
            self.cleanup()
        return self.result


if __name__ == "__main__":
    if sys.argv[1:] == ["--self-test"]:
        result = self_test()
        (ROOT / "self-test.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result))
    elif not sys.argv[1:]:
        probe = Probe()
        result = probe.execute()
        print(probe.run_dir)
        sys.exit(0 if result["status"] == "observed" else 1)
    else:
        print("usage: probe.py [--self-test]", file=sys.stderr)
        sys.exit(64)
