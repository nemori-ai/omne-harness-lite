Failed to fetch https://developers.openai.com/api/docs/models/gpt-6-astra-pro.md: 404 Not Found
