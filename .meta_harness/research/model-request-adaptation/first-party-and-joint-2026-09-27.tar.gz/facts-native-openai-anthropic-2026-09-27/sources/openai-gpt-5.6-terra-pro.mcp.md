Failed to fetch https://developers.openai.com/api/docs/models/gpt-5.6-terra-pro.md: 404 Not Found
