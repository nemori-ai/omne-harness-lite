Failed to fetch https://developers.openai.com/api/docs/models/gpt-6-sol-pro.md: 404 Not Found
