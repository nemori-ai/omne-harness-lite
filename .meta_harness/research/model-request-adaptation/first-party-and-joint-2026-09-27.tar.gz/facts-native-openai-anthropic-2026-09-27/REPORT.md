# 原生事实核对：OpenAI 与 Anthropic，2026-09-27

16 个目标身份全部保留。六个 OpenAI 基础模型及四个 Anthropic 模型取得精确原生模型页；六个 OpenAI `-pro` 精确页返回 404，官方精确 ID 搜索与原生目录未提供对应页。原生支持、OpenRouter 桥接、实际 provider route 是三个不同命题；本包只提供第一个的官方文档读数。未读取秘密、未发送模型请求、未发生本任务模型费用。本包不是定义接受或支持认证。

HUB：`/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime`，分支 `panqiwei/model-request-runtime`，核对时 HEAD `a6285a7f7a116b49b7436a13ae37aa6267604d40`。输入为本树 `official.ts`、既有 research/model-request-adaptation 观察与 v4-definition-design，旧暖读证据不证明本轮原生参数或 TTL 约束。

## 交付与取得

- [16IDfacts.json](16IDfacts.json)：16 项逐字段读数；八个统一参数各有显式 cell；`vendor_document_claim`、`inference`、`unknown` 分开。
- [source-manifest.json](source-manifest.json)：78 份来源/工具返回，含 URL、取得或保存时间、字节数、SHA-256、方式与 HTTP 失败。
- `sources/*.raw.md` / `*.raw.html`：公共 HTTP 原文响应字节，包括 404；精确取得起止 UTC 在三个批次 manifest 和 thinking manifest 中。
- `sources/*.mcp.md` / `*.tool.json`：OpenAI Docs MCP 搜索后 fetch 与实际 web page extraction 返回。早期 MCP 取得未逐次计时，manifest 明示保存 UTC 不是取得 UTC；采用字段有另行取得且精确计时的 HTTP 原文支持。
- `download_readonly.py`、`download_supplemental.py`、`download_final.py`、`download_thinking.py` 为公共 GET 保全脚本；`assemble_facts.py` 为无网络整理脚本；[validation.json](validation.json) 保存本地一致性核对。脚本不访问凭据或模型 API。

每厂商至少三类一手材料：精确模型页、代际/功能指南、API reference。全为厂商自述，未做独立行为复现。OpenAI 先使用官方 MCP 搜索与 fetch；检索/引用仅使用允许的三个 OpenAI 文档域。Anthropic 仅使用官方 Claude Platform Docs。

## 精确身份与核心字段

| OpenRouter 目标 | 精确原生页/原生 ID | 原生输入 → 输出 | 原生 context / max input / max output |
| --- | --- | --- | --- |
| openai/gpt-6-astra | gpt-6-astra | text,image → text | 1050000 / 922000 / 128000 |
| openai/gpt-6-astra-pro | 精确页 404 | unknown | unknown |
| openai/gpt-6-sol | gpt-6-sol | text,image → text | 1050000 / 922000 / 128000 |
| openai/gpt-6-sol-pro | 精确页 404 | unknown | unknown |
| openai/gpt-6-luna | gpt-6-luna | text,image → text | 1050000 / 922000 / 128000 |
| openai/gpt-6-luna-pro | 精确页 404 | unknown | unknown |
| openai/gpt-5.6-sol | gpt-5.6-sol | text,image → text | 1050000 / 922000 / 128000 |
| openai/gpt-5.6-sol-pro | 精确页 404 | unknown | unknown |
| openai/gpt-5.6-terra | gpt-5.6-terra | text,image → text | 1050000 / 922000 / 128000 |
| openai/gpt-5.6-terra-pro | 精确页 404 | unknown | unknown |
| openai/gpt-5.6-luna | gpt-5.6-luna | text,image → text | 1050000 / 922000 / 128000 |
| openai/gpt-5.6-luna-pro | 精确页 404 | unknown | unknown |
| anthropic/claude-opus-5.5 | claude-opus-5-5 | text,image → text | 原文1M / unknown / 原文128K |
| anthropic/claude-opus-5 | claude-opus-5 | text,image → text | 原文1M / unknown / 原文128K |
| anthropic/claude-sonnet-5 | claude-sonnet-5 | text,image → text | 原文1M / unknown / 原文128K |
| anthropic/claude-fable-5.1 | claude-fable-5-1 | text,image → text | 原文1M / unknown / 原文128K |

来源逐项对应 `openai-<native-id>.raw.md` 与 `anthropic-<generation>.raw.md`。OpenAI 数值是模型页独立字段，未由 context 做减法。Anthropic 的 1M/128K 十进制展开在 JSON 独立标为推论；1M 包含输入、历史、工具及生成输出，不能直接填输入上限。Models API 示例的两个上限均为 0，不采作真实能力。[Anthropic context](https://platform.claude.com/docs/en/build-with-claude/context-windows)、[Models API](https://platform.claude.com/docs/en/api/models/retrieve)。

六个 OpenAI pro 目标未被替换为基础模型。原生指南描述基础模型加 Responses `reasoning.mode=pro`，不是这六个 suffix slug 的身份证明；精确 OpenRouter 映射仍未知。[GPT-5.6 guide](https://developers.openai.com/api/docs/guides/latest-model?model=gpt-5.6)、[reasoning mode](https://developers.openai.com/api/docs/guides/reasoning#reasoning-mode)。

十个有精确页的模型均列出 function/tool 能力与结构化 JSON 能力。OpenAI 的原生 built-in tools 列表是 Responses 的列表，`image_generation` 工具不改变直接模型的输出模态。音视频未在精确模态列表中列出，保留为未宣传/未知，不制造 false。Anthropic Structured Outputs metadata 明列四个 native ID，`output_config.format` 与 `strict` 工具仅支持 Schema 子集；拒绝、截断，以及 citations 同用限制仍成立。[OpenAI Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs)、[Anthropic Structured Outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs)。

`inputConstraints.maxImageBytes` 全部未闭合。OpenAI 文档为请求总 payload 上限 512MB，不能当每图上限；Anthropic Claude API 的 10MB 是 base64-encoded 每图上限，不能直接当 decoded image bytes。图片数量、维度、patch 与多图条件另列，没有写 `inputConstraints: {}`。[OpenAI images](https://developers.openai.com/api/docs/guides/images-vision)、[Anthropic vision](https://platform.claude.com/docs/en/build-with-claude/vision)。

## 八个统一参数

| 字段 | OpenAI 已核基础模型 | Anthropic 四项 |
| --- | --- | --- |
| reasoningEffort | Astra low/medium/high/xhigh/max；其他五项再含 none。xhigh 超出当前 core | native effort 为 low/medium/high/xhigh/max；none → disabled 尚无已采用映射 |
| temperature | GPT-6 条件：effort=none 才可采样，Astra 无 none；generic API 域[0,2]。GPT-5.6 per-model 支持未知 | 仅1.0兼容值，其他值400 |
| topP | GPT-6同上；generic API域[0,1]，core另排除0。GPT-5.6 per-model支持未知 | [0.99,1]兼容，其余400 |
| seed | generic Chat 为废弃 Beta int64，精确模型支持未知；不保证确定性 | 未在当前 API/模型指南发现，未知，不是已验证拒绝 |
| maxOutputTokens | Responses max_output_tokens；Chat max_completion_tokens；包含 reasoning | max_tokens 包含 thinking；原生0可预热，core正数域不含0 |
| stopSequences | generic Chat 最多4，精确模型支持未知 | stop_sequences 被API声明；数量/长度上限未找到 |
| frequencyPenalty | generic Chat[-2,2]，精确模型支持未知；Responses签名未声明 | 当前签名未声明，未知 |
| presencePenalty | 同上 | 当前签名未声明，未知 |

[GPT-6 原文](https://developers.openai.com/api/docs/guides/latest-model)、[精确 OpenAI model pages](https://developers.openai.com/api/docs/models)、[Chat reference](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create)、[Claude Messages reference](https://platform.claude.com/docs/en/api/messages/create)分别支持表中的原生与 generic 范围。未把 generic 字段存在写成每模型支持。

GPT-6 Astra 的 Chat function calling 不支持；Sol/Luna 的 Chat function calling 仅 effort=none，reasoning+tools 要 Responses。GPT-6 非 none 时 temperature/top_p/top_logprobs 不支持，另有 endpoint-specific logprobs 限制。工具可用与 endpoint/effort 联合条件、采样与 effort 联合条件超出 D082 的独立有限参数描述，JSON 明列 gap，没有提出扩展方案。[GPT-6](https://developers.openai.com/api/docs/guides/latest-model)。

Anthropic Opus5.5/Fable5.1 always-on thinking，any/tool 强制 tool_choice 返回400；Opus5/Sonnet5 adaptive 支持 forced tools。Opus5 的 disabled 与 xhigh/max 组合400；Sonnet5可disabled。四项 manual enabled均400。这里的条件是原生条件，未证明桥接如何处置。[thinking support table](https://platform.claude.com/docs/en/build-with-claude/thinking-troubleshooting)、[effort](https://platform.claude.com/docs/en/build-with-claude/effort)。

## 提醒与历史

OpenAI 原生现代 instruction role 为 developer，Chat developer 内容为 text。Anthropic ordinary user/assistant 支持明确；Opus5/5.5/Fable5.1 原生 GA mid-conversation system 无需 beta，Sonnet5 不支持。该原生能力不能认定为 OpenRouter 已支持，也不能改写项目正式提醒映射。[OpenAI prompt roles](https://developers.openai.com/api/docs/guides/prompt-engineering)、[Anthropic mid-conversation system](https://platform.claude.com/docs/en/build-with-claude/mid-conversation-system-messages)。

Opus5.5/Fable5.1 的 thinking block 与既有前缀绑定；注入后删除 per-turn reminder 是官方列出的 invalid-signature 反例之一。新账号 2026-08-31 及之后默认执行该检查。历史、提醒和模型切换的原生约束不能用一次短文本暖读关闭。[thinking failures](https://platform.claude.com/docs/en/build-with-claude/thinking-troubleshooting)。

## 缓存字段、TTL、布局与负面限制

OpenAI GPT5.6+/GPT6 原生默认 implicit，也支持 explicit；仅30m TTL，visible prefix至少1024；每请求最多4 write，implicit占1槽。显式字段为 prompt_cache_breakpoint，top-level instructions与additional_tools没有可用显式断点。read/write usage各为 cached_tokens/cache_write_tokens。30m是最小可复用时间，不保证请求到达持有匹配cache的机器。这里未选择 transport 完整布局，也未证明 OpenRouter TTL 转发。[OpenAI cache](https://developers.openai.com/api/docs/guides/prompt-caching)。

Anthropic 原生自动缓存仍需 top-level cache_control，显式为block标记；type仅ephemeral、TTL5m/1h；Opus5.5/Opus5/Fable5.1 min512，Sonnet5 min1024。断点≤4，长TTL必须在短TTL前，tools→system→messages；thinking不能直接标，空text不能标。自动与显式同末块不同TTL会400；无eligible block可跳过。read/write及5m/1h拆分字段在JSON保全，未观测命中、续期或到期。[Claude cache](https://platform.claude.com/docs/en/build-with-claude/prompt-caching)。

OpenAI新缓存write为1.25×，Anthropic5m/1h write为1.25×/2×；费用不由是否叫自动缓存决定。Anthropic读取率按精确模型页：Opus5.5 $0.20/$4、Fable5.1 $0.25/$10，其比率在JSON明确为算术推论，不照抄族级0.1。完整 system/last_tool/last_message 枚举还要实际存在可附着目标、真实wire及route证据，不能由上述位置类别直接冻结。

## 冲突与证据缺口

JSON保留四个源冲突：
1. OpenAI cache guide 的 first2/latest50 explicit + earlier endings，与API reference的latest80不同。
2. OpenAI generic API/OpenAPI examples 出现Astra none/logprobs或Chat工具；精确reasoning guide明确禁止这些条件。
3. Claude Messages intro旧文说无system input role，同页schema含system，新代际指南按模型允许。
4. Claude Models API示例的上限0、enabled=true，不等于精确代际能力。

不静默择一，不用错误示例充实未知值。Chat reference 的直接 HTTP 与MCP markdown fetch返回404，但实际官方web页面能取得；相应extraction保存在工具返回字节中，来源方式与原始HTTP区别显式记在manifest。

所有16项仍有 native→OpenRouter/provider gap。六个pro原生身份、Anthropic独立输入上限、decoded maxImageBytes、OpenAI若干参数、route TTL、完整布局与无附着目标行为均未闭合。结论截至2026-09-27官方页面；页面更新、模型ID映射变化、不同endpoint或不同provider可使读数失效。本包没有接受、实现、生产认证或形式证明声明。

