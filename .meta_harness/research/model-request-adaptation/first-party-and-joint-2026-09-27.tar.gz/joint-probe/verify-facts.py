from pathlib import Path
from collections import Counter
import json, hashlib, re, datetime
hub=Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime')
tmp=hub/'tmp/model-request-runtime'
base=tmp/'facts-openrouter-2026-09-27'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
integrity=[]
for directory in ['facts-openrouter-2026-09-27','facts-native-openai-anthropic-2026-09-27','facts-native-other-2026-09-27']:
    root=tmp/directory; manifest=root/'source-manifest.json'; data=json.loads(manifest.read_text())
    for item in data['sources']:
        name=next((item.get(k) for k in ['body_path','path','raw_path'] if item.get(k)),None)
        assert name, (directory,item.keys())
        path=root/name; assert path.is_file(),str(path)
        assert sha(path)==item['sha256'],str(path)
        integrity.append({'collection':directory,'path':name,'sha256':sha(path),'bytes':path.stat().st_size,
                          'url':item.get('url'),'status':item.get('status'),'source_kind':item.get('source_kind')})
assert len(integrity)==222,len(integrity)
facts=json.loads((base/'facts.json').read_text())
ids=re.findall(r"'((?:openai|anthropic|deepseek|google|x-ai|qwen|moonshotai|z-ai)/[^']+)'",(hub/'packages/model/pi-ai-transport/src/official.ts').read_text())
assert len(ids)==37 and len(set(ids))==37
assert len(facts['models'])==37 and set(ids)=={m['model_id'] for m in facts['models']}
def at(source):
    doc=json.loads((base/source['body_path']).read_text())
    node=doc
    for part in source['json_pointer'].split('/')[1:]:
        part=part.replace('~1','/').replace('~0','~')
        node=node[int(part)] if isinstance(node,list) else node[part]
    return node
rows=[]
for fact in facts['models']:
    identity=fact['identity_matching']; model=at(identity['exact_model_in_models']['source'])
    ep_source=identity['matched_endpoint_source']; ep=at(ep_source)
    full=json.loads((base/ep_source['body_path']).read_text())['data']
    matches=[e for e in full['endpoints'] if e['tag']==fact['selected_route']]
    assert model['id']==fact['model_id']==full['id']
    assert len(matches)==1 and ep==matches[0]
    limits={k:ep.get(k) for k in ['context_length','max_prompt_tokens','max_completion_tokens']}
    assert limits==fact['token_limits']['selected_endpoint']
    assert model.get('context_length')==fact['token_limits']['aggregate_model_context_length']
    assert model.get('top_provider')==fact['token_limits']['aggregate_top_provider']
    params=fact['parameter_metadata']
    assert ep['supported_parameters']==params['selected_route_supported_parameters']
    union=sorted(set(p for e in full['endpoints'] for p in e['supported_parameters']))
    assert union==params['all_endpoints_union']
    assert (sorted(model['supported_parameters'])==union)==params['empirical_aggregate_equals_endpoint_union']
    assert sorted(set(model['supported_parameters'])-set(ep['supported_parameters']))==params['aggregate_parameters_absent_on_selected_route']
    architecture=full['architecture']
    assert architecture['input_modalities']==fact['model_modality_metadata']['input']
    assert architecture['output_modalities']==fact['model_modality_metadata']['output']
    assert ep.get('supports_tool_choice')==fact['tools_and_format']['tool_choice_test_flags']
    assert model.get('reasoning')==fact['reasoning']['model_level_metadata']
    assert ep.get('supports_implicit_caching')==fact['cache']['endpoint_flag']['value']
    rows.append({'model':fact['model_id'],'route':fact['selected_route'],'provider':ep['provider_name'],
                 'json_pointer':ep_source['json_pointer'],'limits':limits,'input_modalities':architecture['input_modalities'],
                 'output_modalities':architecture['output_modalities'],'supported_parameters':ep['supported_parameters'],
                 'tool_choice_metadata':ep.get('supports_tool_choice'),'reasoning_model_metadata':model.get('reasoning'),
                 'implicit_cache_metadata':ep.get('supports_implicit_caching')})
counts=Counter(m for r in rows for m in r['input_modalities'])
result={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exact_target_count':37,
        'selected_route_matches':37,'model_input_metadata_counts':dict(counts),
        'numeric_max_prompt_tokens':sum(isinstance(r['limits']['max_prompt_tokens'],int) for r in rows),
        'null_max_prompt_tokens':sum(r['limits']['max_prompt_tokens'] is None for r in rows),
        'verified_raw_artifacts':len(integrity),'identity_source_sha256':sha(hub/'packages/model/pi-ai-transport/src/official.ts'),
        'facts_source_sha256':sha(base/'facts.json'),'claims_scope':'Root recomputed catalogue JSON fields and raw artifact hashes. Metadata is not wire behavior; raw integrity does not validate native report claims.',
        'native_report_status':'Only explicitly named passages read by root are adopted as source observations. Other agent report claims remain merely relayed, original unreviewed.',
        'rows':rows,'integrity':integrity}
(tmp/'joint-probe-2026-09-27/facts-root-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['rows','integrity']},ensure_ascii=False,indent=2))

