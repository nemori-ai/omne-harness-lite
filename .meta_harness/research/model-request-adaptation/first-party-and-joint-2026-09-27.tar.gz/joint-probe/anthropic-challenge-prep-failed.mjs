import { request, Agent } from 'node:https'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createHash, randomUUID } from 'node:crypto'
import { estimateReservation, openLedger } from '../../../tools/model-probe/src/budget.mjs'
import { getPublic, readCredential, parseFacts } from '../../../tools/model-probe/src/network.mjs'
import { models } from '../../../tools/model-probe/src/models.mjs'

const here = dirname(fileURLToPath(import.meta.url))
const targets = [
  ['openai/gpt-6-luna', 'openai'],
  ['openai/gpt-6-sol', 'openai'],
  ['openai/gpt-6-astra', 'openai'],
  ['anthropic/claude-opus-5.5', 'anthropic'],
  ['anthropic/claude-fable-5.1', 'anthropic'],
]
const settings = { timeoutMs: 60000, maxResponseBytes: 4000000 }
const budget = { limitUsd: '100', researchLimitUsd: '50' }
const hash = value => createHash('sha256').update(value).digest('hex')
async function save(name, value) {
  await writeFile(join(here, name), typeof value === 'string' ? value : JSON.stringify(value, null, 2) + '\n', {mode: 0o600, flag: 'wx'})
}
await mkdir(here, {recursive: true, mode: 0o700})
const phase = process.argv[2]
if (phase === 'prepare') {
  const selected = []
  for (const [model, tag] of targets) {
    if (!models.some(m => m.id === model)) throw new Error('Target outside confirmed scope')
    const got = await getPublic('/api/v1/models/' + model + '/endpoints')
    const parsed = JSON.parse(got.raw)
    if (parsed.data.id !== model) throw new Error('Endpoint response identity mismatch')
    const matches = parsed.data.endpoints.filter(e => e.tag === tag)
    if (matches.length !== 1) throw new Error('Exact selected route not unique')
    const file = 'endpoint-' + selected.length + '.json'
    await save(file, got.raw)
    selected.push({model, tag, observedAt: got.observedAt, url: 'https://openrouter.ai/api/v1/models/' + model + '/endpoints', path: file, sha256: hash(got.raw), endpoint: matches[0]})
  }
  await save('selected.json', {selected, format: 1, paidCalls: 0})
  console.log(JSON.stringify({phase, sources: selected.length, paidCalls: 0, selected: selected.map(s => ({model: s.model, tag: s.tag, provider: s.endpoint.provider_name}))}))
  process.exit(0)
}
if (!['anthropic-challenge'].includes(phase)) throw new Error('Explicit prepare/anthropic-challenge phase required')
const credentialFile = process.argv[3]
if (!credentialFile) throw new Error('Explicit credential file required')
const selected = JSON.parse(await readFile(join(here, 'selected.json'), 'utf8')).selected
for (const source of selected) {
  if (hash(await readFile(join(here, source.path))) !== source.sha256) throw new Error('Frozen endpoint source drift')
}
const credential = await readCredential(credentialFile)
const ledger = await openLedger(join(here, '..', 'ledger.json'), budget)
const entriesBefore = ledger.snapshot().entries.length
const nonce = randomUUID()
const results = []
// These are research measurement bounds. No production policy or adapter defaults.
async function requestOnce(body) {
  if (!models.some(m => m.id === body.model) || body.stream !== false || body.provider.order.length !== 1 ||
      body.provider.allow_fallbacks !== false || body.provider.require_parameters !== true) throw new Error('Research routing gate')
  if (['user','session_id','prompt_cache_key','models','route','plugins'].some(k => Object.hasOwn(body,k))) throw new Error('Forbidden identity or routing field')
  const agent = new Agent({keepAlive: false})
  const serialized = JSON.stringify(body)
  try {
    return await new Promise((resolve, reject) => {
      const req = request('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST', agent, headers: {Authorization: 'Bearer ' + credential, 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(serialized)}
      }, res => {
        const chunks = []; let bytes = 0
        res.on('data', chunk => { bytes += chunk.length; if(bytes > settings.maxResponseBytes) req.destroy(new Error('Bound exceeded')); else chunks.push(chunk) })
        res.on('error', () => reject(new Error('Response failed: reconcile cost')))
        res.on('end', () => resolve({status: res.statusCode, raw: Buffer.concat(chunks).toString('utf8'), bytes}))
      })
      const timer = setTimeout(() => req.destroy(new Error('Timed out: reconcile cost')), settings.timeoutMs)
      req.on('close', () => clearTimeout(timer))
      req.on('error', () => reject(new Error('Connection failed: reconcile cost')))
      req.end(serialized)
    })
  } finally { agent.destroy() }
}
const tool = {type:'function',function:{name:'probe_echo',description:'Record the calculated checksum as a decimal string.',strict:true,parameters:{type:'object',properties:{value:{type:'string',pattern:'^[0-9]+},required:['value'],additionalProperties:false}}}
function bodyFor(model, messages, effort, choice) {
  const source = selected.find(s => s.model === model)
  if (!source || !['tools','tool_choice','reasoning','max_tokens'].every(p => source.endpoint.supported_parameters.includes(p))) throw new Error('Missing advertised research parameters')
  return {model,provider:{order:[source.tag],allow_fallbacks:false,require_parameters:true},stream:false,max_tokens:2048,reasoning:{effort},tools:[tool],tool_choice:choice,messages}
}
async function send(label, body) {
  const source = selected.find(s => s.model === body.model)
  const estimateUsd = estimateReservation(source.endpoint.pricing, Buffer.byteLength(JSON.stringify(body)), body.max_tokens)
  const reservation = await ledger.reserve({model:body.model,provider:source.tag,stage:'research',estimateUsd})
  await save(label + '-intent.json', {label,reservation,request:body,estimateUsd,observedAt:new Date().toISOString()})
  let response
  try { response = await requestOnce(body) } catch(error) {
    await save(label + '-failure.json', {label,reservation,error:error.message,observedAt:new Date().toISOString()})
    throw error
  }
  if (response.raw.includes(credential)) throw new Error('Credential in response: refusing persistence')
  let data
  try { data = parseFacts(response.raw) } catch {}
  const message = data?.choices?.[0]?.message
  const finish = data?.choices?.[0]?.finish_reason
  const summary = {label,reservation,model:body.model,providerRequested:source.tag,providerObserved:data?.provider,
    httpStatus:response.status,finish,reasoningTokens:data?.usage?.completion_tokens_details?.reasoning_tokens ?? 'unknown',
    reasoningDetailTypes:message?.reasoning_details?.map(r=>r.type) ?? [], toolCalls:message?.tool_calls?.map(t=>({name:t.function?.name,arguments:t.function?.arguments})) ?? [],
    content:typeof message?.content==='string' ? message.content : null,
    errorCode:data?.error?.code,errorMessage:data?.error?.message,actualUsd:data?.usage?.cost ?? 'unknown'}
  await save(label + '-response.json', {summary,request:body,response,observedAt:new Date().toISOString()})
  results.push(summary)
  await ledger.settle(reservation, data?.usage?.cost)
  console.log(JSON.stringify(summary))
  return {data,body,summary,message}
}
function validToolCall(result) {
  const calls = result.message?.tool_calls
  if (result.summary.httpStatus !== 200 || result.summary.providerObserved !== selected.find(s=>s.model===result.body.model).endpoint.provider_name ||
      result.summary.finish !== 'tool_calls' || calls?.length !== 1 || calls[0].function?.name !== 'probe_echo') return false
  try {return /^[0-9]+$/.test(JSON.parse(calls[0].function.arguments).value)} catch {return false}
}
let failed
try {
  if (phase === 'openai') {
    for (const [label, model, effort] of [
      ['luna-none','openai/gpt-6-luna','none'],['luna-low','openai/gpt-6-luna','low'],
      ['sol-low','openai/gpt-6-sol','low'],['astra-low','openai/gpt-6-astra','low']
    ]) {
      const result = await send(label, bodyFor(model, [
        {role:'system',content:'This is a synthetic tool protocol experiment. Execute only the declared synthetic tool.'},
        {role:'developer',content:'System reminder for this request ' + nonce + ': call probe_echo with value ALPHA exactly once.'},
        {role:'user',content:'Call the declared tool now.'}
      ], effort, 'required'))
      result.summary.actualRequiredToolObserved = validToolCall(result)
      await save(label + '-oracle.json', {actualRequiredToolObserved: result.summary.actualRequiredToolObserved, reasoningRequested:effort, reasoningTokenObserved:typeof result.summary.reasoningTokens==='number' && result.summary.reasoningTokens>0,
        limits:'Finite nonstream Chat request; does not expose native wire, prove exact effort strength, or certify production SSE/runtime.'})
    }
  } else {
    for (const [slug, model] of [['opus55-challenge','anthropic/claude-opus-5.5'],['fable51-challenge','anthropic/claude-fable-5.1']]) {
      const history = [
        {role:'system',content:'Synthetic arithmetic and tool protocol experiment. Calculate the checksum yourself, then call probe_echo exactly once with its decimal value. After its result, answer ALPHA only and do not call a tool again.'},
        {role:'user',content:'System reminder for the first request ' + nonce + ': obey the declared tool protocol.'},
        {role:'user',content:'Start with x=17. For each integer k from 1 through 12 in order, replace x by (37*x + k*k + 11) modulo 1000003. Compute the final x and call probe_echo with that decimal value. Do not use an external tool for the arithmetic; the declared tool only records the answer.'}
      ]
      const seed = await send(slug + '-seed', bodyFor(model, history, 'high', 'auto'))
      if (!validToolCall(seed) || !seed.message.reasoning_details?.length) {
        await save(slug + '-oracle.json', {outcome:'Unable to verify reminder replay', reason:'Seed lacks verified tool call or reasoning_details'})
        continue
      }
      // Keep every returned assistant field byte-for-byte at the JSON value level.
      const assistant = structuredClone(seed.message)
      const tail = [{role:'tool',tool_call_id:assistant.tool_calls[0].id,content:assistant.tool_calls[0].function.arguments},
        {role:'user',content:'Current request reminder ' + nonce + ': the tool has finished; reply ALPHA only.'}]
      const retained = bodyFor(model,[...history,assistant,...tail],'high','auto')
      const removed = bodyFor(model,[history[0],history[2],assistant,...tail],'high','auto')
      if(JSON.stringify(retained.messages[3])!==JSON.stringify(removed.messages[2])) throw new Error('Opaque assistant replay changed')
      const control = await send(slug + '-retained', retained)
      if(control.summary.httpStatus!==200) {
        await save(slug + '-oracle.json',{outcome:'Unable to verify reminder removal',reason:'Retained-history control rejected',summary:control.summary})
        continue
      }
      const changed = await send(slug + '-removed', removed)
      await save(slug + '-oracle.json',{outcome:'Observed',seed:seed.summary,control:control.summary,removed:changed.summary,
        assistantJsonSha256:hash(JSON.stringify(assistant)),onlyHistoryDifference:'removed exactly the first-request user reminder; the assistant object, tools, effort, output cap and current tail are identical',
        limits:'Finite nonstream OpenRouter Chat requests for synthetic history; no native-wire access or universal claim; protocol error only after a successful retained-history control.'})
    }
  }
} catch(error) {failed = error.message; process.exitCode=1}
finally {
  const state = ledger.snapshot()
  await save(phase+'-summary.json',{phase,nonce,results,failed,entriesBefore,entriesAfter:state.entries.length,unsettled:state.entries.filter(e=>e.state!=='settled').length,completedAt:new Date().toISOString(),settings,scope:'Research only; no accepted adapter policy, official definition, production certification or runtime test.'})
  await ledger.close()
}
}},required:['value'],additionalProperties:false}}}
function bodyFor(model, messages, effort, choice) {
  const source = selected.find(s => s.model === model)
  if (!source || !['tools','tool_choice','reasoning','max_tokens'].every(p => source.endpoint.supported_parameters.includes(p))) throw new Error('Missing advertised research parameters')
  return {model,provider:{order:[source.tag],allow_fallbacks:false,require_parameters:true},stream:false,max_tokens:2048,reasoning:{effort},tools:[tool],tool_choice:choice,messages}
}
async function send(label, body) {
  const source = selected.find(s => s.model === body.model)
  const estimateUsd = estimateReservation(source.endpoint.pricing, Buffer.byteLength(JSON.stringify(body)), body.max_tokens)
  const reservation = await ledger.reserve({model:body.model,provider:source.tag,stage:'research',estimateUsd})
  await save(label + '-intent.json', {label,reservation,request:body,estimateUsd,observedAt:new Date().toISOString()})
  let response
  try { response = await requestOnce(body) } catch(error) {
    await save(label + '-failure.json', {label,reservation,error:error.message,observedAt:new Date().toISOString()})
    throw error
  }
  if (response.raw.includes(credential)) throw new Error('Credential in response: refusing persistence')
  let data
  try { data = parseFacts(response.raw) } catch {}
  const message = data?.choices?.[0]?.message
  const finish = data?.choices?.[0]?.finish_reason
  const summary = {label,reservation,model:body.model,providerRequested:source.tag,providerObserved:data?.provider,
    httpStatus:response.status,finish,reasoningTokens:data?.usage?.completion_tokens_details?.reasoning_tokens ?? 'unknown',
    reasoningDetailTypes:message?.reasoning_details?.map(r=>r.type) ?? [], toolCalls:message?.tool_calls?.map(t=>({name:t.function?.name,arguments:t.function?.arguments})) ?? [],
    content:typeof message?.content==='string' ? message.content : null,
    errorCode:data?.error?.code,errorMessage:data?.error?.message,actualUsd:data?.usage?.cost ?? 'unknown'}
  await save(label + '-response.json', {summary,request:body,response,observedAt:new Date().toISOString()})
  results.push(summary)
  await ledger.settle(reservation, data?.usage?.cost)
  console.log(JSON.stringify(summary))
  return {data,body,summary,message}
}
function validToolCall(result) {
  const calls = result.message?.tool_calls
  if (result.summary.httpStatus !== 200 || result.summary.providerObserved !== selected.find(s=>s.model===result.body.model).endpoint.provider_name ||
      result.summary.finish !== 'tool_calls' || calls?.length !== 1 || calls[0].function?.name !== 'probe_echo') return false
  try {return JSON.parse(calls[0].function.arguments).value === 'ALPHA'} catch {return false}
}
let failed
try {
  if (phase === 'openai') {
    for (const [label, model, effort] of [
      ['luna-none','openai/gpt-6-luna','none'],['luna-low','openai/gpt-6-luna','low'],
      ['sol-low','openai/gpt-6-sol','low'],['astra-low','openai/gpt-6-astra','low']
    ]) {
      const result = await send(label, bodyFor(model, [
        {role:'system',content:'This is a synthetic tool protocol experiment. Execute only the declared synthetic tool.'},
        {role:'developer',content:'System reminder for this request ' + nonce + ': call probe_echo with value ALPHA exactly once.'},
        {role:'user',content:'Call the declared tool now.'}
      ], effort, 'required'))
      result.summary.actualRequiredToolObserved = validToolCall(result)
      await save(label + '-oracle.json', {actualRequiredToolObserved: result.summary.actualRequiredToolObserved, reasoningRequested:effort, reasoningTokenObserved:typeof result.summary.reasoningTokens==='number' && result.summary.reasoningTokens>0,
        limits:'Finite nonstream Chat request; does not expose native wire, prove exact effort strength, or certify production SSE/runtime.'})
    }
  } else {
    for (const [slug, model] of [['opus55','anthropic/claude-opus-5.5'],['fable51','anthropic/claude-fable-5.1']]) {
      const history = [
        {role:'system',content:'Synthetic tool protocol experiment. First call probe_echo exactly once with value ALPHA. After its result, answer ALPHA only and do not call a tool again.'},
        {role:'user',content:'System reminder for the first request ' + nonce + ': obey the declared tool protocol.'},
        {role:'user',content:'Call probe_echo with value ALPHA now.'}
      ]
      const seed = await send(slug + '-seed', bodyFor(model, history, 'low', 'auto'))
      if (!validToolCall(seed) || !seed.message.reasoning_details?.length) {
        await save(slug + '-oracle.json', {outcome:'Unable to verify reminder replay', reason:'Seed lacks verified tool call or reasoning_details'})
        continue
      }
      // Keep every returned assistant field byte-for-byte at the JSON value level.
      const assistant = structuredClone(seed.message)
      const tail = [{role:'tool',tool_call_id:assistant.tool_calls[0].id,content:'{"value":"ALPHA"}'},
        {role:'user',content:'Current request reminder ' + nonce + ': the tool has finished; reply ALPHA only.'}]
      const retained = bodyFor(model,[...history,assistant,...tail],'low','auto')
      const removed = bodyFor(model,[history[0],history[2],assistant,...tail],'low','auto')
      if(JSON.stringify(retained.messages[3])!==JSON.stringify(removed.messages[2])) throw new Error('Opaque assistant replay changed')
      const control = await send(slug + '-retained', retained)
      if(control.summary.httpStatus!==200) {
        await save(slug + '-oracle.json',{outcome:'Unable to verify reminder removal',reason:'Retained-history control rejected',summary:control.summary})
        continue
      }
      const changed = await send(slug + '-removed', removed)
      await save(slug + '-oracle.json',{outcome:'Observed',seed:seed.summary,control:control.summary,removed:changed.summary,
        assistantJsonSha256:hash(JSON.stringify(assistant)),onlyHistoryDifference:'removed exactly the first-request user reminder; the assistant object, tools, effort, output cap and current tail are identical',
        limits:'Finite nonstream OpenRouter Chat requests for synthetic history; no native-wire access or universal claim; protocol error only after a successful retained-history control.'})
    }
  }
} catch(error) {failed = error.message; process.exitCode=1}
finally {
  const state = ledger.snapshot()
  await save(phase+'-summary.json',{phase,nonce,results,failed,entriesBefore,entriesAfter:state.entries.length,unsettled:state.entries.filter(e=>e.state!=='settled').length,completedAt:new Date().toISOString(),settings,scope:'Research only; no accepted adapter policy, official definition, production certification or runtime test.'})
  await ledger.close()
}

