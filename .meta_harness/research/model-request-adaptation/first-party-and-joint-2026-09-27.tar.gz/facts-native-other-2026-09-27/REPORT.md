# 六家原生公开事实：21 个精确模型

本轮取得了六家的一手公开资料，并为 `official.ts` 中分配的 21 个精确 ID 逐项记录事实、条件及未知。**这不是完整 official 定义，也不是路由支持、认证或接受结论。** 原生接口事实不能证明 DeepInfra、OpenRouter 转发、量化实例或 Alibaba Prime 的行为。没有调用推理接口，没有读取凭据或 `.env`，没有付费请求。

- [逐 ID 事实](21IDfacts.json)：21 个 ID，每项都有四种输入/输出模态、工具/选择/结构输出/推理、上限、八个统一参数、特殊提醒类型、缓存与限制。`unknown` 明确不代表 false、空限制或无限制。
- [取得清单](source-manifest.json)：每次 GET 的 URL、UTC、状态、最终 URL、原始字节数、SHA-256、请求方法与保存路径。
- `sources/*.raw` 是实际取得的字节；`sources/*.txt` 是便于核读的派生文本，不能拿其哈希替代原文字节哈希。JSON 的 `sources` 指向原文 ID，并提供派生文本中的定位行。
- `official.ts.snapshot` 与清单内 SHA-256 保留目标名单坐标；取得脚本、五批 URL 列表及事实生成器都在本目录，可重跑。重跑会取得新状态，不能声称复现旧字节。

所有行为结论均为**厂商/作者自述**。本轮没有独立运行观测。README 中的外部 benchmark 提及也没有升级为独立证据。

## 精确身份和可核读入口

| 固定 ID | 原生一手依据 | 保留的边界 |
|---|---|---|
| `deepseek/deepseek-v4.1-flash` | `deepseek-pricing` 的版本为 DeepSeek-V4.1-Flash，调用名 deepseek-flash | 项目选定 `deepinfra/fp8`，不是此原生 API |
| `deepseek/deepseek-v4-pro-0813` | 同表明确 DeepSeek-V4-Pro-0813，调用名 deepseek-v4-pro | 不将别名的后续变化或 DeepInfra 实例当作版本证明 |
| `google/gemini-3.8-flash` | `google-gemini38` 精确 model code | 原生 Gemini API；未取得转发内部消息 |
| `google/gemini-3.7-flash` | `google-gemini37` 精确 model code | 同上 |
| `x-ai/grok-4.7` | `xai-grok47` 精确 model name | 原生 xAI API 文档 |
| `x-ai/grok-4.6` | `xai-grok46` 精确 model name | 原生 xAI API 文档 |
| `qwen/qwen3.8-max-0902` | `alibaba-pricing-cn` 精确 ID，缓存与 API 文档另有精确条目 | 不用 qwen3.8-max 替换快照 |
| `qwen/qwen3.8-max-prime` | `alibaba-pricing-cn` 精确 ID | Prime 在若干支持列表没有精确条目，不能继承为肯定或否定 |
| `qwen/qwen3.8-2.4t-a95b` | 同表精确 ID；`qwen38-readme` 明确开放模型 | 模型权重能力与 Model Studio 服务行为分开 |
| `qwen/qwen3.8-27b` | 同表精确 ID；同官方仓库明确开放模型 | 同上 |
| `qwen/qwen3.7-max` | `alibaba-pricing-cn` 精确 ID | 文档提到当前指向快照，未改任务 ID |
| `qwen/qwen3.7-plus` | 同表、`alibaba-text-models`、`alibaba-cache` | 原生 Alibaba，不等同 OpenRouter |
| `qwen/qwen3.8-flash` | 同表、精确缓存/接口条目 | 原生提供隐式和显式两种模式，不改变项目现有观察模式 |
| `qwen/qwen3.7-flash` | 同表、精确缓存/接口条目 | 同上 |
| `moonshotai/kimi-k3` | `moonshot-models`、`moonshot-docs` 精确 ID | 未证明项目 `moonshotai/mxfp4` 实例 |
| `moonshotai/kimi-k2.7-code` | `moonshot-models`、`moonshot-k27`、`moonshot-parameters` | 未证明项目 `moonshotai/int4` 实例 |
| `z-ai/glm-5.3` | `zai-glm53`、`zai-chat` | 原生 Z.ai，不等同 z-ai/fp8 |
| `z-ai/glm-5.3-flash` | `zai-flash` 明确 Model Code | 精确页面声明文本参数与 GLM-5.3 一致 |
| `z-ai/glm-5.3-flashx` | 同页明确 glm-5.3-flashx | 不从名称近似推断；采用明确共同声明的范围 |
| `z-ai/glm-5.2` | `zai-glm52`、`zai-chat` | repo 与 API 的 effort 回落说法不同，保留冲突 |
| `z-ai/glm-5.3-prime` | `alibaba-prime-mode` 精确 ID，列北京和新加坡 | Alibaba 原生服务；不继承 Z.ai 原生声明 |

## 会影响参数表达的原生约束

1. **DeepSeek**：`deepseek-chat` 明确 temperature 只在非 thinking 生效；top_p 只在 thinking 生效，低于 0.95 按 0.95，非 thinking 固定 1 并忽略传入。thinking 与 `tool_choice=required/named` 组合返回 400。frequency/presence penalty 已弃用且不生效。input + generated tokens 共享窗口。其独立逐项数值域不足以表达模式条件。[原生接口](https://api-docs.deepseek.com/api/create-chat-completion)
2. **Gemini**：两个精确卡片都是 text/image/audio/video 输入、text 输出，单独输入上限 1,048,576、输出上限 65,536，thinking 为 low/medium/high，minimal 返回错误。`google-latest-final` 与 changelog 将 temperature/top_p/top_k 标为 deprecated，迁移文字要求移除；通用 GenerateContent reference 仍列字段，并明确不是每个模型都能配置每个参数。因此未把通用接口域冻结成精确模型的支持规则。[3.8 卡片](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash)、[3.7 卡片](https://ai.google.dev/gemini-api/docs/models/gemini-3.7-flash)、[当前模型指南](https://ai.google.dev/gemini-api/docs/latest-model)
3. **Grok**：4.7/4.6 始终推理，effort 为 low/medium/high/xhigh；presence/frequency penalty 与 stop 会报错。原生 Chat 的 max_completion_tokens 仅计可见输出，不计 reasoning/function-call；默认 128,000 不代表最大输出。release notes 声明没有 text output limit，因此未造一个有限整数上限。xhigh 到本项目 max 的对应关系未知。[推理限制](https://docs.x.ai/developers/model-capabilities/text/reasoning)、[Chat reference](https://docs.x.ai/developers/rest-api-reference/inference/chat-completions)
4. **Qwen/Alibaba**：temperature 为 `[0,2)`，top_p 为 `(0,1]`，包含开端点；stop 的数组不能混 token IDs 与字符串。max_tokens 通常只计回答，max_completion_tokens 计回答和思维链。严格 JSON Schema 在多模态输入上回落 JSON Object，schema 约束不生效；文档另写 Singapore region 尚不支持。开放 Qwen3.8 模型仅在 JSON Object 列表出现，不能从 JSON Schema 列表缺席填 false。[原生参数](https://www.alibabacloud.com/help/en/model-studio/qwen-api-via-openai-chat-completions)、[结构输出范围](https://www.alibabacloud.com/help/en/model-studio/qwen-structured-output)
5. **Kimi**：K3 与 K2.7 Code 均固定 temperature=1、top_p=0.95、两个 penalty=0，其他值报错。K3 effort 为 low/high/max；K2.7 Code 不支持 reasoning_effort，thinking 始终开启且 preserved thinking 始终生效，只接受指定启用形状。K2.7 Code 不支持 required tool choice。stop 最多五串且每串 ≤32 字节；这是数值/枚举之外的串内容限制。input + max_completion_tokens 超窗口报错；K3 的精确输出参数最大值为 1,048,576，不等于可在任意输入量下获得同样输出。[参数比较](https://platform.kimi.ai/docs/api/models-overview.md)、[Chat API](https://platform.kimi.ai/docs/api/chat.md)
6. **Z.ai**：GLM5.3/Flash/FlashX 只允许 thinking enabled；5.2 行为不同。do_sample=false 会使 temperature/top_p 不生效。stop 正文只允许一串，schema 却 maxItems=4；5.2 effort 的 API 兼容映射与权重 repo 的其他值回落 max 说法也不同。temperature 正文称 positive，但 Schema 明确允许 0。这些均以冲突字段记录。[Chat API](https://docs.z.ai/api-reference/llm/chat-completion)、[官方 repo](https://github.com/zai-org/GLM-5)

上述条件是公开事实和映射缺口；没有替项目选择 pass、drop、adjust、默认值或兼容方案。

## 缓存、代价和未决范围

| 原生服务 | 已取得的事实 | 不能由此推得 |
|---|---|---|
| DeepSeek | 自动 prefix-unit 缓存；best effort；建缓存数秒、闲置通常数小时至数日清理；usage 的 hit/miss/cached 字段 | DeepInfra fp8 的 TTL、最小前缀、手动断点或任何保证 |
| Gemini | 两个 Flash 的隐式缓存最小输入 4,096 token；Interactions 仅隐式；GenerateContent 显式例子为精确3.8，使用独立 cache object，TTL默认1小时、例子300s/600s/7200s、文档称无TTL上下界；存储时长收费 | OpenRouter断点布局、5m/1h的wire枚举、确定命中；3.7的精确显式cache object支持仍未核实 |
| xAI | 自动精确消息前缀缓存，包括工具结果；可能因压力、重启或服务器路由而丢缓存；Chat/Responses cached_tokens 字段不同；≥200k prompt 全请求高阶价格 | 保证 TTL、精确最小前缀、显式 cache_control |
| Alibaba Qwen | 非 Prime 七个精确 ID 有显式/隐式条目；两者互斥；最小 1,024；显式五分钟，hit 续期；通常写入125%原输入价；最多四个 message-content 标记、20-block lookback；不能把控制直接放 tools | 原生五分钟等于 wire 接受 ttl=5m；任何1h；项目 system/last_tool/last_message 任意布局组合；Prime 被缺席证明不支持 |
| Moonshot K3 | Chat/Responses 自动写 5m，可设 top-level implicit 5m/1h；两层独立不共享，写价不同、命中续期；Messages 要用顶层 cache_control 写入；前次 prompt 必须 >256；完整 streaming usage 最后一块返回 | 转发量化路由采用这些控制，或项目断点布局可用；缓存页面 K2.7 缩写不能未经核对映射成精确 code 的写入保证 |
| Z.ai | 自动隐式缓存，usage.prompt_tokens_details.cached_tokens；公开页面没有精确 TTL、最小前缀、布局 | 四个 z-ai/fp8 的精确 TTL/命中保证或 Alibaba Prime 行为 |
| Alibaba GLM Prime | 精确 Prime ID 有缓存命中价格 | 有价格不证明显式控制、TTL、断点或 warm-read 必然发生 |

没有发现专用 reminder-message type 的精确声明。资料中的 system/user/model/developer 等普通角色，或成功短答复，都不能证明提醒优先级；每个模型这一格保持 unknown。

除 Gemini 明确分开的输入上限外，总 context 未被直接写成 maxInputTokens。图片字节上限未核实，所有模型都保留 maxImageBytes unknown，未输出空 inputConstraints。Qwen 多数最大输出数字、Prime 完整参数域、跨路由缓存对应以及普通消息以外的提醒语义仍未闭合。

## 取得限制及失败保全

若干猜测的文档/仓库 URL 实际返回 404，全部保留；Alibaba `/prime` 为 HTTP200 的厂商404页，也有单独内容说明。正确 `/prime-mode` 随后取得并核明精确 ID。xAI llms.txt 例举 `.md` 路径在本环境返回404，不带 `.md` 的同页成功取得 Markdown；两次均保全。Moonshot 文档有 platform.moonshot.ai → platform.kimi.ai 的迁移，最终 URL 在清单。

九份 Alibaba console model-card GET 返回 JavaScript shell，页面内没有模型详情。搜索引擎能显示渲染后的 Prime 详情，但它不是本轮抓到的原文字节，未把摘要填成事实。若干官方仓库 README 返回404，仅说明这个 URL 的失败，不能据此宣称对应模型不存在。

负面与代价检索覆盖精确卡片、API schema、缓存说明、thinking/migration、结构输出支持表、官方仓库说明；发现的条件与退化均写入 JSON。独立 issue/probe 未在本限定来源域执行，也没有将厂商比较图当独立验证。
