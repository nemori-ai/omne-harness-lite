# OpenRouter 公开事实复核 — 2026-09-27

这批公开资料闭合了固定 **37/37 精确模型身份、37/37 所选 tag 身份、模型模态声明、逐 endpoint 参数名与输出上限**；它没有闭合 37 份完整正式定义。共有 64 次无凭据 GET，全部 HTTP 200。没有读取 `.env`，没有模型 POST，没有新增付费调用或 wire 认证。取得时间、URL、响应状态/headers、原文 bytes/SHA-256 与命令见 [source-manifest.json](source-manifest.json)。逐模型、逐字段及原文定位见 [facts.json](facts.json)。这是研究读数，不是 official 支持、生产认证或接受记录。

固定范围来自 HUB `a6285a7f7a116b49b7436a13ae37aa6267604d40` 的 [输入快照](inputs/official.ts)，保留了原 37 IDs 与选择 routes，没有替换相近型号或更新 ID。八家计数仍为 12/4/2/2/2/8/2/5。

## 已取得的事实

- `/api/v1/models` 有 458 项，固定 37 项全部精确存在；37 个 `/models/{原ID}/endpoints` 均成功，按 `model_id` 与 `tag` 找到唯一所选条目。
- 所选 route 全部报告 `tools`、`tool_choice`、`response_format`；只有 30 条报告 `structured_outputs`。没有报告不是 `false`；JSON object 支持不能填成 JSON Schema/strict 支持。`supports_tool_choice` 为按值通过测试的厂商标志，与只有参数名的支持声明不同。原 false 标志保留，但本任务没有执行反例或工具测试。[参数协议](https://openrouter.ai/docs/api_reference/parameters)、[endpoint schema](https://openrouter.ai/docs/api/api-reference/endpoints/list-all-endpoints-for-a-model)
- 模型 architecture 声明输入 text 37、image 31、video 10、audio 2，输出全部 text。额外 `file` 标志出现 20 项，原样保留，不塞成 core 的第五种模态。architecture 是模型层声明，没有每 endpoint 的模态执行证明。
- 独立 `max_prompt_tokens` 只在 **18** 条所选 endpoint 给出数值，其余 **19** 条为 null。37 条都有 `context_length` 与 `max_completion_tokens`。两者共享输入/输出窗口，实际请求输出还受输入占用限制；不把共享窗口直接写成固定输入上限，不发明固定减法。[endpoint schema](https://openrouter.ai/docs/api/api-reference/endpoints/list-all-endpoints-for-a-model)
- 这个快照的 37 个 aggregate `supported_parameters` 都恰好等于各自 endpoint 参数并集。这是可由原文重新计算的快照事实，不是泛化保证。它不能证明所选 route 有并集里的每一项。例如 Opus 5/5.5 的 `temperature` 来自其它 endpoint，Moonshot 目录有采样参数但选中的原生 route 没报告它们；Z.ai 原生 route 没报告 `structured_outputs`。[models GET](https://openrouter.ai/api/v1/models)

输出上限差异尤其说明 aggregate 不能替 route 取值：

| 精确 ID | 所选 route | aggregate top-provider 输出值 | 所选 endpoint 输出值 |
| --- | --- | ---: | ---: |
| `deepseek/deepseek-v4.1-flash` | `deepinfra/fp8` | 384000 | 131072 |
| `deepseek/deepseek-v4-pro-0813` | `deepinfra/fp8` | 943718 | 16384 |
| `z-ai/glm-5.3` | `z-ai/fp8` | 943717 | 131072 |
| `z-ai/glm-5.3-flash` | `z-ai/fp8` | 128000 | 131072 |

以上是同时取得的两个来源字段，并非谁覆盖谁的采用结论。

## 参数与消息桥接的限制

[Chat schema](https://openrouter.ai/docs/api/api-reference/chat/create-a-chat-completion) 明确有 `ChatDeveloperMessage`。旧 research 的“该次页面检索没有找到 developer”仍是历史检索记录，不能扩成当前协议不支持。简化 [API overview](https://openrouter.ai/docs/api_reference/overview) 的示例联合类型只列 user/assistant/system，与完整 schema 的覆盖不一致；保留这处文档简化，不从它推负面支持结论。普通提醒在每条 route 是否内部重写、优先级如何，本任务没有上游 wire 或冲突指令实验。

完整 schema 的 `stop` 数组最多 **4** 项；core 当前允许非空序列数组而没有这个计数边界。通用参数文档给 temperature 0..2、top_p 0..1、penalty -2..2、seed 整数、max_tokens 正整数，但参数名存在不足以证明某 route 兑现整个数值域。top_p 的 overview 又写 `(0,1]`；当前 core 的 `(0,1]` 只落在二者共同范围内。不存在 route 的额外限制证明不能写成 `pass` 的完整域事实。[参数文档](https://openrouter.ai/docs/api_reference/parameters)

[推理文档](https://openrouter.ai/docs/guides/best-practices/reasoning-tokens) 说明 `supported_efforts` 是模型层词表；null 表示接受 gateway 词表，缺席表示未公开 effort selector，mandatory=true 时 none 被拒绝。这个快照中 Qwen3.7 Max/Plus、Qwen3.8/3.7 Flash 和 Kimi K2.7 Code 缺该 selector，不能从支持 `reasoning` 推所有 effort 值。原文列表保留 xhigh/minimal，不能静默扩充 core 五档。

[GPT-6 迁移文档](https://openrouter.ai/docs/cookbook/evaluate-and-optimize/model-migrations/gpt-6) 给出了特殊桥接的明确界限：

- Chat 中 `async:true` 工具标志会被移除并同步执行；async 能力只在 Responses skin 暴露。OpenAI/Azure 尊重该标志，Bedrock 同步；GPT-5.6 等早期 OpenAI 模型不能由普通 tools 支持推出 async 支持。
- `configuration_update` 只允许放在 content-less system/developer 消息，转换为上游 Responses item；user/assistant/tool 消息上的更新被 400 拒绝。标准 GPT6 支持，pro 变体拒绝。不能相邻，不能配 `truncation:auto`，在回放中位置需要保留。这是特别的配置条目，不等同普通 developer 提醒。
- Astra 不接受 none，Sol/Luna 接受；更新与 `reasoning.mode:pro` 的组合有跨字段限制。文档仅证明这种明确特殊转换，不证明所有普通 Chat GPT6/5.6 消息都无损转入同一 upstream Responses body。

[GPT-5.6 迁移文档](https://openrouter.ai/docs/cookbook/evaluate-and-optimize/model-migrations/gpt-5-6) 说明 `reasoning.mode:pro` 可把标准 model ID 改路由到 pro listing，`reasoning.context` 有 auto/all_turns/current_turn，均不是“任意 JSON 私有参数”事实。[Responses](https://openrouter.ai/docs/api_reference/responses/overview) 为 stateless，拒绝 store:true 和非 null previous_response_id，必须带全量 history。本任务没有 Responses POST。

[Sonnet5](https://openrouter.ai/docs/cookbook/evaluate-and-optimize/model-migrations/sonnet-5) 明确忽略 temperature/top_p/top_k 与 reasoning.max_tokens，verbosity 覆盖 reasoning.effort；[Opus5](https://openrouter.ai/docs/cookbook/evaluate-and-optimize/model-migrations/opus-5) 明确 disabled reasoning + max/xhigh 返回上游400，adaptive budgets 被忽略。这些是精确型号文档，未外推到 Opus5.5/Fable5.1。多参数优先级、开关+effort 依赖与特殊消息排序超出任务指出的 D-082 独立有限规则形状；本报告只登记表达缺口，没有补选择/drop/pass 政策。

## 缓存、TTL 与布局

[当前 OpenRouter 缓存文档](https://openrouter.ai/docs/guides/best-practices/prompt-caching) 的事实与旧暖读分别保留：

- GPT5.6+ 含本轮 GPT6 文档明确允许自动缓存，无需额外字段；最低 prompt 1024 tokens，自动写入也有 1.25x 写价。还可显式使用 text block `prompt_cache_breakpoint` 与 root `prompt_cache_options`，显式前缀至少30分钟；30m 是例子，schema 的 TTL 不是完整有限枚举。
- Anthropic-style `cache_control` 转 OpenAI marker **丢弃 TTL**；反向 marker 转 Anthropic/Google 使用默认5分钟。marker 格式转换不能当 TTL 无损桥接。
- Anthropic 有逐块显式缓存（最多4断点）和 root `cache_control` 的自动布局。后者仍需字段，与旧研究的无控制自动缓存不是同一个配置。provider级文档 TTL 是5m/1h；该页最低长度列表没有本轮四个 Claude5 IDs，不用旧型号填它们的最低长度。
- Chat schema 可把 cache_control 附到 text block 和 function tool definition，提供语法位置。文档没有逐 route 的 `system/last_tool/last_message` 完整布局枚举、混合 TTL 顺序约束或无可附着目标时行为；不能由三个语法位置补出7种完整布局。
- Alibaba 文档的显式列表是其它6 IDs，写TTL5分钟，还对其它 snapshot IDs给了排除例子；**本轮八个Qwen和GLM Prime都未被精确列举**。不能把家族名当9条具体路由TTL与布局证明，也不能因0902是snapshot便推该模型不支持。
- Gemini2.5+ 有无需控制的隐式模式，平均TTL3..5分钟且会变；同页另有显式模式：5分钟不续期、仅最后普通消息断点生效、cached首systemInstruction不可夹留动态尾。两个子节描述不同模式；本轮两款Gemini没有精确cache最小长度。
- Grok/Moonshot/DeepSeek/Z.AI是家族级自动缓存声明；DeepSeek家族声明未指定本轮DeepInfra，Z.AI声明不能推广Alibaba Prime。这里没有各精确route的TTL/SLA/hit guarantee。
- 26条旧研究无控制暖读可保留；这些route多数当前 `supports_implicit_caching=false`，与文档/暖读不一致。原flag及矛盾均可查，false不写成实际“不支持缓存”。Alibaba两款Flash与Gemini的flag=true。sticky routing十分钟是路由timer，与缓存保留TTL不同；指定provider.order绕过sticky。

## 逐 ID 目录读数

下表都是**公开元数据**。输入模态列只显示core四项；原始file保留在JSON。输出均声明text。`?` 是缺读数/未报告，绝非false。effort属于模型层声明，非每route独立的值域认证；mandatory属于模型层。四种tool choice的原true/false旗标及完整参数名在facts.json逐ID保留。

| 精确 model ID | route | 输入声明 | 共享 context | 输入 max_prompt | 输出 max_completion | json_schema参数 | effort模型词表 | reasoning |
| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |
| `openai/gpt-6-astra` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low | mandatory |
| `openai/gpt-6-astra-pro` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low | mandatory |
| `openai/gpt-6-sol` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low,none | optional |
| `openai/gpt-6-sol-pro` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low,none | optional |
| `openai/gpt-6-luna` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low,none | optional |
| `openai/gpt-6-luna-pro` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low,none | optional |
| `openai/gpt-5.6-sol` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low,none | optional |
| `openai/gpt-5.6-sol-pro` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low,none | optional |
| `openai/gpt-5.6-terra` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low,none | optional |
| `openai/gpt-5.6-terra-pro` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low,none | optional |
| `openai/gpt-5.6-luna` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low,none | optional |
| `openai/gpt-5.6-luna-pro` | `openai` | image+text | 1050000 | 922000 | 128000 | listed | max,xhigh,high,medium,low,none | optional |
| `anthropic/claude-opus-5.5` | `anthropic` | text+image | 1000000 | ? | 128000 | listed | max,xhigh,high,medium,low | mandatory |
| `anthropic/claude-opus-5` | `anthropic` | text+image | 1000000 | ? | 128000 | listed | max,xhigh,high,medium,low | optional |
| `anthropic/claude-sonnet-5` | `anthropic` | text+image | 1000000 | ? | 128000 | listed | max,xhigh,high,medium,low | optional |
| `anthropic/claude-fable-5.1` | `anthropic` | text+image | 1000000 | ? | 128000 | listed | max,xhigh,high,medium,low | mandatory |
| `deepseek/deepseek-v4.1-flash` | `deepinfra/fp8` | text+image | 1048576 | ? | 131072 | listed | max,high,low | optional |
| `deepseek/deepseek-v4-pro-0813` | `deepinfra/fp8` | text | 1048576 | ? | 16384 | listed | max,high,low | optional |
| `google/gemini-3.8-flash` | `google-ai-studio` | text+image+video+audio | 1048576 | ? | 65536 | listed | high,medium,low | mandatory |
| `google/gemini-3.7-flash` | `google-ai-studio` | text+image+video+audio | 1048576 | ? | 65536 | listed | high,medium,low | mandatory |
| `x-ai/grok-4.7` | `xai` | text+image | 500000 | ? | 450000 | listed | xhigh,high,medium,low | mandatory |
| `x-ai/grok-4.6` | `xai` | text+image | 500000 | ? | 450000 | listed | xhigh,high,medium,low | mandatory |
| `qwen/qwen3.8-max-0902` | `alibaba` | text+image+video | 1000000 | 983616 | 131072 | listed | xhigh,high,medium,low,minimal | mandatory |
| `qwen/qwen3.8-max-prime` | `alibaba` | text+image+video | 1000000 | 983616 | 131072 | listed | xhigh,high,medium,low,minimal | mandatory |
| `qwen/qwen3.8-2.4t-a95b` | `alibaba` | text | 1000000 | ? | 131072 | listed | xhigh,medium,low | mandatory |
| `qwen/qwen3.8-27b` | `alibaba` | text+image+video | 1000000 | ? | 131072 | ? | xhigh,medium,low | optional |
| `qwen/qwen3.7-max` | `alibaba` | text | 1000000 | 983616 | 131072 | listed | no exposed selector | optional |
| `qwen/qwen3.7-plus` | `alibaba` | text+image | 1000000 | 983616 | 131072 | listed | no exposed selector | optional |
| `qwen/qwen3.8-flash` | `alibaba` | text+image+video | 1000000 | 983616 | 131072 | listed | no exposed selector | optional |
| `qwen/qwen3.7-flash` | `alibaba` | text+image+video | 1000000 | 983616 | 65536 | ? | no exposed selector | optional |
| `moonshotai/kimi-k3` | `moonshotai/mxfp4` | text+image+video | 1048576 | ? | 943718 | listed | max,high,low | optional |
| `moonshotai/kimi-k2.7-code` | `moonshotai/int4` | text+image | 262144 | ? | 235929 | listed | no exposed selector | mandatory |
| `z-ai/glm-5.3` | `z-ai/fp8` | text | 1048576 | ? | 131072 | ? | max,high,low | mandatory |
| `z-ai/glm-5.3-flash` | `z-ai/fp8` | text+image+video | 1048576 | ? | 131072 | ? | max,high,low | mandatory |
| `z-ai/glm-5.3-flashx` | `z-ai/fp8` | text+image+video | 1048576 | ? | 131072 | ? | max,high,low | mandatory |
| `z-ai/glm-5.2` | `z-ai/fp8` | text | 1048576 | ? | 131072 | ? | xhigh,high | optional |
| `z-ai/glm-5.3-prime` | `alibaba` | text | 1000000 | ? | 131072 | ? | max,high,low | mandatory |

## 未覆盖与检索边界

资料只来自 OpenRouter `docs`、公开 `api/v1/models` 和原ID `/endpoints`。实际 GET了协议/schema、迁移、推理、structured outputs、工具、缓存、provider routing、模态输入与完整OpenAPI，共26个文档/索引原文+1份models JSON+37份endpoint JSON。没有读取上游供应商文档、社区博客、issues或模型付费结果；唯一来源社区是OpenRouter第一方。外部source链接是文档原有指向，本任务未核它们，不能升级为事实依据。

搜索工具做过四个 `site:openrouter.ai/docs` 查询（GPT6+Responses+Chat、GPT5.6+temperature、Chat converted Responses、developer/system translation）。它返回了一些站点模型页及无关结果，它们不在指定source路径内，全部排除。搜索摘要仅作发现尝试，没有进入事实证据；记录在 [search-log.json](search-log.json)。没有找到普通Chat→Responses整套转换的逐字段无损声明，不写成“没有实现”。完整schema与特殊配置桥接是已核范围。

通用image页给png/jpeg/webp/gif与URL/base64输入，明确image数量随模型/provider变化，没有37条route的单图bytes上限。Audio页明确必须base64、format因provider而变；Video页给通用mp4/mpeg/mov/webm，AI Studio direct URLs只支持YouTube，Messages skin不收video。[图片](https://openrouter.ai/docs/guides/overview/multimodal/image-understanding)、[音频](https://openrouter.ai/docs/guides/overview/multimodal/audio)、[视频](https://openrouter.ai/docs/guides/overview/multimodal/videos)

因此未闭合的是19条输入只计窗口、逐route的maxImageBytes或不存在限制证明、每route完整参数/extra值域与条件约束、9条Alibaba模型的确切cache适用性/TTL、全部显式完整布局与空附着行为、普通提醒优先级/重写，以及真实模态/工具/推理回放/TTL认证。不能用false、空inputConstraints、任意extra值域或完整布局的推断填它们。

## 与已有 warm162 的区别及复核方法

历史summary只读复制为 [historical-model-evidence-summary.json](inputs/historical-model-evidence-summary.json)，source原路径/hash另列manifest。它记37模型暖读、162 sends、USD1.057233989500000000、unsettled0；本轮逐ID facts保留每张warm card原值。这仍是历史有限短请求读数，不证明最大窗口、全工具参数、提醒冲突、模态或TTL生效；本任务未重新执行或逐条核其已认证body。

本轮公开原文全在 `raw/`。source-manifest每条含UTC、URL、状态、原文hash与headers，`collect.py`只有GET且不读取凭据；`build_facts.py`从冻结文件生成facts，不能调用网络或产生正式定义。`verify.py`重算hash、校固定37 IDs及route与逐条claim定位，输出 [verification.json](verification.json)。没有HTTP失败；第一次用了本机不存在的`python`命令，原stderr保全于 [失败记录](failures/local-python-missing.txt)，之后用现有python3取得全部资料。

临时目录仍在HUB，属于派发者待核原文的任务证据，不是已经迁入research/design的接受材料。没有修改旧证据、源码、规格、registry或locks。
