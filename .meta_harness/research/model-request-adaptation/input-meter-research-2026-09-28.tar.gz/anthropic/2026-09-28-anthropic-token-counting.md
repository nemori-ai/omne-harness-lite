# Anthropic token 计量：官方接口、pi / OpenCode 与离线重建

调查日期：2026-09-28。状态：事实调查与小型离线复现；不构成选型或规格接受。消费者：model-request-adaptation 的请求计量研究。项目基线：`1b2a6a0b3236281f270aaf354457cf70177eceae`。本次不读取凭据、不发送任何模型或计量 API 请求。

## 结论先行

有一条比旧 Claude BPE 更有针对性证据的离线路线：**社区 `sanderland/ctok` 重建了新版 Claude 文本计数**。本次实际执行它的代码，复现作者记录的 MultiPL-E 22 种编程语言 × Claude 4.5 / 4.7 / Opus 5 三组计数，66 项全部相等。但这些是作者保存的历史单 user 文本计数，不是本次独立取得的 API 真值；它没有完整请求编码器，且明确承认 Opus 5 / 5.5 的未建模差异，因此不能直接提升为四条 OpenRouter 路由的精确请求计量器。[ctok 固定版本说明][ctok]

**pi 与 OpenCode 本身没有解决新版 Claude tokenizer。** 本次查阅版本仍采用字符密度估算；pi 会以适用的历史 usage 为基线加尾部估算，OpenCode 的不同调用路径分别使用响应 usage 或序列化请求的字符估算。这些方法改善了持续对话的反馈来源，却不能把下一次请求的新增内容、模板和图片变成精确计数。[pi 估算源码][pi-est] [OpenCode 估算源码][oc-est]

官方 `count_tokens` 提供最接近实际模型输入的请求前读数，但 Anthropic 自己仍称其为估计。本次在 OpenRouter 公开 OpenAPI 和文档索引中没有找到对应接口；不能据此证明私有接口不存在，也没有做未授权端点探测。官方 Anthropic 接口需要其凭据，不符合“仅用 OpenRouter 凭据即可调用”的条件。所有模型请求走 OpenRouter 的项目约束保持不变。[官方计量][count] [接口与认证][count-api] [OpenRouter OpenAPI][or-api]

## 对象与版本

本次确切对象来自 `packages/model/pi-ai-transport/src/official-models/anthropic.ts`，不是泛称 Claude：

| 项目 model ID | 官方 Claude API ID 证据 | 对离线重建的覆盖 |
|---|---|---|
| `anthropic/claude-opus-5.5` | 官方模型表 `claude-opus-5-5` | ctok 明说比 Opus 5 多 2 tokens 的差异尚未建模 |
| `anthropic/claude-opus-5` | count_tokens 参考示例 `claude-opus-5` | 本次复现 22 个历史 code fixtures；尾部 ASCII 空白差异未建模 |
| `anthropic/claude-sonnet-5` | 官方模型表 `claude-sonnet-5` | ctok 列入 v4.8+；本次没有该模型的独立真值 |
| `anthropic/claude-fable-5.1` | 官方模型表 `claude-fable-5-1` | 官方确认沿用 4.7 tokenizer；ctok 文档只明确写 Fable 5，没有单列 5.1 验证 |

模型名映射依据是[官方模型表][models]与[接口示例][count-api]。词表家族相同不等于消息 framing、thinking 保留及 OpenRouter 转换完全相同。

当前项目 `src/input-meters/anthropic.ts` 的实际行为：只绑定上述四个 revision 1 / `pi-ai:anthropic` revision `mp4-1`；校验 body 与 serialized 一致后，将**完整最终 JSON**进行 NFKC，再用旧 `claude.json` BPE 计数，返回 `estimated`；非 text content（包括图片）返回 `unavailable`。归档词表 SHA-256 为 `58dad83d85e9cd57be209172449ebfbc395df2b455c11fe8b7e5b661e6f462ad`。这是源码观察，不是“JSON 就等于模型可见 token 流”的保证。Anthropic 的[归档 tokenizer][legacy]明确说 Claude 3 起已不准确；本次没有找到官方公开的新 tokenizer 词表文件。

查阅上游与项目采用版本须分开：下表为此次固定的候选调查版本，不表示项目升级了依赖。所有下载文件的固定 URL、SHA-256 与实际取得时间见证据 `manifest.json`。

| 对象 | 本次固定提交 | 许可 / 运行代价 |
|---|---|---|
| pi-mono | `c1449660c83fd00a7c71d5f7e1bd29fafd400550` | MIT；TS，字符估算无计量网络请求 |
| anomalyco/opencode | `3c893f0a166cfc433819b4eff65d2e6c7696a1c9` | MIT；TS，字符估算无计量网络请求 |
| ctok 1.3.0 | `8c43ffd3c7be467622a540f025516e49ef78d8b1` | MIT；Python ≥3.12，当前依赖 `regex`；并非搜索快照所说“零依赖” |
| Anthropic legacy tokenizer | `4d75e64d32fe5cd2b5a24d954242f9fab12e8b4b` | MIT；旧模型 BPE |
| DeepSeek Harness | `4878cdabd87d4041bdaff61d04c966883b9fd07a` | MIT；仅调查 token-meter 子系统 |
| 本地 omne-next | `6263fed545e48ad9efb5714f3fe76a7c1a0af1b5` | 本地 Git 原件；非本项目现行规格 |

用户写的 “opencoder” 在本次按 OpenCode 处理：其[官方网站](https://opencode.ai/)链接 `anomalyco/opencode`。没有将名字相似的第三方插件或 fork 当作官方实现。

## 官方计量的成立条件与 OpenRouter 差距

[官方计量页][count]说明，接口支持 system、client tools、base64 图片/PDF、thinking；拒绝大部分 server tools（advisor 例外）、MCP connector 与 URL/file 媒体源。它按指定 model 计数；Claude 4.7+ 使用新 tokenizer，文档给出的约 30% 增长依内容变化，不能用作误差上界。Fable 5.1 专节确认其 tokenizer 家族。

`POST /v1/messages/count_tokens` 返回输入总数；[API 参考][count-api]明确给出 Anthropic host、X-Api-Key 与 thinking/tool schema。这个读数不保证等于账单：可能含系统附加 token；cache_control 可传入但不会执行 cache 命中逻辑。计量免费，另有按 tier 的 RPM 限制。因此它增加一次携带完整输入的网络往返、独立限流/失败点及 Anthropic 凭据；本次没有实测延迟。

[OpenRouter 文档][or-overview]公开了 chat schema 转换与原生 tokenizer 的响应 usage；prompt_tokens 包含图片、工具等。这个 usage 来自已发生的请求。它能提供后续评估/校准材料，不能让本次预发判定回到过去。把 Anthropic SDK 改 base URL 并不构成 `count_tokens` 在 OpenRouter 存在的证据。

检索边界：实际浏览 OpenRouter `openapi.json`、`docs/llms.txt`、API overview、usage accounting；搜索 `count_tokens` 未命中公开 OpenAPI，文档索引也未列 token counting。原始下载受 403 限制，web 浏览器能够读取；保存的是浏览器文本摘取快照，不能冒充 HTTP 原始响应。未用任何 credential 验证未知接口。

**推断**：即使通过其他渠道取得 Anthropic count_tokens，仍需核对送入该接口的 Anthropic 请求是否与 OpenRouter 实际转出的请求一致；本地 Chat Completions JSON 不是 Anthropic 消息编码格式。该推断依赖 OpenRouter 的已公开格式转换事实，不声称已取得其私有模板。

## 社区实现实际在哪一步计数

### pi：usage 锚点 + 未计量尾部，且会进入请求前输出预算

`packages/ai/src/utils/estimate.ts`：文本 `ceil(UTF-16 length / 4)`，每张图片固定 1200；system tool definitions 用 JSON 字符估算。`estimateContextTokens` 找最近适用的 assistant usage，排除 aborted/error/zero，并用 prefix timestamp 避免较新的前缀继续复用旧 usage；存在锚点时加尾部估算，否则全量估算。[源码][pi-est]

真实调用：`api/anthropic-messages.ts` 的 simple 调用进入 `buildBaseOptions` / `clampMaxTokensToContext`；后者从 window 扣估算 context 与 4096，再限制 maxTokens。[预算路径][pi-options]；同文件 `message_start` / `message_delta` 将 provider input/output/cache read/write 归入 usage。coding-agent 的 `agent-session.ts` 又调用 `estimateProjectedContextTokens` / `shouldCompact`；compaction 模块在编辑或压缩后排除失效 usage。保存的源码能定位这些调用。

**适用与局限**：usage 是已发送前缀的观察，后续增量仍粗估；首请求无锚点；模型/route/前缀变动、tool schema、思考块保留规则变化都可能破坏可比性。源码里的 “conservative” 注释不能证明字符除四不会低估中文。未发现该路径训练按语言/模型拟合的校准器，也未调用 Anthropic count_tokens。

### OpenCode：两条代码路径不能混在一起

`packages/core/src/util/token.ts` 是 `max(0, round(length / 4))`；`packages/opencode/src/util/token.ts` 只是重导出。[源码][oc-est]

- core 的 `session/compaction.ts`：`compactIfNeeded` 对 `{system,messages,tools}` 的 JSON 做字符估算，再比较 context/output/buffer；summary guard 也是这个估算。[core 路径][oc-core]
- opencode 的 `session/compaction.ts`：retained-tail 选择先 `MessageV2.toModelMessagesEffect`，然后 JSON 字符估算。`session/processor.ts` 把实际响应 usage 经 `Session.getUsage` 写入 assistant，overflow 判定读取这些数；`overflow.ts` 使用 total 或 input+output+cache read/write。[overflow 源码][oc-overflow]
- `session/session.ts#getUsage` 已注意 AI SDK v6 inputTokens 包含缓存，因此减去 cache read/write 得普通输入分项；这属于响应归一化，不是新的 tokenizer。

负面来源：[#10634](https://github.com/anomalyco/opencode/issues/10634)报告大 tool result 尚未计入先前 usage 导致下步溢出（已关闭，历史故障）；[#35013](https://github.com/anomalyco/opencode/issues/35013)报告 Fable/Zen JSON 字节限制先于 token 窗口触发（已关闭，历史故障）；[#17340](https://github.com/anomalyco/opencode/issues/17340)仍有 compaction 本身超窗报告。它们是用户报告而非本次复现，不能断言固定 HEAD 仍有同样缺陷；它们说明 token 计数、未来增量与 request bytes 是不同约束。

### DSH 与 omne-next：没有隐藏的新版 Claude 精确算法

DSH 的[固定 estimate.ts][dsh-est]使用 chars/4，加每 block/role 固定开销，工具 JSON 同样估计，图像 reference 用结构价格而非像素 tokenizer。它不是 Anthropic 新词表。[Discussion #6361](https://github.com/deepseek-ai/deepseek-harness/discussions/6361)有中文密集对话与中转 usage 异常的用户报告；本次没有复现其具体请求。

本地 omne-next `.../compaction/token_counting.py` 调 LangChain `get_num_tokens_from_messages`；不可用则回落 `count_tokens_approximately`。`is_exact=True` 的代码含义只是 model 方法返回，不证明底层方法针对四个新 Claude ID 精确。本次只核这个 wrapper，没有展开其所有 adapter/历史运行环境，也未将 omne-next 历史设计引为现行规则。

## 新版离线重建：ctok 的证据更强，覆盖仍需逐模型看

ctok 的[代码][ctok-main]先做 Unicode/词边界/大小写等重写，再以词表求最少片段计数，并加入单消息 frame；与当前 legacy BPE 路径不同。其[公开 fixtures][ctok-fixture]记录实际模型名和计数；本次复现见下一节。词表 witness 只是特定 probe 中的 membership 证据，不独立证明全部编码规则。

关键反例已经写在[固定 README][ctok]中：Opus 5 尾部 ASCII whitespace 免费的行为未建模，Opus 5.5 相对 Opus 5 的 +2 差异也未建模。本次自造五个输入上，ctok 传 `5.0` 与 `5.5` 返回相同数，复现了实现并未区分这一点。因此“v4.8+ 通用”是库的家族选择，不是四个完整 model ID 都已认证。

作者的大规模准确率材料须按来源理解：部分语料参与词表选择；本次只复现 MultiPL-E 22 份 held-out code。没有把作者的数百万零低估声明推广为任意输入保证；没有 Fable 5.1 或 Opus 5.5 的本次独立校验。API 只接文本字符串，未提供 system/tools/multi-turn/images/thinking 完整 wire 计量；把整个 JSON 喂进去只会计“包含 JSON 的单 user 文本”。

另一重建仓库 [freQuensy23-coder/claude-opus-4-7-tokenizer](https://github.com/freQuensy23-coder/claude-opus-4-7-tokenizer/tree/5ac7cfa0d739164e4db73f1f7d7c3f08f20b57bf)采用 sandwich probing，作者自己的 greedy 验证报告在 prose、CJK、俄文有明显偏差。它为“新词表可部分重建”提供另一份第一手实验记录，但本次未复跑其需要 Anthropic key 的采集 pipeline，不能用“verified tokens”推导完整计数精确。该仓库 MIT；另一 [token-opus47-benchmark](https://github.com/tmokmss/token-opus47-benchmark/tree/c6f5ecdef4b383e66dafcdcd9f8a73e1dc6b4931)比较官方 API 两代计数，说明工作负载影响比率，属于在线评估工具，未发现 LICENSE 文件，未复制其实现。

## 本次离线小实验

运行环境：Python 3.12.13、regex 2026.9.10、Node 24.18.0、js-tiktoken 1.0.21。执行真实 ctok 源码与当前项目同 SHA 旧词表；pi/OpenCode 列执行其字符公式，不声称启动整个 app。

1. 作者 MultiPL-E fixtures：22 份代码，分别核对 `claude-opus-4-5`、`claude-opus-4-7`、`claude-opus-5` 的保存计数，三组各 22/22 相等。总运行约 4.76 秒，只是此次 66 次调用墙钟记录，不是性能 benchmark，也不是 API 延迟。原始 model 名/逐项结果见 `probe-result.json`。
2. 自造五类字符串仅比较数值差异；**没有官方真值，不报告误差率**。ctok 列包含单 user frame；legacy/字符列只计字符串，不应直接用差额当 tokenizer 误差。

| 输入类别 | UTF-16 长度 | legacy 文本 BPE | pi 字符公式 | OpenCode 字符公式 | ctok 4.7 单 user | ctok 5.0 / 5.5 单 user |
|---|---:|---:|---:|---:|---:|---:|
| 英文 | 68 | 12 | 17 | 17 | 29 | 24 / 24 |
| 中文 | 36 | 29 | 9 | 9 | 49 | 43 / 43 |
| TS 代码 | 144 | 42 | 36 | 36 | 62 | 57 / 57 |
| tool schema 的 JSON 文本 | 165 | 39 | 42 | 41 | 76 | 71 / 71 |
| 多轮消息的 JSON 文本 | 175 | 47 | 44 | 44 | 83 | 78 / 78 |
| 图片 | — | 项目 meter unavailable | 每张固定 1200 | 未实现像素计数 | 不支持 | 不支持 |

工具 schema / 多轮两行不是 structured-request 测量。图片行是源码能力审查，未伪造图片计数。原始文本、探针、结果与固定来源哈希随证据保存。复现先按 `fetch-ctok.py` 取得固定 source/fixtures 到 scratch，再执行 `probe.py`；旧词表对比通过 `js-probe/probe.mjs <项目根绝对路径>`，命令见 `REPRODUCE.md`。

## 各路线能提供什么、要付什么代价

| 路线 | 准确性依据 | 额外网络/凭据/延迟 | 仍缺什么 |
|---|---|---|---|
| Anthropic count_tokens | 官方按 model 请求前计数，仍称 estimate | Anthropic 凭据，一次完整输入网络往返，独立RPM；免费；延迟未测 | OpenRouter 暴露接口与转换一致性未证实；cache命中不测 |
| ctok 新版重建 | 有模型标注历史 API fixtures，本次66项重放一致 | 离线运行无需凭据/网络；下载依赖仅安装时；Python+regex/词表及维护成本 | 完整请求模板、多模态、精确5.5与Fable5.1读数；TS移植/嵌入未验证 |
| pi usage+tail | 已发生前缀的 provider usage + 新增字符估算 | 复用正常请求usage无额外模型请求 | 首轮和tail仍估计；前缀/模型变化需判失效；无误差上界 |
| OpenCode / DSH chars4 | 确定性源码实现 | 本地低计算量，MIT | 无新Claude词表依据；语言/媒体/模板差异 |
| 旧 Claude BPE | 厂商归档且明确过时 | 本地运行，MIT | 新tokenizer、模板、图像；本次无四模型真实误差分布 |
| 用OpenRouter usage建立经验校准 | 实际route产生的观察可作数据 | 复用既有usage无新增调用；采集与评估成本；需要真实样本 | 本次未训练/验证校准器；不能保证新形态输入，也不是预发真值 |

后续证据缺口是：四个精确 model/provider/转换形态的可比较真值，包含中英、代码、system+tools、多轮thinking/cache、图片；对 ctok 已知5.5差异及 Fable5.1 framing 的核实；OpenRouter 是否提供公开、仅需其凭据的请求前计量服务。上述是未知及其影响，不是项目方案选择。

[count]: https://platform.claude.com/docs/en/build-with-claude/token-counting
[count-api]: https://platform.claude.com/docs/en/api/messages/count_tokens
[models]: https://platform.claude.com/docs/en/models/overview
[or-api]: https://openrouter.ai/openapi.json
[or-overview]: https://openrouter.ai/docs/api_reference/overview
[legacy]: https://github.com/anthropics/anthropic-tokenizer-typescript/tree/4d75e64d32fe5cd2b5a24d954242f9fab12e8b4b
[pi-est]: https://github.com/badlogic/pi-mono/blob/c1449660c83fd00a7c71d5f7e1bd29fafd400550/packages/ai/src/utils/estimate.ts
[pi-options]: https://github.com/badlogic/pi-mono/blob/c1449660c83fd00a7c71d5f7e1bd29fafd400550/packages/ai/src/api/simple-options.ts
[oc-est]: https://github.com/anomalyco/opencode/blob/3c893f0a166cfc433819b4eff65d2e6c7696a1c9/packages/core/src/util/token.ts
[oc-core]: https://github.com/anomalyco/opencode/blob/3c893f0a166cfc433819b4eff65d2e6c7696a1c9/packages/core/src/session/compaction.ts
[oc-overflow]: https://github.com/anomalyco/opencode/blob/3c893f0a166cfc433819b4eff65d2e6c7696a1c9/packages/opencode/src/session/overflow.ts
[dsh-est]: https://github.com/deepseek-ai/deepseek-harness/blob/4878cdabd87d4041bdaff61d04c966883b9fd07a/packages/llm/token-meter/src/estimate.ts
[ctok]: https://github.com/sanderland/ctok/blob/8c43ffd3c7be467622a540f025516e49ef78d8b1/README.md
[ctok-main]: https://github.com/sanderland/ctok/blob/8c43ffd3c7be467622a540f025516e49ef78d8b1/ctok/main.py
[ctok-fixture]: https://github.com/sanderland/ctok/blob/8c43ffd3c7be467622a540f025516e49ef78d8b1/tests/fixtures/multipl_e_counts.json
