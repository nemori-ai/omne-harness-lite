# 无凭据离线复现

保存的是一次版本固定调查，不是已接受模型计量器。取得日期及每个上游文件哈希见 manifest.json；较大的 ctok 词表、fixtures 只保留固定下载清单，避免把完整仓库或依赖包入库。首次准备会下载开源包和源码，测试阶段不访问网络。

把本证据目录复制到可丢弃 scratch 目录，然后在其内执行：

```sh
python3 fetch-ctok.py
uv venv --python 3.12.13 venv
uv pip install --python venv/bin/python regex==2026.9.10
venv/bin/python probe.py
npm ci --prefix js-probe --ignore-scripts --no-audit --no-fund
node js-probe/probe.mjs /absolute/path/to/project-checkout
```

最后一项项目检出必须具有 SHA-256 为 `58dad83d85e9cd57be209172449ebfbc395df2b455c11fe8b7e5b661e6f462ad` 的 `packages/model/pi-ai-transport/tokenizers/anthropic-legacy/claude.json`。本次实际基线为 `1b2a6a0b3236281f270aaf354457cf70177eceae`，不从主检出读取计量源码。

`probe.py` 输出/更新 probe-result.json。fixtures 的期望结果是 22 × 3 个计数相等。运行时/耗时字段会因环境变化；不会保证 JSON 文件字节相等。自造五类字符串没有官方真值；schema/multi-turn 两类明确是“JSON 作为文本”的计数。图片部分是源码覆盖审查，没有图片推理或图片 token 真值。

本次没有运行完整上游测试、没有按生产请求大小测性能、没有执行 Anthropic/OpenRouter API。一次失败的 regex 版本安装解析和一次探针路径 ENOENT 已修正后重跑；未形成结果数据。OpenRouter/Anthropic 原始页面下载返回403，网页事实经 web.run 原文浏览核实；web-extract.txt 是浏览器文字摘取，不是原始HTTP快照。对 OpenRouter OpenAPI 的 `count_tokens` 检索未命中，只支持“本次公开文档未找到”，不证明不存在私有端点。

manifest.json 包含 MIT 开源源码的原件与许可；omne-next 只包含本地已固定 commit 的一个 wrapper，未复制历史设计。研究报告中的 issue 是公开用户报告，不是本次执行证据。
