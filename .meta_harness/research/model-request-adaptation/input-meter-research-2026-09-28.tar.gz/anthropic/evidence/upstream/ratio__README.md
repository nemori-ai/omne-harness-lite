# Claude Opus 4.6 vs 4.7 Tokenizer Benchmark

Measures how the new tokenizer in **Claude Opus 4.7** changes input-token counts
compared to **Claude Opus 4.6**, across a matrix of realistic workload patterns:

- Prose in 8 languages (en, ja, zh, ko, fr, de, ru, hi)
- Mixed JA/EN tech-blog text and OCR-style invoice text
- Code (Python, TypeScript)
- Structured data (JSON records, JSON Schema, Markdown tables, dense numbers)
- Images at varied aspect ratios and resolutions (256² up to 2048²)

Token counts come from the Anthropic API's `messages.countTokens` endpoint, which
returns the exact number of input tokens that would be charged for a real
`messages.create` call. The endpoint itself is billed at $0 per token, so this
benchmark can be re-run freely.

## Headline result

**Overall ratio (4.7 / 4.6): 1.094x** — but the spread by content shape is enormous, and the pattern is clean: **Latin-script languages get hit hard, large images cost more because 4.7 actually looks at them (4.6 silently downscaled), and everything else is essentially unchanged.**

### By prose language

| Language | Avg ratio (4.7 / 4.6) | 4.6 chars/token | 4.7 chars/token |
|---|---|---|---|
| Chinese (zh)   | **1.004x** | 0.92 | 0.92 |
| Hindi (hi)     | **1.005x** | 1.44 | 1.44 |
| Japanese (ja)  | **1.005x** | 0.98 | 0.98 |
| Korean (ko)    | **1.006x** | 0.99 | 0.99 |
| Russian (ru)   | **1.011x** | 2.82 | 2.81 |
| French (fr)    | **1.321x** | 3.40 | 2.56 |
| German (de)    | **1.509x** | 3.13 | 2.10 |
| English (en)   | **1.614x** | 5.20 | 3.30 |

Spread across languages: **0.610** (Chinese 1.004x → English 1.614x).

### By non-prose category

| Category | Avg ratio | Note |
|---|---|---|
| markdown_table  | 1.006x | unchanged |
| json_data       | 1.019x | unchanged |
| ja_ocr_like     | 1.025x | unchanged |
| numbers_dense   | 1.047x | small bump |
| ja_en_mixed     | 1.112x | mixed JA/EN tech blog |
| json_schema     | 1.134x | tool-definition JSON |
| code_typescript | 1.245x | code grows ~25–30% |
| code_python     | 1.295x | code grows ~25–30% |
| images          | 1.742x | avg across 10 images — see below |

### By image resolution

Images only. 10 solid-color PNGs at varied aspect ratios, measured by pixel count.

| Image | Pixels | 4.6 tokens | 4.7 tokens | Ratio | 4.6 px/tok | 4.7 px/tok |
|---|---|---|---|---|---|---|
| 256 × 256           | 0.07 MP | 110   | 114   | **1.04x** |   596 |   575 |
| 1280 × 720   (HD)   | 0.92 MP | 1,206 | 1,210 | **1.00x** |   764 |   762 |
| 1024 × 1024         | 1.05 MP | 1,379 | 1,383 | **1.00x** |   760 |   758 |
| 2048 × 512   (4:1)  | 1.05 MP |   794 | 1,420 | **1.79x** | 1,320 |   739 |
| 512 × 2048   (1:4)  | 1.05 MP |   794 | 1,420 | **1.79x** | 1,320 |   739 |
| 2500 × 500   (5:1)  | 1.25 MP |   682 | 1,634 | **2.40x** | 1,833 |   765 |
| 2100 × 900   (21:9) | 1.89 MP | 1,354 | 2,489 | **1.84x** | 1,396 |   759 |
| 1920 × 1080  (FHD)  | 2.07 MP | 1,570 | 2,705 | **1.72x** | 1,321 |   766 |
| 1080 × 1920  (portrait FHD) | 2.07 MP | 1,570 | 2,705 | **1.72x** | 1,321 |   766 |
| 2048 × 2048         | 4.19 MP | 1,531 | 4,775 | **3.12x** | 2,740 |   878 |

This is a **capability upgrade**, not a pricing change. Per the [Opus 4.7 release notes](https://platform.claude.com/docs/en/about-claude/models/whats-new-claude-4-7#high-resolution-image-support), the maximum image resolution went from **1568 px / 1.15 MP → 2576 px / 3.75 MP**. The measurements match the announcement exactly:

- **Both models price images at ~750 pixels/token** whenever the image fits under the model's cap. 4.6: 760 px/tok at 1024². 4.7: 758–766 px/tok across everything under 3.75 MP.
- **4.6 silently downscaled to its 1.15 MP cap.** That's why 1920×1080 (2.07 MP), 2048×512 (1.05 MP — but with the long edge over 1568 px), and 2500×500 all score well under what 750 px/tok would predict — 4.6 was only ever "seeing" ~1.15 MP of image regardless of what you uploaded.
- **4.7's 2048² (4.19 MP) measurement implies downscaling to ~3.58 MP**, consistent with a 3.75 MP cap. Everything under that cap is priced at ~760 px/tok without any downscaling.
- **Aspect ratio is irrelevant** — 2048×512 and 512×2048 score identically on both models. Tokens track pixel count (after any cap-driven downscaling), nothing else.
- **4.7 also gives you 1:1 pixel coordinates** (no scale-factor math), which matters for computer-use / element-location tasks.

The headline implication: **when you attach a high-resolution image, 4.7 is actually processing the extra detail that 4.6 was throwing away.** The extra tokens buy you better OCR, chart reading, and UI-element localization — per the release notes, this is "particularly important for computer use and screenshot/artifact/document understanding workflows." If you don't need the extra fidelity, downsample to ≤ 1.15 MP on the client and the two models cost the same.

### Takeaways

- **English-heavy prompts cost ~60% more input tokens on 4.7.** German +51%, French +32%.
- **CJK and other non-Latin scripts (zh/ja/ko/hi/ru) are essentially unchanged** — within 1.1% across the board.
- **Code grows ~25–30%**, consistent with code being mostly English keywords + ASCII punctuation.
- **Structured data (JSON records, Markdown tables, OCR-like text) is essentially unchanged** because the heavy hitters are non-tokenized whitespace and Japanese/Chinese characters.
- **High-res images on 4.7 cost 1.7–3.1× more — because 4.7 actually looks at them.** 4.6 silently downscaled to 1.15 MP; 4.7 raises that cap to 3.75 MP ([release notes](https://platform.claude.com/docs/en/about-claude/models/whats-new-claude-4-7#high-resolution-image-support)). At the same effective resolution (≤ 1.15 MP), both models cost the same (±1%).
- Within each category, the ratio is **size-independent for text** (small/medium/large sit within ~1%) but **resolution-dependent for images** (extra tokens = extra detail actually perceived).
- **Operational implication:** if your prompts are English-dominant (e.g. system prompt + tools in English), expect a meaningful input-cost increase on 4.7. If your user content is non-Latin script, you'll see almost no change. If you attach screenshots/photos, decide per-use-case: let 4.7 see the full resolution when fine detail matters (UIs, charts, docs), or downsample to ≤ 1.15 MP when it doesn't.

> Run on 2026-04-17 with 58 samples (48 text + 10 image) × 2 models = 116 `countTokens` calls.
> Reproduce with `npm run bench` (regenerates `results/raw.csv` and `results/summary.md`).

## Prerequisites

- Node.js 20.6+ (for `process.loadEnvFile`)
- An `ANTHROPIC_API_KEY` with access to both `claude-opus-4-6` and
  `claude-opus-4-7`. The key must come from an account with a non-zero credit
  balance — `count_tokens` itself is free, but the API gates on balance.

## Setup

```bash
npm install
echo "ANTHROPIC_API_KEY=sk-ant-..." > .env
```

`.env` is `.gitignore`d. You can also export `ANTHROPIC_API_KEY` directly
instead of using a file.

## Run

```bash
npm run bench
```

This walks every `samples/<category>/{small,medium,large}.txt`, calls
`messages.countTokens` against both models, and writes:

- `results/raw.csv` — one row per (sample × model), including `chars_per_token`
- `results/summary.md` — ratio matrix, chars/token table, ranking, top/bottom
  samples, and a brief auto-generated discussion

Concurrency is capped at 10 in-flight requests; the SDK handles retries with
exponential backoff.

## Sample regeneration

Synthetic structured/code/OCR samples come from `scripts/generate-samples.ts`.
Multilingual prose samples are scraped from Wikipedia by
`scripts/fetch-wikipedia.ts`. Image samples (10 PNGs at varied aspect ratios) are
generated by `scripts/generate-images.ts` via sharp. Each can be re-run
independently:

```bash
npx tsx scripts/generate-samples.ts   # synthetic text categories
npx tsx scripts/fetch-wikipedia.ts    # *_prose categories from Wikipedia
npx tsx scripts/generate-images.ts    # samples/images/*.png
```

## Project layout

```
src/
  index.ts        # entrypoint
  anthropic.ts    # countTokens wrapper (model IDs, client)
  samples.ts      # walks samples/ and builds payloads
  report.ts       # writes CSV + Markdown summary
samples/
  en_prose/       # English prose (Wikipedia)
  ja_prose/       # Japanese prose
  zh_prose/       # Chinese prose
  ko_prose/       # Korean prose
  fr_prose/       # French prose
  de_prose/       # German prose
  ru_prose/       # Russian prose
  hi_prose/       # Hindi prose
  ja_en_mixed/    # tech-blog-style JA/EN mix
  ja_ocr_like/    # OCR-style invoice/delivery slip
  code_python/
  code_typescript/
  json_data/      # business-data JSON (Japanese fields)
  json_schema/    # Anthropic-tool-use-style JSON schema
  markdown_table/
  numbers_dense/  # SKU + qty + price + date + phone, packed
  images/         # PNGs at varied aspect ratios + resolutions
results/          # benchmark output (raw.csv + summary.md)
scripts/
  generate-samples.ts  # synthetic-category generator
  fetch-wikipedia.ts   # multilingual prose fetcher
  generate-images.ts   # PNG sample generator (sharp)
```
