"""Token-counting utilities backed by LangChain's first-party token APIs.

Three callables form the public surface:

* :func:`count_tokens_with_model` — exact-as-the-model-allows count via
  ``BaseChatModel.get_num_tokens_from_messages``. Returns
  ``(count, is_exact)``: ``is_exact`` is ``False`` when the model raises
  one of the documented no-op exceptions (``NotImplementedError``,
  ``AttributeError``, ``TypeError``, ``ImportError``) and the path
  silently degraded to :func:`approximate_token_count`. Other exceptions
  propagate. Returning the flag — instead of swallowing the fallback —
  is what lets the cycle-local cache surface fallback drift to the
  caller via :attr:`TokenCountCache.is_exact`.

* :func:`approximate_token_count` — fast first-party LangChain heuristic
  via :func:`langchain_core.messages.utils.count_tokens_approximately`.
  Already accounts for per-message role/framing overhead, AI tool-call
  payloads, ToolMessage ``tool_call_id``, multi-modal image penalty, and
  optional tool-schema overhead — strictly better than the legacy
  hand-written ``len(content) // 4`` heuristic the wrapper used previously.

* :func:`estimate_token_count` — unified entry point preserved for
  backwards compatibility. With ``model=None`` it delegates to
  :func:`approximate_token_count`; with a non-``None`` model it delegates
  to :func:`count_tokens_with_model` and discards the ``is_exact`` flag.
  Callers that care about exactness must reach for the underlying
  primitive directly (or use :class:`TokenCountCache.is_exact`).

:class:`TokenCountCache` — cycle-local cache wrapping any of the above so
that the prune orchestrator (and the rule loop / post-guard recount) does
not re-tokenize the same messages multiple times in a single compaction
cycle. The cache is exposed as a callable that accepts ``Sequence[BaseMessage]``
and returns ``int``, matching the shape callers expect from a token counter.

Two cache properties surface the model-backing semantics separately so
callers can choose the right predicate for their use case:

* :attr:`TokenCountCache.has_model_backing` — static "is a model wired?"
  predicate suitable for pre-flight configuration checks (e.g. RECOUNT
  mode rejecting an approximate-only counter).
* :attr:`TokenCountCache.is_exact` — runtime "have all counts so far
  stayed on the model-backed path?" telemetry. Becomes ``False``
  permanently the first time a model call falls back to approximate so
  operators can detect silent degradation.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, Final

from langchain_core.messages.utils import count_tokens_approximately

from omne_core_v1.logging import get_logger

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel
    from langchain_core.messages import BaseMessage

__all__ = [
    "TokenCountCache",
    "TokenCounter",
    "approximate_token_count",
    "count_tokens_with_model",
    "estimate_token_count",
]

_logger = get_logger(__name__)

TokenCounter = Callable[[Sequence["BaseMessage"]], int]
"""Public signature for a token-counter callable.

Any callable mapping a sequence of LangChain messages to a non-negative
integer token estimate satisfies the interface — the prune orchestrator
and the per-rule ``estimate_savings`` helpers consume the type-alias to
decouple themselves from the concrete counting implementation.
"""

# Documented no-op exception set for ``BaseChatModel.get_num_tokens_from_messages``.
#
# These four are the "this provider does not implement model-side counting"
# signals that production providers actually raise; everything else is
# treated as a real failure and propagates so callers see it instead of
# silently falling back.
#
# ``ImportError`` covers adapters whose default counter delegates to a
# tokenizer library (e.g. ``transformers``) that is not installed in the
# current environment — semantically identical to NotImplementedError
# from the caller's perspective.
_MODEL_FALLBACK_EXCEPTIONS: Final[tuple[type[BaseException], ...]] = (
    NotImplementedError,
    AttributeError,
    TypeError,
    ImportError,
)


def approximate_token_count(messages: Sequence[BaseMessage]) -> int:
    """Return LangChain's approximate token count for *messages*.

    Delegates to :func:`langchain_core.messages.utils.count_tokens_approximately`
    so the count includes — out of the box — per-message role overhead,
    AIMessage tool-call payload stringification, ToolMessage ``tool_call_id``,
    and a fixed token penalty for multi-modal image blocks. The returned
    value is therefore strictly closer to the true prompt cost than a
    hand-rolled ``len(content) // 4`` estimate, while remaining fast
    enough for hot-path use (no I/O, no model invocation).

    Args:
        messages: Any LangChain message sequence (subtype-friendly — e.g.
            ``list[HumanMessage]`` is accepted without widening).

    Returns:
        Non-negative integer approximation of the prompt-token count.
    """
    return int(count_tokens_approximately(list(messages)))


def count_tokens_with_model(messages: Sequence[BaseMessage], model: BaseChatModel) -> tuple[int, bool]:
    """Return ``(count, is_exact)`` for *messages* via the model's own counter.

    Calls ``model.get_num_tokens_from_messages(list(messages))``. The four
    no-op exception types in :data:`_MODEL_FALLBACK_EXCEPTIONS` trigger a
    fallback to :func:`approximate_token_count` and the returned tuple's
    second element flips to ``False`` so callers can detect the silent
    degradation. Any other exception propagates unchanged so genuine
    runtime errors are not swallowed.

    Args:
        messages: LangChain message sequence to count.
        model: A LangChain ``BaseChatModel``-shaped adapter exposing
            ``get_num_tokens_from_messages``. Must not be ``None`` —
            callers without a model should call
            :func:`approximate_token_count` directly.

    Returns:
        ``(count, is_exact)``. ``is_exact`` is ``True`` only when the
        model's own counter produced the value; ``False`` indicates the
        approximate fallback was used.
    """
    try:
        counter = model.get_num_tokens_from_messages
    except AttributeError:
        _logger.debug(
            "compaction.token_count.fallback",
            reason="missing_get_num_tokens_from_messages",
        )
        return approximate_token_count(messages), False
    try:
        return int(counter(list(messages))), True
    except _MODEL_FALLBACK_EXCEPTIONS as exc:
        _logger.warning(
            "compaction.token_count.fallback",
            reason=type(exc).__name__,
            error_message=str(exc),
        )
        return approximate_token_count(messages), False


def estimate_token_count(
    messages: Sequence[BaseMessage],
    *,
    model: BaseChatModel | None = None,
) -> int:
    """Return a token-count estimate for *messages*.

    Unified backwards-compatible entry point. Routes to
    :func:`count_tokens_with_model` when a model is supplied (discarding
    the ``is_exact`` flag — callers needing fallback observability must
    use :class:`TokenCountCache`) and to :func:`approximate_token_count`
    otherwise.

    Args:
        messages: LangChain message sequence to count.
        model: Optional ``BaseChatModel``. When ``None`` the approximate
            heuristic is used; when supplied the model's own counter is
            consulted first with a graceful fallback to the approximate
            heuristic on documented no-op exceptions.

    Returns:
        Non-negative integer token estimate.
    """
    if model is None:
        return approximate_token_count(messages)
    count, _is_exact = count_tokens_with_model(messages, model)
    return count


def _content_fingerprint(message: BaseMessage) -> int:
    """Return a stable fingerprint for *message*'s tokenizable surface.

    Captures the fields that influence ``approximate_token_count`` /
    ``get_num_tokens_from_messages``: ``content`` (str or list-of-blocks),
    AIMessage ``tool_calls``, ToolMessage ``tool_call_id``, and the
    optional ``name`` attribute (FunctionMessage / OpenAI function-call
    style). Cache correctness depends on every input that affects the
    resulting token count being represented in this fingerprint —
    omitting ``name`` would cause two messages with identical content but
    different speaker / function names to collide in the cache and
    return the same per-message count even though tokenizers charge
    different amounts for the role / name field.
    """
    content = message.content
    if isinstance(content, str):
        content_hash = hash(("str", content))
    elif isinstance(content, list):
        # Multi-modal blocks: hash the canonical repr to avoid mutating dict ordering issues.
        content_hash = hash(("list", repr(content)))
    else:
        content_hash = hash(("other", repr(content)))
    tool_calls = getattr(message, "tool_calls", None)
    tool_call_id = getattr(message, "tool_call_id", None)
    name = getattr(message, "name", None)
    return hash((message.__class__.__name__, content_hash, repr(tool_calls), tool_call_id, name))


class TokenCountCache:
    """Cycle-local cache wrapping a token counter for repeated message lookups.

    The cache is the canonical token counter the prune orchestrator hands
    to its rules: a single instance is constructed at the start of each
    compaction cycle and threaded through ``PruneInput.token_counter`` so
    every rule's ``estimate_savings`` and the orchestrator's watermark
    recount share results without re-tokenizing.

    Behaviour:

    * ``__call__(messages)`` sums per-message cached counts. The first
      time a message ``(class, content, tool_calls, tool_call_id, name)``
      shape is encountered the cache asks the underlying counter for the
      single-message count, stores it under the message fingerprint, and
      returns it on subsequent lookups. Used by the per-rule
      ``estimate_savings`` overrides — per-message granularity matches
      the per-candidate token-delta computation pattern those rules
      apply, where the fixed per-message overhead cancels out in the
      ``original - replacement`` subtraction.

    * :meth:`count_full_sequence` issues a single sequence-level call
      against the underlying counter (or LangChain's approximate
      heuristic when no model is wired) and returns the result. This
      bypasses the per-message cache so provider-side chat-format
      overhead (start / stop tokens, role separators) is captured
      exactly once for the full message list — used by the watermark
      initial estimate, the RECOUNT mode recount after each rule, and
      the post-guard final recount inside ``apply_prune``.

    * :attr:`has_model_backing` reports whether the cache has a model
      wired (the static configuration predicate). Pre-flight checks
      that need a yes/no answer about counter capability — for
      example, RECOUNT mode rejecting an approximate-only counter —
      consult this property.

    * :attr:`is_exact` reports whether every count issued so far has
      stayed on the model-backed path. Becomes ``False`` permanently
      the first time the model's counter raises one of the documented
      no-op exceptions and the cache silently fell back to the
      approximate heuristic. Operators inspect this property to detect
      silent degradation; the pre-flight check intentionally does NOT
      consult it because configuration-time correctness cannot be
      undermined by runtime fallback drift.

    The cache is *not* thread-safe; it is intentionally bound to a single
    compaction cycle which runs serially within one async task.
    """

    __slots__ = ("_any_fallback", "_model", "_per_message")

    def __init__(self, *, model: BaseChatModel | None = None) -> None:
        """Construct an empty cache bound to *model*.

        Args:
            model: Optional ``BaseChatModel``. When supplied, single-message
                counting goes through :func:`count_tokens_with_model`;
                otherwise :func:`approximate_token_count` is used directly.
        """
        self._model = model
        self._per_message: dict[int, int] = {}
        self._any_fallback: bool = False

    @property
    def has_model_backing(self) -> bool:
        """Whether the cache was constructed with a model.

        Static configuration predicate — does NOT reflect runtime
        fallback drift (use :attr:`is_exact` for that). Pre-flight
        checks that need to reject approximate-only callers (RECOUNT
        mode) consult this property because the runtime fallback is a
        graceful degradation, not a configuration error.
        """
        return self._model is not None

    @property
    def is_exact(self) -> bool:
        """Whether every count issued so far has stayed model-backed.

        Becomes ``False`` permanently the first time the model's
        counter raises one of the documented no-op exceptions. Useful
        for telemetry and post-cycle assertions; pre-flight checks
        should use :attr:`has_model_backing` instead because the
        model-fallback transition can happen mid-cycle and is
        intentionally non-fatal.
        """
        return self._model is not None and not self._any_fallback

    @property
    def size(self) -> int:
        """Number of distinct message fingerprints currently cached."""
        return len(self._per_message)

    def __call__(self, messages: Sequence[BaseMessage]) -> int:
        """Return the cached or freshly computed per-message token sum.

        Per-message counts are summed. The per-message overhead
        (``extra_tokens_per_message`` in the LangChain heuristic) is
        therefore double-counted at most once per distinct message — which
        matches the orchestrator's needs for per-rule delta estimation
        because the same overhead lives on both the original message
        and its replacement, cancelling in the subtraction.

        For sequence-level counting where chat-format overhead must be
        captured exactly once across the full list (watermark / post-
        guard / RECOUNT recount), use :meth:`count_full_sequence`
        instead.
        """
        total = 0
        for message in messages:
            fingerprint = _content_fingerprint(message)
            cached = self._per_message.get(fingerprint)
            if cached is None:
                cached = self._count_single(message)
                self._per_message[fingerprint] = cached
            total += cached
        return total

    def count_full_sequence(self, messages: Sequence[BaseMessage]) -> int:
        """Return a sequence-level token count for *messages*.

        Single counter invocation against the full message list — when
        model-backed this captures the provider's chat-format overhead
        (start / stop tokens, message separators, role headers) exactly
        once instead of multi-counting it through per-message
        accumulation. Approximate-only callers fall through to
        :func:`approximate_token_count` which already issues a single
        sequence-level call.

        Intentionally uncached: the surviving message list shrinks
        after every prune action, so cache hits would be rare and the
        memory cost would only mask the recount semantics this method
        exists to provide.

        Side effect: when a model-backed call falls back to approximate
        (per :data:`_MODEL_FALLBACK_EXCEPTIONS`) the cache flips
        :attr:`is_exact` to ``False`` for the remainder of its life so
        operators see the silent degradation surface as telemetry.
        """
        if self._model is None:
            return approximate_token_count(messages)
        count, is_exact = count_tokens_with_model(messages, self._model)
        if not is_exact:
            self._any_fallback = True
        return count

    def _count_single(self, message: BaseMessage) -> int:
        """Count the tokens for a single *message*, model-backed when available."""
        if self._model is None:
            return approximate_token_count([message])
        count, is_exact = count_tokens_with_model([message], self._model)
        if not is_exact:
            self._any_fallback = True
        return count
