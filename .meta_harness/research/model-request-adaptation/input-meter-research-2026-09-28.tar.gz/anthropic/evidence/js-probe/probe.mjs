import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { Tiktoken } from 'js-tiktoken/lite';
const resultURL = new URL('../probe-result.json', import.meta.url);
const result = JSON.parse(readFileSync(resultURL,'utf8'));
if (!process.argv[2]) throw new Error('Pass absolute project checkout root as argv[2]');
const bytes = readFileSync(resolve(process.argv[2], 'packages/model/pi-ai-transport/tokenizers/anthropic-legacy/claude.json'));
// Fail closed on the exact artifact used in the project baseline.
if(createHash('sha256').update(bytes).digest('hex') !== '58dad83d85e9cd57be209172449ebfbc395df2b455c11fe8b7e5b661e6f462ad') throw new Error('artifact mismatch');
const enc = new Tiktoken(JSON.parse(bytes));
for(const row of result.synthetic){
 row.utf16_length = row.text.length;
 row.legacy_text_only = enc.encode(row.text.normalize('NFKC'),'all').length;
 row.pi_text_formula = Math.ceil(row.text.length/4);
 row.opencode_text_formula = Math.max(0,Math.round(row.text.length/4));
}
result.js_runtime = process.version;
result.js_tiktoken = '1.0.21';
writeFileSync(resultURL,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result.synthetic,null,2));
