"""Fetch only pinned ctok probe inputs. No credentials or inference requests."""
import hashlib,json,pathlib,urllib.request
root=pathlib.Path(__file__).parent
for entry in json.loads((root/'ctok-fetch-manifest.json').read_text()):
    relative=pathlib.PurePosixPath(entry['file'])
    if relative.is_absolute() or '..' in relative.parts or relative.parts[0]!='ctok-runtime':
        raise ValueError('unexpected destination')
    output=root/relative
    data=urllib.request.urlopen(entry['url'],timeout=30).read()
    if hashlib.sha256(data).hexdigest()!=entry['sha256']:
        raise ValueError(f'hash mismatch: {relative}')
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_bytes(data)
print('ctok pinned runtime and fixture files fetched and hash-verified')
