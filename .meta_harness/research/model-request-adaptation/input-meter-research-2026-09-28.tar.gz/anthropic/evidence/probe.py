"""Offline reproduction; never reads credentials, never calls an inference API."""
import gzip,json,pathlib,sys,time
ROOT=pathlib.Path(__file__).parent
sys.path.insert(0,str(ROOT/'ctok-runtime'))
from ctok import token_count
import regex
rows=[('english','Please summarize the changes and explain why each decision was made.'),('chinese','请解释这段代码的输入输出、错误处理和生命周期，并给出可以复现的验证步骤。'),('code','export async function read(id: string) {\n  const value = await store.get(id);\n  if (!value) throw new Error(`missing ${id}`);\n  return value;\n}\n'),('tool_schema_json',json.dumps({'type':'function','function':{'name':'read_file','description':'读取文件内容','parameters':{'type':'object','properties':{'path':{'type':'string'}},'required':['path']}}},ensure_ascii=False,separators=(',',':'))),('multi_turn_json',json.dumps({'messages':[{'role':'system','content':'Be concise.'},{'role':'user','content':'你好'},{'role':'assistant','content':'你好！'},{'role':'user','content':'Explain this function.'}]},ensure_ascii=False,separators=(',',':')))]
out={'scope':'synthetic rows have NO official ground truth; schema/multi-turn are literal JSON strings, NOT actual request token counts','python':sys.version,'regex':regex.__version__,'synthetic':[],'fixture_source':'sanderland/ctok@8c43ffd3c7be467622a540f025516e49ef78d8b1; author-recorded historical count_tokens, not independently called','fixtures':[]}
for name,text in rows:
 out['synthetic'].append(dict(name=name,text=text,ctok47_single_user=token_count(text,'4.7'),ctok48_single_user=token_count(text,'4.8'),ctok50_single_user=token_count(text,'5.0'),ctok55_single_user=token_count(text,'5.5')))
counts=json.loads((ROOT/'ctok-runtime/tests/fixtures/multipl_e_counts.json').read_text());start=time.perf_counter()
with gzip.open(ROOT/'ctok-runtime/tests/fixtures/multipl_e.jsonl.gz','rt') as f:
 for line in f:
  r=json.loads(line); item={'lang':r['lang']}
  for family,version in [('v3','3.0'),('v4.7','4.7'),('v5','5.0')]:
   got=token_count(r['text'],version);want=counts[family]['counts'][r['lang']];item[family]={'got':got,'recorded':want,'delta':got-want}
  out['fixtures'].append(item)
out['fixture_elapsed_seconds']=time.perf_counter()-start
out['images']={'ctok':'unsupported: text-only single-user API','legacy_project_meter':'unavailable for image_url parts','pi':'fixed 1200 tokens per image; actual image pixels not measured','opencode':'JSON character heuristic; not a vision tokenizer'}
(ROOT/'probe-result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({'fixture_rows':len(out['fixtures']),'exact_by_family':{fam:sum(r[fam]['delta']==0 for r in out['fixtures']) for fam in ['v3','v4.7','v5']},'elapsed_s':out['fixture_elapsed_seconds'],'synthetic':out['synthetic']},ensure_ascii=False,indent=2))
