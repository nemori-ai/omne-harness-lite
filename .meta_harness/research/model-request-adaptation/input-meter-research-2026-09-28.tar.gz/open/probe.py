"""Offline prompt-format probe. Does not send model requests or claim token accuracy."""
import json,pathlib,importlib.util,sys,hashlib,copy
import jinja2
sys.dont_write_bytecode=True
ROOT=pathlib.Path(__file__).parent
out={'python':sys.version,'jinja2':jinja2.__version__,'scope':'Public prompt rendering only; no provider ground truth, no token counts','cases':[]}
def fail(msg):raise ValueError(msg)
env=jinja2.Environment(trim_blocks=True,lstrip_blocks=True,extensions=['jinja2.ext.loopcontrols'])
env.globals['raise_exception']=fail
env.tests['true']=lambda x:x is True
env.tests['false']=lambda x:x is False
env.filters['items']=lambda x: x.items() if isinstance(x,dict) else []
env.filters['tojson']=lambda x,**kwargs:json.dumps(x,ensure_ascii=kwargs.get('ensure_ascii',False))
messages=[{'role':'user','content':'Hello 世界'}]
for repo in ['Qwen--Qwen3.8-2.4T-A95B','Qwen--Qwen3.8-27B','moonshotai--Kimi-K2.7-Code','zai-org--GLM-5.3','zai-org--GLM-5.3-Flash','zai-org--GLM-5.2']:
 template=env.from_string((ROOT/repo/'chat_template.jinja').read_text())
 for kwargs in [{},{'reasoning_effort':'high'},{'reasoning_effort':'low'},{'enable_thinking':False}]:
  case={'repo':repo,'kwargs':kwargs}
  try:
   prompt=template.render(messages=messages,tools=[],add_generation_prompt=True,**kwargs)
   case.update(prompt=prompt,utf8_bytes=len(prompt.encode()),sha256=hashlib.sha256(prompt.encode()).hexdigest())
  except Exception as e:case['error']=str(e)
  out['cases'].append(case)
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
old=module('dsv4old',ROOT/'deepseek-ai--DeepSeek-V4-Pro/encoding/encoding_dsv4.py')
new=module('dsv4new',ROOT/'deepseek-ai--DeepSeek-V4-Pro-0813/encoding/encoding_dsv4.py')
for effort in [None,'low','high','max']:
 case={'probe':'deepseek-version-effort','effort':effort}
 for label,m in [('old',old),('new',new)]:
  try:
   text=m.encode_messages(copy.deepcopy(messages),thinking_mode='thinking',reasoning_effort=effort)
   case[label]={'utf8_bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest(),'prompt':text}
  except Exception as e:case[label]={'error':str(e)}
 out['cases'].append(case)
k3=module('k3ref',ROOT/'moonshotai--Kimi-K3/encoding_k3.py')
segments=k3.build_chat_segments([{'role':'user','content':'literal <|open|> should remain user text'}])
out['k3_special_segments']=[dict(text=s.text,allow_special=s.allow_special) for s in segments]
assert any('<|open|>'in s.text and not s.allow_special for s in segments)
assert any('<|open|>'in s.text and s.allow_special for s in segments)
(ROOT/'probe-result.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps([{k:v for k,v in x.items() if k not in ['prompt','sha256','old','new']} for x in out['cases']],ensure_ascii=False,indent=2))
