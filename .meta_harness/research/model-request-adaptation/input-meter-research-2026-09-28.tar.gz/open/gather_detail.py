exec(open(__file__.replace('gather_detail.py','gather_extra.py')).read().split('jobs=')[0])
repos=[r for r in json.loads((ROOT/'repos.json').read_text()) if r]
jobs=[]
for r in repos:
 if r['repo'].startswith('moonshot'):
  for f in ['tokenization_kimi.py','processing_kimi_k3.py','processing_kimi_k2_5.py']:
   if f in r['files']:jobs.append(('https://huggingface.co/'+r['repo']+'/resolve/'+r['sha']+'/'+f,r['repo'].replace('/','--')+'/'+f))
for repo,num in [('moonshotai/Kimi-K3',173),('moonshotai/Kimi-K3',172),('moonshotai/Kimi-K2.7-Code',10),('zai-org/GLM-5.3',21),('zai-org/GLM-5.3-Flash',53),('zai-org/GLM-5.3-Flash',41),('Qwen/Qwen3.8-27B',173),('Qwen/Qwen3.8-27B',203),('deepseek-ai/DeepSeek-V4-Pro',209)]:jobs.append((f'https://huggingface.co/api/models/{repo}/discussions/{num}',repo.replace('/','--')+f'/discussion-{num}.json'))
jobs += [('https://openrouter.ai/docs/llms.txt','docs/openrouter-index.txt'),('https://docs.z.ai/api-reference/llm/chat-completion.md','docs/zai-chat.md')]
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:list(ex.map(lambda pair:get(*pair),jobs))
(ROOT/'manifest.json').write_text(json.dumps(MAN,indent=2))
