# 四家公开模型计量来源核对（2026-09-28）

## 结论与范围

**17 个精确叶子中，9 个有对应公开模型仓编码资料；其余 8 个未找到可确认等同该商业叶子的公开仓。**9 个是 DeepSeek 两叶、Qwen 两个开源叶、Moonshot 两叶、ZAI 三叶。本次事实不能把任何 OpenRouter 路由提升为 exact，也不能给出误差率。未读取凭据或环境密钥、未发推理/计数 API 请求、未下载模型权重或 tokenizer 大文件、未修改 tracked 文件。

已有 DeepSeek 两个 meter 使用公开 tokenizer 和编码参考。当前 Flash 以每图额外 1024 tokens 估算；公开参考实际按尺寸算 image span，离线探针得到 544×544 为 184、1024×1024 为 652、1920×1080 为 968。**这是比固定 allowance 更细的公开模型计算来源，尚非实际 OpenRouter/DeepInfra 输入的真值。**Pro-0813 有精确仓，其 tokenizer 文件对象与旧 Pro 相同，编码器却新增 reasoning effort 行为；项目当前仅供 low/none，所以不能将公开 high/max 差异直接判为当前受支持请求误差。

Moonshot 官方 `estimate-token-count` 文档明确覆盖 K3 与 K2.7 Code。ZAI 有 tokenizer API，但取得的 OpenAPI model enum 仅列 GLM 4.6/4.6v/4.5，不能证明本任务 5.x 可用。阿里云找到的 OpenSearch token 计算服务列的是旧 qwen-turbo/plus/max，不能代替百炼 Qwen3.7/3.8 或 OpenRouter 的计数入口。OpenRouter 公开参考说明请求会转换，usage 使用模型原生 tokenizer；没有查到能把本任务路由先验算成最终 prompt token 数的通用端点。

## 基线与取证

执行树 `/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-meter-research-open`，分支 `panqiwei/model-request-runtime-meter-research-open`，HEAD `1b2a6a0b3236281f270aaf354457cf70177eceae`。清单从 `packages/model/pi-ai-transport/src/official-models/{deepseek,qwen,moonshot,zai}.ts` 读取，实施标识都是对应 `pi-ai:<family>@mp4-1`。本次输入目录仅提供 DeepSeek 两个本家专用 meter；其余 15 叶未提供随包专用 meter。调用者可注入 meter；本报告不假设每个消费者已有通用估算。

所有 HTTP 取证均是无认证 GET。HF `api/models/<repo>` 取得当前 commit，随后的模型文件均使用 `/resolve/<commit>/...` 固定地址。`manifest.json` 逐项记录 URL、UTC 取得时间、实际文件 SHA-256、大小及失败；`repos.json` 汇总 commit。`tree.json` 中 tokenizer 的 Git OID/LFS SHA 是 **上游元数据声明，未下载 tokenizer 字节独立复算**。大小上限每文件 3,000,000 bytes，没有下载 tokenizer.json/tiktoken.model。动态文档与讨论不能锁 commit，用取证时间和字节 SHA 保存其快照。

## 精确叶子矩阵

“公开可计”仅表示公开参考栈可还原的文本/工具/结构信息，不表示路由等值；多模态另需 processor 的尺寸、采样和拼接规则。型号简称的固定提交来源见下一表。

|精确 model ID|definition rev / provider|当前随包计量|公开资料与可行性边界|
|---|---|---|---|
|deepseek/deepseek-v4.1-flash|1 / deepinfra/fp8|专用 estimated|DS41 精确 tokenizer+Python encoder+image processor。当前编码源同 commit；图像尺寸法比固定 allowance 更细，但 serving 等值未知。|
|deepseek/deepseek-v4-pro-0813|2 / deepinfra/fp8|专用 estimated（旧 Pro 来源）|DS0813 精确仓；相同 tokenizer，不同 high/max effort 前缀；现有 low/none 子集未因此发现反例。|
|qwen/qwen3.8-max-0902|1 / alibaba|无本家专用|未找到精确公开仓。Qwen 2.4T card 明说商业 Max 增加视觉、非思考与内置工具，不能直接等同。|
|qwen/qwen3.8-max-prime|1 / alibaba|无本家专用|未找到精确公开仓；Prime 与公开 2.4T 的精确版本映射未知。|
|qwen/qwen3.8-flash|1 / alibaba|无本家专用|官方有 Flash-Next 仓，但无事实证明就是该商业 Flash；本次不替代。|
|qwen/qwen3.8-2.4t-a95b|1 / alibaba|无本家专用|Q24 精确 tokenizer+Jinja；文字与工具可按公开栈计。强制 thinking；公开 effort=low/medium/xhigh，与 OR 发 high/max 的服务端映射未知。|
|qwen/qwen3.8-27b|1 / alibaba|无本家专用|Q27 精确 tokenizer+Jinja+processor config；文字/工具公开可计，视觉和视频需预处理。支持禁思考；公开 effort 同上。|
|qwen/qwen3.7-max|1 / alibaba|无本家专用|官方 HF org 搜索 Qwen3.7 无返回；同名猜测仓请求401。只能写未发现/不可访问，不能证明不存在。|
|qwen/qwen3.7-plus|1 / alibaba|无本家专用|同上；视觉输入也不能用文本 tokenizer 单独量完。|
|qwen/qwen3.7-flash|1 / alibaba|无本家专用|同上；视频采样/图像展开未知。|
|moonshotai/kimi-k3|1 / moonshotai/mxfp4|无本家专用|K3 精确 tiktoken vocab+custom tokenizer+Python XTML；结构/用户文本特殊 token 权限分开，不能简单 flatten。官方计数 API明确列本型号；未验证 OR 等值。|
|moonshotai/kimi-k2.7-code|1 / moonshotai/int4|无本家专用|K27 精确 tiktoken vocab+custom tokenizer+Jinja+tool_declaration_ts.py；同词表不等于 K3 同格式。官方计数 API明确列本型号。|
|z-ai/glm-5.3|1 / z-ai/fp8|无本家专用|G53 精确 tokenizer+Jinja；effort low/high/默认max，官方确认不支持 non-thinking。|
|z-ai/glm-5.3-prime|1 / alibaba|无本家专用|未找到 Prime 精确仓；公开 G53 不能证明 Alibaba Prime 的模板和模型版本。|
|z-ai/glm-5.3-flash|1 / z-ai/fp8|无本家专用|GF53 精确 tokenizer+Jinja+processor config；图/视频不是占位符文字的 token 数。|
|z-ai/glm-5.3-flashx|1 / z-ai/fp8|无本家专用|未找到 FlashX 精确仓；公开 Flash 不能证明 FlashX 同模型和预处理。|
|z-ai/glm-5.2|1 / z-ai/fp8|无本家专用|G52 精确 tokenizer+Jinja。与5.3共享 tokenizer blob，但模板禁思考行为不同。|

## 固定源与许可

|代号|一手模型仓固定修订|许可原件读数|
|---|---|---|
|DS41|[DeepSeek-V4.1-Flash](https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash/tree/dba1be0a40aa45a94ad051997016db3960a90277)|MIT|
|DSOld|[DeepSeek-V4-Pro](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/tree/b5968e9190ef611bbf34a7229255be88a0e937c1)|MIT|
|DS0813|[DeepSeek-V4-Pro-0813](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro-0813/tree/72e1d3230f6c080a530b0a1d46f8eb4602340597)|MIT|
|Q24|[Qwen3.8-2.4T-A95B](https://huggingface.co/Qwen/Qwen3.8-2.4T-A95B/tree/207bd685a7e3696cfaff12ded7c6a7ea0f88c996)|Qwen3.8-Max 自定义；含规模署名及 MaaS/AI Work Assistant 商业许可条件，不能简称 MIT。|
|Q27|[Qwen3.8-27B](https://huggingface.co/Qwen/Qwen3.8-27B/tree/1d4bf0f2ff6012fd82039f2fa52739d0dd7c60c0)|Apache-2.0|
|K3|[Kimi-K3](https://huggingface.co/moonshotai/Kimi-K3/tree/f831ab66814297da540d832a5235f8e904f29d06)|Kimi K3 自定义；含 MaaS 收入门槛、规模署名以及内部/官方或认证推理伙伴访问例外。|
|K27|[Kimi-K2.7-Code](https://huggingface.co/moonshotai/Kimi-K2.7-Code/tree/74797c9c62378b951a1f6fcf5c4631024e9b8bef)|Modified MIT；新增规模达到阈值后的型号显示条件。|
|G53|[GLM-5.3](https://huggingface.co/zai-org/GLM-5.3/tree/aca966e4e02791568aa6a4ced368624b3d897f42)|GLM-5.3 自定义；包括极高收入 MaaS 经营者安全审查条件。|
|GF53|[GLM-5.3-Flash](https://huggingface.co/zai-org/GLM-5.3-Flash/tree/eb9eb208eb0d988989d07a6a12d0fdeb5f52574a)|MIT|
|G52|[GLM-5.2](https://huggingface.co/zai-org/GLM-5.2/tree/cf457fa734ab149ffef225f80893eb38c6ff5cdc)|MIT|

这是许可文本内容记录，不是本项目适用性裁决。Q24/K3/G53 明文把 configuration/inference code/docs 纳入 Software，不能只看模型页面“开放权重”就认为 tokenizer/模板脱离许可。每仓 `LICENSE` 原件与 SHA 已存。

## 已有来源与更精细来源的区别

1. **DeepSeek Flash**：`encoding/encoding.py` 渲染特殊标记、工具/历史 reasoning、数值 effort；`inference/image_processor.py::prepare_vl_inputs` 把 image placeholder 替换为 `h*(w+1)+2` image span。当前 meter 已用该 encoder 但图像按固定 1024 加算，且 supplemental 将请求元数据 JSON 也计入估算。尺寸法能更精确复现公开参考；真实图片方向/解码、上游缩放配置及 private request projection 仍是缺口，不能证明总请求上界。
2. **DeepSeek Pro-0813**：两仓 `tokenizer_config.json` SHA-256 均为 `6ac8c8dc065ed118161d02dd532749ae3f52c243deac27872134fae2f50d8547`；tree 中 tokenizer Git OID 同为 `628e3364caad11bdf9e67cea06eae7878122811d`。0813 编码源码 SHA-256 `abc0d26120250dda0ae077dc64aa28836026e61e970854aaeb792445e6a0dde6`。官方公开差异是 effort 前缀，不是已证明 tokenizer 更换。
3. **Qwen**：Q24/Q27 的 tokenizer.json 都是 12,809,320 bytes，LFS SHA `0997f410c57a1f4e53b09e4be8f4a172d90edd9564368fb0847030937229b9f3`；模板、许可与模态不同。两个公开模板都会因 `reasoning_effort='high'` 抛错，而本仓 OR route 暴露 high/max——需要知道 serving 的映射，不能把 wire 值原样送入公开模板并称完成计量。Q24 Max 商业变体关系是作者明示，但不足以量出 -0902/Prime 的最终输入。
4. **Moonshot**：K3/K27 的 tiktoken.model 上游均标 2,795,286 bytes、LFS SHA `b6c497a7469b33ced9c38afb1ad6e47f03f5e5dc05f15930799210ec050c5103`，custom tokenizer/格式却不同。K3 `EncodeSegment.allow_special` 区分结构和正文，工具参数、response schema、结果重排均进入 XTML。K27 Jinja 工具声明还有额外 Python helper，单拿 vocab 不够。不能拿旧 K2 字符比例替代上述精确资料。
5. **ZAI**：G52/G53/GF53 tokenizer.json 上游都标 20,217,442 bytes、LFS SHA `19e773648cb4e65de8660ea6365e10acca112d42a854923df93db4a6f333a82d`；模板、模态和许可不同。5.3 的 reasoning retention、tool results 分组等影响输入。公开词表相同只减少词法未知，不消除模板与 serving 未知。

## 官方计数 API 与 OpenRouter 边界

- [Moonshot Estimate Tokens](https://platform.kimi.ai/docs/api/estimate)：POST `/v1/tokenizers/estimate-token-count`，Bearer Moonshot key；支持 K3/K2.7 Code，示例含图片。文档称 estimate，messages 结构几乎同 chat completion；OpenAPI 与页面 body 不给出 tools/reasoning 的完整等值保证。未调用，未验证错误行为和计费；此端点不使用 OR key，不能把直接 Moonshot 请求当成 OR 通路已提供的能力。
- [ZAI OpenAPI](https://docs.z.ai/openapi.json)：POST `/paas/v4/tokenizer` 收 messages/tools，响应有 prompt/image/video/total tokens；`TokenizerRequest.model.enum` 只有旧三型号。本次只能证明 API 存在，不能证明 GLM5.x 可用或不存在未文档化支持。
- [阿里 OpenSearch Token 计算](https://help.aliyun.com/zh/open-search/search-platform/developer-reference/token-calculation)：服务清单为 ops-qwen-turbo、qwen-turbo/plus/max，要求该产品凭据。不是本任务八个百炼叶子的覆盖证据。检索百炼 token 计算、tokenizer、Qwen3.8 关键词未找到覆盖精确叶子的独立官方计数入口；是检索缺口结论，不是不存在证明。
- [DeepSeek Token Usage](https://api-docs.deepseek.com/quick_start/token_usage/) 指向离线 demo tokenizer、提醒模型分词不同；该页面不能替代 V4.1/0813 的固定仓版本。未找到覆盖本任务两个 OR/DeepInfra 叶子的官方远程预计数保证。
- [OpenRouter API reference](https://openrouter.ai/docs/api/reference/overview) 说明请求字段会转换，工具可能映射为提供商形式，某些路径会用 YAML；usage 原生计数与 generation stats 是**请求完成后**信息。`debug.echo_upstream_body` 是 transformed body 观察点，并非 provider 内部最终 prompt token 序列。检索官方 llms index/overview 未发现适用这些路由的通用 count endpoint；不据此断言所有私有能力不存在。

## 负面资料和局限

这部分区分作者确认、源码观测和社区报告；社区报告仅提示复核方向。

- [GLM5.3 #21](https://huggingface.co/zai-org/GLM-5.3/discussions/21)：官方组织成员确认不支持 non-thinking，模板用 effort 而非 enable_thinking。这与公开模板和离线输出一致；不能沿用5.2假定。
- [GLM5.3 Flash #53](https://huggingface.co/zai-org/GLM-5.3-Flash/discussions/53)：官方成员说视频 codec 支持依赖 backend/FFmpeg build。这是“相同模型”不等于“相同媒体预处理”的直接边界证据。
- [GLM5.3 Flash #41](https://huggingface.co/zai-org/GLM-5.3-Flash/discussions/41)：effort 名字跨 harness 不匹配的问题尚在讨论；不以调用方常见枚举推导模板已有映射。
- [Kimi K3 #172](https://huggingface.co/moonshotai/Kimi-K3/discussions/172)：公开视频 processor 支持 PR 尚 open，作者对全视频 patch budget 还是每 chunk budget 有待确认问题，无官方确认。本次已抓实际 processor 原件；不能把 PR 未合并代码当当前正式计量。
- [Kimi K3 #173](https://huggingface.co/moonshotai/Kimi-K3/discussions/173) 为官方编码更新、已合并；固定 commit 很重要，不能只缓存仓名。
- [Qwen27B #173](https://huggingface.co/Qwen/Qwen3.8-27B/discussions/173)：medium 不插前缀的疑问；回复者非官方，结论由本次实际模板可见分支支持，不采其身份作权威。
- DeepSeek 编码 README 明确输出 parser 只处理良构输出。[旧 Pro #209](https://huggingface.co/deepseek-ai/DeepSeek-V4-Pro/discussions/209) 是用户报告 DSML 输出未结构化的问题；未独立复现、不是本任务0813/DeepInfra计数偏差证据。
- [Kimi2.7 #10](https://huggingface.co/moonshotai/Kimi-K2.7-Code/discussions/10) 社区报告 Together/OpenCode tool ID 问题；只读作 serving 格式可能不同的线索，不调查 OpenCode（另一路负责），不推广到指定 Moonshot route。

开放资料的代价：需要固定词表/模板/processor 多件版本，严格保留 JSON/特殊 token/历史 reasoning/tool grouping 语义；多媒体还依赖解码与采样，不是下载一个词表即可。无需权重能跑文字参考编码，但当前环境无 transformers/tokenizers/tiktoken，故本次不安装完整栈。上述任何候选的真实性能、OR 偏差分布和运行成本均未测。

## 离线探针与复现

`probe.py` 实际跑了 24 个 Jinja 选项用例、4 个 DeepSeek 版本/effort 对比和1个 K3特殊标记断言。Python 3.12.13 + 系统 Jinja2 2.10.1；由于系统旧 Jinja 缺少 true/false test 与 items filter，探针添加对应简单语义 helper。只检查给定消息的渲染，不声称整个 transformers 模板环境等价。结果 `probe-result.json` 明确记录 **UTF-8 bytes，不是 tokens**。

```sh
PYTHONPATH=/usr/lib/python3/dist-packages python3.12 tmp/open-family-token-counting-20260928/probe.py
python3.12 tmp/open-family-token-counting-20260928/probe_image.py
```

第二个探针以 AST 只抽取 pinned image_processor.py 的五个纯数学函数，使用 pinned inference/config.json，不加载 torch/Pillow、不读图像、不发网络。`probe-image-result.json` 显示上述尺寸对应的参考 image span；边界是已知实际输入尺寸、官方原样配置且相同预处理。没有上游真值，所以报告没有误差率。

`gather.py`/`gather_extra.py`/`gather_detail.py`/`gather_final.py` 可重新取证；重新取得 HEAD 可能改变，所以核本报告时以既存 manifest 中 fixed URL/sha 为准。执行 `git status --short` 为空；全部产物在授权 tmp。本报告只提供事实/限制和候选信息，不接受任何项目方案。
