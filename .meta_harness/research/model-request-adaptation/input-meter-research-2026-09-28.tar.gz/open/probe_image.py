"""Execute only pure sizing functions extracted from pinned upstream source by AST."""
import ast,json,pathlib,math,types
p=pathlib.Path(__file__).parent/'deepseek-ai--DeepSeek-V4.1-Flash/inference'
names={'num_image_tokens','llm_grid','solve_resize_ratio','safe_resize','plan_image_grid'}
tree=ast.parse((p/'image_processor.py').read_text())
subset=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[])
ns={'math':math};exec(compile(subset,str(p/'image_processor.py'),'exec'),ns)
conf=json.loads((p/'config.json').read_text());args=types.SimpleNamespace(**conf)
rows=[]
for w,h in [(1,1),(544,544),(1024,1024),(1920,1080),(4000,3000)]:
 nh,nw,bh,bw=ns['plan_image_grid'](w,h,args)
 rows.append(dict(width=w,height=h,grid=[nh,nw],resized=[bw,bh],public_image_span_tokens=ns['num_image_tokens'](nh,nw),current_meter_additional_image_allowance=1024))
out={'scope':'Public reference dimensions only. Full image decoding/orientation and OpenRouter/DeepInfra are not executed. Main prompt placeholder must be replaced, not double-counted.','rows':rows}
(pathlib.Path(__file__).parent/'probe-image-result.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
