import urllib.request,urllib.error,json,hashlib,pathlib,datetime,concurrent.futures
ROOT=pathlib.Path(__file__).parent
MAN=[]
def get(url,name,limit=3_000_000):
    stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'token-counting-research/1'}),timeout=45) as r:
            data=r.read(limit+1)
            if len(data)>limit: raise ValueError('size limit exceeded')
        p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        MAN.append({'url':url,'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'fetched_at':stamp})
        return json.loads(data) if name.endswith('.json') else data.decode()
    except Exception as e:
        MAN.append({'url':url,'path':name,'error':str(e),'fetched_at':stamp});return None
repos=['deepseek-ai/DeepSeek-V4.1-Flash','deepseek-ai/DeepSeek-V4-Pro','deepseek-ai/DeepSeek-V4-Pro-0813','Qwen/Qwen3.8-2.4T-A95B','Qwen/Qwen3.8-27B','Qwen/Qwen3.8-Max','Qwen/Qwen3.8-Flash','Qwen/Qwen3.7-Max','Qwen/Qwen3.7-Plus','Qwen/Qwen3.7-Flash','moonshotai/Kimi-K3','moonshotai/Kimi-K2.7-Code','zai-org/GLM-5.3','zai-org/GLM-5.3-Flash','zai-org/GLM-5.2']
def repo_work(repo):
    slug=repo.replace('/','--'); meta=get('https://huggingface.co/api/models/'+repo,slug+'/metadata.json')
    if not meta:return
    sha=meta['sha'];files=[x['rfilename'] for x in meta.get('siblings',[])]
    wanted=[f for f in files if f.lower() in ['readme.md','license','license.txt','tokenizer_config.json','chat_template.jinja','special_tokens_map.json','preprocessor_config.json','processor_config.json'] or (f.startswith('encoding/') and f.endswith(('.py','.md','.json','.jinja'))) or f.startswith('encoding_')]
    for f in wanted:get('https://huggingface.co/'+repo+'/resolve/'+sha+'/'+f,slug+'/'+f)
    return {'repo':repo,'sha':sha,'files':files,'selected':wanted,'license':meta.get('cardData',{}).get('license')}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:results=list(ex.map(repo_work,repos))
(ROOT/'repos.json').write_text(json.dumps(results,indent=2))
(ROOT/'manifest.json').write_text(json.dumps(MAN,indent=2))
for r in results:
    if r: print(r['repo'],r['sha'],r['license'],r['selected'])
