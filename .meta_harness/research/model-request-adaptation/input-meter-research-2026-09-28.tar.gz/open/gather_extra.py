import urllib.request,json,pathlib,datetime,hashlib,concurrent.futures
ROOT=pathlib.Path(__file__).parent; MAN=json.loads((ROOT/'manifest.json').read_text())
def get(url,name,limit=3_000_000):
 stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'token-counting-research/1'}),timeout=45) as r:data=r.read(limit+1)
  if len(data)>limit:raise ValueError('size limit exceeded')
  p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  MAN.append(dict(url=url,path=name,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),fetched_at=stamp))
  return json.loads(data) if name.endswith('.json') else data.decode()
 except Exception as e:MAN.append(dict(url=url,path=name,error=str(e),fetched_at=stamp));return None
jobs=[('https://docs.z.ai/llms.txt','docs/zai-index.txt'),('https://docs.z.ai/openapi.json','docs/zai-openapi.json'),('https://platform.kimi.ai/docs/api/estimate.md','docs/kimi-estimate.md'),('https://platform.kimi.ai/docs/openapi.json','docs/kimi-openapi.json'),('https://api-docs.deepseek.com/quick_start/token_usage/','docs/deepseek-token-usage.html'),('https://openrouter.ai/docs/api/reference/overview.md','docs/openrouter-overview.md'),('https://help.aliyun.com/zh/open-search/search-platform/developer-reference/token-calculation','docs/aliyun-opensearch-token.html')]
for r in json.loads((ROOT/'repos.json').read_text()):
 if not r:continue
 slug=r['repo'].replace('/','--')
 jobs.append(('https://huggingface.co/api/models/'+r['repo']+'/tree/'+r['sha']+'?recursive=true&expand=false',slug+'/tree.json'))
 jobs.append(('https://huggingface.co/api/models/'+r['repo']+'/discussions',slug+'/discussions.json'))
 if r['repo']=='deepseek-ai/DeepSeek-V4.1-Flash':jobs.append(('https://huggingface.co/'+r['repo']+'/resolve/'+r['sha']+'/inference/image_processor.py',slug+'/inference/image_processor.py'))
for org,query in [('Qwen','Qwen3.8'),('Qwen','Qwen3.7'),('zai-org','GLM-5.3')]:jobs.append((f'https://huggingface.co/api/models?author={org}&search={query}&limit=100',f'discovery/{org}-{query}.json'))
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:list(ex.map(lambda pair:get(*pair),jobs))
(ROOT/'manifest.json').write_text(json.dumps(MAN,indent=2))
print('fetched',len(jobs),'errors',[(r['path'],r['error']) for r in MAN if 'error'in r])
