exec(open(__file__.replace('gather_final.py','gather_extra.py')).read().split('jobs=')[0])
jobs=[]
for r in json.loads((ROOT/'repos.json').read_text()):
 if not r:continue
 files=[]
 if r['repo']=='deepseek-ai/DeepSeek-V4.1-Flash':files=['inference/config.json','inference/model.py']
 if r['repo']=='moonshotai/Kimi-K3':files=['kimi_k3_processor.py','kimi_k3_vision_processing.py']
 if r['repo']=='moonshotai/Kimi-K2.7-Code':files=['tool_declaration_ts.py','kimi_k25_processor.py']
 for f in files:jobs.append(('https://huggingface.co/'+r['repo']+'/resolve/'+r['sha']+'/'+f,r['repo'].replace('/','--')+'/'+f))
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:list(ex.map(lambda pair:get(*pair),jobs))
(ROOT/'manifest.json').write_text(json.dumps(MAN,indent=2))
