# OpenAI、Google、xAI 输入计量来源核对（2026-09-28）

状态：研究原稿，待主会话核原文后入库；不构成项目选型、接受或实现决定。

## 结论与适用范围

1. **存在比本地整份 JSON 编码更接近上游实际输入的官方计数接口，但三家的范围不同。** OpenAI 的 Responses input-token count 覆盖消息格式、图像、PDF、工具与 conversation；Google 的 countTokens 覆盖原生 contents / generateContentRequest；xAI 的 TokenizeText 只接受文本。它们都不是本次 OpenRouter Chat Completions 请求的已验证计数器，也不是无网络本地函数。[OpenAI](https://developers.openai.com/api/docs/guides/token-counting)、[Google](https://ai.google.dev/api/tokens)、[xAI](https://docs.x.ai/developers/grpc-api-reference/tokenize)
2. **现有 OpenAI 六个 GPT-5.6 文本叶子的依据只是 tokenizer 源码的前缀回退。** tiktoken 固定提交 `4e71bbe0c078468e00fefbf94b39849389f346e5` 没有本次任何一个精确叶子的表项；六个 GPT-5.6 和一个故意虚构的 `gpt-5-FAKE-NOT-A-MODEL` 均返回 `o200k_base`，六个 GPT-6 均 `KeyError`。这是可复现的名称解析事实，不能推导精确模型整请求计数正确。[固定源码](https://github.com/openai/tiktoken/blob/4e71bbe0c078468e00fefbf94b39849389f346e5/tiktoken/model.py)
3. **Google 已公开本地 tokenizer，但本次精确两个 Flash 名称不受该快照支持。** python-genai `6d012889752f65c1a51d0ad6e5970fc97d19c4ca` 对 3.7/3.8 均拒绝；较旧 2.5 → gemma3，3.5 → gemma4 的映射不能外推。Cloud CountTokens 官方支持列表则明确列出 3.7、3.8；Developer API 指南示例明确使用 3.8。[loader](https://github.com/googleapis/python-genai/blob/6d012889752f65c1a51d0ad6e5970fc97d19c4ca/google/genai/_local_tokenizer_loader.py)、[Cloud 支持列表](https://docs.cloud.google.com/gemini-enterprise-agent-platform/reference/models/count-tokens)、[Developer API](https://ai.google.dev/gemini-api/docs/tokens)
4. **xAI 公开权重 tokenizer 与 Grok 4.6/4.7 不能画等号。** 官方 Hugging Face 作者目录本次返回 Grok 1、Grok 2；Grok 2 的模型卡明确归属 2024 模型，含 `tokenizer.tok.json`，没有给 4.6/4.7 的兼容声明。官方 TokenizeText 文档直接使用 `grok-4.7`；4.6 的 model 页面存在，但本次未获得 tokenization 服务针对它的成功观测。[官方模型目录](https://huggingface.co/api/models?author=xai-org)、[Grok 2 固定卡片](https://huggingface.co/xai-org/grok-2/blob/daf4395a80ad177386cfe39641b64fc12b1d70ed/README.md)、[TokenizeText](https://docs.x.ai/developers/grpc-api-reference/tokenize)

上述是官方作者文档/源码加本地实验，**没有当前上游 usage 真值，没有精确误差率，也没有 route certification**。本轮未读取环境凭据、未调用任何推理或计数服务端接口、未发出付费请求。

## 调查对象与精确叶子

项目基线 `1b2a6a0b3236281f270aaf354457cf70177eceae`；读取 `packages/model/pi-ai-transport/src/official-models/{openai,google,xai}.ts` 与 `src/input-meters/openai.ts`。全部 definition revision 为 `1`，implementation revision 为 `mp4-1`。`revision: 1` 是项目修订，不是供应商模型快照 ID。

| 模型 ID | 登记 provider / implementation | 本地文本映射观察 | 本次精确名称的原生资料强度 |
| --- | --- | --- | --- |
| openai/gpt-6-astra | openai / pi-ai:openai | tiktoken KeyError | count endpoint 直接示例；图像表直接命名 |
| openai/gpt-6-astra-pro | 同上 | KeyError | count 的 model 为字符串；未逐叶调用，图像表未列 |
| openai/gpt-6-sol | 同上 | KeyError | 同上 |
| openai/gpt-6-sol-pro | 同上 | KeyError | 同上 |
| openai/gpt-6-luna | 同上 | KeyError | 同上 |
| openai/gpt-6-luna-pro | 同上 | KeyError | 同上 |
| openai/gpt-5.6-sol | 同上 | gpt-5 前缀 → o200k_base | 图像表直接命名；未逐叶 count 调用 |
| openai/gpt-5.6-sol-pro | 同上 | gpt-5 前缀 → o200k_base | 图像表未列；未逐叶 count 调用 |
| openai/gpt-5.6-terra | 同上 | gpt-5 前缀 → o200k_base | 图像表直接命名；未逐叶 count 调用 |
| openai/gpt-5.6-terra-pro | 同上 | gpt-5 前缀 → o200k_base | 图像表未列；未逐叶 count 调用 |
| openai/gpt-5.6-luna | 同上 | gpt-5 前缀 → o200k_base | 图像表直接命名；未逐叶 count 调用 |
| openai/gpt-5.6-luna-pro | 同上 | gpt-5 前缀 → o200k_base | 图像表未列；未逐叶 count 调用 |
| google/gemini-3.8-flash | google-ai-studio / pi-ai:google | LocalTokenizer 名称解析 ValueError | Developer countTokens 示例、Cloud 支持列表精确命名 |
| google/gemini-3.7-flash | 同上 | ValueError | Cloud countTokens 支持列表精确命名；Developer model 页存在 |
| x-ai/grok-4.7 | xai / pi-ai:xai | 未找到匹配的官方本地 artifact | TokenizeText 直接示例；仅文本 |
| x-ai/grok-4.6 | 同上 | 未找到匹配的官方本地 artifact | model 页存在；TokenizeText 接受 model 字符串，未验证该叶子 |

Google 文件虽也定义 google-vertex route policy，实际 `googleDefinitions` 本次只登记 google-ai-studio。Cloud 计数支持不是当前路由的相同性证明。

## OpenAI：文本编码、视觉子计量与整请求的区别

事实：当前实现对支持叶子的处理是将图像 URL 替换为占位文字，把**完整剩余 body**序列化后用 o200k_base 编码，再加图像估算。模型、provider、generation 参数、JSON 标点都进入该数值。tiktoken 的编码表确定怎样切一段文本，不定义 Chat Completions 或 Responses 的内部消息模板、tool schema 展开和 reasoning 历史格式。[tiktoken 编码定义](https://github.com/openai/tiktoken/blob/4e71bbe0c078468e00fefbf94b39849389f346e5/tiktoken_ext/openai_public.py)

事实：官方原生接口 `POST /v1/responses/input_tokens` 以 Responses 输入为对象，返回 `input_tokens`。参考页还接收 instructions、conversation/previous response、tools、reasoning、text 与 truncation 等信息；不是将 OpenRouter chat body 原样交给它。官方明确 framing 包含在结果内，而本地可见内容不一定有这些 token。输出 usage 还包含不可见的 channel/tool framing，不能拿可见输出重新 tokenize 当作全部输出真值。[接口](https://developers.openai.com/api/reference/resources/responses/subresources/input_tokens/methods/count)、[计数指南](https://developers.openai.com/api/docs/guides/token-counting)

事实：vision guide 直接列 `gpt-6-astra` 与三个 GPT-5.6 base 的 32px patch 和 1.2 倍 multiplier。对 original/auto，超过 65,535 像素边长时先缩小，随后超过 30,000 patches 是拒绝，不是缩到 patch 上限。high 对 Astra 使用 2,500 patch 与 65,535 边长约束，对三个 GPT-5.6 base 使用 2,500 patch 与 2048 边长约束；low 尺寸上限为 512×512。文档还提示浮点舍入可差一 token。这是**图像子计量**的进一步一手资料，不补足 Astra 文本编码与整请求框架，也不能移植给未列出的 Pro/Sol/Luna GPT-6 叶子。[视觉规则](https://developers.openai.com/api/docs/guides/images-vision)

推断：对 model/provider/generation 元信息和 JSON 外壳计数，可能高估文本框架；遗漏模型内部格式则可能低估。两个方向并存，不能称其天然保守上界。分别编码可见内容、tools 和图片也仍需消息模板及路由改写依据；本轮没有发布新的本地整请求算法。

## Google：公开本地实现并非当前叶子的替代品

事实：官方 LocalTokenizer 标为 experimental / text-only。它收集内容文本、函数名称/参数/响应、函数声明、schema 描述、system instruction 等文本后分别编码并求和。file_data 与 inline_data 会抛错；未知 Content 字段可能仅 warning。role 被复制到核对对象但不作为文本加入编码。此实现覆盖的是代码明示字段，不是任意最新多模态请求的完整计量。[固定 local_tokenizer.py](https://github.com/googleapis/python-genai/blob/6d012889752f65c1a51d0ad6e5970fc97d19c4ca/google/genai/local_tokenizer.py)

事实：Gemma3 路径有固定 SentencePiece URL 和 SHA256；Gemma4 路径调用 Hugging Face AutoProcessor，仓库名为 `google/gemma-4-E4B-it`，该调用没有固定 revision。离线运行需要先备好对应词表/processor 资源及依赖；SDK 的 Apache-2.0 许可不自动给模型文件同样许可。对本次 3.7/3.8，名称检查先拒绝，因此本轮没有下载旧 Gemma 词表冒充兼容。[loader](https://github.com/googleapis/python-genai/blob/6d012889752f65c1a51d0ad6e5970fc97d19c4ca/google/genai/_local_tokenizer_loader.py)

事实：Developer `models.countTokens` 可以传 contents，或整体 generateContentRequest（含 system instructions / function declarations）；两种输入有互斥条件。只传用户可见文字会漏掉其他输入。Cloud/Vertex `computeTokens` 返回文本的 token IDs；当前 Python SDK 在非 vertexai 模式直接拒绝该方法，不能当成 google-ai-studio 已可用的同接口。[Developer reference](https://ai.google.dev/api/tokens)、[Cloud computeTokens](https://docs.cloud.google.com/gemini-enterprise-agent-platform/reference/rest/v1/projects.locations.publishers.models/computeTokens)、[固定 SDK models.py](https://github.com/googleapis/python-genai/blob/6d012889752f65c1a51d0ad6e5970fc97d19c4ca/google/genai/models.py)

事实：3.8 指南覆盖图片、音频、视频；视频计量受静态/agentic 模式、resolution 与帧率影响。音频约 32 tokens/s、静态视频约 100/300 tokens/s 是该页示例性的近似，不能当任意文件的严格离线公式。agentic 视频按需载入的 frame/audio/transcript 可能落到工具使用统计；生成 reasoning/thoughts 不是预先给定输入的本地编码数。API reference 示例中的 countTokens 与 prompt usage 也并非总相等，示例不是当前模型误差测量。[当前指南](https://ai.google.dev/gemini-api/docs/tokens)、[API 例子](https://ai.google.dev/api/tokens)

## xAI：官方文本服务与旧公开 tokenizer

事实：REST `/v1/tokenize-text` 接受 text/model；gRPC TokenizeText 的 Grok 4.7 示例按 token list 长度计数。固定 SDK `47125e210ed7e0c5056464b476ce6efce8e6c56d` 的同步客户端只是构造 protobuf 后 RPC；没有本地词表算法。protobuf v6 请求只有 text/model/user，无法表达 messages/tools/image parts；把整份 JSON 当 text 发去不等于 native chat formatting。[REST](https://docs.x.ai/developers/rest-api-reference/inference/other)、[SDK](https://github.com/xai-org/xai-sdk-python/blob/47125e210ed7e0c5056464b476ce6efce8e6c56d/src/xai_sdk/sync/tokenizer.py)、[protobuf](https://github.com/xai-org/xai-sdk-python/blob/47125e210ed7e0c5056464b476ce6efce8e6c56d/src/xai_sdk/proto/v6/tokenize_pb2.pyi)

事实：本次检索官方 xAI docs 索引、TokenizeText/REST、4.6/4.7 模型页、image-understanding、官方 HF 模型目录及 Grok 2 卡片，未找到映射到 4.6/4.7 的公开 tokenizer 或完整图片/framing 计数规范。这是**检索范围内未找到**，不是不存在的证明。Grok 2 仓库采用 Grok 2 Community License Agreement；xAI SDK Apache-2.0，二者不可混称。[Grok 2 许可](https://huggingface.co/xai-org/grok-2/blob/daf4395a80ad177386cfe39641b64fc12b1d70ed/LICENSE)、[xAI SDK 许可](https://github.com/xai-org/xai-sdk-python/blob/47125e210ed7e0c5056464b476ce6efce8e6c56d/LICENSE)、[图片接口](https://docs.x.ai/developers/model-capabilities/images/understanding)

## OpenRouter 路由差距

官方 overview 说明统一 schema 与 provider-native 的字段转换，tools 对不同接口有不同映射；并提供 streaming debug 的 `echo_upstream_body`。因此本地看到的 body 不一定就是原生计数接口处理的 body。debug 属发送路径上的观测，不是发送前、无网络的计量能力。[overview](https://openrouter.ai/docs/api_reference/overview)

本次浏览官方 [OpenAPI](https://openrouter.ai/openapi.json)、[文档索引](https://openrouter.ai/docs/llms.txt)、[Responses overview](https://openrouter.ai/docs/api_reference/responses/overview)，在 OpenAPI 检索 `count_tokens` 与 `/responses/input_tokens` 均无匹配；索引未列输入预计数操作。**只能写未发现文档化兼容计数接口**，不能据此证明隐藏端点不存在。urllib 对这些资源返回 403，web 阅读成功；因此本包保留 browser-observations.json 的工具读数与抓取失败记录，没有伪造原始 HTTP body hash。

已发送请求的 provider-native usage / generation metadata 可以提供事后观测，但不能作为本轮未调用请求的真值。即使原生计数端点运行成功，还缺相同模型快照、provider route、转换后的完整输入，以及相同 tool/reasoning/media 处理参数的对齐依据。[usage](https://openrouter.ai/docs/api/api-reference/generations/get-generation)

## 候选能力对照（不作选型）

| 候选 | 来源强度与精确叶子 | 范围 | API/网络与成本 | 未解决的问题 |
| --- | --- | --- | --- | --- |
| OpenAI Responses input_tokens | 原生官方接口；Astra 精确示例，其余未逐叶执行 | framing、text、image/PDF、tools、conversation | 每次额外认证网络请求；文件可能需另取；本次材料未确立独立计数收费/配额 | OR chat→native 同一性；离线不可用；输出未来 token 不能预知 |
| tiktoken o200k_base | 官方开源固定源码/词表；GPT5.6 只有前缀回退，GPT6 无映射 | 给定字符串 BPE | 词表准备后离线、无 API token 费；3.6 MB 词表及 Python/Rust 或 TS 实现成本 | exact model 绑定、私有消息/tool/reasoning 格式、多模态 |
| OpenAI 官方 patch 公式 | Astra 和三 GPT5.6 base 精确命名 | 图片子计量 | 离线读取尺寸、缩放/舍入计算 | Pro 及另五 GPT6 叶子、整请求、浮点一 token 差异 |
| Gemini countTokens | 官方 API；Developer 3.8 示例，Cloud 支持列表含3.7/3.8 | 原生完整输入，含 multimodal | 认证网络与可能文件上传/处理等待；本轮未确立当前计数收费/配额 | 当前 AI Studio route 改写；3.7 Developer 实际可用性未测；agentic 后续输入 |
| Gemini computeTokens | 官方 Cloud API / SDK | 文本 IDs/pieces | 需要 Cloud 模式与权限、网络；未确认当前叶子收费 | 不接受当前 Developer 模式；不是多模态请求总计 |
| Google LocalTokenizer | 官方实验代码；拒绝3.7/3.8 | 明示文本/schema 字段 | 预置模型资源后离线；Gemma4 路径另有依赖/模型许可 | 精确叶子缺映射；不支持媒体；未知字段可 warning |
| xAI TokenizeText | 官方服务；Grok4.7 精确示例，4.6未实测 | text 字符串 token IDs | 认证网络；本轮未确立该操作独立费用 | messages/tools/media/framing 不在请求类型中 |
| xAI Grok1/2 公开 tokenizer | 官方旧模型仓 | 旧模型文本编码 | 词表准备后可离线；对应许可 | 与4.6/4.7 无匹配依据，不能充当新叶子方案 |

没有执行计数服务，故网络 RTT、内存/CPU benchmark、rate-limit 行为和收费均未实测；不能把“不产生生成输出”写成“免费、零限流”。

## 离线探针与证据复核

`probe.py` 使用归档源码 AST 原样提取 tiktoken 的两个映射和解析函数、Google 的三个映射和解析函数；没有安装完整 Google SDK，因此结论只到这些函数。tiktoken 0.12.0 在隔离 Python 3.12 环境实际编码；运行时 socket.connect/create_connection 被替换为抛错，词表提前从固定公开 URL 下载并校验。

- o200k 词表 SHA256：`446a9538cb6c348e3516120d7c08b09f57c36495e2acfffe59a5bf8b0cfb1a2d`，3,613,922 bytes；固定源码 expected_hash 一致。
- 英文 `Hello, world!` 与中文 `你好，世界！` 均 4 tokens；JSON/组合 Unicode 夹具分别为 9/14。这是特定编码器结果，不是供应商调用真值。
- 同一内容的最小完整 JSON body 为 28 tokens；增加 generation 参数变 40；只改 JSON 缩进变 44。证明整份序列化文本计量随表示变化；不据此给出真实偏差百分比。
- original 图像算术 1024² → 1229，2048² → 4916，4096×512 → 2458；不是解码服务测试，也不是 high 的缩放结果。

复现：先按 README.md 准备依赖与词表，再运行 `python probe.py`。`probe-results.json` 是本次实际 stdout；`requirements.txt` 固定本轮环境包。`manifest.json` 记录 URL、取得 UTC、原件 bytes/SHA256、失败；`archive-manifest.json` 记录小型交付包中 gzip 与原件的对应关系。源码许可证随原件留档；OpenAI/xAI 文档未在本次页面中建立开源许可证，Google 文档页尾为 CC-BY-4.0、代码样例 Apache-2.0；网站原件不冒充可复用代码许可。

失效触发：tokenizer 映射/词表更新、精确模型 revision 或 OR provider 改写变化、官方 multimodal/framing 规则变化、新增计数端点时复核。尚待另行授权的上游校准须固定同一路由和相同请求，再比较 server count 与实际 usage；本报告不替这项校准承诺结果。
