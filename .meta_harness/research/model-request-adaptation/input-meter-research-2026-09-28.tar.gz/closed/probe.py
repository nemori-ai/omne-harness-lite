"""Offline source-mapping and o200k representation probe; no provider calls.

Fetch o200k_base once into ./cache before running. Source mapping functions are
AST-extracted unchanged to avoid SDK imports/downloads. This does NOT run the
complete Google SDK or certify provider token totals.
"""
import ast
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import socket

ROOT = Path(__file__).resolve().parent
os.environ['TIKTOKEN_CACHE_DIR'] = str(ROOT / 'cache')
def blocked(*args, **kwargs):
    raise RuntimeError('network disabled during offline probe')
socket.socket.connect = blocked
socket.create_connection = blocked

def extract(file, assignments, functions):
    tree = ast.parse((ROOT / 'sources' / file).read_text())
    nodes = []
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in assignments for t in node.targets):
            nodes.append(node)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id in assignments:
            nodes.append(node)
        elif isinstance(node, ast.FunctionDef) and node.name in functions:
            nodes.append(node)
    scope = {}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), file, 'exec'), scope)
    return scope

t = extract('tiktoken-tiktoken_model.py', {'MODEL_TO_ENCODING', 'MODEL_PREFIX_TO_ENCODING'}, {'encoding_name_for_model'})
g = extract('google-genai-google_genai__local_tokenizer_loader.py', {'_GEMINI_MODELS_TO_TOKENIZER_NAMES', '_GEMINI_STABLE_MODELS_TO_TOKENIZER_NAMES', '_GEMINI_MODELS_TO_HUGGINGFACE_TOKENIZER_NAMES'}, {'get_tokenizer_name'})
openai = [f'gpt-{family}-{name}{suffix}' for family, names in [('6', ['astra','sol','luna']), ('5.6',['sol','terra','luna'])] for name in names for suffix in ['', '-pro']]
results = {'scope': 'offline source name resolution and encoding only; no usage truth', 'openai': {}, 'google': {}}
for model in openai + ['gpt-5-FAKE-NOT-A-MODEL']:
    try:
        results['openai'][model] = {'encoding': t['encoding_name_for_model'](model), 'exact_entry': model in t['MODEL_TO_ENCODING']}
    except KeyError:
        results['openai'][model] = {'error': 'KeyError', 'exact_entry': False}
for model in ['gemini-3.7-flash', 'gemini-3.8-flash', 'gemini-3.5-flash', 'gemini-2.5-flash']:
    try:
        results['google'][model] = {'tokenizer': g['get_tokenizer_name'](model)}
    except ValueError:
        results['google'][model] = {'error': 'ValueError'}

import tiktoken
encoding = tiktoken.get_encoding('o200k_base')
results['tiktoken_version'] = importlib.metadata.version('tiktoken')
fixtures = [
    'Hello, world!',
    '你好，世界！',
    '{"city":"北京","count":3}',
    '👨‍👩‍👧‍👦 cafe\u0301 café',
]
results['text'] = [{'text': text, 'tokens': encoding.encode(text), 'count': len(encoding.encode(text))} for text in fixtures]
body = {'model':'openai/gpt-5.6-sol','messages':[{'role':'user','content':'Hello, world!'}]}
cases = {'minimal': body, 'sampling_only': {**body, 'temperature':0.2,'max_tokens':1000}, 'formatting_only':body}
results['serialized_body'] = {name: len(encoding.encode(json.dumps(value, ensure_ascii=False, separators=(',',':')) if name != 'formatting_only' else json.dumps(value, ensure_ascii=False, indent=2))) for name,value in cases.items()}
results['image_original_patch_examples'] = [{'width':w,'height':h,'patches':((w+31)//32)*((h+31)//32),'tokens':((((w+31)//32)*((h+31)//32)*6)+4)//5} for w,h in [(1024,1024),(2048,2048),(4096,512)]]
results['cache_files'] = [{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in (ROOT/'cache').iterdir()]
print(json.dumps(results, ensure_ascii=False, indent=2))
