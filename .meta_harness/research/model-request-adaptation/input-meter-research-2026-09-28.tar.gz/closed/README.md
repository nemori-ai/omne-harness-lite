# Reproduce the offline probe

Research-only source and fixture bundle. No provider requests are performed.

1. In a scratch directory create a Python 3.12 virtual environment, then install
   `requirements.txt` (for example `uv venv .venv` and
   `uv pip install --python .venv/bin/python -r requirements.txt`). Dependency
   preparation needs network unless wheel caches are already populated.
2. If using the compact evidence bundle, unpack each `sources/*.gz` to the
   filename with the `.gz` suffix removed. These are archived bytes, not rewritten
   code. `archive-manifest.json` gives both archived and original SHA256.
3. Fetch only the public vocabulary URL
   `https://openaipublic.blob.core.windows.net/encodings/o200k_base.tiktoken`
   into `cache/fb374d419588a4632f3f557e76b4b70aebbca790`. Its required SHA256 is
   `446a9538cb6c348e3516120d7c08b09f57c36495e2acfffe59a5bf8b0cfb1a2d`.
   The 3.6 MB vocabulary is deliberately not duplicated in the compact bundle.
4. Run `.venv/bin/python probe.py > actual.json`. The probe prohibits socket
   connections before loading the cached encoding. Compare parsed JSON to
   `probe-results.json`; do not compare byte formatting alone.

The Google check extracts the fixed upstream mapping functions using Python AST;
it does not run the entire SDK. The tokenizer outputs concern a given encoding,
not current provider usage. No errors or accuracy rates against server counts are
claimed. The image portion is integer formula arithmetic for original detail,
not provider image decoding or high-detail resizing.

`manifest.json` captures raw-source hashes and UTC retrieval times. Website HTML
is gzip-compressed without altering decompressed bytes. OpenRouter raw retrieval
returned HTTP 403; `browser-observations.json` preserves only the successful web
tool readout and explicitly has no original body hash. Source licenses: tiktoken
MIT, Google and xAI SDK Apache-2.0, Grok 2 Community License Agreement. Model files
and docs do not acquire the SDK's license merely by being referenced by it.
