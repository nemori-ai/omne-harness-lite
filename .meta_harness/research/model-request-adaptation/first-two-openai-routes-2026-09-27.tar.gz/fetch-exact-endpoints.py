from pathlib import Path
import json,hashlib,datetime,urllib.request,urllib.error,concurrent.futures
BASE=Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime/tmp/model-request-runtime/p6-first-model-facts')
REQUESTS=[
 ('sol-endpoints','https://openrouter.ai/api/v1/models/openai/gpt-6-sol/endpoints'),
 ('luna-endpoints','https://openrouter.ai/api/v1/models/openai/gpt-5.6-luna/endpoints'),
]
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):
  raise urllib.error.HTTPError(req.full_url,code,'redirect denied',headers,fp)
def obtain(item):
 name,url=item
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 record={'id':name,'url':url,'method':'GET','request_headers':{'Accept':'application/json','User-Agent':'omne-readonly-fact-closure/1'},'credentials_loaded':False,'redirects_allowed':False,'retries':0,'started_utc':started}
 try:
  opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
  req=urllib.request.Request(url,headers=record['request_headers'],method='GET')
  with opener.open(req,timeout=20) as response:
   data=response.read(4*1024*1024+1)
   if len(data)>4*1024*1024: raise ValueError('response above measurement 4MiB cap')
   record.update(status=response.status,final_url=response.url,response_headers={k:v for k,v in response.headers.items() if k.lower()!='set-cookie'},transient_set_cookie_header_discarded=True,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),raw_path='raw/'+name+'.body')
   (BASE/record['raw_path']).write_bytes(data)
 except Exception as error:
  record['error_type']=type(error).__name__;record['error']=str(error)
 record['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (BASE/'raw'/ (name+'.receipt.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
 return record
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  records=list(pool.map(obtain,REQUESTS))
 print(json.dumps(records,ensure_ascii=False,indent=2))
 if any('error' in r for r in records):raise SystemExit(1)
