Failed to fetch https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create.md: 404 Not Found
