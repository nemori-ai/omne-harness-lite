# 两个固定 OpenAI route 的第一方事实闭合

2026-09-27。HUB 初始 branch panqiwei/model-request-runtime、HEAD b20c408b97e9607c67e358d025411c048cf1007b，tracked clean。只写本 ignored 目录，无源码／正式设计修改。先依 OpenAI Docs 搜索并实际抓取精确型号页，再读 prior 研究与原件。无凭据加载／模型 POST／付费；新增恰 2 次精确 endpoint 免费 GET。

**结论：四个能力字段和 route 身份有直接值；两份完整 official definition 仍不能发布。** 必填 inputConstraints 未闭合，多项参数还只有名字或通用 API 域，缺指定 route 的逐值和条件事实。没有把 unknown 改成空限制、false、pass/drop。机器读数见 [FACTS.json](FACTS.json)，原文 URL／SHA／取得方式见 [SOURCES.json](SOURCES.json)，免费 GET 收据见 [GET-RECEIPTS.json](GET-RECEIPTS.json)。源／政策采用和生产认证皆由主线另外裁定。

| 字段 | 可核事实 | 边界 |
| --- | --- | --- |
| 精确 route | Sol 是 OpenAI / openai/gpt-6-sol-20260922；Luna 是 OpenAI / openai/gpt-5.6-luna-20260709，各唯一 tag=openai | 原 GET /data/endpoints/1、/data/endpoints/2；未改成 flex/fast/Azure |
| inputModalities | 两个精确原生页 text、image；bridge 父 architecture file、image、text | 型号声明，不是指定 route 媒体执行证明；file 不转 core modality |
| outputModalities | 两个精确原生页和 bridge 父 architecture 都为 text | 无穷尽执行认证 |
| maxInputTokens | 原生 max input 与所选 endpoint max_prompt_tokens 都为 922000 | 直接只计输入来源；未拿 context_length=1050000 相减 |
| maxOutputTokens | 两个原生 max output 与所选 endpoint max_completion_tokens 都为 128000 | 未做输出边界执行；D082/G22 当前 rule 仍 pass，不据字段夹取 |
| inputConstraints.maxImageBytes | 未查到这两个精确 route 的逐图字节极限或明确无限制承诺 | 不能填 inputConstraints={}；512 MB 总 payload 和 30000 patches/图不是逐图字节 |
| reminderRole | 用户及 D082 已选 developer，native 通用说明支持 developer | 既定项目映射；本次未执行 ordinary reminder 的 bridge／优先级，configuration_update 是独立功能 |
| cache.mode | OpenRouter OpenAI 专节声明自动、无需配置、1024 token 起；native GPT5.6+ 默认 implicit | 可核既定无控制 automatic 策略的依据；endpoint supports_implicit_caching=false 不足以推翻文档／历史暖读 |

[Sol 原生页](https://developers.openai.com/api/docs/models/gpt-6-sol)、[Luna 原生页](https://developers.openai.com/api/docs/models/gpt-5.6-luna)经官方 docs MCP 实际获取，保留 fetched Markdown 与工具表示。免费 GET 是 [Sol endpoints](https://openrouter.ai/api/v1/models/openai/gpt-6-sol/endpoints)、[Luna endpoints](https://openrouter.ai/api/v1/models/openai/gpt-5.6-luna/endpoints)，2026-09-27 23:30:08 UTC 均 HTTP200。两条所选 endpoint 的身份、窗口、参数名、工具按值标志与 prior 原件逐项相等，没有拿 aggregate 填缺字段。

八个统一参数的事实与缺口：

| 统一项 | 已核 native／gateway 声明 | 未闭事实 |
| --- | --- | --- |
| reasoningEffort | 两个原生页 none/low/medium/high/xhigh/max；core 同名子集 none/low/medium/high/max。所选 route 列 reasoning、reasoning_effort | route 未独立声明逐值／组合保证；缺席不等于 none，不填 xhigh 到 core |
| temperature | Sol GPT6 指导明确非 none 移除该项；通用 0..2；两个 route 均未列 | Sol bridge 是否保持 native 条件；Luna5.6 精确条件未知，未向前代抄 GPT6 规则 |
| topP | Sol 同上；通用 0..1，core 排除 0；route 未列 | 同上；独立项 rule 无法表达 effort 相关条件 |
| seed | 两个 route 列 seed；native 通用 Chat 为 deprecated Beta int64，gateway 为 integer | route 精确值域和 bridge 实際传递／生效；不能推成 core 任意大整数均支持 |
| maxOutputTokens | route 列 max_tokens，原生128000；当前规划发送 max_tokens | D082 pass 为设计例外，不是所有值被上游接受的事实 |
| stopSequences | 通用最多四字符串，route 未列 stop | 精确支持、长度与条件；独立 rule 不能约束任意数组条数 |
| frequencyPenalty | 通用 Chat -2..2，route 未列 | 两型号和精确 bridge 的支持／条件 |
| presencePenalty | 同上 | 同上 |

未列参数保存为 not reported/unknown，不能直接写成不支持。D082 规定跨项条件或复杂约束无法承载时报告投影缺口；本调查没有设计新条件机制。extra 名 include_reasoning、response_format、structured_outputs 存在于目录，完整原键 JSON 值域未知；没有发布任意 JSON pass，也没有把未知支持写成已知空 extra。

缓存的准确适用边界：

- [native 缓存原文](https://developers.openai.com/api/docs/guides/prompt-caching)给 GPT5.6+ 唯一 TTL=30m、默认30m；含义是最后 write/reuse 后的最低 eligible 生命周期，可以留得更久，不承诺每次命中。四 write slot、implicit 占一、visible-prefix 1024 token 起。
- [OpenRouter 缓存原文](https://openrouter.ai/docs/guides/best-practices/prompt-caching)描述 native marker 和 Anthropic 风格 marker 的转换，**块 cache_control.ttl 向 OpenAI 被丢弃**；OpenAI 专用 root prompt_cache_options 不等价于本包通用块 TTL。因此不能把 native30m 填入通用 explicit.cache.ttl 并报告采纳。
- 本次不为这两个自动 target 发布 explicit TTL／完整布局。automatic 本身没有手工字段。
- prior native guide 给 first2/latest50 lookup 边界，本次实际 docs search 的 Responses API 内容给 latest80；未独立抓到后一全文，冲突保留。不要据 search 摘录复刻上游 lookup 机制。
- 本次没有 cache hit、retention、到期请求；prior 暖读是既有有限观察，目录 false flag 不证明没有自动缓存。

新的版本复核信号：[changelog](https://developers.openai.com/api/docs/changelog) Sep25 记录 GPT6 Sol/Luna 的图像编码修复并要求重新视觉评估，实际原文在 docs/p6-changelog.md。没有观察指定 OpenRouter endpoint 的 patch 部署，也没有声称历史样例早于修复；它是 ND-G3 当前验证输入的复核触发。

最小后续事实／验证票，均未执行：

1. **指定 route 参数支持域。** 两个精确型号和 openai、无回退，缺 seed 值域、sampling/effort 条件、stop/penalty 支持及采用 extra 形状。精确文档承诺与有限 none/high、采样、合法/越界 seed、stop 个数反例分开；有限样例不能证明完整连续域或任意整数。出现 source 明确的跨项约束时，现独立 rule 不可静默 drop 代替。
2. **输入约束和 image 实际承载。** 先取得逐图字节限额或明文无限制依据；找不到则 ND-G1 保留，小图成功不许可空限制。ND-G3 需要实际公开制品 ContentBlock→具名 PNG/JPEG bytes→OpenRouter image_url 的正向和拒绝，冻结版本与时间。512 MB/request、1500 images/request、30000 patches/image 不填 maxImageBytes。
3. **当前公开路径的自动缓存和普通提醒。** 固定 binding/config/route，稳定 ≥1024 token 的冷暖与改前缀负控，核 provider、cached_tokens/cache_write_tokens；不发送 session_id/prompt_cache_key/手工 cache_control。developer/user 的合成可区分指令只能给有限优先级读数；configuration_update 不当普通 reminder；TTL 到期另需时间实验。

原件完整性：prior archive SHA bd5bb7f26ed868e445d2c3559c18c1519afd5ecd05bd5d87a565bedb0f45ac67，选出的 27 个原件逐字匹配原 manifest，未重新调查其余35目标。MCP Markdown／search／HTTP body／tool failure 各保留其表示；Chat reference MCP Markdown404、官方 web旧入口 internal error 均留存，失败不证明 API 不支持。免费 GET 丢弃无关 transient set-cookie 头，原 body 未改；收据明确此处理。derive-facts.py 离线只重算精确目标和原件，没有模型请求。模型／route／bridge/native 变更、账号政策或缓存文档变化触发复核。

本次 full definition=0/2、生产认证=0/2；调查 JSON 中 null/unknown 永不进入正式定义。公开工件门、事实采用、生产认证分开，ND-G1～3 均未闭合。
