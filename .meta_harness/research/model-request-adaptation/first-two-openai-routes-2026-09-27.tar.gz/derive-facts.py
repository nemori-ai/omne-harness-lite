from pathlib import Path
import json,hashlib,datetime,subprocess,copy
BASE=Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime/tmp/model-request-runtime/p6-first-model-facts')
HUB=BASE.parents[2]
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
targets=[('openai/gpt-6-sol','sol-endpoints','p6-modeldoc-0',1,3),('openai/gpt-5.6-luna','luna-endpoints','p6-modeldoc-1',2,11)]
prior=json.loads((BASE/'prior/facts-openrouter-2026-09-27/facts.json').read_text())
models=[]
wire={'reasoningEffort':'reasoning.effort','temperature':'temperature','topP':'top_p','seed':'seed','maxOutputTokens':'max_tokens','stopSequences':'stop','frequencyPenalty':'frequency_penalty','presencePenalty':'presence_penalty'}
for model,name,native,expected_index,prior_no in targets:
 raw=json.loads((BASE/'raw'/(name+'.body')).read_bytes());d=raw['data'];assert d['id']==model
 matches=[(i,e) for i,e in enumerate(d['endpoints']) if e['tag']=='openai'];assert len(matches)==1
 index,e=matches[0];assert index==expected_index and e['model_id']==model and e['provider_name']=='OpenAI'
 p=next(r for r in prior['models'] if r['model_id']==model)
 old=json.loads((BASE/'prior/facts-openrouter-2026-09-27/raw'/('endpoint-%02d.body'%prior_no)).read_bytes())
 prior_e=[e2 for e2 in old['data']['endpoints'] if e2['tag']=='openai'];assert len(prior_e)==1
 for field in ['name','model_id','tag','context_length','max_prompt_tokens','max_completion_tokens','supported_parameters','supports_tool_choice','supports_implicit_caching']:
  assert e[field]==prior_e[0][field],(model,field)
 assert d['architecture']==old['data']['architecture']
 assert e['max_prompt_tokens']==922000 and e['max_completion_tokens']==128000 and e['context_length']==1050000
 native_text=(BASE/'docs'/(native+'.md')).read_text()
 assert 'Max input: 922,000 tokens' in native_text and 'Max output: 128,000 tokens' in native_text
 assert 'Input modalities: text, image' in native_text and 'Output modalities: text' in native_text
 selected_source={'source':name,'pointer':'/data/endpoints/'+str(index)}
 capabilities={
  'inputModalities':{'value':['text','image'],'state':'native_documented_model_capability_and_bridge_parent_architecture','sources':[{'source':native,'locator':'Current snapshot details/Input modalities'},{'source':name,'pointer':'/data/architecture/input_modalities'}],'selected_route_actual_media_delivery':'not_verified_this_task','unconverted_gateway_file_marker':'file'},
  'outputModalities':{'value':['text'],'state':'native_documented_model_capability_and_bridge_parent_architecture','sources':[{'source':native,'locator':'Current snapshot details/Output modalities'},{'source':name,'pointer':'/data/architecture/output_modalities'}],'selected_route_exhaustive_actual_delivery':'not_verified_this_task'},
  'maxInputTokens':{'value':922000,'state':'explicit_native_max_input_and_selected_route_max_prompt_tokens_agree','sources':[{'source':native,'locator':'Current snapshot details/Max input'},{**selected_source,'pointer':selected_source['pointer']+'/max_prompt_tokens'}],'subtraction_used':False},
  'maxOutputTokens':{'value':128000,'state':'explicit_native_max_output_and_selected_route_max_completion_tokens_agree','sources':[{'source':native,'locator':'Current snapshot details/Max output'},{**selected_source,'pointer':selected_source['pointer']+'/max_completion_tokens'}],'boundary_output_execution':'not_performed','G22':'current_rule_remains_pass_no_clamp'},
  'inputConstraints':{'state':'unknown_required_field_cannot_publish_empty_object','value':None,'maxImageBytes':{'state':'unknown','value':None,'sources':[{'source':'p6-image-reference','locator':'Image input requirements'}],'known_native_total_payload':'512 MB/request','known_native_image_count':'1500/request','known_native_patch_ceiling':'30000 patches/image after model/detail resizing','per_image_exact_byte_ceiling_or_no_limit_statement':'not_found_in_checked_sources','total_payload_and_patch_ceiling_not_converted_to_maxImageBytes':True}}
 }
 params={}
 for unified,key in wire.items():
  lookup='reasoning_effort' if unified=='reasoningEffort' else key
  info={'emitted_wire_key':key,'selected_route_parameter_name_reported':lookup in e['supported_parameters'],'source':{**selected_source,'pointer':selected_source['pointer']+'/supported_parameters'},'entire_core_domain_route_honoring':'unknown','rule_adopted_this_task':False}
  if unified=='reasoningEffort':
   info.update(native_values=['none','low','medium','high','xhigh','max'],current_core_same_name_subset=['none','low','medium','high','max'],native_source={'source':native,'locator':'reasoning effort'},missing_is_not_none=True)
  elif unified=='maxOutputTokens':
   info.update(accepted_design_rule='pass',reason='D082 preserves runtime G22; upper-limit metadata is not adoption of dynamic clamp',native_documented_max=128000)
  elif unified=='seed':
   info.update(generic_native_chat_int64=[str(-(2**63)),str(2**63-1)],generic_gateway_type='integer',selected_route_exact_domain='unknown',native_bridge_target_and_actual_honoring='unknown')
  elif unified=='stopSequences':
   info.update(generic_gateway_limit='up to four strings',selected_route_exact_support='unknown',current_rule_expression_does_not_bound_string_array_length=True)
  elif unified in ['temperature','topP']:
   info.update(generic_native_and_gateway_numeric_domain=[0,2] if unified=='temperature' else [0,1],core_topP_excludes_zero=(unified=='topP'))
   if model=='openai/gpt-6-sol':
    info.update(native_documented_condition='reasoning effort must be none',native_condition_source={'source':'p6-gpt6-guide','locator':'Update API and model parameters/Unsupported parameters'},selected_route_bridge_condition='unknown',per_parameter_rule_cannot_express_cross_parameter_condition=True)
   else:
    info.update(exact_native_model_sampling_condition='unknown; GPT6 condition not copied backwards')
  else:
   info.update(generic_native_and_gateway_numeric_domain=[-2,2],exact_native_and_bridge_support='unknown')
  params[unified]=info
 models.append({
  'model_id':model,'selected_provider':'openai','selected_endpoint_index':index,'selected_endpoint_name':e['name'],'capabilities':capabilities,'parameters':params,
  'extra':{'state':'no_extra_policy_adopted_this_task','known_catalogued_nonunified_keys':['include_reasoning','response_format','structured_outputs'],'actual_arbitrary_JSON_value_support':'not_established','full_JSON_shape_or_conditional_domains':'unknown','not_filled_with_pass':True,'prompt_cache_options_is_native_and_gateway_API_feature_but_not_equivalent_to_route_registration':True},
  'reminder':{'project_policy_role':'developer','project_policy_basis':'user confirmed mapping plus D082 ND-V6','native_role_supported':True,'native_priority_is_vendor_document_claim':'developer instructions prioritized over user','ordinary_selected_route_message_mapping_priority_execution':'unknown_this_task; configuration_update is distinct','configuration_update_not_added_to_ordinary_reminder':True},
  'cache':{'project_existing_target_mode':'automatic','gateway_vendor_claim':'OpenAI automated without extra configuration; min 1024 prompt tokens','native_vendor_claim':{'default':'implicit','explicit_supported':True,'only_native_ttl':'30m','native_ttl_kind':'minimum eligibility after last write/reuse, not hit guarantee','max_writes':4,'implicit_uses_one_slot':True,'minimum_visible_prefix_tokens':1024},'selected_route_metadata_supports_implicit_caching':e['supports_implicit_caching'],'false_flag_not_promoted_to_absent_cache':True,'cache_READ_WRITE_current_execution':'none_this_task','native_cache_lookup_boundary_conflict':{'cached_prior_guide':'first 2 + latest 50 explicit, plus implicit and at most 20 earlier endings','initial_docs_search_API_text':'latest 80 without content-block lookback limit','resolved':False},'OpenRouter_Anthropic_style_marker_translation':{'cache_control_marker':'may translate to OpenAI prompt_cache_breakpoint','cache_control_ttl':'dropped toward OpenAI','prompt_cache_options_ttl':'OpenAI-specific root field; source example 30m'},'exact_explicit_project_layouts_and_missing_targets':'unknown; not needed to describe current automatic-only target but blocks any explicit offering','no_manual_control_written_for_automatic':True},
  'full_definition_publishable':False,'production_certification':'not_established','prior_critical_metadata_comparison':'unchanged'}
 )
facts={'created_utc':now,'scope':['openai/gpt-6-sol@openai','openai/gpt-5.6-luna@openai'],'repository_initial_head':'b20c408b97e9607c67e358d025411c048cf1007b','models':models,'new_free_exact_endpoint_GETs':2,'new_model_POSTs':0,'credentials_read':0,'paid_cost_USD':'0','source_and_rule_adoption_this_task':False,'new_modality_revision_signal':{'source':'p6-changelog','locator':'September 2026/Sep 25','vendor_claim':'image encoding fix for GPT6 Sol/Luna; rerun visual evaluations','selected_openrouter_endpoint_patch_state':'not_observed','no_claim_historical_runs_before_fix':True}}
(BASE/'FACTS.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2)+'\n')
sources=[]
for model,name,native,index,prior_no in targets:
 r=json.loads((BASE/'raw'/(name+'.receipt.json')).read_text());sources.append({'id':name,'url':r['url'],'acquisition':'credential-free GET; original response body','utc':r['completed_utc'],'file':r['raw_path'],'bytes':r['bytes'],'sha256':r['sha256']})
 sources.append({'id':native,'url':'https://developers.openai.com/api/docs/models/'+model.split('/')[1],'acquisition':'OpenAI documentation MCP fetch; fetched Markdown, not HTTP body','utc_day':'2026-09-27','time_detail':'initial model-page tool timestamp was not separately recorded','file':'docs/'+native+'.md'})
for name in ['p6-image-reference','p6-changelog','p6-gpt6-guide']:
 x=json.loads((BASE/'docs'/(name+'.json')).read_text());sources.append({'id':name,'url':x['url'],'acquisition':'OpenAI documentation MCP fetch; fetched Markdown, not HTTP body','utc':x['at'],'file':'docs/'+name+'.md'})
sources.extend([
 {'id':'native-prior-cache','url':'https://developers.openai.com/api/docs/guides/prompt-caching','acquisition':'previous archive original, copied bytes checked against manifest','utc_day':'2026-09-27','file':'prior/facts-native-openai-anthropic-2026-09-27/sources/openai-prompt-caching.raw.md'},
 {'id':'gateway-prior-cache','url':'https://openrouter.ai/docs/guides/best-practices/prompt-caching','acquisition':'previous archive original, copied bytes checked against manifest','utc_day':'2026-09-27','file':'prior/facts-openrouter-2026-09-27/raw/prompt-caching.body'},
 {'id':'gateway-prior-parameters','url':'https://openrouter.ai/docs/api_reference/parameters.md','acquisition':'previous archive original, copied bytes checked against manifest','utc_day':'2026-09-27','file':'prior/facts-openrouter-2026-09-27/raw/parameters.body'},
 {'id':'gateway-prior-gpt6-migration','url':'https://openrouter.ai/docs/cookbook/evaluate-and-optimize/model-migrations/gpt-6','acquisition':'previous archive original, copied bytes checked against manifest','utc_day':'2026-09-27','file':'prior/facts-openrouter-2026-09-27/raw/gpt6-migration.body'},
 {'id':'gateway-prior-gpt56-migration','url':'https://openrouter.ai/docs/cookbook/evaluate-and-optimize/model-migrations/gpt-5.6','acquisition':'previous archive original, copied bytes checked against manifest','utc_day':'2026-09-27','file':'prior/facts-openrouter-2026-09-27/raw/gpt56-migration.body'},
 {'id':'gateway-prior-images','url':'https://openrouter.ai/docs/guides/overview/multimodal/image-understanding','acquisition':'previous archive original, copied bytes checked against manifest','utc_day':'2026-09-27','file':'prior/facts-openrouter-2026-09-27/raw/image-understanding.body'}])
for r in sources:
 data=(BASE/r['file']).read_bytes();r.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
(BASE/'SOURCES.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'models':len(models),'sources':len(sources),'full_definitions':0,'free_GETs':2,'new_paid_requests':0},ensure_ascii=False))
