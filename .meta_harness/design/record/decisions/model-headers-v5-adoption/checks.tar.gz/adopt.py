from pathlib import Path
import datetime
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-p2-mr5-core-projection')
DESIGN = ROOT / '.meta_harness/design'
HUB = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime')
OUT = ROOT / 'tmp/model-request-runtime/p2-header-adoption'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())

assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT, text=True).strip() == 'panqiwei/model-request-runtime-p2-mr5-core-projection'
preflight = read(HUB / 'tmp/model-request-runtime/p2-mr5-core-projection/root-spoke-preflight.json')
for path, digest in preflight['protected_candidate_files'].items():
    assert sha((ROOT / path).read_bytes()) == digest, path
for path, digest in preflight['protected_original_node_files'].items():
    assert sha((ROOT / path).read_bytes()) == digest, path
node_path = 'realization/packages/core/model-response/v5-design.md'
node_digest = '5c2e633b771e5d262d4d5240310f7d8bf9cd735a36259d4a6e70b749bf41eb94'
assert sha((DESIGN / node_path).read_bytes()) == node_digest
inputs_path = ROOT / 'tmp/model-request-runtime/p2-mr5-core-projection/input-manifest.json'
inputs = read(inputs_path)
entries = inputs['inputs']
assert len(entries) == 168
for entry in entries:
    path = entry['path']
    assert sha((ROOT / path).read_bytes()) == entry['sha256'], path
    assert sha((ROOT / 'tmp/model-request-runtime/p2-mr5-core-projection/input-snapshots' / path).read_bytes()) == entry['sha256'], path

catalog_path = DESIGN / 'registry/catalog.json'
catalog = read(catalog_path)
originals = {}
for name, key in [('catalog', 'contracts'), ('covers', 'covers'), ('formal-tasks', 'tasks')]:
    p = '.meta_harness/design/registry/' + name + '.json'
    original = json.loads(subprocess.check_output(['git', 'show', 'HEAD:' + p], cwd=ROOT))
    current = read(ROOT / p)
    assert current[key][:len(original[key])] == original[key], name
    originals[name] = original
frozen_path = DESIGN / 'registry/frozen.json'
frozen = read(frozen_path)
assert len(frozen['files']) == 472
for path, digest in frozen['files'].items():
    assert sha((DESIGN / path).read_bytes()) == digest, path

review_summary = {
    'format': 1,
    'provenance': 'Root-attributed summaries of actual independent role messages; not verbatim reviewer artifacts, a new review, a product run, or human acceptance.',
    'at_utc': datetime.datetime.now(datetime.UTC).isoformat(),
    'reviews': [
        {'agent': '/root/b1_late_boundary_review', 'object': 'header-handoff rev1', 'sha256': preflight['protected_candidate_files']['.meta_harness/design/record/proposals/model-request-adaptation/header-handoff.md'], 'verdict': 'no in-scope blockers', 'findings': ['A/A: retain scalar or ordered string array map, same-send common rawHeaders fact to final invoke result', 'No HTTP wire ordering claim, no second authority from failure/opaque response', 'Cancellation/read/parse/gate failure cannot erase retained facts; original secret and content boundaries remain'], 'remaining': ['TLS/send/invoke/append/reopen, secrets, actual stopping and compiled negatives', 'Codec history/format policy belongs to common owner'], 'changed_vote_if': ['Original header-line order is required', 'Normalization is formally allowed', 'Independent immediate consumers or headers acquired after send emerge']},
        {'agent': '/root/p2_narrow_projection_expression_review', 'object': 'complete MR5 plus RT5 candidate batch', 'mr5_contract_sha256': 'c4cba40c4cbe9bf0c725cb47d0587d9672fb058a456ef14925dcce638eba065e', 'rt5_contract_sha256': '21c3ef25ae703c7230b709f5a445bdd8daad9d9a808784c8824b2f98878a733e', 'verdict': 'no in-scope blockers', 'findings': ['73 clauses/13 operations with nine items/17 dependencies; only normative MR4 to MR5 upgrade', 'S58 to S54 to S17 success/failure/cancellation/reader-not-entered handoff; four outcomes and content/secret boundaries preserved', 'S33/S36/S64 do not reconstruct never-persisted process-lost headers', 'Old registry and 472 frozen resources protected; four TLA/nineteen cfg unchanged and do not model new headers'], 'non_blocking': 'MR5RT5-EX1: runtime topic README still calls v4 provider unadopted despite D087; current navigation updated by this event', 'remaining': ['No tests/Schema/TLC/build/IO executed by reviewer', 'All RT5-H1 through H6 and original production gates remain']},
        {'agent': '/root/b1_late_boundary_review', 'object': 'core/model-response v5-design rev1', 'sha256': node_digest, 'verdict': 'no in-scope blockers', 'findings': ['Explicit v5/schema-v5 keeps root MR4 and retained v3/v2 identities', 'Full types/17 definitions/fixed resources/shared ordered judge preserve failure precedence', 'No owned value returned by judge; no plugin/service/storage/clock', 'Only observable input mutation or acceptance/order changes qualify as core negative controls'], 'non_blocking': ['Shared-kernel extraction must preserve old root behavior', 'Two actual public pack closures and literal examples remain implementation costs'], 'remaining': ['PV1 through PV9 not run', 'Transport/runtime/codec projections and X1 through X4 remain other owners']},
        {'agent': '/root/p2_narrow_projection_expression_review', 'object': 'core/model-response v5-design rev1', 'sha256': node_digest, 'verdict': 'no in-scope blockers', 'findings': ['Full public types, exact seven dependencies/21 resources, S27/S36 precedence and member/full Schema separation consistent', 'PV1 through PV9 have falsifiable observations; zero new bindings', '17 local links and 13 source digests checked; 168 inputs unchanged'], 'non_blocking': 'Old node README describes v4 as unaccepted/unimplemented; current four-layer navigation updated without elevating verification', 'remaining': ['No source/type/Schema/pack/IO/formal execution performed', 'No new product ruling; codec history remains original owner']},
    ],
    'input_manifest_sha256': sha(inputs_path.read_bytes()),
    'input_count': 168,
    'candidate_paths': 39,
    'new_bindings': 0,
}
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'review-summary.json').write_text(json.dumps(review_summary, ensure_ascii=False, indent=2) + '\n')
bundle = {}
bundle['review-summary.json'] = (OUT / 'review-summary.json').read_bytes()
bundle['provider-input-manifest.json'] = inputs_path.read_bytes()
for entry in entries:
    bundle['input-snapshots/' + entry['path']] = (ROOT / entry['path']).read_bytes()
for path in preflight['protected_candidate_files']:
    bundle['candidate-snapshot/' + path] = (ROOT / path).read_bytes()
bundle['candidate-snapshot/.meta_harness/design/' + node_path] = (DESIGN / node_path).read_bytes()
bundle['original-registry/frozen.json'] = frozen_path.read_bytes()
manifest = {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(bundle.items())}
bundle['manifest.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
reviews = DESIGN / 'record/proposals/model-request-adaptation/reviews'
reviews.mkdir(exist_ok=True)
archive = reviews / 'model-headers-v5-2026-09-27.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tf:
    for name, data in sorted(bundle.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        tf.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tf:
    members = tf.getmembers()
    assert len(members) == len(bundle)
    for member in members:
        assert member.isfile() and tf.extractfile(member).read() == bundle[member.name]
archive_digest = sha(archive.read_bytes())
index_path = reviews / 'model-headers-v5-2026-09-27.json'
index_path.write_text(json.dumps({'format': 1, 'sha256': archive_digest, 'members': len(bundle), 'all_members_read_back': True, 'review_provenance': review_summary['provenance'], 'files': manifest}, ensure_ascii=False, indent=2) + '\n')

decision_dir = DESIGN / 'record/decisions/model-headers-v5-adoption'
assert not decision_dir.exists()
decision_dir.mkdir()
accepts = []
targets = [c for c in catalog['contracts'] if c['coordinate']['version'] == 5 and c['coordinate']['contract_id'] in ('data.model-response', 'capability.model-request-runtime')]
assert len(targets) == 2
for target in targets:
    assert target['status'] == 'candidate' and target['acceptance'] is None
    resources = {p: sha((DESIGN / p).read_bytes()) for p in target['resources']}
    accepts.append({'coordinate': target['coordinate'], 'resources': resources, 'scope_clauses': ['S-' + str(n) for n in range(1, (38 if target['family'] == 'data' else 73) + 1)]})
decision_dir.joinpath('decision.md').write_text(f'''# D-090：多值响应头与同次事实交接的精确技术采用

2026-09-27，主线依用户“Implement the plan”、先有明确 spec／realization 再实施及主调度／验收职责授权，接受 [header-handoff rev1](../../proposals/model-request-adaptation/header-handoff.md) 的两轴 A／A，并技术接受 `data.model-response/v5` 全38条／3资源与 `capability.model-request-runtime/v5` 全73条／27资源。精确资源见 [acceptance.json](acceptance.json)，规范正文保留起草时的 candidate 标签，当前状态归 registry。本次不重采纳旧基线之外的产品修订。

MR5 接收采得且沿原凭据规则处理的 string／ordered string[] map；保留原形、数组次序、重复、空值及缺席，不承诺 HTTP 原始头行次序。RT5 S-58 的同次公共事实 `rawHeaders` 经 S-54 保留到 S-17 完整响应；取消、读体／解析故障、门失败或 reader 未进入不得擦掉已交事实。四 outcome、最多一次发送、内容门、秘密边界、费用、重试和未发出拒绝保持；不创建新失败代码、服务操作或默认值。S-33/S-36/S-64 不要求恢复从未持久且随进程丢失的头值，已提交原完整批次仍优先。

同步技术采用 [core/model-response v5-design rev1](../../../realization/packages/core/model-response/v5-design.md)，SHA256 `{node_digest}`。选择显式 `./v5`、`./schema/v5`，原根与 schema 仍 MR4，保留 v3 与 schema/v2。共享固定有序纯内核须守住完整类型联合、S-27 次序、S-36 绑定相等和独立完整 Schema；judge 不交 owned 值。该包无 plugin、fiber、服务、存储或后台任务；新增 bindings 0。此精确采用允许本 core 源码实施，PV1～9仍待实际执行。

独立架构评审分别核两轴选择和 core 窄投影，独立表达评审分别核完整 MR5／RT5 批和 core 投影，均未发现本次范围内阻断。根当前导航补足 runtime 的 D087 采用及 core 旧候选状态滞后；原历史记录和验证范围保留。共享内核旧行为回归、完整21资源闭包、两个实际公开制品与双语 literal 示例仍是实施成本。评审未运行产品或形式工具，不当实现通过。归因摘要、168输入与39候选及投影原字节封存于 [评审归档](../../proposals/model-request-adaptation/reviews/model-headers-v5-2026-09-27.tar.gz)，SHA256 `{archive_digest}`，全部{len(bundle)}成员已由 root 读回；摘要明确不是 reviewer 原始逐字工件或人的签收。

中央登记先有本决定再翻 accepted，追加30项冻结资源；原79条登记、2015覆盖、54形式任务和472冻结 hash 保留。候选新增83 covers 一律 reviewed:false；六v5形式任务只登记不声称执行，四TLA与十九cfg沿未变模型，不承载新增头性质。推荐／接受不自动升级既有消费者。

transport、runtime 与共同 codec 的 MR5／RT5 提供者投影及显式采用仍待；本决定不暗改 `mrr/1` 历史解释、wrapper／业务键或混用政策。实际 TLS→send→invoke→全部写方→append/reopen、秘密哨兵与真实停止须各原 owner 交证。G6/G28/G29-P/H/G30/G31、TL-G1、完整十三操作、真实租户链、恢复／观测及37认证保持未完成；不得以 pure Schema/judge 成功提升生产门。人的总体交付接受未发生。
''')
decision_dir.joinpath('README.md').write_text('''# D-090 多值响应头与同次事实交接

技术接受 MR5／RT5 的完整精确版本及 core v5 提供者 rev1；原消费者不自动升级。

- [决定与范围](decision.md)
- [精确接受与冻结输入](acceptance.json)

本事件仅使相应设计可实施，不表示源码、真实 IO、生产门或人的总体验收通过。
''')
acceptance = {'format': 1, 'status': 'accepted', 'decision_id': 'D-090', 'decision_path': 'record/decisions/model-headers-v5-adoption/decision.md', 'authority': 'root technical planner under user implementation and acceptance delegation; human overall acceptance excluded', 'at_utc': datetime.datetime.now(datetime.UTC).isoformat(), 'user_instruction': 'Implement the plan.', 'accepts': accepts, 'provider_adoption': {'node': 'packages/core/model-response', 'design_path': node_path, 'revision': 1, 'sha256': node_digest, 'public_adoption': {'root': 4, './schema': 4, './v5': 5, './schema/v5': 5, 'retained_v3': True, 'retained_schema_v2': True}, 'implemented_by_this_event': False, 'new_bindings': 0}, 'review_archive': 'record/proposals/model-request-adaptation/reviews/' + archive.name, 'review_archive_sha256': archive_digest, 'review_archive_members': len(bundle), 'input_count': 168, 'review_summary_is_attributed_not_verbatim': True, 'consumer_auto_upgrade': False, 'human_overall_acceptance': False, 'formal_execution': 'not run; unchanged models do not cover new rawHeaders properties', 'remaining': ['transport/runtime/codec precise projections', 'codec history and new format adoption', 'core MR5-PV1 through PV9', 'RT5-H1 through H6', 'G6', 'G28', 'G29-P/H', 'G30', 'G31', 'TL-G1', 'runtime thirteen operations', 'tenant end-to-end', 'recovery/observability', '37 official certifications']}
decision_dir.joinpath('acceptance.json').write_text(json.dumps(acceptance, ensure_ascii=False, indent=2) + '\n')

# The actual decision and exact acceptance exist before registration status changes.
for target in targets:
    target['status'] = 'accepted'
    target['acceptance'] = 'record/decisions/model-headers-v5-adoption/acceptance.json'
for accepted in accepts:
    for path, digest in accepted['resources'].items():
        assert path not in frozen['files']
        frozen['files'][path] = digest
assert len(frozen['files']) == 502
catalog_path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n')
frozen_path.write_text(json.dumps(frozen, ensure_ascii=False, indent=2) + '\n')

def prepend(path, text):
    path.write_text(text + '\n\n' + path.read_text())
def append(path, text):
    path.write_text(path.read_text().rstrip() + '\n\n' + text + '\n')
prepend(DESIGN / 'realization/packages/core/model-response/README.md', '''## 当前采用与可实施范围（2026-09-27，D-090）

- 语义接受：MR5／RT5 已由 [D-090](../../../../record/decisions/model-headers-v5-adoption/decision.md) 精确接受；本节点 [v5-design rev1](v5-design.md) 同步技术采用。
- 可实施：新增显式 `./v5`、`./schema/v5`；当前根／schema 的 MR4 和保留的 v3／schema-v2 不自动升级。D-078 承接的 v4 采用继续有效，下方候选状态按原日期读取。
- 绑定与证据：本次新增0；v5 PV1～9 尚待，原证据保持原坐标与前提。
- 实际验证：本次没有新增 v5 源码或产品执行，不从采用推断通过。

以下为原版本的历史事件；本节取代其“当前未接受／未实现”的导航口径，不改写历史验证范围。''')
prepend(DESIGN / 'spec/capabilities/model-request-runtime/README.md', '''**2026-09-27 当前规范接受（D-090）**：v5 全73条／27资源已接受并冻结；只将规范 MR4→MR5 并明确同次头事实交接。[决定](../../../record/decisions/model-headers-v5-adoption/decision.md)。D-087 已技术采用 v4-design rev2；v5 runtime/transport/codec 提供者尚待精确投影与采用，当前源码不自动升级，十三操作与真实链未完成。下方早期状态按原事件读取。''')
prepend(DESIGN / 'spec/data/model-response/README.md', '''**2026-09-27 当前规范接受（D-090）**：[v5](v5/contract.md) 全38条／3资源已接受并冻结；core 显式 v5 提供者采用与旧根保持见 [决定](../../../record/decisions/model-headers-v5-adoption/decision.md)。真实采集、脱敏、交接与持久链仍待，规范内 candidate 标签按起草时间读取。''')
append(DESIGN / 'record/proposals/model-request-adaptation/review.md', f'''## 2026-09-27 多值响应头／MR5-RT5 与 core v5 独立评审

两轴 A/A 的 architecture-reviewer、完整 MR5/RT5 的 spec-reviewer、core v5 rev1 的两角色独立只读评审均无本次范围内阻断。受审 MR5 c4cba40c…／RT5 21c3ef25…，core `{node_digest}`；详细责任与未覆盖为 [root 据实际角色消息保存的归因摘要](reviews/model-headers-v5-2026-09-27.json)及其完整归档，不能当逐字 reviewer 原件或产品执行。规范整批的 runtime D087 导航滞后与 core 旧候选导航由本次当前段落修正；旧记录不覆盖。无新增产品政策，codec mrr/1／新格式仍归共同 owner。

主线 [D-090](../../decisions/model-headers-v5-adoption/decision.md)只精确接受完整规范与 core 投影。PV1～9、RT5-H1～6、真实 TLS／秘密／停止／append-reopen、全部写方及十三操作和37认证均待；新增 bindings0。评审归档全部{len(bundle)}成员原字节读回，SHA256 `{archive_digest}`。''')
append(DESIGN / 'record/decisions/README.md', '2026-09-27：[D-090](model-headers-v5-adoption/decision.md)精确接受 MR5／RT5 与 core v5 投影；原根与历史消费者不自动升级，源码／IO／生产验收另核。')
append(DESIGN / 'registry/README.md', '2026-09-27：[D-090](../record/decisions/model-headers-v5-adoption/decision.md)新增 MR5／RT5 accepted，30资源冻结；当前81登记／502冻结／2098 covers／60形式任务，本批83 covers一律reviewed:false。原79登记、472冻结、2015 covers、54任务保持；新增形式任务未执行，不覆盖新增头事实。')
receipt = {'scope': 'exact technical adoption only', 'archive_sha256': archive_digest, 'archive_members': len(bundle), 'old_frozen': 472, 'new_frozen': 502, 'catalog': len(catalog['contracts']), 'covers': len(read(DESIGN / 'registry/covers.json')['covers']), 'formal_tasks': len(read(DESIGN / 'registry/formal-tasks.json')['tasks']), 'core_projection_sha256': node_digest, 'normative_resources': {p: h for accepted in accepts for p, h in accepted['resources'].items()}}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'normative_resources'}, ensure_ascii=False))
