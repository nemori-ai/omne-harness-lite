#!/usr/bin/env python3
"""Mutation checks for the smoke oracle; entirely offline, no Docker imports."""

import copy
import json
import pathlib
import tempfile

import oracle

HERE = pathlib.Path(__file__).resolve().parent
CID = "a" * 64
IMAGE_ID = "sha256:" + "b" * 64
BUILD_ID = "c" * 64
STATE = "/var/lib/omne-tenancy/state"
PROJECT = "r5abc1234"
FILE = "d" * 32 + ".omne-backup"
SOURCE = STATE + "/backups/" + FILE
TARGET = STATE + "/restores/" + PROJECT
META = {"format": "omne-center-backup/1", "centerId": "center-1", "sourceBuildId": BUILD_ID,
        "migrationNames": ["initial"], "startedAt": "2026-09-27T00:00:00.000Z",
        "finishedAt": "2026-09-27T00:00:01.000Z", "byteLength": 10, "sha256": "e" * 64}
DESC = {"fileName": FILE, "metadata": META}


def running(status="running", code=0, started="start-1"):
    return [{"Id": CID, "Image": IMAGE_ID, "Config": {"User": "10001:10001",
            "StopSignal": "SIGTERM", "StopTimeout": -1,
            "Labels": {"ai.nemori.omne.project": PROJECT,
                       "ai.nemori.omne.service": "center",
                       "ai.nemori.omne.host-build-id": BUILD_ID}},
            "State": {"Status": status, "ExitCode": code, "Running": status == "running",
                      "Pid": 123 if status == "running" else 0,
                      "Health": {"Status": "healthy"}, "StartedAt": started},
            "Mounts": [{"Destination": "/state", "Source": STATE, "RW": True}]}]


def seed(root):
    raw = root / "raw"
    raw.mkdir()
    commands = []

    def add(label, value, rc=0, json_line=True):
        data = json.dumps(value, separators=(",", ":")).encode() + b"\n" if json_line else value
        (raw / f"{label}.stdout").write_bytes(data)
        (raw / f"{label}.stderr").write_bytes(b"")
        actions = {"validate": "validate", "start": "start", "full-health": "full-health",
                   "backup": "backup", "backup-status": "backup-status", "verify": "verify",
                   "restore": "restore-isolated", "stop": "stop", "stop-exited": "stop"}
        argv = []
        if label in actions:
            argv = ["docker", "exec", "-e",
                    "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock", "control",
                    "/usr/local/libexec/omne-center", actions[label]]
        elif label.startswith("inspect-"):
            argv = ["docker", "exec", "control", "docker", "--host",
                    "unix:///opt/omne-private-docker/docker.sock", "inspect", CID]
        elif label == "center-events":
            argv = ["docker", "exec", "control", "docker", "--host",
                    "unix:///opt/omne-private-docker/docker.sock", "events",
                    "--filter", "container=" + CID]
        commands.append({"label": label, "returncode": rc, "observation_expired": False,
                         "stdout": f"raw/{label}.stdout", "stderr": f"raw/{label}.stderr",
                         "argv": argv})

    add("validate", {"state": "deployment-structure-valid"})
    add("start", {"state": "running", "containerId": CID, "imageId": IMAGE_ID,
                  "buildId": BUILD_ID, "health": "healthy"})
    for label in ("control-inode", "dind-inode", "app-inode"):
        add(label, b"100:10001:10001:700\n", json_line=False)
    for label in ("read-view-marker", "app-view-marker"):
        add(label, b"101:0\n", json_line=False)
    add("inspect-running", running())
    add("full-health", {"reachable": True, "storageReachable": True, "clockSane": True,
                        "deploymentKeyPresent": True, "deploymentKeyComplete": True,
                        "defectCount": 0, "centerId": "center-1"})
    add("backup", {"status": "completed", "backup": DESC})
    add("backup-status", {"status": "observed", "health": "current",
                          "latest": DESC, "invalidCount": 0})
    add("backup-file-stat", b"regular file:10001:10001:600:123\n", json_line=False)
    add("verify", {"status": "verified", "metadata": META, "businessOpen": False})
    add("restore", {"status": "restored-isolated", "metadata": META,
                    "targetLocation": "/state/restores/" + PROJECT, "businessOpen": False})
    add("restore-target-stat", b"directory:10001:10001:700\n", json_line=False)
    add("restore-marker-stat", b"regular file:600\n", json_line=False)
    add("timer-running-timer-before", b"LastTriggerUSec=n/a\n", json_line=False)
    add("timer-running-timer-after", b"LastTriggerUSec=2026-09-27 00:00:00 UTC\n",
        json_line=False)
    add("timer-running-service-before", b"ExecMainStartTimestampMonotonic=0\n",
        json_line=False)
    add("timer-running-state", b"Result=success\nExecMainStatus=0\nActiveState=inactive\n"
        b"ExecMainStartTimestampMonotonic=100\nExecMainExitTimestampMonotonic=101\n",
        json_line=False)
    add("stop", {"state": "stopped", "containerId": CID, "exitCode": 0, "clean": True})
    add("inspect-stopped", running("exited"))
    add("stop-exited", {"state": "stop-intent-unconfirmed", "containerId": CID,
                         "exitCode": 0}, rc=1)
    add("inspect-after-exited-stop", running("exited"))
    add("timer-stopped-timer-before", b"LastTriggerUSec=2026-09-27 00:00:00 UTC\n",
        json_line=False)
    add("timer-stopped-timer-after", b"LastTriggerUSec=2026-09-27 00:01:00 UTC\n",
        json_line=False)
    add("timer-stopped-service-before", b"ExecMainStartTimestampMonotonic=100\n",
        json_line=False)
    add("timer-stopped-state", b"Result=exit-code\nExecMainStatus=1\nActiveState=failed\n"
        b"ExecMainStartTimestampMonotonic=200\nExecMainExitTimestampMonotonic=201\n",
        json_line=False)
    add("inspect-after-timer", running("exited"))
    add("center-events", {"Action": "kill", "Actor": {"ID": CID,
        "Attributes": {"signal": "15"}}})
    cleanup = []
    for label in ("cleanup-final-list-container", "cleanup-final-list-volume",
                  "cleanup-final-list-network", "cleanup-inner-project-final-list",
                  "cleanup-inner-fixture-final-list", "cleanup-inner-all-final-list"):
        (raw / f"{label}.stdout").write_bytes(b"")
        (raw / f"{label}.stderr").write_bytes(b"")
        cleanup.append({"label": label, "returncode": 0,
                        "stdout": f"raw/{label}.stdout", "stderr": f"raw/{label}.stderr"})
    evidence = {"commands": commands, "source": SOURCE,
                "expected": {"image_id": IMAGE_ID, "inner_image_id": IMAGE_ID,
                             "build_id": BUILD_ID, "project": PROJECT,
                             "control": "control", "dind": "dind",
                             "uid": 10001, "gid": 10001, "state": STATE, "target": TARGET,
                             "target_in_container": "/state/restores/" + PROJECT},
                "business_complete": True, "cleanup_complete": True, "cleanup_errors": [],
                "cleanup_commands": cleanup}
    (root / "evidence.json").write_text(json.dumps(evidence))
    return evidence


def write(root, evidence, label, value):
    (root / "raw" / f"{label}.stdout").write_bytes(value)
    (root / "evidence.json").write_text(json.dumps(evidence))


def test():
    cases = {}
    with tempfile.TemporaryDirectory(dir=HERE, prefix="self-test-") as temp:
        root = pathlib.Path(temp)
        base = seed(root)
        cases["valid"] = oracle.evaluate(root)["status"] == "limited_pass"

        write(root, base, "stop", b"")
        try:
            oracle.evaluate(root)
            cases["empty_stop_output"] = False
        except ValueError:
            cases["empty_stop_output"] = True
        seed_again = root / "reset"
        seed_again.mkdir()
        base = seed(seed_again)
        run = seed_again

        wrong = copy.deepcopy(running("exited"))
        wrong[0]["Id"] = "f" * 64
        write(run, base, "inspect-stopped", json.dumps(wrong).encode() + b"\n")
        try:
            oracle.evaluate(run)
            cases["wrong_id"] = False
        except ValueError:
            cases["wrong_id"] = True

        contradict = root / "contradict"
        contradict.mkdir()
        base = seed(contradict)
        bad = running("exited", code=1)
        write(contradict, base, "inspect-stopped", json.dumps(bad).encode() + b"\n")
        try:
            oracle.evaluate(contradict)
            cases["exit_state_contradiction"] = False
        except ValueError:
            cases["exit_state_contradiction"] = True

        cleanup = root / "cleanup"
        cleanup.mkdir()
        base = seed(cleanup)
        base["cleanup_complete"] = False
        base["cleanup_errors"] = ["volume remains"]
        (cleanup / "evidence.json").write_text(json.dumps(base))
        try:
            oracle.evaluate(cleanup)
            cases["failed_cleanup_cannot_pass"] = False
        except ValueError:
            cases["failed_cleanup_cannot_pass"] = True

        missing = root / "missing"
        missing.mkdir()
        base = seed(missing)
        base["commands"] = [entry for entry in base["commands"] if entry["label"] != "stop"]
        (missing / "evidence.json").write_text(json.dumps(base))
        try:
            oracle.evaluate(missing)
            cases["missing_exit_record"] = False
        except (KeyError, ValueError):
            cases["missing_exit_record"] = True

        no_term = root / "no-term"
        no_term.mkdir()
        base = seed(no_term)
        write(no_term, base, "center-events", b"")
        try:
            oracle.evaluate(no_term)
            cases["missing_actual_term_event"] = False
        except ValueError:
            cases["missing_actual_term_event"] = True

        residue = root / "residue"
        residue.mkdir()
        seed(residue)
        (residue / "raw" / "cleanup-final-list-volume.stdout").write_bytes(b"remaining-volume\n")
        try:
            oracle.evaluate(residue)
            cases["cleanup_claim_without_empty_label_query"] = False
        except ValueError:
            cases["cleanup_claim_without_empty_label_query"] = True

        stale_timer = root / "stale-timer"
        stale_timer.mkdir()
        base = seed(stale_timer)
        write(stale_timer, base, "timer-stopped-timer-after",
              b"LastTriggerUSec=2026-09-27 00:00:00 UTC\n")
        try:
            oracle.evaluate(stale_timer)
            cases["stale_timer_state"] = False
        except ValueError:
            cases["stale_timer_state"] = True

        wrong_daemon = root / "wrong-daemon"
        wrong_daemon.mkdir()
        base = seed(wrong_daemon)
        for item in base["commands"]:
            if item["label"] == "inspect-stopped":
                item["argv"][5] = "unix:///var/run/docker.sock"
        (wrong_daemon / "evidence.json").write_text(json.dumps(base))
        try:
            oracle.evaluate(wrong_daemon)
            cases["wrong_daemon_provenance"] = False
        except ValueError:
            cases["wrong_daemon_provenance"] = True

    return cases


if __name__ == "__main__":
    result = test()
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(0 if all(result.values()) else 1)
