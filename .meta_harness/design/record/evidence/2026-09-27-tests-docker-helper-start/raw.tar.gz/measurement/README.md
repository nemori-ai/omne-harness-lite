# R5 helper 首轮真实纵向 smoke：静态准备，尚未运行

本包只准备一次可由 root 审核后另行放行的 Linux control + 私有 DinD 测量。`driver.py`、`oracle.py` 和离线负控已经写好；**没有调用 Docker、没有构建镜像、没有读取部署秘密、没有最终 R5 helper/I3 制品结果**。本目录是忽略的临时证据，不是设计规格或产品验收记录。

采用依据为 EC3 v3 S-55～S-59、其 `governance-center-entry.schema.json`，HT3 v3 S-20～S-21（该 topic 没有独立 JSON Schema；S-21 明确引用 EC3 的输入/结果 Schema），D-071 `decision.md` 及 `provider-snapshot.json`，`realization/apps/tenancy-host/{design,docker,verification}.md`。本次 `docker.md` SHA256 为 `3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223`。施工边界来自 HUB `tmp/next-iteration/tasks/docker-delivery.md` 与 `docker-stop-r5-implementation.md`。现有 V0-c Linux 环境证据和 I1 IO 先导只提供夹具前提；旧 I2 helper 及 I1 镜像绝不代替本轮最终输入。

## 最小路径、资源与命令矩阵

| 阶段 | Linux 进程、daemon 与路径 | 观察点 |
| --- | --- | --- |
| 输入冻结 | 驱动在本 spoke 校验 `helper`、两 Compose、health、service/timer、image tar 各自 SHA，镜像 ID、BUILD_ID；V0-c CLI/Compose SHA 固定。`--print-inputs` 只做本地哈希。 | root 对 `inputs_sha256`、driver/oracle SHA、最终 I3 清单核对后另写 gate。`--execute` 与有效 gate 同时存在才能碰 Docker。 |
| 私有环境 | 宿主 Docker **只**按本 run 唯一 `omne.r5.helper-prep=<run-id>` label 建 control、DinD、3 卷、网络并在最后清理。宿主 CLI 只运输 copy/load 和管理这些外层资源；不挂用户 Docker socket到 control，不重启宿主 daemon。 | 固定 control image、DinD image ID；control root/systemd252、CLI/Engine29.1.3、Compose2.40.3；外层 Mounts 只能是 named volume 且无端口。 |
| Linux 同根 | control、DinD 同挂 `/var/lib/omne-tenancy`；应用 UID/GID 默认10001正整数，可显式替换。state 下 data/backups/offline-work/restores、secrets 私有；settings root0600。 | 三方 stat 同一 inode/UID/GID/mode 和 marker 可见；真实中心 inspect `/state` mount、非root User。 |
| 制品 | 传入 tar 从宿主 stdin 流入 DinD 的 `docker load`。内外 image ID 可因导入表示不同，分别留原值；比对 Linux/arm64、RootFS.Layers 和 BUILD_ID/distribution label。 | `image inspect` 原始输出、实际中心 `Image`、label、PID、健康。首轮仅 arm64；amd64/I3 双架构另验。 |
| 产品纵线 | **root control 容器内**调用最终 `/usr/local/libexec/omne-center`，`DOCKER_HOST` 指向私有 socket：`validate → start → full-health → backup → backup-status → verify → restore-isolated → stop → 再 stop 初始 exited`。镜像中 app 的 keygen 建一次性密钥；helper 对内层 daemon 操作。 | helper 原 stdout/stderr 与 exit 即时落独立文件；原 `docker inspect`、备份文件 stat、恢复隔离 marker、Engine event 同时取证。backup 完成文件名导出 source；离线 stdout 必须独立一份 JSON+LF、businessOpen=false；stop 要同 ID exit0 且恰一次可观察 SIGTERM event。 |
| timer 执行路径 | 实际 control systemd 加载产品 unit/timer；隔离容器内只加一次性 QA drop-in，将 `OnCalendar` 清空并设 `OnActiveSec=2s`，不改产品 service、Unit 指向或启动依赖。运行/已停状态各启动一次实际 timer，再读 `LastTriggerUSec`、service 主进程起止时间、Result/ExecMainStatus 与中心原 ID 状态。 | 两次真实 timer trigger 和 service 进程各自更新；运行时成功，已停时非零，中心 StartedAt 不变。此处只证明加速排程下的真实 timer 执行路径和不复活；原每小时 `OnCalendar` 的实际墙钟到点不在首轮。产品原 unit/timer 与测试 drop-in 内容都留原始输出，产品文件纳入输入哈希。 |
| 收场 | 业务检查结束后才进入 fixture cleanup：先按唯一 project 与 QA label 在私有 Engine 列出/核 ID 并可 `rm -f`；再按唯一 run label 删除外层资源。 | 清理原始命令与三个外层 exact-label 空查询、内层 project/QA 空查询及私有 Engine 全容器空查询必须齐全；清理失败不能改变业务结论或令 oracle pass。这里的强删只属于测量夹具，与产品正常 stop 分开。 |

`driver.py` 每条命令在 `runs/<run-id>/raw/<label>.stdout/.stderr` 直接接收原始字节，`evidence.json` 写 argv、时间、真实 exit、观察超时和资源。正常 stop **没有**产品有限 KILL deadline；`--observe-seconds` 仅限测量器等待，若到期记录 unknown，随后夹具清理可强删私有资源，绝不记作产品停止完成。尝试私有环境清理后，测量器会收回自己遗留的本地 Docker CLI 并单列其动作；那不是对应用再发 TERM/KILL，清理失败仍报失败。Engine 的 rc0/空 wait 和 TERM ack 不能成为成功依据：oracle 要求 helper 完整 JSON+LF、同 ID 实际 `exited/ExitCode` 与唯一 TERM event。HTTP/运维的成功结果还须对照原 EC3 表示、真实文件/marker。stdout/stderr 只写本次私有目录，不只留长度或抽样。

## root 复审与将来单次运行

运行前，root 需要给出**最终** helper 目录、I3 arm64 tar、各文件 SHA256、外层 image ID 和 BUILD_ID；不能从本目录的候选源码或旧 I1 清单推定。driver 参数为 `--helper-dir`、`--helper-sha256`、`--compose-sha256`、`--maintenance-compose-sha256`、`--health-sha256`、`--service-sha256`、`--timer-sha256`、`--image-tar`、`--image-tar-sha256`、`--image-id`、`--build-id`，可选 `--uid/--gid/--observe-seconds/--timer-observe-seconds`。先带全部参数及 `--print-inputs` 离线打印精确 `inputs` 与 `inputs_sha256`，核静态清单后由 root 在本目录写 `reviewed-gate.json`（此文件现在不存在）：

```json
{
  "approved": true,
  "reviewer": "root",
  "inputs_sha256": "<root 核对的 --print-inputs 值>",
  "driver_sha256": "<本轮 driver SHA256>",
  "oracle_sha256": "<本轮 oracle SHA256>"
}
```

再使用**相同参数**加 `--reviewed-gate <本目录/reviewed-gate.json的绝对路径> --execute` 单次运行。缺 gate、路径或 hash 变更均在首次 Docker 命令前拒绝，运行目录另冻结一份 gate 并记录其 SHA。将来执行成功只表示本有限 oracle 对本次原始观察通过；独立 reviewer 与主线仍须核原件、版本和范围。驱动自动调用冻结副本的 `oracle.py runs/<run-id>`，另存 `oracle.stdout/stderr`；可独立复跑 oracle。run 目录必须在 spoke 退休前由 root 保全。

## 本轮离线验证与明确未覆盖

`PYTHONDONTWRITEBYTECODE=1 python3 -B self_test.py` 使用授权目录内临时输入，正例通过，负例检出缺/空 stop 结果、错 ID、实际 exit 矛盾、无 TERM event、cleanup 错误及假空查询。`python3` AST parse 也通过。临时目录不留构建输出；项目共享格式化只覆盖维护的 TS/JS，不作用于本目录 Python/Markdown。

首轮不覆盖长 IO >31 秒、close EIO 残余与第二 owner、wait rc0 空结果的真实注入、restarting、丢回执、startup 失败、离线取消/断连/并发、daemon 重启/并发 shutdown、原每小时 timer 的墙钟到点、强杀恢复、两账号治理 TLS旅程、升级及 amd64。下一 wave 的 caller 可处理退出还须核**本地等待 Docker 客户端已收回，中心原资源仍按真实排空持有**；本地 wait 客户端退出不等于应用完成。旧 gate 可供下一 wave 定向使用，必须换最终产品制品并重新核 app inventory；旧 I1 成功不能升级为 R5 helper 结果。若最终 helper 的真实行为与 oracle/契约不符，保留原始失败并交回产品 owner，不改产品或放宽判据。
