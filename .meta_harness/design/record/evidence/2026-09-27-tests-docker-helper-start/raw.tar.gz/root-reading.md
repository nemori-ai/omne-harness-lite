# Root reading of the first final-artifact helper observation

Source integration cad70bb799cc1e4b949a27858b6a16e92ec2938f; helper 0602a52ef521a3a41971097e80c560db2fb24cc69cb2d5098634f81774bd156d, host BUILD_ID b921f14cdac3a3246a32b0745794e8e36b2e8a5e37c37cdd32fee18db918479b. Artifact metadata and root inventory verification are retained separately.

Single authorized run 20260926T191856Z-f3b18dbd ended observation-incomplete: validate succeeded, start returned actual-container-unsafe before application start. Nineteen actual-container predicates were examined; the expected third Mounts element and tmpfs Mounts member were the two false predicates. HostConfig.Tmpfs already carried the intended configuration. This rejects the implementation projection, not the accepted tmpfs isolation requirement.

174 original input/output files were independently hashed against post-run-files.sha256.json and copied byte-for-byte. The driver and oracle remain in their original static snapshot; no successful business, timer, stop, backup, restore or runtime tmpfs result is claimed for this run. Fixture cleanup completed; three independent exact-label resource queries returned empty with exit zero. No automatic rerun occurred.

The root's following-source reading is retained in the adjacent docker-tmpfs-source directory. Correction is delegated to the product owner; no product mutation is made by the independent QA author. Old I3 snapshots and failed observation are preserved; later runs require rebuilt matching artifacts and new gates.
