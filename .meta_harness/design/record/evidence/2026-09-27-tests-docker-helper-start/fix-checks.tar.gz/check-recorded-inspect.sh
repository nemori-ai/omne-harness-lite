#!/usr/bin/env bash
set -euo pipefail
source apps/tenancy-host/deploy/docker/omne-center
inspect_file="$1"
expected_sha=0fbcebf15ed81508e51cd1d7bef18a2f68d670897f630f6a26d70b095d29f3fb
observed_sha="$(shasum -a 256 "$inspect_file" | cut -d ' ' -f 1)"
[[ "$observed_sha" == "$expected_sha" ]] || { printf 'recorded-input-hash-mismatch\n' >&2; exit 1; }
inspected="$(cat "$inspect_file")"
user="$(jq -er '.[0].Config.User' <<< "$inspected")"
app_uid="${user%%:*}"
app_gid="${user#*:}"
state_dir="$(jq -er '.[0].Mounts[] | select(.Destination == "/state") | .Source' <<< "$inspected")"
secrets_dir="$(jq -er '.[0].Mounts[] | select(.Destination == "/secrets") | .Source' <<< "$inspected")"
desired_image_id="$(jq -er '.[0].Image' <<< "$inspected")"
publish_address="$(jq -er '.[0].HostConfig.PortBindings."8443/tcp"[0].HostIp' <<< "$inspected")"
publish_port="$(jq -er '.[0].HostConfig.PortBindings."8443/tcp"[0].HostPort' <<< "$inspected")"
verify_container_image() { :; }
validate_actual_center "$inspected"
printf 'recorded-created-inspect-accepted sha256=%s mounts=%s tmpfsKeys=%s\n' "$observed_sha" \
  "$(jq -r '.[0].Mounts | length' <<< "$inspected")" \
  "$(jq -r '.[0].HostConfig.Tmpfs | keys | length' <<< "$inspected")"
