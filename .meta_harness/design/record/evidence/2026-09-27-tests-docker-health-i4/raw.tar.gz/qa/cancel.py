#!/usr/bin/env python3
"""Original-image Docker outer-timeout probe. No Docker without an exact root gate."""

import argparse
import datetime
import hashlib
import json
import pathlib
import secrets
import shutil
import subprocess
import sys
import time

import inputs as source

HERE = pathlib.Path(__file__).resolve().parent
HEALTH = ["CMD", "node", "/opt/omne/app/deploy/docker/health.mjs"]


def prepared(args):
    data = source.checked(args.manifest, args.manifest_sha256, "arm64")
    data["case"] = "cancel"
    data["source_shas"] = {
        name: source.sha(HERE / name)
        for name in (
            "inputs.py",
            "cancel.py",
            "cancel_oracle.py",
            "hold-ops.mjs",
            "inventory.mjs",
        )
    }
    return data


class Run:
    def __init__(self, data, gate):
        self.id = (
            datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            + "-"
            + secrets.token_hex(4)
        )
        self.path = HERE / "runs" / ("cancel-" + self.id)
        self.path.mkdir(mode=0o700, parents=True, exist_ok=False)
        (self.path / "raw").mkdir(mode=0o700)
        frozen = self.path / "inputs"
        frozen.mkdir(mode=0o700)
        for name in (
            "inputs.py",
            "cancel.py",
            "cancel_oracle.py",
            "hold-ops.mjs",
            "inventory.mjs",
        ):
            target = frozen / name
            shutil.copyfile(HERE / name, target)
            source.need(
                source.sha(target) == data["source_shas"][name],
                "frozen measuring source changed",
            )
        shutil.copyfile(data["manifest"], frozen / "manifest-delivery.json")
        source.need(
            source.sha(frozen / "manifest-delivery.json") == data["manifest_sha256"],
            "frozen manifest changed",
        )
        shutil.copyfile(gate, frozen / "reviewed-gate.json")
        self.name = "omne-health-qa-" + self.id.lower().replace("t", "-").replace(
            "z", ""
        )
        self.label = "ai.nemori.omne.health-qa=" + self.id
        self.data = data
        self.events = {
            "case": "cancel",
            "input": data,
            "gate_sha256": source.sha(frozen / "reviewed-gate.json"),
            "name": self.name,
            "label": self.label,
            "commands": [],
            "cleanup": [],
            "business_verdict": "unverified",
            "cleanup_verdict": "unverified",
        }
        self.save()

    def save(self):
        (self.path / "evidence.json").write_text(
            json.dumps(self.events, sort_keys=True, indent=2) + "\n"
        )

    def call(self, tag, *argv, timeout=20, cleanup=False, expected=0):
        records = self.events["cleanup" if cleanup else "commands"]
        source.need(all(row["tag"] != tag for row in records), "duplicate command tag")
        row = {
            "tag": tag,
            "argv": ["docker", *argv],
            "startUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "stdout": "raw/" + tag + ".stdout",
            "stderr": "raw/" + tag + ".stderr",
            "rc": None,
            "observationTimeout": False,
        }
        records.append(row)
        self.save()
        with (
            (self.path / row["stdout"]).open("xb") as out,
            (self.path / row["stderr"]).open("xb") as err,
        ):
            try:
                result = subprocess.run(
                    row["argv"], stdout=out, stderr=err, timeout=timeout, check=False
                )
                row["rc"] = result.returncode
            except subprocess.TimeoutExpired:
                row["observationTimeout"] = True
        row["endUtc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        self.save()
        source.need(not row["observationTimeout"], tag + ": observation timed out")
        if expected is not None:
            source.need(row["rc"] == expected, tag + ": rc " + str(row["rc"]))
        return (self.path / row["stdout"]).read_bytes()

    def inspect(self, tag):
        value = json.loads(self.call(tag, "inspect", self.name))
        source.need(
            len(value) == 1 and value[0]["Name"] == "/" + self.name,
            "container identity",
        )
        source.need(
            value[0]["Config"]["Labels"].get("ai.nemori.omne.health-qa") == self.id,
            "container label",
        )
        return value[0]

    def cleanup(self):
        errors = []
        try:
            ids = (
                self.call(
                    "cleanup-list",
                    "ps",
                    "-aq",
                    "--no-trunc",
                    "--filter",
                    "label=" + self.label,
                    cleanup=True,
                )
                .decode()
                .splitlines()
            )
            for index, cid in enumerate(ids):
                inspected = json.loads(
                    self.call(
                        "cleanup-inspect-" + str(index), "inspect", cid, cleanup=True
                    )
                )[0]
                source.need(
                    inspected["Id"] == cid
                    and inspected["Name"]
                    in ("/" + self.name, "/" + self.name + "-inventory")
                    and inspected["Config"]["Labels"].get("ai.nemori.omne.health-qa")
                    == self.id,
                    "cleanup identity mismatch",
                )
                self.call("cleanup-remove-" + str(index), "rm", "-f", cid, cleanup=True)
            remain = self.call(
                "cleanup-final-list",
                "ps",
                "-aq",
                "--no-trunc",
                "--filter",
                "label=" + self.label,
                cleanup=True,
            )
            source.need(remain == b"", "labelled QA container residue")
        except Exception as error:
            errors.append(f"{type(error).__name__}: {error}")
        self.events["cleanup_errors"] = errors
        self.events["cleanup_verdict"] = "pass" if not errors else "unverified"
        self.save()


def execute(args, data):
    run = Run(data, args.reviewed_gate)
    try:
        image = json.loads(
            run.call("image-inspect", "image", "inspect", data["image_id"])
        )[0]
        producer = json.loads(pathlib.Path(data["image_inspection"]).read_text())
        if isinstance(producer, list):
            source.need(len(producer) == 1, "producer inspect count")
            producer = producer[0]
        source.need(
            image["Id"] == data["image_id"]
            and image["Os"] == "linux"
            and image["Architecture"] == "arm64",
            "original image identity/platform",
        )
        source.need(
            image["RootFS"]["Layers"] == data["rootfs_layers"]
            and producer["Id"] == data["image_id"],
            "original image layers",
        )
        labels = image["Config"]["Labels"]
        source.need(
            labels["ai.nemori.omne.host-build-id"] == data["host_build_id"]
            and labels["org.opencontainers.image.version"] == data["version"]
            and labels["ai.nemori.omne.distribution"] == "tenancy-host-docker/1",
            "original image labels",
        )
        source.need(
            image["Config"]["Healthcheck"]["Test"] == HEALTH, "original HEALTHCHECK"
        )
        source.need(
            image["Config"]["Entrypoint"] == ["node", "/opt/omne/app/dist/cli.js"]
            and image["Config"]["Cmd"] == ["serve"],
            "original entrypoint",
        )
        inventory = run.path / "inputs/inventory.mjs"
        run.call(
            "image-full-inventory",
            "run",
            "--rm",
            "--pull",
            "never",
            "--network",
            "none",
            "--name",
            run.name + "-inventory",
            "--label",
            run.label,
            "-e",
            "EXPECTED_BUILD_ID=" + data["host_build_id"],
            "-e",
            "EXPECTED_MANIFEST_SHA256=" + data["host_manifest_sha256"],
            "--mount",
            f"type=bind,source={inventory},target=/qa/inventory.mjs,readonly",
            "--entrypoint",
            "node",
            data["image_id"],
            "/qa/inventory.mjs",
            timeout=90,
        )
        for suffix in ("", "-inventory"):
            absent = run.call(
                "name-absent" + suffix,
                "ps",
                "-aq",
                "--no-trunc",
                "--filter",
                "name=^/" + run.name + suffix + "$",
                expected=0,
            )
            source.need(absent == b"", "QA name collision")
        qa = run.path / "inputs/hold-ops.mjs"
        created = (
            run.call(
                "create",
                "run",
                "-d",
                "--pull",
                "never",
                "--name",
                run.name,
                "--label",
                run.label,
                "--network",
                "none",
                "--restart",
                "no",
                "--health-interval",
                "1s",
                "--health-timeout",
                "2s",
                "--health-start-period",
                "1ms",
                "--health-retries",
                "1",
                "--tmpfs",
                "/run/omne-tenancy:rw,nosuid,nodev,noexec,size=16m,uid=10001,gid=10001,mode=0700",
                "--mount",
                f"type=bind,source={qa},target=/qa/hold-ops.mjs,readonly",
                "--entrypoint",
                "node",
                data["image_id"],
                "/qa/hold-ops.mjs",
                timeout=45,
            )
            .decode()
            .strip()
        )
        initial = run.inspect("inspect-initial")
        source.need(
            initial["Id"] == created and initial["Image"] == data["image_id"],
            "created original image",
        )
        source.need(
            initial["Config"]["Healthcheck"]["Test"] == HEALTH
            and initial["Config"]["Healthcheck"]["Timeout"] == 2_000_000_000
            and initial["Config"]["Healthcheck"]["Interval"] == 1_000_000_000
            and initial["Config"]["Healthcheck"]["StartPeriod"] == 1_000_000
            and initial["Config"]["Healthcheck"]["Retries"] == 1,
            "actual Docker health policy",
        )
        source.need(
            initial["Config"]["Entrypoint"] == ["node"]
            and initial["Config"]["Cmd"] == ["/qa/hold-ops.mjs"]
            and initial["Config"]["User"] == "10001:10001"
            and initial["HostConfig"]["NetworkMode"] == "none",
            "QA override bounds",
        )
        mounts = initial["Mounts"]
        binds = [mount for mount in mounts if mount["Type"] == "bind"]
        source.need(
            len(binds) == 1
            and binds[0]["Source"] == str(qa)
            and binds[0]["Destination"] == "/qa/hold-ops.mjs"
            and binds[0]["RW"] is False
            and all(mount["Type"] in ("bind", "tmpfs") for mount in mounts)
            and all(
                mount["Type"] != "tmpfs" or mount["Destination"] == "/run/omne-tenancy"
                for mount in mounts
            )
            and set(initial["HostConfig"]["Tmpfs"]) == {"/run/omne-tenancy"},
            "only QA readonly bind and private ops tmpfs",
        )
        deadline = time.monotonic() + 15
        for attempt in range(1, 16):
            run.call(f"logs-{attempt}", "logs", run.name)
            current = run.inspect(f"inspect-{attempt}")
            events = [
                json.loads(line)
                for line in (run.path / f"raw/logs-{attempt}.stdout")
                .read_text()
                .splitlines()
                if line
            ]
            health_log = current["State"].get("Health", {}).get("Log", [])
            timeout_rows = [
                row
                for row in health_log
                if row.get("ExitCode") == -1
                and "timeout" in row.get("Output", "").lower()
            ]
            if (
                timeout_rows
                and any(
                    e.get("event") == "sample" and e.get("firstPresent") is False
                    for e in events
                )
                and any(
                    e.get("event") in ("late-write-result", "peer-socket-error")
                    for e in events
                )
            ):
                run.events["final_inspect_tag"] = f"inspect-{attempt}"
                run.events["final_logs_tag"] = f"logs-{attempt}"
                run.save()
                break
            source.need(
                time.monotonic() < deadline,
                "required timeout/disappearance/late-write observation missing",
            )
            time.sleep(0.7)
        else:
            raise RuntimeError("bounded observation exhausted")
        run.events["business_verdict"] = "observed-awaiting-oracle"
        run.save()
    except Exception as error:
        run.events["business_error"] = f"{type(error).__name__}: {error}"
        run.save()
    finally:
        run.cleanup()
    result = subprocess.run(
        [
            sys.executable,
            "-B",
            str(run.path / "inputs/cancel_oracle.py"),
            str(run.path),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    (run.path / "oracle.stdout").write_text(result.stdout)
    (run.path / "oracle.stderr").write_text(result.stderr)
    run.events["oracle_exit"] = result.returncode
    run.save()
    print(
        json.dumps(
            {
                "run": str(run.path),
                "oracle_exit": result.returncode,
                "cleanup": run.events["cleanup_verdict"],
            },
            sort_keys=True,
        )
    )
    return result.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=pathlib.Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    data = prepared(args)
    digest = hashlib.sha256(source.canonical(data)).hexdigest()
    if args.print_inputs or not args.execute:
        print(json.dumps({"inputs": data, "inputs_sha256": digest}, sort_keys=True))
        return 0
    source.need(args.reviewed_gate is not None, "root gate required")
    gate = json.loads(args.reviewed_gate.read_text())
    source.need(
        gate
        == {
            "approved": True,
            "reviewer": "root",
            "inputs_sha256": digest,
            "driver_sha256": data["source_shas"]["cancel.py"],
            "oracle_sha256": data["source_shas"]["cancel_oracle.py"],
        },
        "root gate mismatch",
    )
    return execute(args, data)


if __name__ == "__main__":
    raise SystemExit(main())
