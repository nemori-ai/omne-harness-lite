// QA-only PID 1. It owns a private socket and never answers the request.
import fs from 'node:fs'
import net from 'node:net'

const socketPath = '/run/omne-tenancy/governance-center-ops.sock'
const expectedBody = JSON.stringify({ opsVersion: '1', operation: 'full-health', payload: {} })
const log = (event, detail = {}) =>
  process.stdout.write(`${JSON.stringify({ event, wallUtc: new Date().toISOString(), monoNs: String(process.hrtime.bigint()), ...detail })}\n`)

function processes() {
  const found = []
  for (const entry of fs.readdirSync('/proc')) {
    if (!/^\d+$/.test(entry)) continue
    try {
      const root = `/proc/${entry}`
      const stat = fs.readFileSync(`${root}/stat`, 'utf8')
      const tail = stat.slice(stat.lastIndexOf(')') + 2).trim().split(' ')
      const cmdline = fs.readFileSync(`${root}/cmdline`).toString('utf8').split('\0').filter(Boolean)
      const uid = Number(fs.readFileSync(`${root}/status`, 'utf8').match(/^Uid:\s+(\d+)/m)?.[1])
      const fd = fs.readdirSync(`${root}/fd`).map(name => {
        try { return fs.readlinkSync(`${root}/fd/${name}`) } catch { return '<raced>' }
      })
      found.push({ pid: Number(entry), ppid: Number(tail[1]), startTicks: tail[19], cmdline,
        uid, pidNamespace: fs.readlinkSync(`${root}/ns/pid`), fd })
    } catch { /* A process may disappear between /proc reads. */ }
  }
  return found
}

let firstProbe
let firstSocket
let receiptNs
const server = net.createServer({ allowHalfOpen: true }, socket => {
  let bytes = Buffer.alloc(0)
  let recorded = false
  socket.on('data', chunk => {
    bytes = Buffer.concat([bytes, chunk])
    if (bytes.length > 8192) { log('unexpected-request-size', { bytes: bytes.length }); socket.destroy(); return }
    const boundary = bytes.indexOf('\r\n\r\n')
    if (boundary < 0 || recorded) return
    const head = bytes.subarray(0, boundary).toString('latin1')
    const length = Number(head.match(/(?:^|\r\n)Content-Length: (\d+)(?:\r\n|$)/i)?.[1])
    if (!Number.isSafeInteger(length) || length < 0 || bytes.length < boundary + 4 + length) return
    recorded = true
    const body = bytes.subarray(boundary + 4, boundary + 4 + length).toString('utf8')
    const peers = processes()
    const probes = peers.filter(p => p.cmdline.join('\0') === 'node\0/opt/omne/app/deploy/docker/health.mjs')
    receiptNs = process.hrtime.bigint()
    log('request', { head, body, expectedBody, complete: bytes.length === boundary + 4 + length,
      probes, descendants: peers.filter(p => probes.some(q => p.ppid === q.pid)),
      opsClients: peers.filter(p => p.cmdline.includes('/opt/omne/app/dist/cli.js') && p.cmdline.includes('ops')) })
    if (firstProbe === undefined && probes.length === 1 && body === expectedBody) {
      firstProbe = probes[0]
      firstSocket = socket
      log('first-probe', { probe: firstProbe })
      // A request-side FIN is only a write half-close. Keep our write side open.
      setTimeout(() => {
        log('late-write-attempt', { firstProbePresent: processes().some(p =>
          p.pid === firstProbe.pid && p.startTicks === firstProbe.startTicks),
          socketDestroyed: firstSocket.destroyed })
        firstSocket.write('HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n', error =>
          log('late-write-result', { code: error?.code ?? null, message: error?.message ?? null }))
      }, 3000)
    }
  })
  socket.on('end', () => log('peer-write-halfclose'))
  socket.on('close', hadError => log('peer-socket-close', { hadError }))
  socket.on('error', error => log('peer-socket-error', { code: error.code, message: error.message }))
})
server.listen(socketPath, () => {
  fs.chmodSync(socketPath, 0o600)
  log('server-ready', { pid: process.pid, uid: process.getuid(), pidNamespace: fs.readlinkSync('/proc/self/ns/pid') })
})
setInterval(() => {
  if (firstProbe === undefined) return
  const peers = processes()
  const current = peers.find(p => p.pid === firstProbe.pid && p.startTicks === firstProbe.startTicks)
  const health = peers.filter(p => p.cmdline.includes('/opt/omne/app/deploy/docker/health.mjs'))
  const opsClients = peers.filter(p => p.cmdline.includes('/opt/omne/app/dist/cli.js') && p.cmdline.includes('ops'))
  const descendants = peers.filter(p => p.ppid === firstProbe.pid)
  const elapsedMs = Number((process.hrtime.bigint() - receiptNs) / 1_000_000n)
  log('sample', { elapsedMs, firstPresent: current !== undefined,
    firstFdDirectoryPresent: fs.existsSync(`/proc/${firstProbe.pid}/fd`) && current !== undefined,
    health: health.map(p => ({ pid: p.pid, startTicks: p.startTicks, cmdline: p.cmdline })),
    opsClients: opsClients.map(p => ({ pid: p.pid, startTicks: p.startTicks, cmdline: p.cmdline })), descendants })
}, 100).unref()
