#!/usr/bin/env python3
"""Independent verdict from saved Engine inspect and PID1 /proc observations."""

import datetime
import json
import pathlib
import re
import sys

from inputs import need


def utc(value):
    return datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))


def check(run):
    evidence = json.loads((run / "evidence.json").read_text())
    need(
        evidence["business_verdict"] == "observed-awaiting-oracle",
        "observation incomplete",
    )
    need(evidence["cleanup_verdict"] == "pass", "QA cleanup incomplete")
    inspect_tag = evidence["final_inspect_tag"]
    logs_tag = evidence["final_logs_tag"]
    commands = {row["tag"]: row for row in evidence["commands"]}
    need(
        all(
            row["rc"] == 0 and not row["observationTimeout"]
            for row in commands.values()
        ),
        "Docker command failed",
    )
    inventory_bytes = (run / commands["image-full-inventory"]["stdout"]).read_bytes()
    need(
        inventory_bytes.endswith(b"\n") and inventory_bytes.count(b"\n") == 1,
        "image inventory output shape",
    )
    inventory = json.loads(inventory_bytes)
    need(
        inventory["status"] == "verified"
        and inventory["buildId"] == evidence["input"]["host_build_id"]
        and inventory["manifestSha256"] == evidence["input"]["host_manifest_sha256"]
        and inventory["files"] + inventory["links"]
        == evidence["input"]["host_file_count"]
        and inventory["node"] == "v24.21.0",
        "original image full app inventory",
    )
    final = json.loads((run / commands[inspect_tag]["stdout"]).read_text())[0]
    events = [
        json.loads(line)
        for line in (run / commands[logs_tag]["stdout"]).read_text().splitlines()
        if line
    ]
    need(
        final["Name"] == "/" + evidence["name"]
        and final["Image"] == evidence["input"]["image_id"],
        "wrong container",
    )
    need(
        final["Config"]["Labels"].get("ai.nemori.omne.health-qa")
        == evidence["label"].split("=", 1)[1],
        "wrong QA label",
    )
    need(
        final["Config"]["Healthcheck"]["Test"]
        == ["CMD", "node", "/opt/omne/app/deploy/docker/health.mjs"],
        "health command changed",
    )
    need(
        final["State"]["Running"] is True
        and final["State"]["Health"]["Status"] == "unhealthy",
        "QA server or actual Docker unhealthy state missing",
    )
    rows = final["State"]["Health"]["Log"]
    need(rows, "no actual Engine Health.Log")
    ready = [e for e in events if e["event"] == "server-ready"]
    request = [e for e in events if e["event"] == "request"]
    first = [e for e in events if e["event"] == "first-probe"]
    halfclose = [e for e in events if e["event"] == "peer-write-halfclose"]
    samples = [e for e in events if e["event"] == "sample"]
    attempts = [e for e in events if e["event"] == "late-write-attempt"]
    results = [
        e for e in events if e["event"] in ("late-write-result", "peer-socket-error")
    ]
    need(
        len(ready) == 1 and ready[0]["pid"] == 1 and ready[0]["uid"] == 10001,
        "Node PID1 identity",
    )
    need(
        len(request) >= 1 and len(first) == 1 and halfclose and attempts and results,
        "request/socket evidence",
    )
    req = request[0]
    need(
        req["complete"] is True
        and req["body"]
        == req["expectedBody"]
        == '{"opsVersion":"1","operation":"full-health","payload":{}}',
        "complete original full-health request",
    )
    need(
        req["head"].startswith("POST / HTTP/1.1\r\nContent-Length: ")
        and len(req["probes"]) == 1,
        "actual client request/one probe",
    )
    length = re.search(r"(?:^|\r\n)Content-Length: (\d+)(?:\r\n|$)", req["head"], re.I)
    need(
        length is not None and int(length[1]) == len(req["body"].encode()),
        "request Content-Length",
    )
    probe = first[0]["probe"]
    need(
        probe == req["probes"][0]
        and probe["cmdline"] == ["node", "/opt/omne/app/deploy/docker/health.mjs"],
        "actual health PID command",
    )
    need(
        probe["uid"] == 10001 and probe["pidNamespace"] == ready[0]["pidNamespace"],
        "probe UID/PID namespace",
    )
    need(
        any(fd.startswith("socket:[") for fd in probe["fd"]),
        "client socket FD not observed in flight",
    )
    need(
        req["descendants"] == []
        and req["opsClients"] == []
        and all(s["descendants"] == [] and s["opsClients"] == [] for s in samples),
        "probe descendant or orphan ops client survived",
    )
    elapsed = lambda event: int(event["monoNs"]) - int(req["monoNs"])
    need(any(elapsed(e) >= 0 for e in halfclose), "client write halfclose absent")
    need(
        any(s["firstPresent"] is True and elapsed(s) > 0 for s in samples),
        "no in-flight process after receipt",
    )
    gone = [
        s
        for s in samples
        if s["firstPresent"] is False and s["firstFdDirectoryPresent"] is False
    ]
    need(
        gone and min(elapsed(s) for s in gone) > 0,
        "old PID/startticks and FD directory did not disappear",
    )
    need(
        all(
            not any(
                p["pid"] == probe["pid"] and p["startTicks"] == probe["startTicks"]
                for p in s["health"]
            )
            for s in gone
        ),
        "old probe residue",
    )
    timeouts = []
    for row in rows:
        if row.get("ExitCode") != -1 or "timeout" not in row.get("Output", "").lower():
            continue
        start, end = utc(row["Start"]), utc(row["End"])
        if (
            start <= utc(req["wallUtc"]) < end
            and 1.5 <= (end - start).total_seconds() <= 3.5
        ):
            timeouts.append(row)
    need(timeouts, "no genuine Engine outer 2s timeout after in-flight request")
    need(
        abs((utc(gone[0]["wallUtc"]) - utc(timeouts[0]["End"])).total_seconds()) <= 0.7,
        "old PID disappearance not coupled to Engine timeout end",
    )
    attempt = attempts[0]
    need(
        elapsed(attempt) > elapsed(gone[0]) and attempt["firstProbePresent"] is False,
        "late peer write was not after old probe disappearance",
    )
    codes = [row.get("code") for row in results if elapsed(row) > elapsed(attempt)]
    disconnected = any(code in ("EPIPE", "ECONNRESET") for code in codes)
    # The recorded exact PID/startticks and its /proc/<pid>/fd disappearance is
    # sufficient when Node has already closed the server socket before write().
    need(
        disconnected or attempt["socketDestroyed"] is True,
        "no peer-disconnect observation",
    )
    return {
        "verdict": "PASS",
        "timeout": timeouts[0],
        "probe": {"pid": probe["pid"], "startTicks": probe["startTicks"]},
        "disconnect": "peer-error" if disconnected else "old-client-fd-gone",
        "request": req["body"],
    }


if __name__ == "__main__":
    try:
        print(json.dumps(check(pathlib.Path(sys.argv[1])), sort_keys=True))
    except Exception as error:
        print(
            json.dumps(
                {"verdict": "UNVERIFIED", "reason": f"{type(error).__name__}: {error}"},
                sort_keys=True,
            )
        )
        raise SystemExit(1)
