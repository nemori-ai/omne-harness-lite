#!/usr/bin/env python3
"""Narrow original-image normal helper/CLI journey on proven private DinD fixture."""

import argparse
import hashlib
import importlib.util
import json
import pathlib
import platform
import re
import secrets
import shutil
import subprocess
import sys

import inputs as source

HERE = pathlib.Path(__file__).resolve().parent
BASE_PATH = pathlib.Path(
    "/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-fixtures/tmp/docker-product-fixtures/r5-helper-prep/driver.py"
)
BASE_SHA = "a450179ed522b8ab2033f0aa368c5d4ad3fe43139353b9d14d24afb01915da26"
CROSS_PATH = pathlib.Path(
    "/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/tmp/next-iteration/docker-cross-os-amd64-rosetta-pass/driver.py"
)
CROSS_SHA = "5e2857935db344c88caba685e84ecf5fff255947e8ba059f10fd9e834677842a"
V0 = BASE_PATH.parent.parent / "v0c"
HELPER = source.TREE / "apps/tenancy-host/deploy/docker"


def load(path, name, expected):
    source.need(source.sha(path) == expected, name + " fixture SHA")
    spec = importlib.util.spec_from_file_location(name, path)
    source.need(spec is not None and spec.loader is not None, name + " import")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def prepared(args):
    data = source.checked(args.manifest, args.manifest_sha256, args.platform)
    source.need(
        source.sha(BASE_PATH) == BASE_SHA and source.sha(CROSS_PATH) == CROSS_SHA,
        "proven fixture source changed",
    )
    paths = {
        "helper": HELPER / "omne-center",
        "compose": HELPER / "compose.yaml",
        "maintenance_compose": HELPER / "compose.maintenance.yaml",
        "health": HELPER / "health.mjs",
        "service": HELPER / "omne-center-backup@.service",
        "timer": HELPER / "omne-center-backup@.timer",
        "image_tar": pathlib.Path(data["image_tar"]),
        "cli_tar": pathlib.Path(data["cli_tar"]),
        "compose_binary": V0 / "docker-compose-linux-aarch64",
        "docker_cli": V0 / "extracted-bin/docker",
        "v0_driver": BASE_PATH,
        "cross_driver": CROSS_PATH,
        "driver": HERE / "normal.py",
        "oracle": HERE / "v2/oracle.py",
        "inputs": HERE / "inputs.py",
        "inventory": HERE / "inventory.mjs",
    }
    hashes = {name: source.sha(path) for name, path in paths.items()}
    for name, manifest_name in (
        ("helper", "omne-center"),
        ("compose", "compose.yaml"),
        ("maintenance_compose", "compose.maintenance.yaml"),
        ("health", "health.mjs"),
        ("service", "omne-center-backup@.service"),
        ("timer", "omne-center-backup@.timer"),
    ):
        source.need(
            hashes[name] == data["deploy_shas"][manifest_name],
            name + " source/manifest mismatch",
        )
    source.need(
        hashes["image_tar"] == data["image_tar_sha256"]
        and hashes["cli_tar"] == data["cli_tar_sha256"],
        "artifact SHA",
    )
    source.need(
        hashes["compose_binary"]
        == "d26373b19e89160546d15407516cc59f453030d9bc5b43ba7faf16f7b4980137"
        and hashes["docker_cli"]
        == "544cf329807e30c9601652562a159b17179345146be0f8211bfe2ebd872eb880",
        "control tool SHA",
    )
    data.update(
        {
            "case": "normal",
            "paths": {key: str(value.resolve()) for key, value in paths.items()},
            "sha256": hashes,
            "build_id": data["host_build_id"],
            "cli_build_id": data["cli_build_id"],
            "uid": 10001,
            "gid": 10001,
            "observe_seconds": 600,
            "timer_observe_seconds": 30,
        }
    )
    return data


def run_normal(args, data):
    source.need(
        platform.system() == "Darwin",
        "normal fixture expects the reviewed Darwin Docker host",
    )
    base = load(BASE_PATH, "normal_base", BASE_SHA)
    cross = load(CROSS_PATH, "normal_cross", CROSS_SHA)
    base.HERE = HERE / "v2"
    base_args = argparse.Namespace(
        helper_dir=HELPER,
        image_tar=pathlib.Path(data["image_tar"]),
        image_id=data["image_id"],
        build_id=data["build_id"],
        uid=10001,
        gid=10001,
        observe_seconds=600,
        timer_observe_seconds=30,
        reviewed_gate=args.reviewed_gate,
    )
    run = base.Run(base_args, data)
    for name, path in (
        ("normal.py", HERE / "normal.py"),
        ("inputs.py", HERE / "inputs.py"),
        ("inventory.mjs", HERE / "inventory.mjs"),
        ("v0-driver.py", BASE_PATH),
        ("cross-driver.py", CROSS_PATH),
        ("manifest.json", pathlib.Path(data["manifest"])),
    ):
        target = run.frozen / name
        shutil.copyfile(path, target)
        source.need(source.sha(target) == source.sha(path), "frozen input changed")
    journey = cross.Journey(run, base, data)
    try:
        cross.setup(run, base)
        cross.import_image(run, base, args.platform)
        run.inner(
            "image-version",
            "run",
            "--rm",
            "--pull",
            "never",
            "--network",
            "none",
            "--name",
            run.prefix + "-version",
            "--label",
            run.label,
            run.image_id,
            "--version",
        )
        run.prepare_paths()
        run.outer(
            "copy-image-inventory",
            "cp",
            str(run.frozen / "inventory.mjs"),
            f"{run.control}:{base.STATE}/inventory.mjs",
        )
        run.inner(
            "image-full-inventory",
            "run",
            "--rm",
            "--pull",
            "never",
            "--network",
            "none",
            "--name",
            run.prefix + "-inventory",
            "--label",
            run.label,
            "-e",
            "EXPECTED_BUILD_ID=" + data["host_build_id"],
            "-e",
            "EXPECTED_MANIFEST_SHA256=" + data["host_manifest_sha256"],
            "-v",
            f"{base.STATE}/inventory.mjs:/qa/inventory.mjs:ro",
            "--entrypoint",
            "node",
            run.image_id,
            "/qa/inventory.mjs",
            timeout=90,
        )
        run.control_exec(
            "qa-credential-policy",
            "sh",
            "-c",
            'printf "%s\\n" "$1" >> "$2"',
            "sh",
            cross.QA_CREDENTIAL_POLICY,
            base.SETTINGS,
        )
        source.need(
            run.control_exec(
                "qa-policy-observed",
                "grep",
                "-Fx",
                cross.QA_CREDENTIAL_POLICY,
                base.SETTINGS,
            ).strip()
            == cross.QA_CREDENTIAL_POLICY.encode(),
            "QA policy not set",
        )
        cross.prepare_clients(run, journey)
        deployment = journey.deployment()
        run.helper("validate", "validate", *deployment)
        started = base.parse_json_line(
            run.helper("start", "start", *deployment, timeout=600), "start"
        )
        cid = started["containerId"]
        source.need(re.fullmatch(r"[0-9a-f]{64}", cid) is not None, "center ID")
        run.evidence["expected"]["first_center_container"] = cid
        run.save()
        run.inner("center-inspect-running", "inspect", cid)
        run.inner("center-proc-comm", "exec", cid, "cat", "/proc/1/comm")
        run.inner("center-proc-exe", "exec", cid, "readlink", "/proc/1/exe")
        run.inner("center-proc-cmdline", "exec", cid, "cat", "/proc/1/cmdline")
        run.inner("center-proc-uid", "exec", cid, "id", "-u")
        run.inner("center-node-version", "exec", cid, "node", "--version")
        journey.rosetta_probes(cid, "before")
        run.helper("full-health", "full-health", "--project", run.project)
        journey.cli(
            "cli-configure",
            "linux",
            "alice",
            "configure",
            endpoint=f"https://{run.dind_ip}:{cross.PORT}/",
            ca=cross.LINUX_QA_DIR + "/ca.pem",
        )
        journey.cli("cli-public-health", "linux", "alice", "health")
        login = "qa" + run.project
        credential = secrets.token_hex(18).encode()
        journey.cli(
            "cli-register",
            "linux",
            "alice",
            "register",
            {"loginIdentifier": login},
            credential,
        )
        journey.cli(
            "cli-login",
            "linux",
            "alice",
            "login",
            {"loginIdentifier": login},
            credential,
        )
        journey.cli("cli-current", "linux", "alice", "current", {}, refresh=True)
        journey.cli(
            "cli-create-team",
            "linux",
            "alice",
            "create",
            {"creationKey": "health-qa-" + run.project},
        )
        backup = base.parse_json_line(
            run.helper("backup", "backup", "--project", run.project, timeout=600),
            "backup",
        )
        source.need(backup.get("status") == "completed", "backup not complete")
        run.control_exec(
            "backup-file-stat",
            "stat",
            "-c",
            "%F:%u:%g:%a:%s",
            base.STATE + "/backups/" + backup["backup"]["fileName"],
        )
        run.helper("backup-status", "backup-status", "--project", run.project)
        run.helper("stop", "stop", "--project", run.project, timeout=600)
        run.inner("center-inspect-stopped", "inspect", cid)
        run.evidence["status"] = "observed-awaiting-oracle"
    except Exception as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
    finally:
        run.save()
        run.cleanup()
    result = subprocess.run(
        [sys.executable, "-B", str(run.frozen / "oracle.py"), str(run.run)],
        capture_output=True,
        text=True,
        check=False,
    )
    (run.run / "oracle.stdout").write_text(result.stdout)
    (run.run / "oracle.stderr").write_text(result.stderr)
    run.evidence["oracle_exit"] = result.returncode
    run.save()
    print(
        json.dumps(
            {
                "run": str(run.run),
                "oracle_exit": result.returncode,
                "cleanup_complete": run.evidence["cleanup_complete"],
            },
            sort_keys=True,
        )
    )
    return result.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--platform", choices=("arm64", "amd64"), required=True)
    parser.add_argument("--manifest", type=pathlib.Path, required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    data = prepared(args)
    digest = hashlib.sha256(source.canonical(data)).hexdigest()
    if args.print_inputs or not args.execute:
        print(json.dumps({"inputs": data, "inputs_sha256": digest}, sort_keys=True))
        return 0
    source.need(args.reviewed_gate is not None, "root gate required")
    gate = json.loads(args.reviewed_gate.read_text())
    source.need(
        gate
        == {
            "approved": True,
            "reviewer": "root",
            "inputs_sha256": digest,
            "driver_sha256": data["sha256"]["driver"],
            "oracle_sha256": data["sha256"]["oracle"],
        },
        "root gate mismatch",
    )
    return run_normal(args, data)


if __name__ == "__main__":
    raise SystemExit(main())
