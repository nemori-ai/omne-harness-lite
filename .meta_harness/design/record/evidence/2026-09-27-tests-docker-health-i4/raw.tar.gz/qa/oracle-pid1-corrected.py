#!/usr/bin/env python3
"""Original-image N verdict from saved command bytes and real Engine state."""

import hashlib
import json
import pathlib
import re
import sys

from inputs import need

HEALTH_KEYS = {
    "reachable",
    "centerId",
    "version",
    "startedAt",
    "storageReachable",
    "deploymentKeyPresent",
    "deploymentKeyComplete",
    "clockSane",
    "defectCount",
    "deploymentParameters",
}
PARAMETERS = {
    "unactivatedRetention",
    "invitationTtlDefault",
    "affiliationRequestTtlDefault",
    "copyNoticeTtlDefault",
    "sharingInvitationTtlDefault",
}


def check(run):
    evidence = json.loads((run / "evidence.json").read_text())
    need(
        evidence["status"] == "observed-awaiting-oracle"
        and evidence["cleanup_complete"] is True,
        "normal run or cleanup incomplete",
    )
    commands = {c["label"]: c for c in evidence["commands"]}
    need(len(commands) == len(evidence["commands"]), "duplicate command labels")

    def raw(label):
        need(label in commands, "missing command " + label)
        item = commands[label]
        need(
            item["returncode"] == 0 and item["observation_expired"] is False,
            label + " failed or timed out",
        )
        need(item["stdout"] == "raw/" + label + ".stdout", "raw path changed")
        return (run / item["stdout"]).read_bytes()

    def line(label):
        value = raw(label)
        need(
            value.endswith(b"\n") and value.count(b"\n") == 1,
            label + " must be one JSON+LF",
        )
        return json.loads(value)

    inputs = evidence["inputs"]
    expected = evidence["expected"]
    need(
        inputs["source_commit"] == "b88da2da9e7bb30bd23a6dc097631e987bca319b", "source"
    )
    inner = json.loads(raw("inner-image-inspect"))[0]
    outer = json.loads(raw("outer-product-image"))[0]
    need(
        inner["RootFS"]["Layers"]
        == outer["RootFS"]["Layers"]
        == inputs["rootfs_layers"],
        "actual image layers",
    )
    for image in (inner, outer):
        need(
            image["Os"] == "linux" and image["Architecture"] == inputs["platform"],
            "actual image arch",
        )
        labels = image["Config"]["Labels"]
        need(
            labels["ai.nemori.omne.host-build-id"] == inputs["host_build_id"]
            and labels["org.opencontainers.image.version"] == inputs["version"]
            and labels["ai.nemori.omne.distribution"] == "tenancy-host-docker/1",
            "image labels",
        )
        need(
            image["Config"]["Healthcheck"]["Test"]
            == ["CMD", "node", "/opt/omne/app/deploy/docker/health.mjs"],
            "health command",
        )
    need(
        outer["Id"] == inputs["image_id"] and inner["Id"] == expected["inner_image_id"],
        "image IDs",
    )
    need(
        raw("image-version")
        == f"tenancy-host {inputs['version']} {inputs['host_build_id']}\n".encode(),
        "actual imported image --version",
    )
    inventory = line("image-full-inventory")
    need(
        inventory
        == {
            "status": "verified",
            "buildId": inputs["host_build_id"],
            "files": inventory.get("files"),
            "links": inventory.get("links"),
            "manifestSha256": inputs["host_manifest_sha256"],
            "node": "v24.21.0",
        }
        and type(inventory["files"]) is int
        and type(inventory["links"]) is int
        and inventory["files"] + inventory["links"] == inputs["host_file_count"],
        "actual image whole app inventory",
    )
    started = line("start")
    cid = started["containerId"]
    need(
        cid == expected["first_center_container"]
        and started["state"] == "running"
        and started["health"] == "healthy"
        and started["buildId"] == inputs["host_build_id"]
        and started["imageId"] == inner["Id"],
        "helper start result",
    )
    running = json.loads(raw("center-inspect-running"))[0]
    need(
        running["Id"] == cid
        and running["Image"] == inner["Id"]
        and running["State"]["Running"] is True
        and running["State"]["Health"]["Status"] == "healthy",
        "actual running health",
    )
    need(
        any(row["ExitCode"] == 0 for row in running["State"]["Health"]["Log"]),
        "actual Engine healthy probe log absent",
    )
    need(
        running["Config"]["Entrypoint"] == ["node", "/opt/omne/app/dist/cli.js"]
        and running["Config"]["Cmd"] == ["serve"]
        and running["Config"]["User"] == "10001:10001",
        "actual production entrypoint",
    )
    need(
        running["Config"]["Healthcheck"]["Test"]
        == ["CMD", "node", "/opt/omne/app/deploy/docker/health.mjs"],
        "actual production health",
    )
    need(
        raw("center-proc-uid") == b"10001\n"
        and raw("center-node-version") == b"v24.21.0\n",
        "actual PID1 runtime",
    )
    observed_comm = raw("center-proc-comm").decode("utf8", "strict").strip()
    if inputs["platform"] == "arm64":
        need(
            raw("center-proc-exe") == b"/usr/local/bin/node\n"
            and raw("center-proc-cmdline")
            == b"node\0/opt/omne/app/dist/cli.js\0serve\0",
            "arm64 native Node PID1",
        )
    else:
        need(
            raw("center-proc-exe") == b"/run/rosetta/rosetta\n"
            and raw("center-proc-cmdline")
            == b"node\0--no-opt\0-r\0/proc/.reset\0/opt/omne/app/dist/cli.js\0serve\0",
            "named amd64 Rosetta adapter",
        )
        maps = raw("center-maps-before").decode()
        need(
            any(
                "x" in row.split()[1] and row.endswith("/usr/local/bin/node")
                for row in maps.splitlines()
            )
            and any(
                "x" in row.split()[1] and row.endswith("/run/rosetta/rosetta")
                for row in maps.splitlines()
            ),
            "Rosetta/Node executable mappings",
        )
        uid_rows = [
            row.split()
            for row in raw("center-status-before").splitlines()
            if row.startswith(b"Uid:")
        ]
        need(
            uid_rows == [[b"Uid:", b"10001", b"10001", b"10001", b"10001"]],
            "Rosetta UID",
        )
        reset = raw("center-reset-before")
        need(
            reset == b"const p=require('process');p.execArgv=p.execArgv.slice(3)\n"
            and hashlib.sha256(reset).hexdigest()
            == "86c6676bd07477697e8aed12348041dc1ef6bdeee70bdd4d346dd1ce2e27aacd",
            "Rosetta reset",
        )
        runtime = line("center-node-elf-before")
        need(
            runtime
            == {
                "arch": "x64",
                "platform": "linux",
                "execPath": "/usr/local/bin/node",
                "version": "v24.21.0",
                "uid": 10001,
                "nodeSha256": "7fde7b8afa198da66257f42ee2001d874c7355631e6d1579a5fb5ef1f246df4c",
                "elfMagic": "7f454c46",
                "elfMachine": 62,
            },
            "Rosetta Node runtime",
        )

    health = line("full-health")
    need(
        set(health) == HEALTH_KEYS
        and all(
            health[name] is True
            for name in (
                "reachable",
                "storageReachable",
                "deploymentKeyPresent",
                "deploymentKeyComplete",
                "clockSane",
            )
        )
        and health["defectCount"] == 0
        and re.fullmatch(r"[0-9a-f]{32}", health["centerId"]),
        "real full-health body",
    )
    need(
        health["version"] == inputs["version"]
        and set(health["deploymentParameters"]) == PARAMETERS
        and all(
            type(value) is int and value > 0
            for value in health["deploymentParameters"].values()
        ),
        "full-health version/parameters",
    )
    for label in (
        "cli-configure",
        "cli-public-health",
        "cli-register",
        "cli-login",
        "cli-current",
        "cli-create-team",
    ):
        report = line(label)
        need(
            report["format"] == "governance-client/1"
            and report["admission"]["status"] == "admitted"
            and report["remote"]["status"] == "success"
            and report["view"]["source"] != "copy",
            label + " live CLI",
        )
    configured = line("cli-configure")
    need(
        configured["remote"]["stage"] == "health"
        and configured["remote"]["sendAttempted"] is False
        and configured["remote"]["health"]["centerId"] == health["centerId"]
        and configured["local"]["status"] == "installed",
        "CLI configure actual health/install",
    )
    public = line("cli-public-health")["remote"]["health"]
    need(
        public["reachable"] is True and public["centerId"] == health["centerId"],
        "public CLI center identity",
    )
    need(
        line("cli-register")["remote"]["reply"]["reply"]["result"] == "registered",
        "real registration",
    )
    current = line("cli-current")["remote"]["reply"]["reply"]["result"]
    team = line("cli-create-team")["remote"]["reply"]["reply"]["result"]
    need(
        isinstance(current["account"], str)
        and current["account"]
        and isinstance(team, str)
        and team,
        "current identity/team not confirmed",
    )
    backup, status = line("backup"), line("backup-status")
    need(
        backup["status"] == "completed"
        and status["status"] == "observed"
        and status["health"] == "current",
        "backup result",
    )
    meta = backup["backup"]["metadata"]
    need(
        meta["centerId"] == health["centerId"]
        and meta["sourceBuildId"] == inputs["host_build_id"]
        and status["latest"]["fileName"] == backup["backup"]["fileName"]
        and status["latest"]["metadata"]["sha256"] == meta["sha256"],
        "backup actual identity",
    )
    file_stat = raw("backup-file-stat").decode().strip()
    need(
        re.fullmatch(r"regular file:10001:10001:600:[1-9][0-9]*", file_stat)
        is not None,
        "backup file missing or wrong owner/mode",
    )
    stopped = line("stop")
    final = json.loads(raw("center-inspect-stopped"))[0]
    need(
        stopped
        == {"state": "stopped", "containerId": cid, "exitCode": 0, "clean": True},
        "supported stop result",
    )
    need(
        final["Id"] == cid
        and final["State"]["Status"] == "exited"
        and final["State"]["ExitCode"] == 0
        and final["State"]["Running"] is False,
        "actual final container state",
    )
    return {
        "verdict": "PASS",
        "platform": inputs["platform"],
        "centerId": health["centerId"],
        "containerId": cid,
        "imageId": inner["Id"],
        "pid1CommObserved": observed_comm,
    }


if __name__ == "__main__":
    try:
        print(json.dumps(check(pathlib.Path(sys.argv[1])), sort_keys=True))
    except Exception as error:
        print(
            json.dumps(
                {"verdict": "UNVERIFIED", "reason": f"{type(error).__name__}: {error}"},
                sort_keys=True,
            )
        )
        raise SystemExit(1)
