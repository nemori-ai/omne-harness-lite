"""Read-only I4 source and full archive identity checks for final-health QA."""

import hashlib
import json
import pathlib
import tarfile

HERE = pathlib.Path(__file__).resolve().parent
TREE = HERE.parents[1]
SOURCE_COMMIT = "b88da2da9e7bb30bd23a6dc097631e987bca319b"
HEX64 = set("0123456789abcdef")


def need(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with pathlib.Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def read_archive(archive, detail):
    need(sha(archive) == detail["sha256"], "archive SHA: " + str(archive))
    need(
        pathlib.Path(archive).stat().st_size == detail["sizeBytes"], "archive byte size"
    )
    expected_info = pathlib.Path(detail["fullFileManifest"])
    need(sha(expected_info) == detail["fullFileManifestSha256"], "build-info SHA")
    info = json.loads(expected_info.read_text())
    need(
        info["buildId"] == detail["buildId"] and info["format"] == detail["format"],
        "BUILD_ID/format",
    )
    need(
        info["version"] == detail["version"] and info["node"] == detail["node"],
        "version/Node",
    )
    need(len(info["files"]) == detail["fileCount"], "full inventory count")
    actual = {}
    with tarfile.open(archive, "r:gz") as stream:
        members = {m.name: m for m in stream.getmembers() if m.isfile() or m.issym()}
        need(
            "app/BUILD_ID" in members and "app/build-info.json" in members,
            "archive metadata",
        )
        build = stream.extractfile(members["app/BUILD_ID"])
        embedded = stream.extractfile(members["app/build-info.json"])
        need(
            build is not None and build.read().decode().strip() == detail["buildId"],
            "embedded BUILD_ID",
        )
        need(
            embedded is not None
            and hashlib.sha256(embedded.read()).hexdigest()
            == detail["fullFileManifestSha256"],
            "embedded inventory",
        )
        for name, member in members.items():
            if name in ("app/BUILD_ID", "app/build-info.json"):
                continue
            need(name.startswith("app/"), "archive member outside app")
            key = name.removeprefix("app/")
            if member.isfile():
                opened = stream.extractfile(member)
                need(opened is not None, "file unreadable: " + key)
                digest = hashlib.sha256()
                for chunk in iter(lambda: opened.read(1024 * 1024), b""):
                    digest.update(chunk)
                actual[key] = {
                    "path": key,
                    "kind": "file",
                    "sha256": digest.hexdigest(),
                }
            else:
                actual[key] = {"path": key, "kind": "link", "target": member.linkname}
    declared = {row["path"]: row for row in info["files"]}
    need(
        len(declared) == len(info["files"]) and actual == declared,
        "archive full inventory mismatch",
    )
    return info


def read_image_config(archive):
    with tarfile.open(archive, "r:") as stream:
        manifest_file = stream.extractfile("manifest.json")
        need(manifest_file is not None, "Docker save manifest absent")
        rows = json.load(manifest_file)
        need(isinstance(rows, list) and len(rows) == 1, "Docker save manifest count")
        config_file = stream.extractfile(rows[0]["Config"])
        need(config_file is not None, "Docker save config absent")
        config_bytes = config_file.read()
        config = json.loads(config_bytes)
        return config, "sha256:" + hashlib.sha256(config_bytes).hexdigest()


def checked(manifest_path, manifest_sha, platform):
    manifest_path = pathlib.Path(manifest_path).resolve(strict=True)
    need(
        len(manifest_sha) == 64 and set(manifest_sha) <= HEX64,
        "explicit manifest SHA required",
    )
    need(sha(manifest_path) == manifest_sha, "I4 manifest SHA mismatch")
    manifest = json.loads(manifest_path.read_text())
    need(manifest["source"]["commit"] == SOURCE_COMMIT, "I4 source commit")
    need(manifest["format"] == "omne-docker-i4-artifacts/1", "manifest format")
    need(platform in ("arm64", "amd64"), "platform")
    host = read_archive(
        manifest["archives"]["host"]["path"], manifest["archives"]["host"]
    )
    cli = read_archive(manifest["archives"]["cli"]["path"], manifest["archives"]["cli"])
    need(host["node"] == cli["node"] == "24.21.0", "Node version")
    image = manifest["images"][platform]
    need(image["platform"] == "linux/" + platform, "image platform")
    need(image["buildId"] == host["buildId"], "image host BUILD_ID")
    need(sha(image["archive"]) == image["archiveSha256"], "image archive SHA")
    need(
        pathlib.Path(image["archive"]).stat().st_size == image["archiveSizeBytes"],
        "image archive size",
    )
    image_config, saved_id = read_image_config(image["archive"])
    need(saved_id == image["imageId"], "Docker save config/image ID")
    need(
        image_config["architecture"] == platform and image_config["os"] == "linux",
        "saved image platform",
    )
    need(
        sha(image["imageInspection"]) == image["imageInspectionSha256"],
        "producer image inspect SHA",
    )
    files = {}
    for name, detail in manifest["deployFiles"].items():
        source = TREE / detail["source"]
        need(sha(source) == detail["sourceSha256"], "deploy source SHA: " + name)
        packaged = manifest_path.parent / detail["packaged"]
        need(
            sha(packaged) == detail["packagedSha256"] == detail["sourceSha256"],
            "deploy packaged SHA: " + name,
        )
        files[name] = detail["sourceSha256"]
    return {
        "source_commit": SOURCE_COMMIT,
        "manifest": str(manifest_path),
        "manifest_sha256": manifest_sha,
        "platform": platform,
        "host_build_id": host["buildId"],
        "host_manifest_sha256": manifest["archives"]["host"]["fullFileManifestSha256"],
        "host_file_count": manifest["archives"]["host"]["fileCount"],
        "cli_build_id": cli["buildId"],
        "version": host["version"],
        "image_id": image["imageId"],
        "image_tar": image["archive"],
        "image_tar_sha256": image["archiveSha256"],
        "image_inspection": image["imageInspection"],
        "image_inspection_sha256": image["imageInspectionSha256"],
        "rootfs_layers": image_config["rootfs"]["diff_ids"],
        "host_tar": manifest["archives"]["host"]["path"],
        "host_tar_sha256": manifest["archives"]["host"]["sha256"],
        "cli_tar": manifest["archives"]["cli"]["path"],
        "cli_tar_sha256": manifest["archives"]["cli"]["sha256"],
        "deploy_shas": files,
    }
