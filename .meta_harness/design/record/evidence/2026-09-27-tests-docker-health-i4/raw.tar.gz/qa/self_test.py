#!/usr/bin/env python3
"""Small offline false-success checks for the cancellation oracle."""

import copy
import datetime
import json
import pathlib
import tempfile

import cancel_oracle

HERE = pathlib.Path(__file__).resolve().parent
BASE = datetime.datetime(2026, 9, 27, tzinfo=datetime.timezone.utc)


def stamp(seconds):
    return (
        (BASE + datetime.timedelta(seconds=seconds)).isoformat().replace("+00:00", "Z")
    )


PROBE = {
    "pid": 22,
    "ppid": 1,
    "startTicks": "12345",
    "cmdline": ["node", "/opt/omne/app/deploy/docker/health.mjs"],
    "uid": 10001,
    "pidNamespace": "pid:[7]",
    "fd": ["socket:[55]"],
}


def fixture():
    events = [
        {
            "event": "server-ready",
            "pid": 1,
            "uid": 10001,
            "pidNamespace": "pid:[7]",
            "monoNs": "100000000",
            "wallUtc": stamp(0),
        },
        {
            "event": "request",
            "head": "POST / HTTP/1.1\r\nContent-Length: 57",
            "body": '{"opsVersion":"1","operation":"full-health","payload":{}}',
            "expectedBody": '{"opsVersion":"1","operation":"full-health","payload":{}}',
            "complete": True,
            "probes": [PROBE],
            "descendants": [],
            "opsClients": [],
            "monoNs": "1200000000",
            "wallUtc": stamp(1.2),
        },
        {
            "event": "first-probe",
            "probe": PROBE,
            "monoNs": "1200000100",
            "wallUtc": stamp(1.2),
        },
        {
            "event": "peer-write-halfclose",
            "monoNs": "1300000000",
            "wallUtc": stamp(1.3),
        },
        {
            "event": "sample",
            "firstPresent": True,
            "firstFdDirectoryPresent": True,
            "health": [{"pid": 22, "startTicks": "12345"}],
            "descendants": [],
            "opsClients": [],
            "monoNs": "1500000000",
            "wallUtc": stamp(1.5),
        },
        {
            "event": "sample",
            "firstPresent": False,
            "firstFdDirectoryPresent": False,
            "health": [],
            "descendants": [],
            "opsClients": [],
            "monoNs": "3200000000",
            "wallUtc": stamp(3.2),
        },
        {
            "event": "late-write-attempt",
            "firstProbePresent": False,
            "socketDestroyed": False,
            "monoNs": "4200000000",
            "wallUtc": stamp(4.2),
        },
        {
            "event": "late-write-result",
            "code": "EPIPE",
            "monoNs": "4200000100",
            "wallUtc": stamp(4.2),
        },
    ]
    image = {
        "Name": "/omne-health-qa-test",
        "Image": "sha256:" + "a" * 64,
        "Config": {
            "Labels": {"ai.nemori.omne.health-qa": "test"},
            "Healthcheck": {
                "Test": ["CMD", "node", "/opt/omne/app/deploy/docker/health.mjs"]
            },
        },
        "State": {
            "Running": True,
            "Health": {
                "Status": "unhealthy",
                "Log": [
                    {
                        "ExitCode": -1,
                        "Output": "Health check exceeded timeout (2s)",
                        "Start": stamp(1),
                        "End": stamp(3),
                    }
                ],
            },
        },
    }
    evidence = {
        "business_verdict": "observed-awaiting-oracle",
        "cleanup_verdict": "pass",
        "name": "omne-health-qa-test",
        "label": "ai.nemori.omne.health-qa=test",
        "input": {
            "image_id": "sha256:" + "a" * 64,
            "host_build_id": "b" * 64,
            "host_manifest_sha256": "c" * 64,
            "host_file_count": 2,
        },
        "final_inspect_tag": "inspect-final",
        "final_logs_tag": "logs-final",
        "commands": [
            {
                "tag": tag,
                "rc": 0,
                "observationTimeout": False,
                "stdout": "raw/" + tag + ".stdout",
            }
            for tag in ("inspect-final", "logs-final", "image-full-inventory")
        ],
    }
    return events, image, evidence


def check(events, image, evidence):
    with tempfile.TemporaryDirectory(prefix="offline-oracle-", dir=HERE) as directory:
        path = pathlib.Path(directory)
        (path / "raw").mkdir()
        (path / "evidence.json").write_text(json.dumps(evidence))
        (path / "raw/inspect-final.stdout").write_text(json.dumps([image]))
        (path / "raw/logs-final.stdout").write_text(
            "".join(json.dumps(event) + "\n" for event in events)
        )
        (path / "raw/image-full-inventory.stdout").write_text(
            json.dumps(
                {
                    "status": "verified",
                    "buildId": "b" * 64,
                    "manifestSha256": "c" * 64,
                    "files": 1,
                    "links": 1,
                    "node": "v24.21.0",
                }
            )
            + "\n"
        )
        return cancel_oracle.check(path)


if __name__ == "__main__":
    events, image, evidence = fixture()
    assert check(events, image, evidence)["verdict"] == "PASS"
    changes = {
        "missing-engine-timeout": lambda e, i: i["State"]["Health"].update(Log=[]),
        "request-not-in-flight": lambda e, i: e.__setitem__(1, {**e[1], "probes": []}),
        "old-probe-residue": lambda e, i: e[5].update(
            firstPresent=True, firstFdDirectoryPresent=True
        ),
        "halfclose-only": lambda e, i: e[7].update(code=None),
        "client-fd-unobserved": lambda e, i: e[1]["probes"][0].update(fd=[]),
    }
    rejected = []
    for name, change in changes.items():
        altered_events, altered_image = copy.deepcopy(events), copy.deepcopy(image)
        change(altered_events, altered_image)
        try:
            check(altered_events, altered_image, evidence)
        except (AssertionError, KeyError, RuntimeError, ValueError):
            rejected.append(name)
    assert len(rejected) == len(changes), "an invalid observation passed"
    print(
        json.dumps(
            {"synthetic_positive": "PASS", "false_successes_rejected": rejected},
            sort_keys=True,
        )
    )
