import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const output = import.meta.dirname
const result = {}
for (const name of ['host', 'cli']) {
  const files = JSON.parse(readFileSync(join(output, `${name}-build-info.json`), 'utf8')).files
  const paths = files.map(entry => entry.path)
  const privateFiles = paths.filter(path =>
    /(^|\/)(?:\.env(?:\.[^/]*)?|[^/]+\.(?:pem|key|sqlite|sqlite3|db))$/i.test(path),
  )
  const runtimeState = paths.filter(path => /^(?:state|tmp|secrets?)(?:\/|$)/i.test(path))
  const appTests = paths.filter(path => /^(?:tests?|__tests__|fixtures)(?:\/|$)/i.test(path))
  const runners = paths.filter(path => /(^|\/)(?:vitest|jest|mocha|tap)(\/|$)/i.test(path))
  const dependencyTestSources = paths.filter(
    path => path.startsWith('node_modules/') && /(^|\/)(?:tests?|__tests__|fixtures)(\/|$)/i.test(path),
  )
  result[name] = {
    fileCount: files.length,
    privateFiles,
    runtimeState,
    appTests,
    runners,
    dependencyTestSourcesCount: dependencyTestSources.length,
    dependencyTestSourcePackages: [
      ...new Set(dependencyTestSources.map(path => path.split('/node_modules/').at(-1)?.split('/')[0])),
    ].sort(),
  }
}
writeFileSync(join(output, 'closure-summary.json'), `${JSON.stringify(result, null, 2)}\n`)
process.stdout.write(`${JSON.stringify(result)}\n`)
