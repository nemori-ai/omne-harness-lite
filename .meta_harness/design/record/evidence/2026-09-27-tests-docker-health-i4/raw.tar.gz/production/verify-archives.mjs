import { createHash } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { inventory } from '../../../tools/artifact-builder/dist/index.js'

for (const [name, format] of [
  ['host', 'omne-tenancy-host-build/1'],
  ['cli', 'omne-cli-build/1'],
]) {
  const app = join(import.meta.dirname, `${name}-unpacked/app`)
  const info = JSON.parse(await readFile(join(app, 'build-info.json'), 'utf8'))
  const marker = await readFile(join(app, 'BUILD_ID'), 'utf8')
  const files = (await inventory(app)).filter(
    entry => entry.path !== 'BUILD_ID' && entry.path !== 'build-info.json',
  )
  const calculated = createHash('sha256').update(JSON.stringify(files)).digest('hex')
  if (
    info.format !== format || info.node !== '24.21.0' || info.pnpm !== '10.28.1' ||
    marker !== `${info.buildId}\n` || calculated !== info.buildId ||
    JSON.stringify(files) !== JSON.stringify(info.files)
  ) throw new Error(`${name}-manifest-mismatch`)
  process.stdout.write(JSON.stringify({ name, format: info.format, version: info.version, node: info.node, pnpm: info.pnpm, buildId: info.buildId, fileCount: files.length }) + '\n')
}
