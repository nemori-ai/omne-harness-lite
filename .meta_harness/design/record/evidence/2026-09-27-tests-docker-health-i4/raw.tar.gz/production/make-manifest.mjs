import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { createReadStream, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs'
import { join, relative, resolve } from 'node:path'
import { execFileSync } from 'node:child_process'

const output = import.meta.dirname
const root = resolve(output, '../../..')
const expectedCommit = 'b88da2da9e7bb30bd23a6dc097631e987bca319b'
const oldManifest = '/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery/tmp/docker-delivery/i3-f8f286c9/manifest-delivery.json'
const baseDigest = 'sha256:64af3819f9275802414d7cdc38c27e9d82bd564dec4d4da87d008255d36c63b4'

async function sha(path) {
  const hash = createHash('sha256')
  for await (const chunk of createReadStream(path)) hash.update(chunk)
  return hash.digest('hex')
}
function read(name) {
  return readFileSync(join(output, name), 'utf8')
}
function json(name) {
  return JSON.parse(read(name))
}
function git(...args) {
  return execFileSync('git', args, { cwd: root, encoding: 'utf8' }).trim()
}
function cleanOutput(name) {
  assert.equal(read(`${name}.exit`).trim(), '0', name)
  assert.equal(read(`${name}.stderr.log`), '', `${name} stderr`)
  return read(`${name}.stdout.log`)
}

assert.equal(git('rev-parse', 'HEAD'), expectedCommit)
assert.equal(git('status', '--porcelain'), '')
assert.equal(read('node-version.stdout.log'), 'v24.21.0\n')
assert.equal(read('pnpm-version.stdout.log'), '10.28.1\n')
assert.equal(read('docker-version.stdout.log'), '29.1.3 29.1.3 linux/arm64\n')
assert.equal(read('compose-version.stdout.log'), '2.40.3-desktop.1\n')
assert.equal(read('archive-verify.exit').trim(), '0')
assert.equal(read('inventory-correspondence.exit').trim(), '0')
assert.equal(read('closure-scan.exit').trim(), '0')
assert.equal(readdirSync(output).filter(name => name.startsWith('.omne-')).length, 0)

const hostResult = json('host-package.stdout.log')
const cliResult = json('cli-package.stdout.log')
const hostInfo = json('host-build-info.json')
const cliInfo = json('cli-build-info.json')
const old = JSON.parse(readFileSync(oldManifest, 'utf8'))
assert.equal(await sha(oldManifest), await sha(join(output, 'comparison-i3/manifest-delivery.json')))
assert.equal(await sha(join(resolve(oldManifest, '..'), 'host-build-info.json')), await sha(join(output, 'comparison-i3/host-build-info.json')))
assert.equal(await sha(join(resolve(oldManifest, '..'), 'cli-build-info.json')), await sha(join(output, 'comparison-i3/cli-build-info.json')))
const closure = json('closure-summary.json')
const normalizedDiff = json('inventory-normalized-diff.json')
const correspondence = json('inventory-path-correspondence.json')
for (const name of ['host', 'cli']) {
  assert.deepEqual(closure[name].privateFiles, [])
  assert.deepEqual(closure[name].runtimeState, [])
  assert.deepEqual(closure[name].appTests, [])
  assert.deepEqual(closure[name].runners, [])
  assert.equal(normalizedDiff[name].added.length, 0)
  assert.equal(normalizedDiff[name].removed.length, 0)
  assert.equal(correspondence[name].changedLinks, 0)
  assert.equal(correspondence[name].changedRuntimeJavaScript, 0)
}
assert.deepEqual(
  normalizedDiff.host.changed.filter(path => !path.startsWith('node_modules/')),
  ['deploy/docker/README.md', 'deploy/docker/health.mjs', 'package.json', 'pnpm-lock.yaml'],
)
assert.deepEqual(
  normalizedDiff.cli.changed.filter(path => !path.startsWith('node_modules/')),
  ['package.json', 'pnpm-lock.yaml'],
)

async function archive(name, result, info) {
  const path = join(output, `${name}.tar.gz`)
  assert.equal(result.path, path)
  assert.equal(result.sha256, await sha(path))
  assert.equal(result.buildId, info.buildId)
  assert.equal(readFileSync(join(output, `${name}-unpacked/app/BUILD_ID`), 'utf8'), `${info.buildId}\n`)
  assert.equal(await sha(join(output, `${name}-unpacked/app/build-info.json`)), await sha(join(output, `${name}-build-info.json`)))
  assert.equal(info.node, '24.21.0')
  assert.equal(info.pnpm, '10.28.1')
  return {
    path,
    sha256: result.sha256,
    sizeBytes: statSync(path).size,
    format: info.format,
    version: info.version,
    node: info.node,
    pnpm: info.pnpm,
    buildId: info.buildId,
    fileCount: info.files.length,
    fullFileManifest: join(output, `${name}-build-info.json`),
    fullFileManifestSha256: await sha(join(output, `${name}-build-info.json`)),
  }
}

async function image(arch) {
  const built = json(`${arch}-build.stdout.log`)
  const inspected = json(`${arch}-image-inspect.json`)
  const path = join(output, `center-${arch}.tar`)
  assert.equal(built.path, path)
  assert.equal(built.sha256, await sha(path))
  assert.equal(built.platform, `linux/${arch}`)
  assert.equal(built.buildId, hostInfo.buildId)
  assert.equal(built.baseDigest, baseDigest)
  assert.equal(inspected.Os, 'linux')
  assert.equal(inspected.Architecture, arch)
  assert.equal(inspected.User, '10001:10001')
  assert.equal(inspected.Labels['org.opencontainers.image.version'], hostInfo.version)
  assert.equal(inspected.Labels['ai.nemori.omne.host-build-id'], hostInfo.buildId)
  assert.equal(inspected.Labels['ai.nemori.omne.distribution'], 'tenancy-host-docker/1')
  assert.match(inspected.Id, /^sha256:[0-9a-f]{64}$/)
  assert.equal(cleanOutput(`${arch}-run-version`), `tenancy-host ${hostInfo.version} ${hostInfo.buildId}\n`)
  assert.equal(cleanOutput(`${arch}-run-node`), 'v24.21.0\n')
  assert.equal(cleanOutput(`${arch}-run-uid`), '10001\n')
  assert.equal(cleanOutput(`${arch}-run-gid`), '10001\n')
  assert.equal(cleanOutput(`${arch}-residual-containers`), '')
  const loadOutput = cleanOutput(`${arch}-load`).trim()
  assert.match(loadOutput, /^Loaded image: omne-tenancy-i1:[0-9a-f-]+$/)
  return {
    archive: path,
    archiveSha256: built.sha256,
    archiveSizeBytes: statSync(path).size,
    producerImageId: built.imageId,
    imageId: inspected.Id,
    producerAndLocalIdEqual: built.imageId === inspected.Id,
    platform: built.platform,
    buildId: built.buildId,
    baseDigest: built.baseDigest,
    labels: inspected.Labels,
    repoDigests: inspected.RepoDigests,
    imageInspection: join(output, `${arch}-image-inspect.json`),
    imageInspectionSha256: await sha(join(output, `${arch}-image-inspect.json`)),
    observedVersion: read(`${arch}-run-version.stdout.log`).trim(),
    observedNode: read(`${arch}-run-node.stdout.log`).trim(),
    observedUid: Number(read(`${arch}-run-uid.stdout.log`).trim()),
    observedGid: Number(read(`${arch}-run-gid.stdout.log`).trim()),
    loadOutput,
    execution: arch === 'arm64'
      ? 'Docker Desktop Linux/aarch64 VM on Darwin arm64'
      : 'Docker Desktop linux/amd64 emulation on Darwin arm64; not native amd64',
  }
}

const deploy = {}
const sourceDeploy = join(root, 'apps/tenancy-host/deploy/docker')
for (const name of readdirSync(sourceDeploy).sort()) {
  const source = join(sourceDeploy, name)
  if (!statSync(source).isFile()) continue
  const packaged = join(output, 'host-unpacked/app/deploy/docker', name)
  const sourceSha256 = await sha(source)
  const packagedSha256 = await sha(packaged)
  assert.equal(sourceSha256, packagedSha256, name)
  deploy[name] = {
    source: relative(root, source),
    sourceSha256,
    packaged: relative(output, packaged),
    packagedSha256,
  }
}
for (const name of ['Dockerfile', 'compose.yaml', 'compose.maintenance.yaml', 'omne-center', 'omne-center-backup@.service', 'omne-center-backup@.timer']) {
  assert.equal(deploy[name].sourceSha256, old.deployFiles[name].sourceSha256, name)
}

const sourceInputs = [
  'pnpm-lock.yaml', 'package.json',
  'scripts/package-tenancy-host.sh', 'scripts/package-cli.sh', 'scripts/build-tenancy-image.sh',
  'apps/tenancy-host/tools/package.ts', 'apps/cli/tools/package.ts',
  'apps/tenancy-host/tools/docker-image.ts', 'tools/artifact-builder/src/index.ts',
  'apps/tenancy-host/deploy/docker/health.mjs', 'apps/tenancy-host/deploy/docker/README.md',
  '.meta_harness/design/realization/apps/tenancy-host/docker.md',
  '.meta_harness/design/record/decisions/governance-docker-stop-adoption/decision.md',
  '.meta_harness/design/record/decisions/governance-docker-health-binding/decision.md',
  '.meta_harness/design/product/PF-017-governance-center-as-deployable-application/projection/v8/projection.md',
  '.meta_harness/design/product/PF-017-governance-center-as-deployable-application/projection/v8/provenance.json',
]
const inputFilesSha256 = {}
for (const name of sourceInputs) inputFilesSha256[name] = await sha(join(root, name))
assert.equal(inputFilesSha256['.meta_harness/design/realization/apps/tenancy-host/docker.md'], '7c62869388afd0292161fb42f1d746acea2e8567c9d2f761a133c4029e7d99d2')

const evidenceNames = [
  'verify-archives.mjs', 'compare-inventories.mjs', 'inventory-correspondence.mjs',
  'scan-closure.mjs', 'capture.sh', 'make-ledger.mjs', 'make-manifest.mjs',
  'inventory-diff.json', 'inventory-normalized-diff.json',
  'inventory-path-correspondence.json', 'inventory-byte-diff.raw.txt',
  'closure-summary.json', 'commands.md',
  'comparison-i3/manifest-delivery.json',
  'comparison-i3/host-build-info.json',
  'comparison-i3/cli-build-info.json',
]
const evidenceFilesSha256 = {}
for (const name of evidenceNames) evidenceFilesSha256[name] = await sha(join(output, name))
const rawLogs = {}
for (const name of readdirSync(output).filter(name => name.endsWith('.log')).sort()) {
  const path = join(output, name)
  rawLogs[name] = { sha256: await sha(path), sizeBytes: statSync(path).size }
}

assert.equal(cleanOutput('host-version'), `tenancy-host ${hostInfo.version} ${hostInfo.buildId}\n`)
assert.equal(cleanOutput('cli-version'), `omne ${cliInfo.version} ${cliInfo.buildId}\n`)
assert.match(cleanOutput('cli-help'), /^Usage: omne /)

const manifest = {
  format: 'omne-docker-i4-artifacts/1',
  source: {
    commit: expectedCommit,
    branch: git('branch', '--show-current'),
    clean: true,
    host: 'Darwin arm64',
    dockerServer: 'Linux/aarch64 Docker Desktop 29.1.3',
    dockerClient: '29.1.3',
    compose: '2.40.3-desktop.1',
    node: '24.21.0',
    pnpm: '10.28.1',
    inputFilesSha256,
  },
  adopted: {
    decision: 'D-072',
    projection: 'PF017/v8',
    dockerNodeSha256: inputFilesSha256['.meta_harness/design/realization/apps/tenancy-host/docker.md'],
  },
  archives: {
    host: await archive('host', hostResult, hostInfo),
    cli: await archive('cli', cliResult, cliInfo),
  },
  images: {
    arm64: await image('arm64'),
    amd64: await image('amd64'),
  },
  deployFiles: deploy,
  sourceAppDiff: {
    previousI3Manifest: oldManifest,
    previousI3ManifestSha256: await sha(oldManifest),
    previousI3ManifestCopy: join(output, 'comparison-i3/manifest-delivery.json'),
    previousI3HostInventoryCopy: join(output, 'comparison-i3/host-build-info.json'),
    previousI3CliInventoryCopy: join(output, 'comparison-i3/cli-build-info.json'),
    rawInventoryDiff: join(output, 'inventory-diff.json'),
    normalizedInventoryDiff: join(output, 'inventory-normalized-diff.json'),
    fullPathCorrespondence: join(output, 'inventory-path-correspondence.json'),
    rawChangedByteDiff: join(output, 'inventory-byte-diff.raw.txt'),
    normalizationRule: 'Only compare logical paths after replacing pnpm virtual-store @omne-harness-lite+PACKAGE@file+worktree-specific segment with @omne-harness-lite+PACKAGE@file+local; actual app inventory and BUILD_ID remain unnormalized.',
    hostChangedLogicalPaths: normalizedDiff.host.changed,
    cliChangedLogicalPaths: normalizedDiff.cli.changed,
    logicalLinksChanged: 0,
    runtimeJavaScriptChanged: 0,
    generatedMetadataFacts: [
      'package.json and pnpm-lock.yaml contain the new spoke file:/// paths',
      'pnpm virtual-store directory names and symlink targets encode the new spoke path; full old/new correspondence is retained',
      'node_modules/.modules.yaml changes workspace file:/// paths and prunedAt',
      'node_modules/.pnpm-workspace-state-v1.json changes lastValidatedTimestamp',
      'generated .bin scripts change NODE_PATH to this run unique temporary staging path; command targets remain the same',
      'node_modules/.pnpm/lock.yaml contains the new spoke file:/// paths',
    ],
  },
  closure,
  commandLedger: { path: join(output, 'commands.md'), sha256: evidenceFilesSha256['commands.md'] },
  evidenceFilesSha256,
  rawLogs,
  checks: {
    producerOrder: 'official host archive, CLI archive, arm64 image, amd64 image; all exit 0',
    packageBuild: 'official packagers rebuilt their respective app dist in this spoke',
    archiveInventory: 'both full file lists and BUILD_ID values independently recomputed; exit 0',
    loadedImageRuns: 'both saved tars loaded; no-network --pull never --version/Node/uid/gid all exit 0',
    residualTestContainers: 'none by exact loaded image ID',
    priorI3Comparison: 'complete raw entries, normalized logical path correspondence and changed-byte diffs retained; no logical link or runtime JS change',
  },
  resources: {
    temporaryPackagingAndImageStaging: 'none left in output directory',
    testContainers: 'docker run --rm; no residual container for either loaded image ID',
    localImages: 'two unique loaded omne-tenancy-i1 tags retained as local deliverables',
    paidModelApiCalls: 0,
    registryPushes: 0,
    dockerRegistryPulls: 'not independently observed; official build consumed fixed base digest',
  },
  notVerified: [
    'No root omne-center helper or real governance operation was started in I4 production',
    'No new-image full-health probe or short outer Docker deadline fault test; independent QA owns those checks',
    'No Linux amd64 native CPU run; amd64 checks used Docker Desktop emulation',
    'No final long-IO, close-error, second-owner, timer, daemon restart or full TLS governance QA',
    'No bare-metal power-loss or independent disaster-recovery guarantee',
    'Root and independent QA/Fable have not accepted these new artifacts',
  ],
}

const target = join(output, 'manifest-delivery.json')
writeFileSync(target, `${JSON.stringify(manifest, null, 2)}\n`, { flag: 'wx' })
const checksum = await sha(target)
writeFileSync(join(output, 'manifest-delivery.sha256'), `${checksum}  manifest-delivery.json\n`, { flag: 'wx' })
process.stdout.write(`manifest=${target}\nmanifestSha256=${checksum}\nhostBuildId=${hostInfo.buildId}\ncliBuildId=${cliInfo.buildId}\n`)
