import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'

const oldDirectory = resolve(process.argv[2])
const output = import.meta.dirname

function logical(value) {
  return value.replace(/(@omne-harness-lite\+[^/@]+)@file\+[^/]+/g, '$1@file+local')
}

function inventory(name, directory) {
  const manifest = JSON.parse(readFileSync(join(directory, `${name}-build-info.json`), 'utf8'))
  const entries = new Map()
  for (const entry of manifest.files) {
    const key = logical(entry.path)
    if (entries.has(key)) throw new Error(`ambiguous path: ${name} ${key}`)
    entries.set(key, entry)
  }
  return entries
}

function digest(buffer) {
  return createHash('sha256').update(buffer).digest('hex')
}

function normalizedText(buffer, oldRoot, newRoot) {
  return logical(buffer.toString('utf8'))
    .replaceAll(oldRoot, '<worktree>')
    .replaceAll(newRoot, '<worktree>')
}

const oldRoot = resolve(oldDirectory, '../../..')
const newRoot = resolve(output, '../../..')
const report = {}
const diffSections = []
for (const name of ['host', 'cli']) {
  const before = inventory(name, oldDirectory)
  const after = inventory(name, output)
  if (before.size !== after.size) throw new Error(`${name} file count changed`)
  const correspondence = []
  const changed = []
  let changedLinks = 0
  let changedRuntimeJavaScript = 0
  for (const key of [...before.keys()].sort()) {
    const oldEntry = before.get(key)
    const newEntry = after.get(key)
    if (newEntry === undefined) throw new Error(`${name} missing logical path: ${key}`)
    if (oldEntry.kind !== newEntry.kind) throw new Error(`${name} kind changed: ${key}`)
    const oldTarget = oldEntry.kind === 'link' ? logical(oldEntry.target) : undefined
    const newTarget = newEntry.kind === 'link' ? logical(newEntry.target) : undefined
    if (oldTarget !== newTarget) changedLinks++
    const byteChanged = oldEntry.kind === 'file' && oldEntry.sha256 !== newEntry.sha256
    if (byteChanged) {
      changed.push(key)
      if (/(?:^dist\/|\/dist\/).*\.js$/.test(key)) changedRuntimeJavaScript++
      const left = join(oldDirectory, `${name}-unpacked/app`, oldEntry.path)
      const right = join(output, `${name}-unpacked/app`, newEntry.path)
      const raw = spawnSync('diff', ['-u', left, right], { encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 })
      if (raw.status !== 1) throw new Error(`${name} unexpected diff status for ${key}`)
      diffSections.push(`## ${name}: ${key}\n${raw.stdout}`)
      const oldBytes = readFileSync(left)
      const newBytes = readFileSync(right)
      correspondence.push({
        logicalPath: key,
        oldPath: oldEntry.path,
        newPath: newEntry.path,
        kind: 'file',
        oldSha256: oldEntry.sha256,
        newSha256: newEntry.sha256,
        normalizedTextSha256: [
          digest(normalizedText(oldBytes, oldRoot, newRoot)),
          digest(normalizedText(newBytes, oldRoot, newRoot)),
        ],
      })
    } else {
      correspondence.push({
        logicalPath: key,
        oldPath: oldEntry.path,
        newPath: newEntry.path,
        kind: oldEntry.kind,
        ...(oldEntry.kind === 'file'
          ? { sha256: oldEntry.sha256 }
          : { oldTarget: oldEntry.target, newTarget: newEntry.target, logicalTarget: oldTarget }),
      })
    }
  }
  if (changedLinks !== 0 || changedRuntimeJavaScript !== 0)
    throw new Error(`${name}: logical links or runtime JS changed`)
  report[name] = { oldCount: before.size, newCount: after.size, changed, changedLinks, changedRuntimeJavaScript, correspondence }
}
writeFileSync(join(output, 'inventory-path-correspondence.json'), `${JSON.stringify(report, null, 2)}\n`)
writeFileSync(join(output, 'inventory-byte-diff.raw.txt'), `${diffSections.join('\n')}\n`)
process.stdout.write(
  `${JSON.stringify(
    Object.fromEntries(
      Object.entries(report).map(([name, value]) => [name, { count: value.oldCount, changed: value.changed, changedLinks: value.changedLinks, changedRuntimeJavaScript: value.changedRuntimeJavaScript }]),
    ),
    null,
    2,
  )}\n`,
)
