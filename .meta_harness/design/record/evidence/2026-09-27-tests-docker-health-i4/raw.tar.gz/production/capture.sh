#!/usr/bin/env bash
set -uo pipefail

name=$1
shift
directory=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
{
  printf 'startedUtc=%s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  printf 'cwd=%q\n' "$PWD"
  printf 'argv='
  printf '%q ' "$@"
  printf '\n'
  printf 'node=%s\n' "$(node --version)"
  printf 'pnpm=%s\n' "$(pnpm --version)"
  printf 'TMPDIR=%q\n' "$TMPDIR"
  printf 'PATH=%q\n' "$PATH"
} > "$directory/$name.command.txt"

"$@" > "$directory/$name.stdout.log" 2> "$directory/$name.stderr.log"
result=$?
printf '%s\n' "$result" > "$directory/$name.exit"
printf 'finishedUtc=%s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" >> "$directory/$name.command.txt"
exit "$result"
