import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const output = import.meta.dirname
const steps = [
  'host-package',
  'cli-package',
  'host-extract',
  'cli-extract',
  'archive-verify',
  'inventory-compare',
  'arm64-build',
  'amd64-build',
  'arm64-load',
  'amd64-load',
  'arm64-inspect',
  'amd64-inspect',
  'arm64-run-version',
  'arm64-run-node',
  'arm64-run-uid',
  'arm64-run-gid',
  'amd64-run-version',
  'amd64-run-node',
  'amd64-run-uid',
  'amd64-run-gid',
  'host-version',
  'cli-version',
  'cli-help',
  'node-version',
  'pnpm-version',
  'docker-version',
  'compose-version',
  'arm64-residual-containers',
  'amd64-residual-containers',
  'inventory-correspondence',
  'closure-scan',
]

let document = `# I4 artifact command ledger\n\nSource commit: b88da2da9e7bb30bd23a6dc097631e987bca319b.\nAll captured commands ran from the health-fix spoke with Node 24.21.0, pnpm 10.28.1 and TMPDIR=/private/tmp.\nThe original command lines and environment are retained in each .command.txt; stdout, stderr and exit status are separate raw files.\nOfficial host package, CLI package, arm64 image and amd64 image production ran strictly in that order.\n\n`
for (const [index, name] of steps.entries()) {
  const command = readFileSync(join(output, `${name}.command.txt`), 'utf8')
  const exit = readFileSync(join(output, `${name}.exit`), 'utf8').trim()
  if (exit !== '0') throw new Error(`${name} failed with ${exit}`)
  document += `## ${index + 1}. ${name} (exit ${exit})\n\n\`\`\`text\n${command}\`\`\`\nRaw output: ${name}.stdout.log and ${name}.stderr.log.\n\n`
}
document += `The saved tar archives were loaded and their exact imported tags inspected before image-ID runs. All docker run checks used --rm, --pull never and --network none. No helper, center service, fault injection, registry push, external deployment or user state was touched.\n\nThe independent app inventory comparison is in inventory-diff.json, inventory-normalized-diff.json, inventory-path-correspondence.json and inventory-byte-diff.raw.txt. The corresponding scripts and closure scan are in this directory.\n`
writeFileSync(join(output, 'commands.md'), document)
process.stdout.write(`steps=${steps.length}\n`)
