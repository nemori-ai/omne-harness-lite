import { readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'

const oldDirectory = resolve(process.argv[2])
const output = import.meta.dirname

function normalizePath(value) {
  return value.replace(
    /(@omne-harness-lite\+[^/@]+)@file\+[^/]+/g,
    '$1@file+local',
  )
}

function normalizedInventory(name, directory) {
  const manifest = JSON.parse(readFileSync(join(directory, `${name}-build-info.json`), 'utf8'))
  const entries = new Map()
  for (const entry of manifest.files) {
    const path = normalizePath(entry.path)
    if (entries.has(path)) throw new Error(`ambiguous normalized path: ${path}`)
    entries.set(path, {
      kind: entry.kind,
      value: entry.kind === 'link' ? normalizePath(entry.target) : entry.sha256,
    })
  }
  return { manifest, entries }
}

const report = {}
for (const name of ['host', 'cli']) {
  const before = normalizedInventory(name, oldDirectory)
  const after = normalizedInventory(name, output)
  const added = [...after.entries.keys()].filter(path => !before.entries.has(path)).sort()
  const removed = [...before.entries.keys()].filter(path => !after.entries.has(path)).sort()
  const changed = [...after.entries.keys()]
    .filter(
      path =>
        before.entries.has(path) &&
        JSON.stringify(before.entries.get(path)) !== JSON.stringify(after.entries.get(path)),
    )
    .sort()
  const runtimeDifference = [...added, ...removed, ...changed].filter(path =>
    /(?:^dist\/|\/dist\/).*\.js$/.test(path),
  )
  if (runtimeDifference.length !== 0)
    throw new Error(`${name} runtime JS changed: ${runtimeDifference.join(', ')}`)
  report[name] = {
    oldBuildId: before.manifest.buildId,
    newBuildId: after.manifest.buildId,
    oldCount: before.manifest.files.length,
    newCount: after.manifest.files.length,
    normalizedCount: after.entries.size,
    added,
    removed,
    changed,
    unchangedRuntimeJavaScript: [...after.entries.keys()].filter(path =>
      /(?:^dist\/|\/dist\/).*\.js$/.test(path),
    ).length,
  }
}
writeFileSync(join(output, 'inventory-normalized-diff.json'), `${JSON.stringify(report, null, 2)}\n`)
process.stdout.write(
  `${JSON.stringify(
    Object.fromEntries(
      Object.entries(report).map(([name, result]) => [
        name,
        {
          oldCount: result.oldCount,
          newCount: result.newCount,
          normalizedCount: result.normalizedCount,
          added: result.added.length,
          removed: result.removed.length,
          changed: result.changed,
          unchangedRuntimeJavaScript: result.unchangedRuntimeJavaScript,
        },
      ]),
    ),
    null,
    2,
  )}\n`,
)
