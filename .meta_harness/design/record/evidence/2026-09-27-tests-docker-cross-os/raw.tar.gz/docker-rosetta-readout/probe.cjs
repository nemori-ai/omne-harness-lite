const fs=require('node:fs'); const crypto=require('node:crypto');
const node=fs.readFileSync('/usr/local/bin/node');
const reset=fs.readFileSync('/proc/.reset');
if(reset.length>16384) throw new Error('unexpected reset probe size');
console.log(JSON.stringify({runtime:{arch:process.arch,platform:process.platform,execPath:process.execPath,version:process.version,pid:process.pid,execArgv:process.execArgv.slice(0,-1)},exe:fs.readlinkSync('/proc/1/exe'),cmdline:fs.readFileSync('/proc/1/cmdline').toString().split('\0'),node:{sha256:crypto.createHash('sha256').update(node).digest('hex'),elfMagic:node.subarray(0,4).toString('hex'),elfMachine:node.readUInt16LE(18)},reset:{sha256:crypto.createHash('sha256').update(reset).digest('hex'),text:reset.toString()},maps:fs.readFileSync('/proc/1/maps','utf8').split('\n').filter(x=>x.includes('/usr/local/bin/node')||x.includes('rosetta'))}));
