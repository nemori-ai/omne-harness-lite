# M0 DK-I2 / DK-I4 跨 OS 独立验收准备 · v2 夹具路径

状态：**v2 只做静态准备与离线检查，尚未实跑。**首轮正式 arm64 测量在原 `tmp/docker-cross-os/runs/20260926T204032Z-bfae1c01/` 因 Linux QA tar 的 `docker cp` 目标 `/tmp/omne-cross-os` 不可见而中止，未进入业务旅程；原脚本、gate、run 和非私有证据 SHA 清单均保留在原目录。本目录为指定 spoke 新建的 ignored 临时材料，本工具没有最终验收权。

## 输入与冻结边界

- 执行仓库：`/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-cross-os`，branch `pandazki/agent-work-loop-docker-cross-os`，HEAD `f8f286c95cb9458fe3173190edbeab6076339b08`。仅写本目录。施工计划为 HUB `tmp/next-iteration/tasks/docker-delivery.md` 的 V0、I3 与 DK-I2/I4。
- 设计工作区为本执行仓库 `.meta_harness`。采用范围：PF-016/PF-017 现行投影；`composition.governance-cli-entry/v2`、`composition.governance-client-operations/v2`、`composition.governance-center-entry/v3`、`composition.governance-center-entry-https-json/v3`，EC3 明列消费的 `capability.account-identity/v3` 与 `capability.organization-governance/v2`。精确状态/决定见 `design/registry/catalog.json` 各坐标与 D-050、D-055～D-057、D-070 Docker R4、D-071 R5。映射消费 `design/realization/apps/tenancy-host/{docker,maintenance-binding,packaging}.md` 与 `design/realization/apps/cli/{governance,packaging}.md`，其中 Docker R5 文件 SHA256 `3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223`。
- 最终 I3 manifest：`/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery/tmp/docker-delivery/i3-f8f286c9/manifest-delivery.json`，SHA256 `c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e`。预检逐件核该清单中的 host/CLI BUILD_ID、CLI tar、对应架构 image tar 与六项部署文件 SHA；实际私有 daemon 内导入后再核镜像层、arch、labels 与实际运行身份。该 manifest 的独立归档 inventory 核验由 root 已完成，测量器不以标签取代归档审核。
- 只读复用 V0 固定控制输入与 `r5-helper-prep/driver.py`，后者 SHA256 `a450179ed522b8ab2033f0aa368c5d4ad3fe43139353b9d14d24afb01915da26`。复用其唯一资源命名、原始命令日志、私有 DinD 数据路径、inode/UID 三视角比较与 exact-label 清理；本脚本拥有跨 OS 端口与旅程。旧 `oracle.py` 没被复用，尤其不要求 restore target 的 marker。

静态输入快照分别是 `arm64-inputs.json` 与 `amd64-inputs.json`；运行前应重新生成并比较。每个平台独立一轮，root 先审放 arm64，amd64 留待另一波，避免把 amd64 的 Docker Desktop 模拟称为原生 amd64。控制容器本身为固定 Linux arm64 systemd/Node24.21/OpenSSL3 镜像；私有 Engine/CLI 为29.1.3，Compose为2.40.3。Mac 侧必须在 `fnm exec --using=24.21.0` 环境下运行，以确保本地 `node` 精确版本；root 实际命令还设置 `TMPDIR=/private/tmp`。任一缓存镜像、工具或制品缺失/哈希不符即拒绝，不拉取替代项。

## 真实测量路径及通过条件

`driver.py` 从 root Linux control 容器调用正式 `omne-center`，只把私有 DinD socket 以 named volume 共享给 control，用户主 Docker socket 不进入控制容器。外层只有本轮唯一 label 的 control、DinD、三个卷、一个网络；DinD 的 `18443/tcp` 外层只发布到 Mac `127.0.0.1` 的 Engine 分配临时端口。内层 center 把端口发布到 DinD 的私网 IP，Linux CLI 从 control 容器访问该 IP；Mac CLI 访问回环端口。两段 NAT 只转 TCP，TLS 始终由正式 center 终结。一次性证书 SAN 覆盖 `127.0.0.1` 与实际 DinD IP；Mac/Linux 各以该 CA、真实 Node24.21 运行 I3 CLI 制品。伪 CA 配置须返回 `transportFailure=trust` 且未发送目标操作，OpenSSL3 的 TLS1.2 握手须失败。

v2 只修测量夹具的控制容器路径：Linux QA tar、解压目录、CLI 状态、payload/凭据文件、测试 CA 与 decoy CA 一律位于常规 rootfs 的 `/opt/omne-cross-os/private`（祖先和该目录 0700；输入文件由 0077 umask 创建）。首轮 raw 显示 `mkdir-plugin`、`copy-omne-center`、`mkdir-qa` 都 rc0，而随后 `copy-linux-cli-tar` rc1，Docker 报 `/tmp/omne-cross-os` 不存在；control 的 `/tmp` 是 tmpfs。此前 `docker cp` 到常规 rootfs `/usr/local/libexec` 已在同一轮成功。这里据此改路径，不推断 v2 已通过 Docker。产品 state、secrets、helper、镜像、网络与验收判据不变。

| 场景 | 直接判据（均由 `oracle.py` 从原始输出重读） | 来源 |
| --- | --- | --- |
| DK-I2 每架构真实 image | 导入私有 Engine 的层、OS/arch、BUILD_ID 对 I3；真实中心容器 `node` PID1、UID10001、Node24.21、health=healthy、同一 `/state` bind；两架构分别运行并记录宿主 CPU/模拟范围 | Docker R5「输入、目录、镜像身份」、I3 manifest、计划 DK-I2 |
| DK-I4 两系统同中心 | Mac 注册/登录 Alice，Linux 注册/登录 Bob；各建团队，初始及重建后租户列表每项的账号必须等于调用者账号，且不得出现对方组织下本账号的身份；Bob 退出 A 后列表仍不得再含 A；Bob 对 A 团队成员读被拒；Alice 切身份邀 Bob，Bob 收邀请并接受、切身份，成员读有效；Alice 升/降 Bob 角色，Bob 的超管读随之可用/拒绝；Bob 退出团队后读被拒 | AI3、OG2 S-21/25/26/27/28/29/36/37/57/60，EC3 S-15/16/17/22/23，CQ2 S-13～15 |
| DK-I4 重建与排他 | helper `stop` 的同 ID `clean=true,exitCode=0`，另以真实 inspect 核 exited/0；完整导出旧 logs/inspect 后只对该 ID `docker rm`，同 STATE 重建，容器 ID 必变；四次 Mac/Linux health 的 centerId 必同且合法，两个团队及各自选择/成员事实仍可现读。同库第二项目确实创建实际 center 容器并因 `occupied` 启动失败；原中心 `full-health` 的五个健康布尔须全部为 true，defectCount 为整数 0，centerId 等于客户端已观测值。最终 stop 后、fixture cleanup 前，另存同 ID 真实 inspect 并核 exited/0/Running=false | EC3 S-26～28 与停机承诺、Docker R5 停止/属主、计划 DK-I4 |
| DK-I4 TLS/退出 | 两系统错误 CA 都拒绝且不降级；TLS1.2 负例须由 OpenSSL3 原 stderr 显示 peer `alert protocol version`，并以有效 cipher 排除已协商成功，不能把连接失败或成功握手后的 EOF 当成拒绝；两系统 logout 后下一次治理读均阻断且不发目标请求 | HT3 S-4/30、CQ2 S-15、AI3 撤销/出示物 |
| 工具收场 | 每条命令原字节 stdout、stderr、退出码与 argv 单独落盘；伪造成功/漏命令不能通过；测试凭据不出现在任何原始输出/元数据；第二项目与内外资源按精确 label 清理、最终各集合为空 | 计划「独立 oracle」、V0 资源纪律 |

`driver.py` 的 `runs/<run-id>/raw/` 是每步原始输出，`evidence.json` 记录时间、argv、真实退出/观察超时、资源及清理；`private/` 0700 保存一次性测试输入。未知业务写入不会自动重试。`oracle.py` 以返回身份、列表和成员事实、真实镜像/容器 inspect、停止终态、TLS 错误与 exact-label 空查询判断；单独 rc0、helper 自报、回调调用均不够。每轮应用容器和私有环境的实际退出、残余及诊断应在 root 保全后再考虑退休 spoke。

## 离线复核及后续运行门

已执行（均在指定 spoke，未触碰 Docker）：

```text
python3 -B -m py_compile tmp/docker-cross-os-v2/{driver,oracle,test_offline}.py
black --check tmp/docker-cross-os-v2/{driver,oracle,test_offline}.py
python3 -B tmp/docker-cross-os-v2/test_offline.py
python3 -B tmp/docker-cross-os-v2/driver.py --platform arm64 --print-inputs > tmp/docker-cross-os-v2/arm64-inputs.json
python3 -B tmp/docker-cross-os-v2/driver.py --platform amd64 --print-inputs > tmp/docker-cross-os-v2/amd64-inputs.json
python3 -B tmp/docker-cross-os-v2/driver.py --platform arm64
```

`offline-result.json`：合成基线 PASS；25 项负控全检出，0 漏检；另有 `Cipher is (NONE)` 加 peer alert 的合成合法解析边界 PASS。后者不是实际 OpenSSL 输出观测。无 gate 时退出 2。旧 oracle 的历史快照在原 `tmp/docker-cross-os/history/`；v2 不复用原 arm64 gate，不把旧失败改写为产品失败或通过。

root 实际放行时，每个平台重新运行 `--print-inputs`，核 `inputs_sha256`、本目录 driver/oracle SHA、I3 manifest/制品与外层固定 image/tool 缓存；随后由 root 为该平台写一份私有 `reviewed-gate-<platform>.json`，内容严格为：

```json
{"approved":true,"reviewer":"root","inputs_sha256":"<该平台 print-inputs 值>","driver_sha256":"<inputs.sha256.driver>","oracle_sha256":"<inputs.sha256.oracle>"}
```

再在 `TMPDIR=/private/tmp` 与 `fnm exec --using=24.21.0` 下执行 `python3 -B tmp/docker-cross-os-v2/driver.py --platform <arm64|amd64> --reviewed-gate <该平台新 gate 的绝对路径> --execute`。任一输入或代码变化使 gate 失效。运行会冻结 helper 与 oracle、生成唯一 run，最后自动调用冻结 oracle 并打印 run 位置及结果；实际执行需要 root 另审定命令与副作用。此目录没有 gate 文件，也未获 v2 实跑放行。

## 未覆盖

DK-I3 的安装负控、DK-I5 在线并发备份/验证/隔离恢复、DK-I6 IO 门和关闭错误、DK-I7 daemon 故障、DK-I8 timer、DK-I9 升级、DK-I10 客户端失联由各自任务承担。本工具未做 I5 并发；可复用 `Journey.go()` 两账号登录且团队已确认之后、stop 之前的同一私有环境，但需另一个能分别记录两个进程原始开始/结束和真实交叠的测量器，且不能要求快照必含最后写。未测公司 DNS/CA、真实人员或生产密钥、裸机断电耐久、原生 amd64 CPU、CLI TUI 人读。有限离线负控不证明正式 I3 产品或两架构运行通过。
