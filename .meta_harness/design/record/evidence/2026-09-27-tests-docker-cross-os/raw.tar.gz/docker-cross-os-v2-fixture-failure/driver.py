#!/usr/bin/env python3
"""One-platform DK-I2/I4 runner. Docker execution requires an exact root review gate."""

import argparse
import hashlib
import importlib.util
import json
import pathlib
import platform as host_platform
import re
import secrets
import shutil
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
TREE = pathlib.Path(__file__).resolve().parents[2]
I3 = pathlib.Path(
    "/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery/tmp/docker-delivery/i3-f8f286c9"
)
MANIFEST = I3 / "manifest-delivery.json"
MANIFEST_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
BASE_PATH = pathlib.Path(
    "/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-fixtures/tmp/docker-product-fixtures/r5-helper-prep/driver.py"
)
BASE_SHA = "a450179ed522b8ab2033f0aa368c5d4ad3fe43139353b9d14d24afb01915da26"
V0 = BASE_PATH.parent.parent / "v0c"
HELPER_DIR = TREE / "apps/tenancy-host/deploy/docker"
PORT = "18443"
LINUX_QA_DIR = "/opt/omne-cross-os/private"
LINUX_CLI = LINUX_QA_DIR + "/app/dist/main.js"
HEX32 = re.compile(r"[0-9a-f]{32}\Z")
IMAGE = re.compile(r"sha256:[0-9a-f]{64}\Z")


def need(test, message):
    if not test:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def load_base():
    need(sha(BASE_PATH) == BASE_SHA, "frozen V0 driver changed")
    spec = importlib.util.spec_from_file_location("frozen_v0_driver", BASE_PATH)
    need(spec is not None and spec.loader is not None, "V0 import unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.HERE = HERE  # Run evidence and frozen oracle belong to this spoke.
    return module


def input_set(platform):
    need(platform in ("arm64", "amd64"), "platform")
    need(sha(MANIFEST) == MANIFEST_SHA, "I3 manifest changed")
    manifest = json.loads(MANIFEST.read_text())
    need(
        manifest["source"]["commit"] == "f8f286c95cb9458fe3173190edbeab6076339b08",
        "I3 source",
    )
    need(
        manifest["archives"]["host"]["buildId"]
        == "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616",
        "host BUILD_ID",
    )
    need(
        manifest["archives"]["cli"]["buildId"]
        == "f38e46f1f169aea8993640c8ccf0ffc42545f2d64adf21f96b6658b2c83bb9f1",
        "CLI BUILD_ID",
    )
    image = manifest["images"][platform]
    need(
        image["platform"] == "linux/" + platform and IMAGE.fullmatch(image["imageId"]),
        "image identity",
    )
    paths = {
        "helper": HELPER_DIR / "omne-center",
        "compose": HELPER_DIR / "compose.yaml",
        "maintenance_compose": HELPER_DIR / "compose.maintenance.yaml",
        "health": HELPER_DIR / "health.mjs",
        "service": HELPER_DIR / "omne-center-backup@.service",
        "timer": HELPER_DIR / "omne-center-backup@.timer",
        "image_tar": pathlib.Path(image["archive"]),
        "cli_tar": pathlib.Path(manifest["archives"]["cli"]["path"]),
        "compose_binary": V0 / "docker-compose-linux-aarch64",
        "docker_cli": V0 / "extracted-bin/docker",
        "manifest": MANIFEST,
        "v0_driver": BASE_PATH,
        "driver": HERE / "driver.py",
        "oracle": HERE / "oracle.py",
    }
    hashes = {key: sha(path) for key, path in paths.items()}
    for name, manifest_key in (
        ("helper", "omne-center"),
        ("compose", "compose.yaml"),
        ("maintenance_compose", "compose.maintenance.yaml"),
        ("health", "health.mjs"),
        ("service", "omne-center-backup@.service"),
        ("timer", "omne-center-backup@.timer"),
    ):
        need(
            hashes[name] == manifest["deployFiles"][manifest_key]["sourceSha256"],
            name + " SHA",
        )
    need(
        hashes["helper"]
        == "71ba9f3c31b34c171dd2a4048d9e249af31f7948abcf66ee603da5ffb7d1b365",
        "helper adopted SHA",
    )
    need(hashes["image_tar"] == image["archiveSha256"], "image tar SHA")
    need(hashes["cli_tar"] == manifest["archives"]["cli"]["sha256"], "CLI tar SHA")
    need(
        hashes["compose_binary"]
        == "d26373b19e89160546d15407516cc59f453030d9bc5b43ba7faf16f7b4980137"
        and hashes["docker_cli"]
        == "544cf329807e30c9601652562a159b17179345146be0f8211bfe2ebd872eb880",
        "V0 control tools SHA",
    )
    need(
        hashes["v0_driver"] == BASE_SHA and hashes["manifest"] == MANIFEST_SHA,
        "fixture SHA",
    )
    need(
        sha(TREE / ".meta_harness/design/realization/apps/tenancy-host/docker.md")
        == "3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223",
        "R5 node SHA",
    )
    need(
        subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=TREE,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        == manifest["source"]["commit"],
        "worktree HEAD",
    )
    return {
        "paths": {key: str(path.resolve()) for key, path in paths.items()},
        "sha256": hashes,
        "platform": platform,
        "image_id": image["imageId"],
        "build_id": image["buildId"],
        "cli_build_id": manifest["archives"]["cli"]["buildId"],
        "source_commit": manifest["source"]["commit"],
        "uid": 10001,
        "gid": 10001,
        "observe_seconds": 600,
        "timer_observe_seconds": 30,
    }


def args_for_base(inputs, gate):
    names = {
        "helper_dir": HELPER_DIR,
        "image_tar": pathlib.Path(inputs["paths"]["image_tar"]),
        "image_id": inputs["image_id"],
        "build_id": inputs["build_id"],
        "uid": 10001,
        "gid": 10001,
        "observe_seconds": 600,
        "timer_observe_seconds": 30,
        "reviewed_gate": gate,
    }
    return argparse.Namespace(**names)


class Journey:
    def __init__(self, run, base, inputs):
        self.run = run
        self.base = base
        self.inputs = inputs
        self.history = []
        self.private = run.run / "private"
        self.private.mkdir(mode=0o700)

    def parse(self, label, data):
        return self.base.parse_json_line(data, label)

    def deployment(self, project=None, port=PORT):
        return [
            "--project",
            project or self.run.project,
            "--image",
            self.run.image_id,
            "--state-dir",
            self.base.STATE,
            "--secrets-dir",
            self.base.SECRETS,
            "--settings-file",
            self.base.SETTINGS,
            "--publish-address",
            self.run.dind_ip,
            "--publish-port",
            str(port),
            "--uid",
            "10001",
            "--gid",
            "10001",
        ]

    def put_control(self, label, path, content):
        self.run.outer(
            label,
            "exec",
            "-i",
            self.run.control,
            "sh",
            "-c",
            'umask 077; cat > "$1"',
            "sh",
            path,
            stdin=content,
        )

    def input_file(self, os_name, label, content, secret=False):
        need(re.fullmatch(r"[a-z0-9-]+", label) is not None, "input label")
        if os_name == "mac":
            path = self.private / (label + (".secret" if secret else ".json"))
            path.write_bytes(content)
            path.chmod(0o600)
            return str(path)
        path = LINUX_QA_DIR + "/" + label + (".secret" if secret else ".json")
        self.put_control("input-" + label, path, content)
        return path

    def cli(
        self,
        label,
        os_name,
        client,
        action,
        payload=None,
        credential=None,
        endpoint=None,
        ca=None,
        refresh=False,
        expected=None,
    ):
        command = {
            "configure": ["center", "configure"],
            "health": ["center", "health"],
            "register": ["register"],
            "login": ["login"],
            "logout": ["logout"],
            "current": ["tenant", "current"],
            "tenant-list": ["tenant", "list"],
            "create": ["organization", "create"],
            "invite": ["invitation", "invite-by-login"],
            "inbox": ["invitation", "inbox"],
            "accept": ["invitation", "accept"],
            "switch": ["tenant", "switch"],
            "membership": ["membership", "inspect"],
            "members": ["membership", "list"],
            "role": ["membership", "set-role"],
            "remove": ["membership", "remove"],
            "admin-inbox": ["affiliation", "inbox"],
        }[action]
        state = (
            str(self.private / ("state-" + client))
            if os_name == "mac"
            else LINUX_QA_DIR + "/state-" + client
        )
        argv = ["machine", *command, "--state-dir", state]
        if action == "configure":
            argv += ["--endpoint", endpoint, "--ca-file", ca]
        else:
            if action in ("register", "login"):
                identifier = payload.pop("loginIdentifier")
                argv += ["--login-identifier", identifier]
            if payload is not None:
                argv += [
                    "--payload-file",
                    self.input_file(os_name, label, canonical(payload)),
                ]
            if credential is not None:
                argv += [
                    "--credential-file",
                    self.input_file(os_name, label, credential, True),
                ]
            if refresh:
                argv += ["--refresh"]
        if os_name == "mac":
            actual = self.run.call(
                label,
                [self.run.mac_node, str(self.run.mac_cli), *argv],
                timeout=90,
                expected=expected,
            )
        else:
            actual = self.run.outer(
                label,
                "exec",
                "-e",
                "HOME=" + LINUX_QA_DIR,
                self.run.control,
                "node",
                LINUX_CLI,
                *argv,
                timeout=90,
                expected=expected,
            )
        report = self.parse(label, actual)
        need(
            report.get("format") == "governance-client/1",
            label + " malformed CLI report",
        )
        self.history.append(
            {"label": label, "os": os_name, "client": client, "action": action}
        )
        self.run.evidence["journey"] = self.history
        self.run.save()
        return report

    @staticmethod
    def result(report, label):
        need(
            report.get("remote", {}).get("status") == "success"
            and report.get("remote", {}).get("reply", {}).get("reply", {}).get("result")
            is not None,
            label + " did not return a remote result",
        )
        return report["remote"]["reply"]["reply"]["result"]

    def go(self):
        r = self.run
        deployment = self.deployment()
        r.helper("validate", "validate", *deployment)
        started = self.parse(
            "start", r.helper("start", "start", *deployment, timeout=600)
        )
        cid = started["containerId"]
        need(re.fullmatch(r"[0-9a-f]{64}", cid), "start container ID")
        r.evidence["expected"]["first_center_container"] = cid
        r.save()
        r.inner("center-inspect-before", "inspect", cid)
        r.inner("center-pid1-before", "exec", cid, "cat", "/proc/1/comm")
        r.inner("center-uid-before", "exec", cid, "id", "-u")
        r.inner("center-node-before", "exec", cid, "node", "--version")
        mac_url = f"https://127.0.0.1:{r.mac_port}/"
        linux_url = f"https://{r.dind_ip}:{PORT}/"
        self.cli(
            "mac-configure-alice",
            "mac",
            "alice",
            "configure",
            endpoint=mac_url,
            ca=str(self.private / "ca.pem"),
        )
        self.cli(
            "linux-configure-bob",
            "linux",
            "bob",
            "configure",
            endpoint=linux_url,
            ca=LINUX_QA_DIR + "/ca.pem",
        )
        mac_health = self.cli("mac-health-before", "mac", "alice", "health")
        linux_health = self.cli("linux-health-before", "linux", "bob", "health")
        center_id = mac_health["remote"]["health"]["centerId"]
        need(
            HEX32.fullmatch(center_id)
            and linux_health["remote"]["health"]["centerId"] == center_id,
            "cross OS center ID",
        )
        name_a, name_b = "qa" + r.project + "a", "qa" + r.project + "b"
        password_a, password_b = (
            secrets.token_hex(18).encode(),
            secrets.token_hex(18).encode(),
        )
        bob_secret = self.private / "bob-credential.secret"
        bob_secret.write_bytes(password_b)
        bob_secret.chmod(0o600)
        self.cli(
            "mac-register-alice",
            "mac",
            "alice",
            "register",
            {"loginIdentifier": name_a},
            password_a,
        )
        self.cli(
            "linux-register-bob",
            "linux",
            "bob",
            "register",
            {"loginIdentifier": name_b},
            password_b,
        )
        self.cli(
            "mac-login-alice",
            "mac",
            "alice",
            "login",
            {"loginIdentifier": name_a},
            password_a,
        )
        self.cli(
            "linux-login-bob",
            "linux",
            "bob",
            "login",
            {"loginIdentifier": name_b},
            password_b,
        )
        personal_a = self.result(
            self.cli(
                "mac-current-personal", "mac", "alice", "current", {}, refresh=True
            ),
            "alice current",
        )
        personal_b = self.result(
            self.cli(
                "linux-current-personal", "linux", "bob", "current", {}, refresh=True
            ),
            "bob current",
        )
        team_a = self.result(
            self.cli(
                "mac-create-team-a",
                "mac",
                "alice",
                "create",
                {"creationKey": "cross-a-" + r.project},
            ),
            "team A",
        )
        team_b = self.result(
            self.cli(
                "linux-create-team-b",
                "linux",
                "bob",
                "create",
                {"creationKey": "cross-b-" + r.project},
            ),
            "team B",
        )
        tenant_a = {"organization": team_a, "account": personal_a["account"]}
        tenant_b = {"organization": team_b, "account": personal_b["account"]}
        bob_a = {"organization": team_a, "account": personal_b["account"]}
        self.cli("mac-list-isolated", "mac", "alice", "tenant-list", {}, refresh=True)
        self.cli("linux-list-isolated", "linux", "bob", "tenant-list", {}, refresh=True)
        self.cli(
            "linux-not-member-a",
            "linux",
            "bob",
            "membership",
            {"tenant": bob_a},
            refresh=True,
        )
        self.cli(
            "mac-switch-team-a",
            "mac",
            "alice",
            "switch",
            {"expectedTenant": personal_a, "targetTenant": tenant_a},
        )
        self.cli("mac-current-team-a", "mac", "alice", "current", {}, refresh=True)
        invitation = self.result(
            self.cli(
                "mac-invite-bob",
                "mac",
                "alice",
                "invite",
                {"expectedTenant": tenant_a, "loginIdentifier": name_b},
            ),
            "invitation",
        )
        self.cli("linux-inbox-bob", "linux", "bob", "inbox", {}, refresh=True)
        self.cli("linux-accept", "linux", "bob", "accept", {"invitation": invitation})
        self.cli(
            "linux-switch-team-a",
            "linux",
            "bob",
            "switch",
            {"expectedTenant": personal_b, "targetTenant": bob_a},
        )
        self.cli("linux-current-team-a", "linux", "bob", "current", {}, refresh=True)
        self.cli(
            "linux-member-after-accept",
            "linux",
            "bob",
            "membership",
            {"tenant": bob_a},
            refresh=True,
        )
        self.cli(
            "mac-promote-bob",
            "mac",
            "alice",
            "role",
            {
                "expectedTenant": tenant_a,
                "targetTenant": bob_a,
                "role": "superAdministrator",
            },
        )
        self.cli(
            "linux-admin-after-promote",
            "linux",
            "bob",
            "admin-inbox",
            {"expectedTenant": bob_a},
            refresh=True,
        )
        self.cli(
            "mac-demote-bob",
            "mac",
            "alice",
            "role",
            {"expectedTenant": tenant_a, "targetTenant": bob_a, "role": "member"},
        )
        self.cli(
            "linux-admin-after-demote",
            "linux",
            "bob",
            "admin-inbox",
            {"expectedTenant": bob_a},
            refresh=True,
        )
        self.cli(
            "linux-leave-team-a",
            "linux",
            "bob",
            "remove",
            {"expectedTenant": bob_a, "targetTenant": bob_a},
        )
        self.cli(
            "linux-member-after-leave",
            "linux",
            "bob",
            "membership",
            {"tenant": bob_a},
            refresh=True,
        )
        # TLS trust failure is checked on an otherwise reachable center.
        self.cli(
            "mac-bad-ca",
            "mac",
            "bad-mac",
            "configure",
            endpoint=mac_url,
            ca=str(self.private / "bad-ca.pem"),
        )
        self.cli(
            "linux-bad-ca",
            "linux",
            "bad-linux",
            "configure",
            endpoint=linux_url,
            ca=LINUX_QA_DIR + "/bad-ca.pem",
        )
        r.control_exec(
            "tls12-negative",
            "openssl",
            "s_client",
            "-tls1_2",
            "-connect",
            f"{r.dind_ip}:{PORT}",
            expected=None,
        )
        self.second_owner()
        stopped = self.parse(
            "stop", r.helper("stop", "stop", "--project", r.project, timeout=600)
        )
        need(
            stopped.get("containerId") == cid
            and stopped.get("clean") is True
            and stopped.get("exitCode") == 0,
            "clean stop required before removal",
        )
        r.inner("first-center-logs-export", "logs", cid)
        inspected = json.loads(r.inner("first-center-inspect-export", "inspect", cid))[
            0
        ]
        need(
            inspected["Id"] == cid
            and inspected["State"]["Status"] == "exited"
            and inspected["State"]["ExitCode"] == 0,
            "actual exited state required before removal",
        )
        r.inner("remove-first-center", "rm", cid)
        restarted = self.parse(
            "restart", r.helper("restart", "start", *deployment, timeout=600)
        )
        new_cid = restarted["containerId"]
        need(new_cid != cid, "container was not rebuilt")
        r.evidence["expected"]["second_center_container"] = new_cid
        r.save()
        r.inner("center-inspect-after", "inspect", new_cid)
        r.inner("center-pid1-after", "exec", new_cid, "cat", "/proc/1/comm")
        r.inner("center-uid-after", "exec", new_cid, "id", "-u")
        r.inner("center-node-after", "exec", new_cid, "node", "--version")
        self.cli("mac-health-after", "mac", "alice", "health")
        self.cli("linux-health-after", "linux", "bob", "health")
        self.cli(
            "mac-current-after-restart", "mac", "alice", "current", {}, refresh=True
        )
        self.cli(
            "linux-current-after-restart", "linux", "bob", "current", {}, refresh=True
        )
        self.cli(
            "mac-list-after-restart", "mac", "alice", "tenant-list", {}, refresh=True
        )
        self.cli(
            "linux-list-after-restart", "linux", "bob", "tenant-list", {}, refresh=True
        )
        self.cli(
            "mac-member-after-restart",
            "mac",
            "alice",
            "membership",
            {"tenant": tenant_a},
            refresh=True,
        )
        self.cli(
            "linux-member-after-restart",
            "linux",
            "bob",
            "membership",
            {"tenant": bob_a},
            refresh=True,
        )
        self.cli("mac-logout", "mac", "alice", "logout")
        self.cli("linux-logout", "linux", "bob", "logout")
        self.cli("mac-after-logout", "mac", "alice", "current", {})
        self.cli("linux-after-logout", "linux", "bob", "current", {})
        final_stop = self.parse(
            "final-stop",
            r.helper("final-stop", "stop", "--project", r.project, timeout=600),
        )
        need(
            final_stop.get("containerId") == new_cid
            and final_stop.get("clean") is True,
            "final stop",
        )
        final_inspect = json.loads(
            r.inner("final-center-inspect-before-cleanup", "inspect", new_cid)
        )[0]
        need(
            final_inspect["Id"] == new_cid
            and final_inspect["State"]["Status"] == "exited"
            and final_inspect["State"]["ExitCode"] == 0
            and final_inspect["State"]["Running"] is False,
            "actual final exited state required before cleanup",
        )
        r.evidence["business_complete"] = True
        r.save()

    def second_owner(self):
        r = self.run
        second = r.project + "other"
        args = self.deployment(project=second, port="18444")
        r.helper("second-owner-validate", "validate", *args)
        r.helper("second-owner-start", "start", *args, timeout=150, expected=None)
        need(
            r.evidence["commands"][-1]["returncode"] != 0,
            "second owner unexpectedly started",
        )
        r.helper(
            "first-owner-health-after-second", "full-health", "--project", r.project
        )
        r.inner(
            "second-owner-ps",
            "ps",
            "-aq",
            "--no-trunc",
            "--filter",
            f"label=ai.nemori.omne.project={second}",
        )
        ids = (r.run / "raw/second-owner-ps.stdout").read_text().splitlines()
        need(len(ids) == 1, "second owner container count")
        r.inner("second-owner-inspect", "inspect", ids[0])
        r.inner("second-owner-logs", "logs", ids[0])
        r.evidence["expected"]["second_owner_container"] = ids[0]
        r.evidence["expected"]["second_owner_project"] = second
        r.save()


def run_platform(platform, gate):
    need(host_platform.system() == "Darwin", "Mac CLI leg requires a Darwin host")
    inputs = input_set(platform)
    gate_data = json.loads(gate.read_text())
    need(
        gate_data
        == {
            "approved": True,
            "reviewer": "root",
            "inputs_sha256": hashlib.sha256(canonical(inputs)).hexdigest(),
            "driver_sha256": inputs["sha256"]["driver"],
            "oracle_sha256": inputs["sha256"]["oracle"],
        },
        "review gate missing or stale",
    )
    base = load_base()
    args = args_for_base(inputs, gate)
    run = base.Run(args, inputs)
    for name, source, key in (
        ("driver.py", HERE / "driver.py", "driver"),
        ("v0-driver.py", BASE_PATH, "v0_driver"),
        ("manifest-delivery.json", MANIFEST, "manifest"),
    ):
        frozen = run.frozen / name
        shutil.copyfile(source, frozen)
        need(sha(frozen) == inputs["sha256"][key], "frozen input changed: " + name)
    run.evidence["host"] = {
        "system": host_platform.system(),
        "machine": host_platform.machine(),
    }
    run.save()
    journey = Journey(run, base, inputs)
    try:
        setup(run, base)
        import_image(run, base, platform)
        run.prepare_paths()
        prepare_clients(run, journey)
        journey.go()
        run.evidence["status"] = "observed-awaiting-oracle"
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
    finally:
        other_errors = cleanup_other_project(run)
        run.cleanup()
        run.evidence["other_project_cleanup_complete"] = not other_errors
        run.evidence["other_project_cleanup_errors"] = other_errors
        run.save()
    with (
        (run.run / "oracle.stdout").open("xb") as out,
        (run.run / "oracle.stderr").open("xb") as err,
    ):
        result = subprocess.run(
            [sys.executable, "-B", str(run.frozen / "oracle.py"), str(run.run)],
            stdout=out,
            stderr=err,
            check=False,
        )
    run.evidence["oracle_exit"] = result.returncode
    run.save()
    print(
        json.dumps(
            {
                "run": str(run.run),
                "oracle_exit": result.returncode,
                "cleanup_complete": run.evidence["cleanup_complete"],
            },
            sort_keys=True,
        )
    )
    return result.returncode


def setup(run, base):
    for kind, name in [
        ("network", run.network),
        *(("volume", v) for v in run.volumes),
        ("container", run.control),
        ("container", run.dind),
    ]:
        run.preflight_resource(kind, name)
    for image, expected in ((base.CONTROL, base.CONTROL_ID), (base.DIND, base.DIND_ID)):
        actual = json.loads(
            run.outer("outer-image-" + image.split(":")[0], "image", "inspect", image)
        )[0]["Id"]
        need(actual == expected, "fixed image changed " + image)
    run.create(
        "network", run.network, "network", "create", "--label", run.label, run.network
    )
    for volume in run.volumes:
        run.create("volume", volume, "volume", "create", "--label", run.label, volume)
    run.create(
        "container",
        run.control,
        "run",
        "-d",
        "--pull",
        "never",
        "--name",
        run.control,
        "--label",
        run.label,
        "--network",
        run.network,
        "--privileged",
        "-e",
        f"DOCKER_HOST={base.SOCKET}",
        "--cgroupns=private",
        "--tmpfs",
        "/run",
        "--tmpfs",
        "/run/lock",
        "--tmpfs",
        "/tmp",
        "-v",
        f"{run.volumes[0]}:{base.ROOT}",
        "-v",
        f"{run.volumes[1]}:/opt/omne-private-docker",
        base.CONTROL,
    )
    run.create(
        "container",
        run.dind,
        "run",
        "-d",
        "--pull",
        "never",
        "--name",
        run.dind,
        "--label",
        run.label,
        "--network",
        run.network,
        "--privileged",
        "-p",
        f"127.0.0.1::{PORT}",
        "-e",
        f"DOCKER_HOST={base.SOCKET}",
        "-e",
        "DOCKER_TLS_CERTDIR=",
        "-v",
        f"{run.volumes[0]}:{base.ROOT}",
        "-v",
        f"{run.volumes[1]}:/opt/omne-private-docker",
        "-v",
        f"{run.volumes[2]}:/var/lib/docker",
        base.DIND,
        "--host",
        base.SOCKET,
        "--tls=false",
    )
    for outer in (run.control, run.dind):
        inspected = json.loads(run.outer("outer-inspect-" + outer, "inspect", outer))[0]
        need(
            all(m["Type"] == "volume" for m in inspected["Mounts"]),
            "host bind forbidden",
        )
        ports = inspected["NetworkSettings"]["Ports"]
        if outer == run.control:
            need(not inspected["HostConfig"]["PortBindings"], "control port forbidden")
        else:
            published = ports[f"{PORT}/tcp"]
            need(
                len(published) == 1 and published[0]["HostIp"] == "127.0.0.1",
                "Mac forwarding must be loopback only",
            )
            run.mac_port = int(published[0]["HostPort"])
            run.dind_ip = inspected["NetworkSettings"]["Networks"][run.network][
                "IPAddress"
            ]
            need(
                re.fullmatch(r"(?:10|172|192)\.[0-9.]+", run.dind_ip)
                and 1 <= run.mac_port <= 65535,
                "private DinD IP/port",
            )
    need(run.control_exec("control-uid", "id", "-u").strip() == b"0", "control root")
    need(
        run.control_exec("control-pid1", "cat", "/proc/1/comm").strip() == b"systemd",
        "control systemd",
    )
    run.control_exec("control-systemd-version", "systemctl", "--version")
    need(
        run.control_exec("linux-uname", "uname", "-s").strip() == b"Linux",
        "Linux client control",
    )
    run.control_exec(
        "mkdir-plugin",
        "install",
        "-d",
        "-m",
        "0755",
        "/usr/local/lib/docker/cli-plugins",
        "/usr/local/libexec",
    )
    run.copy(
        "copy-docker-cli", base.V0 / "extracted-bin/docker", "/usr/local/bin/docker"
    )
    run.copy(
        "copy-compose",
        base.V0 / "docker-compose-linux-aarch64",
        "/usr/local/lib/docker/cli-plugins/docker-compose",
    )
    run.control_exec(
        "chmod-cli",
        "chmod",
        "0755",
        "/usr/local/bin/docker",
        "/usr/local/lib/docker/cli-plugins/docker-compose",
    )
    for attempt in range(1, 41):
        output = run.inner(
            f"engine-ready-{attempt}",
            "version",
            "--format",
            "{{.Client.Version}} {{.Server.Version}}",
            expected=None,
        )
        if (
            run.evidence["commands"][-1]["returncode"] == 0
            and output.strip() == b"29.1.3 29.1.3"
        ):
            break
        import time

        time.sleep(1)
    else:
        raise RuntimeError("private Engine unavailable")
    need(
        run.control_exec(
            "compose-version", "docker", "compose", "version", "--short"
        ).strip()
        == b"2.40.3",
        "Compose version",
    )
    for name in (
        "omne-center",
        "compose.yaml",
        "compose.maintenance.yaml",
        "health.mjs",
    ):
        run.copy("copy-" + name, run.frozen / name, "/usr/local/libexec/" + name)
    run.control_exec("chmod-helper", "chmod", "0755", base.HELPER)
    run.evidence["network"] = {
        "dind_ip": run.dind_ip,
        "mac_loopback_port": run.mac_port,
    }
    run.save()


def cleanup_other_project(run):
    """The helper's second project is owned by this run but not by V0's project filter."""
    errors = []
    second = run.project + "other"
    try:
        if ("container", run.control) not in run.created or (
            "container",
            run.dind,
        ) not in run.created:
            return errors
        found = (
            run.inner(
                "cleanup-other-list",
                "ps",
                "-aq",
                "--no-trunc",
                "--filter",
                f"label=ai.nemori.omne.project={second}",
                cleanup=True,
            )
            .decode()
            .splitlines()
        )
        for index, cid in enumerate(found):
            inspected = json.loads(
                run.inner(
                    f"cleanup-other-inspect-{index}", "inspect", cid, cleanup=True
                )
            )[0]
            need(
                inspected["Id"] == cid
                and inspected["Config"]["Labels"].get("ai.nemori.omne.project")
                == second,
                "second project cleanup identity mismatch",
            )
            run.inner(f"cleanup-other-remove-{index}", "rm", "-f", cid, cleanup=True)
        remaining = run.inner(
            "cleanup-other-final-list",
            "ps",
            "-aq",
            "--no-trunc",
            "--filter",
            f"label=ai.nemori.omne.project={second}",
            cleanup=True,
        )
        need(remaining == b"", "second project residual")
    except Exception as error:
        errors.append(str(error))
    return errors


def import_image(run, base, platform):
    need(
        sha(run.args.image_tar) == run.evidence["inputs"]["sha256"]["image_tar"],
        "image changed",
    )
    run.outer(
        "load-image",
        "exec",
        "-i",
        run.dind,
        "docker",
        "--host",
        base.SOCKET,
        "load",
        stdin=run.args.image_tar,
        timeout=180,
    )
    ids = run.inner(
        "inner-image-list",
        "image",
        "ls",
        "-q",
        "--no-trunc",
        "--filter",
        f"label=ai.nemori.omne.host-build-id={run.args.build_id}",
    )
    lines = sorted(set(ids.decode().splitlines()))
    need(len(lines) == 1 and IMAGE.fullmatch(lines[0]), "inner image ambiguous")
    inner = json.loads(run.inner("inner-image-inspect", "image", "inspect", lines[0]))[
        0
    ]
    outer = json.loads(
        run.outer("outer-product-image", "image", "inspect", run.args.image_id)
    )[0]
    need(
        outer["Id"] == run.args.image_id
        and inner["RootFS"]["Layers"] == outer["RootFS"]["Layers"],
        "image bytes mismatch",
    )
    for image in (inner, outer):
        need(
            image["Os"] == "linux" and image["Architecture"] == platform,
            "image platform",
        )
        need(
            image["Config"]["Labels"]["ai.nemori.omne.host-build-id"]
            == run.args.build_id,
            "image BUILD_ID",
        )
        need(
            image["Config"]["Labels"]["ai.nemori.omne.distribution"]
            == "tenancy-host-docker/1",
            "image distribution",
        )
    run.image_id = lines[0]
    run.evidence["expected"] = {
        "image_id": run.args.image_id,
        "inner_image_id": run.image_id,
        "build_id": run.args.build_id,
        "cli_build_id": run.evidence["inputs"]["cli_build_id"],
        "project": run.project,
        "control": run.control,
        "dind": run.dind,
        "uid": 10001,
        "gid": 10001,
        "state": base.STATE,
        "platform": platform,
    }
    run.save()


def prepare_clients(run, journey):
    base = journey.base
    run.control_exec("linux-node-version", "node", "--version")
    need(
        (run.run / "raw/linux-node-version.stdout").read_bytes() == b"v24.21.0\n",
        "Linux Node",
    )
    run.control_exec("linux-openssl-version", "openssl", "version")
    need(
        b"OpenSSL 3." in (run.run / "raw/linux-openssl-version.stdout").read_bytes(),
        "Linux OpenSSL3",
    )
    run.mac_node = shutil.which("node")
    need(run.mac_node is not None, "Mac Node absent")
    need(
        run.call("mac-node-version", [run.mac_node, "--version"]).strip()
        == b"v24.21.0",
        "Mac Node24.21",
    )
    run.control_exec(
        "mkdir-qa",
        "install",
        "-d",
        "-m",
        "0700",
        "/opt/omne-cross-os",
        LINUX_QA_DIR,
    )
    cli_tar = pathlib.Path(journey.inputs["paths"]["cli_tar"])
    need(sha(cli_tar) == journey.inputs["sha256"]["cli_tar"], "CLI changed")
    frozen_cli = run.frozen / "cli.tar.gz"
    shutil.copyfile(cli_tar, frozen_cli)
    need(sha(frozen_cli) == journey.inputs["sha256"]["cli_tar"], "frozen CLI")
    mac_cli_root = journey.private / "mac-cli"
    mac_cli_root.mkdir(mode=0o700)
    run.call(
        "mac-cli-extract", ["tar", "-xzf", str(frozen_cli), "-C", str(mac_cli_root)]
    )
    run.mac_cli = mac_cli_root / "app/dist/main.js"
    run.outer(
        "copy-linux-cli-tar",
        "cp",
        str(frozen_cli),
        f"{run.control}:{LINUX_QA_DIR}/cli.tar.gz",
    )
    run.control_exec(
        "linux-cli-extract",
        "tar",
        "-xzf",
        LINUX_QA_DIR + "/cli.tar.gz",
        "-C",
        LINUX_QA_DIR,
    )
    need(
        journey.inputs["cli_build_id"].encode()
        in run.call("mac-cli-version", [run.mac_node, str(run.mac_cli), "--version"]),
        "Mac CLI build",
    )
    need(
        journey.inputs["cli_build_id"].encode()
        in run.control_exec(
            "linux-cli-version",
            "node",
            LINUX_CLI,
            "--version",
        ),
        "Linux CLI build",
    )
    # Parent prepares full shared Linux state and fixture-only keys. Reissue a SAN
    # certificate for both actual transport endpoints after the DinD address is known.
    run.control_exec(
        "cross-tls",
        "openssl",
        "req",
        "-x509",
        "-newkey",
        "rsa:2048",
        "-sha256",
        "-nodes",
        "-days",
        "1",
        "-subj",
        "/CN=localhost",
        "-addext",
        f"subjectAltName=DNS:localhost,IP:127.0.0.1,IP:{run.dind_ip}",
        "-keyout",
        base.SECRETS + "/tls-private.pem",
        "-out",
        base.SECRETS + "/tls-chain.pem",
    )
    run.control_exec(
        "cross-tls-owner",
        "chown",
        "10001:10001",
        base.SECRETS + "/tls-private.pem",
        base.SECRETS + "/tls-chain.pem",
    )
    run.control_exec(
        "cross-tls-mode",
        "chmod",
        "0600",
        base.SECRETS + "/tls-private.pem",
        base.SECRETS + "/tls-chain.pem",
    )
    run.control_exec(
        "cross-tls-inspect",
        "openssl",
        "x509",
        "-in",
        base.SECRETS + "/tls-chain.pem",
        "-noout",
        "-ext",
        "subjectAltName",
    )
    run.outer(
        "copy-mac-ca",
        "cp",
        f"{run.control}:{base.SECRETS}/tls-chain.pem",
        str(journey.private / "ca.pem"),
    )
    run.control_exec(
        "decoy-ca",
        "openssl",
        "req",
        "-x509",
        "-newkey",
        "rsa:2048",
        "-sha256",
        "-nodes",
        "-days",
        "1",
        "-subj",
        "/CN=wrong-test-ca",
        "-keyout",
        LINUX_QA_DIR + "/bad-ca.key",
        "-out",
        LINUX_QA_DIR + "/bad-ca.pem",
    )
    run.outer(
        "copy-mac-bad-ca",
        "cp",
        f"{run.control}:{LINUX_QA_DIR}/bad-ca.pem",
        str(journey.private / "bad-ca.pem"),
    )
    run.control_exec(
        "copy-linux-ca",
        "cp",
        base.SECRETS + "/tls-chain.pem",
        LINUX_QA_DIR + "/ca.pem",
    )
    run.evidence["client_paths"] = {
        "mac": str(run.mac_cli),
        "linux": LINUX_CLI,
    }
    run.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--platform", choices=("arm64", "amd64"), required=True)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    inputs = input_set(args.platform)
    if args.print_inputs:
        print(
            json.dumps(
                {
                    "inputs": inputs,
                    "inputs_sha256": hashlib.sha256(canonical(inputs)).hexdigest(),
                },
                sort_keys=True,
            )
        )
        return 0
    need(
        args.execute and args.reviewed_gate is not None,
        "Docker requires --execute and root-reviewed gate",
    )
    return run_platform(args.platform, args.reviewed_gate)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"preflight refused: {error}", file=sys.stderr)
        raise SystemExit(2)
