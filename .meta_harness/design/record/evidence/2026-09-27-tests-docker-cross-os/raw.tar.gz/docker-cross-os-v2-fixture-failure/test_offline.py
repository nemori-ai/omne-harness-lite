#!/usr/bin/env python3
"""Synthetic negative controls for the measurement oracle; no product claim."""

import json
import pathlib
import tempfile

import oracle

HERE = pathlib.Path(__file__).resolve().parent
HOST_BUILD = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
CLI_BUILD = "f38e46f1f169aea8993640c8ccf0ffc42545f2d64adf21f96b6658b2c83bb9f1"
IMAGE_ID = "sha256:" + "a" * 64
INNER_ID = "sha256:" + "b" * 64
FIRST = "c" * 64
SECOND = "d" * 64
OTHER = "e" * 64
CENTER = "f" * 32
PERSONAL_A = {"organization": "personal-a", "account": "account-a"}
PERSONAL_B = {"organization": "personal-b", "account": "account-b"}
TENANT_A = {"organization": "team-a", "account": "account-a"}
TENANT_B = {"organization": "team-b", "account": "account-b"}
BOB_A = {"organization": "team-a", "account": "account-b"}


def report(label):
    value = "ok"
    results = {
        "mac-current-personal": PERSONAL_A,
        "linux-current-personal": PERSONAL_B,
        "mac-create-team-a": "team-a",
        "linux-create-team-b": "team-b",
        "mac-list-isolated": [PERSONAL_A, TENANT_A],
        "linux-list-isolated": [PERSONAL_B, TENANT_B],
        "mac-list-after-restart": [PERSONAL_A, TENANT_A],
        "linux-list-after-restart": [PERSONAL_B, TENANT_B],
        "mac-current-team-a": TENANT_A,
        "linux-current-team-a": BOB_A,
        "mac-current-after-restart": TENANT_A,
        "linux-current-after-restart": BOB_A,
        "mac-invite-bob": "invitation-1",
        "linux-inbox-bob": [{"invitation": "invitation-1"}],
        "linux-member-after-accept": {"standing": "effective", "role": "member"},
        "mac-member-after-restart": {
            "standing": "effective",
            "role": "superAdministrator",
        },
    }
    value = results.get(label, value)
    result = {
        "format": "governance-client/1",
        "admission": {"status": "admitted"},
        "remote": {
            "status": "success",
            "stage": "operation",
            "sendAttempted": True,
            "reply": {"operation": "fixture", "reply": {"result": value}},
        },
        "local": {"status": "not-requested"},
        "view": {"source": "online"},
        "use": "active",
    }
    if label.startswith(("mac-health", "linux-health")) or "configure" in label:
        result["remote"] = {
            "status": "success",
            "stage": "health",
            "sendAttempted": False,
            "health": {"centerId": CENTER, "reachable": True, "version": "2"},
        }
    if label in (
        "linux-not-member-a",
        "linux-admin-after-demote",
        "linux-member-after-leave",
        "linux-member-after-restart",
    ):
        result["remote"] = {
            "status": "rejected",
            "stage": "operation",
            "sendAttempted": True,
            "reply": {"operation": "fixture", "reply": {"failure": "notAuthorized"}},
        }
    if label in ("mac-bad-ca", "linux-bad-ca"):
        result["remote"] = {
            "status": "unavailable",
            "stage": "health",
            "sendAttempted": False,
            "transportFailure": "trust",
        }
        result["view"] = {"source": "none"}
    if label in ("mac-logout", "linux-logout"):
        result["use"] = "ended"
    if label.endswith("after-logout"):
        result["admission"] = {"status": "blocked", "reason": "not-logged-in"}
        result["remote"] = {
            "status": "not-attempted",
            "stage": "none",
            "sendAttempted": False,
        }
        result["view"] = {"source": "none"}
    return result


def write_raw(run, commands, label, payload=b"", returncode=0):
    (run / "raw" / (label + ".stdout")).write_bytes(payload)
    (run / "raw" / (label + ".stderr")).write_bytes(b"")
    commands.append(
        {
            "label": label,
            "stdout": "raw/" + label + ".stdout",
            "stderr": "raw/" + label + ".stderr",
            "returncode": returncode,
            "observation_expired": False,
        }
    )


def jsonline(value):
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def image(image_id):
    return {
        "Id": image_id,
        "Os": "linux",
        "Architecture": "arm64",
        "RootFS": {"Layers": ["sha256:layer"]},
        "Config": {
            "Labels": {
                "ai.nemori.omne.host-build-id": HOST_BUILD,
                "ai.nemori.omne.distribution": "tenancy-host-docker/1",
            }
        },
    }


def center(cid):
    return {
        "Id": cid,
        "Image": INNER_ID,
        "Config": {
            "User": "10001:10001",
            "Labels": {"ai.nemori.omne.host-build-id": HOST_BUILD},
        },
        "State": {"Running": True, "Health": {"Status": "healthy"}},
        "Mounts": [
            {
                "Type": "bind",
                "Source": "/var/lib/omne-tenancy/state",
                "Destination": "/state",
            }
        ],
    }


def build(run):
    (run / "raw").mkdir(parents=True)
    (run / "private").mkdir()
    (run / "private/mac-register-alice.secret").write_bytes(b"synthetic-alice-secret")
    (run / "private/bob-credential.secret").write_bytes(b"synthetic-bob-secret")
    commands = []
    for label in oracle.CLIENT_STEPS:
        value = report(label)
        write_raw(run, commands, label, jsonline(value), oracle.exit_status(value))
    for label in oracle.COMMAND_STEPS:
        if label in {x["label"] for x in commands}:
            continue
        payload = b"observed\n"
        rc = 0
        if label in ("inner-image-inspect", "outer-product-image"):
            payload = json.dumps(
                [image(INNER_ID if label.startswith("inner") else IMAGE_ID)]
            ).encode()
        elif label in ("center-inspect-before", "center-inspect-after"):
            payload = json.dumps(
                [center(FIRST if label.endswith("before") else SECOND)]
            ).encode()
        elif label in ("linux-node-version", "mac-node-version"):
            payload = b"v24.21.0\n"
        elif label.startswith("center-node-"):
            payload = b"v24.21.0\n"
        elif label.startswith("center-pid1-"):
            payload = b"node\n"
        elif label.startswith("center-uid-"):
            payload = b"10001\n"
        elif label == "linux-uname":
            payload = b"Linux\n"
        elif label in ("mac-cli-version", "linux-cli-version"):
            payload = ("omne-cli " + CLI_BUILD + "\n").encode()
        elif label in ("start", "restart"):
            payload = jsonline(
                {
                    "containerId": FIRST if label == "start" else SECOND,
                    "buildId": HOST_BUILD,
                    "health": "healthy",
                }
            )
        elif label in ("stop", "final-stop"):
            payload = jsonline(
                {
                    "state": "stopped",
                    "containerId": FIRST if label == "stop" else SECOND,
                    "exitCode": 0,
                    "clean": True,
                }
            )
        elif label == "first-center-inspect-export":
            payload = json.dumps(
                [{"Id": FIRST, "State": {"Status": "exited", "ExitCode": 0}}]
            ).encode()
        elif label == "final-center-inspect-before-cleanup":
            payload = json.dumps(
                [
                    {
                        "Id": SECOND,
                        "State": {"Status": "exited", "ExitCode": 0, "Running": False},
                    }
                ]
            ).encode()
        elif label == "first-owner-health-after-second":
            payload = jsonline(
                {
                    "reachable": True,
                    "centerId": CENTER,
                    "version": "2",
                    "startedAt": "2026-09-27T00:00:00.000Z",
                    "storageReachable": True,
                    "deploymentKeyPresent": True,
                    "deploymentKeyComplete": True,
                    "clockSane": True,
                    "defectCount": 0,
                    "deploymentParameters": {},
                }
            )
        elif label == "remove-first-center":
            payload = (FIRST + "\n").encode()
        elif label == "second-owner-inspect":
            payload = json.dumps(
                [
                    {
                        "Id": OTHER,
                        "Config": {
                            "Labels": {"ai.nemori.omne.project": "projectother"}
                        },
                        "State": {"Status": "exited", "ExitCode": 1},
                    }
                ]
            ).encode()
        elif label == "second-owner-logs":
            payload = b'{"event":"startup-failed","stage":"occupied"}\n'
        elif label == "second-owner-start":
            rc = 1
        elif label == "tls12-negative":
            payload = b"CONNECTED(00000003)\nNew, (NONE), Cipher is (NONE)\n"
            rc = 1
        write_raw(run, commands, label, payload, rc)
        if label == "tls12-negative":
            (run / "raw/tls12-negative.stderr").write_bytes(
                b"SSL routines:ssl3_read_bytes:tlsv1 alert protocol version\n"
            )
    cleanup = []
    for kind in ("container", "network", "volume"):
        write_raw(run, cleanup, "cleanup-final-list-" + kind)
    for label in (
        "cleanup-other-final-list",
        "cleanup-inner-project-final-list",
        "cleanup-inner-fixture-final-list",
        "cleanup-inner-all-final-list",
    ):
        write_raw(run, cleanup, label)
    evidence = {
        "status": "observed-awaiting-oracle",
        "business_complete": True,
        "host": {"system": "Darwin", "machine": "arm64"},
        "inputs": {
            "platform": "arm64",
            "sha256": {
                "manifest": "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
            },
        },
        "expected": {
            "platform": "arm64",
            "image_id": IMAGE_ID,
            "inner_image_id": INNER_ID,
            "build_id": HOST_BUILD,
            "cli_build_id": CLI_BUILD,
            "state": "/var/lib/omne-tenancy/state",
            "first_center_container": FIRST,
            "second_center_container": SECOND,
            "second_owner_container": OTHER,
            "second_owner_project": "projectother",
        },
        "commands": commands,
        "cleanup_commands": cleanup,
        "cleanup_complete": True,
        "cleanup_errors": [],
        "other_project_cleanup_complete": True,
    }
    (run / "evidence.json").write_text(json.dumps(evidence))
    return evidence


def mutate_json(run, label, mutation):
    path = run / "raw" / (label + ".stdout")
    obj = json.loads(path.read_bytes())
    mutation(obj)
    path.write_bytes(jsonline(obj))


def replace_tls(run, stdout, stderr):
    (run / "raw/tls12-negative.stdout").write_bytes(stdout)
    (run / "raw/tls12-negative.stderr").write_bytes(stderr)


def main():
    controls = {
        "wrong-build": lambda run: mutate_json(
            run,
            "inner-image-inspect",
            lambda x: x[0]["Config"]["Labels"].update(
                {"ai.nemori.omne.host-build-id": "0" * 64}
            ),
        ),
        "wrong-tenant": lambda run: mutate_json(
            run,
            "mac-current-after-restart",
            lambda x: x["remote"]["reply"]["reply"].update({"result": TENANT_B}),
        ),
        "foreign-visible": lambda run: mutate_json(
            run,
            "linux-list-isolated",
            lambda x: x["remote"]["reply"]["reply"]["result"].append(TENANT_A),
        ),
        "foreign-org-own-account": lambda run: mutate_json(
            run,
            "linux-list-after-restart",
            lambda x: x["remote"]["reply"]["reply"]["result"].append(BOB_A),
        ),
        "tls-fallback": lambda run: mutate_json(
            run,
            "mac-bad-ca",
            lambda x: x["remote"].update(
                {"status": "success", "transportFailure": "trust"}
            ),
        ),
        "changed-center-id": lambda run: mutate_json(
            run,
            "linux-health-after",
            lambda x: x["remote"]["health"].update({"centerId": "0" * 32}),
        ),
        "forged-success": lambda run: mutate_json(
            run, "linux-accept", lambda x: x["remote"].update({"status": "rejected"})
        ),
        "missing-command": lambda run: (run / "raw/mac-logout.stdout").unlink(),
        "cleanup-failed": lambda run: (
            run / "raw/cleanup-final-list-container.stdout"
        ).write_bytes(b"residual\n"),
        "secret-leak": lambda run: (run / "raw/second-owner-logs.stdout").write_bytes(
            (run / "raw/second-owner-logs.stdout").read_bytes()
            + b"synthetic-bob-secret\n"
        ),
        "full-health-false": lambda run: mutate_json(
            run,
            "first-owner-health-after-second",
            lambda x: x.update({"storageReachable": False}),
        ),
        "full-health-wrong-center": lambda run: mutate_json(
            run,
            "first-owner-health-after-second",
            lambda x: x.update({"centerId": "0" * 32}),
        ),
        "full-health-defect-positive": lambda run: mutate_json(
            run,
            "first-owner-health-after-second",
            lambda x: x.update({"defectCount": 1}),
        ),
        "full-health-defect-false": lambda run: mutate_json(
            run,
            "first-owner-health-after-second",
            lambda x: x.update({"defectCount": False}),
        ),
        "full-health-rc0-only": lambda run: (
            run / "raw/first-owner-health-after-second.stdout"
        ).write_bytes(jsonline({"reachable": True})),
        "tls-connect-failed": lambda run: replace_tls(
            run, b"", b"connect: Connection refused\n"
        ),
        "tls-negotiated-eof": lambda run: replace_tls(
            run,
            b"CONNECTED(00000003)\nNew, TLSv1.2, Cipher is ECDHE-RSA-AES256-GCM-SHA384\n",
            b"unexpected eof while reading\n",
        ),
        "tls-negotiated-with-alert": lambda run: replace_tls(
            run,
            b"CONNECTED(00000003)\nNew, TLSv1.2, Cipher is ECDHE-RSA-AES256-GCM-SHA384\n",
            b"SSL routines:ssl3_read_bytes:tlsv1 alert protocol version\n",
        ),
        "final-inspect-wrong-id": lambda run: mutate_json(
            run,
            "final-center-inspect-before-cleanup",
            lambda x: x[0].update({"Id": FIRST}),
        ),
        "final-inspect-running": lambda run: mutate_json(
            run,
            "final-center-inspect-before-cleanup",
            lambda x: x[0]["State"].update({"Running": True}),
        ),
        "final-inspect-exit1": lambda run: mutate_json(
            run,
            "final-center-inspect-before-cleanup",
            lambda x: x[0]["State"].update({"ExitCode": 1}),
        ),
    }
    expected_reasons = {
        "foreign-org-own-account": "foreign organization/account visible",
        "full-health-false": "unhealthy storageReachable",
        "full-health-wrong-center": "defects/centerId",
        "full-health-rc0-only": "EC3 S-26 field set",
        "tls-connect-failed": "TLS1.2 peer protocol-version rejection not established",
        "tls-negotiated-eof": "TLS1.2 peer protocol-version rejection not established",
        "tls-negotiated-with-alert": "TLS1.2 peer protocol-version rejection not established",
        "final-inspect-wrong-id": "final center actual terminal state before cleanup",
        "final-inspect-running": "final center actual terminal state before cleanup",
        "final-inspect-exit1": "final center actual terminal state before cleanup",
        "full-health-defect-positive": "defects/centerId",
        "full-health-defect-false": "defects/centerId",
    }
    for field in (
        "reachable",
        "deploymentKeyPresent",
        "deploymentKeyComplete",
        "clockSane",
    ):
        name = "full-health-" + field + "-false"
        controls[name] = lambda run, key=field: mutate_json(
            run,
            "first-owner-health-after-second",
            lambda x: x.update({key: False}),
        )
        expected_reasons[name] = "unhealthy " + field
    result = {"baseline": "", "tls_none_peer_alert": "", "detected": [], "missed": []}
    with tempfile.TemporaryDirectory(prefix="offline-", dir=HERE) as temp:
        root = pathlib.Path(temp)
        baseline = root / "baseline"
        build(baseline)
        result["baseline"] = oracle.check(baseline)["status"]
        none_cipher = root / "tls-none-peer-alert"
        build(none_cipher)
        replace_tls(
            none_cipher,
            b"CONNECTED(00000003)\nNew, TLSv1.2, Cipher is (NONE)\n",
            b"SSL routines:ssl3_read_bytes:tlsv1 alert protocol version\n",
        )
        result["tls_none_peer_alert"] = oracle.check(none_cipher)["status"]
        for name, mutation in controls.items():
            case = root / name
            build(case)
            mutation(case)
            try:
                oracle.check(case)
            except (
                AssertionError,
                FileNotFoundError,
                ValueError,
                KeyError,
                TypeError,
            ) as error:
                if name in expected_reasons and expected_reasons[name] not in str(
                    error
                ):
                    result["missed"].append(name + ":wrong-reason:" + str(error))
                else:
                    result["detected"].append(name)
            else:
                result["missed"].append(name)
    result["scope"] = (
        "synthetic oracle negative controls; no Docker or product execution"
    )
    (HERE / "offline-result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(result, sort_keys=True))
    if (
        result["baseline"] != "PASS"
        or result["tls_none_peer_alert"] != "PASS"
        or result["missed"]
    ):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
