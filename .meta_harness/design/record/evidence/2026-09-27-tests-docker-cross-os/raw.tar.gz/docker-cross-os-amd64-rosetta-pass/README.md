# M0 DK-I2 / DK-I4 跨 OS 独立验收准备 · v5 Rosetta 仿真测量适配

状态：**v5 只做静态准备与离线检查，尚未实跑。**v4 arm64 单次真实运行 `tmp/docker-cross-os-v4/runs/20260926T211436Z-392c69a5/` 的冻结 oracle 为 PASS，非私有 420 件清单 SHA256 `112c2f0eff3be4c905a71c356781f42d8ae35b110ca4e1bf5846df13771ab384`。v4 amd64 在 arm64 Mac 宿主仿真下的单次运行 `tmp/docker-cross-os-v4/runs/20260926T212021Z-3e766912/` 走完业务与清理，但原严格 PID1 oracle 因 `/proc/1/exe=/run/rosetta/rosetta` 返回 FAIL；非私有 828 件清单 SHA256 `7ab6cab0816df37f0dc0c8704b016ee0bceb07a8b269248df472899f9fced0bd`。两份原结果、工具、raw/frozen 和资源反查均保持原样。v5 只为这个精确仿真环境新增具名观测，不把它改称原生 amd64 或把原失败翻为通过。本目录为指定 spoke 新建的 ignored 临时材料，本工具没有最终验收权。

## 输入与冻结边界

- 执行仓库：`/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-cross-os`，branch `pandazki/agent-work-loop-docker-cross-os`，HEAD `f8f286c95cb9458fe3173190edbeab6076339b08`。仅写本目录。施工计划为 HUB `tmp/next-iteration/tasks/docker-delivery.md` 的 V0、I3 与 DK-I2/I4。
- 设计工作区为本执行仓库 `.meta_harness`。采用范围：PF-016/PF-017 现行投影；`composition.governance-cli-entry/v2`、`composition.governance-client-operations/v2`、`composition.governance-center-entry/v3`、`composition.governance-center-entry-https-json/v3`，EC3 明列消费的 `capability.account-identity/v3` 与 `capability.organization-governance/v2`。精确状态/决定见 `design/registry/catalog.json` 各坐标与 D-050、D-055～D-057、D-070 Docker R4、D-071 R5。映射消费 `design/realization/apps/tenancy-host/{docker,maintenance-binding,packaging}.md` 与 `design/realization/apps/cli/{governance,packaging}.md`，其中 Docker R5 文件 SHA256 `3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223`。
- 最终 I3 manifest：`/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery/tmp/docker-delivery/i3-f8f286c9/manifest-delivery.json`，SHA256 `c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e`。预检逐件核该清单中的 host/CLI BUILD_ID、CLI tar、对应架构 image tar 与六项部署文件 SHA；实际私有 daemon 内导入后再核镜像层、arch、labels 与实际运行身份。该 manifest 的独立归档 inventory 核验由 root 已完成，测量器不以标签取代归档审核。
- 只读复用 V0 固定控制输入与 `r5-helper-prep/driver.py`，后者 SHA256 `a450179ed522b8ab2033f0aa368c5d4ad3fe43139353b9d14d24afb01915da26`。复用其唯一资源命名、原始命令日志、私有 DinD 数据路径、inode/UID 三视角比较与 exact-label 清理；本脚本拥有跨 OS 端口与旅程。旧 `oracle.py` 没被复用，尤其不要求 restore target 的 marker。

静态输入快照分别是 `arm64-inputs.json` 与 `amd64-inputs.json`；运行前应重新生成并比较。v5 仅待 root 单独审定 amd64 仿真 gate，原生 amd64 CPU 未测。控制容器本身为固定 Linux arm64 systemd/Node24.21/OpenSSL3 镜像；私有 Engine/CLI 为29.1.3，Compose为2.40.3。Mac 侧必须在 `fnm exec --using=24.21.0` 环境下运行，以确保本地 `node` 精确版本；root 实际命令还设置 `TMPDIR=/private/tmp`。任一缓存镜像、工具或制品缺失/哈希不符即拒绝，不拉取替代项。

## 真实测量路径及通过条件

`driver.py` 从 root Linux control 容器调用正式 `omne-center`，只把私有 DinD socket 以 named volume 共享给 control，用户主 Docker socket 不进入控制容器。外层只有本轮唯一 label 的 control、DinD、三个卷、一个网络；DinD 的 `18443/tcp` 外层只发布到 Mac `127.0.0.1` 的 Engine 分配临时端口。内层 center 把端口发布到 DinD 的私网 IP，Linux CLI 从 control 容器访问该 IP；Mac CLI 访问回环端口。两段 NAT 只转 TCP，TLS 始终由正式 center 终结。一次性证书 SAN 覆盖 `127.0.0.1` 与实际 DinD IP；Mac/Linux 各以该 CA、真实 Node24.21 运行 I3 CLI 制品。伪 CA 配置须返回 `transportFailure=trust` 且未发送目标操作，OpenSSL3 的 TLS1.2 握手须失败。

v2 修复的控制容器路径在 v5 沿用：Linux QA tar、解压目录、CLI 状态、payload/凭据文件、测试 CA 与 decoy CA 一律位于常规 rootfs 的 `/opt/omne-cross-os/private`（祖先和该目录 0700；输入文件由 0077 umask 创建）。

v3 的显式夹具政策和 Linux `-json`/`-secret` 独立原始标签也沿用。夹具政策仅为 `OMNE_TENANCY_CREDENTIAL_POLICY={"minLength":12}`，在 `prepare_paths()` 后、helper validate/start 前写进实际 settings 并原样读回；这不是生产默认。

v4 的日志、logout、TLS、身份隔离、重建和治理判据在 v5 保持。arm64 仍要求 `/proc/1/exe=/usr/local/bin/node`、cmdline 精确 `node /opt/omne/app/dist/cli.js serve`。amd64 仅在已观察到的 Rosetta 仿真条件下，要求前后各容器 `/proc/1/exe=/run/rosetta/rosetta`、NUL 分隔 cmdline 精确 `node --no-opt -r /proc/.reset /opt/omne/app/dist/cli.js serve`；同时保留 image RootFS/arch/BUILD_ID、center Config.Entrypoint/Cmd/Path/Args、UID10001 与 Node24.21 原判据。新增从外部 `docker exec` 对目标 PID1 读 `/proc/1/maps` 和 `/proc/1/status`，要求同一 PID1 映射中同时有 `/usr/local/bin/node` 与 Rosetta 的可执行段、真实 UID 四列均为10001；另读 Node 文件并核 SHA256 `7fde7b8afa198da66257f42ee2001d874c7355631e6d1579a5fb5ef1f246df4c`、ELF magic 与 machine=62、运行时 x64/Linux/Node24.21/UID10001。`/proc/.reset` 原字节单独保存，摘要须等于 `86c6676bd07477697e8aed12348041dc1ef6bdeee70bdd4d346dd1ce2e27aacd`。未知 qemu、flag、shim 或映射均拒绝；这是仿真观测，不证明原生运行。

精确 Rosetta 形态来自 root 的固定最终 amd64 image 只读探针 `/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/tmp/next-iteration/docker-rosetta-readout/`（`probe.cjs` SHA256 `4abee201d0d93ad1a98dd15588fda6519e0cb49d87a568c7cd1089b1e205da64`、`stdout` SHA256 `c291a5f166d834e748dcc08067aa90c84f083ebdfc53a378570693447c95c27f`）和 v4 amd64 实跑 raw，不来自一般平台文档。`v4-amd64-counterfactual-diagnostic.json` 只在内存补入 v4 未采的八个新探针走查其余 oracle；它不是实跑或通过证据。

| 场景 | 直接判据（均由 `oracle.py` 从原始输出重读） | 来源 |
| --- | --- | --- |
| DK-I2 每架构真实 image | 导入私有 Engine 的层、OS/arch、BUILD_ID 对 I3；真实中心容器保持指定 `serve` 入口、UID10001、Node24.21、health=healthy、同一 `/state` bind；arm64 保持原 Node PID1 exe/cmdline 判据，amd64 只按上段的具名 Rosetta 仿真证据另核，并记录宿主 CPU/模拟范围 | Docker R5「输入、目录、镜像身份」、I3 manifest、计划 DK-I2 |
| DK-I4 两系统同中心 | Mac 注册/登录 Alice，Linux 注册/登录 Bob；各建团队，初始及重建后租户列表每项的账号必须等于调用者账号，且不得出现对方组织下本账号的身份；Bob 退出 A 后列表仍不得再含 A；Bob 对 A 团队成员读被拒；Alice 切身份邀 Bob，Bob 收邀请并接受、切身份，成员读有效；Alice 升/降 Bob 角色，Bob 的超管读随之可用/拒绝；Bob 退出团队后读被拒 | AI3、OG2 S-21/25/26/27/28/29/36/37/57/60，EC3 S-15/16/17/22/23，CQ2 S-13～15 |
| DK-I4 重建与排他 | helper `stop` 的同 ID `clean=true,exitCode=0`，另以真实 inspect 核 exited/0；完整导出旧 logs/inspect 后只对该 ID `docker rm`，同 STATE 重建，容器 ID 必变；四次 Mac/Linux health 的 centerId 必同且合法，两个团队及各自选择/成员事实仍可现读。同库第二项目确实创建实际 center 容器并因 `occupied` 启动失败；原中心 `full-health` 的五个健康布尔须全部为 true，defectCount 为整数 0，centerId 等于客户端已观测值。最终 stop 后、fixture cleanup 前，另存同 ID 真实 inspect 并核 exited/0/Running=false | EC3 S-26～28 与停机承诺、Docker R5 停止/属主、计划 DK-I4 |
| DK-I4 TLS/退出 | 两系统错误 CA 都拒绝且不降级；TLS1.2 负例须由 OpenSSL3 原 stderr 显示 peer `alert protocol version`，并以有效 cipher 排除已协商成功，不能把连接失败或成功握手后的 EOF 当成拒绝；两系统成功 logout 即时需重进，下一次治理读均阻断且不发目标请求 | HT3 S-4/30、CQ1 S-6、CG2 S-15、CQ2 S-9.5、AI3 S-16 |
| 工具收场 | 每条命令原字节 stdout、stderr、退出码与 argv 单独落盘；伪造成功/漏命令不能通过；测试凭据不出现在任何原始输出/元数据；第二项目与内外资源按精确 label 清理、最终各集合为空 | 计划「独立 oracle」、V0 资源纪律 |

`driver.py` 的 `runs/<run-id>/raw/` 是每步原始输出，`evidence.json` 记录时间、argv、真实退出/观察超时、资源及清理；`private/` 0700 保存一次性测试输入。未知业务写入不会自动重试。`oracle.py` 以返回身份、列表和成员事实、真实镜像/容器 inspect、停止终态、TLS 错误与 exact-label 空查询判断；单独 rc0、helper 自报、回调调用均不够。每轮应用容器和私有环境的实际退出、残余及诊断应在 root 保全后再考虑退休 spoke。

## 离线复核及后续运行门

已执行（均在指定 spoke，未触碰 Docker）：

```text
python3 -B -m py_compile tmp/docker-cross-os-v5/{driver,oracle,test_offline}.py
black --check tmp/docker-cross-os-v5/{driver,oracle,test_offline}.py
python3 -B tmp/docker-cross-os-v5/test_offline.py
TMPDIR=/private/tmp fnm exec --using=24.21.0 -- python3 -B tmp/docker-cross-os-v5/driver.py --platform arm64 --print-inputs > tmp/docker-cross-os-v5/arm64-inputs.json
TMPDIR=/private/tmp fnm exec --using=24.21.0 -- python3 -B tmp/docker-cross-os-v5/driver.py --platform amd64 --print-inputs > tmp/docker-cross-os-v5/amd64-inputs.json
TMPDIR=/private/tmp fnm exec --using=24.21.0 -- python3 -B tmp/docker-cross-os-v5/driver.py --platform amd64 --execute
```

`offline-result.json`：arm64 原基线、amd64 Rosetta 合成基线、仅 stdout 产品日志正例均 PASS；原 40 项负控及新增 13 项仿真负控全检出，0 漏检；另有 `Cipher is (NONE)` 加 peer alert 的合成合法解析边界 PASS。后者不是实际 OpenSSL 输出观测。无 gate 时退出 2。v5 不复用 v4 的 arm64 或 amd64 gate，不把旧 amd64 失败改写为通过。

root 实际放行时，每个平台重新运行 `--print-inputs`，核 `inputs_sha256`、本目录 driver/oracle SHA、I3 manifest/制品与外层固定 image/tool 缓存；随后由 root 为该平台写一份私有 `reviewed-gate-<platform>.json`，内容严格为：

```json
{"approved":true,"reviewer":"root","inputs_sha256":"<该平台 print-inputs 值>","driver_sha256":"<inputs.sha256.driver>","oracle_sha256":"<inputs.sha256.oracle>"}
```

再在 `TMPDIR=/private/tmp` 与 `fnm exec --using=24.21.0` 下执行 `python3 -B tmp/docker-cross-os-v5/driver.py --platform amd64 --reviewed-gate <新 gate 的绝对路径> --execute`。任一输入或代码变化使 gate 失效。运行会冻结 helper 与 oracle、生成唯一 run，最后自动调用冻结 oracle 并打印 run 位置及结果；实际执行需要 root 另审定命令与副作用。此目录没有 gate 文件，也未获 v5 实跑放行。

## 未覆盖

DK-I3 的安装负控、DK-I5 在线并发备份/验证/隔离恢复、DK-I6 IO 门和关闭错误、DK-I7 daemon 故障、DK-I8 timer、DK-I9 升级、DK-I10 客户端失联由各自任务承担。本工具未做 I5 并发；可复用 `Journey.go()` 两账号登录且团队已确认之后、stop 之前的同一私有环境，但需另一个能分别记录两个进程原始开始/结束和真实交叠的测量器，且不能要求快照必含最后写。未测公司 DNS/CA、真实人员或生产密钥、裸机断电耐久、原生 amd64 CPU、CLI TUI 人读。有限离线负控不证明正式 I3 产品或两架构运行通过。
