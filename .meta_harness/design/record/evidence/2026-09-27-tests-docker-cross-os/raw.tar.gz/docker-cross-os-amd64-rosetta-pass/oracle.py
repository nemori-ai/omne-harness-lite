#!/usr/bin/env python3
"""Independent raw-output oracle for one DK-I2/I4 platform run."""

import hashlib
import json
import pathlib
import re
import sys

HEX32 = re.compile(r"[0-9a-f]{32}\Z")
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
CENTER_ENTRYPOINT = ["node", "/opt/omne/app/dist/cli.js"]
CENTER_CMD = ["serve"]
CENTER_EXE = b"/usr/local/bin/node\n"
CENTER_CMDLINE = (
    b"\x00".join(part.encode() for part in (*CENTER_ENTRYPOINT, *CENTER_CMD)) + b"\x00"
)
ROSETTA_EXE = b"/run/rosetta/rosetta\n"
ROSETTA_CMDLINE = (
    b"node\x00--no-opt\x00-r\x00/proc/.reset\x00"
    b"/opt/omne/app/dist/cli.js\x00serve\x00"
)
ROSETTA_NODE_SHA256 = "7fde7b8afa198da66257f42ee2001d874c7355631e6d1579a5fb5ef1f246df4c"
ROSETTA_RESET_SHA256 = (
    "86c6676bd07477697e8aed12348041dc1ef6bdeee70bdd4d346dd1ce2e27aacd"
)
ROSETTA_RESET_BYTES = b"const p=require('process');p.execArgv=p.execArgv.slice(3)\n"
ROSETTA_NODE_PROBE_SHA256 = (
    "7f69b759f2d5f5541dda1b523a14450f34eb07e60cc5e9bf307208a80601efe4"
)
CLIENT_STEPS = (
    "mac-configure-alice",
    "linux-configure-bob",
    "mac-health-before",
    "linux-health-before",
    "mac-register-alice",
    "linux-register-bob",
    "mac-login-alice",
    "linux-login-bob",
    "mac-current-personal",
    "linux-current-personal",
    "mac-create-team-a",
    "linux-create-team-b",
    "mac-list-isolated",
    "linux-list-isolated",
    "linux-not-member-a",
    "mac-switch-team-a",
    "mac-current-team-a",
    "mac-invite-bob",
    "linux-inbox-bob",
    "linux-accept",
    "linux-switch-team-a",
    "linux-current-team-a",
    "linux-member-after-accept",
    "mac-promote-bob",
    "linux-admin-after-promote",
    "mac-demote-bob",
    "linux-admin-after-demote",
    "linux-leave-team-a",
    "linux-member-after-leave",
    "mac-bad-ca",
    "linux-bad-ca",
    "mac-health-after",
    "linux-health-after",
    "mac-current-after-restart",
    "linux-current-after-restart",
    "mac-list-after-restart",
    "linux-list-after-restart",
    "mac-member-after-restart",
    "linux-member-after-restart",
    "mac-logout",
    "linux-logout",
    "mac-after-logout",
    "linux-after-logout",
)
COMMAND_STEPS = (
    "load-image",
    "inner-image-inspect",
    "outer-product-image",
    "control-uid",
    "control-pid1",
    "linux-uname",
    "linux-node-version",
    "linux-openssl-version",
    "mac-node-version",
    "mac-cli-version",
    "linux-cli-version",
    "center-inspect-before",
    "center-inspect-after",
    "center-pid1-before",
    "center-pid1-after",
    "center-exe-before",
    "center-exe-after",
    "center-cmdline-before",
    "center-cmdline-after",
    "center-uid-before",
    "center-uid-after",
    "center-node-before",
    "center-node-after",
    "validate",
    "start",
    "tls12-negative",
    "second-owner-validate",
    "second-owner-start",
    "first-owner-health-after-second",
    "second-owner-ps",
    "second-owner-inspect",
    "second-owner-logs",
    "stop",
    "first-center-logs-export",
    "first-center-inspect-export",
    "remove-first-center",
    "restart",
    "final-stop",
    "final-center-inspect-before-cleanup",
)
ROSETTA_STEPS = (
    "center-maps-before",
    "center-status-before",
    "center-reset-before",
    "center-node-elf-before",
    "center-maps-after",
    "center-status-after",
    "center-reset-after",
    "center-node-elf-after",
)


def need(test, message):
    if not test:
        raise AssertionError(message)


def one_json(raw, label):
    need(raw.endswith(b"\n") and raw.count(b"\n") == 1, label + " must be one JSON+LF")
    return json.loads(raw[:-1].decode("utf-8", "strict"))


def command_map(evidence):
    commands = evidence.get("commands", [])
    labels = [item.get("label") for item in commands]
    need(len(labels) == len(set(labels)), "duplicate command labels")
    return {item["label"]: item for item in commands}


def raw_for(run, commands, label, stream="stdout"):
    need(label in commands, "missing command " + label)
    item = commands[label]
    need(
        item.get("observation_expired") is False and item.get("returncode") is not None,
        label + " incomplete observation",
    )
    path = item.get(stream)
    need(path == f"raw/{label}.{stream}", label + " raw path mismatch")
    target = run / path
    need(target.is_file(), label + " missing raw stream")
    return target.read_bytes()


def exit_status(report):
    if (
        report.get("defect") is not None
        or report.get("local", {}).get("status") == "defect"
        or report.get("admission", {}).get("reason") == "defect"
    ):
        return 70
    if report.get("local", {}).get("status") in (
        "conflict",
        "not-installed",
        "unconfirmed",
    ):
        return 5
    if report.get("remote", {}).get("status") == "unknown" or (
        report.get("remote", {}).get("status") == "unavailable"
        and report.get("view", {}).get("source") != "copy"
    ):
        return 3
    if (
        report.get("remote", {}).get("status") == "rejected"
        or report.get("use") == "reenter-required"
        or report.get("admission", {}).get("reason") == "not-logged-in"
    ):
        return 4
    if report.get("admission", {}).get("status") == "blocked":
        return (
            3 if report.get("admission", {}).get("reason") == "local-unavailable" else 2
        )
    return 0


def check_cli(run, commands):
    reports = {}
    for label in CLIENT_STEPS:
        report = one_json(raw_for(run, commands, label), label)
        need(
            isinstance(report, dict) and report.get("format") == "governance-client/1",
            label + " report",
        )
        need(
            report.get("defect") is None
            and commands[label]["returncode"] == exit_status(report),
            label + " exit/report mismatch",
        )
        need(
            report.get("view", {}).get("source") != "copy",
            label + " stale cache is not live oracle",
        )
        reports[label] = report
    for label in CLIENT_STEPS:
        report = reports[label]
        if label in ("mac-bad-ca", "linux-bad-ca"):
            remote = report["remote"]
            need(
                remote
                == {
                    "status": "unavailable",
                    "stage": "health",
                    "sendAttempted": False,
                    "transportFailure": "trust",
                },
                label + " TLS failure did not stop request",
            )
        elif label.endswith("after-logout"):
            need(
                report["admission"] == {"status": "blocked", "reason": "not-logged-in"}
                and report["remote"]
                == {"status": "not-attempted", "stage": "none", "sendAttempted": False}
                and report["local"] == {"status": "not-requested"}
                and report["view"]["source"] == "none"
                and report["use"] == "ended"
                and commands[label]["returncode"] == 4,
                label + " logout not enforced",
            )
        elif label in ("mac-logout", "linux-logout"):
            need(
                report["admission"]["status"] == "admitted"
                and report["remote"]
                == {
                    "status": "success",
                    "stage": "operation",
                    "sendAttempted": True,
                    "reply": {
                        "operation": "capability.account-identity/v3#S-16",
                        "reply": {"result": "ok"},
                    },
                }
                and report["local"]["status"] == "installed"
                and report["use"] == "reenter-required"
                and commands[label]["returncode"] == 4,
                label + " logout result",
            )
        elif label in (
            "linux-not-member-a",
            "linux-admin-after-demote",
            "linux-member-after-leave",
            "linux-member-after-restart",
        ):
            need(
                report["remote"]["status"] == "rejected"
                and report["remote"].get("reply", {}).get("reply")
                == {"failure": "notAuthorized"},
                label + " cross-tenant/admin rejection",
            )
        else:
            need(
                report["remote"]["status"] == "success"
                and report["admission"]["status"] == "admitted"
                and report["local"]["status"]
                not in ("conflict", "not-installed", "unconfirmed", "defect"),
                label + " not confirmed",
            )
    healths = [
        reports[label]["remote"]["health"]["centerId"]
        for label in (
            "mac-health-before",
            "linux-health-before",
            "mac-health-after",
            "linux-health-after",
        )
    ]
    need(
        all(HEX32.fullmatch(value) for value in healths) and len(set(healths)) == 1,
        "centerId changed across OS/rebuild",
    )

    def result(label):
        return reports[label]["remote"]["reply"]["reply"]["result"]

    personal_a, personal_b = result("mac-current-personal"), result(
        "linux-current-personal"
    )
    team_a, team_b = result("mac-create-team-a"), result("linux-create-team-b")
    need(
        isinstance(personal_a, dict)
        and isinstance(personal_b, dict)
        and personal_a.get("account") != personal_b.get("account")
        and isinstance(team_a, str)
        and isinstance(team_b, str)
        and team_a != team_b,
        "two distinct account/team identities",
    )
    tenant_a = {"organization": team_a, "account": personal_a["account"]}
    tenant_b = {"organization": team_b, "account": personal_b["account"]}
    bob_a = {"organization": team_a, "account": personal_b["account"]}
    need(personal_a != personal_b and tenant_a != tenant_b, "tenant separation")
    for label, own, foreign_organization in (
        ("mac-list-isolated", tenant_a, team_b),
        ("linux-list-isolated", tenant_b, team_a),
        ("mac-list-after-restart", tenant_a, team_b),
        ("linux-list-after-restart", tenant_b, team_a),
    ):
        listing = result(label)
        need(
            isinstance(listing, list)
            and own in listing
            and all(
                isinstance(row, dict)
                and set(row) == {"organization", "account"}
                and row["account"] == own["account"]
                and row["organization"] != foreign_organization
                for row in listing
            ),
            label
            + " own confirmed tenant absent or foreign organization/account visible",
        )
    invitation = result("mac-invite-bob")
    need(isinstance(invitation, str) and invitation, "invitation ID")
    need(
        invitation in json.dumps(result("linux-inbox-bob")),
        "invitation not observed by recipient",
    )
    need(
        result("mac-switch-team-a") == result("linux-switch-team-a") == "ok",
        "identity switch result",
    )
    for label, tenant in (
        ("mac-current-team-a", tenant_a),
        ("linux-current-team-a", bob_a),
        ("mac-current-after-restart", tenant_a),
        ("linux-current-after-restart", bob_a),
    ):
        need(result(label) == tenant, label + " selected identity not durable")
    need(
        result("linux-member-after-accept")
        == {"standing": "effective", "role": "member"},
        "acceptance not reflected in membership",
    )
    need(
        result("mac-member-after-restart")
        == {"standing": "effective", "role": "superAdministrator"},
        "owner membership not durable",
    )
    return {
        "centerId": healths[0],
        "teamA": team_a,
        "teamB": team_b,
        "tenantA": tenant_a,
        "tenantB": tenant_b,
        "bobA": bob_a,
    }


def executable_map(raw, path):
    for line in raw.decode("utf-8", "strict").splitlines():
        parts = line.split(maxsplit=5)
        if len(parts) == 6 and "x" in parts[1] and parts[5] == path:
            return True
    return False


def check_rosetta(run, commands, expected, moment):
    cid = expected[
        "first_center_container" if moment == "before" else "second_center_container"
    ]
    paths = {
        "maps": "/proc/1/maps",
        "status": "/proc/1/status",
        "reset": "/proc/.reset",
    }
    for kind, path in paths.items():
        label = "center-" + kind + "-" + moment
        need(
            commands[label]["returncode"] == 0
            and commands[label].get("argv", [])[-4:] == ["exec", cid, "cat", path],
            label + " not a successful target PID1 read",
        )
    probe_label = "center-node-elf-" + moment
    probe_argv = commands[probe_label].get("argv", [])
    need(
        commands[probe_label]["returncode"] == 0
        and probe_argv[-5:-1] == ["exec", cid, "node", "-e"]
        and len(probe_argv) >= 5
        and hashlib.sha256(probe_argv[-1].encode()).hexdigest()
        == ROSETTA_NODE_PROBE_SHA256,
        probe_label + " not the reviewed read-only probe",
    )
    maps = raw_for(run, commands, "center-maps-" + moment)
    need(
        executable_map(maps, "/usr/local/bin/node"),
        "Rosetta target lacks executable Node map " + moment,
    )
    need(
        executable_map(maps, "/run/rosetta/rosetta"),
        "Rosetta target lacks executable translator map " + moment,
    )
    status = raw_for(run, commands, "center-status-" + moment)
    uid_lines = [
        line.split() for line in status.splitlines() if line.startswith(b"Uid:")
    ]
    need(
        uid_lines == [[b"Uid:", b"10001", b"10001", b"10001", b"10001"]],
        "Rosetta target PID1 UID differs " + moment,
    )
    reset = raw_for(run, commands, "center-reset-" + moment)
    need(
        reset == ROSETTA_RESET_BYTES
        and hashlib.sha256(reset).hexdigest() == ROSETTA_RESET_SHA256,
        "Rosetta reset source differs " + moment,
    )
    node = one_json(raw_for(run, commands, probe_label), probe_label)
    need(
        node
        == {
            "arch": "x64",
            "platform": "linux",
            "execPath": "/usr/local/bin/node",
            "version": "v24.21.0",
            "uid": 10001,
            "nodeSha256": ROSETTA_NODE_SHA256,
            "elfMagic": "7f454c46",
            "elfMachine": 62,
        },
        "Rosetta mapped Node binary/runtime differs " + moment,
    )


def check_images(run, commands, expected):
    inner = json.loads(raw_for(run, commands, "inner-image-inspect"))[0]
    outer = json.loads(raw_for(run, commands, "outer-product-image"))[0]
    for image in (inner, outer):
        need(
            image["Os"] == "linux" and image["Architecture"] == expected["platform"],
            "wrong image architecture",
        )
        need(
            image["Config"]["Labels"]["ai.nemori.omne.host-build-id"]
            == expected["build_id"],
            "wrong image BUILD_ID",
        )
        need(
            image["Config"]["Labels"]["ai.nemori.omne.distribution"]
            == "tenancy-host-docker/1",
            "wrong image distribution",
        )
    need(
        outer["Id"] == expected["image_id"]
        and inner["Id"] == expected["inner_image_id"]
        and outer["RootFS"]["Layers"] == inner["RootFS"]["Layers"],
        "image mismatch",
    )
    for label in ("center-inspect-before", "center-inspect-after"):
        center = json.loads(raw_for(run, commands, label))[0]
        need(
            center["Image"] == expected["inner_image_id"]
            and center["Config"]["Labels"]["ai.nemori.omne.host-build-id"]
            == expected["build_id"]
            and center["Config"]["User"] == "10001:10001"
            and center["State"]["Running"] is True
            and center["State"]["Health"]["Status"] == "healthy",
            label + " product identity/health",
        )
        need(
            any(
                m["Type"] == "bind"
                and m["Source"] == expected["state"]
                and m["Destination"] == "/state"
                for m in center["Mounts"]
            ),
            label + " real state mount",
        )
        need(
            center["Config"]["Entrypoint"] == CENTER_ENTRYPOINT
            and center["Config"]["Cmd"] == CENTER_CMD
            and center["Path"] == CENTER_ENTRYPOINT[0]
            and center["Args"] == CENTER_ENTRYPOINT[1:] + CENTER_CMD,
            label + " configured entrypoint/argv differs",
        )
    for moment in ("before", "after"):
        if expected["platform"] == "amd64":
            need(
                raw_for(run, commands, "center-exe-" + moment) == ROSETTA_EXE,
                "unexpected amd64 translator executable " + moment,
            )
            need(
                raw_for(run, commands, "center-cmdline-" + moment) == ROSETTA_CMDLINE,
                "unexpected amd64 translator argv " + moment,
            )
            check_rosetta(run, commands, expected, moment)
        else:
            need(
                raw_for(run, commands, "center-exe-" + moment) == CENTER_EXE,
                "actual center PID1 executable differs " + moment,
            )
            need(
                raw_for(run, commands, "center-cmdline-" + moment) == CENTER_CMDLINE,
                "actual center PID1 argv differs " + moment,
            )
        need(
            raw_for(run, commands, "center-uid-" + moment) == b"10001\n"
            and raw_for(run, commands, "center-node-" + moment) == b"v24.21.0\n",
            "actual center UID/Node differs " + moment,
        )
    need(
        raw_for(run, commands, "linux-node-version") == b"v24.21.0\n"
        and raw_for(run, commands, "mac-node-version") == b"v24.21.0\n",
        "Node24.21 client",
    )
    need(raw_for(run, commands, "linux-uname") == b"Linux\n", "Linux CLI control OS")
    for label in ("linux-cli-version", "mac-cli-version"):
        need(
            expected["cli_build_id"].encode() in raw_for(run, commands, label),
            label + " wrong CLI BUILD_ID",
        )


def check_full_health(run, commands, label, center_id):
    need(commands[label]["returncode"] == 0, label + " command failed")
    health = one_json(raw_for(run, commands, label), label)
    need(isinstance(health, dict), label + " must return an object")
    need(
        set(health)
        == {
            "reachable",
            "centerId",
            "version",
            "startedAt",
            "storageReachable",
            "deploymentKeyPresent",
            "deploymentKeyComplete",
            "clockSane",
            "defectCount",
            "deploymentParameters",
        },
        label + " EC3 S-26 field set",
    )
    for key in (
        "reachable",
        "storageReachable",
        "deploymentKeyPresent",
        "deploymentKeyComplete",
        "clockSane",
    ):
        need(health[key] is True, label + " unhealthy " + key)
    need(
        type(health["defectCount"]) is int
        and health["defectCount"] == 0
        and health["centerId"] == center_id,
        label + " defects/centerId",
    )


def contains_product_log(raw):
    for line in raw.splitlines():
        try:
            record = json.loads(line)
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        if (
            isinstance(record, dict)
            and type(record.get("ts")) is int
            and record["ts"] > 0
            and all(
                isinstance(record.get(key), str) and record[key]
                for key in ("level", "name")
            )
            and ("event" in record or "message" in record)
        ):
            return True
    return False


def check_lifecycle(run, commands, expected, center_id):
    first = expected["first_center_container"]
    second = expected["second_center_container"]
    need(
        HEX64.fullmatch(first) and HEX64.fullmatch(second) and first != second,
        "new exact container ID",
    )
    start = one_json(raw_for(run, commands, "start"), "start")
    restart = one_json(raw_for(run, commands, "restart"), "restart")
    need(
        start["containerId"] == first
        and restart["containerId"] == second
        and start["buildId"] == restart["buildId"] == expected["build_id"]
        and start["health"] == restart["health"] == "healthy",
        "start/rebuild product observation",
    )
    for label, cid in (("stop", first), ("final-stop", second)):
        stopped = one_json(raw_for(run, commands, label), label)
        need(
            stopped
            == {"state": "stopped", "containerId": cid, "exitCode": 0, "clean": True},
            label + " incomplete stop",
        )
        need(commands[label]["returncode"] == 0, label + " nonzero")
    order = list(commands)
    need(
        order.index("final-stop") < order.index("final-center-inspect-before-cleanup")
        and order[-1] == "final-center-inspect-before-cleanup",
        "final inspect must follow stop and precede cleanup",
    )
    final_inspect = json.loads(
        raw_for(run, commands, "final-center-inspect-before-cleanup")
    )[0]
    need(
        final_inspect["Id"] == second
        and final_inspect["State"]["Status"] == "exited"
        and final_inspect["State"]["ExitCode"] == 0
        and final_inspect["State"]["Running"] is False,
        "final center actual terminal state before cleanup",
    )
    prior = json.loads(raw_for(run, commands, "first-center-inspect-export"))[0]
    need(
        prior["Id"] == first
        and prior["State"]["Status"] == "exited"
        and prior["State"]["ExitCode"] == 0,
        "prior diagnostics not exported at actual terminal state",
    )
    logs_command = commands["first-center-logs-export"]
    logs_stdout = raw_for(run, commands, "first-center-logs-export")
    logs_stderr = raw_for(run, commands, "first-center-logs-export", "stderr")
    need(
        logs_command["returncode"] == 0
        and logs_command.get("argv", [])[-2:] == ["logs", first]
        and (contains_product_log(logs_stdout) or contains_product_log(logs_stderr)),
        "prior logs missing or not from stopped center",
    )
    need(
        commands["remove-first-center"]["returncode"] == 0
        and first.encode() in raw_for(run, commands, "remove-first-center"),
        "old container was not deleted",
    )

    second_owner = expected["second_owner_container"]
    need(
        HEX64.fullmatch(second_owner)
        and commands["second-owner-start"]["returncode"] != 0,
        "second owner incorrectly accepted",
    )
    inspect = json.loads(raw_for(run, commands, "second-owner-inspect"))[0]
    need(
        inspect["Id"] == second_owner
        and inspect["Config"]["Labels"]["ai.nemori.omne.project"]
        == expected["second_owner_project"]
        and inspect["State"]["Status"] in ("exited", "restarting")
        and inspect["State"]["ExitCode"] != 0,
        "second owner not actually rejected",
    )
    logs = raw_for(run, commands, "second-owner-logs") + raw_for(
        run, commands, "second-owner-logs", "stderr"
    )
    need(
        b"startup-failed" in logs and b"occupied" in logs,
        "no product ownership rejection evidence",
    )
    check_full_health(run, commands, "first-owner-health-after-second", center_id)
    tls_stdout = raw_for(run, commands, "tls12-negative")
    tls_stderr = raw_for(run, commands, "tls12-negative", "stderr").lower()
    negotiated_tls12 = re.search(
        rb"(?im)^(?:New|Reused),\s*TLSv1\.2,\s*Cipher is\s+(?!\(NONE\)|0000\b)\S+",
        tls_stdout,
    )
    if re.search(rb"(?im)^\s*Protocol\s*:\s*TLSv1\.2\s*$", tls_stdout):
        negotiated_tls12 = negotiated_tls12 or re.search(
            rb"(?im)^\s*Cipher\s*:\s*(?!0000|\(NONE\))\S+", tls_stdout
        )
    need(
        commands["tls12-negative"]["returncode"] != 0
        and b"CONNECTED(" in tls_stdout
        and b"alert protocol version" in tls_stderr
        and not negotiated_tls12,
        "TLS1.2 peer protocol-version rejection not established",
    )


def check_cleanup(evidence, commands, run):
    need(
        evidence.get("cleanup_complete") is True
        and evidence.get("cleanup_errors") == [],
        "cleanup failed",
    )
    cleanup = {item["label"]: item for item in evidence.get("cleanup_commands", [])}
    for kind in ("container", "network", "volume"):
        label = "cleanup-final-list-" + kind
        need(
            label in cleanup
            and cleanup[label]["returncode"] == 0
            and (run / cleanup[label]["stdout"]).read_bytes() == b"",
            label + " exact label remains",
        )
    for label in (
        "cleanup-other-final-list",
        "cleanup-inner-project-final-list",
        "cleanup-inner-fixture-final-list",
        "cleanup-inner-all-final-list",
    ):
        need(
            label in cleanup
            and cleanup[label]["returncode"] == 0
            and (run / cleanup[label]["stdout"]).read_bytes() == b"",
            label + " private Engine residual",
        )
    need(
        evidence.get("other_project_cleanup_complete") is True,
        "second owner cleanup incomplete",
    )


def check_secrets(run):
    sources = (
        run / "private/mac-register-alice.secret",
        run / "private/bob-credential.secret",
    )
    secrets = [path.read_bytes() for path in sources]
    need(
        all(len(value) >= 16 for value in secrets),
        "private fixture credential unavailable",
    )
    for output in [run / "evidence.json", *(run / "raw").iterdir()]:
        if not output.is_file():
            continue
        content = output.read_bytes()
        need(
            all(value not in content for value in secrets),
            "fixture credential leaked in " + output.name,
        )


def check(run):
    evidence = json.loads((run / "evidence.json").read_text())
    need(
        evidence["status"] == "observed-awaiting-oracle"
        and evidence["business_complete"] is True,
        "driver did not complete business journey",
    )
    need(evidence["inputs"]["platform"] in ("arm64", "amd64"), "platform absent")
    need(
        evidence["expected"]["platform"] == evidence["inputs"]["platform"],
        "platform observation mismatch",
    )
    need(
        evidence.get("host", {}).get("system") == "Darwin", "Mac CLI host not observed"
    )
    if evidence["inputs"]["platform"] == "amd64":
        need(
            evidence["host"].get("machine") == "arm64",
            "Rosetta simulation requires observed arm64 host",
        )
    need(
        evidence["inputs"]["sha256"]["manifest"]
        == "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e",
        "manifest mismatch",
    )
    commands = command_map(evidence)
    platform_steps = ROSETTA_STEPS if evidence["inputs"]["platform"] == "amd64" else ()
    for label in (*CLIENT_STEPS, *COMMAND_STEPS, *platform_steps):
        raw_for(run, commands, label)
        raw_for(run, commands, label, "stderr")
    check_images(run, commands, evidence["expected"])
    observed = check_cli(run, commands)
    check_lifecycle(run, commands, evidence["expected"], observed["centerId"])
    check_cleanup(evidence, commands, run)
    check_secrets(run)
    return {
        "status": "PASS",
        "platform": evidence["inputs"]["platform"],
        "centerId": observed["centerId"],
        "rawCommandCount": len(commands),
        "scope": "one final I3 image, real private Linux Engine, Mac and Linux CLI; no native amd64 claim",
    }


def main():
    need(len(sys.argv) == 2, "usage: oracle.py RUN_DIRECTORY")
    run = pathlib.Path(sys.argv[1]).resolve()
    print(json.dumps(check(run), sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"FAIL {type(error).__name__}: {error}", file=sys.stderr)
        raise SystemExit(1)
