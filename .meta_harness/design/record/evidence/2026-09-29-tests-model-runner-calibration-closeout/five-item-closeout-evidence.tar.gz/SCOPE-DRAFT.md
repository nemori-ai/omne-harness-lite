# 五项技术关闭证据输入草稿

这是 root 后续正式技术验收记录的证据输入包，不是规格、正式 record 或新的接受决定。root 已明确报告 TODO 关闭 T09/T10/T15/T19/T20；本打包只固定依据及来源，最终署名与接受责任仍在 root／实际负责人。

本次打包输入 HUB `panqiwei/model-request-runtime` @ `bc24829860c191ef8b90c7ca38c2423e943cf7a2`。精确根目录、全部copy来源/SHA、tracked源码与测试的snapshotCommit/gitBlob/SHA/lastChangeCommit、已采用设计引用、既存归档索引在 `inputs.json`。源码与设计只给Git可定位引用，不另复制正文形成第二规格。

## 有限接受范围

| 项 | 本轮关闭的实际有限义务 | 关键链 |
| --- | --- | --- |
| T09 | 同合法原Run/调用的完整失败来源交给runner；同prefix、显式借用/释放、旧owner unknown责任 | v18来源修复与三技术重载；真withRun/TLS503→实际source；真noRun/错Run拒绝；A2同物理日志default/custom/跨call历史；实际release/host stop |
| T10 | 真Cordis runner/P5登记与配置代际、纯replay；耐久retry后调用方等待、再次守卫与原事实保留 | P5旧新policy/sample代际；原PT0.5S等待550ms后TLS二发；真实EIS撤限后的unavailable零新HTTP；生产共用adapter七联合精确映射 |
| T15 | 十三操作原逐义务矩阵及本模型纵线适用轴；额外C1/C2闭合 | 真SL3 resumable规划拒绝/修正/release；每次当前两limit；真实custodian发布轮换→同call第二TLS授权SHA改变，原binding不变；T08与A4复用 |
| T19 | 首轮/稳定追加/缺usage更早锚、prefix/可见性/compaction输入失效、model/basis/route与来源因果 | 旧独立U4矩阵；新withRun三轮；U16-V6同log两合法M/R的选入A/B与候选顺序拒绝 |
| T20 | 原物理M/R或R校准原值、unknown隔离/真实cold重开、retry/并发隔离及明确工具/媒体/opaque/cache适用域 | 旧独立U4物理批、连续EIO、SIGKILL后零模型重开；actual tokenizer历史0；新withRun原批；同log合法非祖先门 |

不包含 T21逐家full/phi/delta算法、T22满37或真实OR认证、付费收据、后继新增OpenAI opaque模型交付、完整Run/AgentLoop/治理/压缩器或全部CLI用户流程。受控single-Run/terminal选择和本地TLS上游usage的前提照原报告保留；不能称生产G28或真实OR统计已认证。多个测试日志有重跑与范围重叠，不累加为新测试总数。

## 谁实际做了什么

- `root-logs/`：root 在HUB实际执行测试/build相关类型检查的原始输出；本次独立代理只读结果并核对实际测试体。日志无明确exit字段时不单凭空错误输出推断成功；两次关键exit在 `inputs.json.rootConfirmedExitCodes` 记为 root 提供的实际句柄结果。
- `independent-a4/`：本代理此前独立实际创建两仓外consumer，真实pnpm项目包＋精确已安装第三方重包、离线安装、逐字EN/ZH README编译执行。32项目tarball是实际pnpm pack，29第三方重包不是registry原tgz。包中有原字块、driver、结果、依赖闭包与清理回执。此处不复制任何第三方源码/完整node_modules，tgz的逐SHA记录在packs.json；精确重放的tgz仍在原HUB私有证据目录。
- `reports/`：本代理当时与本次独立只读审查报告；最终两份报告保留初次未通过/未覆盖记录，再由顶部最终追加给出限定Pass。不得将审查称为独立重跑root测试。
- completion30旧U4：65具名场景是此前同一独立代理的分批实际执行，原始report与日志已经私有保全。本包只给existing tar/index真实路径、整个tar SHA及8个指定成员SHA/hash-match，不复制旧数据库/配置/密钥，也不重跑没有变化的性能。未把旧65与root重复执行相加。
- completion34退役：原runner-assembly与u4-source-order索引文件仅路径/SHA引用；未读取或复制该目录的数据库与运行配置。无活动消费者可保留。

## 必须保留的首次失败／反例

1. 原7595c196 noRun失败被包装为Run的真实产品反例：`reports/5/REPORT.md` 保留当时实际代码/测试重现和根确认；`root-logs/runner-source-release-tests.log` 是当时错误正向oracle的运行，不能重写成正确通过。Git历史引用可回读旧源码。后继原Run绑定修复及真noRun拒绝才闭合。
2. `root-logs/runner-final-guard-types.log`：与transport build并发缺dist的原类型失败；after-build原log保留，root原句柄42902 exit0独立列出。首次不是产品行为负控，不掩盖也不当契约缺陷。
3. `root-logs/withrun-three-turns-typecheck.log`：原测试类型推断失败；fixed原log及68b49260类型标注修复对应，不删原失败。
4. `root-logs/demo-v18-exact-attempt-tests.log`：原环境空间不足运行失败，与改受控临时目录后的tests-data-tmp日志分别留存。
5. A4 `pack-driver-initial-failure.log`（TS定位）、`en/compile-1.log`（夹具类型）、`en/run-1.log`（误将字段读取当调用）、`en/run-2.log`（冻结对象Proxy不变量）；最终原样README与产品均未修改，只修独立夹具，原日志保留。
6. 旧U4真正OpenAI显示名失效反例 `tmp/calibration-acceptance/openai-original.log` 与原oracle修后 `openai-fixed.log` 位于已核archive member引用；旧U4其它fixture/unknown/cold/Pro反例的完整索引由归档README原入口维护，不复制或删改原归档。

## 可回放校验与归档边界

在包目录运行 `python3 verify.py`：只读本包已复制文件及SHA清单，核每份copy、零未知遗漏，输出精确计数。`assemble.py` 是本次原始固定白名单复制工具；它逐copy比较复制前源SHA、复制后源SHA与目标SHA，源码ref来自一个冻结Git HEAD，不遍历用户配置或业务目录。

`inputs.json` 是证据入口；`MANIFEST.json` 覆盖本包每个文件。root可私有归档 `five-item-closeout-evidence.tar.gz`，其中不包含该tar自身。这个包不创建正式record、不修改TODO、不执行git fetch/merge/push，也不导入main未提交内容。本次只写授权证据目录，无新测试/网络/模型调用；打包程序完成后无进程、reader或租借资源。
