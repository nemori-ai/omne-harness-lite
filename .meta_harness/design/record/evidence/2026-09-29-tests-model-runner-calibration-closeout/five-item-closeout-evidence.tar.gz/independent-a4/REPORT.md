# A4 runtime v18 新失败来源：双语仓外制品独立验收

结论：**Pass（本节最小制品消费门）**。两个全新仓外消费者分别逐字提取打包内 README.md / README_ZH.md 的 `inspectFailure` TypeScript 块，独立离线安装、严格编译、执行实际打包 `createModelRuntime` / `readAttempts` / `ModelFailureSource`，每种语言 9 项检查通过。此结论不替代 root 接受，不关闭 T09/T10 的其它运行组合义务。

## 精确输入与封闭性

- 打包源：HUB `panqiwei/model-request-runtime`，HEAD `c42b8a6b6f07e38b6d2d1d3df2e5f09204189364`。root 授权只读已构建 dist，期间冻结相关 dist；未运行 build。封存 32 个项目包的 package/dist/README 文件 SHA；打包前后完全相等（`dist-before.json`、`project-pack-complete.json`）。报告整理时 HUB 已由 root 推进，不把后来 HEAD 冒充制品源。
- runtime 原 `pnpm pack` tgz SHA256：`2a10fe9278dc155db5dc72df2f34fa69b7e68462954fdb6c31b1e59d33255926`。
- 32 个项目真正 pnpm tarball；另 29 个第三方依赖由本机锁定的已安装文件重封包，**不是 registry 原始 tgz**。`packs.json` 逐项记录版本、来源、SHA、kind；仅用已有 TypeScript，没有下载或升级。最终 61 个 tgz 全部拷入两个消费者自己的 artifacts，package.json 所有依赖及 overrides 均为本地 file。
- `/tmp/omne-f18-consumer-en-caut6qgb` 与 `/tmp/omne-f18-consumer-zh-sqoqr37x` 是本轮 mkdtemp 独占目录。各自离线安装、自有 store；每处 305 条 node_modules 软链均落于自身目录，无 workspace / 原 dist 外链，见两语 `closure.json`。实际 Node v24.18.0，pnpm 版本详 closure。
- README 块从每个已安装 runtime 包独立提取，没有修改语句；两语块 SHA 均为 `218a8df9cbf28a5eff359b0cdad20b0961227a4d84e23735776dfea2a2a1ebd9`。README 各自 SHA 与 tgz SHA 在各 `extraction.json`，原样字节在 `literal.mts`。

## 义务与实际结果

| 义务 | 实际辨别 | EN / ZH |
| --- | --- | --- |
| 公开新签名可编译 | 原样 literal + 完整 typed consumer；另 @ts-expect-error 检查缺 execution 参数、缺 attempt、普通结果误取 consumption 均不能通过类型检查 | Pass / Pass |
| 普通读取保持业务结果 | 实际 awaiting_decision 无 consumption/result 包装，无 verify 序列化 | Pass / Pass |
| 新显式失败借用 | 同一真实日志中的原 Run/attempt失败，由真实 runtime 生成 source；原样函数返回 authoritativeSubject | Pass / Pass |
| 函数 finally 释放 | 函数返回后持有真实 source 再 verify 为 unavailable；跨 Run 拒绝后同样释放 | Pass / Pass |
| 同 Run 后继执行 | 原 Run attempt 1 的失败可由 attempt 2 的 execution 验证 | Pass / Pass |
| 错误归属不能借用 | another Run 及真实 noRun dispatched/response 均 invalidInput；fractional attempt 亦 invalidInput | Pass / Pass |
| 不适用返回原业务结果 | 不存在 call 返回 callNotFound，不新增物理 append | Pass / Pass |
| 原主体/原 prefix | 改 failure 拒绝；准确主体成功；verify 不新增读；真实追加无关 ended 后仍成功且不补读 | Pass / Pass |
| 生命周期实际失效 | source.release 可重复；实际 runtime.close 后未主动 release 的真实 source 失效；owner 实际任务 stopped 后才能 release | Pass / Pass |

每种语言分别 9 组行为检查（不是 9 个既有测试名）：9 次实际日志读，6 次 append，9 次任务实际 stopped，最终 active=0，forbidden provider calls=0，网络尝试计数=0。原始结果在 `en/result.json` 与 `zh/result.json`。

## 执行与回放

已执行 `pack.py` 与 `finish-pack.py`；每包命令日志保留。`consumers.py` 创建两个全新目录，复制封闭 tgz 并运行：

```sh
pnpm install --offline --ignore-scripts --store-dir <该消费者>/store
pnpm exec tsc --noEmit --strict --target ES2023 --module NodeNext --moduleResolution NodeNext --skipLibCheck --allowImportingTsExtensions --types node literal.mts consumer.mts
node --experimental-strip-types consumer.mts
```

最终证据：`en/compile-final.log`、`en/run-3.log`、`zh/compile-final.log`、`zh/run-1.log`，退出码均 0；编译成功日志为空是 tsc 正常结果。`consumer.mts`、两语 literal/package/lock、实际受控 JSONL、依赖闭包清单均已保留。`finalize.py` 在验证结果与软链后保全文件并仅删除本轮两个 mkdtemp 目录，`cleanup.json` 两项 removed=true。无剩余进程/reader/借用资源。

## 原失败及范围限制

1. 原 pack driver 在尝试从根 node_modules 找 TypeScript 时失败；随后从 runtime 已安装依赖精确解析，保留 `pack-driver-initial-failure.log`。未补装新版或网络获取。
2. `en/compile-1.log` 是独立夹具缺 SessionModelSelectionInput 四个字段及 wait 返回型错误；修正夹具，literal 不变。
3. `en/run-1.log` 是夹具把构造时读取 policy.now 误判为调用；修正为调用才抛错；`en/run-2.log` 是代理冻结 service 方法违反 JS Proxy 不变量，改为空目标透明转发。原受控日志分别保存在 fixture-run-1-log / fixture-run-2-log；产品未改，断言未放宽。
4. 真实 JSONL/persisted MR9 + 真实 runtime/source；身份与读任务 owner 是明确有限受控输入，history failure adapter 从这同一枚真实前缀解释原 dispatched/response，并确认无 runner 条目。不宣称真实外域 Run terminal/治理 owner 已实现；本轮不发模型请求，不认证 paid route，不取凭据，也不证明全部十三操作或取消竞态。
5. 网络防御计数覆盖 consumer 安装完成后实际执行段；没有将这个局部计数冒称所有包纯 import 全时网络审计。离线安装原始日志独立保留。
