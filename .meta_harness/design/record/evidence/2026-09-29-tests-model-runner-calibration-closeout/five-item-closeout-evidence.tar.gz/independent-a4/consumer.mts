import assert from 'node:assert/strict'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { Socket } from 'node:net'
import { syncBuiltinESMExports } from 'node:module'
import { inspectFailure } from './literal.mts'
import {
  createModelRuntime, createCallContainerStore, captureModelLogValue, prepareModelLogEntry,
  interpretCallHistory,
  type RuntimeConstruction, type PlannedSemantics, type SettlementOwner, type SettlementTask,
  type SettlementTaskKind, type ModelRuntimeService, type ModelFailureSource,
  type ModelLogCategory, type ModelLogPurpose, type ModelLogShell, type SessionRuntimeBinding,
  type ModelFailureExecution,
} from '@omne-harness-lite/model-request-runtime'
import { openJsonlSessionLog, type SessionLog } from '@omne-harness-lite/session-log-jsonl'
import { parseOpaqueIdentifier, parseTenantId, unwrap } from '@omne-harness-lite/identity-values'
import { judgeModelResponse, type ModelResponse } from '@omne-harness-lite/model-response'
import type { JsonNumber } from '@omne-harness-lite/content-blocks'

let networkAttempts=0
Socket.prototype.connect = function () { networkAttempts++; throw Error('unexpected network') } as typeof Socket.prototype.connect
globalThis.fetch = async () => { networkAttempts++; throw Error('unexpected fetch') }
syncBuiltinESMExports()
const session=unwrap(parseOpaqueIdentifier('artifact-session','SessionRef'))
const tenant=unwrap(parseTenantId({organization:'artifact-org',account:'artifact-account'}))
const run='artifact-original-run'
const at='2026-09-29T00:00:00Z'
const dir=join(process.cwd(),'owned-log'); await mkdir(dir,{recursive:true})
const physical=await openJsonlSessionLog({dir,processOwnership:{current:`artifact-${process.pid}`,async observeExit(){return 'unknown'}}})
let reads=0, appends=0, forbiddenCalls=0, active=0, actualStops=0
const port:SessionLog={
 async readSince(...args){reads++; return await physical.readSince(...args)},
 async readByKey(...args){reads++; return await physical.readByKey(...args)},
 async append(...args){appends++; return await physical.append(...args)},
}
let currentGeneration:object=Object.freeze({})
const logBinding={session,tenant,log:port,generation:currentGeneration,currentGeneration:()=>currentGeneration}
let admission:'open'|'closed'='open'
const owner:SettlementOwner={
 name:'artifact-enumerated-read-owner',admission:()=>admission,opened:()=>({confirmed:true}),unresolvedWrites:()=>[],
 acquire(_limit:JsonNumber){
  if(admission!=='open') return {unavailable:true}
  active++;let running=0,released=false
  return {registration:{
   start<T>(_kind:SettlementTaskKind,work:(signal:AbortSignal)=>Promise<T>):SettlementTask<T>{
    running++;const ctl=new AbortController();const completion=Promise.resolve().then(()=>work(ctl.signal))
    const stopped=completion.then(()=>undefined,()=>undefined).then(()=>{running--;actualStops++})
    return {completion,stopped,requestStop:()=>ctl.abort()}
   },
   release(){assert.equal(running,0,'registration released before actual stop');assert.equal(released,false);released=true;active--},
  }}
 },
}
function unused<T>(name:string):T {
 return new Proxy({}, {get(){return ()=>{forbiddenCalls++; throw Error('unexpected provider use: '+name)}}}) as T
}
const adaptation={implementation:{name:'artifact-controlled',revision:'one'},definition:{modelId:'artifact/model',revision:'one'},configuration:{revision:'one',values:{}}}
const profile={adaptation,providers:['artifact-provider'],allowFallback:false,inputModalities:['text'],outputModalities:['text'],maxInputTokens:100,maxOutputTokens:20,inputConstraints:{},upstreamInputLimits:{maxInputTokens:{status:'unknown'},maxRequestBytes:{status:'unknown'}},updatedAt:at}
function prepared(category:ModelLogCategory,value:unknown,purpose:ModelLogPurpose,shell:ModelLogShell={tenant}){
 const captured=captureModelLogValue({category,input:{kind:'value',value}})
 if(!('ok' in captured)) throw Error('capture '+category+': '+captured.reason)
 const result=prepareModelLogEntry({session,shell,captured:captured.ok,purpose,messagePrefix:[]})
 if(!('ok' in result)) throw Error('prepare '+category+': '+result.reason)
 return result.ok
}
async function append(category:ModelLogCategory,value:unknown,shell:ModelLogShell={tenant},fenced=false){
 const record=prepared(category,value,{kind:category},shell)
 const fence=fenced?{kind:'fenced' as const,run,attempt:1}:{kind:'unfenced' as const}
 assert.ok('positions' in await port.append(session,[record],fence,{kind:'unconditional'}))
}
const shell={tenant,run,attempt:1}
await append('message',{id:'artifact-attempt',type:'system_reminder',nature:'event',source:{kind:'attempt_started',attempt:1,reason:'first',at},blocks:[],createdAt:at},shell,true)
for(const belongs of [true,false]){
 const call=belongs?'run-call':'norun-call';const id=call+'-response'
 const dispatch={kind:'model_call_dispatched',call,dispatch:1,response:id,adaptation,profile:{origin:'official',routeName:'artifact/model'},profileSnapshot:profile,provider:'artifact-provider',selectedBy:'session',credentialScope:{layer:'factory'},parameters:{}}
 await append('record',dispatch,belongs?shell:{tenant},belongs)
 const response={id,call:belongs?{callId:call,runId:run}:{callId:call},...(belongs?{attemptId:1}:{}),dispatch:1,route:{adaptation,profile:dispatch.profile,profileSnapshot:profile,provider:'artifact-provider',selectedBy:'session',credentialScope:{layer:'factory'},parameters:{}},outcome:'failed',failure:{cause:'upstream_unavailable',statusCode:503},timing:{sentAt:at,endedAt:'2026-09-29T00:00:01Z'},usage:{input_tokens:3,output_tokens:0,cache_read_tokens:0,cache_write_tokens:0,source:'upstream'},cost:{cost_usd:0.0001,source:'upstream_usage'},inputCalibration:{requestInput:{kind:'unavailable',reason:'not_retained'},observedInput:{kind:'unavailable',reason:'missing_usage'},outputGroup:{kind:'unavailable',reason:'not_retained'}}}
 assert.ok('ok' in judgeModelResponse(response),'independent response must satisfy actual public judge')
 await append('response',response,belongs?shell:{tenant})
}
const binding:SessionRuntimeBinding={
 log:logBinding,
 selection:{binding:logBinding,owner,sessionTenancy:unused('session tenancy'),compatible:()=>{throw Error('unexpected compatibility')},diagnostic(){},onDiagnosticFailure(){},concurrent:2,currentEvaluationInputs:unused('selection current input'),catalog:unused('selection catalog'),projection:async()=>{throw Error('unexpected projection')},now:()=>at},
 catalog:unused('catalog'),currentEvaluationInputs:unused('current input'),credentials:unused('credentials'),tools:unused('tools'),
}
const construction:RuntimeConstruction<PlannedSemantics,unknown>={
 sessions:{async bind(s){return s===session?{binding}:{failure:'invalidInput'}}},
 calls:createCallContainerStore(),transport:unused('transport'),
 settlementContention:{name:'artifact-one-submission',limits:{submissions:1,elapsedMs:1000,retainedBytes:1000000,concurrent:2},decide:()=>({proceed:{waitMs:0}})},
 settlementScheduler:{nowMonotonicMs:()=>0,wait:()=>{throw Error('unexpected wait')}},
 reservationWaitPolicy:{maxWaitersPerCall:2,timeoutMs:100},tokenMargin:{multiplier:1,reserveTokens:0},
 policy:unused('invocation policy'),identities:unused('identity mint'),diagnostic(){},recovery:unused('recovery'),
 history:{
  call:(prefix,callId)=>interpretCallHistory({prefix,callId}),
  failure(prefix,callId){
   // This enumerated real log contains no runner domain entries; absence comes from this very prefix.
   assert.equal(prefix.entries.some(e=>e.readKeys.some(k=>k.startsWith('runner/'))),false)
   const h=interpretCallHistory({prefix,callId}); if(!('known'in h)) return {unavailable:true}
   const last=h.known.dispatches.at(-1); if(!last?.response) return {unavailable:true}
   const value=last.response.value; if(!('ok'in judgeModelResponse(value))) return {unavailable:true}
   const response=value as unknown as ModelResponse; if(response.outcome!=='failed')return {unavailable:true}
   const records=h.known.dispatches.map(d=>d.record);const first=records[0];if(!first)return {unavailable:true}
   return {subject:{failure:response.failure.cause,statusCode:503,profile:last.record.profileSnapshot,dispatches:[first,...records.slice(1)],retryConclusions:[]}}
  },
  calibration:()=>({sourceUnavailable:true}),run:()=>({unavailable:true}),
 },
}
const runtime=createModelRuntime(construction)
let lastSource:ModelFailureSource|undefined
// Transparent observation only: every result/source comes from the actual packed runtime.
const observedService=new Proxy({} as ModelRuntimeService,{get(_target,key){
 const target=runtime.service
 if(key==='readAttempts')return async (...args:Parameters<ModelRuntimeService['readAttempts']>)=>{
  const answer=await Reflect.apply(target.readAttempts,target,args)
  if(answer?.consumption?.kind==='failure')lastSource=answer.consumption.source
  return answer
 }
 return Reflect.get(target,key)
}}) as ModelRuntimeService
const key={session,callId:'run-call'}
const execution={run,attempt:1}
const checks:string[]=[]
try{
 const normal=await runtime.service.readAttempts(key)
 assert.equal('consumption'in normal,false);assert.equal('result'in normal,false)
 assert.equal('state'in normal&&normal.state,'awaiting_decision')
 assert.equal(JSON.stringify(normal).includes('verify'),false);checks.push('normal result only')
 const answer=await inspectFailure(observedService,key,execution)
 assert.ok('authoritativeSubject'in answer)
 assert.ok(lastSource);assert.deepEqual(lastSource.verify(lastSource.subject,execution),{unavailable:true})
 checks.push('literal positive and finally release')
 assert.deepEqual(await inspectFailure(observedService,key,{run,attempt:2}),{authoritativeSubject:lastSource.subject})
 checks.push('same Run later attempt allowed')
 assert.deepEqual(await inspectFailure(observedService,key,{run:'another-run',attempt:1}),{invalidInput:true})
 assert.ok(lastSource);assert.deepEqual(lastSource.verify(lastSource.subject,execution),{unavailable:true})
 checks.push('wrong Run rejected and finally released')
 assert.deepEqual(await inspectFailure(observedService,{session,callId:'norun-call'},execution),{invalidInput:true})
 checks.push('noRun cannot be borrowed as Run')
 assert.deepEqual(await inspectFailure(observedService,key,{run,attempt:1.5}),{invalidInput:true})
 checks.push('invalid attempt rejected')
 const beforeNoCall=appends
 assert.deepEqual(await inspectFailure(observedService,{session,callId:'absent'},execution),{callNotFound:true})
 assert.equal(appends,beforeNoCall);checks.push('notApplicable returns original business result')
 const live=await runtime.service.readAttempts(key,{consumeFailure:true});assert.equal(live.consumption.kind,'failure')
 if(live.consumption.kind!=='failure')throw Error('source missing')
 const source=live.consumption.source;const readCount=reads
 assert.deepEqual(source.verify({...source.subject,failure:'request_rejected'},execution),{invalidInput:true})
 assert.ok('authoritativeSubject'in source.verify(source.subject,execution));assert.equal(reads,readCount)
 await append('record',{kind:'model_call_ended',call:'unrelated',ending:'undispatched',cause:'credential_unavailable'})
 assert.ok('authoritativeSubject'in source.verify(source.subject,execution));assert.equal(reads,readCount)
 checks.push('exact subject, no later read, unrelated append survives')
 source.release();source.release();assert.deepEqual(source.verify(source.subject,execution),{unavailable:true})
 const held=await runtime.service.readAttempts(key,{consumeFailure:true});if(held.consumption.kind!=='failure')throw Error('held source')
 assert.deepEqual(await runtime.close(),{released:true})
 assert.deepEqual(held.consumption.source.verify(held.consumption.source.subject,execution),{unavailable:true})
 held.consumption.source.release();checks.push('actual runtime close invalidates retained scope')
 assert.equal(active,0);assert.equal(forbiddenCalls,0);assert.equal(networkAttempts,0)
 await writeFile('result.json',JSON.stringify({checks,reads,appends,actualStops,active,forbiddenCalls,networkAttempts,scope:'Actual packed createModelRuntime/readAttempts/source over real JSONL; finite enumerated trusted owner, no production Run terminal or auth certification.'},null,2)+'\n')
 console.log(JSON.stringify({checks:checks.length,active,forbiddenCalls,networkAttempts}))
}finally{await runtime.close();await physical.close()}

// Compile-time negative controls are never executed.
async function publicTypes(service:ModelRuntimeService,source:ModelFailureSource){
 const ordinary=await service.readAttempts(key)
 // @ts-expect-error normal business result has no transient consumption resource
 ordinary.consumption
 // @ts-expect-error original subject alone is not the new public verification signature
 source.verify(source.subject)
 // @ts-expect-error actual execution requires both Run and attempt
 const invalid:ModelFailureExecution={run}
 void invalid
}
void publicTypes
