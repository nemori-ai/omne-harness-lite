from pathlib import Path
import json,hashlib
base=Path(__file__).resolve().parent
manifest=json.loads((base/'MANIFEST.json').read_text())
for row in manifest['files']:
 p=base/row['path'];assert p.is_file(),row['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],row['path']
expected={row['path'] for row in manifest['files']}
actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file() and p.name not in ['MANIFEST.json','five-item-closeout-evidence.tar.gz','verify-result.log']}
assert actual==expected,{'extra':sorted(actual-expected),'missing':sorted(expected-actual)}
inputs=json.loads((base/'inputs.json').read_text())
for row in inputs['copiedFiles']:
 assert hashlib.sha256((base/row['copy']).read_bytes()).hexdigest()==row['sha256'],row['copy']
print(json.dumps({'manifestFilesVerified':len(manifest['files']),'copiedFilesVerified':len(inputs['copiedFiles']),'result':'pass','scope':'package integrity only; does not rerun tests or accept delivery'}))
