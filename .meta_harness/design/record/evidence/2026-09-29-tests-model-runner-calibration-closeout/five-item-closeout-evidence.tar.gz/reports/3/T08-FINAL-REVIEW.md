# T08 最终独立只读复核

结论：**Pass，建议 root 按原有限模型侧边界关闭 T08。** 前次指出的三项证据缺口均已由实际新测试补齐；结合既有 withRun 锚点、结算、恢复与 A4 双语仓外制品结果，本轮未留下 T08 模型侧必经未证项。此为独立验收建议，最终接受仍由 root 决定。

检查工作树：`/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime`；分支 `panqiwei/model-request-runtime`；HEAD `4473220e3d1c540673e9ae46d67cd8290f438051`。新增小表由 HUB `46b4201b` 集成；本次只读检查新测试体及已完成主线原始日志，没有重跑 build/测试，没有修改任何源码或既有证据。

| 前次缺口 | 新测试的实际输入、辨别断言 | 结论 |
| --- | --- | --- |
| 原 attempt 仍最新但 Run 已结束 | `acceptance-t08-run-terminal.spec.ts:116` 使用真实 JSONL 的 attempt_started(1) 及原 dispatched/opened；受控 source latest=1、terminal=ended；真实 coordinator 结算成功，R late=true、原 attemptId=1、恰一次新提交、物理日志恰一R | Pass。移除 terminal 独立分支会击穿此正向 |
| superseded 不得短路未知/非法终结 | 同文件参数化 invalid/unknown：真实日志先有 attempt1 后有 attempt2；source 被调用一次并返回该不可信终结值；结果 run_history_unavailable，提交数不增长，实际前后 readSince 完整相等 | Pass。不是只测返回错误，实际零追加被核 |
| 反射伪造不是 owned prefix | 同文件真 readSettlementPrefix 先作正向，source调用1；随后 spread、同prototype+assign、同prototype+descriptors三类复制均 unavailable 且source调用0 | Pass。明确击穿删除 owned brand 检查的回归，不借 captured-value 的别项测试替代 |

原运行证据 `vendor-completion-root/t08-t15-final-gaps.log` 已完成：3 文件、9 测试全部通过，Type Errors no errors，开始 08:09:11、耗时12.16秒。该数字是 T08/T15 联合运行的整体统计，不冒称本新增小表有9项；本小表实际4个测试实例（ended正向、invalid、unknown、反射复制）。本次独立行为核查以这些具体断言为依据，运行结果引用 root 实际日志。

既有证据仍按 `T08-REVIEW.md` 限定复用：真 fenced D/opened/intent 与 tailEquals 响应，物理完整批两向竞争，opened unknown/迟到写实际停止前持有，旧 attempt 正文与新 attempt 归账及原批优先恢复，模型来源身份/生命周期、新 attempt calibration target。主线 `t08-final-owned-run-composition.log` 6文件140测及 `runtime-v18-source-tests.log` 3文件9测已在上次逐项核到实际测试体。本次没有重复把统计数当覆盖。

A4 `tmp/f18-artifact-acceptance/REPORT.md` 是本代理已独立执行的 c42b8a6b 真实打包双语仓外消费者：原样 README inspectFailure 块分别严格编译并各通过9组运行检查，真实JSONL/runtime/source，同Run后继、wrongRun/noRun、finally及runtime.close失效；两个独占目录已清理。当前新增项是测试，既有制品输入范围不被扩称新实现认证。

范围：合法来源的条件消费与模型运行算法；受控 G28 terminal 输入明确为前提，并未宣称生产 Run 终结协议已经交付。T09/T10 runner/P5最后装配、T19/T20三轮marginal及其他外域仍各归原任务，本报告不评价或替代。原值/归账壳保真由上次实际组合覆盖，本新增 ended 用例只补此前缺失的独立 terminal→late 分支，不要求复制所有既有矩阵。

## 本次读取输入 SHA256

- `packages/model/model-request-runtime/tests/acceptance-t08-run-terminal.spec.ts`: `22775d02f0c66212626f04b7624176c984ed139ad4af7ffc4e3feae267280708`
- `packages/model/model-request-runtime/src/settlement-prefix.ts`: `fa2e95f8a6e71d8b30e5fab9423aac0df08b441a8d2dd1b2349a5d2ffe14458f`
- `packages/model/model-request-runtime/src/settlement-coordinator.ts`: `27c6ca6c781bca46d18f83db154d8e4306f702dff45416113bb1fc7d9f86eb5c`
- `tmp/model-request-runtime/vendor-completion-root/t08-t15-final-gaps.log`: `a7e1cd9719f0c85a47cf799c180fd564a2349b24409ab835e1e65434c32cb8d5`
- `tmp/model-request-runtime/vendor-completion-root/t08-final-owned-run-composition.log`: `e2df093c9f118d73aef857f8a5104a94ff42b5a0592534314d68f1480b19de14`
- `tmp/model-request-runtime/vendor-completion-root/runtime-v18-source-tests.log`: `494ca18d90363f2f43f40cdedbcfaf1a41bbf784636d2794553fa0cd3f4bfe31`
- `tmp/model-request-runtime/t15-final-matrix/T08-REVIEW.md`: `e30fd7494c83d515d1ae050bc6abfcbcd9ef3e7f2bc3f4ae4895b228c4016c0e`
- `tmp/f18-artifact-acceptance/REPORT.md`: `46509ffe4966c32e16c94e0ee58016fa25d62b8019d829cbbdcf9f850a1e7561`

所有操作为读文件与写本报告；无新增消费者、进程、reader、writer或资源租借需要释放。
