# 最终追加：唯一 U16-V6 缺口已补齐

**最终结论：Pass，建议 root 按 T19/T20 原有有限模型纵线边界关闭两项。** 本报告下方初次复核唯一保留的同日志合法来源/到达顺序门，现由新实际SL3测试补齐；没有另定位的T19/T20必经未证项或真实反例。本结论不把T21算法、T22满37/付费、后来OpenAI opaque模型交付当作这两项的前置，也不接受其各自范围。root最终接受。

集成输入：原作者 f35901b4 → HUB `47b5c575`；实际新增 `packages/model/model-request-runtime/tests/acceptance-u4-causal-source-order.spec.ts`。主线后来进到69b12a57的transport/image增量，root明确说明未修改本runtime源码/新测试，不把它计成新的本门输入或验收结论。

独立读实际测试体确认：

- 真SL3同一日志先有A的原D/opened及完整M/R，再有另一call B的合法D/opened及完整M/R；两者都经公开MR9 judge/capture/prepare，I分别11与37，前缀摘要与费用也不同，实际owned prefix读得8项。不是把一个合法源同假/损坏payload相比。
- 当前明确selected message/locator选A时，实际 `authorizedCalibration` 返回A的原I=11、prefixDigest、outputBlocks及replaySelection，虽B物理较新也不推进来源；单独实际选B又能得到37，证明B确属可用的另一合法来源。
- 对选择A，真实candidate `[A,B]` / `[B,A]` / `[B]` 皆unavailable，不能靠候选先后/最新物理位置把未选B塞成祖先。两个来源都是刚读出的真entry locator，未用trusted boolean代替来源认证。
- 整组读取前后真实日志完全相同、submissions不增；原A/B完整R含不同upstream cost逐值保持，没有重计量或回写。

因此它满足初次报告最小oracle的责任边界：选入因果与物理较新分离，以及不合法候选到达顺序不能被静默采用。有限selector仍是声明的受控来源输入，不宣称生产Run分支owner；不为关闭本门新增异步网络到达矩阵、完整Run引擎或压缩器。真实并发会话/重试/unknown/冷退出等依旧由原65场景与已核SL3组合分别承担，不拿此单测代替它们。

运行证据：`tmp/model-request-runtime/vendor-completion-root/u4-causal-source-order-integrated.log` 已读，1文件1测通过、Type Errors no errors，08:41:48开始、6.16秒。root随后明确提供原句柄24516已完成exit_code=0。本代理是只读独立断言审查与原日志核验，没有冒称本轮自行执行测试或build。

原矩阵中首轮/稳定追加、缺usage更早合法锚、输入/basis失效、媒体/工具/opaque适用域、实际usage/cache/cost、物理批/unknown/cold/no回写各门继续复用；withRun三轮真服务full→marginal与物理M/R证据已在初次报告核定。T19/T20原唯一尾项现已闭合；全部U4或所有模型认证的其它承诺仍按各任务保留其精确边界。

最终新增输入SHA256：

- `packages/model/model-request-runtime/tests/acceptance-u4-causal-source-order.spec.ts`: `41c012a92f20be4bb5435bb3e3afed960c7665ac1181b969b8e2660a96a66cc7`
- `packages/model/model-request-runtime/src/service-calibration.ts`: `0e58b2b0f59fd0126ab34bf0a92f9b640d2184c3328de3bce88c26bfdbc3c7ae`
- `tmp/model-request-runtime/vendor-completion-root/u4-causal-source-order-integrated.log`: `eeeb151e00a1185365b5ded70b413bc9783702089ca411da5956677871c3bee7`

本轮仅追加此报告；没有新增进程/消费者或资源租借，源码和原失败证据未改。

---

## 保留：091d1c3d初次复核记录

# T19 / T20 原 U4 失效、来源、耐久及形态最终范围复核

结论：**主要具名矩阵 Pass with issues；只剩一个共享来源/并发分支的小型用例尚未定位有效证据，建议补齐后关闭 T19/T20。** 没有已证产品缺陷。新增真实 withRun 三轮已经补上此前单Run实际服务消费缺口，不能再以外域 Run 未实现笼统阻停。逐家算法 T21、逐模型付费 T22 不作为本两项全部前置。

本次 HUB `panqiwei/model-request-runtime`，起始HEAD `091d1c3d7454b150f91ed4b2f8049c0e910235a2`，只读旧证据/当前测试和来源源码，未运行build、测试、网络或模型，不读取private配置/凭据/账本。唯一写入本报告。D107已采用MR9/RT10/transport v12 rev2/runtime v16，后继v17/v18的条件来源消费范围沿正式采用追加；verification保存的candidate字样不被当作当前未采用。

## 旧证据回读及新增输入

旧独立U4原报告在主检出 completion30/calibration-acceptance-unique.tar.gz 的 `tmp/calibration-acceptance/README.md`，SHA `7f6898c3435b829ff79b8447af2f61a7cc599e4ea462bfb344e1f43a988a3f35`。本次从tar直接读取其原报告及5个原运行日志，并逐一对原manifest核SHA相等；没有恢复旧环境、执行归档脚本或复制完整归档。原65场景是分批实际独立执行，日志存在重跑，不相加制造新场景数。

新 `runner-service-with-run-calibration.spec.ts` 当前实际内容独立读到：真正认证/STT、SQLite/MF/EIS、生产Cordis/registry与本地TLS，构造期具名单Run选择、真fenced MS6 start，production `readDemoCalibrationHistory` 读同owned prefix；三次真实call/persist，首轮full 2/fresh 0，后两轮full 0/fresh 2；三条物理JSONL各是 `[message,response]` 单批，原inputCalibration与Pending逐值一致，实际壳Run/attempt保真。受控 upstream usage 有明确语义，未称真实OR认证。

HUB `withrun-three-turns-final.log` 3文件3测通过；`withrun-three-turns-typecheck-fixed.log` 类型通过。原类型推断失败保留且68b49260只修标注，不抹历史。`runner-service-calibration-source.spec.ts` 的默认noRun拒绝是受控空prefix+Run target负向，不能单独夸为真实Run历史正向；真正原批与正向由上述三轮及runtime service-calibration共同承担。

## T19：原失效与来源门

| 原义务／采用坐标 | 具体有效证据 | 当前读数 |
| --- | --- | --- |
| 首轮/稳定追加；UCT-V2/V6，U16-V3/V6 | 独立四Anthropic三轮真实TLS服务，OpenAI显示名原反例修复后原oracle；新withRun三轮真正来源闭包 | Pass（已采用代表binding域） |
| 缺usage不推进、选更早合法I、所有中间新增不漏 | acceptance-calibration-service:494 两轮missing_usage后回用旧锚，actual fresh units包含两轮中间及本轮而不含稳定原P；失败无I :539，准确I失败同call重试 :686 | Pass |
| prefix编辑/删除/重排/system/visibility/compaction后可见性 | acceptance-calibration-invalidation:160–189 实际messages变化触发full/prefix_changed，没有依赖“compaction=true”标记 | Pass。只核压缩结果作为输入，不认证或新造压缩算法 |
| model/basis/config/route变化 | usage-calibration-service:38/182真实服务切模型变full；invalidation:191–232 tokenizer/algorithm/replay/config、已知错model/provider、tools变化；旧lease及phi跨代际沿已接受D4 | Pass；不强加所有字段笛卡尔积 |
| 错session/locator/dispatch/分支选入、source缺失与不可读不同 | acceptance-calibration-source:154–268 真SQL/SL3前缀，错原locator/同位异payload/selected错entry/重复candidate/映射/代际拒绝；service-calibration:205/329真实Run旧attempt批与错Run/attempt/selected拒绝 | Pass（条件源防御）；不能以测试标题“candidate reordering”冒充两个不同合法候选的顺序反例 |
| 合法Run旧attempt及no-reply同call下一dispatch | service-calibration:205 原完整批current:null、原I不重算；:349/433 samecall nextdispatch Run/attempt与跨call/dispatch拒绝；service-dispatch实际当前target1/2与D壳一致；新withRun三轮实际应用来源 | Pass（有限具名来源），不要求生产分支治理 |
| **乱序到达、更新但非祖先，选最新合法准确观察；U16-V6 / RT10 S-77/S-80/S-82** | 现有并发是不同session线性链；源码selected/candidate关系有防御，但尚未见同一真实log中两个不同且均合法的候选，物理新者未选入时仍选择旧合法祖先，或其完成到达顺序与选入因果顺序不同 | **未覆盖，唯一小用例见下文** |

## T20：原耐久、并发与形态门

| 原义务／采用坐标 | 具体有效证据 | 当前读数 |
| --- | --- | --- |
| 原物理M/R或无reply R、读取/结算全值不回写；U16-V8 | 独立service直接读entries.jsonl每个物理line的entries，Pending/calibration与readAttempts一致；同稳定key异calibration竞争只认原winner；新withRun三轮同样直接验真实单line批 | Pass；未用邻接或receipt known伪造物理batch |
| unknown不校准、不释放、不新计量；U16-V8 | service:591实际response datasync连续EIO+truncate失败，后续call零full/replay/fresh增长、零新HTTP、原registry references=1；实际日志原值保持 | Pass；解除注入不谎称同实例恢复可信写 |
| 关闭重开原批，不需新模型/凭据；U16-V9 | cold:83两支before/after-write，真实supervisor SIGKILL→exit+close；零definitions/inputMeters的新实例认回原SHA/原calibration或send_unknown，HTTP不增 | Pass；不宣称物理删除所有旧凭据，本义务是恢复不依赖新取凭据/计量 |
| retry与并发隔离 | 真503无观察及usage先于带内错的同call retry；A/B两真实会话Promise.all，actual wire/计量units不串；同call竞争及unknown writer沿已验RT10/SL3 | Pass。**同日志不同因果分支/乱序共享上方唯一源选择用例**，不把两个session称同日志分支已验 |
| tools/media/opaque；UCT-V5/V7，U16-V7 | invalidation:232/295/344/396 tools改变envelope，真实PNG字节/图数限制，新增tool call/result的实际wire身份，opaque适用域明确拒绝；source block/index/重复target/映射与实际delta反例 | Pass（明确官方适用域），不把cipher长度当token，也不承诺任意媒体算法 |
| cache分类/usage与cost保真；U16-V2/V5 | reader13场景完整/部分/冲突/准确零/response-cache零/账单总量/missing；实际异常取消/断流/拒收保留已观测I，actual reader stopped；四Anthropic cache分类不重复相加；六Proscope_unknown防守，非Pro不误伤 | Pass（合法受控上游语义）。真实统计范围属于T22，不把假usage当认证 |
| 稳定P不重tokenize及同wire百万范围 | 独立actual Tiktoken.encode范围断言；旧基准1000019实际tokens/8000495bytes同wire，历史计量0/新增6；新withRun服务full0/fresh2补集成 | 复用原有限性能Pass，无需重跑无变化样本；非37型号/图像/真实1M供给/端到端全部性能认证 |

## 唯一必要补证：同物理日志两条合法候选的因果/到达区别

依据为现行 U16-V6 的具体命名输入“乱序到达、更新但非祖先”，并非为了穷举新加维度。原独立测试 `acceptance-calibration-source` 虽标题有candidate reordering，正文实际只有 `[original,original]` 重复及把selected entry换成D等非法输入；它没有两个不同合法候选。新withRun是同Run串行三轮；跨session并发不能替代同日志这一点。因此T19/T20在这一个共享门上仍留未证，不报缺实现。

最小施工（runtime历史消费/ demo来源owner，同一个新增表即可）：真SL3放入两次不同调用的合法D及各自完整M/R，确保每个单独都可成为合法观察；有限具名selector明确当前实际选入的messages/locator（非trusted boolean），安排其中较晚物理提交的B不在当前祖先，A为较早合法准确I。调用实际来源解释＋authorizedCalibration，核得到A原I与原locator/组、B不能推进anchor；把另一个实际合法选入顺序/完成先后作为表中对照，核按明确因果来源而非R物理时间/最新position选择。将B非法塞进当前candidate或将两个真实candidate颠倒所要求顺序时按当前契约拒绝，不静默repair。对后续公开planner至少核稳定前缀不会因B而错扣，或精确核calibration返回A原值作为此责任边界oracle。

可用现有prepare/settlement与授权owned-prefix构造两条真实合法批，合法选择是明示的有限受控来源输入；**不要求实现通用Run分支引擎、压缩器、治理、AgentLoop，不要求再把全部65项跑到每个分支**。若owner能给已经存在的同等实际test body＋运行日志，可直接替代新测。此小用例通过后，本报告未定位另一条T19/T20必须新增门。

## 不混入这两项的其它责任

- T21每家full/phi/delta适用算法与所有绑定准入；T22 37模型public/service及真实OR usage/cache/cost认证，各依原门继续。Pro保守scope_unknown通过不意味着其真实I可校准。
- U16-V12完整CLI多轮/切模型/图片工具/查询用户流程超出TODO T19/T20本次具名矩阵。已有两处仓外runtime校准literal通过仍保留，不能因此宣布整个CLI或全部U4交付接受。
- 生产Run因果owner、不同call无reply没有显式因果边时保持sourceUnavailable/更早源；这是已采用能力边界，不作为本轮必须造出的功能。
- 原百万planner样本不扩成所有型号、图片或runtime端到端同倍率提速；无变化不重跑性能。

## 回读SHA与实际命令

本次只执行 git branch/HEAD、rg/sed读取测试/源码、Python tarfile读取指定regular members并SHA核manifest、读取明确root日志。没有运行付费或重build。旧归档以下成员已逐项hash-match：

- `tmp/calibration-acceptance/README.md`: `7f6898c3435b829ff79b8447af2f61a7cc599e4ea462bfb344e1f43a988a3f35`
- `tmp/calibration-acceptance/transport-final.log`: `65ac184129d97f57fe65962b2b002fc8325c662c5ee094668ce43c213c63549e`
- `tmp/calibration-acceptance/runtime-final.log`: `310eac572eaf81e27d5de5db658c19672fe92f4b94bec0e25faee5bafad1acfb`
- `tmp/calibration-acceptance/demo-final.log`: `b21105ad5cdecaf3bdb38764221bf64b31c5b72c091abbaf2a02896f2ff40fc9`
- `tmp/calibration-acceptance/service-complete.log`: `1593f9662e6f689e9ac3bc56e25a77617f26e7d2d0fc00cb6c490e52e0f81518`
- `tmp/calibration-acceptance/pro-independent-4.log`: `799146c84c4d97c76cb96653b5871ca5da562be016c292f34f22629d42894214`

当前HUB关键输入：

- `tmp/model-request-runtime/vendor-completion-root/withrun-three-turns-final.log`: `2fcc26a367e743656c0da8df20c4327f7c8f9126926cfd2999df4fc60010ffde`
- `tmp/model-request-runtime/vendor-completion-root/withrun-three-turns-typecheck-fixed.log`: `ec241ba0298653129191b60438043f57a191c2f3f3e84105be1360e6d7c44c19`
- `examples/model-invocation-minimal-demo/tests/runner-service-with-run-calibration.spec.ts`: `988edf32c1a3dd033d8460dc2cc068a243a63cb64b89cdeffc515f58ada82fac`
- `packages/model/model-request-runtime/tests/acceptance-calibration-source.spec.ts`: `aac6421e7fba6a4f56a0f5862f6652f73592151ba10eadfb63d0dca53154ef92`
- `packages/model/model-request-runtime/tests/service-calibration.spec.ts`: `c0aa562bf5c8d55897145cbcdc55118771d5e5aeb099b9da32530d77ad2bdfc0`
- `examples/model-invocation-minimal-demo/tests/acceptance-calibration-service.spec.ts`: `60479a9fa73d90b7160704316db4f12177b289755f2795c075be7c617d18c8c1`
- `examples/model-invocation-minimal-demo/tests/acceptance-calibration-cold.spec.ts`: `7ed36a089a335c0e52ee2db7250d5120bde7f1179ef22ee1add659bc5957c8a7`
- `.meta_harness/design/realization/packages/model/model-request-runtime/verification.md`: `eeb15c9ec48ee9a5af965a961b05360134bacb8bdda75ebc2455ce7ea815f779`

本轮无消费者、进程、reader、writer或租借资源需要释放；root最终验收。
