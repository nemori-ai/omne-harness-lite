# 最终追加复核：a3697a05

**最终结论：Pass，建议 root 关闭 T09/T10/T15 的原有限模型纵线义务。行为门与本次类型门均已完成。** 下文原报告的 A2/A3 未覆盖结论已被本节新证据替代，保留原记录供追溯，不再列为当前欠交。T08、C1/C2与A4及其已核边界继续复用，不新增外域Run/Loop或T21/T22前置。

本次只读 HUB `panqiwei/model-request-runtime`，HEAD `a3697a051ab0978e1eca859abd72f590934742b2`，未build/运行测试/修改产品。新增实际测试体与主线运行日志逐项核对如下：

| 原剩余 | 新输入与实际判别 | 最终有限结论 |
| --- | --- | --- |
| A2 完整耐久同prefix历史 | 9006c5e7 的 `runner-service-retry-after-wait.spec.ts:271` 从实际P5耐久结论取原default，经真实judgeConclusionForSubject、prepareRunnerConclusion、fenced SL3 append写custom、另一真实失败call的retry、不同anchor同值default；真实完整read读得第一call `[original,custom,original]`、另一call仅crossCall，再由实际runtime readAttempts消费source逐值核对/verify/release | Pass。真正物理历史补齐，已不依赖callback数组或subject篡改冒正向；原source固定/无关追加/变化subject拒绝的已验机制继续复用，不要求这里再全交叉 |
| A3 明确等待后第二发 | 同文件:398，fixture真P5产 `PT0.5S`，caller实际sleep550ms后原call/attempt dispatchAgain；真实第二TLS请求、replyPending仍原call，真实persist后两dispatch，旧log前缀完全不变 | Pass。等待责任在测试caller，不声称实现AgentLoop |
| A3 事后限额不可用保留retry | 同文件:432，经实际publication改变limits及app.prepareModelInputs更新EIS；纯guard仍allowed，但dispatchAgain重新现读返回unavailable，实际日志不增、HTTP仍1、awaiting_decision及原retry保持 | Pass。与原已验release→alreadyEnded共同覆盖已派后置门，不重复扩所有失败组合 |
| A3 全联合薄映射 | 05611e15 生产judgeCapabilities直接调用同一 `projectRunnerRetryGuard`；guard-map.spec.ts 7行分别为allowed/refused原why/alreadyEnded/callNotFound/wrongPhase/invalidInput/unavailable，exact toEqual不补why | Pass。薄边界表配当前真实allowed/ended整链；不冒七次独立TLS装配 |
| 双语配套文字 | 同提交README/README_ZH对计划after等待、后次重读限额且保留retry、无Run与受信单Run选入链表述对应 | Pass（有限说明对齐），原实际制品门继续引用A4 |

原始运行：`luna-service-runner-prefix-final.log` 2文件15测通过（含本文件A2/A3及另一组，不将15都归A2）；`runner-p5-wait-limit-final.log` 1文件2测通过；`runner-final-guard-map.log` 1文件7测通过。都是 root 实际运行，本次只读核断言而未重跑。

类型：`runner-final-guard-types.log` 的首次失败已读，实际为并发transport build缺pi-ai-transport dist/declarations及其下游推断报错，原日志保留。`runner-final-guard-types-after-build.log` 当前仅正常tsc命令头、无错误，且未见对应活进程；这些现象本身不证明exit 0。随后 root 已从原执行句柄 42902 取得完成结果 exit_code=0（本代理收到明确消息），故类型门通过。这个退出码是主线执行证据，本代理没有冒称自行重跑。原失败不删除；主线最终责任不转移给本报告。

本次关键输入SHA256：

- `examples/model-invocation-minimal-demo/tests/runner-service-retry-after-wait.spec.ts`: `39a56277f119ba9c7b7e4c53ed71fa582677a4b9907f748e4dc603f310c68f77`
- `examples/model-invocation-minimal-demo/tests/runner-service-guard-map.spec.ts`: `7067121300abcf265dfa50cfa63727559dbf1defec4dadb65136565004a9f8b2`
- `examples/model-invocation-minimal-demo/src/runner-service-host.ts`: `1e7528e94085b68c452ea680fda76f4a30ecb63923140525ba79097672442e92`
- `tmp/model-request-runtime/vendor-completion-root/luna-service-runner-prefix-final.log`: `0a349bad45ccb858d1195dc78e13f144ce7e1eaf6647dda17f5ddd7cff813f25`
- `tmp/model-request-runtime/vendor-completion-root/runner-p5-wait-limit-final.log`: `0ca9d0cea5e83c32f43e1b08abcf15386ff7aef28c69cdb616f9c610e3ccc189`
- `tmp/model-request-runtime/vendor-completion-root/runner-final-guard-map.log`: `e6de0e8e7e95102210e7a018beb4e16ebae168feeb6bdc7bd01cda2d1599ce6a`
- `tmp/model-request-runtime/vendor-completion-root/runner-final-guard-types.log`: `e224bb6f1a32870a89cd2843364fcb554e01a99f19dbd579190cbad76c760e0f`
- `tmp/model-request-runtime/vendor-completion-root/runner-final-guard-types-after-build.log`: `ec241ba0298653129191b60438043f57a191c2f3f3e84105be1360e6d7c44c19`

本轮无消费者或借用资源需释放。T19/T20另待指定f35901b4集成证据，不在这里抢先接受。

---

## 保留：68b49260初次收口记录

# T09 / T10 / T15 独立有限收口复核

结论：**C1、C2、A1、A4、B2 可关闭；T08 已单独 Pass。T09/T10/T15 目前仍有两个明确组合门 A2/A3，暂不能整体关闭。** 这是验收证据不足，没有新定位产品逻辑缺陷，也不要求新设计或完整外域。主线 root 最终接受。

本次在 HUB `panqiwei/model-request-runtime`，起始 HEAD `68b49260a8da01cf79aa096c4cea7df3a81e1c65` 独立只读；未运行 build/test、未修改源码、已有测试或正式设计。读了 runner-assembly 原 `tmp/runner-assembly/T09-T10-MATRIX.md`，其作者矩阵只作导航。`8a9cb016` 在本次输入为待合：其声明的 captured subject 篡改负控不能计作真实 durable 三变体正向，不拿未来合入结果充本轮证据。

## 已具名门的变更读数

| 原门 | 当前实际依据与范围 | 判断 |
| --- | --- | --- |
| A1 / R7-V5 / F18-V1–4 原Run归属 | demo runner-service-assembly:175 原调用携真实受控Run、attempt与report，先有真实fenced MS6；本地TLS503的原D/R，再由实际readAttempts source交实际P5；缺Run/另一Run/错actor/session/改主体均在external acquisition前拒绝。:350另真noRun失败不能包装Run；runtime原来源与runner自有execution的类型/负向门已由前轮核定 | **Pass**。7595c196原缺陷已被替代，不再重开设计 |
| B1 / M17-V8 来源借用生命周期 | 实际source.release失效、实际host.stop后不再消费、runtime.close仓外验证；runner service真实fiber撤除/依赖撤除仍持任务至stop及unknown重开已在原报告逐体核查。scope.release闭包实际释放source，异常与不可用路径亦调用 | **Pass（既有借用生命周期）**。按root已明确边界，不扩每次verify重评组织未来政策；不声称生产授权订阅实现。有限受控await/宿主任务证据可复用，无需每种await再做全包交叉 |
| B2 / M17-V10 P5配置换代 | runner acceptance-public-matrix:1157 真Cordis P5，旧policy/sample捕获后改对象仍PT0.5S；注销/新贡献PT6S；旧迟到输出不能提交retry。HUB runner-v8-p5-generation-tests.log 1通过，394跳过不计通过 | **Pass** |
| A4 / M17-V12 新runtime scope字面制品 | 本代理已执行双语仓外c42 tarball原样inspectFailure，各strict compile+9组运行；normal无资源，终于release、Run身份/关闭失效。原P5登记制品证据仍只覆盖不变的真实registry/factory面 | **Pass（已指定最小制品门）**。不把旧registry tgz说成新failure签名制品 |
| R7-V1/V2 E链/租户历史 | 原真实SQLite AR/MF/EIS链、同E引用/版本拒绝，demo实际认证STT及真实目录/owner接线，本次合法withRun成功已解除原源缺陷 | **Pass（限定模型消费者）**。外部Run/卡片未建不作缺席成功的免责，也不阻合法条件正向 |
| R7-V3/V4/V6/V8 生命周期、登记、纯replay、unknown | 原service.spec真实重复启动/卸载/日志换代，物理delayed append/datasync unknown/可信absent与合法异值winner；当前demo真实P5结果replay保持原log、external acquisition/HTTP均不增 | **Pass，复用原已核组件+当前装配**。不新增OS/全Loop恢复认证 |
| M17-V7 三重载及同prefix普通/技术面 | runtime service-dispatch现在实际withRun dispatch/read/dispatchAgain三路径产生source，普通结果无资源；demo :278实际readAttempts识别1条真实runner retry | 该部分**Pass**；完整durable重复/custom/cross-call仍属A2 |
| R7-V9 缺席外域源 | missing external等unavailable，noRun失败位置拒绝；当前受控Run是构造期明确事实条件 | **Pass（条件消费）**，不宣称G28生产者交付 |
| R7-V7/M17-V11 事后重守卫 | demo :299 allowed；实际releaseCall改变durable phase；canDispatchAgain与dispatchAgain均alreadyEnded，原retry/log保留、HTTP仍1 | 这个**停止/终态负向Pass**。A3剩余见下文，不能继续称“没有任何P5后重守卫组合” |

## T15 两个额外补口已闭合

- **C1 Pass**：`acceptance-t15-resume-planning.spec.ts` 用真实SL3原D与实际reconcile得到resumable（前任absence为明确受控输入，未冒SIGKILL）。:310 三类新输入拒绝：图像进入真实dispatch规划，工具两个先由openCall早拒；再用合法输入+受控planner返回两工具拒绝检验历史dispatch分支。每次原entries完全不变、requests/sends=0、仍resumable；修正输入后实际HTTP一次、第二D；:383 release只新增ended{released}无cause/R，再release alreadyEnded。原C1允许此早拒/下游拒绝的分项证明。
- **C2 Pass**：runtime `acceptance-t15-fresh-dispatch-inputs` 真实SQLite/EIS发布新两个limit，scheduler实际收到7000/9000、same-call新凭据与原snapshot不变、当前输入不可读零新增、缺凭据仅released。新增demo `acceptance-t15-credential-rotation.spec.ts` 补实际custodian publish→同call第二TLS发送，服务端Authorization仅SHA比对旧/新，真实SL3两次D的adaptation/profileSnapshot/parameters不变，最后settle consumed。此前受控credential port的组合限制已由此一条正向补齐。
- 实际日志 `t08-t15-final-gaps.log` 3文件9测/类型无错；`t15-credential-runner-final.log` 2文件3测通过。与已读5文件7测及demo typecheck日志交叉引用，不相加、不当全矩阵计数。本次自己没有重跑。
- 原13方法逐条表 `REPORT.md` 继续有效：首四选择、ordinary readAttempts等无独立缺实现；dispatch/dispatchAgain/resumable/release的C1/C2标记可改闭合。T15目前只承接下列T09/T10的既有适用组合，没有第三个新泛化任务。

## 仍必需的最小两个任务

### A2：原完整prefix里的真实durable重试历史

采用坐标：runtime verification **M17-V7**，runner verification **R7-V5**，RT10 S-76、Runner5 S-53/S-54；明确要求原full prefix真实runner retry项同值重复/custom/cross-call、顺序完整、不能第二尾补证。

当前 `failure-subject.spec.ts:58–116` 的重复两项来自回调subject常量；runner `pure.spec.ts:146` 两项来自prepared arrays；demo实际只落一条P5结论；8a9cb016仅篡改已捕获subject。这些分别有用，但没有执行被要求的合流。

**owner：demo装配（消费runtime/runner现有公开面；不需修改产品）**。在一枚真实owned JSONL前缀内以合法不同anchor落两个同值default retry、一个custom retry及other-call事实；实际 `readAttempts(...,{consumeFailure:true})` 经 `readDemoRunnerFailure` 读取：同call三项顺序保留、other-call排除；旧source在合法无关追加后仍认证旧主体，新read得到新完整历史；遗漏/重排/拿另一尾subject不能被旧source认作同一主体。重复计数/自定义不算default已有纯政策断言可复用，不要求这里扩全政策表。可以复用真实public prepare/append构造有限durable事实；不能直接把数组注入history callback冒充物理来源。

### A3：P5已落重试的后续执行及拒绝

采用坐标：runner verification **R7-V7**明确“事后限额拒绝保留既有retry事实”；runtime **M17-V11**明确“确认retry后显式调度等待，再dispatchAgain重新guard”；RT10 S-30 after由caller等待。当前source中的正确代码不替代运行证据。

**owner：demo装配，runtime owner供现有EIS fixture；runner owner仅可协助薄映射测试。** 复用当前真withRun/P5 fixture，保留现有release→alreadyEnded作为停止拒绝：

1. 一条正向取得实际P5非零after，调用者明确等待/受控时钟调度到期后调用原call dispatchAgain，真实本地TLS第二发，原耐久retry不丢。无需构建AgentLoop或另一个模型服务。
2. 一个后置输入拒绝：P5 retry已落后，真实EIS当前两个limit缺失/非法/不可判（选一有辨别力反例即可），实际dispatchAgain unavailable、无新D/R/HTTP，原retry保持。C2单独无P5事实的拒绝可复用其它分支，但不能冒此已落事实的组合。
3. 同一个小任务为 `runner-service-host.ts:268–280` 的canDispatchAgain联合映射补薄表：allowed、refused原why、alreadyEnded、callNotFound、wrongPhase、invalidInput、unavailable。实际runtime guard真状态/优先级已验，无需为每行再建完整TLS；薄adapter受控typed union输入可证明原值/无why不补，然后复用当前整链allowed/ended两个真实路径。

**不新增要求**：不要求上述两分支再交叉所有凭据/partial/unknown/tenant组合；原模型测试已覆盖那些机制，不要求重复37模型、生产Run/Loop/card或三轮marginal认证。A2/A3补齐并经主线实际日志后即可按此有限边界复核T09/T10/T15，不另起开放式覆盖扩张。

## 输入与释放

本轮仅写本报告，没有持有消费者、进程或资源租借。以下SHA冻结本次实际读取的关键输入；运行日志均为主线原证据，本次不是其独立重跑。

- `tmp/model-request-runtime/t15-final-matrix/REPORT.md`: `7bd6682e0120a764ada27fda04cc32c6e31e7a07a32f6ec524d472cc8ff66dd6`
- `tmp/model-request-runtime/t15-final-matrix/T08-FINAL-REVIEW.md`: `48faf4ea84252570178d1d50f3e4ab424fe40ca70758b5dfe7048fdf9588dcff`
- `tmp/f18-artifact-acceptance/REPORT.md`: `46509ffe4966c32e16c94e0ee58016fa25d62b8019d829cbbdcf9f850a1e7561`
- `packages/model/model-request-runtime/tests/acceptance-t15-resume-planning.spec.ts`: `2a7724da8dc298d1b7e7eb9c1a2eadf94ef1a632d07b35d72f3d4234360561c1`
- `packages/model/model-request-runtime/tests/acceptance-t15-fresh-dispatch-inputs.spec.ts`: `af4a8f62a3dad83d3974977a73499e94c6ac9c1256bb2521432a855974a983ee`
- `examples/model-invocation-minimal-demo/tests/acceptance-t15-credential-rotation.spec.ts`: `2ae8d08c15db1f0da4811e8c68c27980291e463bd7b532c109df6cc913420eb8`
- `examples/model-invocation-minimal-demo/tests/runner-service-assembly.spec.ts`: `22c990ac8710b7ef2c02490cc2991f3fe5283f05dfa18c7e4b1df8f55b97e508`
- `examples/model-invocation-minimal-demo/src/runner-service-host.ts`: `c5eba423e738153ff1dbf4e38bb2eb68f78e11dfe955949a36572d358e6011bd`
- `packages/model/model-request-runtime/tests/failure-subject.spec.ts`: `a1e525ba435640ef239c3e6b56298f735cf3ccd984697e43cfe2920ed575539d`
- `packages/agent-loop/loop-extension-runner/tests/pure.spec.ts`: `a15790026ebc8c9210089ddc052afc8d4b9e651415698716f1ac72ba3b1a6bf5`
- `packages/agent-loop/loop-extension-runner/tests/acceptance-public-matrix.spec.ts`: `4960af15f2a6fffb1c722a768c86ee1330870f2579bb5d4f43f550e26d6f5e99`
- `tmp/model-request-runtime/vendor-completion-root/t08-t15-final-gaps.log`: `a7e1cd9719f0c85a47cf799c180fd564a2349b24409ab835e1e65434c32cb8d5`
- `tmp/model-request-runtime/vendor-completion-root/t15-credential-runner-final.log`: `0982f80a34793e3fc5014e9eeef43b6c0b11722a6bd8575e3043f1c82afd931c`
- `tmp/model-request-runtime/vendor-completion-root/demo-v18-exact-attempt-tests-data-tmp.log`: `f408f7e4b42a593f8cb3ba78122a67778acdd7994938aef8749aa7e811a41360`
- `tmp/model-request-runtime/vendor-completion-root/demo-v18-exact-attempt-typecheck.log`: `ec241ba0298653129191b60438043f57a191c2f3f3e84105be1360e6d7c44c19`
- `tmp/model-request-runtime/vendor-completion-root/runner-v8-second-tests.log`: `d8568f4308d97a669f20cdcd4b27888f31caf7a0bd62bdb30d0f4b9789df8289`
- `tmp/model-request-runtime/vendor-completion-root/runner-v8-p5-generation-tests.log`: `633243b47ee8a9aeadb7b9a0007d01e28b910c6e6917bddbfb4ecba645d3ac73`
