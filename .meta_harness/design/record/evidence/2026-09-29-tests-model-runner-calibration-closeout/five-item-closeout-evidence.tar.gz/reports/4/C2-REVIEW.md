# C2 cb25b8b7 独立只读复核

结论：**runtime 每次现取与当前设置的组合断言已补齐；生产凭据提供者同 call 轮换组合尚未执行，仍留一个窄验收点。** 没有定位产品缺陷，不要求新设计、完整凭据服务或扩大外域。

被核提交 `cb25b8b767ea6818fc57b4c532566c52fe35ce0e`，新增 `packages/model/model-request-runtime/tests/acceptance-t15-fresh-dispatch-inputs.spec.ts` 336 行。本次读实际 test body 与接线，未重跑测试/构建；作者/主线运行结果须仍由其原日志支撑，不能把本次阅读写成独立运行 Pass。

| 承诺 | 新测试实证设计 | 核查结论 |
| --- | --- | --- |
| RT10 S-21:589–599 / S-29:773 当前完整输入重新求值 | 真实 selectionHost SQLite/EIS publish 两个新 limit，同 call 第一次失败后 dispatchAgain；观测 scheduler 精确 7000/9000 | 实际门已由新 oracle 覆盖，不必另要求两项自然等到超时 |
| S-19:565–572，每次现取租户/origin 凭据，不缓存 | currentCredential 受控闭包第一次旧值→第二次新值，send 捕获 SHA；实际 HTTP 请求数 1→2 | runtime 端口消费覆盖成立；不是实际 custodian 发布轮换，也不是 TLS 服务端已观察授权头 |
| 原绑定不变 | 两次 plan.input snapshot/parameters/adaptation 相等 | 原承诺覆盖 |
| 当前输入无法读 | 原日志完全相等、HTTP 仍1、credential观察数仍1、awaiting_decision | 零副作用与原状态覆盖 |
| 现取凭据缺失 | 第二次仅 ended released{credential_unavailable}，无第二 dispatched/response/HTTP | runtime 负向覆盖；缺值由受控 port 注入 |

权威边界：`tmp/model-request-runtime/IMPLEMENTATION.md:207–209` P4.2 明确放行“每次重新取实际设置/凭据”；RT10 `contract.md:568` 明确“凭据轮换零通知，下一次发出就用新值”。C2 原 brief 明确真实凭据。不能用两处分离测试声称那个组合已经执行。

可以直接复用且无需再造的证据：

- `examples/model-invocation-minimal-demo/src/bootstrap.ts:1174–1192` 从真正 Cordis CREDENTIAL_LOOKUP_SERVICE 取得 lookup；`:1495` SessionRuntimeBinding 直接 `credentials: lookup`，未复制某次值。
- `packages/model/model-request-runtime/src/service-dispatch.ts:1134–1145` 每次 prepareSend 先 currentDispatchTiming，然后以原 tenant/profile.origin 调实际 `.value`，未缓存 credential。
- `examples/model-invocation-minimal-demo/tests/acceptance-d4-scopes.spec.ts:323–344` 真 `app.publishCredential` 新 sourceRef/新 body 后同租户真实 lookup 返回新值；旧已借用 bytes 保旧值。
- `examples/model-invocation-minimal-demo/tests/model-service-retry-control.spec.ts:123` 真 demo/SL3/TLS 第一次503、相同 call 第二次成功，能复用完整装配与 finite owner。

这些组成很强的可组合正确性证据，没有相反源码。但其运行断言分别缺少“同 call 活着时生产发布新绑定→第二实际发送所用值”这个交界，故将其记为未执行组合，不能误称已有或已发现失败。

最小补口只有一条正向（demo 新测试，root 调度写者）：沿上述 retry fixture、实际官方合法 profile，第一次TLS503得到 awaiting_decision；对同 actor/tenant 调真实 `app.publishCredential`，使用不同受控 sourceRef/body；原 call `dispatchAgain`，本地 TLS 服务端仅断言两次 Authorization 的安全 SHA 为旧/新已知测试值。保留 callId 及 profile/params/adaptation，实际读取原两次 dispatched/response，退出真实资源。用现有 app API，无新 credential port / setCredential 替身，不输出密钥明文，不需付费。不必复制三个 runtime 分支，也不必把当前两个 limit 再改一遍；新测试只补真实提供者连接在同 call 中的轮换。
