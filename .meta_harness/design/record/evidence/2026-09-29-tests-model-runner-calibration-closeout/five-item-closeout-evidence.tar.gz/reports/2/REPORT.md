# T15 十三操作最终矩阵准备（独立只读）

结论：十三方法均有真实源码和既有运行证据，不能称“缺实现”。现阶段不能整体关闭 T15；除已经派发的 T08/T09/T10、A1–A4 外，本次只定位 **两个可合并执行的小型验收任务 C1/C2**：续接后的规划拒绝与 resumable 放手；同一调用再发时更新当前时限/凭据。它们是尚未定位到足够辨别力的组合证据，**不是已证明的实现缺陷**。首四个选择方法、普通 readAttempts 未定位到另外的实现缺陷。

仓库 `/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime`，分支 `panqiwei/model-request-runtime`。进入 HEAD `6297fea47b70c8084edc2c55ce9d36f284155089`，证据捕获 HEAD `703a119effafdc212286df6aadc51d147f3dea9e`；期间只有 root 合入 runner 用例增量，所核十三方法产品文件未因该提交变化。工作区 tracked 状态干净。本次仅写此证据目录，没有 build/test、网络、凭据、账本访问，也没有创建常驻进程。

[inputs.json](inputs.json) 固定 66 项实际源码/测试/规范/日志 SHA；[capture.log](capture.log) 记录分支、HEAD、清洁状态。本报告是最终执行矩阵的准备和现有证据对账，不承担技术接受。

## 精确范围与判断口径

输入为当前 TODO T15、rev7 排期原完整 D3（其 IMPLEMENTATION.md D3/P4.2/P5 原范围仍保留）、已接受 RT10 S24–34/S49–50 及 S68–76/S80–81、runtime README 的现行 v17/v18 **采用追加**。保留候选正文中的旧“未采用/未实现”不是当前状态；本次不另起设计。

每条“已覆盖”仅指表内具体行为；运行测试数不替代覆盖。共同身份/生命周期门可沿真正共享实现复用，不要求把 13×所有失败的笛卡尔积冒充必经矩阵。全量最终集成、更新签名后的实际制品仍须 root 安排。

- `createModelRuntime` 在 `service-runtime.ts:124` 将十三方法组合到同一 store、读面、控制及结算构件；关闭统一截准入并等已登记任务，不能另建第十四操作。
- demo `bootstrap.ts:2077` 的 `boundModelService.invoke` 对每个方法统一核固定 session、实际 `sessionAccess(actor,session)`、recovery admission；身份由真实 auth/STT/tenant 提供，不能只看 raw public function 未重复鉴权就称漏洞。当前全部十三 wrapper 均走该门，三个技术重载保真另归 T09。
- 无 Run 的选择/查询不依赖 Run 生产者。合法具名受控 Run＋真实 owned prefix 可以验条件行为；完整 Run/AgentLoop/卡片 owner 不在 D3 本模型纵线交付范围。不能以外域未建把本地成功面都改成 unavailable。
- **取消轴**：只读方法没有单操作 abort 参数，适用的是 owner/实例关闭、未停任务留存和租户隔离；不适用模型 socket abort、retry 或 reply settlement。`selectModel` 是命令写方，适用未知写入责任而非模型取消。`canDispatchAgain` 不做网络/计时/凭据取值，allowed 也不是未来发送许可。

## 十三方法逐项矩阵

简写：R=`packages/model/model-request-runtime`，D=`examples/model-invocation-minimal-demo`；所有文件和主要运行日志见后文证据索引。源码存在性已直接读文件，不由测试名称推断。

| 方法 / 精确义务 | 现行源码 | 正向与拒绝：已读实际断言 | 身份、取消、重试、结算、恢复适用轴 | 结论 / 尚未覆盖 |
|---|---|---|---|---|
| **legalTargets — S24/S11/S66**：每次当前合法集合；缺任何必要来源整次 unavailable，不空集/部分集；model 锁不缩合法集合 | R `service-reads.ts` selection→`session-selection.ts` legal→共有纯 selection | `session-selection.spec.ts:19,70,198,400,674,745` 真 SQLite/EIS 现读计数、model 锁变化、缺模型项合法、foreign/ineffective/current不可读不空集、真实图投影不合文本模型。`service-reads.spec.ts:242` 公开服务相同集合、0凭据取值/transport | 实际 holding tenant/受控 foreign 回包；旧 generation/close拒绝；只读，无重试/结算/网络取消。恢复后现读重新计算 | **已覆盖代表正反，无新增独立缺口。** 最终共同集成门待 root，不冒缺实现 |
| **displayList — S25/S12**：每名一行、winner/covered/selected/注记完整，selected缺行 profileNotFound，缺源不省条 | R `service-reads.ts`→`session-selection.ts` displayList | `session-display-list.spec.ts:8,108,168,197,259,309` 真组织/租户/官方覆盖、credential metadata绑定/解绑仅注记、选中withdrawn保留与relist、selected模态不符仍列、missing/不可读正确区分、generation在presence await中撤除留存真实stop；`service-reads:242` 两行selected布尔准确 | tenant/scope回包隔离；presence不取密钥；同一真实日志重开仍选中。只读无retry/settlement | **已覆盖，无新增独立缺口。** 未声称对所有模型逐行重复认证 |
| **effectiveModel — S26/S10**：现selection→层锁→落点；selectedBy按锁存在（同名也算）；不做出门合法性，不回退初值 | R `service-reads.ts`→`session-selection.ts` effectiveModel | `session-selection:115,167,198,638` 无selection unavailable、同名/异名锁、缺optional model无锁、缺行/关闭来源不假默认、实际scope最具体落点与撤回后落点改变；D `model-service-faults:225` 在途已绑定layer_lock不随当前源解锁改变 | 授权/租户共同门；generation撤除；重开从耐久selection读。无发送取消/settlement/retry | **已覆盖，无新增独立缺口** |
| **selectModel — S27**：合法再判重复；一次selection追加；重复合法零写；已撤回同名不成功；未知不能断言旧selection/未提交 | R `service-reads.ts`→`session-selection.ts` selectModel及owner | `session-selection:115,235,275,306,332,367,447,480,550,600` 实际codec单记录、reopen、合法重复零写、withdrawn拒绝、lost/malformed ack、可信absent、晚writer与actual stopped分离、stop rejection保owner；`service-reads:177,242` 同一写方留存 | 只交付命令路径；真实tenant在entry壳；unknown writer不因读到缺席释放。N/A模型socket/回复结算；并发合法窗口是S27明确允许 | **已覆盖，无新增独立缺口**；不将未知写入当恰一次保证 |
| **openCall — S28/S53/S74/S80**：新call绑定原basis/target/profile/params/lease；检查次序；缺源零写；报告/工具身份；resume取原精确绑定且可更新messages/tools/report | R `service-calls.ts:195,514,531`，call-tools、container | `service-calls:121–279` capture、changed target缺provenance、Run/report/observer身份、停止前及bind await中停止无late publication；`:325+` acquire lease/invalidInput/unavailable三分不造锚。D `model-service-faults:84` 真跨tenant、未知工具来源、缺凭据undispatched、非UTF8零HTTP；D4 `acceptance-d4-lifecycle:345–535` 真SIGKILL→原A缺失不回退B→恢复A用同call续接；`call-tools:216` 真registry原report snapshot不回退current | 未出门open不耐久，重复打开两call；stopping保实际prepare关闭；withRun合法来源/报告归 T08；固定A生命周期D4已验。resume非法新输入须下次plan守卫 | **已有正反/真实恢复；C1待补 resume新输入规划拒绝**。withRun最终组合 T08 pending，非缺整个open实现 |
| **dispatch — S29/S15–17/S21/S74/S80**：open/resumable；当前时限/现取凭据；固定计划→dispatched→HTTP→opened→可见；回复pending或失败R；开口过不再发 | R `service-dispatch.ts:319,1016,1100`、anchored invocation、共有coordinator | `service-dispatch:132+` 真SQL/SL3两个锚在交Pending前，规划cap/orphan拒绝零新增、failed主体；D `model-service-path:15` 真授权TLS与M/R原批，`model-service-retry-control:288` 并发同call仅一次物理发送；`faults:225` 固定snapshot不随当前变；D4:345真实resume发送仍A。anchored `:484,650,1148` 最终参数/owned凭据与身份门 | 首内容门/未知opened不交内容；D `model-recovery-host:31` held HTTPS实际stop再drain；冷恢复opened保时间不重发。withRun/fence/late归T08 | **部分Pass；C1 resume规划拒绝，C2同call当前时限/凭据辨别组合未覆盖**。新source签名T09集成pending |
| **dispatchAgain — S30/S50/S74**：awaiting_decision；终态→already_spoke→phase→fact_class→provider顺序；after由caller等；允许后重新现读/plan，不幂等 | R `service-dispatch.ts:254,1053` 复用 dispatchGuard与run/prepareSend | D `model-service-retry-control:123` 503→同call第二真实HTTP→消费settle；malformed多字段plan、forbidden provider、terminal拒绝均无新增；`:316` 并发retry仅一次新send；`:354` 已说话failed中断再发拒绝；R `service-dispatch:97,113` fact类/provider与终态顺序 | actual reader/socket停止沿同dispatch；retry始终保原binding；失败完整scope及Run身份归T09；P5已落retry后重守卫归A3 | **已有真实重试，C2仍待；A2/A3/T08–10 pending**，不由T01只有拒绝dispatchAgain误称正向已验 |
| **interrupt — S31/S36/S81**：仅call；意图先耐久再abort；before_dispatch/in_flight/speaking；reply_pending/终态absorbing；未知不能发信号 | R `service-control.ts:234,501` 共享read/write tracker | D `model-service-retry-control:244,386,427,479` open两call只断指定、pre-content与speaking真实TLS socket关闭、意图单条、带reply交pending再settle、datasync失败intent缺席无abort且send继续；`control-writer-uncertainty:366` 已知未提交不abort。R `service-control:212,284` 同一intent/unknown留owner，`:60,96` completion与stopped分离 | 系统stop走原system-stop非伪user；另一call不动；冷恢复意图优先见R reconcile:519及真实control/recovery证据；withRun真实attempt壳组件在`:33`，完整归T08 | **已覆盖本地主要阶段及实际取消；未定位T08之外独立缺口**。无工具/Run终结副作用为边界N/A |
| **releaseCall — S32/S81**：只awaiting_decision/resumable；released无cause；terminal吸收；unknown留责；不生成新响应/HTTP | R `service-control.ts:251,501` | D `model-service-retry-control:208` 真failed→released单条、同callrepeat alreadyEnded、HTTP不增；`control-writer-uncertainty:237,282` 真datasync+truncate连续EIO，SIGKILL真实exit后successor全扫原released，原字节不变/无二发。R `service-control:198` classifier明确resumable可放手 | awaiting_decision真实写/unknown恢复已验；resumable实际放手尚只有分类断言，不把同类状态推论当实跑。withRun普通control壳归T08 | **C1末尾补真实resumable release无cause**；其他unknown/control已有证据无需新恢复平台 |
| **reconcile — S33/S69–73/S81**：旧任务实际stop+完整原批优先；7行表；不发HTTP/不需旧实现；sentAt未知null；多call任一不明不返部分 | R `service-reconcile.ts:259,391`、coordinator/call-history | R `service-reconcile:519,593,658,751,805,932,973,1029` intent-only、unknown原/absent、writer关闭交错、opened null-send、原批优先、某call不可读整次不partial且重试只补剩余、真account/header留存；D `cold-supervisor:75,124,185,228,340,381` 真kill/exit/closed、opened时间/原批/迟到旧IPC隔离/先恢复后缺新credential、disconnect不是exit；`response-writer-cold-recovery:77` 真before/after response写EIO→kill/reopen原值或unknown补值，无重发 | D4真旧A不可加载仍reconcile resumable，再open才不可用；reply_pending冷丢失按opened，原批exists优先；withRun原attempt/current归账/late竞态归T08 | **真实冷恢复主要轴已覆盖；T08待最终有限Run矩阵**。全生产session lifecycle调用时机由外域，N/A重新实现它 |
| **readAttempts — S34/S76/S80**：完整同prefix，只读；仅内存open可无记录答；awaiting_decision必须完整failure；旧格式/缺源不partial；MR9新字段原样 | R `service-reads.ts:146,226`、call-history/source | R `service-reads:302,374,480` 完整empty→notFound、0credential/transport/append、日志不可读unavailable；真failed但retry源不可读整次unavailable，旧codec同prefix拒绝；`call-history:109,229,257,293` durable与volatile区别、跨call、gapped/orphan拒绝；D retry:123实际2次发出状态，U4原calibration保真/冷认回证据 | shared auth→samebinding；close等reader actual stopped；普通调用无scope；显式消费完整历史与新签名归A2/T09，不借普通只读成功关闭 | **普通只读已有充分代表证据，无另定位缺陷；A2/T09 pending** |
| **settleReply — S49/S17/S75/S81**：仅原收到Pending方；vetoed/consumed单R；persisted必须外部[M,R]原批；重复同处置认回、异处置alreadyEnded；不改reply/outcome/usage | R `service-reconcile.ts:124`、response-construction/coordinator | D `model-service-settlement:142,238,278,311,363,532` 真实TLS完整veto/consumed（无assistant）、persisted输入拒绝零append、外部persisted赢家、实际并发只一个完整R、A认回不干扰in-flight B、实际datasync+truncate失败unknown。R `service-reconcile:206,236,261` 相同/相异、malformed多支、unknown认回原值；U4真原calibration/异winner/冷恢复 | 原交接方由实际assembly给，不扩新授权协议；待确认scope不提前释放原writer；withRun late/尾条件归T08；after-reply runner功能归T10对应边界 | **已覆盖noRun实际双写方/失败/恢复；T08 pending，无另外独立缺口** |
| **canDispatchAgain — S50/S30**：共用守卫/优先级，只读，allowed不是持久授权 | R `service-reads.ts`→共享`dispatch-guard.ts`；dispatchAgainAdmission复用同核 | R `service-reads:302,374,480` absent/unreadable、终态/已说话/phase优先、failure-history unavailable不必阻只需guard事实的判定；`dispatch-guard.spec.ts` closed完整fact/provider/fallback表；D retry:123/354 actual allowed/forbidden/malformed/terminal/post-content拒绝，log/HTTP保持 | 共用session/tenant门；无credential取值/no scheduling，后次dispatch独立现判；与实际P5完整union映射归A3 | **普通守卫代表路径已覆盖；A3 pending，无另外独立缺口** |

## 已运行证据如何使用

以下均是已有 root 实际日志，本次只读而不重跑。log summary 不含完整测试名称时只作运行批次佐证，不单凭计数推断某行被执行；相应测试体定位如上。源码/版本变动后的最后一次整体集成仍未发生，不写“当前十三方法全绿”。

| 证据（HUB tmp/model-request-runtime 下） | 确认到的用途与限制 |
|---|---|
| `vendor-completion-root/thirteen-operations-integrated.log` | 1个同service真SQLite/SL3+两次本机HTTP综合场景；实际读 `acceptance-thirteen-operations.spec.ts` 后可见它的dispatchAgain只有拒绝，没有成功重试；controlled failure history空数组只声明本fixture无runner，不能认证G3。 |
| `m1-session-selection-final-hub/test.log`、`m1-session-selection-stop-hub/test.log` | 选择/关闭既有运行；当前session selection/display test体进一步对账。早期版本运行不自动成为当前所有新版消费者的完整结果。 |
| `vendor-completion-root/service-input-tests.log` / `service-input-media-recovery-tests.log` / `service-tools-tests.log` | 实际输入、媒体/工具、恢复相关组合；本轮读了对应工具/媒体/故障断言，不能把24文件92个总数当13方法覆盖数。 |
| `vendor-completion-root/interrupt-final-tls.log` | 实际TLS retry/control/settlement组18测的既有输入；本轮直接确认socketClosed与physical send计数断言。 |
| `vendor-completion-root/control-writer-cold-tests.log` | 3个实际EIO/释放/冷退出控制写方用例。原未知提交责任和真实SIGKILL收口可复用。 |
| `vendor-completion-root/d4-lifecycle-integrated.log` / `d4-scopes-integrated.log` | 各2测：旧A held调用/真实SIGKILL恢复原A、组织租户与配置/实际会员撤除。只读credential rotation不等于同call再发已经使用新credential。 |
| `vendor-completion-root/u4-cold-service-integrated.log` / `u4-service-integrated.log` | 新calibration原批/恢复/实际service有限组合；不据此声称withRun后继或真实统计范围全部认证。 |
| `vendor-completion-root/runtime-v17-last-recovery-tests.log` / `runtime-v17-source-matrix-tests.log` / `runtime-v17-astra-demo-tests.log` | 分别3文件87、3文件43、3文件11的真实后继组合；继续受T08/09/10逐义务范围约束。 |
| `vendor-completion-root/runtime-v17-tests.log` 与 `runtime-v17-postbuild-targeted.log` | 原全包4失败/675通过日志保留；旧dist原因后完整build并对受影响5文件65测通过已记TODO。本审查不把它改述成单次全包679通过，也不运行新的build干扰root。 |

## 除已派事项外的最小测试任务

### C1：真实 resumable 的新输入拒绝及放手（openCall/dispatch/releaseCall）

权威：RT10 S28 出门前检查末两段、S29④、S32。现代码 `service-dispatch.ts` 按耐久历史次数分流，实际已有实现；没有发现反例。已定位用例中，planner拒绝发生于新call `actual-call-2`；D4真SIGKILL恢复原A后只执行合法续接，resumable release只有 `classifyRelease` 断言。故不能把成功续接及首次拒绝相加，当成历史>0拒绝分支已验。

可执行最小任务：复用 `acceptance-d4-lifecycle.spec.ts:345` 的真实冷恢复构造（不重复37型号、不引入外域Run），得到已耐久发出+无opened+runtime_lost响应的 resumable call；分别给模态不可承载、孤立工具调用、ToolInternalMessage 三类新输入，经真实openCall/resume与dispatch走到实际适配plan。若某类按现有输入形状应更早在openCall拒绝，分别记录该前置门并用合法受控planner返回触达契约允许的dispatch最终拒绝面，不伪造历史状态。断言：原日志字节/既有response不变，零新dispatched/HTTP/response/ended；维持resumable，纠正输入后可以续接。独立一支 `releaseCall` 写唯一 `released` **无cause**，复调alreadyEnded且无HTTP。真实状态来源不得用 `forceResumable=true` 代替。

### C2：同call再发每次现取当前时限/凭据（dispatch/dispatchAgain）

权威：D3 P4.2、RT10 S19/S21/S29/S30。现 `prepareSend` 明确先 `currentDispatchTiming` 再 `session.credentials.value`，最终policy使用现读两个limit；代码存在。当前 `service-dispatch.spec.ts` 只断言 evaluationReads增长，schedule用空实现，不能检测仍沿旧limit的回归；D4 rotate测真实lookup旧/新值，hotupdate测public调用，不等于同call重试使用新值。

可执行最小任务：真实service/local TLS第一次先内容前503→awaiting_decision；发布新的两项时限和新credential后同call `dispatchAgain`，观察实际transport收到新credential（只比较测试已知值/安全hash）及真实scheduler收到的新两个精确limit，原snapshot/profile/parameters/adaptation仍等于第一次。另让当前输入不可读，断言零新anchor/HTTP/R且保持原状态；再让真实credential不存在，断言只写 `released{cause:credential_unavailable}`、不造新response、不发HTTP。这条可与A3宿主场景共享装配，但其oracle不能省掉；无需另造P5/Run设计。

**不加第三个泛化“全错误表”任务。** 共同identity/close与纯guard已有具体复用证据；未逐模型或所有状态排列穷举，不等于必须新写全部笛卡尔积。

## 已派 pending 与不适用

- T08：合法受控Run、attempt fence、same-prefix/late、原批恢复及新withRun calibration的实际组合。现行源码/组件正向存在，最终组合未接受，不因缺完整G28生产者拒本地条件消费。
- T09/T10 A1–A3：6c30befd来源修复和demo最终组合**待成组集成/复验**；实际执行上下文固定已有15d62bd3，703a119e又增加runner代际用例。本报告不沿旧Run挪用反例重开设计、不把旧失败正向重记Pass。真实重复/custom/cross-call retry来源和P5已落retry→重守卫仍用既定owner接续。
- A4：当前新scope signature落定后再做EN/ZH实际仓外制品最小门。旧P5 packed真实登记与U16 calibration文字示例分别只复用其原范围；本轮不打包旧签名。
- B1已由root澄清为已发source/scope真实owner release/revoke/stop/generation撤除，不扩纯verify同步重判组织所有未来政策；本次无新增治理任务。
- 完整Loop/Run生命周期写方、tool execution/card/waiting产品、另建source/计量真值store、37型号逐路径认证并非这些缺口的隐含前置；按原外域边界不适用。实际已承诺模型消费、真实batch和停止义务不能用N/A隐藏。

## 收尾与复核入口

可重放本次证据捕获：在HUB运行 `python3 tmp/model-request-runtime/t15-final-matrix/capture.py`；只写本目录。所有原规范/产品/测试/旧证据未改。没有新进程、reader、writer或租借资源；消费者已释放。最终sha另存 `report.sha256`，root可把C1/C2派为新增测试的精确任务；独立矩阵不替代root接受。
