from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
ROOT=Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime')
OUT=ROOT/'tmp/model-request-runtime/five-item-closeout-evidence'
MAIN=Path('/data/qiwei/repos/omne-harness-lite')
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=str(ROOT)).decode().strip()
head=git('rev-parse','HEAD'); copied=[]; refs=[]
def copy(relative,group,provenance):
 p=ROOT/relative; before=digest(p); dest=OUT/group/p.name
 dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists() and digest(dest)!=before:raise RuntimeError('would overwrite different evidence '+str(dest))
 shutil.copyfile(str(p),str(dest));after=digest(p);got=digest(dest)
 assert before==after==got,'unstable copy '+relative
 copied.append({'source':str(p),'copy':str(dest.relative_to(OUT)),'sha256':got,'bytes':p.stat().st_size,'provenance':provenance,'copyHashVerified':True})
reports=['tmp/model-request-runtime/t15-final-matrix/T09-T10-T15-CLOSEOUT.md','tmp/model-request-runtime/u4-final-closeout/T19-T20-REVIEW.md','tmp/model-request-runtime/t15-final-matrix/REPORT.md','tmp/model-request-runtime/t15-final-matrix/T08-FINAL-REVIEW.md','tmp/model-request-runtime/t15-final-matrix/C2-REVIEW.md','tmp/model-request-runtime/t09-t10-independent/REPORT.md']
for i,p in enumerate(reports):copy(p,'reports/'+str(i),'independent-read-only-review; root retains acceptance')
logs=['luna-service-runner-prefix-final.log','runner-p5-wait-limit-final.log','runner-final-guard-map.log','runner-final-guard-types.log','runner-final-guard-types-after-build.log','t08-t15-final-gaps.log','t15-credential-runner-final.log','u4-causal-source-order-integrated.log','withrun-three-turns-final.log','withrun-three-turns-typecheck.log','withrun-three-turns-typecheck-fixed.log','runtime-v18-source-tests.log','t08-final-owned-run-composition.log','withrun-calibration-retry-target-tests.log','demo-v18-exact-attempt-tests.log','demo-v18-exact-attempt-tests-data-tmp.log','demo-v18-exact-attempt-typecheck.log','runner-v8-p5-generation-tests.log','runner-v8-second-tests.log','runner-final-service-chain-tests.log','runner-final-boundary-tests.log','runner-source-release-tests.log','runtime-v17-source-matrix-tests.log']
for name in logs:copy('tmp/model-request-runtime/vendor-completion-root/'+name,'root-logs','root-executed; reviewer read log and relevant assertions; overlapping counts not summed')
a4=['REPORT.md','packs.json','dist-before.json','project-pack-complete.json','execution-receipt.json','consumer.mts','consumers.json','cleanup.json','pack-driver-initial-failure.log','finish-pack.log','en/compile-1.log','en/run-1.log','en/run-2.log','en/compile-final.log','en/run-3.log','en/result.json','en/extraction.json','en/literal.mts','en/closure.json','zh/compile-final.log','zh/run-1.log','zh/result.json','zh/extraction.json','zh/literal.mts','zh/closure.json']
for path in a4:copy('tmp/f18-artifact-acceptance/'+path,'independent-a4/'+str(Path(path).parent),'independent actual offline artifact execution; 32 pnpm project packs + 29 installed-file third-party repacks, not registry originals')
tracked=[
'.meta_harness/design/record/decisions/runner-current-pure-provider-adoption/decision.md',
'.meta_harness/design/record/decisions/model-input-usage-calibration-adoption/decision.md',
'.meta_harness/design/spec/capabilities/model-request-runtime/v10/contract.md',
'.meta_harness/design/spec/capabilities/loop-extension-runner/v5/contract.md',
'.meta_harness/design/spec/data/model-response/v9/contract.md',
'.meta_harness/design/realization/packages/model/model-request-runtime/v16-usage-calibration-design.md',
'.meta_harness/design/realization/packages/model/model-request-runtime/v17-model-consumption-design.md',
'.meta_harness/design/realization/packages/model/model-request-runtime/v18-failure-execution-design.md',
'.meta_harness/design/realization/packages/model/model-request-runtime/verification.md',
'.meta_harness/design/realization/packages/agent-loop/loop-extension-runner/v7-model-service-design.md',
'.meta_harness/design/realization/packages/agent-loop/loop-extension-runner/v8-failure-execution-design.md',
'.meta_harness/design/realization/packages/agent-loop/loop-extension-runner/verification.md',
'packages/model/model-request-runtime/src/service-calibration.ts','packages/model/model-request-runtime/src/failure-subject.ts','packages/model/model-request-runtime/src/service-dispatch.ts','packages/model/model-request-runtime/src/service-reads.ts','packages/model/model-request-runtime/src/service-types.ts',
'packages/model/model-request-runtime/tests/acceptance-t15-resume-planning.spec.ts','packages/model/model-request-runtime/tests/acceptance-t15-fresh-dispatch-inputs.spec.ts','packages/model/model-request-runtime/tests/acceptance-u4-causal-source-order.spec.ts','packages/model/model-request-runtime/tests/service-calibration.spec.ts','packages/model/model-request-runtime/tests/acceptance-calibration-source.spec.ts','packages/model/model-request-runtime/tests/service-dispatch.spec.ts','packages/model/model-request-runtime/tests/failure-source.spec.ts',
'examples/model-invocation-minimal-demo/src/runner-service-host.ts','examples/model-invocation-minimal-demo/src/model-request-text.ts','examples/model-invocation-minimal-demo/tests/runner-service-retry-after-wait.spec.ts','examples/model-invocation-minimal-demo/tests/runner-service-guard-map.spec.ts','examples/model-invocation-minimal-demo/tests/runner-service-assembly.spec.ts','examples/model-invocation-minimal-demo/tests/runner-service-with-run-calibration.spec.ts','examples/model-invocation-minimal-demo/tests/acceptance-t15-credential-rotation.spec.ts','examples/model-invocation-minimal-demo/tests/acceptance-calibration-service.spec.ts','examples/model-invocation-minimal-demo/tests/acceptance-calibration-cold.spec.ts',
'packages/model/pi-ai-transport/tests/acceptance-calibration-invalidation.spec.ts','packages/model/pi-ai-transport/tests/acceptance-calibration-reader.spec.ts','packages/model/pi-ai-transport/tests/acceptance-calibration-openai.spec.ts','packages/model/pi-ai-transport/tests/acceptance-calibration-pro.spec.ts','packages/agent-loop/loop-extension-runner/tests/acceptance-public-matrix.spec.ts','packages/agent-loop/loop-extension-runner/tests/service.spec.ts']
for path in tracked:
 data=subprocess.check_output(['git','show',head+':'+path],cwd=str(ROOT))
 refs.append({'path':path,'snapshotCommit':head,'gitBlob':git('rev-parse',head+':'+path),'sha256':hashlib.sha256(data).hexdigest(),'lastChangeCommit':git('log','-1','--format=%H',head,'--',path),'worktreeMatchesSnapshot':digest(ROOT/path)==hashlib.sha256(data).hexdigest(),'kind':'adopted-authority-reference' if path.startswith('.meta_harness/') else 'implementation-or-test-reference','copied':False})
archives=[]
for rel in ['tmp/model-request-runtime/retired-20260929-completion30/calibration-acceptance-manifest.json','tmp/model-request-runtime/retired-20260929-completion30/calibration-acceptance-unique.tar.gz','tmp/model-request-runtime/retired-20260929-completion34/runner-assembly/MANIFEST.json','tmp/model-request-runtime/retired-20260929-completion34/u4-source-order/SHA256-MANIFEST.tsv','tmp/model-request-runtime/retired-20260929-completion34/u4-source-order/RECOVERY.md']:
 p=MAIN/rel;archives.append({'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size,'copied':False,'purpose':'existing preserved archive/index; no DB/config/key/ledger opened'})
base=MAIN/'tmp/model-request-runtime/retired-20260929-completion30'
m=json.loads((base/'calibration-acceptance-manifest.json').read_text());members=[]
with tarfile.open(str(base/'calibration-acceptance-unique.tar.gz')) as t:
 for name in ['README.md','transport-final.log','runtime-final.log','demo-final.log','service-complete.log','pro-independent-4.log','openai-original.log','openai-fixed.log']:
  path='tmp/calibration-acceptance/'+name
  member=t.getmember(path);assert member.isfile()
  data=t.extractfile(member).read();d=hashlib.sha256(data).hexdigest();assert d==m['files'][path]['sha256']
  members.append({'archive':str(base/'calibration-acceptance-unique.tar.gz'),'member':path,'sha256':d,'originalManifestMatch':True,'copied':False,'provenance':'reused prior independent U4 execution; original failure preserved in archive'})
result={'schema':'local-evidence-manifest-v1','purpose':'five-item evidence handoff, not specification or acceptance','branch':git('branch','--show-current'),'captureHead':head,'rootAcceptanceInput':'Root explicitly reported TODO closeout of T09/T10/T15/T19/T20; packaging does not accept again','copiedFiles':copied,'trackedReferences':refs,'archiveReferences':archives,'archiveMembersVerified':members,'executionRoles':{'rootExecuted':'root-logs/; tests/typechecks were performed by root; full output copied unchanged','independentExecuted':'independent-a4/ plus existing archived U4 suite; no new execution in packaging','independentReadOnly':'reports/ plus this packaging hash audit','reuse':'archiveReferences and archiveMembersVerified, with exact provenance'},'scopeExclusions':['T21/T22','paid receipts','user conversation','keys/config/ledger/databases','full Run/AgentLoop/governance','formal record creation'],'rootConfirmedExitCodes':[{'log':'runner-final-guard-types-after-build.log','handle':42902,'exitCode':0,'source':'explicit root result, not inferred from empty log'},{'log':'u4-causal-source-order-integrated.log','handle':24516,'exitCode':0,'source':'explicit root result'}]}
(OUT/'inputs.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'head':head,'copies':len(copied),'trackedReferences':len(refs),'archives':len(archives),'archiveMembersVerified':len(members),'inputsSHA256':digest(OUT/'inputs.json')},ensure_ascii=False))
