# Recovery A/B measurement review, provisional draft

Root read driver.py 428 lines, oracle.py 320 lines and fixture.py 409 lines; application code untouched. Inputs current final I3/new helper and older cad70 image for deployment-only replacement.

Required fixes before first actual run:
- Imported private legacy image ID can differ from outer I3 image ID. Match unique inner BUILD per role, compare original layers/platform/labels, preserve both IDs; helper and inspect consume actual inner ID.
- put_cli_file rejects its own credential.secret and *.json names. Restrict safe basenames consistently; do not widen arbitrary shell text.
- operations metadata is pretty jq JSON, not a single-line output protocol. Decode strict JSON document for this file; preserve precise fields/identity. stdout business protocol remains exactly one JSON+LF.
- A finite observation must record/check actual elapsed duration against configured bound, not infer duration from sample count.
- B normal stop and actual exited inspect precede fixture teardown; cleanup cannot substitute product shutdown evidence.

B driver uses public final CLI/state and no business SQL; default missing payload file correctly maps to {} in apps/cli/src/input.ts, so register/login need not manufacture an extra file. A only restarts uniquely labelled private DinD with unchanged metadata volume; no concurrent manager or damaged metadata claim. B compares image/BUILD replacement, not schema migration. C is not part of this draft review.

Pending final source delta/hash/offline examples before gate. No actual recovery run authorized yet.
