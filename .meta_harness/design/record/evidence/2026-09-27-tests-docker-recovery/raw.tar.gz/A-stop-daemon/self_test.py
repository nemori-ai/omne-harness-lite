#!/usr/bin/env python3
"""Offline mutation tests for the recovery evidence reader; never starts Docker."""

import json
import pathlib
import tempfile

import driver
import oracle

HERE = pathlib.Path(__file__).resolve().parent
CID = "a" * 64
IMAGE_ID = "sha256:" + "b" * 64
OUTER_IMAGE = "sha256:" + "9" * 64
BUILD_ID = "c" * 64
DIND_ID = "d" * 64
PROJECT = "r5test"
CONTROL = "private-control"
DIND = "private-dind"
OLD_CID = "e" * 64
OLD_IMAGE = "sha256:" + "f" * 64
OLD_OUTER_IMAGE = "sha256:" + "8" * 64
OLD_BUILD = "1" * 64
OPERATIONS = "/var/lib/omne-tenancy/state/operations/center-old-12345678"


def center(state="running", started="old-start", restart=0):
    return [{"Id": CID, "Image": IMAGE_ID,
             "Config": {"Labels": {"ai.nemori.omne.project": PROJECT,
                                   "ai.nemori.omne.host-build-id": BUILD_ID}},
             "State": {"Status": state, "Running": state == "running",
                       "Pid": 42 if state == "running" else 0,
                       "ExitCode": 0, "StartedAt": started}, "RestartCount": restart}]


def helper_argv(action):
    return ["docker", "exec", "-e",
            "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock", CONTROL,
            "/usr/local/libexec/omne-center", action]


def seed(root):
    (root / "raw").mkdir()
    commands = []

    def add(label, value, argv=None, rc=0):
        data = value if isinstance(value, bytes) else json.dumps(value).encode() + b"\n"
        (root / "raw" / (label + ".stdout")).write_bytes(data)
        (root / "raw" / (label + ".stderr")).write_bytes(b"")
        stamp = "2026-09-27T00:00:10+00:00" if label == "a-observe-2" else (
            "2026-09-27T00:00:00+00:00")
        commands.append({"label": label, "argv": argv or [], "returncode": rc,
                         "observation_expired": False,
                         "started_utc": stamp,
                         "stdout": "raw/" + label + ".stdout",
                         "stderr": "raw/" + label + ".stderr"})

    def image(image_id):
        return [{"Id": image_id, "Os": "linux", "Architecture": "arm64",
                 "RootFS": {"Layers": ["layer"]},
                 "Config": {"Labels": {"ai.nemori.omne.host-build-id": BUILD_ID,
                   "org.opencontainers.image.version": "0.0.0"}}}]
    add("new-outer-image-inspect", image(OUTER_IMAGE))
    add("new-inner-image-list", (IMAGE_ID + "\n").encode(),
        ["docker", "exec", CONTROL, "docker", "--host",
         "unix:///opt/omne-private-docker/docker.sock", "image", "ls", "-q",
         "--no-trunc", "--filter", "label=ai.nemori.omne.host-build-id=" + BUILD_ID])
    add("new-inner-image-inspect", image(IMAGE_ID))
    add("new-load-image", b"loaded\n")
    add("a-validate", {"state": "deployment-structure-valid"}, helper_argv("validate"))
    add("a-start", {"state": "running", "containerId": CID,
                    "imageId": IMAGE_ID, "buildId": BUILD_ID,
                    "health": "healthy"}, helper_argv("start"))
    add("a-inspect-running", center())
    add("a-full-health", {"reachable": True, "storageReachable": True,
                          "clockSane": True, "deploymentKeyPresent": True,
                          "deploymentKeyComplete": True, "defectCount": 0,
                          "centerId": "center-1"}, helper_argv("full-health"))
    add("a-status-running", {"state": "running", "containerId": CID,
                             "imageId": IMAGE_ID, "buildId": BUILD_ID},
        helper_argv("status"))
    add("a-stop", {"state": "stopped", "containerId": CID,
                   "exitCode": 0, "clean": True})
    add("a-stop-inspect", center("exited"))
    add("a-stop-status", {"state": "exited", "containerId": CID,
                          "imageId": IMAGE_ID, "buildId": BUILD_ID})
    dind = [{"Id": DIND_ID, "Mounts": [{"Name": "private-engine-volume"}],
             "Config": {"Labels": {"omne.r5.helper-prep": "run-1"}}}]
    add("a-dind-before", dind)
    add("a-restart-private-dind", b"private-dind\n",
        ["docker", "restart", DIND])
    add("a-dind-after", dind)
    add("a-inspect-after-engine", center("exited"))
    add("a-status-after-engine", {"state": "exited", "containerId": CID,
                                  "imageId": IMAGE_ID, "buildId": BUILD_ID})
    for number in (1, 2):
        add(f"a-observe-{number}", center("exited"))
    add("a-events", b"", ["docker", "exec", CONTROL, "docker", "--host",
                          "unix:///opt/omne-private-docker/docker.sock", "events",
                          "--filter", "container=" + CID])
    cleanup = []
    for label in ("cleanup-final-list-container", "cleanup-final-list-volume",
                  "cleanup-final-list-network", "cleanup-inner-project-final-list",
                  "cleanup-inner-fixture-final-list", "cleanup-inner-all-final-list"):
        (root / "raw" / (label + ".stdout")).write_bytes(b"")
        cleanup.append({"label": label, "returncode": 0,
                        "stdout": "raw/" + label + ".stdout"})
    evidence = {"run_id": "run-1", "scenario": "A", "status": "observed-awaiting-oracle",
                "business_complete": True, "inputs": {"no_restart_observe_seconds": 10},
                "expected": {"control": CONTROL, "dind": DIND,
                "project": PROJECT, "images": {"new": {"outer_image_id": OUTER_IMAGE,
                    "inner_image_id": IMAGE_ID, "build_id": BUILD_ID}}},
                "commands": commands, "cleanup_commands": cleanup,
                "cleanup_complete": True, "cleanup_errors": []}
    (root / "evidence.json").write_text(json.dumps(evidence))
    return evidence


def seed_b(root):
    (root / "raw").mkdir()
    commands = []

    def add(label, value, argv=None, stderr=b"", rc=0):
        data = value if isinstance(value, bytes) else json.dumps(value).encode() + b"\n"
        (root / "raw" / (label + ".stdout")).write_bytes(data)
        (root / "raw" / (label + ".stderr")).write_bytes(stderr)
        commands.append({"label": label, "argv": argv or [], "returncode": rc,
                         "observation_expired": False, "stdout": "raw/" + label + ".stdout",
                         "stderr": "raw/" + label + ".stderr"})

    def image(image_id, build):
        return [{"Id": image_id, "Os": "linux", "Architecture": "arm64",
                 "RootFS": {"Layers": [build]},
                 "Config": {"Labels": {"ai.nemori.omne.host-build-id": build,
                   "org.opencontainers.image.version": "0.0.0"}}}]

    def actual(cid, image_id, build, state):
        return [{"Id": cid, "Image": image_id,
                 "Config": {"Labels": {"ai.nemori.omne.project": PROJECT,
                                       "ai.nemori.omne.host-build-id": build}},
                 "State": {"Status": state, "Running": state == "running",
                           "Pid": 42 if state == "running" else 0, "ExitCode": 0,
                           "StartedAt": "start-1", "FinishedAt": "finish-1"},
                 "RestartCount": 0}]

    def cli_argv(action):
        argv = ["docker", "exec", "-e", "HOME=/tmp/omne-recovery-cli", CONTROL,
                "node", "/opt/omne-recovery-cli/app/dist/main.js", "machine",
                *action, "--state-dir", "/tmp/omne-recovery-cli/state"]
        if action in (["tenant", "current"], ["tenant", "list"]):
            argv.append("--refresh")
        return argv

    def report(result=None, health=False):
        remote = {"status": "success", "health": {"centerId": "center-1"}} if health else {
            "status": "success", "reply": {"reply": {"result": result}}}
        return {"format": "governance-client/1", "view": {"source": "remote"},
                "remote": remote}

    for role, outer_id, inner_id, build in (("old", OLD_OUTER_IMAGE, OLD_IMAGE, OLD_BUILD),
                                           ("new", OUTER_IMAGE, IMAGE_ID, BUILD_ID)):
        add(role + "-outer-image-inspect", image(outer_id, build))
        add(role + "-load-image", b"loaded\n")
        add(role + "-inner-image-list", (inner_id + "\n").encode(),
            ["docker", "exec", CONTROL, "docker", "--host",
             "unix:///opt/omne-private-docker/docker.sock", "image", "ls", "-q",
             "--no-trunc", "--filter", "label=ai.nemori.omne.host-build-id=" + build])
        add(role + "-inner-image-inspect", image(inner_id, build))
    add("b-add-qa-credential-policy", b"",
        ["docker", "exec", "-i", CONTROL, "sh", "-c",
         "cat >> /var/lib/omne-tenancy/settings.env"])
    add("b-qa-policy-stat", b"regular file:0:0:600\n")
    add("b-qa-policy-tail", b'OMNE_TENANCY_CREDENTIAL_POLICY={"minLength":12}\n')
    add("b-old-validate", {"state": "deployment-structure-valid"}, helper_argv("validate"))
    add("b-old-start", {"state": "running", "containerId": OLD_CID,
                        "imageId": OLD_IMAGE, "buildId": OLD_BUILD,
                        "health": "healthy"}, helper_argv("start"))
    add("b-old-inspect-running", actual(OLD_CID, OLD_IMAGE, OLD_BUILD, "running"))
    full_health = {"reachable": True, "storageReachable": True, "clockSane": True,
                   "deploymentKeyPresent": True, "deploymentKeyComplete": True,
                   "defectCount": 0, "centerId": "center-1"}
    add("b-old-full-health", full_health, helper_argv("full-health"))
    add("b-old-status-running", {"state": "running", "containerId": OLD_CID,
                                 "imageId": OLD_IMAGE, "buildId": OLD_BUILD},
        helper_argv("status"))
    add("b-new-validate", {"state": "deployment-structure-valid"})
    add("b-cli-configure", {"format": "governance-client/1"},
        cli_argv(["center", "configure"]) + ["--endpoint", "https://172.18.0.2:18443",
                                         "--ca-file", "/var/lib/omne-tenancy/secrets/tls-chain.pem"])
    add("b-cli-build-id", ("2" * 64 + "\n").encode())
    add("b-control-node-version", b"v24.21.0\n")
    add("b-write-credential-stat", b"regular file:0:0:600\n")
    for label, action, value in (
        ("b-cli-health-before", ["center", "health"], report(health=True)),
        ("b-cli-register", ["register"], report("ok")),
        ("b-cli-login", ["login"], report("ok")),
        ("b-cli-personal-before", ["tenant", "current"],
         report({"organization": "personal-1", "account": "account-1"})),
        ("b-cli-create-team", ["organization", "create"], report("team-1")),
        ("b-cli-switch", ["tenant", "switch"], report("ok")),
        ("b-cli-current-before", ["tenant", "current"],
         report({"organization": "team-1", "account": "account-1"})),
        ("b-cli-list-before", ["tenant", "list"],
         report([{"organization": "team-1", "account": "account-1"}])),
        ("b-cli-health-after", ["center", "health"], report(health=True)),
        ("b-cli-current-after", ["tenant", "current"],
         report({"organization": "team-1", "account": "account-1"})),
        ("b-cli-list-after", ["tenant", "list"],
         report([{"organization": "team-1", "account": "account-1"}])),
    ):
        argv = cli_argv(action)
        if label in ("b-cli-register", "b-cli-login"):
            argv += ["--login-identifier", "qatestr5", "--credential-file",
                     "/tmp/omne-recovery-cli/credential.secret"]
        add(label, value, argv)
    add("b-old-stop", {"state": "stopped", "containerId": OLD_CID,
                       "exitCode": 0, "clean": True})
    add("b-old-stop-inspect", actual(OLD_CID, OLD_IMAGE, OLD_BUILD, "exited"))
    add("b-old-stop-status", {"state": "exited", "containerId": OLD_CID,
                              "imageId": OLD_IMAGE, "buildId": OLD_BUILD})
    add("b-old-logs", b"old stdout\n", ["docker", "exec", CONTROL, "docker",
                                     "--host", "unix:///opt/omne-private-docker/docker.sock",
                                     "logs", OLD_CID], stderr=b"old stderr\n")
    add("b-new-start", {"state": "running", "containerId": CID,
                        "imageId": IMAGE_ID, "buildId": BUILD_ID, "health": "healthy"},
        stderr=(f"omne-center: operations-exported container={OLD_CID} "
                f"directory={OPERATIONS}\nomne-center: center-start-request "
                f"project={PROJECT} container={CID} image={IMAGE_ID}\n").encode())
    add("b-new-inspect", actual(CID, IMAGE_ID, BUILD_ID, "running"))
    add("b-new-status", {"state": "running", "containerId": CID,
                         "imageId": IMAGE_ID, "buildId": BUILD_ID})
    add("b-new-full-health", full_health)
    add("b-operations-parent-stat", b"directory:0:0:700\n",
        ["docker", "exec", CONTROL, "stat", "-c", "%F:%u:%g:%a",
         "/var/lib/omne-tenancy/state/operations"])
    add("b-operations-dir-stat", b"directory:0:0:700\n",
        ["docker", "exec", CONTROL, "stat", "-c", "%F:%u:%g:%a", OPERATIONS])
    contents = {"stdout.log": b"old stdout\n", "stderr.log": b"old stderr\n",
                "metadata.json": json.dumps({"containerId": OLD_CID,
                    "imageId": OLD_IMAGE, "buildId": OLD_BUILD,
                    "version": "0.0.0",
                    "status": "exited", "exitCode": 0,
                    "finishedAt": "finish-1"}, indent=2).encode() + b"\n"}
    for name, data in contents.items():
        add("b-export-stat-" + name, f"regular file:0:0:600:{len(data)}\n".encode(),
            ["docker", "exec", CONTROL, "stat", "-c", "%F:%u:%g:%a:%s",
             OPERATIONS + "/" + name])
        add("b-export-content-" + name, data,
            ["docker", "exec", CONTROL, "cat", OPERATIONS + "/" + name])
    add("b-new-stop", {"state": "stopped", "containerId": CID,
                       "exitCode": 0, "clean": True})
    add("b-new-stop-inspect", actual(CID, IMAGE_ID, BUILD_ID, "exited"))
    add("b-new-stop-status", {"state": "exited", "containerId": CID,
                              "imageId": IMAGE_ID, "buildId": BUILD_ID})
    cleanup = []
    for label in ("cleanup-final-list-container", "cleanup-final-list-volume",
                  "cleanup-final-list-network", "cleanup-inner-project-final-list",
                  "cleanup-inner-fixture-final-list", "cleanup-inner-all-final-list"):
        (root / "raw" / (label + ".stdout")).write_bytes(b"")
        cleanup.append({"label": label, "returncode": 0,
                        "stdout": "raw/" + label + ".stdout"})
    evidence = {"run_id": "run-1", "scenario": "B", "status": "observed-awaiting-oracle",
                "business_complete": True, "operations_directory": OPERATIONS,
                "private_dind_ip": "172.18.0.2", "inputs": {"cli_build_id": "2" * 64},
                "expected": {"control": CONTROL, "dind": DIND, "project": PROJECT,
                    "state": "/var/lib/omne-tenancy/state",
                    "images": {"old": {"outer_image_id": OLD_OUTER_IMAGE,
                                       "inner_image_id": OLD_IMAGE, "build_id": OLD_BUILD},
                               "new": {"outer_image_id": OUTER_IMAGE,
                                       "inner_image_id": IMAGE_ID, "build_id": BUILD_ID}}},
                "commands": commands, "cleanup_commands": cleanup,
                "cleanup_complete": True, "cleanup_errors": []}
    (root / "evidence.json").write_text(json.dumps(evidence))
    return evidence


def mutate(root, name, change):
    path = root / name
    path.mkdir()
    evidence = seed(path)
    change(path, evidence)
    (path / "evidence.json").write_text(json.dumps(evidence))
    try:
        oracle.evaluate(path)
        return False
    except (ValueError, KeyError, TypeError):
        return True


def mutate_b(root, name, change):
    path = root / name
    path.mkdir()
    evidence = seed_b(path)
    change(path, evidence)
    (path / "evidence.json").write_text(json.dumps(evidence))
    try:
        oracle.evaluate(path)
        return False
    except (ValueError, KeyError, TypeError):
        return True


def test():
    cases = {}
    cases["cli_private_names_accept_fixed_suffixes"] = all(
        driver.safe_cli_name(name) for name in ("credential.secret", "b-cli-create-team.json"))
    cases["cli_private_names_reject_traversal_and_shell"] = all(
        not driver.safe_cli_name(name) for name in ("../secret", "a..b", "a/b", "x;cat", ".hidden"))
    with tempfile.TemporaryDirectory(dir=HERE, prefix="offline-") as temp:
        root = pathlib.Path(temp)
        valid = root / "valid"
        valid.mkdir()
        seed(valid)
        cases["valid_A"] = oracle.evaluate(valid) == {"status": "limited_pass",
                                                        "scenario": "A"}
        cases["empty_stop_output"] = mutate(root, "empty-stop", lambda path, _: (
            path / "raw/a-stop.stdout").write_bytes(b""))
        cases["wrong_id"] = mutate(root, "wrong-id", lambda path, _: (
            path / "raw/a-stop-inspect.stdout").write_text(json.dumps(center("exited")).replace(
                CID, "f" * 64) + "\n"))
        cases["same_id_but_started_again"] = mutate(root, "started-again", lambda path, _: (
            path / "raw/a-observe-2.stdout").write_text(json.dumps(center("exited", "new-start")) + "\n"))
        cases["same_id_but_restart_count_changed"] = mutate(root, "restart-count", lambda path, _: (
            path / "raw/a-observe-2.stdout").write_text(json.dumps(center("exited", restart=1)) + "\n"))
        def short_observation(path, evidence):
            next(item for item in evidence["commands"] if item["label"] ==
                 "a-observe-2")["started_utc"] = "2026-09-27T00:00:02+00:00"
        cases["observation_shorter_than_input"] = mutate(root, "short-window",
                                                           short_observation)
        cases["start_event"] = mutate(root, "start-event", lambda path, _: (
            path / "raw/a-events.stdout").write_text(json.dumps(
                {"Action": "start", "Actor": {"ID": CID}}) + "\n"))
        def wrong_daemon(path, evidence):
            next(x for x in evidence["commands"] if x["label"] ==
                 "a-restart-private-dind")["argv"][-1] = "user-docker-daemon"
        cases["wrong_daemon_target"] = mutate(root, "wrong-daemon", wrong_daemon)
        def cleanup_false(path, evidence):
            evidence["cleanup_complete"] = False
        cases["cleanup_claim_cannot_pass"] = mutate(root, "cleanup", cleanup_false)
        cases["label_query_residue"] = mutate(root, "residue", lambda path, _: (
            path / "raw/cleanup-final-list-volume.stdout").write_bytes(b"volume-remains\n"))
        def status_wrong_build(path, evidence):
            value = {"state": "exited", "containerId": CID,
                     "imageId": IMAGE_ID, "buildId": "f" * 64}
            (path / "raw/a-status-after-engine.stdout").write_text(json.dumps(value) + "\n")
        cases["status_wrong_build"] = mutate(root, "wrong-build", status_wrong_build)
        valid_b = root / "valid-b"
        valid_b.mkdir()
        seed_b(valid_b)
        cases["valid_B"] = oracle.evaluate(valid_b) == {"status": "limited_pass",
                                                         "scenario": "B"}
        empty_logs = root / "empty-logs"
        empty_logs.mkdir()
        seed_b(empty_logs)
        for stream, name in (("stdout", "stdout.log"), ("stderr", "stderr.log")):
            (empty_logs / "raw" / ("b-old-logs." + stream)).write_bytes(b"")
            (empty_logs / "raw" / ("b-export-content-" + name + ".stdout")).write_bytes(b"")
            (empty_logs / "raw" / ("b-export-stat-" + name + ".stdout")).write_bytes(
                b"regular empty file:0:0:600:0\n")
        cases["valid_B_empty_logs"] = oracle.evaluate(empty_logs) == {
            "status": "limited_pass", "scenario": "B"}
        def rewrite(path, label, value, stream="stdout"):
            (path / "raw" / (label + "." + stream)).write_bytes(
                value if isinstance(value, bytes) else json.dumps(value).encode() + b"\n")
        cases["B_new_build_mismatch"] = mutate_b(root, "b-new-build", lambda path, _: rewrite(
            path, "b-new-status", {"state": "running", "containerId": CID,
                                   "imageId": IMAGE_ID, "buildId": OLD_BUILD}))
        cases["B_missing_qa_policy"] = mutate_b(root, "b-no-policy", lambda path, _: rewrite(
            path, "b-qa-policy-tail", b""))
        cases["B_center_id_changed"] = mutate_b(root, "b-center", lambda path, _: rewrite(
            path, "b-new-full-health", {"centerId": "other", "defectCount": 0}))
        cases["B_team_selection_changed"] = mutate_b(root, "b-selected", lambda path, _: rewrite(
            path, "b-cli-current-after", {"format": "governance-client/1",
                "view": {"source": "remote"}, "remote": {"status": "success",
                "reply": {"reply": {"result": {"organization": "other",
                                               "account": "account-1"}}}}}))
        cases["B_stale_cli_copy"] = mutate_b(root, "b-stale", lambda path, _: rewrite(
            path, "b-cli-list-after", {"format": "governance-client/1",
                "view": {"source": "copy"}, "remote": {"status": "success",
                "reply": {"reply": {"result": [{"organization": "team-1",
                                               "account": "account-1"}]}}}}))
        cases["B_export_not_from_helper"] = mutate_b(root, "b-no-export", lambda path, _: rewrite(
            path, "b-new-start", b"", stream="stderr"))
        cases["B_export_after_create_cannot_pass"] = mutate_b(root, "b-late-export", lambda path, _: rewrite(
            path, "b-new-start", (f"omne-center: center-start-request project={PROJECT} "
                                   f"container={CID} image={IMAGE_ID}\n"
                                   f"omne-center: operations-exported container={OLD_CID} "
                                   f"directory={OPERATIONS}\n").encode(), stream="stderr"))
        cases["B_export_metadata_wrong_old_id"] = mutate_b(root, "b-metadata", lambda path, _: rewrite(
            path, "b-export-content-metadata.json", {"containerId": CID,
                "imageId": OLD_IMAGE, "buildId": OLD_BUILD,
                "status": "exited", "exitCode": 0}))
        cases["B_export_bytes_mismatch"] = mutate_b(root, "b-logs", lambda path, _: rewrite(
            path, "b-export-content-stdout.log", b"different\n"))
        cases["B_export_not_private"] = mutate_b(root, "b-mode", lambda path, _: rewrite(
            path, "b-export-stat-stdout.log", b"regular file:0:0:644:11\n"))
        cases["B_pretty_metadata_duplicate_key"] = mutate_b(root, "b-duplicate", lambda path, _: rewrite(
            path, "b-export-content-metadata.json",
            (path / "raw/b-export-content-metadata.json.stdout").read_bytes().rstrip(b"\n}")
            + b',\n  "containerId": "' + OLD_CID.encode() + b'"\n}\n'))
        cases["B_new_center_not_normally_stopped"] = mutate_b(root, "b-new-stop", lambda path, _: rewrite(
            path, "b-new-stop", b""))
        cases["B_one_image_cannot_fake_two"] = mutate_b(root, "b-one-image", lambda path, _: rewrite(
            path, "old-inner-image-inspect", [{"Id": IMAGE_ID,
                "RootFS": {"Layers": [IMAGE_ID]},
                "Config": {"Labels": {"ai.nemori.omne.host-build-id": BUILD_ID}}}]))
    return cases


if __name__ == "__main__":
    result = test()
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(0 if all(result.values()) else 1)
