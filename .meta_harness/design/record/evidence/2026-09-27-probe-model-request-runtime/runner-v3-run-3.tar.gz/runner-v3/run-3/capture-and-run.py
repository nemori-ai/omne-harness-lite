#!/usr/bin/env python3
"""Capture immutable candidate inputs and retain the actual validation output."""
from __future__ import annotations

import copy
import hashlib
import importlib.metadata
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urldefrag, urljoin


ROOT = Path(__file__).resolve().parents[3]
DESIGN = ROOT / ".meta_harness/design"
EVIDENCE = Path(__file__).resolve().parent
TOPIC = "spec/capabilities/loop-extension-runner"


def dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()


def refs(value: object):
    if isinstance(value, dict):
        if "$ref" in value:
            yield value["$ref"]
        for child in value.values():
            yield from refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from refs(child)


def main() -> int:
    assert git("branch", "--show-current") == "panqiwei/model-request-runtime"
    assert git("rev-parse", "HEAD").startswith("d4eaf767")
    frozen = []
    for name in ["contract.md", "examples.md"]:
        rel = f".meta_harness/design/{TOPIC}/v2/{name}"
        old = subprocess.check_output(["git", "show", f"HEAD:{rel}"], cwd=ROOT)
        current = (ROOT / rel).read_bytes()
        assert current == old, f"frozen v2 changed: {rel}"
        frozen.append({"path": rel, "sha256": digest(current), "unchanged_from_head": True})
    dump(EVIDENCE / "frozen-v2.json", frozen)

    catalog_path = DESIGN / "registry/catalog.json"
    catalog = json.loads(catalog_path.read_text())
    old_entry = next(entry for entry in catalog["contracts"] if entry["coordinate"]["contract_id"] == "capability.loop-extension-runner" and entry["coordinate"]["version"] == 2)
    candidate = copy.deepcopy(old_entry)
    candidate["coordinate"]["version"] = 3
    candidate["status"] = "candidate"
    candidate["acceptance"] = None
    candidate["contract_path"] = candidate["contract_path"].replace("/v2/", "/v3/")
    candidate["resources"] = [item.replace("/v2/", "/v3/") for item in candidate["resources"]]
    upgrades = {"data.loop-extension": 4, "data.messages": 4, "data.content-blocks": 3, "data.model-response": 4, "capability.model-request-runtime": 3}
    for dependency in candidate["dependencies"]:
        name = dependency["coordinate"]["contract_id"]
        if name in upgrades:
            dependency["coordinate"]["version"] = upgrades[name]
        if name == "data.messages":
            dependency["clauses"].append("S-49")
        if name == "data.model-response":
            dependency["clauses"].append("S-36")
    covers_path = DESIGN / "registry/covers.json"
    covers = []
    for row in json.loads(covers_path.read_text())["covers"]:
        if row["target"]["contract_id"] == "capability.loop-extension-runner" and row["target"]["version"] == 2:
            row = copy.deepcopy(row)
            row["target"]["version"] = 3
            row["reviewed"] = False
            row["note"] = "2026-09-27 v3 精确消费演进候选：继承 v2 的同号条款覆盖；PF-013 rev 13 仅 UI 验收适用增量，本轮不新增产品政策。尚未独立复核、未接受。"
            covers.append(row)
    dump(EVIDENCE / "candidate-metadata.json", {
        "status": "candidate-not-registered-by-drafter",
        "source_catalog_sha256": digest(catalog_path.read_bytes()),
        "source_covers_sha256": digest(covers_path.read_bytes()),
        "catalog_entry": candidate,
        "covers": covers,
        "formal_tasks_additions": [],
        "id_namespaces_additions": [],
        "note": "Only the mainline registry owner may apply this candidate metadata; inherited G-14 remains open."
    })

    all_schemas = {}
    for path in (DESIGN / "spec/data").rglob("*.schema.json"):
        schema = json.loads(path.read_text())
        all_schemas[schema["$id"]] = (path, schema)
    initial_path = DESIGN / "spec/data/loop-extension/v4/loop-extension.schema.json"
    pending = [json.loads(initial_path.read_text())["$id"]]
    visited = set()
    files = {DESIGN / TOPIC / version / name for version in ["v2", "v3"] for name in ["contract.md", "examples.md"]}
    for dependency in candidate["dependencies"]:
        coord = dependency["coordinate"]
        family, topic = coord["contract_id"].split(".", 1)
        files.add(DESIGN / "spec" / ("capabilities" if family == "capability" else family) / topic / f"v{coord['version']}" / "contract.md")
    while pending:
        identity = pending.pop()
        if identity in visited:
            continue
        visited.add(identity)
        path, schema = all_schemas[identity]
        files.add(path)
        files.add(path.parent / "contract.md")
        for ref in refs(schema):
            target = urldefrag(urljoin(identity, ref))[0]
            if target != identity:
                assert target in all_schemas, f"unresolved schema: {target}"
                pending.append(target)
    inputs = EVIDENCE / "inputs"
    manifest = {"format": 1, "captured_at": datetime.now(timezone.utc).isoformat(), "source_root": str(DESIGN), "source_commit": git("rev-parse", "HEAD"), "source_branch": git("branch", "--show-current"), "files": []}
    for source in sorted(files):
        rel = source.relative_to(DESIGN)
        target = inputs / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        data = source.read_bytes()
        target.write_bytes(data)
        manifest["files"].append({"path": str(rel), "sha256": digest(data), "bytes": len(data)})
    dump(EVIDENCE / "inputs-sha256.json", manifest)
    argv = [sys.executable, str(EVIDENCE / "check.py"), "--inputs", str(inputs), "--manifest", str(EVIDENCE / "inputs-sha256.json")]
    started = datetime.now(timezone.utc).isoformat()
    with (EVIDENCE / "stdout.jsonl").open("wb") as stdout, (EVIDENCE / "stderr.txt").open("wb") as stderr:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
    dump(EVIDENCE / "run.json", {
        "started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(), "argv": argv, "cwd": str(ROOT), "exit_code": result.returncode,
        "python": platform.python_version(), "packages": {name: importlib.metadata.version(name) for name in ["jsonschema", "referencing"]},
        "artifacts": [{"path": name, "sha256": digest((EVIDENCE / name).read_bytes())} for name in ["check.py", "capture-and-run.py", "inputs-sha256.json", "stdout.jsonl", "stderr.txt", "frozen-v2.json", "candidate-metadata.json"]]
    })
    print(json.dumps({"exit_code": result.returncode, "input_files": len(files), "schemas": len(visited), "covers": len(covers), "dependencies": len(candidate["dependencies"])}, ensure_ascii=False))
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
