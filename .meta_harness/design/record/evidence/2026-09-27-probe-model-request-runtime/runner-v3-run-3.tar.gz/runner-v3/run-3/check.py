#!/usr/bin/env python3
"""Candidate checks only: dependency shape, binding predicates, inherited rows."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
from decimal import Decimal
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource


def emit(value: dict) -> None:
    print(json.dumps(value, ensure_ascii=False, default=str))


def exact_json(left: object, right: object) -> bool:
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int, Decimal)) and isinstance(right, (int, Decimal)):
        return left == right
    if type(left) is not type(right):
        return False
    if isinstance(left, dict) and isinstance(right, dict):
        return left.keys() == right.keys() and all(exact_json(value, right[key]) for key, value in left.items())
    if isinstance(left, list) and isinstance(right, list):
        return len(left) == len(right) and all(exact_json(a, b) for a, b in zip(left, right))
    return left == right


def normalize(text: str) -> str:
    for identity, topic, old, new in [
        ("capability.loop-extension-runner", "loop-extension-runner", 2, 3),
        ("data.loop-extension", "loop-extension", 2, 4),
        ("data.messages", "messages", 2, 4),
        ("data.model-response", "model-response", 2, 4),
        ("data.content-blocks", "content-blocks", 2, 3),
        ("capability.model-request-runtime", "model-request-runtime", 2, 3),
    ]:
        for before, after in [
            (f"{identity} v{old}", f"{identity} v{new}"),
            (f"{identity}/v{old}", f"{identity}/v{new}"),
            (f"{identity}` v{old}", f"{identity}` v{new}"),
            (f"{identity} · v{old}", f"{identity} · v{new}"),
            (f"{topic}/v{old}/", f"{topic}/v{new}/"),
        ]:
            text = text.replace(before, after)
    return text


def operation_rows(text: str, number: int) -> dict[str, str]:
    section = re.search(rf"^### S-{number} .*?(?=^### S-|\Z)", text, re.M | re.S).group(0)
    return dict(re.findall(r"^\| ([①②③④⑤⑥⑦⑧⑨]) \| (.*)$", section, re.M))


def binding_consistent(value: dict) -> bool:
    subject = value["subject"]
    records = subject["dispatches"]
    return all(
        exact_json(subject["profile"], record["profileSnapshot"])
        and exact_json(record["adaptation"], record["profileSnapshot"]["adaptation"])
        and record["adaptation"]["definition"]["modelId"] == record["profile"]["routeName"]
        and record["call"] == records[0]["call"]
        for record in records
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    schemas = []
    for item in manifest["files"]:
        path = args.inputs / item["path"]
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != item["sha256"]:
            raise ValueError(f"input hash mismatch: {item['path']}")
        if path.name.endswith(".schema.json"):
            schema = json.loads(data)
            schemas.append((schema["$id"], Resource.from_contents(schema)))
    emit({"event": "input_hashes", "verified": len(manifest["files"])})
    topic = args.inputs / "spec/capabilities/loop-extension-runner"
    old = (topic / "v2/contract.md").read_text()
    current = (topic / "v3/contract.md").read_text()
    ids = re.findall(r"^#{3,4} S-(\d+) ", current, re.M)
    assert len(ids) == 52 and set(map(int, ids)) == set(range(1, 53))
    emit({"event": "clause_ids", "count": len(ids), "unchanged": True})
    for topic_name, old_version in [("loop-extension", 2), ("messages", 2), ("model-response", 2), ("content-blocks", 2), ("model-request-runtime", 2)]:
        assert f"{topic_name}/v{old_version}/" not in current
    emit({"event": "exact_adoption", "obsolete_dependency_paths": 0})
    for number in [21, 22]:
        before = operation_rows(normalize(old), number)
        after = operation_rows(current, number)
        assert set(before) == set(after) == set("①②③④⑤⑥⑦⑧⑨")
        protected = "②③④⑤⑥⑦⑧⑨" if number == 21 else "①②③④⑤⑥⑦⑧⑨"
        for row in protected:
            assert before[row] == after[row], (number, row)
        emit({"event": "operation", "clause": f"S-{number}", "nine_rows": True, "inherited_rows_unchanged": protected, "failure_set": after["⑥"]})
    registry = Registry().with_resources(schemas)
    lc = json.loads((args.inputs / "spec/data/loop-extension/v4/loop-extension.schema.json").read_text())
    def validator(name: str) -> Draft202012Validator:
        return Draft202012Validator({"$ref": lc["$id"] + "#/$defs/" + name}, registry=registry, format_checker=FormatChecker())
    example_text = (topic / "v3/examples.md").read_text().split("## 8. v3：", 1)[1]
    values = [json.loads(block, parse_float=Decimal) for block in re.findall(r"```json\n(.*?)\n```", example_text, re.S)]
    assert len(values) == 2
    failures = []
    checked = 0
    for name, value in zip(["ExtensionInput", "Conclusion"], values):
        errors = list(validator(name).iter_errors(value))
        emit({"event": "schema", "case": name, "expected_valid": True, "valid": not errors, "errors": [{"path": list(e.path), "message": e.message} for e in errors]})
        checked += 1
        if errors:
            failures.append(name)
    base = values[0]
    assert binding_consistent(base)
    mutations = []
    for path in [
        ("subject", "profile", "adaptation"),
        ("subject", "dispatches", 0, "adaptation"),
        ("subject", "dispatches", 0, "profileSnapshot", "adaptation"),
    ]:
        value = copy.deepcopy(base)
        target = value
        for part in path[:-1]:
            target = target[part]
        del target[path[-1]]
        mutations.append(("missing " + repr(path), value, False, False))
    for member in ["cache", "servingProvider"]:
        value = copy.deepcopy(base)
        value["subject"][member] = {} if member == "cache" else "provider-a"
        mutations.append(("unexpected " + member, value, False, False))
    value = copy.deepcopy(base)
    value["subject"]["dispatches"][0]["adaptation"]["configuration"]["values"] = {"different": True}
    mutations.append(("record binding mismatch", value, True, False))
    value = copy.deepcopy(base)
    record = value["subject"]["dispatches"][0]
    for binding in [record["adaptation"], record["profileSnapshot"]["adaptation"], value["subject"]["profile"]["adaptation"]]:
        binding["definition"]["modelId"] = "example/another-model"
    mutations.append(("model id mismatch", value, True, False))
    value = copy.deepcopy(base)
    value["subject"]["profile"]["adaptation"]["implementation"]["revision"] = "another-revision"
    mutations.append(("subject snapshot mismatch", value, True, False))
    value = copy.deepcopy(base)
    second = copy.deepcopy(value["subject"]["dispatches"][0])
    second.update(call="another-call", dispatch=2, response="another-response")
    value["subject"]["dispatches"].append(second)
    mutations.append(("another call mixed in", value, True, False))
    input_validator = validator("ExtensionInput")
    for name, value, expected_shape, expected_binding in mutations:
        errors = list(input_validator.iter_errors(value))
        valid = not errors
        accepted = valid and binding_consistent(value)
        emit({"event": "mutation", "case": name, "expected_shape": expected_shape, "actual_shape": valid, "expected_binding": expected_binding, "actual_binding": accepted, "errors": [{"path": list(e.path), "message": e.message} for e in errors]})
        if valid != expected_shape or accepted != expected_binding:
            failures.append(name)
    emit({"event": "result", "normative_shapes": checked, "mutations": len(mutations), "operations": 2, "clauses": 52, "failures": failures, "product_runtime_executed": False, "formal_tool_executed": False})
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
