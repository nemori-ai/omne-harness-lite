# ModelResponse v4 candidate validation evidence

This directory contains the actual saved rerun of the response/v4 Schema and
binding-predicate checks. It does not replace production conformance tests,
the full rejection-priority implementation, upstream fact verification, or
the global design checker.

Artifacts:

- `verify.py`: the executable checker used for this run.
- `inputs/`: byte snapshots of the response examples and transitive Schema
  dependency closure, with corresponding contracts retained as semantic input.
- `inputs-sha256.json`: source branch/commit, capture time, source-relative paths,
  byte lengths and SHA-256 for all 43 captured input files.
- `stdout.jsonl`: unabridged process stdout, including individual Schema cases,
  validation errors, binding comparisons and exact-JSON mutations.
- `stderr.txt`: unabridged process stderr; empty for this run.
- `run.json`: exact argv, working directory, timestamps, Python/package versions,
  process exit code and hashes of the script, manifest and raw output files.

Run from the specified worktree, using its already prepared environment:

```sh
.venv/bin/python tmp/model-request-runtime/response-v4/verify.py \
  --inputs tmp/model-request-runtime/response-v4/inputs \
  --manifest tmp/model-request-runtime/response-v4/inputs-sha256.json
```

The checker first verifies the captured input hashes. This command prints a new
run to stdout without overwriting the preserved raw output. It reads the captured
files, so concurrent edits to candidate specs do not silently change the test
inputs. New candidate revisions require a new captured evidence set.

The saved run exited 0. The actual result event appears at the end of
`stdout.jsonl`: 58 Schema instances (22 accepted, 36 rejected), 12 incremental
binding checks and 5 exact-JSON value mutations; no mismatches. Two inherited
JSON fragments are reported individually as non-documents, not counted as
passing ModelResponse examples.

These artifacts live under ignored `tmp/` in the named worktree. Preserve or move
them through the mainline evidence-retention process before retiring that tree;
their presence does not imply Git publication or formal acceptance.
