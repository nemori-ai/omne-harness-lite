#!/usr/bin/env python3
"""Check the captured response/v4 examples; this is not a product validator."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from decimal import Decimal
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource


def exact_json(left: object, right: object) -> bool:
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int, Decimal)) and isinstance(right, (int, Decimal)):
        return left == right
    if type(left) is not type(right):
        return False
    if isinstance(left, dict) and isinstance(right, dict):
        return left.keys() == right.keys() and all(
            exact_json(value, right[key]) for key, value in left.items()
        )
    if isinstance(left, list) and isinstance(right, list):
        return len(left) == len(right) and all(
            exact_json(a, b) for a, b in zip(left, right)
        )
    return left == right


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    resources = []
    for entry in manifest["files"]:
        source = args.inputs / entry["path"]
        data = source.read_bytes()
        actual = hashlib.sha256(data).hexdigest()
        if actual != entry["sha256"]:
            raise ValueError(f"input digest mismatch: {entry['path']}")
        if source.name.endswith(".schema.json"):
            schema = json.loads(data)
            resources.append((schema["$id"], Resource.from_contents(schema)))
    print(json.dumps({"event": "input_hashes", "verified": len(manifest["files"])}, ensure_ascii=False))

    topic = args.inputs / "spec/data/model-response/v4"
    schema = json.loads((topic / "model-response.schema.json").read_text())
    Draft202012Validator.check_schema(schema)
    validator = Draft202012Validator(
        schema,
        registry=Registry().with_resources(resources),
        format_checker=FormatChecker(),
    )
    text = (topic / "examples.md").read_text()
    total = passed = rejected = judged = skipped = 0
    mismatches = []
    for match in re.finditer(r"```json\n(.*?)\n```", text, re.S):
        prefix = text[:match.start()]
        headings = list(re.finditer(r"^#{2,4} (.+)$", prefix, re.M))
        label = headings[-1].group(1)
        context = prefix[headings[-1].start():]
        try:
            value = json.loads(match.group(1), parse_float=Decimal)
        except ValueError:
            skipped += 1
            print(json.dumps({"event": "non_document", "case": label, "reason": "JSON fragment"}, ensure_ascii=False))
            continue
        if not isinstance(value, dict) or "outcome" not in value:
            skipped += 1
            print(json.dumps({"event": "non_document", "case": label, "reason": "not ModelResponse"}, ensure_ascii=False))
            continue
        expected = re.findall(r"预期(?: Schema)?：`(通过|拒绝)", context)
        if not expected:
            raise ValueError(f"missing normative expectation: {label}")
        errors = list(validator.iter_errors(value))
        valid = not errors
        total += 1
        passed += valid
        rejected += not valid
        result = {
            "event": "schema",
            "case": label,
            "expected": expected[-1],
            "actual": "通过" if valid else "拒绝",
            "error_count": len(errors),
            "errors": [
                {"instance_path": list(error.path), "schema_path": list(error.schema_path), "message": error.message}
                for error in errors
            ],
        }
        print(json.dumps(result, ensure_ascii=False, default=str))
        if valid != (expected[-1] == "通过"):
            mismatches.append({"case": label, "check": "schema"})
        if label.startswith("V4-E"):
            expected_judge = re.search(r"纯判定：`([^`]+)`", context).group(1)
            route = value["route"]
            accepted = valid and exact_json(route["adaptation"], route["profileSnapshot"]["adaptation"])
            accepted = accepted and route["adaptation"]["definition"]["modelId"] == route["profile"]["routeName"]
            actual_judge = "通过" if accepted else "malformed"
            judged += 1
            print(json.dumps({"event": "binding_predicates", "case": label, "expected": expected_judge, "actual": actual_judge}, ensure_ascii=False))
            if actual_judge != expected_judge:
                mismatches.append({"case": label, "check": "binding_predicates"})

    mutations = [
        ("exact decimal equal", {"threshold": Decimal("0.10000000000000000001")}, {"threshold": Decimal("0.10000000000000000001")}, True),
        ("exact decimal unequal", {"threshold": Decimal("0.10000000000000000001")}, {"threshold": Decimal("0.1")}, False),
        ("object order irrelevant", {"x": 1, "y": 2}, {"y": 2, "x": 1}, True),
        ("array order significant", {"x": [1, 2]}, {"x": [2, 1]}, False),
        ("boolean differs from number", {"enabled": True}, {"enabled": 1}, False),
    ]
    for name, left, right, expected in mutations:
        actual = exact_json(left, right)
        print(json.dumps({"event": "exact_json_mutation", "case": name, "expected_equal": expected, "actual_equal": actual}, ensure_ascii=False))
        if actual != expected:
            mismatches.append({"case": name, "check": "exact_json_mutation"})
    print(json.dumps({"event": "result", "schema_instances": total, "passed": passed, "rejected": rejected, "non_documents_skipped": skipped, "incremental_judge_instances": judged, "exact_json_value_mutations": len(mutations), "mismatches": mismatches}, ensure_ascii=False))
    return 1 if mismatches else 0


if __name__ == "__main__":
    raise SystemExit(main())
