import { readFileSync, mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs'
import { resolve, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import { describe, expect, it } from 'vitest'
import { IDENTITY_TYPE_NAMES } from '@omne-harness-lite/identity-values'
import {
  collectSources,
  corePureImports,
  createIdentityDecisionInputs,
  IDENTITY_CHECK_INPUTS,
  identityAccountReferences,
  identityDecisionInputs,
  identityScopeColumns,
  noWallClock,
  noTestingImport,
  runRules,
  type SourceFile,
} from '../src/index.ts'

const file = (path: string, text: string): SourceFile => ({ path, text })
const root = fileURLToPath(new URL('../../../', import.meta.url))
const real = (path: string): SourceFile =>
  file(path, readFileSync(join(root, 'packages', path), 'utf8'))

// 独立列出节点范围，防止新增规则遗漏一个包而测试仍通过。
const purePackages = [
  'content-blocks',
  'asset-model',
  'model-profile',
  'call-accounts',
  'messages',
  'tool-definition',
  'loop-extension',
  'skill-package',
  'connector',
  'mcp-endpoint',
  'arrival-events',
  'model-response',
  'slash-command',
  'stream-assembly',
  'asset-evaluation',
]

describe('core-pure-imports', () => {
  it('OE1 精确资源入口只授予已登记依赖，不准许版本通配或私有路径', () => {
    for (const pkg of [
      'asset-model',
      'call-accounts',
      'loop-extension',
      'mcp-endpoint',
      'messages',
      'model-profile',
      'model-response',
    ]) {
      const path = `core/${pkg}/src/schema.ts`
      expect(
        corePureImports.check([
          file(path, `import schema from '@omne-harness-lite/offer-expiry/schema/v1'`),
        ]),
      ).toEqual([])
      for (const specifier of [
        '@omne-harness-lite/offer-expiry/schema/v2',
        '@omne-harness-lite/offer-expiry/schema/v1/private',
        '@omne-harness-lite/offer-expiry/schema/v1.json',
        '@omne-harness-lite/offer-expiry/schema/offer-expiry.v1.schema.json',
        '@omne-harness-lite/offer-expiry/src/index.ts',
      ])
        expect(corePureImports.check([file(path, `import '${specifier}'`)])).toHaveLength(1)
    }
    for (const pkg of ['content-blocks', 'tool-definition', 'arrival-events'])
      expect(
        corePureImports.check([
          file(`core/${pkg}/src/index.ts`, `import '@omne-harness-lite/offer-expiry/schema/v1'`),
        ]),
      ).toHaveLength(1)
  })

  it('中性 Schema runtime 从批准的 content-blocks 依赖公开子入口消费', () => {
    for (const pkg of ['asset-model', 'tool-definition', 'messages', 'mcp-endpoint']) {
      expect(
        corePureImports.check([
          file(
            `core/${pkg}/src/schema.ts`,
            `import { createSchemaRuntime } from '@omne-harness-lite/content-blocks/schema-runtime'`,
          ),
        ]),
      ).toEqual([])
      for (const specifier of [
        '@omne-harness-lite/content-blocks/schema-runtime/private',
        '@omne-harness-lite/content-blocks/schema-runtime.js',
        '@omne-harness-lite/content-blocks/src/schema-runtime/index.ts',
        '@omne-harness-lite/content-blocks/dist/schema-runtime/index.js',
        '@omne-harness-lite/content-blocks/testing',
        'node:fs',
      ])
        expect(
          corePureImports.check([file(`core/${pkg}/src/schema.ts`, `import '${specifier}'`)]),
        ).toHaveLength(1)
    }
    expect(
      corePureImports.check([
        file(
          'core/mcp-endpoint/src/schema.ts',
          `import '@omne-harness-lite/content-blocks/json-runtime'`,
        ),
      ]),
    ).toHaveLength(1)
    expect(
      corePureImports.check([
        file(
          'core/content-blocks/src/schema.ts',
          `import '@omne-harness-lite/content-blocks/schema-runtime'`,
        ),
      ]),
    ).toHaveLength(1)
  })

  it('MCP 中性技术边只允许已批准 CB 根／Schema/runtime 子入口，不扩大为任意子路径', () => {
    const path = 'core/mcp-endpoint/src/values.ts'
    for (const statement of [
      `import { readJsonStrict, writeJsonLossless } from '@omne-harness-lite/content-blocks'`,
      `import schema from '@omne-harness-lite/content-blocks/schema'`,
      `import { createSchemaRuntime } from '@omne-harness-lite/content-blocks/schema-runtime'`,
      `export type { SchemaDocument } from '@omne-harness-lite/content-blocks/schema-runtime'`,
      `type Value = import('@omne-harness-lite/content-blocks').JsonValue`,
      `const runtime = import('@omne-harness-lite/content-blocks/schema-runtime')`,
      String.raw`import '\u0040omne-harness-lite/content-blocks/schema-runtime'`,
    ])
      expect(corePureImports.check([file(path, statement)])).toEqual([])
    for (const specifier of [
      '@omne-harness-lite/content-blocks/schema-runtime/private',
      '@omne-harness-lite/content-blocks/schema-testing',
      '@omne-harness-lite/content-blocks/testing',
      '@omne-harness-lite/content-blocks/json-runtime',
      '@omne-harness-lite/content-blocks/src/json.ts',
      '@omne-harness-lite/content-blocks/dist/index.js',
      '@omne-harness-lite/asset-model/schema-runtime',
      '../../content-blocks/src/index.ts',
      'node:fs',
      'node:child_process',
    ])
      expect(corePureImports.check([file(path, `import '${specifier}'`)])).toHaveLength(1)
    for (const statement of [
      `const runtime = import(runtimePath)`,
      `const runtime = import('@omne-harness-lite/content-blocks/' + name)`,
      `const runtime = require(runtimePath)`,
    ])
      expect(corePureImports.check([file(path, statement)])).toHaveLength(1)
  })

  it('AM 已迁出的旧 schema-runtime 不再是公开入口，即使包依赖仍批准', () => {
    for (const statement of [
      `import { createSchemaRuntime } from '@omne-harness-lite/asset-model/schema-runtime'`,
      `export { createSchemaRuntime } from '@omne-harness-lite/asset-model/schema-runtime'`,
      `type Runtime = import('@omne-harness-lite/asset-model/schema-runtime').SchemaRuntime`,
      `const runtime = import('@omne-harness-lite/asset-model/schema-runtime')`,
      String.raw`import '\u0040omne-harness-lite/asset-model/schema-runtime'`,
    ]) {
      expect(
        corePureImports.check([file('core/tool-definition/src/parameter.ts', statement)]),
      ).toHaveLength(1)
      expect(
        corePureImports.check([file('core/content-blocks/src/parameter.ts', statement)]),
      ).toHaveLength(1)
    }
    for (const specifier of [
      '@omne-harness-lite/asset-model/schema-runtime/private',
      '@omne-harness-lite/asset-model/schema-runtime.js',
      '@omne-harness-lite/asset-model/src/schema-runtime.ts',
      '@omne-harness-lite/asset-model/dist/schema-runtime.js',
      '@omne-harness-lite/asset-model/testing',
      '@omne-harness-lite/asset-model/unknown',
      'node:fs',
      'node:child_process',
    ]) {
      expect(
        corePureImports.check([
          file('core/tool-definition/src/parameter.ts', `import '${specifier}'`),
        ]),
      ).toHaveLength(1)
    }
  })

  it.each(purePackages)('%s 不导入 Cordis、kernel、storage 或非 core 插件', pkg => {
    for (const specifier of [
      '@deepseek-ai/cordis',
      '@omne-harness-lite/kernel-basis',
      '@omne-harness-lite/storage',
      '@omne-harness-lite/asset-governance',
    ]) {
      const source = file(`core/${pkg}/src/index.ts`, `import type { Value } from '${specifier}'`)
      expect(corePureImports.check([source])).toHaveLength(1)
    }
  })

  it('精确公开依赖与纯构件可用；不自动准许其他 core 包', () => {
    const good = [
      file(
        'core/content-blocks/src/index.ts',
        `import { parseAccountId } from '@omne-harness-lite/identity-values'
import schema from '@omne-harness-lite/identity-values/schema'
import Ajv from 'ajv/dist/2020.js'
import { parse } from './strict.ts'
import localSchema from '../schema/content-blocks.schema.json'`,
      ),
      file('core/asset-model/src/hash.ts', `import { createHash } from 'node:crypto'`),
      file(
        'core/asset-evaluation/src/index.ts',
        `import { writeJsonLossless } from '@omne-harness-lite/content-blocks'
import { createHash } from 'node:crypto'`,
      ),
      file(
        'core/stream-assembly/src/index.ts',
        `import { Buffer } from 'node:buffer'
import { ArrivalEnvelope } from '@omne-harness-lite/arrival-events'`,
      ),
      file('core/skill-package/src/parse.ts', `import { parseDocument } from 'yaml'`),
      file(
        'core/tool-definition/src/pattern.ts',
        `import { RegExpParser } from '@eslint-community/regexpp'`,
      ),
    ]
    expect(corePureImports.check(good)).toEqual([])
    expect(
      corePureImports.check([
        file(
          'core/content-blocks/src/x.ts',
          `import { createState } from '@omne-harness-lite/stream-assembly'`,
        ),
      ]),
    ).toHaveLength(1)
  })

  it('不经私有 src、dist、未登记子入口或相对路径穿透包边界', () => {
    for (const specifier of [
      '@omne-harness-lite/identity-values/src/values',
      '@omne-harness-lite/identity-values/dist/index.js',
      '@omne-harness-lite/identity-values/secret',
      '../../identity-values/src/index.ts',
      '../../../infra/clock/src/index.ts',
      '../schema/hidden.ts',
      'node:fs',
      'node:child_process',
    ])
      expect(
        corePureImports.check([
          file('core/content-blocks/src/x.ts', `export * from '${specifier}'`),
        ]),
      ).toHaveLength(1)
  })

  it('asset-model S-17 可用纯 path 字面规范化；其他节点不因此获得路径依赖', () => {
    for (const specifier of ['node:path', 'path']) {
      const source = file(
        'core/asset-model/src/workspace.ts',
        `import { isAbsolute, normalize } from '${specifier}'
export const normalizeDirectory = (path: string) => isAbsolute(path) ? normalize(path) : undefined`,
      )
      expect(corePureImports.check([source])).toEqual([])
      expect(
        corePureImports.check([file('core/content-blocks/src/x.ts', source.text)]),
      ).toHaveLength(1)
    }
    for (const specifier of [
      'node:fs',
      '@deepseek-ai/cordis',
      '@omne-harness-lite/asset-governance',
    ]) {
      expect(
        corePureImports.check([file('core/asset-model/src/workspace.ts', `import '${specifier}'`)]),
      ).toHaveLength(1)
    }
  })

  it('已明确采用 JSON 工具的节点可通过 content-blocks 公开入口复用', () => {
    for (const pkg of [
      'asset-model',
      'call-accounts',
      'messages',
      'arrival-events',
      'model-response',
      'stream-assembly',
      'asset-evaluation',
    ]) {
      expect(
        corePureImports.check([
          file(
            `core/${pkg}/src/json.ts`,
            `import { readJsonStrict, writeJsonLossless } from '@omne-harness-lite/content-blocks'`,
          ),
        ]),
      ).toEqual([])
    }
  })

  it('静态、重导出、类型导入、require、import()、转义字面量都查；计算说明符拒绝', () => {
    const source = file(
      'core/content-blocks/src/x.ts',
      [
        `import '@deepseek-ai/cordis'`,
        `export { Value } from '@omne-harness-lite/storage'`,
        `type T = import('@omne-harness-lite/kernel-basis').Value`,
        `const a = require('@omne-harness-lite/storage')`,
        `const b = import('@omne-harness-lite/storage')`,
        `import K = require('@omne-harness-lite/storage')`,
        String.raw`import '\u0040omne-harness-lite/storage'`,
        `const d = import(computed)`,
        `const e = require('node:' + name)`,
        `// import '@deepseek-ai/cordis'`,
        `const note = "import '@deepseek-ai/cordis'"`,
      ].join('\n'),
    )
    expect(corePureImports.check([source]).map(v => v.line)).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9])
  })

  it('既有 kernel/storage 职责例外；产品测试不限制', () => {
    expect(
      corePureImports.check([
        file('core/kernel-basis/src/x.ts', `import { Context } from '@deepseek-ai/cordis'`),
        file('core/storage/src/x.ts', `import { Kysely } from 'kysely'`),
        file('core/content-blocks/tests/x.spec.ts', `import fs from 'node:fs'`),
      ]),
    ).toEqual([])
  })

  it('collectSources + CLI 真实临时包：坏依赖退出1，合法包退出0', () => {
    const scratch = join(root, 'tmp')
    mkdirSync(scratch, { recursive: true })
    const dir = mkdtempSync(join(scratch, 'core-rules-'))
    try {
      const src = join(dir, 'core/content-blocks/src')
      mkdirSync(src, { recursive: true })
      const path = join(src, 'index.ts')
      writeFileSync(path, `import { Context } from '@deepseek-ai/cordis'`)
      expect(runRules(collectSources(dir)).map(v => v.rule)).toContain('core-pure-imports')
      const cli = resolve(root, 'tools/ts-checks/src/cli.ts')
      const bad = spawnSync(process.execPath, ['--experimental-strip-types', cli, dir], {
        encoding: 'utf8',
      })
      expect(bad.status).toBe(1)
      expect(bad.stderr).toContain('[core-pure-imports]')
      writeFileSync(path, `import { parseAccountId } from '@omne-harness-lite/identity-values'`)
      const good = spawnSync(process.execPath, ['--experimental-strip-types', cli, dir], {
        encoding: 'utf8',
      })
      expect(good.status).toBe(0)
      expect(good.stdout).toContain('PASS:')
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  }, 20_000) // Each CLI invocation now also checks the real repository's restricted entry paths.
})

describe('SC-OE-3 no-wall-clock', () => {
  it('字面解码、globalThis、const 与解构别名仍禁止取墙钟，显式转换保持合法', () => {
    const source = file(
      'core/offer-expiry/src/time.ts',
      String.raw`const current = Date.now
const { now: measure } = performance
const Constructor = Date
current()
measure()
new Constructor()
Date['\u006eow']()
globalThis.Date.now()
globalThis['performance']['now']()
new Constructor(issuedAt)`,
    )
    expect(noWallClock.check([source]).map(value => value.line)).toEqual([4, 5, 6, 7, 8, 9])
    expect(
      noWallClock.check([
        file('infra/clock/src/clock.ts', source.text),
        file('core/offer-expiry/tests/time.spec.ts', source.text),
      ]),
    ).toEqual([])
  })

  it('Date.now、new Date()、performance.now 各有必红反例，并保留原真实扫描', () => {
    const source = file(
      'core/content-blocks/src/x.ts',
      `Date.now()
new Date( )
performance . now ( )`,
    )
    expect(noWallClock.check([source]).map(v => v.line)).toEqual([1, 2, 3])
    expect(
      noWallClock.check([
        file(
          source.path,
          `const d = new Date(issuedAt)
const note = 'new Date()'; // Date.now()
const t = clock.now()`,
        ),
        file('infra/clock/src/clock.ts', 'Date.now(); new Date(); performance.now()'),
        file('core/content-blocks/tests/x.spec.ts', 'new Date()'),
      ]),
    ).toEqual([])
  })
})

describe('no-testing-import — 解码后的真实说明符', () => {
  it('静态、侧效应、动态、重导出、类型与 require 的 testing 入口都红', () => {
    const source = file(
      'core/kernel-basis/src/consumer.ts',
      String.raw`import '@omne-harness-lite/offer-expiry/testing'
export { testClock } from '@omne-harness-lite/offer-expiry/testing'
type Clock = import('@omne-harness-lite/offer-expiry/testing').TestClock
const testing = import('@omne-harness-lite/offer-expiry/testing')
const clock = require('@omne-harness-lite/offer-expiry/testing')
import Test = require('@omne-harness-lite/offer-expiry/testing')
import '\u0040omne-harness-lite/offer-expiry/testing'
import '@omne-harness-lite/offer-expiry/testing/private'
// import '@omne-harness-lite/offer-expiry/testing'
const note = "from '@omne-harness-lite/offer-expiry/testing'"`,
    )
    expect(noTestingImport.check([source]).map(value => value.line)).toEqual([
      1, 2, 3, 4, 5, 6, 7, 8,
    ])
    expect(
      noTestingImport.check([file('core/kernel-basis/tests/consumer.spec.ts', source.text)]),
    ).toEqual([])
    expect(
      noTestingImport.check([
        file(
          source.path,
          `import '@omne-harness-lite/offer-expiry'; import '@omne-harness-lite/offer-expiry/schema'`,
        ),
      ]),
    ).toEqual([])
  })
})

describe('identity SC-1 精确输入', () => {
  const path = 'assets/asset-governance/src/admission.ts'
  const rule = createIdentityDecisionInputs({
    ...IDENTITY_CHECK_INPUTS,
    decisionTargets: [{ path, functionName: 'canAccess' }],
  })

  it('规则输入消费公开身份类型清单，非第二份领域名单', () => {
    expect(IDENTITY_CHECK_INPUTS.identityTypeNames).toBe(IDENTITY_TYPE_NAMES)
    expect(Object.isFrozen(IDENTITY_CHECK_INPUTS.identityTypeNames)).toBe(true)
  })

  it('登记准入参数的物理品牌、嵌套成员、本地别名、具名import改名必红', () => {
    const source = file(
      path,
      `import type { HostName as Remote } from './physical.ts'
type Physical = Branded<string, 'FilePath'>
interface Basis { actor: TenantId; host: Remote; path: Physical }
export function canAccess(input: Basis): boolean { return true }`,
    )
    expect(rule.check([source])).toHaveLength(1)
    expect(rule.check([source])[0]?.message).toMatch(/HostName.*FilePath/)
  })

  it('身份/持有/效力输入合法；未点名的路径函数和组织结构谓词不受查', () => {
    const source = file(
      path,
      `export function canAccess(actor: TenantId, held: HoldingRecord, standing: MembershipStanding) { return true }
export function readFile(path: FilePath) { return path }
export function shareAncestor(parentOf: ParentSnapshot) { return true }`,
    )
    expect(rule.check([source])).toEqual([])
    expect(
      identityDecisionInputs.check([file(path, 'function readFile(path: FilePath) {}')]),
    ).toEqual([])
    expect(
      rule.check([
        file(path, `export function canAccess(input: { label: 'Path' }) { return true }`),
      ]),
    ).toEqual([])
  })

  it('品牌构造器改名不丢失物理品牌证据', () => {
    const source = file(
      path,
      `import type { Branded as Brand } from './brands.ts'
type Physical = Brand<string, 'FilePath'>
export function canAccess(path: Physical) { return true }`,
    )
    expect(rule.check([source])).toHaveLength(1)
    expect(rule.check([source])[0]?.message).toContain('FilePath')
  })

  it('@identityDecision 标注函数、箭头和方法同样查，不把注释字样当任意函数', () => {
    const source = file(
      path,
      `/** @identityDecision */
export function judge(host: HostName) { return true }
/** @identityDecision */
export const judgeArrow = (env: EnvironmentVariables) => true
class Guard {
  /** @identityDecision */
  judge(instance: RuntimeInstanceId) { return true }
}
// @identityDecision
function unrelated(path: FilePath) {}`,
    )
    expect(identityDecisionInputs.check([source])).toHaveLength(3)
  })

  it('注册目标/类型标注消失会红，身份与物理名字重叠输入拒绝', () => {
    expect(rule.check([file(path, 'export function renamed(actor: TenantId) {}')])).toHaveLength(1)
    expect(rule.check([])).toHaveLength(1)
    expect(rule.check([file(path, 'export function canAccess(actor) {}')])).toHaveLength(1)
    expect(() =>
      createIdentityDecisionInputs({
        ...IDENTITY_CHECK_INPUTS,
        identityTypeNames: ['TenantId'],
        physicalTypeNames: ['TenantId'],
      }),
    ).toThrow('重叠')
  })
})

describe('identity SC-2 账号记录', () => {
  const path = 'tenancy/account-identity/src/schema.ts'
  it('两个AccountId字段（含改名与品牌别名）必红；登录状态引用与合法账号记录不报', () => {
    const source = file(
      path,
      `import { type AccountId as Account } from '@omne-harness-lite/identity-values'
type LinkedAccount = OpaqueIdentifier<'AccountId'>
interface AccountRecord { id: Account; linked: LinkedAccount }
interface LoginStateRow { login: LoginStateId; account: AccountId }`,
    )
    expect(identityAccountReferences.check([source])).toHaveLength(1)
    expect(
      identityAccountReferences.check([
        file(path, 'interface AccountRecord { id: AccountId; identifier: LoginIdentifier }'),
      ]),
    ).toEqual([])
  })

  it('真实AccountRow原文通过；向string自身份记录添加一个typed引用必红', () => {
    const original = real(path)
    expect(identityAccountReferences.check([original])).toEqual([])
    const anchor = 'export interface AccountRow {'
    expect(original.text).toContain(anchor)
    const mutant = file(
      path,
      original.text.replace(anchor, `${anchor}\nreadonly linked: AccountId`),
    )
    expect(identityAccountReferences.check([mutant])).toHaveLength(1)
  })

  it('普通string聚类键语义不由类型语法检查证明', () => {
    expect(
      identityAccountReferences.check([
        file(path, 'interface AccountRow { account_id: string; arbitrary_cluster: string }'),
      ]),
    ).toEqual([])
  })
})

describe('identity SC-9 持久归属', () => {
  const path = 'core/asset-model/src/records.ts'
  it('optional、nullable、nullable本地别名成对列必红', () => {
    const source = file(
      path,
      `interface HoldingRecord { organization?: OrganizationId; tenant?: TenantId }
type HoldingRow = { organization: OrganizationId | null; tenant: TenantId | undefined }
type MaybeTenant = TenantId | null
interface HoldingTable { organization?: OrganizationId; tenant: MaybeTenant }`,
    )
    expect(identityScopeColumns.check([source])).toHaveLength(3)
  })

  it('合法ScopeLayerIdentity、两个互斥判别分支及不归属的读面不误报', () => {
    const source = file(
      path,
      `interface HoldingRecord { scope: ScopeLayerIdentity }
type OtherRow = { layer: 'organization'; organization: OrganizationId } | { layer: 'tenant'; tenant: TenantId }
interface SelectionReading { organization?: OrganizationId; tenant?: TenantId }
interface MemberRecord { organization: OrganizationId; tenant: TenantId }`,
    )
    expect(identityScopeColumns.check([source])).toEqual([])
  })

  it('@scopedRecord明确标注持久形状；测试免查', () => {
    const text = `/** @scopedRecord */
interface StoredObject { organization?: OrganizationId; tenant?: TenantId }`
    expect(identityScopeColumns.check([file(path, text)])).toHaveLength(1)
    expect(identityScopeColumns.check([file('core/asset-model/tests/x.spec.ts', text)])).toEqual([])
  })
})

it('allows a data module to statically load its own exported Schema', () => {
  const violations = corePureImports.check([
    {
      path: 'core/content-blocks/src/schema.ts',
      text: "import schema from '@omne-harness-lite/content-blocks/schema' with { type: 'json' }",
    },
  ])
  expect(violations).toEqual([])
})
