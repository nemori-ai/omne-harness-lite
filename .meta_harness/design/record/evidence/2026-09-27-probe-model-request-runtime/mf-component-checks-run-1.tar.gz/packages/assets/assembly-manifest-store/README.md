# assembly-manifest-store

开发入口与采用范围见 [实现映射](../../../.meta_harness/design/realization/packages/assets/assembly-manifest-store/README.md)。

从仓库根依次运行：

```sh
pnpm --filter @omne-harness-lite/assembly-manifest-store... run build
pnpm --filter @omne-harness-lite/assembly-manifest-store run typecheck
pnpm --filter @omne-harness-lite/assembly-manifest-store run test
```

测试使用临时 SQLite 文件；杀进程测试加载构建产物，因此先构建。数据库迁移通过公开 `assemblyManifestMigrations` 与装配其余迁移合成，迁移确认由装配负责。

公共入口同时提供纯构件、`createAssemblyManifestStore` 和 Cordis 插件。独立闭包及插件借用 storage；调用方在闭包排空后关闭自身持有的 storage。当前组件测试与完整纵线验收范围分别记录在实现映射的验证材料中。
