import { createAssemblyManifestStore, checkManifestGivenReadInput,
  type AssemblyManifestService, type GivenReadResult } from '@omne-harness-lite/assembly-manifest-store'
import type { Storage } from '@omne-harness-lite/storage'
declare const storage: Storage
const service: AssemblyManifestService = createAssemblyManifestStore(storage)
const result: Promise<GivenReadResult> = service.readGiven('session', 0)
const represented = checkManifestGivenReadInput('session', 0)
void result
void represented
