import { mkdtemp, mkdir, symlink, copyFile, writeFile, rm, readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
const evidence = fileURLToPath(new URL('./',import.meta.url))
const tree = fileURLToPath(new URL('../../../',import.meta.url))
const modules = join(tree,'packages/assets/assembly-manifest-store/node_modules')
const external = await mkdtemp(join(tmpdir(),'mf-artifact-consumer-'))
const results = []
function run(command,args) {
  const result = spawnSync(command,args,{cwd:external,encoding:'utf8'})
  const item = {command,args,cwd:external,status:result.status,stdout:result.stdout,stderr:result.stderr,
    error:result.error?.name}
  results.push(item)
  process.stdout.write(result.stdout ?? '')
  process.stderr.write(result.stderr ?? '')
  if (result.status !== 0) throw new Error('artifact consumer failed')
}
try {
  run('tar',['-xzf',join(evidence,'manifest.tgz'),'-C',external])
  await symlink(modules,join(external,'package/node_modules'))
  await mkdir(join(external,'node_modules/@omne-harness-lite'),{recursive:true})
  await symlink(join(external,'package'),join(external,'node_modules/@omne-harness-lite/assembly-manifest-store'))
  for(const name of ['storage-sql','storage','asset-evaluation','identity-values','content-blocks'])
    await symlink(join(modules,'@omne-harness-lite',name),join(external,'node_modules/@omne-harness-lite',name))
  for(const name of ['@deepseek-ai','@types']) await symlink(join(modules,name),join(external,'node_modules',name))
  await writeFile(join(external,'package.json'),JSON.stringify({type:'module',private:true}))
  for(const name of ['consumer.mjs','consumer.ts']) await copyFile(join(evidence,name),join(external,name))
  await writeFile(join(external,'tsconfig.json'),JSON.stringify({compilerOptions:{module:'NodeNext',moduleResolution:'NodeNext',
    target:'ES2023',strict:true,noEmit:true,skipLibCheck:false},include:['consumer.ts']}))
  run(join(tree,'node_modules/.bin/tsc'),['-p','tsconfig.json'])
  run(process.execPath,['consumer.mjs'])
} finally {
  await writeFile(join(evidence,'results.json'),JSON.stringify({node:process.version,tree,
    artifactSha256:createHash('sha256').update(await readFile(join(evidence,'manifest.tgz'))).digest('hex'),
    dependencyBoundary:'packed MF exports; exact built workspace dependencies linked explicitly; no network installation or portability claim',results},null,2)+'\n')
  await rm(external,{recursive:true,force:true})
}
