import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Context } from '@deepseek-ai/cordis'
import { openStorage } from '@omne-harness-lite/storage-sql'
import { composeMigrations } from '@omne-harness-lite/storage'
import { evaluate } from '@omne-harness-lite/asset-evaluation'
import { parseTenantId, unwrap } from '@omne-harness-lite/identity-values'
import { toOpaqueJson, LosslessNumber, writeJsonLossless } from '@omne-harness-lite/content-blocks'
import { createAssemblyManifestStore, assemblyManifestMigrations, assemblyManifestStorePlugin,
  checkManifestGivenReadInput } from '@omne-harness-lite/assembly-manifest-store'

assert.ok('ok' in checkManifestGivenReadInput('session', new LosslessNumber('1e999999')))
const root = { category: 'agent_definition', name: 'example:root' }
const result = evaluate({ tenant: unwrap(parseTenantId({organization:'org_example',account:'acc_example'})),
  standing: {standing:'effective',role:'member'},
  root: {definition:root,references:[],attributes:[],source:{asset:'ast_example',version:1}},
  holdings:[{holder:{layer:'factory'},capability:root,asset:'ast_example',basis:{kind:'official'},
    versionSelection:{kind:'current'},immutable:false,assignments:[],since:'2026-09-27T00:00:00Z'}],
  definitions:[{id:'ast_example',capability:root,origin:'official',versions:[{number:1,
    content:{category:'agent_definition',body:toOpaqueJson({references:[],attributes:[]})},publishedAt:'2026-09-27T00:00:00Z'}]}]})
assert.ok('ok' in result)
const folder = await mkdtemp(join(tmpdir(),'mf-artifact-data-'))
const storage = await openStorage({dialect:'sqlite',file:join(folder,'db.sqlite'),
  migrations:composeMigrations(assemblyManifestMigrations),upgrade:false})
try {
  const standalone = createAssemblyManifestStore(storage)
  assert.deepEqual(await standalone.readGiven('session',0),{none:true})
  assert.deepEqual(await standalone.append('session',0,{evaluation:{kind:'given',ref:'given_a'},
    tables:{tool:{filledAt:1,composition:{exact:new LosslessNumber('9007199254740993')}}},
    content:{evaluation:result.ok,compositionOrder:[],extra:new LosslessNumber('0.10000000000000000001')}}),
    {seq:1,head:1,evaluationRef:'given_a'})
  const original = await standalone.readGiven('session',1)
  assert.ok('record' in original)
  assert.ok(writeJsonLossless(original.record.content).includes('0.10000000000000000001'))
  await standalone.close()
  const ctx = new Context()
  ctx.provide('storage',storage)
  const fiber = ctx.plugin(assemblyManifestStorePlugin,{})
  await fiber
  const service = ctx.get('assemblyManifest')
  assert.deepEqual(Object.keys(service).sort(),['append','dependencyPresence','readEvaluation','readGiven','readHead','readHistory'].sort())
  assert.deepEqual(await service.readGiven('session',1),original)
  await fiber.dispose()
  assert.deepEqual(await service.readGiven('session',1),{failure:'unavailable'})
  assert.deepEqual((await storage.read(async tx => tx.db.selectFrom('assembly_manifest_record').select('seq').execute())).map(row => row.seq),[1])
  process.stdout.write('PASS: packed MF4 runtime export, standalone closure, real SQLite, lossless values and actual Cordis six-operation service\n')
} finally {
  await storage.close()
  await rm(folder,{recursive:true,force:true})
}
