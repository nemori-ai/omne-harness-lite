#!/usr/bin/env node
import { runCli, providers } from './application.ts'

const controller = new AbortController()
const stop = () => controller.abort()
for (const signal of ['SIGINT', 'SIGTERM', 'SIGHUP'] as const) process.on(signal, stop)
// The single process entry owns these streams until process termination. A write
// callback rejection is handled by runCli; emitted error events must not escape it.
process.stdout.on('error', () => {})
process.stderr.on('error', () => {})
const write = (stream: NodeJS.WriteStream, text: string) =>
  new Promise<void>((resolve, reject) => {
    stream.write(text, error => (error == null ? resolve() : reject(new Error('output-failed'))))
  })
try {
  process.exitCode = await runCli(process.argv.slice(2), {
    ...providers(),
    signal: controller.signal,
    stdoutIsTTY: process.stdout.isTTY === true,
    stdout: text => write(process.stdout, text),
    stderr: text => write(process.stderr, text),
  })
} catch {
  process.exitCode = 70
  try {
    await write(process.stderr, 'omne: internal-defect\n')
  } catch {
    /* no recursive diagnostics */
  }
} finally {
  for (const signal of ['SIGINT', 'SIGTERM', 'SIGHUP'] as const) process.off(signal, stop)
}
