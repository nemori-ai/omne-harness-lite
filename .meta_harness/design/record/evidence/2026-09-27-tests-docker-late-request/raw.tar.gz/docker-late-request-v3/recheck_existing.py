#!/usr/bin/env python3
"""Read-only v3 oracle recheck of the v2 run; never starts Docker."""

import hashlib
import json
from pathlib import Path
import re

import oracle


HERE = Path(__file__).resolve().parent
RUN = HERE.parent / "docker-late-request-v2/runs/20260927T013409Z-1d405f02"
FROZEN = {
    "base_driver.py": "base_driver", "driver.py": "driver", "oracle.py": "oracle",
    "inventory.mjs": "inventory", "helper_probe.mjs": "helper_probe",
    "pid_absence.mjs": "pid_absence", "kill_helper.mjs": "kill_helper",
    "lock_holders.mjs": "lock_holders", "proxy_rules.mjs": "proxy_rules",
    "late_proxy.mjs": "late_proxy", "proxy_admin.mjs": "proxy_admin",
    "i3-manifest.json": "i3_manifest", "health.mjs": "health",
    "omne-center": "helper", "compose.yaml": "compose",
    "compose.maintenance.yaml": "maintenance_compose",
    "omne-center-backup@.service": "service", "omne-center-backup@.timer": "timer",
}


def digest(value):
    return hashlib.sha256(value).hexdigest()


def tree_snapshot():
    files = {}
    for path in sorted(RUN.rglob("*")):
        if path.is_symlink():
            raise ValueError("symlink in old run: " + str(path))
        if path.is_file():
            files[str(path.relative_to(RUN))] = {
                "bytes": path.stat().st_size, "sha256": digest(path.read_bytes())}
    canonical = json.dumps(files, sort_keys=True, separators=(",", ":")).encode()
    return digest(canonical), files


def main():
    if not RUN.is_dir() or RUN.is_symlink():
        raise ValueError("old run is missing or linked")
    old_run_sha256, files = tree_snapshot()
    evidence_bytes = (RUN / "evidence.json").read_bytes()
    evidence = json.loads(evidence_bytes)
    if len(evidence["commands"]) != 107 or evidence.get("oracle_exit") != 1:
        raise ValueError("unexpected old run command count or original verdict")
    if b"original center start not healthy" not in (RUN / "oracle.stderr").read_bytes():
        raise ValueError("original oracle failure evidence changed")
    for filename, key in FROZEN.items():
        if files["inputs/" + filename]["sha256"] != evidence["inputs"]["sha256"][key]:
            raise ValueError("old frozen input differs: " + filename)
    if files["inputs/i3-manifest.json"]["sha256"] != evidence["artifact_manifest_sha256"]:
        raise ValueError("old artifact manifest differs")

    raw = {}
    seen = set()
    for item in evidence["commands"]:
        label = item["label"]
        if not re.fullmatch(r"[A-Za-z0-9_.@-]+", label) or label in seen:
            raise ValueError("duplicate or unsafe command label")
        seen.add(label)
        for stream in ("stdout", "stderr"):
            relative = "raw/" + label + "." + stream
            if item[stream] != relative or relative not in files:
                raise ValueError("raw command stream path missing/mismatched: " + label)
            raw[label, stream] = (RUN / relative).read_bytes()
            if digest(raw[label, stream]) != files[relative]["sha256"]:
                raise ValueError("raw command stream changed during read: " + label)
    proxy_log = (RUN / "raw/proxy-events.jsonl").read_bytes()
    if digest(proxy_log) != files["raw/proxy-events.jsonl"]["sha256"]:
        raise ValueError("proxy log changed during read")

    result = oracle.evaluate_observation(evidence, raw, proxy_log)
    oracle.demand(evidence.get("cleanup_complete") is True and
                  not evidence.get("independent_host_errors"),
                  "old private resource cleanup/independent audit incomplete")
    after_sha256, _ = tree_snapshot()
    if after_sha256 != old_run_sha256:
        raise ValueError("old run changed during recheck")
    return {
        "kind": "additional-read-only-recheck-of-existing-v2-observation",
        "new_product_run": False,
        "old_run": str(RUN), "old_run_sha256": old_run_sha256,
        "old_evidence_sha256": digest(evidence_bytes),
        "old_frozen_oracle_sha256": files["inputs/oracle.py"]["sha256"],
        "v3_oracle_sha256": digest((HERE / "oracle.py").read_bytes()),
        "frozen_inputs_verified": len(FROZEN),
        "raw_command_streams_verified": len(raw),
        "old_run_files_hashed": len(files),
        "original_oracle_exit": evidence["oracle_exit"],
        "additional_oracle_result": result,
    }


if __name__ == "__main__":
    try:
        print(json.dumps(main(), sort_keys=True))
    except Exception as error:
        print(json.dumps({"kind": "additional-read-only-recheck-of-existing-v2-observation",
                          "new_product_run": False, "status": "unverified",
                          "error": f"{type(error).__name__}: {error}"}, sort_keys=True))
        raise SystemExit(1)
