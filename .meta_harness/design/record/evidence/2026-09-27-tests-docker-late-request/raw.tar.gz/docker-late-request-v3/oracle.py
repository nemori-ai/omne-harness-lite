#!/usr/bin/env python3
"""Independent raw-byte oracle for one causally late, original center stop request."""

import base64
import hashlib
import json
import pathlib
import re
import sys

BUILD_ID = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
IMAGE_ID = "sha256:27c0665146265afefe39012aaea26bdae7499784eaaeb74aea712a6fcdfc03f2"
I3_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
SOCKET = "unix:///opt/omne-private-docker/docker.sock"
HELPER = "/usr/local/libexec/omne-center"
QA_DIR = "/opt/omne-r5-qa"
RUN_DIR = "/run/omne-center-qa"
QA_SOCKET = "unix://" + RUN_DIR + "/docker.sock"
QA_ADMIN = RUN_DIR + "/control.sock"
QA_LOG = "/var/lib/omne-tenancy/state/qa/late-proxy.jsonl"
EMPTY_SHA = hashlib.sha256(b"").hexdigest()
CID = re.compile(r"[0-9a-f]{64}\Z")
IMAGE = re.compile(r"sha256:[0-9a-f]{64}\Z")
KILL_PATH = re.compile(r"/(?:v[0-9]+\.[0-9]+/)?containers/([0-9a-f]{64})/kill\Z")
HEALTH = {"reachable", "centerId", "version", "startedAt", "storageReachable",
          "deploymentKeyPresent", "deploymentKeyComplete", "clockSane", "defectCount",
          "deploymentParameters"}


def demand(ok, message):
    if not ok:
        raise ValueError(message)


def one(data, label):
    demand(isinstance(data, bytes) and data.endswith(b"\n") and data.count(b"\n") == 1,
           label + ": exactly one JSON+LF required")
    result = json.loads(data)
    demand(isinstance(result, dict), label + ": object required")
    return result


def proc_argv(encoded, label):
    raw = base64.b64decode(encoded, validate=True)
    demand(len(raw) > 1 and raw[-1:] == b"\0", label + ": raw cmdline required")
    return raw[:-1].decode("utf8", "strict").split("\0")


def evaluate_observation(e, raw, proxy_log):
    entries = e["commands"]
    rows = {item["label"]: item for item in entries}
    demand(len(rows) == len(entries), "duplicate command label")
    order = list(rows)
    stages = ("load-image", "inner-image-list", "inner-image-inspect",
              "outer-product-image", "original-inventory", "validate", "start", "center-before",
              "health-before", "status-before", "qa-proxy", "helper-pidfile-absent",
              "stop-helper", "helper-probe", "lock-held-before-kill",
              "center-held-before-kill", "signal-helper", "proxy-before-close",
              "close-caller", "lock-held-after-close", "lock-flock-available",
              "lock-after-flock", "status-pending", "center-pending",
              "health-pending", "proxy-pending", "events-before-release",
              "release-original", "center-wait", "center-final", "status-final",
              "events-after-release", "capture-proxy-log")
    demand(all(label in rows for label in stages) and
           [order.index(label) for label in stages] == sorted(order.index(label) for label in stages),
           "scenario stages or causal order missing")
    demand(e.get("scenario") == "late-original-stop" and
           e.get("status") == "observed-awaiting-oracle" and
           e.get("business_complete") is True and
           e.get("artifact_manifest_sha256") == I3_SHA and
           e["inputs"]["image_id"] == IMAGE_ID and e["inputs"]["build_id"] == BUILD_ID,
           "unreviewed scenario or incomplete business observation")

    def row(label, code=0):
        item = rows[label]
        demand(item["returncode"] == code and not item.get("observation_expired"),
               label + ": actual client result missing or wrong")
        return item

    def out(label, stream="stdout"):
        value = raw.get((label, stream))
        demand(isinstance(value, bytes), label + ": missing raw " + stream)
        return value

    def obj(label, code=0):
        row(label, code)
        return one(out(label), label)

    def inspect(label, cid):
        row(label)
        value = json.loads(out(label))
        demand(isinstance(value, list) and len(value) == 1 and
               value[0].get("Id") == cid, label + ": wrong exact CID inspect")
        return value[0]

    cid = e["center_id"]
    demand(isinstance(cid, str) and CID.fullmatch(cid), "center CID invalid")
    expected = e["expected"]
    control = expected["control"]
    project = expected["project"]
    inner_image_id = expected.get("inner_image_id")
    demand(expected.get("image_id") == IMAGE_ID and
           isinstance(inner_image_id, str) and IMAGE.fullmatch(inner_image_id),
           "outer/inner reviewed image identity missing")
    direct = ["docker", "exec", "-e", "DOCKER_HOST=" + SOCKET, control, HELPER]
    inner = ["docker", "exec", control, "docker", "--host", SOCKET]
    for label, action in (("validate", "validate"), ("start", "start"),
                          ("health-before", "full-health"),
                          ("health-pending", "full-health"),
                          ("status-before", "status"), ("status-pending", "status"),
                          ("status-final", "status")):
        demand(rows[label]["argv"][:len(direct) + 1] == [*direct, action] and
               "--project" in rows[label]["argv"] and
               rows[label]["argv"][rows[label]["argv"].index("--project") + 1] == project,
               label + ": not official helper on this project/private Engine")
    demand(not any(item["argv"][:len(direct) + 1] == [*direct, action]
                   for item in entries for action in ("stop", "start")
                   if item["label"] not in ("start",)) and
           sum(item["label"] == "stop-helper" for item in entries) == 1,
           "unsupported lifecycle replay/new intent")
    inventory = obj("original-inventory")
    demand(inventory == {"status": "verified", "buildId": BUILD_ID, "files": 2851,
                         "links": 115, "manifestSha256": e["inputs"]["host_manifest_sha256"],
                         "node": "v24.21.0"}, "original complete app inventory failed")
    row("load-image")
    demand(rows["load-image"]["argv"] ==
           ["docker", "exec", "-i", expected["dind"], "docker", "--host", SOCKET, "load"],
           "image archive not loaded into private Engine")
    row("inner-image-list")
    demand(rows["inner-image-list"]["argv"] ==
           [*inner, "image", "ls", "-q", "--no-trunc",
            "--filter", "label=ai.nemori.omne.host-build-id=" + BUILD_ID] and
           out("inner-image-list") == (inner_image_id + "\n").encode(),
           "private Engine image identity ambiguous")

    def image_inspect(label, argv, image_id):
        row(label)
        demand(rows[label]["argv"] == argv, label + ": wrong image inspect target")
        images = json.loads(out(label))
        demand(isinstance(images, list) and len(images) == 1 and
               images[0].get("Id") == image_id, label + ": wrong inspected image ID")
        return images[0]

    inner_image = image_inspect("inner-image-inspect",
                                [*inner, "image", "inspect", inner_image_id], inner_image_id)
    outer_image = image_inspect("outer-product-image",
                                ["docker", "image", "inspect", IMAGE_ID], IMAGE_ID)
    rootfs = inner_image.get("RootFS")
    demand(isinstance(rootfs, dict) and rootfs.get("Type") == "layers" and
           isinstance(rootfs.get("Layers"), list) and len(rootfs["Layers"]) > 0 and
           all(isinstance(layer, str) and IMAGE.fullmatch(layer)
               for layer in rootfs["Layers"]) and rootfs == outer_image.get("RootFS") and
           inner_image.get("Os") == outer_image.get("Os") == "linux" and
           inner_image.get("Architecture") == outer_image.get("Architecture") == "arm64",
           "private/outer image RootFS or platform differs")
    for image in (inner_image, outer_image):
        labels = image.get("Config", {}).get("Labels", {})
        demand(labels.get("ai.nemori.omne.host-build-id") == BUILD_ID and
               labels.get("ai.nemori.omne.distribution") == "tenancy-host-docker/1",
               "private/outer adopted image labels differ")
    started = obj("start")
    demand(started.get("containerId") == cid and started.get("state") == "running" and
           started.get("health") == "healthy" and started.get("buildId") == BUILD_ID and
           started.get("imageId") == inner_image_id and
           rows["start"]["argv"].count("--image") == 1 and
           rows["start"]["argv"][rows["start"]["argv"].index("--image") + 1] == inner_image_id,
           "original center start not healthy or wrong private image")
    before = inspect("center-before", cid)
    held_inspect = inspect("center-held-before-kill", cid)
    pending_inspect = inspect("center-pending", cid)
    final = inspect("center-final", cid)
    for item in (before, held_inspect, pending_inspect, final):
        demand(item["Image"] == inner_image_id and
               item["Config"]["User"] == "10001:10001" and
               item["Config"]["StopSignal"] == "SIGTERM" and
               item["HostConfig"]["RestartPolicy"]["Name"] == "unless-stopped" and
               any(m.get("Destination") == "/state" and
                   m.get("Source") == e["expected"]["state"] for m in item["Mounts"]),
               "original center identity/image/config/mount changed")
    for item in (before, held_inspect, pending_inspect):
        demand(item["State"]["Status"] == "running" and item["State"]["Running"] is True and
               item["State"]["Pid"] == before["State"]["Pid"] > 0 and
               item["State"]["StartedAt"] == before["State"]["StartedAt"] and
               item["RestartCount"] == before["RestartCount"],
               "original center was no longer same running process while request pending")
    demand(final["State"]["Status"] == "exited" and final["State"]["ExitCode"] == 0 and
           final["RestartCount"] == before["RestartCount"],
           "same center did not actually stop clean after late request")
    for label, actual in (("status-before", before), ("status-pending", pending_inspect),
                          ("status-final", final)):
        status = obj(label)
        demand(status.get("containerId") == cid and status.get("imageId") == inner_image_id and
               status.get("buildId") == BUILD_ID and
               status.get("state") == actual["State"]["Status"] and
               status.get("restartCount") == actual["RestartCount"] and
               status.get("previousExit") == "unknown", label + ": status mismatches Engine")
        if label != "status-final":
            demand(status.get("running") is True and status.get("pid") == before["State"]["Pid"]
                   and status.get("exitCode") is None, label + ": false pending stop result")
        else:
            demand(status.get("running") is False and status.get("exitCode") == 0,
                   "final status did not report actual application exit")
    health = obj("health-before")
    for label in ("health-before", "health-pending"):
        result = obj(label)
        demand(set(result) == HEALTH and result["reachable"] is True and
               result["storageReachable"] is True and result["clockSane"] is True and
               result["deploymentKeyPresent"] is True and
               result["deploymentKeyComplete"] is True and result["defectCount"] == 0 and
               result["centerId"] == health["centerId"] and
               result["startedAt"] == health["startedAt"],
               label + ": center health degraded before late request release")

    row("qa-proxy", None)
    proxy_argv = rows["qa-proxy"]["argv"]
    demand(proxy_argv == ["docker", "exec", control, "node", QA_DIR + "/late_proxy.mjs",
                          "/opt/omne-private-docker/docker.sock", RUN_DIR + "/docker.sock",
                          QA_ADMIN, QA_LOG, cid], "proxy did not target fixed private Engine/CID")
    pid = e["helper_pid"]
    child = e["kill_child_pid"]
    demand(type(pid) is int and pid > 1 and type(child) is int and child > 1 and child != pid,
           "unsafe or ambiguous inner helper/child PIDs")
    pidfile = RUN_DIR + "/helper.pid"
    shell = 'printf "%s\\n" "$$" > "$1"; shift; exec "$@"'
    wrapper = ["docker", "exec", "-e", "DOCKER_HOST=" + QA_SOCKET,
               control, "sh", "-c", shell, "sh", pidfile, HELPER,
               "stop", "--project", project]
    demand(rows["stop-helper"]["argv"] == wrapper and
           rows["helper-pidfile-absent"]["argv"] ==
           ["docker", "exec", control, "test", "!", "-e", pidfile],
           "not one original helper stop via reviewed proxy/wrapper")
    label = e["helper_pid_label"]
    demand(re.fullmatch(r"helper-pid-[0-9]+", label) and
           order.index("stop-helper") < order.index(label) < order.index("helper-probe") and
           rows[label]["argv"] == ["docker", "exec", control, "cat", pidfile] and
           int(out(label).strip()) == pid, "helper PID not captured from exact wrapper")
    probe = obj("helper-probe")
    probe_cmd = rows["helper-probe"]["argv"]
    demand(probe_cmd[:6] == ["docker", "exec", control, "node", "--input-type=module", "-e"]
           and len(probe_cmd) == 8 and probe_cmd[-1] == str(pid) and
           hashlib.sha256(probe_cmd[-2].encode()).hexdigest() == e["inputs"]["sha256"]["helper_probe"],
           "helper identity was not reviewed raw /proc probe")
    args = proc_argv(probe["helperCmdlineBase64"], "helper")
    demand(probe["pid"] == pid and probe["helperArgv"] == args and
           pathlib.PurePosixPath(args[0]).name == "bash" and
           args[1:] == [HELPER, "stop", "--project", project],
           "signalled PID was not original exec'd helper")
    children_text = base64.b64decode(probe["childrenRawBase64"], validate=True).decode("ascii").strip()
    demand(children_text == str(child) and len(probe["children"]) == 1 and
           probe["children"][0]["pid"] == child, "Docker kill was not unique direct child")
    child_args = proc_argv(probe["children"][0]["cmdlineBase64"], "kill child")
    demand(probe["children"][0]["argv"] == child_args and len(child_args) == 4 and
           pathlib.PurePosixPath(child_args[0]).name == "docker" and
           child_args[1:] == ["kill", "--signal=SIGTERM", cid],
           "direct child was not exact original Engine TERM request")
    signal = obj("signal-helper")
    signal_cmd = rows["signal-helper"]["argv"]
    demand(signal_cmd[:6] == probe_cmd[:6] and len(signal_cmd) == 10 and
           signal_cmd[-3:] == [str(pid), str(child), cid] and
           hashlib.sha256(signal_cmd[-4].encode()).hexdigest() == e["inputs"]["sha256"]["kill_helper"]
           and signal == {"pid": pid, "child": child, "cid": cid,
                          "signal": "SIGKILL", "accepted": True},
           "single exact known inner-helper SIGKILL missing")
    for name, actual_pid in (("helper", pid), ("kill_child", child), ("helper_final", pid)):
        label = e[name + "_absence_label"]
        command = rows[label]["argv"]
        demand(re.fullmatch(name + r"-absence-[0-9]+", label) and
               command[:6] == probe_cmd[:6] and len(command) == 8 and
               command[-1] == str(actual_pid) and
               hashlib.sha256(command[-2].encode()).hexdigest() == e["inputs"]["sha256"]["pid_absence"]
               and obj(label) == {"pid": actual_pid, "absent": True, "reason": "ENOENT"},
               name + ": process not proven absent")
    demand(order.index("signal-helper") < order.index(e["helper_absence_label"]) <
           order.index("close-caller") < order.index(e["kill_child_absence_label"]) <
           order.index("lock-held-after-close") < order.index("release-original") <
           order.index(e["helper_final_absence_label"]),
           "helper/child absence or lock release not in causal sequence")
    caller = row("stop-helper", rows["stop-helper"]["returncode"])
    demand(type(caller["returncode"]) is int and caller["returncode"] != 0 and
           out("stop-helper") == b"" and
           caller["finished_monotonic_ns"] < e["release_monotonic_ns"] and
           e["held_monotonic_ns"] < e["signal_monotonic_ns"] <
           e["close_monotonic_ns"] < e["lock_released_monotonic_ns"] <
           e["release_monotonic_ns"],
           "dead original caller was falsely reported clean or ordering is wrong")

    lockpath = f"/run/omne-center/{project}.lock"
    lock_script = e["inputs"]["sha256"]["lock_holders"]
    locks = [obj(label) for label in ("lock-held-before-kill", "lock-held-after-close",
                                      "lock-after-flock")]
    for label, value in zip(("lock-held-before-kill", "lock-held-after-close", "lock-after-flock"), locks):
        command = rows[label]["argv"]
        demand(command[:6] == probe_cmd[:6] and len(command) == 8 and
               command[-1] == lockpath and
               hashlib.sha256(command[-2].encode()).hexdigest() == lock_script and
               value["path"] == lockpath and value["uid"] == value["gid"] == 0 and
               value["mode"] == "600" and value["dev"] == locks[0]["dev"] and
               value["ino"] == locks[0]["ino"],
               label + ": original root-owned 0600 lock inode changed")
    demand(any(holder["pid"] == pid for holder in locks[0]["holders"]) and
           locks[1]["holders"] == locks[2]["holders"] == [] and
           rows["lock-flock-available"]["argv"] ==
           ["docker", "exec", control, "flock", "-n", lockpath, "-c", "true"] and
           row("lock-flock-available"),
           "original lock remained owned or independent nonblocking flock failed")

    admin_prefix = ["docker", "exec", control, "node", QA_DIR + "/proxy_admin.mjs", QA_ADMIN]
    for key, expected in (("proxy-ready_label", None), ("proxy-held_label", e["held"])):
        label = e[key]
        demand(re.fullmatch(key.removesuffix("_label") + r"-[0-9]+", label) and
               rows[label]["argv"] == [*admin_prefix, "status"] and
               order.index("qa-proxy") < order.index(label) < order.index("signal-helper"),
               "independent proxy ready/held observation missing")
        value = obj(label)
        if expected is not None:
            demand(value == expected, "held request field was not the raw proxy status")
        else:
            demand(value["targetId"] == cid and value["pendingCount"] == 0 and
                   value["forwardCount"] == value["closeCount"] == value["rejectCount"] == 0,
                   "proxy was not fresh at ready")
    for label, action in (("proxy-before-close", "status"), ("close-caller", "close-caller"),
                          ("proxy-pending", "status"), ("release-original", "release")):
        demand(rows[label]["argv"] == [*admin_prefix, action],
               label + ": QA admin operation changed")
    held = e["held"]
    receipt = {key: held[key] for key in ("method", "path", "query", "bodySha256")}
    demand(held["targetId"] == cid and held["pendingCount"] == 1 and
           held["forwardCount"] == held["closeCount"] == held["rejectCount"] == 0 and
           type(held.get("readCount")) is int and held["readCount"] >= 1 and
           held["callerClosed"] is False and receipt["method"] == "POST" and
           KILL_PATH.fullmatch(receipt["path"]) is not None and
           KILL_PATH.fullmatch(receipt["path"]).group(1) == cid and
           receipt["query"] == "?signal=SIGTERM" and receipt["bodySha256"] == EMPTY_SHA,
           "independently held request was not original exact-CID SIGTERM")
    for label, pending, forward, closed in (("proxy-before-close", 1, 0, 0),
                                            ("close-caller", 1, 0, 1),
                                            ("proxy-pending", 1, 0, 1),
                                            ("release-original", 0, 1, 1)):
        value = obj(label)
        demand(value["targetId"] == cid and value["pendingCount"] == pending and
               value["forwardCount"] == forward and value["closeCount"] == closed and
               value["rejectCount"] == 0 and
               all(value[key] == receipt[key] for key in receipt),
               label + ": proxy request/state changed")
        if label == "close-caller":
            demand(value["wasOpen"] is True and value["callerClosed"] is True,
                   "QA did not explicitly destroy live caller socket")
    upstream = obj("release-original")["upstreamResult"]
    demand(upstream == {"status": 204, "bodySha256": EMPTY_SHA,
                        "bodyLength": 0, "bodyBase64": ""},
           "single forwarded request lacks real accepted Engine response")
    row("events-before-release")
    demand(rows["events-before-release"]["argv"][:len(inner) + 1] == [*inner, "events"] and
           rows["events-before-release"]["argv"][rows["events-before-release"]["argv"].index("--since") + 1]
           == e["event_start_utc"] and out("events-before-release") == b"",
           "Engine already had a kill event before late original request")
    row("events-after-release")
    events = [json.loads(line) for line in out("events-after-release").splitlines()]
    demand(len(events) == 1 and events[0].get("Action") == "kill" and
           events[0].get("Actor", {}).get("ID") == cid and
           events[0].get("Actor", {}).get("Attributes", {}).get("signal") in ("15", "SIGTERM") and
           all(f"container={cid}" in rows[label]["argv"] and
               "event=kill" in rows[label]["argv"] for label in
               ("events-before-release", "events-after-release")),
           "one actual private Engine exact-CID SIGTERM event not proved")
    demand(rows["center-wait"]["argv"] == [*inner, "wait", cid] and
           row("center-wait") and out("center-wait") == b"0\n", "real application exit code not observed")

    demand(rows["capture-proxy-log"]["argv"] ==
           ["docker", "cp", f"{control}:{QA_LOG}",
            str(pathlib.Path(e["run_path"]) / "raw/proxy-events.jsonl")],
           "proxy log copy source changed")
    demand(e["proxy_log_sha256"] == hashlib.sha256(proxy_log).hexdigest(),
           "raw proxy log changed after capture")
    log = [json.loads(line) for line in proxy_log.splitlines()]
    times = [int(item["monotonicNs"]) for item in log]
    demand(len(times) == len(set(times)) and times == sorted(times),
           "proxy monotonic log order invalid")
    by_event = {name: [item for item in log if item.get("event") == name]
                for name in ("proxy-ready", "held-original-request", "caller-socket-destroyed",
                             "release-original-request", "kill-upstream-result", "rejected",
                             "body-rejected", "duplicate-kill-rejected", "kill-upstream-error",
                             "read-forwarded", "read-upstream-error")}
    demand(all(len(by_event[name]) == 1 for name in
               ("proxy-ready", "held-original-request", "caller-socket-destroyed",
                "release-original-request", "kill-upstream-result")) and
           all(not by_event[name] for name in
               ("rejected", "body-rejected", "duplicate-kill-rejected", "kill-upstream-error",
                "read-upstream-error")) and
           len(by_event["read-forwarded"]) == held["readCount"] and
           all(type(item.get("status")) is int and 200 <= item["status"] < 300 and
               type(item.get("responseLength")) is int and item["responseLength"] >= 0 and
               re.fullmatch(r"[0-9a-f]{64}", item.get("responseSha256", ""))
               for item in by_event["read-forwarded"]),
           "proxy request duplicated, rejected, or result not recorded")
    sequence = [by_event[name][0]["monotonicNs"] for name in
                ("proxy-ready", "held-original-request", "caller-socket-destroyed",
                 "release-original-request", "kill-upstream-result")]
    demand([int(value) for value in sequence] == sorted(int(value) for value in sequence),
           "proxy did not preserve held→disconnect→late forward causality")
    for name in ("held-original-request", "release-original-request"):
        event = by_event[name][0]
        demand(event["targetId"] == cid and
               all(event[key] == receipt[key] for key in receipt),
               name + ": byte identity of original request changed")
    demand(by_event["held-original-request"][0]["bodyLength"] == 0 and
           by_event["caller-socket-destroyed"][0]["wasOpen"] is True and
           by_event["kill-upstream-result"][0]["status"] == 204 and
           by_event["kill-upstream-result"][0]["bodySha256"] == EMPTY_SHA and
           by_event["kill-upstream-result"][0]["bodyLength"] == 0,
           "proxy did not record one real late Engine response")
    return {"result": "limited-pass", "scenario": "late-original-stop", "center_id": cid,
            "helper_pid": pid, "kill_child_pid": child,
            "original_helper_returncode": caller["returncode"],
            "proxy_request_sha256": receipt["bodySha256"]}


def main(run):
    e = json.loads((run / "evidence.json").read_text())
    raw = {}
    for item in e["commands"]:
        for stream in ("stdout", "stderr"):
            raw[(item["label"], stream)] = (run / item[stream]).read_bytes()
    proxy_log = (run / "raw/proxy-events.jsonl").read_bytes()
    result = evaluate_observation(e, raw, proxy_log)
    demand(e.get("cleanup_complete") is True and not e.get("independent_host_errors"),
           "private resource cleanup/independent host audit incomplete")
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    try:
        main(pathlib.Path(sys.argv[1]))
    except Exception as error:
        print(f"unverified: {type(error).__name__}: {error}", file=sys.stderr)
        raise SystemExit(1)
