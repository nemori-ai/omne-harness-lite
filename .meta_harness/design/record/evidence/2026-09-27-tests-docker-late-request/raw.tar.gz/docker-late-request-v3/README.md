# Late original stop request: image identity oracle repair

This ignored v3 candidate reads the accepted Docker R4/R5 stop boundary in
`.meta_harness/design/realization/apps/tenancy-host/docker.md` (D-070/D-071)
and EC3 v3 S-59. The HUB “Late-request construction refinement” brief defines
the one-request causal scenario. The execution worktree remains at
`a91b889750d2cd819bf066b0e950bb9225fffdd4`.

The v2 **product run** `20260927T013409Z-1d405f02` made 107 commands,
recorded `business_complete=true` and `cleanup_complete=true`, but its frozen
oracle returned 1 at `original center start not healthy`. Its raw start,
inspect and status show the private Engine image ID
`sha256:217d7b6a27aa35f1ffa02036f31544c776575f0d5ae0da45255a5ea0ed625fba`.
The reviewed outer I3 image ID remains
`sha256:27c0665146265afefe39012aaea26bdae7499784eaaeb74aea712a6fcdfc03f2`.
The imported image has the same full RootFS, Linux/arm64 platform and adopted
BUILD_ID/distribution labels. The old oracle incorrectly required the outer ID
for the inner helper's start, container inspect and status results.

Only the copied `oracle.py` changes measurement semantics: it verifies the
outer and inner image inspections against their respective IDs, full RootFS,
OS, Architecture and adopted labels, then checks the three runtime outputs
against `expected.inner_image_id`. The original 2,851-file/115-link app
inventory assertion and every causal/exit/cleanup requirement remain. The
copied `self_test.py` now supplies distinct synthetic image IDs and adds three
rejected mutations (wrong start ID, private RootFS, outer ID). All other copied
tools are byte-identical to v2.

`recheck_existing.py` is a read-only **additional assessment of the existing
v2 observation**, not another product run. It verifies 18 frozen input hashes
against the old evidence, reads all 214 command streams, hashes all 275 run
files before and after evaluation, and keeps the old `oracle_exit=1` and
stderr intact. Its [result](recheck-result.json) is `limited-pass` under the
new oracle for that exact old run snapshot. The old run tree SHA256 at recheck
was `d4a41031096105cb0f3a1fe505cd5e9bdde3998d5739478d1db710f7c5c1784c`;
the result also records both oracle source hashes and the old evidence hash.
Root owns final sealing and the judgment of whether this raw observation is
sufficient. No new Docker, proxy, build or product API run was made for v3.

Static commands used `TMPDIR=/private/tmp`:

| Command from worktree root | Result |
| --- | --- |
| `python3 -B tmp/docker-late-request-v3/self_test.py` | One synthetic positive; 32 false-completion mutations rejected. |
| `fnm exec --using=24.21.0 -- node tmp/docker-late-request-v3/route_test.mjs` | 7 allowed, 11 rejected. |
| `fnm exec --using=24.21.0 -- python3 -B tmp/docker-late-request-v3/argv_test.py` | Valid file invocation reached absent socket; invalid arguments rejected. |
| `python3 -B tmp/docker-late-request-v3/recheck_existing.py` | Existing v2 raw observation passed the new oracle and cleanup check; `recheck-result.json`. |

The first wrapper attempt returned `duplicate or unsafe command label` because
its filename-safe label check omitted `@` in the two original systemd unit copy
labels. The v2 command list establishes those labels; the wrapper now permits
`@` while still requiring each stream's exact `raw/<label>.<stream>` path.
That was a wrapper error, not a product or oracle finding. The repository
formatter excludes `tmp/`, so it was not applied to these scratch files.

`print-inputs.json` binds this v3 path and oracle to canonical
`inputs_sha256=4b5c95a70aa9e2d00d949a404ecfd44e2550b213be80e6c494302bbd986523ed`.
`run-argv-inert.json` has no `--execute` and no v3 reviewed gate exists.
`manifest-static-v3.json` hashes the v3 files and check results. The original
v2 product verdict remains failed in its original evidence; this v3 result
does not overwrite it or claim an independent real execution.
