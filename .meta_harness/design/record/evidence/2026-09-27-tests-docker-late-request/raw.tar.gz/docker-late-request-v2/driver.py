#!/usr/bin/env python3
"""One private-Engine late original stop request; actual use needs a root review gate."""

import argparse
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import sys
import time

import base_driver as base

HERE = pathlib.Path(__file__).resolve().parent
I3_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
BUILD_ID = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
IMAGE_ID = "sha256:27c0665146265afefe39012aaea26bdae7499784eaaeb74aea712a6fcdfc03f2"
IMAGE_TAR_SHA = "503fc0c6006d5d654e1e288bbff1af806ec041163d56223bac7e322391653de2"
HELPER_SHA = "71ba9f3c31b34c171dd2a4048d9e249af31f7948abcf66ee603da5ffb7d1b365"
DOCKER_SPEC_SHA = "3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223"
QA_DIR = "/opt/omne-r5-qa"
RUN_DIR = "/run/omne-center-qa"
QA_DOCKER = RUN_DIR + "/docker.sock"
QA_ADMIN = RUN_DIR + "/control.sock"
QA_LOG = base.STATE + "/qa/late-proxy.jsonl"
EMPTY_SHA = hashlib.sha256(b"").hexdigest()
KILL_PATH = re.compile(r"/(?:v[0-9]+\.[0-9]+/)?containers/([0-9a-f]{64})/kill\Z")
SCRIPTS = ("driver.py", "base_driver.py", "oracle.py", "inventory.mjs",
           "helper_probe.mjs", "pid_absence.mjs", "kill_helper.mjs",
           "lock_holders.mjs", "proxy_rules.mjs", "late_proxy.mjs", "proxy_admin.mjs")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def checked_inputs(args):
    base.V0 = args.v0_dir
    paths = {name.removesuffix(".py").removesuffix(".mjs"): HERE / name for name in SCRIPTS}
    paths.update({
        "i3_manifest": args.i3_manifest, "image_tar": args.image_tar,
        "host_build_info": args.helper_dir.parents[1] / "build-info.json",
        "host_build_id": args.helper_dir.parents[1] / "BUILD_ID",
        "helper": args.helper_dir / "omne-center",
        "compose": args.helper_dir / "compose.yaml",
        "maintenance_compose": args.helper_dir / "compose.maintenance.yaml",
        "health": args.helper_dir / "health.mjs",
        "service": args.helper_dir / "omne-center-backup@.service",
        "timer": args.helper_dir / "omne-center-backup@.timer",
        "compose_binary": args.v0_dir / "docker-compose-linux-aarch64",
        "docker_cli": args.v0_dir / "extracted-bin/docker",
        "docker_spec": args.design_root / "realization/apps/tenancy-host/docker.md",
        "d071_decision": args.design_root / "record/decisions/governance-docker-stop-adoption/decision.md",
        "d071_snapshot": args.design_root / "record/decisions/governance-docker-stop-adoption/provider-snapshot.json",
        "ec3_contract": args.design_root / "spec/compositions/governance-center-entry/v3/contract.md",
        "helper_source": HERE.parents[1] / "apps/tenancy-host/deploy/docker/omne-center",
    })
    actual = {name: base.sha(path) for name, path in paths.items()}
    manifest = json.loads(args.i3_manifest.read_text())
    arm = manifest["images"]["arm64"]
    host = manifest["archives"]["host"]
    require(actual["i3_manifest"] == I3_SHA and actual["docker_spec"] == DOCKER_SPEC_SHA,
            "adopted I3/spec inputs changed")
    require(manifest["source"]["commit"] == "f8f286c95cb9458fe3173190edbeab6076339b08"
            and arm["imageId"] == IMAGE_ID and arm["archiveSha256"] == IMAGE_TAR_SHA
            and arm["buildId"] == host["buildId"] == BUILD_ID, "I3 identity changed")
    require(actual["image_tar"] == IMAGE_TAR_SHA and
            actual["host_build_info"] == host["fullFileManifestSha256"] and
            paths["host_build_id"].read_text().strip() == BUILD_ID and
            json.loads(paths["host_build_info"].read_text())["buildId"] == BUILD_ID,
            "I3 packaged app manifest changed")
    require(actual["helper"] == actual["helper_source"] == HELPER_SHA and
            all(actual[key] == manifest["deployFiles"][filename]["packagedSha256"]
                for key, filename in (("compose", "compose.yaml"),
                                      ("maintenance_compose", "compose.maintenance.yaml"),
                                      ("health", "health.mjs"),
                                      ("service", "omne-center-backup@.service"),
                                      ("timer", "omne-center-backup@.timer"))),
            "original packaged deployment bytes changed")
    require(actual["compose_binary"] == base.COMPOSE_SHA and
            actual["docker_cli"] == base.CLI_SHA, "fixed private Engine tools changed")
    require(args.uid == args.gid == 10001 and args.observe_seconds >= 90 and
            0 < args.probe_seconds <= 60 and args.scenario == "late-original-stop",
            "unreviewed scenario or observation budget")
    return {"paths": {key: str(path.resolve()) for key, path in paths.items()},
            "sha256": actual, "image_id": IMAGE_ID, "build_id": BUILD_ID,
            "host_manifest_sha256": host["fullFileManifestSha256"],
            "uid": args.uid, "gid": args.gid, "scenario": args.scenario,
            "observe_seconds": args.observe_seconds, "probe_seconds": args.probe_seconds}


def reviewed_inputs(args, inputs):
    require(args.reviewed_gate is not None, "root-reviewed gate required")
    gate = json.loads(args.reviewed_gate.read_text())
    require(gate.get("approved") is True and gate.get("reviewer") == "root" and
            gate.get("inputs_sha256") == canonical_hash(inputs) and
            gate.get("driver_sha256") == inputs["sha256"]["driver"] and
            gate.get("oracle_sha256") == inputs["sha256"]["oracle"],
            "missing or stale root-reviewed gate")


class LateRun(base.Run):
    def __init__(self, args, inputs):
        super().__init__(args, inputs)
        for name in SCRIPTS:
            if name == "oracle.py":
                continue
            target = self.frozen / name
            shutil.copyfile(HERE / name, target)
            require(base.sha(target) == inputs["sha256"][name.removesuffix(".py").removesuffix(".mjs")],
                    "reviewed script changed during freeze")
        shutil.copyfile(args.i3_manifest, self.frozen / "i3-manifest.json")
        self.evidence.update({"scenario": args.scenario,
                              "run_path": str(self.run),
                              "artifact_manifest_sha256": inputs["sha256"]["i3_manifest"]})
        self.save()
        self.async_clients = {}

    def asynchronous(self, label, argv):
        require(label not in self.async_clients, "duplicate async label")
        out = pathlib.Path("raw") / f"{label}.stdout"
        err = pathlib.Path("raw") / f"{label}.stderr"
        item = {"label": label, "argv": argv, "stdout": str(out), "stderr": str(err),
                "started_utc": base.utc(), "started_monotonic_ns": time.monotonic_ns(),
                "returncode": None, "observation_expired": False}
        self.evidence["commands"].append(item)
        self.save()
        with (self.run / out).open("xb") as stdout, (self.run / err).open("xb") as stderr:
            process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=stdout,
                                       stderr=stderr, close_fds=True)
        self.async_clients[label] = (item, process)
        self.pending_clients.append((label, process))

    def finish_async(self, label, timeout):
        item, process = self.async_clients[label]
        try:
            item["returncode"] = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            item["observation_expired"] = True
        item["finished_utc"] = base.utc()
        item["finished_monotonic_ns"] = time.monotonic_ns()
        self.save()
        require(not item["observation_expired"], label + ": finite observation expired")

    def admin(self, label, action, *, expected=0):
        value = self.control_exec(label, "node", QA_DIR + "/proxy_admin.mjs", QA_ADMIN,
                                  action, expected=expected, timeout=15)
        if self.evidence["commands"][-1]["returncode"] != 0:
            return None
        return base.parse_json_line(value, label)

    def await_admin(self, prefix, predicate):
        deadline = time.monotonic() + self.args.probe_seconds
        for attempt in range(1, 201):
            label = f"{prefix}-{attempt}"
            result = self.admin(label, "status", expected=None)
            if result is not None and predicate(result):
                self.evidence[prefix + "_label"] = label
                self.save()
                return result
            if time.monotonic() >= deadline:
                break
            time.sleep(0.1)
        raise RuntimeError(prefix + ": proxy condition not seen")

    def await_pid(self, path):
        deadline = time.monotonic() + self.args.probe_seconds
        for attempt in range(1, 201):
            label = f"helper-pid-{attempt}"
            value = self.control_exec(label, "cat", path, expected=None, timeout=8)
            if self.evidence["commands"][-1]["returncode"] == 0:
                text = value.decode("ascii", "strict").strip()
                require(re.fullmatch(r"[1-9][0-9]*", text) and int(text) > 1,
                        "helper pidfile invalid")
                self.evidence["helper_pid_label"] = label
                self.evidence["helper_pid"] = int(text)
                self.save()
                return int(text)
            if time.monotonic() >= deadline:
                break
            time.sleep(0.1)
        raise RuntimeError("inner helper PID not observed")

    def await_absent(self, name, pid):
        script = (self.frozen / "pid_absence.mjs").read_text()
        deadline = time.monotonic() + self.args.probe_seconds
        for attempt in range(1, 201):
            label = f"{name}-absence-{attempt}"
            observed = base.parse_json_line(self.control_exec(label, "node", "--input-type=module",
                "-e", script, str(pid)), label)
            if observed == {"pid": pid, "absent": True, "reason": "ENOENT"}:
                self.evidence[name + "_absence_label"] = label
                self.save()
                return
            require(observed == {"pid": pid, "absent": False}, name + ": malformed PID result")
            if time.monotonic() >= deadline:
                break
            time.sleep(0.1)
        raise RuntimeError(name + ": exact PID remains")

    def lock_probe(self, label):
        script = (self.frozen / "lock_holders.mjs").read_text()
        return base.parse_json_line(self.control_exec(label, "node", "--input-type=module",
            "-e", script, f"/run/omne-center/{self.project}.lock"), label)

    def inventory(self):
        self.outer("original-inventory", "exec", "-i", self.control, "docker", "--host",
                   base.SOCKET, "run", "--rm", "-i", "--pull", "never", "--network", "none",
                   "--label", self.label, "--entrypoint", "node", "-e", "NODE_OPTIONS=",
                   "-e", f"EXPECTED_BUILD_ID={BUILD_ID}",
                   "-e", f"EXPECTED_MANIFEST_SHA256={self.evidence['inputs']['host_manifest_sha256']}",
                   self.image_id, "--input-type=module", "-",
                   stdin=self.frozen / "inventory.mjs", timeout=180)
        result = json.loads((self.run / "raw/original-inventory.stdout").read_text())
        require(result == {"status": "verified", "buildId": BUILD_ID, "files": 2851,
                           "links": 115, "manifestSha256": self.evidence["inputs"]["host_manifest_sha256"],
                           "node": "v24.21.0"}, "original app inventory changed")

    def prepare_proxy(self, cid):
        self.control_exec("qa-run-dir", "install", "-d", "-m", "0700", RUN_DIR)
        self.control_exec("qa-code-dir", "install", "-d", "-m", "0700", QA_DIR)
        self.control_exec("qa-log-dir", "install", "-d", "-m", "0700", base.STATE + "/qa")
        for name in ("proxy_rules.mjs", "late_proxy.mjs", "proxy_admin.mjs"):
            self.copy("copy-" + name, self.frozen / name, QA_DIR + "/" + name)
        self.control_exec("qa-code-mode", "chmod", "0444", *[QA_DIR + "/" + name
                          for name in ("proxy_rules.mjs", "late_proxy.mjs", "proxy_admin.mjs")])
        self.asynchronous("qa-proxy", ["docker", "exec", self.control, "node",
                          QA_DIR + "/late_proxy.mjs", "/opt/omne-private-docker/docker.sock",
                          QA_DOCKER, QA_ADMIN, QA_LOG, cid])
        ready = self.await_admin("proxy-ready", lambda state: state.get("targetId") == cid
                                 and state.get("pendingCount") == 0
                                 and state.get("forwardCount") == 0)
        require(ready["readCount"] == ready["rejectCount"] == 0,
                "proxy not fresh at ready")

    def scenario(self):
        common = ["--project", self.project]
        deployment = [*common, "--image", self.image_id, "--state-dir", base.STATE,
                      "--secrets-dir", base.SECRETS, "--settings-file", base.SETTINGS,
                      "--publish-address", "127.0.0.1", "--publish-port", "18443",
                      "--uid", str(self.args.uid), "--gid", str(self.args.gid)]
        self.helper("validate", "validate", *deployment)
        started = base.parse_json_line(self.helper("start", "start", *deployment,
            timeout=self.args.observe_seconds), "start")
        cid = started.get("containerId")
        require(isinstance(cid, str) and base.HEX64.fullmatch(cid), "known center ID absent")
        self.evidence["center_id"] = cid
        self.save()
        self.inner("center-before", "inspect", cid)
        self.helper("health-before", "full-health", *common)
        self.helper("status-before", "status", *common)
        self.prepare_proxy(cid)
        pidfile = RUN_DIR + "/helper.pid"
        self.control_exec("helper-pidfile-absent", "test", "!", "-e", pidfile)
        event_start = base.utc()
        self.evidence["event_start_utc"] = event_start
        self.save()
        shell = 'printf "%s\\n" "$$" > "$1"; shift; exec "$@"'
        wrapper = ["docker", "exec", "-e", "DOCKER_HOST=unix://" + QA_DOCKER,
                   self.control, "sh", "-c", shell, "sh", pidfile, base.HELPER,
                   "stop", *common]
        self.asynchronous("stop-helper", wrapper)
        held = self.await_admin("proxy-held", lambda state: state.get("pendingCount") == 1)
        require(held["targetId"] == cid and held["forwardCount"] == 0 and
                held["closeCount"] == 0 and held["callerClosed"] is False and
                held["bodySha256"] == EMPTY_SHA and
                held["query"] == "?signal=SIGTERM" and
                KILL_PATH.fullmatch(held["path"]).group(1) == cid,
                "original exact-CID TERM request was not independently held")
        self.evidence["held"] = held
        self.evidence["held_monotonic_ns"] = time.monotonic_ns()
        self.save()
        pid = self.await_pid(pidfile)
        script = (self.frozen / "helper_probe.mjs").read_text()
        probe = base.parse_json_line(self.control_exec("helper-probe", "node",
            "--input-type=module", "-e", script, str(pid)), "helper-probe")
        children = probe.get("children")
        require(probe.get("pid") == pid and isinstance(children, list) and len(children) == 1
                and children[0].get("argv", [None])[1:] ==
                ["kill", "--signal=SIGTERM", cid], "not exact helper/direct kill child")
        child = children[0]["pid"]
        self.evidence["kill_child_pid"] = child
        self.save()
        before = self.lock_probe("lock-held-before-kill")
        require(any(item["pid"] == pid for item in before["holders"]),
                "original helper did not hold project lock FD")
        self.inner("center-held-before-kill", "inspect", cid)
        signal = (self.frozen / "kill_helper.mjs").read_text()
        self.control_exec("signal-helper", "node", "--input-type=module", "-e", signal,
                          str(pid), str(child), cid)
        self.evidence["signal_monotonic_ns"] = time.monotonic_ns()
        self.save()
        self.await_absent("helper", pid)
        preclose = self.admin("proxy-before-close", "status")
        require(preclose["pendingCount"] == 1 and preclose["forwardCount"] == 0 and
                preclose["closeCount"] == 0 and preclose["callerClosed"] is False,
                "caller closed before explicit QA disconnection")
        closed = self.admin("close-caller", "close-caller")
        require(closed["wasOpen"] is True and closed["closeCount"] == 1 and
                closed["pendingCount"] == 1 and closed["forwardCount"] == 0,
                "original response socket was not explicitly destroyed")
        self.evidence["close_monotonic_ns"] = time.monotonic_ns()
        self.save()
        self.await_absent("kill_child", child)
        self.finish_async("stop-helper", self.args.probe_seconds)
        require((self.run / "raw/stop-helper.stdout").read_bytes() == b"",
                "dead original caller claimed stop completion")
        after = self.lock_probe("lock-held-after-close")
        require(after["path"] == before["path"] and after["dev"] == before["dev"] and
                after["ino"] == before["ino"] and after["holders"] == [],
                "original project lock FD remains held")
        lockpath = f"/run/omne-center/{self.project}.lock"
        self.control_exec("lock-flock-available", "flock", "-n", lockpath, "-c", "true")
        final_lock = self.lock_probe("lock-after-flock")
        require(final_lock["dev"] == before["dev"] and final_lock["ino"] == before["ino"]
                and final_lock["holders"] == [], "lock probe replaced the original inode")
        self.evidence["lock_released_monotonic_ns"] = time.monotonic_ns()
        self.save()
        self.helper("status-pending", "status", *common)
        self.inner("center-pending", "inspect", cid)
        self.helper("health-pending", "full-health", *common)
        pending = self.admin("proxy-pending", "status")
        require(pending["pendingCount"] == 1 and pending["forwardCount"] == 0
                and pending["closeCount"] == 1 and pending["callerClosed"] is True,
                "late request already forwarded before explicit release")
        self.inner("events-before-release", "events", "--since", event_start,
                   "--until", base.utc(), "--filter", f"container={cid}",
                   "--filter", "event=kill", "--format", "{{json .}}", timeout=20)
        require((self.run / "raw/events-before-release.stdout").read_bytes() == b"",
                "Engine already accepted a kill before QA release")
        released = self.admin("release-original", "release")
        self.evidence["release_monotonic_ns"] = time.monotonic_ns()
        self.save()
        require(released["pendingCount"] == 0 and released["forwardCount"] == 1 and
                released["closeCount"] == 1 and
                released["upstreamResult"]["status"] == 204 and
                released["upstreamResult"]["bodyLength"] == 0 and
                released["upstreamResult"]["bodySha256"] == EMPTY_SHA,
                "real private Engine did not accept the single forwarded original TERM")
        wait = self.inner("center-wait", "wait", cid, timeout=self.args.observe_seconds)
        require(wait == b"0\n", "same center did not exit application code zero")
        self.inner("center-final", "inspect", cid)
        self.helper("status-final", "status", *common)
        self.inner("events-after-release", "events", "--since", event_start,
                   "--until", base.utc(), "--filter", f"container={cid}",
                   "--filter", "event=kill", "--format", "{{json .}}", timeout=20)
        self.await_absent("helper_final", pid)
        self.evidence["business_complete"] = True
        self.evidence["status"] = "observed-awaiting-oracle"
        self.save()

    def capture_proxy_log(self):
        if ("container", self.control) not in self.created:
            return
        target = self.run / "raw/proxy-events.jsonl"
        try:
            self.outer("capture-proxy-log", "cp", f"{self.control}:{QA_LOG}", str(target),
                       expected=None)
            require(self.evidence["commands"][-1]["returncode"] == 0 and target.is_file(),
                    "proxy log copy failed")
            self.evidence["proxy_log_sha256"] = base.sha(target)
        except BaseException as error:
            self.evidence["proxy_log_error"] = f"{type(error).__name__}: {error}"
        self.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=("late-original-stop",), required=True)
    for name in ("i3-manifest", "image-tar", "helper-dir", "v0-dir", "design-root"):
        parser.add_argument("--" + name, type=pathlib.Path, required=True)
    parser.add_argument("--uid", type=int, default=10001)
    parser.add_argument("--gid", type=int, default=10001)
    parser.add_argument("--observe-seconds", type=int, default=180)
    parser.add_argument("--probe-seconds", type=float, default=20.0)
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    inputs = checked_inputs(args)
    if args.print_inputs:
        print(json.dumps({"inputs": inputs, "inputs_sha256": canonical_hash(inputs)}, sort_keys=True))
        return 0
    require(args.execute, "Docker execution requires --execute")
    reviewed_inputs(args, inputs)
    args.image_id = IMAGE_ID
    args.build_id = BUILD_ID
    run = LateRun(args, inputs)
    try:
        run.setup()
        run.import_image()
        run.prepare_paths()
        run.inventory()
        run.scenario()
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
        run.save()
    finally:
        run.capture_proxy_log()
        run.cleanup()
        for kind, argv in (("container", ["ps", "-aq", "--filter", f"label={run.label}"]),
                           ("network", ["network", "ls", "-q", "--filter", f"label={run.label}"]),
                           ("volume", ["volume", "ls", "-q", "--filter", f"label={run.label}"])):
            try:
                output = run.outer("independent-host-" + kind, *argv)
                require(not output.strip(), "exact-label resource remains: " + kind)
            except BaseException as error:
                run.evidence.setdefault("independent_host_errors", []).append(str(error))
                run.save()
        for kind, names in (("container", (run.control, run.dind)),
                            ("network", (run.network,)), ("volume", run.volumes)):
            for name in names:
                try:
                    argv = ["docker", kind, "inspect", name]
                    run.call("independent-name-" + kind + "-" + name, argv, expected=None)
                    require(run.evidence["commands"][-1]["returncode"] != 0,
                            "named fixture resource remains: " + name)
                except BaseException as error:
                    run.evidence.setdefault("independent_host_errors", []).append(str(error))
                    run.save()
    with (run.run / "oracle.stdout").open("xb") as stdout, (run.run / "oracle.stderr").open("xb") as stderr:
        checked = subprocess.run([sys.executable, "-B", str(run.frozen / "oracle.py"), str(run.run)],
                                 stdout=stdout, stderr=stderr, check=False)
    run.evidence["oracle_exit"] = checked.returncode
    run.save()
    print(json.dumps({"run": str(run.run), "oracle_exit": checked.returncode,
                      "cleanup_complete": run.evidence["cleanup_complete"]}, sort_keys=True))
    return 0 if checked.returncode == 0 and run.evidence["cleanup_complete"] and not run.evidence.get(
        "independent_host_errors") else 1


if __name__ == "__main__":
    raise SystemExit(main())
