// Pure route tests. This imports no server and opens no socket.
import assert from 'node:assert/strict'
import { classifyRoute } from './proxy_rules.mjs'

const id = 'a'.repeat(64)
const other = 'b'.repeat(64)
const good = [
  ['HEAD', '/_ping', 'read'], ['GET', '/version', 'read'],
  ['GET', '/v1.52/info', 'read'],
  ['GET', '/v1.52/containers/json?all=1&filters=%7B%7D', 'read'],
  ['GET', `/v1.52/containers/${id}/json?size=false`, 'read'],
  ['GET', `/images/sha256%3A${id}/json?manifests=false`, 'read'],
  ['POST', `/v1.52/containers/${id}/kill?signal=SIGTERM`, 'kill'],
]
const bad = [
  ['POST', `/containers/${other}/kill?signal=SIGTERM`],
  ['POST', `/containers/${id}/kill?signal=SIGKILL`],
  ['POST', `/containers/${id}/kill?signal=SIGTERM&signal=SIGTERM`],
  ['POST', `/containers/${id}/stop`], ['POST', `/containers/create`],
  ['POST', `/containers/${id}/start`], ['DELETE', `/containers/${id}`],
  ['GET', `/containers/${id}/logs`], ['GET', `/containers/${id}/json?size=maybe`],
  ['GET', `/images/sha256%3A${id}/json?manifests=maybe`],
  ['GET', '/v1.52/containers/json?all=1&unknown=1'],
]
for (const [method, url, expected] of good) {
  assert.equal(classifyRoute(method, url, id).kind, expected, `${method} ${url}`)
}
for (const [method, url] of bad) {
  assert.equal(classifyRoute(method, url, id).kind, 'reject', `${method} ${url}`)
}
process.stdout.write(JSON.stringify({ positive: good.length, negative: bad.length,
  allRejected: true, scope: 'pure-route-no-server' }) + '\n')
