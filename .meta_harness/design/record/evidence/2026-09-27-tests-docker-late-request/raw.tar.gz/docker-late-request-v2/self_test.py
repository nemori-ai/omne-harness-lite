#!/usr/bin/env python3
"""Offline oracle controls: one synthetic pass and causal/identity false-pass mutants."""

import ast
import base64
import copy
import hashlib
import json
from pathlib import Path

import oracle

HERE = Path(__file__).parent


def j(value):
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def argv_raw(values):
    return ("\0".join(values) + "\0").encode()


def wrapper_source():
    tree = ast.parse((HERE / "driver.py").read_text())
    values = [node.value.value for node in ast.walk(tree)
              if isinstance(node, ast.Assign) and
              any(isinstance(target, ast.Name) and target.id == "shell" for target in node.targets)
              and isinstance(node.value, ast.Constant)]
    assert values == ['printf "%s\\n" "$$" > "$1"; shift; exec "$@"'], values
    return values[0]


def fixture():
    cid = "a" * 64
    project = "r5abcd1234"
    control = "omne-r5-synthetic-control"
    pid, child = 200, 201
    state = "/var/lib/omne-tenancy/state"
    names = ["original-inventory", "validate", "start", "center-before", "health-before",
             "status-before", "qa-proxy", "proxy-ready-1", "helper-pidfile-absent",
             "stop-helper", "proxy-held-1", "helper-pid-1", "helper-probe",
             "lock-held-before-kill", "center-held-before-kill", "signal-helper",
             "helper-absence-1", "proxy-before-close", "close-caller",
             "kill_child-absence-1", "lock-held-after-close", "lock-flock-available",
             "lock-after-flock", "status-pending", "center-pending", "health-pending",
             "proxy-pending", "events-before-release", "release-original", "center-wait",
             "center-final", "status-final", "events-after-release",
             "helper_final-absence-1", "capture-proxy-log"]
    rows = [{"label": name, "argv": [], "returncode": 0, "observation_expired": False}
            for name in names]
    by = {item["label"]: item for item in rows}
    raw = {(name, stream): b"" for name in names for stream in ("stdout", "stderr")}

    def put(name, value):
        raw[name, "stdout"] = value if isinstance(value, bytes) else j(value)

    hashes = {name.removesuffix(".mjs"): hashlib.sha256((HERE / name).read_bytes()).hexdigest()
              for name in ("helper_probe.mjs", "pid_absence.mjs", "kill_helper.mjs",
                           "lock_holders.mjs")}
    e = {"commands": rows, "scenario": "late-original-stop",
         "status": "observed-awaiting-oracle", "business_complete": True,
         "artifact_manifest_sha256": oracle.I3_SHA,
         "inputs": {"image_id": oracle.IMAGE_ID, "build_id": oracle.BUILD_ID,
                    "host_manifest_sha256": "f" * 64, "sha256": hashes},
         "center_id": cid, "helper_pid": pid, "kill_child_pid": child,
         "expected": {"control": control, "project": project, "state": state},
         "run_path": "/private/synthetic-run", "helper_pid_label": "helper-pid-1",
         "proxy-ready_label": "proxy-ready-1", "proxy-held_label": "proxy-held-1",
         "helper_absence_label": "helper-absence-1",
         "kill_child_absence_label": "kill_child-absence-1",
         "helper_final_absence_label": "helper_final-absence-1",
         "held_monotonic_ns": 100, "signal_monotonic_ns": 200,
         "close_monotonic_ns": 300, "lock_released_monotonic_ns": 400,
         "release_monotonic_ns": 600, "event_start_utc": "2026-09-26T23:00:00Z"}
    direct = ["docker", "exec", "-e", "DOCKER_HOST=" + oracle.SOCKET,
              control, oracle.HELPER]
    inner = ["docker", "exec", control, "docker", "--host", oracle.SOCKET]
    for name, action in (("validate", "validate"), ("start", "start"),
                         ("health-before", "full-health"),
                         ("health-pending", "full-health"),
                         ("status-before", "status"), ("status-pending", "status"),
                         ("status-final", "status")):
        by[name]["argv"] = [*direct, action, "--project", project]
    put("original-inventory", {"status": "verified", "buildId": oracle.BUILD_ID,
                               "files": 2851, "links": 115,
                               "manifestSha256": "f" * 64, "node": "v24.21.0"})
    put("start", {"containerId": cid, "state": "running", "health": "healthy",
                  "imageId": oracle.IMAGE_ID, "buildId": oracle.BUILD_ID})

    def inspected(running):
        return {"Id": cid, "Image": oracle.IMAGE_ID,
                "Config": {"User": "10001:10001", "StopSignal": "SIGTERM"},
                "HostConfig": {"RestartPolicy": {"Name": "unless-stopped"}},
                "Mounts": [{"Destination": "/state", "Source": state}],
                "RestartCount": 0,
                "State": {"Status": "running" if running else "exited",
                          "Running": running, "Pid": 234 if running else 0,
                          "StartedAt": "2026-09-26T23:00:00Z", "ExitCode": None if running else 0}}
    for name in ("center-before", "center-held-before-kill", "center-pending"):
        by[name]["argv"] = [*inner, "inspect", cid]
        put(name, [inspected(True)])
    by["center-final"]["argv"] = [*inner, "inspect", cid]
    put("center-final", [inspected(False)])
    health = {"reachable": True, "centerId": "b" * 32, "version": "v1",
              "startedAt": "2026-09-26T23:00:00Z", "storageReachable": True,
              "deploymentKeyPresent": True, "deploymentKeyComplete": True,
              "clockSane": True, "defectCount": 0, "deploymentParameters": {}}
    put("health-before", health)
    put("health-pending", health)
    for name, running in (("status-before", True), ("status-pending", True),
                          ("status-final", False)):
        put(name, {"containerId": cid, "imageId": oracle.IMAGE_ID,
                   "buildId": oracle.BUILD_ID, "state": "running" if running else "exited",
                   "restartCount": 0, "previousExit": "unknown", "running": running,
                   "pid": 234 if running else 0, "exitCode": None if running else 0})
    by["qa-proxy"].update({"argv": ["docker", "exec", control, "node",
                                       oracle.QA_DIR + "/late_proxy.mjs",
                                       "/opt/omne-private-docker/docker.sock",
                                       oracle.RUN_DIR + "/docker.sock", oracle.QA_ADMIN,
                                       oracle.QA_LOG, cid], "returncode": None})
    pidfile = oracle.RUN_DIR + "/helper.pid"
    by["helper-pidfile-absent"]["argv"] = ["docker", "exec", control,
                                             "test", "!", "-e", pidfile]
    by["stop-helper"].update({"argv": ["docker", "exec", "-e",
                                         "DOCKER_HOST=" + oracle.QA_SOCKET, control,
                                         "sh", "-c", wrapper_source(), "sh", pidfile,
                                         oracle.HELPER, "stop", "--project", project],
                              "returncode": 137, "finished_monotonic_ns": 500})
    by["helper-pid-1"]["argv"] = ["docker", "exec", control, "cat", pidfile]
    put("helper-pid-1", b"200\n")
    prefix = ["docker", "exec", control, "node", "--input-type=module", "-e"]
    helper_args = ["bash", oracle.HELPER, "stop", "--project", project]
    child_args = ["docker", "kill", "--signal=SIGTERM", cid]
    by["helper-probe"]["argv"] = [*prefix, (HERE / "helper_probe.mjs").read_text(), str(pid)]
    put("helper-probe", {"pid": pid,
                         "helperCmdlineBase64": base64.b64encode(argv_raw(helper_args)).decode(),
                         "helperArgv": helper_args,
                         "childrenRawBase64": base64.b64encode(b"201 ").decode(),
                         "children": [{"pid": child,
                                       "cmdlineBase64": base64.b64encode(argv_raw(child_args)).decode(),
                                       "argv": child_args}]})
    by["signal-helper"]["argv"] = [*prefix, (HERE / "kill_helper.mjs").read_text(),
                                     str(pid), str(child), cid]
    put("signal-helper", {"pid": pid, "child": child, "cid": cid,
                          "signal": "SIGKILL", "accepted": True})
    for name, actual in (("helper-absence-1", pid), ("kill_child-absence-1", child),
                         ("helper_final-absence-1", pid)):
        by[name]["argv"] = [*prefix, (HERE / "pid_absence.mjs").read_text(), str(actual)]
        put(name, {"pid": actual, "absent": True, "reason": "ENOENT"})
    lock = f"/run/omne-center/{project}.lock"
    lockbase = {"path": lock, "dev": "1", "ino": "2", "uid": 0, "gid": 0, "mode": "600"}
    for name, holders in (("lock-held-before-kill", [{"pid": pid, "fd": 10}]),
                          ("lock-held-after-close", []), ("lock-after-flock", [])):
        by[name]["argv"] = [*prefix, (HERE / "lock_holders.mjs").read_text(), lock]
        put(name, {**lockbase, "holders": holders})
    by["lock-flock-available"]["argv"] = ["docker", "exec", control,
                                            "flock", "-n", lock, "-c", "true"]
    path = "/v1.52/containers/" + cid + "/kill"
    receipt = {"method": "POST", "path": path, "query": "?signal=SIGTERM",
               "bodySha256": oracle.EMPTY_SHA}
    ready = {"targetId": cid, "pendingCount": 0, "forwardCount": 0,
             "closeCount": 0, "readCount": 0, "rejectCount": 0,
             "callerClosed": False, "method": None, "path": None, "query": None,
             "bodySha256": None, "upstreamResult": None}
    held = {**ready, **receipt, "pendingCount": 1, "readCount": 1}
    e["held"] = held
    admin = ["docker", "exec", control, "node", oracle.QA_DIR + "/proxy_admin.mjs",
             oracle.QA_ADMIN]
    for name, action, value in (("proxy-ready-1", "status", ready),
                                ("proxy-held-1", "status", held),
                                ("proxy-before-close", "status", held),
                                ("close-caller", "close-caller",
                                 {**held, "closeCount": 1, "callerClosed": True,
                                  "wasOpen": True}),
                                ("proxy-pending", "status",
                                 {**held, "closeCount": 1, "callerClosed": True}),
                                ("release-original", "release",
                                 {**held, "pendingCount": 0, "forwardCount": 1,
                                  "closeCount": 1, "callerClosed": True,
                                  "upstreamResult": {"status": 204, "bodySha256": oracle.EMPTY_SHA,
                                                     "bodyLength": 0, "bodyBase64": ""}})):
        by[name]["argv"] = [*admin, action]
        put(name, value)
    for name in ("events-before-release", "events-after-release"):
        by[name]["argv"] = [*inner, "events", "--since", e["event_start_utc"],
                             "--until", "2026-09-26T23:01:00Z", "--filter", f"container={cid}",
                             "--filter", "event=kill", "--format", "{{json .}}"]
    put("events-after-release", j({"Action": "kill", "Actor": {"ID": cid,
                                                                  "Attributes": {"signal": "15"}}}))
    by["center-wait"]["argv"] = [*inner, "wait", cid]
    put("center-wait", b"0\n")
    by["capture-proxy-log"]["argv"] = ["docker", "cp", f"{control}:{oracle.QA_LOG}",
                                        e["run_path"] + "/raw/proxy-events.jsonl"]
    log = [{"event": "proxy-ready", "targetId": cid, "monotonicNs": "1"},
           {"event": "read-forwarded", "method": "GET", "path": "/_ping", "query": "",
            "responseSha256": oracle.EMPTY_SHA, "responseLength": 0,
            "status": 200, "monotonicNs": "2"},
           {"event": "held-original-request", **receipt, "bodyLength": 0,
            "targetId": cid, "monotonicNs": "3"},
           {"event": "caller-socket-destroyed", "wasOpen": True,
            "targetId": cid, "monotonicNs": "4"},
           {"event": "release-original-request", **receipt,
            "targetId": cid, "monotonicNs": "5"},
           {"event": "kill-upstream-result", "status": 204,
            "bodySha256": oracle.EMPTY_SHA, "bodyLength": 0, "bodyBase64": "",
            "targetId": cid, "monotonicNs": "6"}]
    logbytes = b"".join(j(item) for item in log)
    e["proxy_log_sha256"] = hashlib.sha256(logbytes).hexdigest()
    return e, raw, logbytes


def check_rejected(name, change):
    e, raw, log = fixture()
    updated = change(e, raw, log)
    if updated is not None:
        log = updated
        e["proxy_log_sha256"] = hashlib.sha256(log).hexdigest()
    try:
        oracle.evaluate_observation(e, raw, log)
    except (ValueError, KeyError, TypeError, IndexError, AttributeError, AssertionError):
        return
    raise AssertionError("false completion accepted: " + name)


def main():
    e, raw, log = fixture()
    assert oracle.evaluate_observation(e, raw, log)["result"] == "limited-pass"
    negatives = {
        "wrong-held-CID": lambda e, r, l: e["held"].update(path=e["held"]["path"].replace("a" * 64, "b" * 64)),
        "wrong-held-signal": lambda e, r, l: e["held"].update(query="?signal=SIGKILL"),
        "no-held-request": lambda e, r, l: e["held"].update(pendingCount=0),
        "already-forwarded": lambda e, r, l: e["held"].update(forwardCount=1),
        "wrong-helper-PID": lambda e, r, l: e.update(helper_pid=900),
        "wrong-child-PID": lambda e, r, l: e.update(kill_child_pid=900),
        "wrong-kill-target": lambda e, r, l: r.__setitem__(("signal-helper", "stdout"),
                                                            j({"pid": 201, "child": 200, "cid": e["center_id"],
                                                               "signal": "SIGKILL", "accepted": True})),
        "helper-still-present": lambda e, r, l: r.__setitem__(("helper-absence-1", "stdout"),
                                                               j({"pid": 200, "absent": False})),
        "child-still-present": lambda e, r, l: r.__setitem__(("kill_child-absence-1", "stdout"),
                                                              j({"pid": 201, "absent": False})),
        "lock-held": lambda e, r, l: r.__setitem__(("lock-held-after-close", "stdout"),
                                                   j({"path": "/run/omne-center/r5abcd1234.lock",
                                                      "dev": "1", "ino": "2", "uid": 0, "gid": 0,
                                                      "mode": "600", "holders": [{"pid": 201, "fd": 10}]})),
        "flock-busy": lambda e, r, l: next(item for item in e["commands"] if item["label"] ==
                                            "lock-flock-available").update(returncode=1),
        "replaced-lock-inode": lambda e, r, l: r.__setitem__(("lock-after-flock", "stdout"),
                                                              j({"path": "/run/omne-center/r5abcd1234.lock",
                                                                 "dev": "1", "ino": "3", "uid": 0, "gid": 0,
                                                                 "mode": "600", "holders": []})),
        "caller-false-success": lambda e, r, l: r.__setitem__(("stop-helper", "stdout"),
                                                               j({"state": "stopped", "clean": True})),
        "caller-rc-zero": lambda e, r, l: next(item for item in e["commands"] if item["label"] ==
                                                 "stop-helper").update(returncode=0),
        "early-forward": lambda e, r, l: r.__setitem__(("proxy-pending", "stdout"),
                                                       j({**e["held"], "forwardCount": 1,
                                                          "closeCount": 1, "callerClosed": True})),
        "no-explicit-close": lambda e, r, l: r.__setitem__(("close-caller", "stdout"),
                                                           j({**e["held"], "closeCount": 1,
                                                              "callerClosed": True, "wasOpen": False})),
        "pending-center-exited": lambda e, r, l: r.__setitem__(("center-pending", "stdout"),
                                                                r["center-final", "stdout"]),
        "pending-status-exited": lambda e, r, l: r.__setitem__(("status-pending", "stdout"),
                                                                r["status-final", "stdout"]),
        "wrong-final-CID": lambda e, r, l: r.__setitem__(("center-final", "stdout"),
                                                         j([{**json.loads(r["center-final", "stdout"])[0],
                                                             "Id": "b" * 64}])),
        "bad-app-exit": lambda e, r, l: r.__setitem__(("center-wait", "stdout"), b"1\n"),
        "fake-engine-response": lambda e, r, l: r.__setitem__(("release-original", "stdout"),
                                                              j({**json.loads(r["release-original", "stdout"]),
                                                                 "upstreamResult": {"status": 200,
                                                                                    "bodySha256": oracle.EMPTY_SHA,
                                                                                    "bodyLength": 0,
                                                                                    "bodyBase64": ""}})),
        "no-engine-kill": lambda e, r, l: r.__setitem__(("events-after-release", "stdout"), b""),
        "pre-release-engine-kill": lambda e, r, l: r.__setitem__(("events-before-release", "stdout"),
                                                                 r["events-after-release", "stdout"]),
        "duplicate-kill-events": lambda e, r, l: r.__setitem__(("events-after-release", "stdout"),
                                                                r["events-after-release", "stdout"] * 2),
        "proxy-log-replay": lambda e, r, l: l + j({"event": "release-original-request",
                                                  "method": "POST", "path": e["held"]["path"],
                                                  "query": "?signal=SIGTERM", "bodySha256": oracle.EMPTY_SHA,
                                                  "targetId": e["center_id"], "monotonicNs": "7"}),
        "late-before-close": lambda e, r, l: e.update(close_monotonic_ns=700),
        "client-still-pending": lambda e, r, l: next(item for item in e["commands"] if item["label"] ==
                                                    "stop-helper").update(returncode=None),
        "not-original-script": lambda e, r, l: next(item for item in e["commands"] if item["label"] ==
                                                    "signal-helper")["argv"].__setitem__(6, "bad"),
        "new-stop-intent": lambda e, r, l: e["commands"].append({"label": "extra-stop", "argv":
            ["docker", "exec", "-e", "DOCKER_HOST=" + oracle.SOCKET,
             "omne-r5-synthetic-control", oracle.HELPER, "stop", "--project", "r5abcd1234"],
            "returncode": 0, "observation_expired": False}),
    }
    for name, change in negatives.items():
        check_rejected(name, change)
    print(json.dumps({"positive": 1, "negative": len(negatives),
                      "all_rejected": True, "scope": "synthetic-oracle-only"}, sort_keys=True))


if __name__ == "__main__":
    main()
