// Recheck the exact helper/kill-child relationship, then signal only the helper once.
import { readFile } from 'node:fs/promises'
const pidText = process.argv[1]
const childText = process.argv[2]
const cid = process.argv[3]
if (!/^[1-9][0-9]*$/.test(pidText)) throw new Error('known positive helper PID required')
if (!/^[1-9][0-9]*$/.test(childText) || !/^[0-9a-f]{64}$/.test(cid ?? '')) {
  throw new Error('known child PID and CID required')
}
const pid = Number(pidText)
const child = Number(childText)
if (!Number.isSafeInteger(pid) || pid <= 1 || !Number.isSafeInteger(child) || child <= 1) {
  throw new Error('unsafe PID')
}
const words = raw => {
  if (raw.length === 0 || raw.at(-1) !== 0) throw new Error('cmdline unavailable')
  return raw.subarray(0, -1).toString('utf8').split('\0')
}
const helperArgs = words(await readFile(`/proc/${pid}/cmdline`))
if (helperArgs[0].split('/').at(-1) !== 'bash' ||
    helperArgs[1] !== '/usr/local/libexec/omne-center' ||
    helperArgs[2] !== 'stop') throw new Error('PID no longer names stop helper')
const children = (await readFile(`/proc/${pid}/task/${pid}/children`))
  .toString('ascii').trim().split(/\s+/).filter(Boolean)
if (children.length !== 1 || children[0] !== childText) {
  throw new Error('kill child not direct and unique')
}
const childArgs = words(await readFile(`/proc/${child}/cmdline`))
if (childArgs.length !== 4 || childArgs[0].split('/').at(-1) !== 'docker' ||
    childArgs[1] !== 'kill' || childArgs[2] !== '--signal=SIGTERM' ||
    childArgs[3] !== cid) throw new Error('child no longer exact Docker kill')
process.kill(pid, 'SIGKILL')
process.stdout.write(JSON.stringify({ pid, child, cid, signal: 'SIGKILL', accepted: true }) + '\n')
