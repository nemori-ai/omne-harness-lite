# Late original stop request: proxy admin argv repair

This is a static v2 copy of the QA fixture at `tmp/docker-late-request/` on
`a91b889750d2cd819bf066b0e950bb9225fffdd4`. The original candidate and
its failed run `20260927T012616Z-5c8f416b` remain untouched. That run stopped
before a fault signal or held stop request: `proxy-ready-1.stderr` records
`unsafe proxy admin arguments`, and its oracle returned 1. Cleanup completed.
It is a failed fixture execution, not evidence for the R4/R5 unknown-outcome
behavior.

The only copied tool change is `proxy_admin.mjs`: the driver executes it as
`node FILE SOCKET action`, so it now reads `process.argv.slice(2)` instead of
`slice(1)`. The admin socket/action allowlist and HTTP request are unchanged.
Invocation audit found `late_proxy.mjs` is also a file invocation and already
uses `slice(2)`. `helper_probe.mjs`, `kill_helper.mjs`, `lock_holders.mjs`, and
`pid_absence.mjs` are supplied to `node --input-type=module -e` and correctly
use `argv[1]` for their first supplied argument. No other copied script reads
`process.argv`.

The adopted boundary is the HUB brief's “Late-request construction refinement”,
the accepted Docker R4/R5 mapping in
`.meta_harness/design/realization/apps/tenancy-host/docker.md` (R4 late Engine
request and R5 stop result), D-070/D-071, and EC3 v3 S-59 for real maintenance
completion. This repair changes only the measurement entry point. It does not
change the oracle's causal checks or any product behavior.

Static checks in this worktree used `TMPDIR=/private/tmp`, Node v24.21.0 via
`fnm exec --using=24.21.0 --`, and Python `-B`:

| Command (from worktree root) | Result |
| --- | --- |
| `fnm exec --using=24.21.0 -- python3 -B tmp/docker-late-request-v2/argv_test.py` | Valid file invocation reached `connect ENOENT` because the local admin socket is absent; invalid action and socket were rejected. See `argv-self-test.json`. |
| `fnm exec --using=24.21.0 -- node tmp/docker-late-request-v2/route_test.mjs` | 7 allowed, 11 rejected; `route-self-test.json`. |
| `python3 -B tmp/docker-late-request-v2/self_test.py` | 1 synthetic positive, 29 false-completion mutations rejected; `oracle-self-test.json`. |
| `node --check` for each copied `.mjs` under Node v24.21.0 | All passed. |

`argv_test.py` fails if the old `slice(1)` bug returns, since valid arguments
would be rejected before connection. It refuses to run if the hardcoded admin
socket exists locally. Repository formatting excludes `tmp/` by design, so no
formatter was applied to these scratch scripts.

`print-inputs.json` is the driver's read-only `--print-inputs` result for this
v2 path. Its canonical `inputs_sha256` is
`baf6b6776f938754ae0db0ecba99d970314e779515b952e4b561f8871d67c7d0`;
`proxy_admin.mjs` is
`315f1a98e283b604193607ab3473b34d7c60f2c7fa9a506bfc4a44e6f7c12786`.
`run-argv-inert.json` intentionally omits `--execute`; no v2 reviewed gate
exists. Executing that inert argv returned 1 with
`Docker execution requires --execute` before any Docker call; see
`inert-argv-result.json`. `manifest-static-v2.json` hashes this package and
records the checks.
There have been **zero** v2 Docker, proxy, build, or product API runs. Actual
proxy readiness, held request, process/FD cleanup, Engine forwarding and
unknown-outcome behavior remain unverified for v2 and require root review and
an independently gated run.
