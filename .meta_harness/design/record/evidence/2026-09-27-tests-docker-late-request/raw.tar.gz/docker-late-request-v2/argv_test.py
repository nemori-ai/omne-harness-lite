#!/usr/bin/env python3
"""Check the proxy admin file-entry argv boundary without starting a proxy."""

import json
import os
import pathlib
import subprocess


HERE = pathlib.Path(__file__).resolve().parent
SOCKET = "/run/omne-center-qa/control.sock"
SCRIPT = HERE / "proxy_admin.mjs"


def invoke(*args):
    return subprocess.run(["node", str(SCRIPT), *args], capture_output=True,
                          text=True, timeout=5, check=False)


def main():
    if os.path.lexists(SOCKET):
        raise RuntimeError("refusing local admin socket contact")
    version = subprocess.check_output(["node", "--version"], text=True).strip()
    assert version == "v24.21.0", version

    valid = invoke(SOCKET, "status")
    assert valid.returncode != 0, valid
    assert "connect ENOENT" in valid.stderr, valid.stderr
    assert "unsafe proxy admin arguments" not in valid.stderr, valid.stderr

    invalid_action = invoke(SOCKET, "invalid-action")
    assert invalid_action.returncode != 0, invalid_action
    assert "unsafe proxy admin arguments" in invalid_action.stderr, invalid_action.stderr

    invalid_socket = invoke(SOCKET + ".invalid", "status")
    assert invalid_socket.returncode != 0, invalid_socket
    assert "unsafe proxy admin arguments" in invalid_socket.stderr, invalid_socket.stderr

    print(json.dumps({"node": version, "entry": "node FILE SOCKET action",
                      "valid_args_reached_connect": True,
                      "invalid_action_rejected": True,
                      "invalid_socket_rejected": True,
                      "socket_absent": True}, sort_keys=True))


if __name__ == "__main__":
    main()
