// Read only the exact project lock inode and its open FDs in this private control PID namespace.
import { readdir, stat } from 'node:fs/promises'

const path = process.argv[1]
if (!/^\/run\/omne-center\/r5[0-9a-f]{8}\.lock$/.test(path)) {
  throw new Error('exact private project lock required')
}
const source = await stat(path, { bigint: true })
if (!source.isFile() || source.uid !== 0n || source.gid !== 0n ||
    (source.mode & 0o777n) !== 0o600n) throw new Error('project lock identity changed')
const holders = []
for (const name of await readdir('/proc')) {
  if (!/^[1-9][0-9]*$/.test(name)) continue
  let fds
  try { fds = await readdir(`/proc/${name}/fd`) } catch (error) {
    if (error?.code === 'ENOENT') continue
    throw error
  }
  for (const fd of fds) {
    if (!/^[0-9]+$/.test(fd)) continue
    let item
    try { item = await stat(`/proc/${name}/fd/${fd}`, { bigint: true }) } catch (error) {
      if (error?.code === 'ENOENT') continue
      throw error
    }
    if (item.dev === source.dev && item.ino === source.ino) {
      holders.push({ pid: Number(name), fd: Number(fd) })
    }
  }
}
holders.sort((a, b) => a.pid - b.pid || a.fd - b.fd)
process.stdout.write(JSON.stringify({ path, dev: source.dev.toString(),
  ino: source.ino.toString(), uid: Number(source.uid), gid: Number(source.gid),
  mode: Number(source.mode & 0o777n).toString(8), holders }) + '\n')
