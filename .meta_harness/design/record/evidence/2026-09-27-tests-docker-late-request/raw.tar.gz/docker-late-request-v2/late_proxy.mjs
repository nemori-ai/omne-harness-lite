// Disposable Unix-only Docker API proxy for one causally late original SIGTERM request.
// No automatic release. No synthetic Engine response is ever forwarded as a real result.
import fs from 'node:fs'
import http from 'node:http'
import { createHash } from 'node:crypto'
import { classifyRoute } from './proxy_rules.mjs'

const [engineSocket, dockerSocket, adminSocket, logPath, targetId] = process.argv.slice(2)
const privatePrefix = '/run/omne-center-qa/'
if (engineSocket !== '/opt/omne-private-docker/docker.sock' ||
    !dockerSocket?.startsWith(privatePrefix) || !adminSocket?.startsWith(privatePrefix) ||
    dockerSocket === adminSocket || !logPath?.startsWith('/var/lib/omne-tenancy/state/qa/') ||
    !/^[0-9a-f]{64}$/.test(targetId ?? '')) throw new Error('unsafe late-proxy inputs')
process.umask(0o077)
const logFd = fs.openSync(logPath, 'wx', 0o600)
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
let held = null
let forwardCount = 0
let closeCount = 0
let readCount = 0
let rejectCount = 0
let upstreamResult = null

function record(event) {
  const line = JSON.stringify({ ...event, monotonicNs: process.hrtime.bigint().toString() }) + '\n'
  fs.writeSync(logFd, line)
  fs.fsyncSync(logFd)
}
function state() {
  return {
    targetId, pendingCount: held !== null && forwardCount === 0 ? 1 : 0,
    forwardCount, closeCount, readCount, rejectCount,
    callerClosed: held?.callerClosed ?? false,
    method: held?.method ?? null, path: held?.path ?? null, query: held?.query ?? null,
    bodySha256: held?.bodySha256 ?? null, upstreamResult,
  }
}
function collect(request, limit, complete) {
  let completed = false
  const done = (error, body) => {
    if (completed) return
    completed = true
    complete(error, body)
  }
  const claimed = request.headers['content-length']
  if (claimed !== undefined && (!/^[0-9]+$/.test(claimed) || Number(claimed) > limit)) {
    done(new Error('request-body-limit'))
    request.resume()
    return
  }
  let size = 0
  const chunks = []
  request.on('data', chunk => {
    size += chunk.length
    if (size > limit) {
      done(new Error('request-body-limit'))
      request.destroy()
      return
    }
    chunks.push(chunk)
  })
  request.on('end', () => done(null, Buffer.concat(chunks)))
  request.on('error', error => done(error))
}
function forward(request, body, onResult) {
  let completed = false
  const done = (error, result) => {
    if (completed) return
    completed = true
    onResult(error, result)
  }
  const upstream = http.request({
    socketPath: engineSocket, method: request.method, path: request.url,
    headers: { Host: 'docker', 'Content-Length': String(body.length) },
  }, reply => {
    let size = 0
    const chunks = []
    reply.on('data', chunk => {
      size += chunk.length
      if (size > 4 * 1024 * 1024) {
        upstream.destroy(new Error('engine-response-limit'))
        return
      }
      chunks.push(chunk)
    })
    reply.on('error', error => done(error))
    reply.on('end', () => done(null, {
      status: reply.statusCode, headers: reply.headers, body: Buffer.concat(chunks),
    }))
  })
  upstream.on('error', error => done(error))
  upstream.end(body)
}
const dockerServer = http.createServer((request, response) => {
  const route = classifyRoute(request.method, request.url, targetId)
  if (route.kind === 'reject') {
    rejectCount += 1
    record({ event: 'rejected', method: request.method,
      rawUrlSha256: sha(Buffer.from(request.url ?? '')) })
    response.writeHead(403).end()
    request.resume()
    return
  }
  collect(request, 4096, (error, body) => {
    if (error !== null || body.length !== 0) {
      rejectCount += 1
      record({ event: 'body-rejected', method: request.method, path: route.path,
        query: route.query, reason: error?.message ?? 'unexpected-body' })
      response.writeHead(413).end()
      return
    }
    const receipt = { method: request.method, path: route.path, query: route.query,
      bodySha256: sha(body), bodyLength: body.length }
    if (route.kind === 'kill') {
      if (held !== null || forwardCount !== 0) {
        rejectCount += 1
        record({ event: 'duplicate-kill-rejected', ...receipt })
        response.writeHead(409).end()
        return
      }
      held = { ...receipt, url: request.url, headers: request.headers, body,
        response, callerClosed: false }
      response.on('close', () => { if (held !== null) held.callerClosed = true })
      record({ event: 'held-original-request', ...receipt, targetId })
      return
    }
    readCount += 1
    forward(request, body, (failure, result) => {
      if (failure !== null) {
        record({ event: 'read-upstream-error', ...receipt, code: failure.code ?? null })
        if (!response.destroyed) response.destroy()
        return
      }
      record({ event: 'read-forwarded', ...receipt, status: result.status,
        responseSha256: sha(result.body), responseLength: result.body.length })
      if (response.destroyed) return
      const headers = { ...result.headers }
      delete headers.connection
      delete headers['transfer-encoding']
      headers['content-length'] = String(result.body.length)
      response.writeHead(result.status, headers).end(result.body)
    })
  })
})
dockerServer.on('upgrade', (request, socket) => {
  rejectCount += 1
  record({ event: 'upgrade-rejected', rawUrlSha256: sha(Buffer.from(request.url ?? '')) })
  socket.destroy()
})

const adminServer = http.createServer((request, response) => {
  if (request.method !== 'POST' || !['/status', '/close-caller', '/release'].includes(request.url)) {
    response.writeHead(404).end()
    return
  }
  collect(request, 0, (error, body) => {
    if (error !== null || body.length !== 0) { response.writeHead(413).end(); return }
    const answer = value => response.writeHead(200, { 'Content-Type': 'application/json' })
      .end(JSON.stringify(value) + '\n')
    if (request.url === '/status') { answer(state()); return }
    if (held === null || forwardCount !== 0) { response.writeHead(409).end(); return }
    if (request.url === '/close-caller') {
      const wasOpen = !held.response.destroyed
      if (!wasOpen || held.callerClosed || closeCount !== 0) {
        response.writeHead(409).end()
        return
      }
      closeCount = 1
      held.response.socket?.destroy()
      held.callerClosed = true
      record({ event: 'caller-socket-destroyed', wasOpen, targetId })
      answer({ ...state(), wasOpen })
      return
    }
    if (!held.callerClosed) { response.writeHead(409).end(); return }
    forwardCount = 1
    record({ event: 'release-original-request', method: held.method,
      path: held.path, query: held.query, bodySha256: held.bodySha256, targetId })
    const original = { method: held.method, url: held.url }
    forward(original, held.body, (failure, result) => {
      if (failure !== null) {
        record({ event: 'kill-upstream-error', code: failure.code ?? null, targetId })
        answer({ ...state(), error: failure.code ?? 'upstream-error' })
        return
      }
      upstreamResult = { status: result.status, bodySha256: sha(result.body),
        bodyLength: result.body.length, bodyBase64: result.body.toString('base64') }
      record({ event: 'kill-upstream-result', ...upstreamResult, targetId })
      answer(state())
    })
  })
})
adminServer.on('upgrade', (_request, socket) => socket.destroy())
dockerServer.listen(dockerSocket, () => {
  fs.chmodSync(dockerSocket, 0o600)
  adminServer.listen(adminSocket, () => {
    fs.chmodSync(adminSocket, 0o600)
    record({ event: 'proxy-ready', dockerSocket, adminSocket, targetId })
  })
})
