// Exact QA-only control socket client; no Engine request and no automatic retry.
import http from 'node:http'
const [socketPath, action] = process.argv.slice(2)
if (socketPath !== '/run/omne-center-qa/control.sock' ||
    !['status', 'close-caller', 'release'].includes(action)) {
  throw new Error('unsafe proxy admin arguments')
}
const request = http.request({ socketPath, method: 'POST', path: `/${action}`,
  headers: { 'Content-Length': '0' } }, response => {
  const chunks = []
  let size = 0
  response.on('data', chunk => {
    size += chunk.length
    if (size > 64 * 1024) throw new Error('proxy admin response too large')
    chunks.push(chunk)
  })
  response.on('end', () => {
    if (response.statusCode !== 200) throw new Error(`proxy admin status ${response.statusCode}`)
    process.stdout.write(Buffer.concat(chunks))
  })
})
request.on('error', error => { throw error })
request.end()
