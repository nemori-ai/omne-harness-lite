// Pure route boundary for the disposable private-Engine proxy.
const versioned = /^\/(?:v[0-9]+\.[0-9]+\/)?(.*)$/
const containerRead = /^containers\/([0-9a-f]{12,64})\/json$/
const imageRead = /^images\/([^/]+)\/json$/
const kill = /^containers\/([0-9a-f]{64})\/kill$/
const containerListKeys = new Set(['all', 'filters', 'limit', 'size', 'since', 'before'])

export function classifyRoute(method, rawUrl, targetId) {
  if (typeof method !== 'string' || typeof rawUrl !== 'string' ||
      rawUrl.length > 4096 || !/^[0-9a-f]{64}$/.test(targetId)) return { kind: 'reject' }
  let url
  try { url = new URL(rawUrl, 'http://private-docker') } catch { return { kind: 'reject' } }
  if (url.origin !== 'http://private-docker' || url.hash !== '') return { kind: 'reject' }
  const match = versioned.exec(url.pathname)
  if (match === null) return { kind: 'reject' }
  const path = match[1]
  const query = url.search
  if (method === 'POST') {
    const requested = kill.exec(path)
    if (requested?.[1] === targetId && query === '?signal=SIGTERM') {
      return { kind: 'kill', path: url.pathname, query }
    }
    return { kind: 'reject' }
  }
  if (method !== 'GET' && method !== 'HEAD') return { kind: 'reject' }
  if ((path === '_ping' || path === 'version' || path === 'info') && query === '') {
    return { kind: 'read', path: url.pathname, query }
  }
  if (method !== 'GET') return { kind: 'reject' }
  if (path === 'containers/json' &&
      [...url.searchParams.keys()].every(key => containerListKeys.has(key)) &&
      [...url.searchParams.keys()].length === new Set(url.searchParams.keys()).size) {
    return { kind: 'read', path: url.pathname, query }
  }
  if (containerRead.test(path) &&
      (query === '' || (url.searchParams.size === 1 &&
       ['0', '1', 'false', 'true'].includes(url.searchParams.get('size'))))) {
    return { kind: 'read', path: url.pathname, query }
  }
  const image = imageRead.exec(path)
  if (image !== null &&
      (query === '' || (url.searchParams.size === 1 &&
       ['0', '1', 'false', 'true'].includes(url.searchParams.get('manifests'))))) {
    let reference
    try { reference = decodeURIComponent(image[1]) } catch { return { kind: 'reject' } }
    if (/^sha256:[0-9a-f]{64}$/.test(reference)) {
      return { kind: 'read', path: url.pathname, query }
    }
  }
  return { kind: 'reject' }
}
