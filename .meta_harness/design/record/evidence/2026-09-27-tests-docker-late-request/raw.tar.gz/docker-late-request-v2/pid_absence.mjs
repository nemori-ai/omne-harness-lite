// Inspect only a recorded PID in the private control PID namespace.
import { lstat } from 'node:fs/promises'

const pidText = process.argv[1]
if (!/^[1-9][0-9]*$/.test(pidText)) throw new Error('known positive helper PID required')
const pid = Number(pidText)
if (!Number.isSafeInteger(pid) || pid <= 1) throw new Error('unsafe helper PID')
try {
  await lstat(`/proc/${pid}`)
  process.stdout.write(JSON.stringify({ pid, absent: false }) + '\n')
} catch (error) {
  if (error?.code !== 'ENOENT') throw error
  process.stdout.write(JSON.stringify({ pid, absent: true, reason: 'ENOENT' }) + '\n')
}
