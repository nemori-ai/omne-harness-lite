import { spawnSync } from 'node:child_process'
import path from 'node:path'

const root = process.cwd()
const directory = path.join(root, 'apps/tenancy-host/deploy/docker')
const base = {
  ...process.env,
  OMNE_CENTER_IMAGE: `sha256:${'a'.repeat(64)}`,
  OMNE_CENTER_PROJECT: 'office1',
  OMNE_CENTER_UID: '10001',
  OMNE_CENTER_GID: '10001',
  OMNE_CENTER_STATE_DIR: '/private/state',
  OMNE_CENTER_VERSION: '0.0.0',
  OMNE_CENTER_BUILD_ID: 'b'.repeat(64),
  OMNE_CENTER_LOG_MAX_SIZE: '10m',
  OMNE_CENTER_LOG_MAX_FILE: '3',
}
for (const [name, extra] of [
  ['center', {
    OMNE_CENTER_CONTAINER_NAME: 'omne-office1-center',
    OMNE_CENTER_SECRETS_DIR: '/private/secrets',
    OMNE_CENTER_SETTINGS_FILE: path.join(directory, 'settings.env.example'),
    OMNE_CENTER_PUBLISH_ADDRESS: '127.0.0.1',
    OMNE_CENTER_PUBLISH_PORT: '8443',
    OMNE_CENTER_HEALTH_INTERVAL: '30s',
    OMNE_CENTER_HEALTH_TIMEOUT: '7s',
    OMNE_CENTER_HEALTH_START_PERIOD: '30s',
    OMNE_CENTER_HEALTH_RETRIES: '3',
  }],
  ['maintenance', {}],
]) {
  const file = path.join(directory, name === 'center' ? 'compose.yaml' : 'compose.maintenance.yaml')
  const result = spawnSync('docker', ['compose', '--ansi', 'never', '-f', file, '-p', 'office1', 'config', '--format', 'json'], {
    encoding: 'utf8', env: { ...base, ...extra },
  })
  if (result.status !== 0) {
    process.stderr.write(result.stderr)
    process.exitCode = 1
    continue
  }
  const service = JSON.parse(result.stdout).services[name]
  process.stdout.write(JSON.stringify({ name, stop_signal: service.stop_signal, stop_grace_period: service.stop_grace_period, restart: service.restart }) + '\n')
}
