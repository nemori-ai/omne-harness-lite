#!/usr/bin/env bash
set -euo pipefail
source apps/tenancy-host/deploy/docker/omne-center
probe_dir="$(mktemp -d "${TMPDIR:-/private/tmp}/omne-r5-wait-XXXXXXXX")"
client_pid=''
cleanup() {
  stop_local_wait_client "$client_pid"
  rm -rf -- "$probe_dir"
}
trap cleanup EXIT
mkdir "$probe_dir/bin"
cat > "$probe_dir/bin/docker" <<'FAKE_DOCKER'
#!/bin/sh
printf '%s\n' "$$" > "$(dirname "$0")/pid"
exec sleep 30
FAKE_DOCKER
chmod 0700 "$probe_dir/bin/docker"
PATH="$probe_dir/bin:$PATH"
docker_wait_client "$(printf '%064d' 0)" >/dev/null 2>/dev/null &
client_pid=$!
for _ in {1..100}; do
  [[ -s "$probe_dir/bin/pid" ]] && break
  sleep 0.01
done
[[ -s "$probe_dir/bin/pid" ]] || { printf 'fake-client-did-not-start\n' >&2; exit 1; }
actual_pid="$(cat "$probe_dir/bin/pid")"
[[ "$actual_pid" == "$client_pid" ]] || { printf 'wrapper-pid-mismatch %s %s\n' "$client_pid" "$actual_pid" >&2; exit 1; }
stop_local_wait_client "$client_pid"
client_pid=''
if kill -0 "$actual_pid" 2>/dev/null; then
  printf 'local-client-still-alive %s\n' "$actual_pid" >&2
  exit 1
fi
printf 'single-owned-client-pid=%s reaped=true\n' "$actual_pid"
