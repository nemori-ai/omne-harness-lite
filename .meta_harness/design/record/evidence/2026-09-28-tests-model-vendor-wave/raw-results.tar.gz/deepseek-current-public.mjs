import assert from 'node:assert/strict'
import { randomUUID, createHash } from 'node:crypto'
import { resolve, join } from 'node:path'
import { execFileSync } from 'node:child_process'
import * as p from '../../packages/model/pi-ai-transport/dist/index.js'
import { invokeModel, openRouterCredentialRedactionConfig } from '../../packages/model/model-request-runtime/dist/index.js'
import { judgeMessage } from '../../packages/core/messages/dist/index.js'
import { writeJsonLossless, jsonNumberSource } from '../../packages/core/content-blocks/dist/index.js'
import { openProductionLedger, privateOutputDirectory, writePrivateEvidence, paidInvocation } from '../../tools/model-probe/src/production-gate.mjs'
import { getPublic, readCredential } from '../../tools/model-probe/src/network.mjs'
import { estimateReservation } from '../../tools/model-probe/src/budget.mjs'
import { plainUsd } from './m1-real/artifact/money.mjs'

const dry = process.argv[2] === '--dry'
const credentialPath = dry ? undefined : process.argv[2]
if (!dry && !credentialPath) throw Error('Explicit credential file or --dry required')
const task = resolve('tmp/model-request-runtime'), runId = randomUUID()
const output = await privateOutputDirectory(join(task, `deepseek-current-${runId}`))
const source = execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim()
const provider = 'deepinfra/fp8', maxOutputTokens = 1024
const targets = [
  [p.deepseekV4Pro0813Definition, p.deepseekV4Pro0813Configuration, p.createDeepSeekV4ProInputMeter],
  [p.deepseekV41FlashDefinition, p.deepseekV41FlashConfiguration, p.createDeepSeekV41FlashInputMeter],
]
let credential, ledger
const visible = { toHuman: true, toModel: true }, summaries = []
function judged(value) {
  const result = judgeMessage(value)
  if ('rejected' in result) throw Error(`Synthetic message rejected: ${result.rejected}`)
  return result.ok
}
function message(type, text, id) {
  return judged({ type, id, createdAt: '2026-09-28T00:00:00Z',
    blocks: [{ id: `${id}-text`, kind: 'text', text, visibility: visible }],
    ...(type === 'system_reminder' ? { nature: 'event', source: { kind: 'extension', extension: 'certification:reminder' } } : {}),
  })
}
async function evidence(name, value) {
  const text = typeof value === 'string' ? value : writeJsonLossless(value) + '\n'
  if (credential && text.includes(credential)) throw Error('Credential sentinel in evidence')
  await writePrivateEvidence(join(output, name), text)
}
const policy = {
  now: () => new Date().toISOString(),
  schedule: (ms, callback) => { const timer = setTimeout(callback, ms); return () => clearTimeout(timer) },
  firstContentTimeoutMs: 120000, idleContentTimeoutMs: 120000,
  statusCauseTable: { '400': 'request_rejected', '401': 'credential_unavailable', '402': 'request_rejected', '429': 'upstream_unavailable', '500': 'upstream_unavailable', '502': 'upstream_unavailable', '503': 'upstream_unavailable', '504': 'upstream_unavailable' },
  credentialRedaction: openRouterCredentialRedactionConfig, diagnostic() {},
}
const network = { maxConnections: 1, idleConnectionTimeoutMs: 5000, connectTimeoutMs: 15000, maxErrorBodyBytes: 65536, maxSseEventBytes: 8388608, credentialRedaction: openRouterCredentialRedactionConfig }
try {
  if (!dry) {
    const ledgerPath = join(task, 'ledger.json')
    ledger = await openProductionLedger(ledgerPath, ledgerPath, { limitUsd: '100', researchLimitUsd: '50' })
    credential = await readCredential(credentialPath)
  }
  for (const [definition, configuration, meterFactory] of targets) {
    const model = definition.modelId, label = model.split('/')[1]
    const profile = p.createOfficialProfileContent(definition, { providers: [provider], allowFallback: false, configuration })
    assert.ok('ok' in profile)
    const meter = meterFactory(definition)
    const transport = p.createPiAiTransport({ definitions: [definition], inputMeters: [meter], policy: network })
    const prefix = `Synthetic runtime certification ${runId}.\n` +
      Array.from({ length: 320 }, (_, i) => `Reference row ${i}: stable reference material must remain unchanged between requests; no tool result is present in this row.\n`).join('')
    const base = {
      routeName: model, provider, tokenMargin: { multiplier: 1.1, reserveTokens: 256 },
      parameters: { reasoningEffort: 'low', maxOutputTokens },
      snapshot: { adaptation: profile.ok.adaptation, providers: profile.ok.providers, allowFallback: profile.ok.allowFallback, inputModalities: profile.ok.inputModalities, outputModalities: profile.ok.outputModalities, maxInputTokens: profile.ok.maxInputTokens, maxOutputTokens: profile.ok.maxOutputTokens, inputConstraints: profile.ok.inputConstraints, upstreamInputLimits: profile.ok.upstreamInputLimits, updatedAt: new Date().toISOString() },
      tools: [{ name: 'lookup_code', description: 'Look up the secret answer code by record name.', parameters: { type: 'object', properties: { name: { type: 'string' } }, required: ['name'], additionalProperties: false } }],
      messages: [message('system', prefix, 'stable-system'), message('system_reminder', 'Use lookup_code to obtain the code. After the tool result, answer only the returned code.', 'stable-reminder'), message('user', 'Please retrieve the code for record ORCHID by calling lookup_code. Do not guess the value.', 'question')],
    }
    let endpoint, previousSerialized
    try {
      if (!dry) {
        const facts = await getPublic(`/api/v1/models/${model}/endpoints`)
        endpoint = JSON.parse(facts.raw).data.endpoints.find(row => row.tag === provider)
        assert.ok(endpoint)
        assert.ok(endpoint.max_completion_tokens >= maxOutputTokens)
        await evidence(`${label}-endpoints.json`, { ...facts, source })
      }
      for (let turn = 1; turn <= (dry ? 1 : 3); turn++) {
        const input = { ...base, target: { kind: 'model_call', callId: `${runId}-${label}-${turn}`, dispatch: 1 } }
        const planned = transport.plan(input)
        if (!('planned' in planned)) {
          await evidence(`${label}-${turn}-rejected.json`, planned)
          throw Error('Production planner rejected certification input')
        }
        const plan = planned.planned
        await evidence(`${label}-${turn}-request.json`, plan.serialized + '\n')
        const measurement = meter.measure({ body: plan.body, serialized: plan.serialized })
        assert.equal(measurement.kind, 'estimated')
        if (dry) { summaries.push({ model, measurement, bytes: Buffer.byteLength(plan.serialized) }); continue }
        const estimateUsd = estimateReservation(endpoint.pricing, Buffer.byteLength(plan.serialized), maxOutputTokens)
        let sends = 0, arrivals = 0, stopped = false
        const adapter = {
          plan: () => planned,
          send: (actual, secret, signal) => { assert.equal(actual, plan); sends++; return transport.send(actual, secret, signal) },
          read: async function* (response, actual, signal) { try { return yield* transport.read(response, actual, signal) } finally { await response.stopped; stopped = true } },
        }
        const receipt = await paidInvocation(ledger, { model, provider, stage: 'acceptance', estimateUsd }, async id => {
          const handle = invokeModel({ ...input, transport: adapter, credential, policy, signal: AbortSignal.timeout(180000), onAccepted() { arrivals++ } })
          const result = await handle.outcome
          await evidence(`${label}-${turn}-outcome.json`, result)
          const actualUsd = 'outcome' in result && result.cost.source === 'upstream_usage' && result.cost.cost_usd !== 'unknown' ? plainUsd(jsonNumberSource(result.cost.cost_usd)) : undefined
          return { id, result, actualUsd }
        })
        const result = receipt.receipt.result
        const summary = { model, turn, id: receipt.id, measurement, actualUsd: receipt.receipt.actualUsd, outcome: result.outcome, usage: result.usage, servingProvider: result.servingProvider, upstreamModel: result.upstreamModel, arrivals, sends, stopped, bodyHash: createHash('sha256').update(plan.serialized).digest('hex'), identicalToPrevious: previousSerialized === plan.serialized }
        summaries.push(summary)
        await evidence(`${label}-${turn}-summary.json`, summary)
        assert.equal(result.outcome, 'complete')
        assert.equal(sends, 1); assert.equal(stopped, true); assert.ok(arrivals > 0)
        if (turn === 1) {
          const calls = result.blocks.filter(block => block.kind === 'tool_call')
          assert.equal(calls.length, 1)
          const call = calls[0]
          assert.equal(call.complete, true); assert.equal(call.tool, 'lookup_code')
          assert.equal(call.arguments.name, 'ORCHID')
          base.messages = [...base.messages,
            judged({ id: 'actual-assistant', type: 'assistant', response: 'actual-response', ending: result.ending, createdAt: new Date().toISOString(), blocks: result.blocks }),
            judged({ id: 'actual-tool-result', type: 'tool', callId: call.callId, createdAt: new Date().toISOString(), blocks: [{ id: 'result', kind: 'tool_result', callId: call.callId, outcome: 'completed', visibility: visible, blocks: [{ id: 'result-text', kind: 'text', text: 'ORCHID-742', visibility: visible }] }] }),
          ]
        } else {
          assert.ok(result.blocks.filter(b => b.kind === 'text').map(b => b.text).join('').includes('ORCHID-742'))
          if (turn === 3) { assert.equal(previousSerialized, plan.serialized); assert.notEqual(result.usage.cache_read_tokens, 'unknown'); assert.ok(Number(jsonNumberSource(result.usage.cache_read_tokens)) > 0) }
        }
        previousSerialized = plan.serialized
      }
    } finally { await transport.close() }
  }
  await evidence('result.json', { pass: true, dry, source, summaries, scope: 'Fixed official public production factory: synthetic long prefix, actual tool response/history, identical repeated follow-up and upstream cache/cost. Not complete per-model or service certification.' })
  console.log(JSON.stringify({ pass: true, dry, output, count: summaries.length }))
} catch (error) {
  await evidence('failure.json', { source, summaries, message: String(error.message) })
  console.log(JSON.stringify({ pass: false, output, completed: summaries.length }))
  process.exitCode = 1
} finally { if (ledger) await ledger.close() }
