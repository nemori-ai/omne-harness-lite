import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const root = 'tmp/maintenance-e2e-fix'
const target = 'apps/tenancy-host/tests/e2e/deploy.ts'
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const command = (name, args = []) => execFileSync(name, args, { encoding: 'utf8' }).trim()
const beforeSha = readFileSync(join(root, 'deploy-before.sha256'), 'utf8').split(' ')[0]
const afterSha = readFileSync(join(root, 'deploy-after.sha256'), 'utf8').split(' ')[0]
const inputs = {
  checkout: process.cwd(),
  branch: command('git', ['branch', '--show-current']),
  headAtTest: command('git', ['rev-parse', 'HEAD']),
  changedTrackedPathsAtTest: command('git', ['diff', '--name-only']).split('\n').filter(Boolean),
  target,
  targetBeforeSha256: beforeSha,
  targetAfterSha256: afterSha,
  v1cExplicitFailureSha256: sha(readFileSync('tmp/maintenance-e2e-diagnosis/probe-1.log')),
  v1cExplicitMetadataSha256: sha(readFileSync('tmp/maintenance-e2e-diagnosis/cert-metadata.log')),
  v1cNamedTlsControlSha256: sha(readFileSync('tmp/maintenance-e2e-diagnosis/named-curve-tls-control.log')),
  platform: process.platform,
  architecture: process.arch,
  macOS: command('sw_vers', ['-productVersion']),
  node: process.version,
  nodeOpenSsl: process.versions.openssl,
  systemOpenSsl: command('openssl', ['version']),
  pnpm: command('pnpm', ['--version']),
  vitest: JSON.parse(readFileSync('apps/tenancy-host/node_modules/vitest/package.json')).version,
  tmpdir: '/private/tmp',
  candidateSource: '10.18.100.75',
  sourceProbe: JSON.parse(readFileSync(join(root, 'source-address-probe.log'), 'utf8')),
  environmentFlags: JSON.parse(readFileSync(join(root, 'environment-flags.json'), 'utf8')),
}
writeFileSync(join(root, 'inputs.json'), JSON.stringify(inputs, null, 2) + '\n')

const runs = readdirSync(join(root, 'runs'))
  .filter(name => name.endsWith('.exit'))
  .sort()
  .map(name => {
    const stem = name.slice(0, -'.exit'.length)
    const prefix = join(root, 'runs', stem)
    const log = readFileSync(`${prefix}.log`, 'utf8')
    return {
      id: stem,
      command: readFileSync(`${prefix}.command`, 'utf8').trim(),
      startUtc: readFileSync(`${prefix}.start`, 'utf8').trim(),
      endUtc: readFileSync(`${prefix}.end`, 'utf8').trim(),
      exitCode: Number(readFileSync(`${prefix}.exit`, 'utf8').trim()),
      logPath: `${prefix}.log`,
      logSha256: sha(log),
      summary: log.match(/Test Files[^\n]*\n\s*Tests[^\n]*/)?.[0] ?? null,
    }
  })
const evidence = {
  runs,
  sourceAddressProbe: {
    command: 'TMPDIR=/private/tmp fnm exec --using=24.21.0 -- node --experimental-transform-types --no-warnings tmp/maintenance-e2e-fix/source-address-probe.mjs 10.18.100.75',
    logPath: join(root, 'source-address-probe.log'),
    logSha256: sha(readFileSync(join(root, 'source-address-probe.log'))),
  },
  actualHelperCertificateMetadata: {
    command: 'TMPDIR=/private/tmp fnm exec --using=24.21.0 -- node --experimental-transform-types --no-warnings tmp/maintenance-e2e-diagnosis/cert-metadata.mjs',
    logPath: join(root, 'cert-metadata-after.log'),
    logSha256: sha(readFileSync(join(root, 'cert-metadata-after.log'))),
    parsed: JSON.parse(readFileSync(join(root, 'cert-metadata-after.log'), 'utf8')),
  },
  hostFailuresPath: join(root, 'host-failures.txt'),
  hostFailuresCount: readFileSync(join(root, 'host-failures.txt'), 'utf8').trim().split('\n').length,
  hostFailuresSha256: sha(readFileSync(join(root, 'host-failures.txt'))),
  sourceProbeScratchRemaining: readdirSync('/private/tmp').filter(name => name.startsWith('omne-e2e-source-probe-')),
}
writeFileSync(join(root, 'runs.json'), JSON.stringify(evidence, null, 2) + '\n')
