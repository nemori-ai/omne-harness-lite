#!/usr/bin/env bash
set -euo pipefail

expected_root=/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-dispose-probe
if [[ "$PWD" != "$expected_root" ]] || [[ "$(git branch --show-current)" != pandazki/agent-work-loop-dispose-probe ]]; then
  printf 'wrong checkout or branch\n' >&2
  exit 64
fi
kind=${1:?format, typecheck, or host required}
case "$kind" in
  format)
    command=(fnm exec --using=24.21.0 -- pnpm format:check -- apps/tenancy-host/tests/e2e/deploy.ts)
    ;;
  typecheck)
    command=(fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host run typecheck)
    ;;
  host)
    if ! ifconfig | rg -q '[[:space:]]inet 10\.18\.100\.75[[:space:]]'; then
      printf 'second source address is no longer assigned\n' >&2
      exit 75
    fi
    command=(env OMNE_TEST_ALTERNATE_SOURCE_ADDRESS=10.18.100.75 fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host run test)
    ;;
  *) printf 'invalid kind\n' >&2; exit 64 ;;
esac
out="tmp/maintenance-e2e-fix/runs/${kind}"
if [[ -e "${out}.log" ]]; then
  printf 'run already exists: %s\n' "$out" >&2
  exit 64
fi
export TMPDIR=/private/tmp
unset OMNE_E2E_EVIDENCE_DIR OMNE_E2E_KEEP OMNE_E2E_SECRETS_OUT
printf '%q ' "${command[@]}" > "${out}.command"
printf '\n' >> "${out}.command"
date -u +%Y-%m-%dT%H:%M:%SZ > "${out}.start"
set +e
"${command[@]}" > "${out}.log" 2>&1
status=$?
set -e
date -u +%Y-%m-%dT%H:%M:%SZ > "${out}.end"
printf '%s\n' "$status" > "${out}.exit"
printf '%s exit=%s log=%s\n' "$kind" "$status" "${out}.log"
exit "$status"
