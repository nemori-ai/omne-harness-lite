# M0-V1d：e2e EC 证书使用命名曲线

## 改动与采用输入

执行工作树 `/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-dispose-probe`，分支 `pandazki/agent-work-loop-dispose-probe`，父提交 `ed01430dba3a4449792ee9c9b69e559d028afee8`。本任务提交 `818a7163e00f2f28b5a4fb7b6407c165ff07ed04`，作者为既有的人类 Git 配置。唯一 tracked 改动是 `apps/tenancy-host/tests/e2e/deploy.ts` 的 `makeCa()` 与 `makeServerCertificate()` 两处 `openssl req -newkey ec` 参数：各补 `-pkeyopt ec_param_enc:named_curve`，保留 `ec_paramgen_curve:P-256`、CA/叶子扩展、SAN 及既有 TLS 验证。精确 [diff](deploy-after.diff)、[commit 元数据](commit.json)；没有改断言、TLS 安全级别、产品代码、系统网络或凭据。

V1c 的 [首次请求反例](../maintenance-e2e-diagnosis/probe-1.log)记录 `Certificate public key has explicit ECC parameters`，旧实际 helper 的 CA/叶子元数据均为 `Field Type: prime-field`；其输入和命名曲线隔离控制均未覆盖。改动后再次调用**本项目同一两个 helper**，CA/叶子均显示 `ASN1 OID: prime256v1`、`NIST CURVE: P-256`，见 [cert-metadata-after.log](cert-metadata-after.log)。这验证了参数确实改变夹具制品表示，而不仅是脚本成功退出。环境、源码和新旧日志 SHA-256 见 [inputs.json](inputs.json)。

## 本机第二来源与实际检查

恢复时重新检查本机地址，当前除 `127.0.0.1` 外，`en0` 已分配 `10.18.100.75`；没有沿用前一地点的地址。[source-address-probe.mjs](source-address-probe.mjs)先验证此地址属于本机，再让原 `sendTls()` 从该地址连到 `127.0.0.1` 的隔离 TLS 服务器。结果 `peerAuthorized=true`、`TLSv1.3`、`requestWritten=true`、`error=null`，见 [原始探针输出](source-address-probe.log)。探针没有输出证书、私钥或请求正文，并在 `finally` 清理临时密钥/证书目录。因此仅在这次探针通过后，完整 host 测试才显式设置 `OMNE_TEST_ALTERNATE_SOURCE_ADDRESS=10.18.100.75`。未修改系统 IP、VPN、代理或路由。

局部格式写入显示 unchanged；同一文件的共享格式检查退出 0，host 类型检查退出 0。命令、UTC 起止、退出码及原始日志哈希在 [runs.json](runs.json)，对应 [format.log](runs/format.log)、[typecheck.log](runs/typecheck.log)。

## 完整 host 一轮结果及剩余失败

按包缺省并发执行一次 `TMPDIR=/private/tmp OMNE_TEST_ALTERNATE_SOURCE_ADDRESS=10.18.100.75 pnpm --filter @omne-harness-lite/tenancy-host run test`（Node 24.21.0/pnpm 10.28.1）。**运行完成但退出 1**：15 文件中 13 通过、1 失败、1 跳过；198 测试中 186 通过、1 失败、11 跳过。唯一失败是 [host-failures.txt](host-failures.txt) 所列 e2e “另一个程序（openssl s_client）”步骤：系统 LibreSSL 3.3.6 的 `s_client` 不接受既有 `-verify_hostname`，报 `unknown option -verify_hostname`、退出 1。失败断言在 `e2e.spec.ts:1528`，完整原始输出和 CLI usage 在 [host.log](runs/host.log)。测试中此前的首次 TLS 请求、业务旅程、第二来源请求和其它证书检验未再失败；但这不等于完整 host 测试通过。`OMNE_TEST_PG_URL` 未设置，PG 延期组仍跳过，跳过未计为通过。

本任务仅授权改证书生成参数；`s_client` 调用与它需要的 CA/主机名核验位于 `e2e.spec.ts`，不在本次写范围。不能通过删除 `-verify_hostname`、放宽断言或降低验证要求取得绿色结果。下一步需由测试拥有者在保持独立程序验证 CA 与主机名的前提下，处理当前 LibreSSL CLI 不支持该选项的环境差异；本提交不宣称完成该项验收。

## 范围与交接状态

[commit.json](commit.json) 证明提交父节点、唯一变更路径、人类作者和提交后干净的 tracked 状态；`git show --check` 退出 0。旧 V1c 证据原样保留，新证据只在 `tmp/maintenance-e2e-fix/`。探针临时目录无残留，完整 host 测试默认临时部署根按其 `afterAll` 清理；测试进程已有实际退出码。本任务未推送、未合并；独立复核与接受归主线。

主线 HUB 在本次开工时已由此前任务说明中的 `2cb236db` 前进到 `dbd30176`，并有 Docker 设计草稿未提交；本任务只在指定 spoke 开发，未触碰 HUB，也不据 HUB 现状更改此提交的基线或范围。
