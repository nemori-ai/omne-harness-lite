fnm exec --using=24.21.0 -- pnpm format:check -- apps/tenancy-host/tests/e2e/deploy.ts 
