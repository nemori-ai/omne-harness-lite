env OMNE_TEST_ALTERNATE_SOURCE_ADDRESS=10.18.100.75 fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host run test 
