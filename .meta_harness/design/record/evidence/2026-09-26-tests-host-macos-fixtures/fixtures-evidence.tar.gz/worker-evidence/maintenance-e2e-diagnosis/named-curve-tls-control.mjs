import { execFileSync } from 'node:child_process'
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { createServer } from 'node:tls'
import { join } from 'node:path'
import { sendTls } from '../../apps/tenancy-host/tests/e2e/client.ts'

const root = mkdtempSync('/private/tmp/omne-e2e-tls-control-')
let server
const sockets = new Set()
try {
  const config = join(root, 'req.cnf')
  writeFileSync(config, [
    '[req]', 'prompt = no', 'distinguished_name = dn', 'x509_extensions = v3',
    '[dn]', 'CN = localhost',
    '[v3]', 'subjectAltName = DNS:localhost,IP:127.0.0.1',
    'basicConstraints = critical,CA:FALSE',
    'keyUsage = critical,digitalSignature',
    'extendedKeyUsage = serverAuth', '',
  ].join('\n'))
  execFileSync('openssl', [
    'req', '-x509', '-config', config, '-extensions', 'v3', '-newkey', 'ec',
    '-pkeyopt', 'ec_paramgen_curve:P-256', '-pkeyopt', 'ec_param_enc:named_curve',
    '-nodes', '-keyout', join(root, 'key.pem'), '-out', join(root, 'cert.pem'), '-days', '1',
  ], { cwd: root, stdio: ['ignore', 'ignore', 'pipe'] })
  const cert = readFileSync(join(root, 'cert.pem'))
  const key = readFileSync(join(root, 'key.pem'))
  server = createServer({ key, cert, allowHalfOpen: true }, socket => {
    sockets.add(socket)
    socket.once('close', () => sockets.delete(socket))
    socket.once('end', () => socket.end())
    socket.on('data', () => undefined)
  })
  server.on('error', error => { throw error })
  await new Promise((resolve, reject) => server.listen(0, '127.0.0.1', error => error ? reject(error) : resolve()))
  const address = server.address()
  if (address === null || typeof address === 'string') throw new Error('server did not bind')
  const wire = await sendTls(
    { host: '127.0.0.1', port: address.port, servername: 'localhost', ca: cert.toString('utf8') },
    Buffer.from('GET / HTTP/1.1\r\nHost: localhost\r\n\r\n'),
    5_000,
  )
  console.log(JSON.stringify({
    requestWritten: wire.requestWritten,
    peerAuthorized: wire.tls?.authorized ?? null,
    protocol: wire.tls?.protocol ?? null,
    error: wire.error ?? null,
    timedOut: wire.timedOut,
    receivedBytes: wire.received.length,
  }, null, 2))
  if (!wire.requestWritten || wire.tls?.authorized !== true) process.exitCode = 1
} finally {
  for (const socket of sockets) socket.destroy()
  if (server?.listening) await new Promise(resolve => server.close(resolve))
  rmSync(root, { recursive: true, force: true })
}
