#!/usr/bin/env bash
set -euo pipefail

expected_root=/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-dispose-probe
if [[ "$PWD" != "$expected_root" ]] || [[ "$(git branch --show-current)" != pandazki/agent-work-loop-dispose-probe ]]; then
  printf 'wrong checkout or branch\n' >&2
  exit 64
fi
number=${1:?probe number required}
if [[ "$number" != 1 && "$number" != 2 ]]; then
  printf 'probe budget exceeded\n' >&2
  exit 64
fi
out="tmp/maintenance-e2e-diagnosis/probe-${number}"
if [[ -e "${out}.log" ]]; then
  printf 'probe already exists\n' >&2
  exit 64
fi
export TMPDIR=/private/tmp
export OMNE_E2E_TLS_DIAGNOSTIC=1
unset OMNE_TEST_ALTERNATE_SOURCE_ADDRESS OMNE_E2E_EVIDENCE_DIR OMNE_E2E_KEEP OMNE_E2E_SECRETS_OUT
command=(fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host exec vitest run tests/e2e/e2e.spec.ts --testNamePattern '第一次启动成功|一个还没登录的人看体检')
printf '%q ' "${command[@]}" > "${out}.command"
printf '\n' >> "${out}.command"
date -u +%Y-%m-%dT%H:%M:%SZ > "${out}.start"
set +e
"${command[@]}" > "${out}.log" 2>&1
status=$?
set -e
date -u +%Y-%m-%dT%H:%M:%SZ > "${out}.end"
printf '%s\n' "$status" > "${out}.exit"
printf 'probe %s exit=%s log=%s\n' "$number" "$status" "${out}.log"
exit "$status"
