import { execFileSync } from 'node:child_process'
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const root = mkdtempSync('/private/tmp/omne-e2e-named-control-')
try {
  const config = join(root, 'req.cnf')
  writeFileSync(config, '[req]\nprompt = no\ndistinguished_name = dn\n[dn]\nCN = named-control\n')
  execFileSync('openssl', [
    'req', '-x509', '-config', config, '-newkey', 'ec',
    '-pkeyopt', 'ec_paramgen_curve:P-256',
    '-pkeyopt', 'ec_param_enc:named_curve',
    '-nodes', '-keyout', join(root, 'key.pem'), '-out', join(root, 'cert.pem'), '-days', '1',
  ], { cwd: root, stdio: ['ignore', 'ignore', 'pipe'] })
  const description = execFileSync('openssl', ['x509', '-in', join(root, 'cert.pem'), '-noout', '-text'], { encoding: 'utf8' })
  const metadata = description.split('\n').map(line => line.trim()).filter(line =>
    /Public Key Algorithm|ASN1 OID|Field Type|NIST CURVE|prime-field|explicit|named curve/i.test(line),
  )
  console.log(JSON.stringify({ systemOpenSsl: execFileSync('openssl', ['version'], { encoding: 'utf8' }).trim(), metadata }, null, 2))
} finally {
  rmSync(root, { recursive: true, force: true })
}
