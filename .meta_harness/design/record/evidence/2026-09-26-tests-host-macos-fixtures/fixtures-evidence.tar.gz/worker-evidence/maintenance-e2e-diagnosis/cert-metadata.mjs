import { execFileSync } from 'node:child_process'
import { mkdtempSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { makeCa, makeServerCertificate } from '../../apps/tenancy-host/tests/e2e/deploy.ts'

const root = mkdtempSync('/private/tmp/omne-e2e-cert-inspect-')
try {
  const ca = makeCa(root, 'probe-ca', () => undefined)
  const leaf = makeServerCertificate(root, 'probe-leaf', ca, ['DNS:localhost', 'IP:127.0.0.1'], () => undefined)
  const inspect = file => {
    const description = execFileSync('openssl', ['x509', '-in', file, '-noout', '-text'], { encoding: 'utf8' })
    return description.split('\n').map(line => line.trim()).filter(line =>
      /Public Key Algorithm|ASN1 OID|Field Type|NIST CURVE|prime-field|explicit|named curve/i.test(line),
    )
  }
  console.log(JSON.stringify({
    systemOpenSsl: execFileSync('openssl', ['version'], { encoding: 'utf8' }).trim(),
    nodeOpenSsl: process.versions.openssl,
    caPublicKeyMetadata: inspect(ca.certFile),
    leafPublicKeyMetadata: inspect(join(root, 'probe-leaf.pem')),
  }, null, 2))
} finally {
  rmSync(root, { recursive: true, force: true })
}
