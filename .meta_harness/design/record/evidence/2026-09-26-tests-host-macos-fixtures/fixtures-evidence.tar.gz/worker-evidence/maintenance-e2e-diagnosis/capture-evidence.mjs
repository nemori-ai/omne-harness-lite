import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const root = 'tmp/maintenance-e2e-diagnosis'
const client = 'apps/tenancy-host/tests/e2e/client.ts'
const deploy = 'apps/tenancy-host/tests/e2e/deploy.ts'
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const cmd = (name, args = []) => execFileSync(name, args, { encoding: 'utf8' }).trim()
const headClient = execFileSync('git', ['show', `HEAD:${client}`])
const inputs = {
  checkout: process.cwd(),
  branch: cmd('git', ['branch', '--show-current']),
  head: cmd('git', ['rev-parse', 'HEAD']),
  trackedStatusAfterRestore: cmd('git', ['status', '--porcelain']),
  platform: process.platform,
  arch: process.arch,
  node: process.version,
  nodeOpenSsl: process.versions.openssl,
  systemOpenSsl: cmd('openssl', ['version']),
  clientHeadSha256: sha(headClient),
  clientBeforeSha256: readFileSync(join(root, 'client-before.sha256'), 'utf8').trim().split(' ')[0],
  clientAfterSha256: readFileSync(join(root, 'client-after.sha256'), 'utf8').trim().split(' ')[0],
  clientAfterDiffBytes: readFileSync(join(root, 'client-after.diff')).length,
  deploySha256: sha(readFileSync(deploy)),
  priorHostFailureLogSha256: sha(readFileSync('tmp/maintenance-dispose-fix/runs/host.log')),
}
writeFileSync(join(root, 'inputs.json'), JSON.stringify(inputs, null, 2) + '\n')

const probeLog = readFileSync(join(root, 'probe-1.log'), 'utf8')
const diagnosticLine = probeLog.split('\n').find(line => line.startsWith('{"event":"tls-probe",'))
if (diagnosticLine === undefined) throw new Error('TLS diagnostic missing')
const outputs = {
  firstRequest: {
    command: readFileSync(join(root, 'probe-1.command'), 'utf8').trim(),
    startUtc: readFileSync(join(root, 'probe-1.start'), 'utf8').trim(),
    endUtc: readFileSync(join(root, 'probe-1.end'), 'utf8').trim(),
    exitCode: Number(readFileSync(join(root, 'probe-1.exit'), 'utf8').trim()),
    logPath: join(root, 'probe-1.log'),
    logSha256: sha(probeLog),
    diagnostic: JSON.parse(diagnosticLine),
    summary: probeLog.match(/Test Files[^\n]*\n\s*Tests[^\n]*/)?.[0] ?? null,
  },
  fixtureCertificateMetadata: {
    command: 'TMPDIR=/private/tmp fnm exec --using=24.21.0 -- node --experimental-transform-types --no-warnings tmp/maintenance-e2e-diagnosis/cert-metadata.mjs',
    outputPath: join(root, 'cert-metadata.log'),
    outputSha256: sha(readFileSync(join(root, 'cert-metadata.log'))),
    result: JSON.parse(readFileSync(join(root, 'cert-metadata.log'), 'utf8')),
  },
  namedCurveMetadata: {
    command: 'TMPDIR=/private/tmp fnm exec --using=24.21.0 -- node tmp/maintenance-e2e-diagnosis/named-curve-control.mjs',
    outputPath: join(root, 'named-curve-control.log'),
    outputSha256: sha(readFileSync(join(root, 'named-curve-control.log'))),
    result: JSON.parse(readFileSync(join(root, 'named-curve-control.log'), 'utf8')),
  },
  namedCurveTlsControl: {
    command: 'TMPDIR=/private/tmp OMNE_E2E_TLS_DIAGNOSTIC=1 fnm exec --using=24.21.0 -- node --experimental-transform-types --no-warnings tmp/maintenance-e2e-diagnosis/named-curve-tls-control.mjs',
    outputPath: join(root, 'named-curve-tls-control.log'),
    outputSha256: sha(readFileSync(join(root, 'named-curve-tls-control.log'))),
    result: JSON.parse(readFileSync(join(root, 'named-curve-tls-control.log'), 'utf8')),
  },
}
writeFileSync(join(root, 'runs.json'), JSON.stringify(outputs, null, 2) + '\n')
