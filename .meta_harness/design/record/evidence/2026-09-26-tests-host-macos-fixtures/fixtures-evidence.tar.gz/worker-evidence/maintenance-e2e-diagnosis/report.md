# M0-V1c：首次 TLS 请求 `UNSPECIFIED` 诊断与暂停交接

## 已定位原因

在 macOS 27.0 arm64、Node 24.21.0（内置 OpenSSL 3.5.8）与系统 `openssl` LibreSSL 3.3.6 上，e2e 的首次公开体检请求没有写出，是 TLS 证书检查拒绝了**显式 ECC 曲线参数**。仅选择“第一次启动成功”和“未登录公开体检”两项的最小探针中，启动项通过；客户端 `sendTls()` 的真实 `error` 事件为 `name=Error`、`code=UNSPECIFIED`、`message=Certificate public key has explicit ECC parameters`。测试原有读面只保留 `err.code`，故显示 `request not sent (UNSPECIFIED)`；这一错误发生在 `secureConnect` 与写请求之前。原始输出见 [probe-1.log](probe-1.log)，环境、输入哈希及命令见 [inputs.json](inputs.json)、[runs.json](runs.json)。

未改动的 `apps/tenancy-host/tests/e2e/deploy.ts` 中，`makeCa()` 和 `makeServerCertificate()` 两处调用系统 `openssl req -newkey ec -pkeyopt ec_paramgen_curve:P-256`，都没有显式指定参数编码。用这两个实际 helper 在隔离临时目录生成的 CA 与叶子证书，过滤后的公钥元数据均为 `Field Type: prime-field`，见 [cert-metadata.log](cert-metadata.log)；脚本没有输出证书、私钥或请求正文。作为对照，系统 LibreSSL 加 `-pkeyopt ec_param_enc:named_curve` 生成的证书显示 `ASN1 OID: prime256v1`、`NIST CURVE: P-256`，见 [named-curve-control.log](named-curve-control.log)。使用同一 `sendTls()`、DNS `localhost` 与 IP SAN、正常授权及 TLS 1.3 的隔离服务器控制请求，得到 `peerAuthorized=true`、`protocol=TLSv1.3`、`requestWritten=true`、`error=null`，见 [named-curve-tls-control.log](named-curve-tls-control.log)。该控制只证明命名曲线证书可通过此客户端握手与写请求，不声称完整 host e2e 已通过。

因此后续实现任务的最小候选是仅在上述两处证书/CSR 生成命令显式加入 `ec_param_enc:named_curve`，保持 P-256、CA/叶子用途、SAN、TLS 校验与安全级别。该建议需要按正常并发全量 host 验证；当前 37 项 e2e 失败中有大量依赖前面注册/登录步骤，不能在未执行修复后全套测试时断言 37 项全部同因。

## 尝试与代码状态

- 预算内执行了 **1 次实际 e2e 首请求探针**（启动测试 1 通过、公开体检 1 失败、其余 44 跳过）与 **1 次命名曲线的隔离 TLS 请求控制**；未运行 37 项全套。另两次只生成、检查证书编码的脚本没有发网络请求。脚本和原始输出都在本目录，临时证书目录由各脚本的 `finally` 删除。
- 为看到错误 `name/code/短消息`，曾在 `apps/tenancy-host/tests/e2e/client.ts` 的错误监听处加入由 `OMNE_E2E_TLS_DIAGNOSTIC=1` 控制的临时插桩。[client-instrument.diff](client-instrument.diff) 保存精确内容。撤除前复核当前 diff 与保存的插桩 diff 逐字相同；撤除后 [client-before.sha256](client-before.sha256) 与 [client-after.sha256](client-after.sha256) 都是 `85ac6e2476667c96bff4f6dcb29d4330dbaba06287100d3c21006313e9ffe37d`，与 HEAD 相同，插桩前及撤除后的 diff 均为空。没有提交插桩。
- 当前 HEAD 仍为 `ed01430dba3a4449792ee9c9b69e559d028afee8`，tracked Git 状态干净。`deploy.ts` 未修改，SHA-256 见 [status.json](status.json)；本次三个独有临时证书目录前缀均无残留。此前 V1b 修复和 V1c 诊断证据均保留；未推送或合并。

主线转达用户要求“规划好后暂停、准备登机”。因此后续 V1d 的 `deploy.ts` 修改、第二来源地址绑定探针和完整 host 测试**均未启动**，也没有新提交或系统网络变更。恢复时先重新核对同一 worktree/HEAD、有效任务输入与网络条件，再按已授权的 V1d 范围实施；本报告不代表 V1d 通过或最终接受。
