# M0-V1b：macOS maintenance-dispose 夹具路径修复交接

## 变更与依据

在隔离工作树 `/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-dispose-probe`、分支 `pandazki/agent-work-loop-dispose-probe`，从基线 `2cb236db7da15e78bb1e96dd8220ee68b6eceb75` 提交 `ed01430dba3a4449792ee9c9b69e559d028afee8`。唯一 tracked 改动是 `apps/tenancy-host/tests/maintenance-dispose.process.spec.ts`：测试部署标签从 `maintenance-dispose-${fault}` 缩为 `dispose-${fault}`，加一行说明 macOS Unix socket 路径上限。四个 case、故障注入、原始断言和 20 秒超时均未改；生产 socket 检查和共享 `deployment()` helper 未改。[commit.json](commit.json) 记录 commit、父提交、作者、唯一改动路径及提交后的干净 tracked 状态。

依据是原诊断的 macOS 反例：旧 `controller-pending` socket 地址 106 字节、启动前 `listen EINVAL`；本机独立探针在 104 字节可绑定、105 字节返回 `EINVAL`。旧原始失败日志和完整论证仍在 `../maintenance-dispose-investigation/`，本次 [inputs.json](inputs.json) 记录旧日志 SHA-256、旧/新测试文件 SHA-256、Node/pnpm/Vitest 与系统版本。修复没有改变 EC3 S-59、HT3 S-20 或装配的真实收场判据。

## 验收逐项结果

| 项 | 实际结果与证据 |
| --- | --- |
| F1：同环境四例 4/4 | **通过。** macOS 27.0 arm64、Node 24.21.0、pnpm 10.28.1、Vitest 4.1.11、`TMPDIR=/private/tmp`。`fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host exec vitest run tests/maintenance-dispose.process.spec.ts` 退出 0，1 文件、4 测试全通过；原始 [single.log](runs/single.log)。 |
| F2：局部格式、host 类型 | **通过。** `pnpm format:write -- apps/tenancy-host/tests/maintenance-dispose.process.spec.ts` 输出 unchanged；同文件 `format:check` 退出 0；`@omne-harness-lite/tenancy-host` 的 `typecheck` 退出 0。原始 [format.log](runs/format.log)、[typecheck.log](runs/typecheck.log)。 |
| F3：一次默认并发完整 host | **运行但未通过。** `pnpm --filter @omne-harness-lite/tenancy-host run test` 退出 1，15 文件为 13 通过、1 失败、1 跳过；198 测试为 150 通过、37 失败、11 跳过。37 个失败全在 `tests/e2e/e2e.spec.ts`，逐项名称见 [host-failures.txt](host-failures.txt)，每项堆栈和原始输出见 [host.log](runs/host.log)。本次改动的 `maintenance-dispose.process.spec.ts` 在完整运行中也通过。`OMNE_TEST_PG_URL` 未设，PG 延期组的跳过仍是跳过，不能报成通过。 |
| F4：范围与旧证据 | **通过。** `git diff-tree` 仅列指定测试文件，提交无额外 trailer，`git show --check` 退出 0，提交后 `git status --porcelain` 为空；旧诊断的失败日志可读且 SHA-256 与本次输入记录一致。新证据只写 `tmp/maintenance-dispose-fix/`。 |

各命令的 UTC 起止、退出码、环境、日志哈希和测试汇总见 [runs.json](runs.json)。`run.sh` 保留可复跑入口；测试前已有同一基线的冻结安装和宿主依赖构建，具体命令见旧诊断报告。

## 完整 host 失败的边界

默认并发全量中的首个 e2e 客户端体检失败为 `unreachable (request not sent (UNSPECIFIED))`，此后许多旅程依赖前一步注册/登录而连续失败。运行中心的独立 e2e 证据显示 `serving` 日志已出现，未能据此确定 TLS 请求没有发出的底层原因。为区分跨文件并发，将 e2e 文件单独运行一次并将其可遮蔽证据写入 [e2e-evidence](e2e-evidence/)；仍是 37 失败、9 通过，首个体检仍为相同的 `UNSPECIFIED`。这说明跨文件并发不是该失败出现的必要条件，不证明其它并发性质。

派发者指出此前 HUB 的 macOS 完整命令带 `OMNE_TEST_ALTERNATE_SOURCE_ADDRESS=10.0.0.251`。按 [e2e README](../../apps/tenancy-host/tests/e2e/README.md) 的要求只读核对本机地址：[network-check.json](network-check.json) 中该地址 `assigned=false`，现有 IPv4 为 `127.0.0.1`、`172.30.251.81`、`198.18.0.1`，到 `10.0.0.251` 的路由经网关。当前不能以该值充当本机第二来源地址，故未冒用该环境重跑，也未改系统网络。此次未设该变量与旧 HUB 环境不完全同条件；但它本身不能解释在使用默认来源地址的首个 TLS 请求上看到的 `UNSPECIFIED`，该底层原因仍未归因。F3 保留失败，不作全套通过声明，也不在本任务改 e2e 或放宽判据。

端到端证据自检扫描 40 个文件、44 个秘密样本的五种形式，报告 `hits: 0`。有意设置 `OMNE_E2E_EVIDENCE_DIR` 后，测试不会自动删除其临时部署根；本任务已用 [cleanup-e2e.json](cleanup-e2e.json) 核对并删除唯一属于本次复跑的 `/private/tmp/omne-e2e-suite-*` 根。其余测试进程均有退出码，未删除他人进程或容器。未推送或合并；独立复核与最终接受仍归主线。
