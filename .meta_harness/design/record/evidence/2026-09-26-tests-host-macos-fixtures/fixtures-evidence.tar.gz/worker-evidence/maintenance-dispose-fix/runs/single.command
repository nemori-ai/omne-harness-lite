fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host exec vitest run tests/maintenance-dispose.process.spec.ts 
