import { existsSync, readFileSync } from 'node:fs'
import { rm } from 'node:fs/promises'

const commands = readFileSync('tmp/maintenance-dispose-fix/e2e-evidence/commands/commands.txt', 'utf8')
const roots = [...new Set(commands.match(/\/private\/tmp\/omne-e2e-suite-[A-Za-z0-9]{6}/g) ?? [])]
if (roots.length !== 1) throw new Error(`expected one owned e2e root, found ${roots.length}`)
const [root] = roots
const existedBefore = existsSync(root)
await rm(root, { recursive: true, force: true })
const remains = existsSync(root)
console.log(JSON.stringify({ root, existedBefore, remains }, null, 2))
if (remains) process.exitCode = 1
