import { execFileSync } from 'node:child_process'

const requestedAddress = '10.0.0.251'
const lines = execFileSync('ifconfig', { encoding: 'utf8' }).split('\n')
const addresses = []
let interfaceName = ''
for (const line of lines) {
  if (line.length > 0 && !/^\s/.test(line)) interfaceName = line.split(':')[0] ?? ''
  const ipv4 = line.match(/^\s+inet (\d+\.\d+\.\d+\.\d+)/)?.[1]
  if (ipv4 !== undefined) addresses.push({ interface: interfaceName, address: ipv4 })
}
const route = execFileSync('route', ['-n', 'get', requestedAddress], { encoding: 'utf8' }).trim()
console.log(JSON.stringify({ requestedAddress, assigned: addresses.some(item => item.address === requestedAddress), addresses, route }, null, 2))
