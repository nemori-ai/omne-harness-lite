#!/usr/bin/env bash
set -euo pipefail

expected_root=/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-dispose-probe
if [[ "$PWD" != "$expected_root" ]] || [[ "$(git branch --show-current)" != pandazki/agent-work-loop-dispose-probe ]]; then
  printf 'wrong checkout or branch\n' >&2
  exit 64
fi
kind=${1:?single, format, typecheck, host, or e2e required}
case "$kind" in
  single)
    command=(fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host exec vitest run tests/maintenance-dispose.process.spec.ts)
    ;;
  format)
    command=(fnm exec --using=24.21.0 -- pnpm format:check -- apps/tenancy-host/tests/maintenance-dispose.process.spec.ts)
    ;;
  typecheck)
    command=(fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host run typecheck)
    ;;
  host)
    command=(fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host run test)
    ;;
  e2e)
    command=(env OMNE_E2E_EVIDENCE_DIR="$PWD/tmp/maintenance-dispose-fix/e2e-evidence" fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host exec vitest run tests/e2e/e2e.spec.ts)
    ;;
  *) printf 'invalid kind\n' >&2; exit 64 ;;
esac
out="tmp/maintenance-dispose-fix/runs/${kind}"
if [[ -e "${out}.log" ]]; then
  printf 'run already exists: %s\n' "$out" >&2
  exit 64
fi
export TMPDIR=/private/tmp
printf '%q ' "${command[@]}" > "${out}.command"
printf '\n' >> "${out}.command"
date -u +%Y-%m-%dT%H:%M:%SZ > "${out}.start"
set +e
"${command[@]}" > "${out}.log" 2>&1
status=$?
set -e
date -u +%Y-%m-%dT%H:%M:%SZ > "${out}.end"
printf '%s\n' "$status" > "${out}.exit"
printf '%s exit=%s log=%s\n' "$kind" "$status" "${out}.log"
exit "$status"
