fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host run typecheck 
