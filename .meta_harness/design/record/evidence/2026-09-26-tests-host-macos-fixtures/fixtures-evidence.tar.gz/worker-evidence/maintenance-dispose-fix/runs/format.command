fnm exec --using=24.21.0 -- pnpm format:check -- apps/tenancy-host/tests/maintenance-dispose.process.spec.ts 
