import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const root = 'tmp/maintenance-dispose-fix'
const target = 'apps/tenancy-host/tests/maintenance-dispose.process.spec.ts'
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const command = (name, args = []) => execFileSync(name, args, { encoding: 'utf8' }).trim()
const baseSource = execFileSync('git', ['show', `2cb236db:${target}`])
const inputs = {
  checkout: process.cwd(),
  branch: command('git', ['branch', '--show-current']),
  baseHead: '2cb236db7da15e78bb1e96dd8220ee68b6eceb75',
  currentHead: command('git', ['rev-parse', 'HEAD']),
  changedTrackedPaths: command('git', ['diff', '--name-only']).split('\n').filter(Boolean),
  target,
  targetBeforeSha256: sha(baseSource),
  targetAfterSha256: sha(readFileSync(target)),
  originalFailureLogSha256: sha(readFileSync('tmp/maintenance-dispose-investigation/runs/single-1.log')),
  originalDiagnosisReportSha256: sha(readFileSync('tmp/maintenance-dispose-investigation/report.md')),
  platform: process.platform,
  architecture: process.arch,
  macOS: command('sw_vers', ['-productVersion']),
  node: process.version,
  pnpm: command('pnpm', ['--version']),
  vitest: JSON.parse(readFileSync('apps/tenancy-host/node_modules/vitest/package.json')).version,
  testTmpdir: '/private/tmp',
  alternateSourceAddress: null,
  alternateSourceCheck: JSON.parse(readFileSync(join(root, 'network-check.json'))),
}
writeFileSync(join(root, 'inputs.json'), JSON.stringify(inputs, null, 2) + '\n')

const runs = readdirSync(join(root, 'runs'))
  .filter(name => name.endsWith('.exit'))
  .sort()
  .map(name => {
    const stem = name.slice(0, -5)
    const prefix = join(root, 'runs', stem)
    const log = readFileSync(`${prefix}.log`, 'utf8')
    return {
      id: stem,
      command: readFileSync(`${prefix}.command`, 'utf8').trim(),
      startUtc: readFileSync(`${prefix}.start`, 'utf8').trim(),
      endUtc: readFileSync(`${prefix}.end`, 'utf8').trim(),
      exitCode: Number(readFileSync(`${prefix}.exit`, 'utf8').trim()),
      tmpdir: '/private/tmp',
      logPath: `${prefix}.log`,
      logSha256: sha(log),
      summary: log.match(/Test Files[^\n]*\n\s*Tests[^\n]*/)?.[0] ?? null,
    }
  })
const evidence = {
  runs,
  hostFailuresPath: join(root, 'host-failures.txt'),
  hostFailuresCount: readFileSync(join(root, 'host-failures.txt'), 'utf8').trim().split('\n').length,
  hostFailuresSha256: sha(readFileSync(join(root, 'host-failures.txt'))),
  networkCheckPath: join(root, 'network-check.json'),
  networkCheckSha256: sha(readFileSync(join(root, 'network-check.json'))),
  cleanupPath: join(root, 'cleanup-e2e.json'),
  cleanupSha256: sha(readFileSync(join(root, 'cleanup-e2e.json'))),
  preservedOriginalFailure: true,
}
writeFileSync(join(root, 'runs.json'), JSON.stringify(evidence, null, 2) + '\n')
