#!/usr/bin/env bash
set -euo pipefail

expected_root=/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-dispose-probe
if [[ "$PWD" != "$expected_root" ]] || [[ "$(git branch --show-current)" != pandazki/agent-work-loop-dispose-probe ]]; then
  printf 'wrong checkout or branch\n' >&2
  exit 64
fi
out=tmp/maintenance-e2e-openssl3/host
if [[ -e "${out}.log" ]]; then
  printf 'host run already exists\n' >&2
  exit 64
fi
export PATH="/opt/homebrew/opt/openssl@3/bin:$PATH"
export TMPDIR=/private/tmp
export OMNE_TEST_ALTERNATE_SOURCE_ADDRESS=10.18.100.75
unset OMNE_E2E_EVIDENCE_DIR OMNE_E2E_KEEP OMNE_E2E_SECRETS_OUT
fnm exec --using=24.21.0 -- node tmp/maintenance-e2e-openssl3/preflight.mjs > tmp/maintenance-e2e-openssl3/preflight-at-run.json
command=(fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host run test)
printf '%q ' "${command[@]}" > "${out}.command"
printf '\n' >> "${out}.command"
date -u +%Y-%m-%dT%H:%M:%SZ > "${out}.start"
set +e
"${command[@]}" > "${out}.log" 2>&1
status=$?
set -e
date -u +%Y-%m-%dT%H:%M:%SZ > "${out}.end"
printf '%s\n' "$status" > "${out}.exit"
printf 'host exit=%s log=%s\n' "$status" "${out}.log"
exit "$status"
