import { execFileSync, spawnSync } from 'node:child_process'
import { realpathSync } from 'node:fs'

const resolved = execFileSync('sh', ['-c', 'command -v openssl'], { encoding: 'utf8' }).trim()
const actual = realpathSync(resolved)
const version = execFileSync('openssl', ['version'], { encoding: 'utf8' }).trim()
const help = spawnSync('openssl', ['s_client', '-help'], { encoding: 'utf8' })
const helpText = `${help.stdout ?? ''}\n${help.stderr ?? ''}`
const hostnameOption = helpText.split('\n').find(line => line.includes('-verify_hostname')) ?? null
const addresses = [...execFileSync('ifconfig', { encoding: 'utf8' }).matchAll(/^\s+inet (\d+\.\d+\.\d+\.\d+)/gm)].map(match => match[1])
const candidateSource = '10.18.100.75'
const result = {
  node: process.version,
  nodeOpenSsl: process.versions.openssl,
  opensslCommand: resolved,
  opensslRealpath: actual,
  opensslVersion: version,
  hostnameOption,
  supportsVerifyHostname: hostnameOption !== null,
  candidateSource,
  candidateSourceAssigned: addresses.includes(candidateSource),
  tmpdir: process.env.TMPDIR ?? null,
}
console.log(JSON.stringify(result, null, 2))
if (resolved !== '/opt/homebrew/opt/openssl@3/bin/openssl' || !result.supportsVerifyHostname || !result.candidateSourceAssigned) process.exitCode = 1
