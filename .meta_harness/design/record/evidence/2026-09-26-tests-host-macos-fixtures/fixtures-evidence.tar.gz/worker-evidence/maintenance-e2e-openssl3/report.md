# M0-V1e：显式 OpenSSL 3 工具链下的 host 验证

在隔离工作树 `/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-dispose-probe`，分支 `pandazki/agent-work-loop-dispose-probe`、HEAD `818a7163e00f2f28b5a4fb7b6407c165ff07ed04` 上完成。本轮只运行工具和检查，没有修改 tracked 文件、提交、推送或合并；`git status --porcelain` 为空。源码及锁文件 SHA-256 见 [inputs.json](inputs.json)。V1d 在系统 LibreSSL 下的 [原失败日志](../maintenance-e2e-fix/runs/host.log)与 V1c 的显式 ECC 原反例均保留。

先用子进程 `PATH` 将 `/opt/homebrew/opt/openssl@3/bin` 置前。测试前和完整运行紧前的 [preflight-at-run.json](preflight-at-run.json) 均证实实际解析到 `/opt/homebrew/opt/openssl@3/bin/openssl`（realpath 为 `/opt/homebrew/Cellar/openssl@3/3.6.3/bin/openssl`）、版本 `OpenSSL 3.6.3`，其 `s_client -help` 明列 `-verify_hostname val`。Node 为 24.21.0，内置 OpenSSL 3.5.8；pnpm 10.28.1，Vitest 4.1.11，macOS 27.0 arm64。这里只调整测试子进程环境，没有变更系统 OpenSSL、PATH 配置或网络设置。

当前合法第二来源 `10.18.100.75` 在运行前仍已分配。用同一 OpenSSL 3 工具链再次执行既有 [来源地址探针](source-address-probe.log)：从该地址连接回环 `127.0.0.1`，得到 `peerAuthorized=true`、`TLSv1.3`、`requestWritten=true`、`error=null`；探针清理了自己的临时证书目录。其结果只支持此时本机测试的来源地址前提。

随后以 `TMPDIR=/private/tmp`、`OMNE_TEST_ALTERNATE_SOURCE_ADDRESS=10.18.100.75` 和上述子进程 `PATH` 执行一次完整 `@omne-harness-lite/tenancy-host` 默认并发测试。**退出码 0：14 个文件通过、1 个文件跳过；187 项测试通过、11 项跳过；类型错误 0。**[host.log](host.log) 为原始输出；[runs.json](runs.json) 给出实际命令、环境选择、UTC 起止、退出码与原始日志 SHA-256。之前 LibreSSL 的 `s_client -verify_hostname` 不支持错误，在此精确工具前提下未再出现。

跳过项保持原状态，尤其 PG 延期装配没有实际验证；本轮通过只适用于上述 commit、Node/OpenSSL、macOS、本机第二来源和 host 测试范围，不等于整仓、Linux/systemd 或生产部署验收。V1d 的局部格式与 host 类型检查已针对同一源码提交通过，本轮源码未变，故没有重复运行。旧失败和本次通过分别保留其工具链前提，不能把前者改标成功，也不能将后者外推到缺少 `-verify_hostname` 的 LibreSSL CLI 环境。
