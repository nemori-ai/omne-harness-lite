import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const root = 'tmp/maintenance-e2e-openssl3'
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const command = (name, args = []) => execFileSync(name, args, { encoding: 'utf8' }).trim()
const sourcePaths = [
  'apps/tenancy-host/tests/e2e/deploy.ts',
  'apps/tenancy-host/tests/e2e/client.ts',
  'apps/tenancy-host/tests/e2e/e2e.spec.ts',
  'pnpm-lock.yaml',
]
const preflight = JSON.parse(readFileSync(join(root, 'preflight-at-run.json'), 'utf8'))
const inputs = {
  checkout: process.cwd(),
  branch: command('git', ['branch', '--show-current']),
  head: command('git', ['rev-parse', 'HEAD']),
  trackedStatus: command('git', ['status', '--porcelain']),
  platform: process.platform,
  architecture: process.arch,
  macOS: command('sw_vers', ['-productVersion']),
  node: process.version,
  pnpm: command('pnpm', ['--version']),
  vitest: JSON.parse(readFileSync('apps/tenancy-host/node_modules/vitest/package.json')).version,
  sourceSha256: Object.fromEntries(sourcePaths.map(path => [path, sha(readFileSync(path))])),
  priorLibreSslFailureSha256: sha(readFileSync('tmp/maintenance-e2e-fix/runs/host.log')),
  priorExplicitEccFailureSha256: sha(readFileSync('tmp/maintenance-e2e-diagnosis/probe-1.log')),
  preflightAtRun: preflight,
  pgUrlSetAtEvidenceCapture: process.env.OMNE_TEST_PG_URL !== undefined,
}
writeFileSync(join(root, 'inputs.json'), JSON.stringify(inputs, null, 2) + '\n')

const log = readFileSync(join(root, 'host.log'), 'utf8')
const runs = {
  host: {
    command: readFileSync(join(root, 'host.command'), 'utf8').trim(),
    environment: {
      opensslPathPrefix: '/opt/homebrew/opt/openssl@3/bin',
      tmpdir: '/private/tmp',
      alternateSource: '10.18.100.75',
      e2eEvidenceDirSet: false,
    },
    startUtc: readFileSync(join(root, 'host.start'), 'utf8').trim(),
    endUtc: readFileSync(join(root, 'host.end'), 'utf8').trim(),
    exitCode: Number(readFileSync(join(root, 'host.exit'), 'utf8').trim()),
    logPath: join(root, 'host.log'),
    logSha256: sha(log),
    summary: log.match(/Test Files[^\n]*\n\s*Tests[^\n]*\n\s*Type Errors[^\n]*/)?.[0] ?? null,
  },
  preflightAtRun: {
    command: 'PATH=/opt/homebrew/opt/openssl@3/bin:$PATH TMPDIR=/private/tmp fnm exec --using=24.21.0 -- node tmp/maintenance-e2e-openssl3/preflight.mjs',
    path: join(root, 'preflight-at-run.json'),
    sha256: sha(readFileSync(join(root, 'preflight-at-run.json'))),
  },
  sourceAddressProbe: {
    command: 'PATH=/opt/homebrew/opt/openssl@3/bin:$PATH TMPDIR=/private/tmp fnm exec --using=24.21.0 -- node --experimental-transform-types --no-warnings tmp/maintenance-e2e-fix/source-address-probe.mjs 10.18.100.75',
    path: join(root, 'source-address-probe.log'),
    sha256: sha(readFileSync(join(root, 'source-address-probe.log'))),
    result: JSON.parse(readFileSync(join(root, 'source-address-probe.log'), 'utf8')),
  },
  sourceProbeScratchRemaining: readdirSync('/private/tmp').filter(name => name.startsWith('omne-e2e-source-probe-')),
}
writeFileSync(join(root, 'runs.json'), JSON.stringify(runs, null, 2) + '\n')
