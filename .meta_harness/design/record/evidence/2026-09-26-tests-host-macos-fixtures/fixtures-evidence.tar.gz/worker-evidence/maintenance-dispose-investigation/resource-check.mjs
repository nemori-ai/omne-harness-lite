import { existsSync, readFileSync } from 'node:fs'

const evidence = 'tmp/maintenance-dispose-investigation'
const casePaths = readFileSync(`${evidence}/case-paths.log`, 'utf8').trim().split('\n').map(line => JSON.parse(line).socketPath)
const shortPath = JSON.parse(readFileSync(`${evidence}/short-path-control.log`, 'utf8')).socketPath
const originalLog = readFileSync(`${evidence}/runs/single-1.log`, 'utf8')
const failedPath = originalLog.match(/listen EINVAL: invalid argument ([^\n\\]+)/)?.[1]
if (failedPath === undefined) throw new Error('failed socket address missing')
const roots = [...casePaths, shortPath, failedPath].map(path => path.slice(0, path.lastIndexOf('/ops-')))
const results = roots.map(root => ({ root, remains: existsSync(root) }))
console.log(JSON.stringify(results, null, 2))
if (results.some(result => result.remains)) process.exitCode = 1
