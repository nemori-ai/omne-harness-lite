import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { once } from 'node:events'
import { rm } from 'node:fs/promises'
import { createInterface } from 'node:readline'
import { fileURLToPath } from 'node:url'
import { deployment } from '../../apps/tenancy-host/tests/support/deployment.ts'

const d = await deployment('md-cp')
const child = spawn(
  process.execPath,
  [
    '--experimental-transform-types',
    '--no-warnings',
    fileURLToPath(new URL('../../apps/tenancy-host/tests/fixtures/maintenance-dispose-child.ts', import.meta.url)),
    'controller-pending',
  ],
  { env: { ...process.env, ...d.env }, stdio: ['pipe', 'pipe', 'pipe'] },
)
let stderr = ''
child.stderr.setEncoding('utf8').on('data', chunk => { stderr += chunk })
const exited = once(child, 'exit')
const timeout = setTimeout(() => child.kill('SIGKILL'), 20_000)
const reader = createInterface({ input: child.stdout })
const lines = reader[Symbol.asyncIterator]()
try {
  const ready = JSON.parse((await lines.next()).value ?? '{}')
  assert.deepEqual(ready, { stage: 'ready' })
  child.stdin.write('dispose\n')
  const disposed = JSON.parse((await lines.next()).value ?? '{}')
  assert.deepEqual(disposed, {
    stage: 'disposed',
    result: { complete: false, unfinished: ['governance-center-ops'] },
  })
  child.stdin.write('exit\n')
  const [exitCode] = await exited
  assert.equal(exitCode, 1)
  console.log(JSON.stringify({
    socketPath: d.socketPath,
    socketPathBytes: Buffer.byteLength(d.socketPath),
    ready,
    disposed,
    exitCode,
  }, null, 2))
} catch (error) {
  console.error(error)
  console.error(stderr)
  process.exitCode = 1
} finally {
  clearTimeout(timeout)
  if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL')
  await exited
  reader.close()
  await rm(d.root, { recursive: true, force: true })
}
