# maintenance-dispose `controller-pending` macOS 诊断

## 结论与范围

在指定隔离检出 `2cb236db`、macOS 27.0 arm64、Node 24.21.0、pnpm 10.28.1、Vitest 4.1.11、`TMPDIR=/private/tmp` 下，单文件第 1 次运行即复现原日志点名的失败。根因是现有测试部署名拼出的 Unix socket 地址为 **106 字节**，超过本机 Node/macOS 实测可绑定的 **104 字节**；`listen` 返回 `EINVAL`，子进程在发出 `ready` 前启动失败。当前反例没有运行到 `host.dispose()`，因此不能据此认定产品的 pending 收场判定失败。

把同一个 `controller-pending` 子进程夹具放在 73 字节的套接字路径下，未改动产品源码、测试或故障注入，即观察到 `ready`、`{complete:false,unfinished:['governance-center-ops']}`、退出码 1。这是对“本次红测源于收场逻辑给出假成功”的反证；它只覆盖这一次路径控制下的场景。上游 Linux 通过与原 macOS 全量日志均不能单独给出原运行的完整断言链：原日志只有失败测试名，随后全量被 SIGTERM 暂停。本机复现和对照解释了同一失败名在当前输入下的直接原因。

## 输入与契约判据（Q1）

- 执行工作树：`/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-dispose-probe`，分支 `pandazki/agent-work-loop-dispose-probe`，HEAD `2cb236db7da15e78bb1e96dd8220ee68b6eceb75`。起始与结束的 tracked Git 状态均为空。
- 精确输入、外部任务书及原日志 SHA-256、工具版本见 [inputs.json](inputs.json)。EC3 `contract.md` SHA-256 为 `8c638900033558faffb077a4a67d34be51c94c580c171745533eb4c8a73aae19`，HT3 为 `1836b2ba0a08ed03d28d98617cf5ca8d35ac6619863ab9cbf2b8d347df02c91a`，与 D055 决定列出的受审哈希一致。规范正文保留 candidate 字样；本诊断消费 D055 对其采用的范围及 D056 的资源责任决定，不将候选字样自行改写。
- EC3 S-59 要求在线维护源属主及资源真实结束后才能释放，HT3 S-20 指定运维面为配置目录下的 `governance-center-ops.sock`。D055 与装配 `maintenance-binding.md` 进一步要求 controller/storage 两观察槽保持 pending、error 或 residual 时，`HostDisposal.complete` 不得为 true；Cordis 吞掉 disposer 异常不解除该义务。本测试的独立可观察判据是子进程先发 `ready`，执行 `dispose` 后返回 `complete:false` 且点名 `governance-center-ops`，最后以 1 退出。
- 准备命令：`fnm exec --using=24.21.0 -- pnpm install --frozen-lockfile --ignore-scripts`；`fnm exec --using=24.21.0 -- pnpm --filter '@omne-harness-lite/tenancy-host...' run build`。二者退出 0。只产生本工作树的 `node_modules`、所需 `dist`/`tsbuildinfo`。

## 运行与因果核对（Q2）

测试尝试预算为单文件最多 5 次；若未复现，宿主正常并发设置最多 3 次。本次单文件 **1/1 次复现**，四例中仅 `controller-pending` 失败，其余三例通过，因此未触发宿主整包并发运行分支，也未耗尽预算。实际命令、起止 UTC、退出码、原始日志 SHA-256 在 [runs.json](runs.json)；原始完整输出在 [runs/single-1.log](runs/single-1.log)。运行器为 [run.sh](run.sh)，命令是 `TMPDIR=/private/tmp` 环境下的 `fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host exec vitest run tests/maintenance-dispose.process.spec.ts`，退出码 1。

原始错误链为 `listen EINVAL: invalid argument <106-byte socket path>` → `OpsSocketError(unusable)` → `HostStartupFailure(stage='plugin',item='governance-center-ops')`。测试第一断言期待 `{stage:'ready'}`，实际读到 EOF 后的 `{}`；它没有到达 `dispose` 交互。启动失败时的日志反而记录 `dispose-incomplete`，controller=`pending`、storage=`clean`，未见假完成。

| 故障名 | 实测套接字路径字节数 | 单文件结果 |
| --- | ---: | --- |
| `controller-error` | 104 | 通过 |
| `storage-error` | 101 | 通过 |
| `controller-pending` | 106 | 启动前 `EINVAL`，失败 |
| `storage-pending` | 103 | 通过 |

上述长度由未改动的 `deployment()` 实际生成路径后量取，见 [case-paths.log](case-paths.log)。[socket-length-probe.mjs](socket-length-probe.mjs) 经 `node:net.createServer().listen()` 直接在本机验证 96、100、103、104 字节均可绑定，105、106、108、110、120 字节均返回 `EINVAL`；正反控制及原始结果见 [socket-length.log](socket-length.log)。这说明测量工具能检出越界失败，不能把所有路径一律报成失败或成功。这里报告的是此 Node/macOS 环境的实测边界，不外推所有平台或文件系统。

[short-path-control.mjs](short-path-control.mjs) 只将部署名换成 `md-cp`，复用原 `maintenance-dispose-child.ts`、原 `controller-pending` 注入以及真实 `boot()`/`dispose()`；它逐项断言 `ready`、未完成结果和进程退出码 1。路径 73 字节，控制脚本退出 0，原始结果见 [short-path-control.log](short-path-control.log)。脚本未在夹具中补造产品行为。

## 假设台账与建议（Q3、Q4）

| 假设 | 证据与判断 |
| --- | --- |
| 产品收场逻辑把 controller pending 误判为成功 | 本次红测未到 `dispose`；短路径控制实际得到 `complete:false`。此假设不能解释本次失败。不能由单次控制推出所有收场交错均正确。 |
| 测试夹具构造了本机不可绑定的套接字地址 | 测试用 `maintenance-dispose-${fault}` 作 `mkdtemp` 前缀，再叠加 `ops-XXXXXX/governance-center-ops.sock`；仅最长的 `controller-pending` 成为 106 字节。长度探针给出 104/105 字节分界，短路径同故障注入通过。此为本次直接根因。 |
| 环境或资源竞争 | macOS 路径长度是必要环境条件；错误为 `EINVAL` 而非 `EADDRINUSE`，每例独立随机目录。短路径同机同环境成功，资源争用没有解释力。未实测其它机器或整包高并发下的独立问题。 |

建议由测试拥有者在 `apps/tenancy-host/tests/maintenance-dispose.process.spec.ts` 中给四例使用简短部署标签，例如映射为 `md-ce/md-se/md-cp/md-sp`；随机 `mkdtemp` 后缀继续隔离各例。最小反驳点是 macOS/Node 24.21.0、`TMPDIR=/private/tmp` 下原单文件应四例全通过，且 `controller-pending` 必须真正发出 `ready`，随后仍断言 `complete:false`、具名 `unfinished` 与退出码 1。测试可在生成路径后报告其 UTF-8 字节数以便再遇到平台路径上界时直接定位。生产 socket 目录的权限、归属与绑定检查不应放宽。本任务无源码写权限，建议未执行，也不宣称测试已修复。

## 资源、验证与未覆盖（Q5）

- [resource-check.log](resource-check.log) 核对本次运行和探针生成的六个测试部署根目录均已移除。`run.sh` 的 Vitest 进程已退出；短路径控制显式等待子进程退出，并在 `finally` 清理临时目录；长度探针也在 `finally` 清理。未操作他人进程或容器。
- `bash -n run.sh` 和本次五个 `.mjs` 的 `node --check` 均退出 0。诊断脚本只在获准的 `tmp/maintenance-dispose-investigation/`，没有修改已有源码、测试、规范、锁文件；没有提交或推送。临时目录不在共享 Prettier 的受维护范围。
- 覆盖范围是本机单文件一次、同夹具短路径一次、四个夹具路径样本、九个独立 socket 长度样本。没有整包并发重跑、Linux重跑、真实 systemd、生产部署或其它 controller/storage 竞态验收；当前结果不代替独立评审或主线最终接受。
