import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { basename, join } from 'node:path'

const evidence = 'tmp/maintenance-dispose-investigation'
const sourcePaths = [
  'package.json',
  'pnpm-lock.yaml',
  '.meta_harness/design/spec/compositions/governance-center-entry/v3/contract.md',
  '.meta_harness/design/spec/compositions/governance-center-entry-https-json/v3/contract.md',
  '.meta_harness/design/record/decisions/governance-online-maintenance-adoption/decision.md',
  '.meta_harness/design/record/decisions/governance-maintenance-resources-adoption/decision.md',
  '.meta_harness/design/record/decisions/governance-conformance-runner-adoption/decision.md',
  '.meta_harness/design/realization/apps/tenancy-host/maintenance-binding.md',
  'apps/tenancy-host/src/boot.ts',
  'apps/tenancy-host/src/maintenance-state.ts',
  'apps/tenancy-host/tests/maintenance-dispose.process.spec.ts',
  'apps/tenancy-host/tests/fixtures/maintenance-dispose-child.ts',
  'apps/tenancy-host/tests/support/deployment.ts',
  'packages/tenancy/governance-center-entry/src/ops/socket.ts',
]
const externalPaths = [
  '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/tmp/next-iteration/tasks/dispose-probe.md',
  '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/tmp/governance-rebase/runtime-check-r2.log',
]
const sha256 = path => createHash('sha256').update(readFileSync(path)).digest('hex')
const command = (name, args = []) => execFileSync(name, args, { encoding: 'utf8' }).trim()
const inputs = {
  checkout: process.cwd(),
  branch: command('git', ['branch', '--show-current']),
  head: command('git', ['rev-parse', 'HEAD']),
  trackedStatus: command('git', ['status', '--porcelain']),
  platform: process.platform,
  architecture: process.arch,
  macOS: command('sw_vers', ['-productVersion']),
  node: process.version,
  pnpm: command('pnpm', ['--version']),
  fnm: command('fnm', ['--version']),
  vitest: JSON.parse(readFileSync('apps/tenancy-host/node_modules/vitest/package.json')).version,
  tmpdir: process.env.TMPDIR,
  sourceSha256: Object.fromEntries(sourcePaths.map(path => [path, sha256(path)])),
  externalSha256: Object.fromEntries(externalPaths.map(path => [path, sha256(path)])),
}
writeFileSync(join(evidence, 'inputs.json'), JSON.stringify(inputs, null, 2) + '\n')

const runsDirectory = join(evidence, 'runs')
const attempts = readdirSync(runsDirectory)
  .filter(name => name.endsWith('.exit'))
  .sort()
  .map(name => {
    const stem = name.slice(0, -'.exit'.length)
    const logPath = join(runsDirectory, `${stem}.log`)
    const log = readFileSync(logPath, 'utf8')
    const address = log.match(/listen EINVAL: invalid argument ([^\n\\]+)/)?.[1] ?? null
    return {
      id: stem,
      command: readFileSync(join(runsDirectory, `${stem}.command`), 'utf8').trim(),
      startUtc: readFileSync(join(runsDirectory, `${stem}.start`), 'utf8').trim(),
      endUtc: readFileSync(join(runsDirectory, `${stem}.end`), 'utf8').trim(),
      tmpdir: '/private/tmp',
      exitCode: Number(readFileSync(join(runsDirectory, `${stem}.exit`), 'utf8').trim()),
      logPath,
      logSha256: sha256(logPath),
      failedTests: [...log.matchAll(/× observes ([^\n]+?) despite Cordis/g)].map(match => match[1]),
      socketError: address === null ? null : { code: 'EINVAL', address, bytes: Buffer.byteLength(address) },
    }
  })
const diagnostics = [
  {
    id: 'socket-length',
    command: 'fnm exec --using=24.21.0 -- node tmp/maintenance-dispose-investigation/socket-length-probe.mjs',
    logPath: join(evidence, 'socket-length.log'),
    parsed: JSON.parse(readFileSync(join(evidence, 'socket-length.log'), 'utf8')),
  },
  {
    id: 'case-paths',
    command: 'TMPDIR=/private/tmp fnm exec --using=24.21.0 -- node --experimental-transform-types --no-warnings tmp/maintenance-dispose-investigation/case-paths.mjs',
    logPath: join(evidence, 'case-paths.log'),
    parsed: readFileSync(join(evidence, 'case-paths.log'), 'utf8').trim().split('\n').map(line => JSON.parse(line)),
  },
  {
    id: 'short-path-control',
    command: 'TMPDIR=/private/tmp fnm exec --using=24.21.0 -- node --experimental-transform-types --no-warnings tmp/maintenance-dispose-investigation/short-path-control.mjs',
    logPath: join(evidence, 'short-path-control.log'),
    parsed: JSON.parse(readFileSync(join(evidence, 'short-path-control.log'), 'utf8')),
  },
  {
    id: 'resource-check',
    command: 'fnm exec --using=24.21.0 -- node tmp/maintenance-dispose-investigation/resource-check.mjs',
    logPath: join(evidence, 'resource-check.log'),
    parsed: JSON.parse(readFileSync(join(evidence, 'resource-check.log'), 'utf8')),
  },
].map(item => ({ ...item, logSha256: sha256(item.logPath) }))
const runs = {
  attemptBudget: { singleFileMaximum: 5, hostSuiteMaximumIfSingleFileDoesNotReproduce: 3 },
  attempts,
  diagnostics,
  scriptSha256: Object.fromEntries(
    ['run.sh', 'socket-length-probe.mjs', 'case-paths.mjs', 'short-path-control.mjs', 'resource-check.mjs', 'capture-evidence.mjs']
      .map(name => [basename(name), sha256(join(evidence, name))]),
  ),
}
writeFileSync(join(evidence, 'runs.json'), JSON.stringify(runs, null, 2) + '\n')
