#!/usr/bin/env bash
set -euo pipefail

expected_root=/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-dispose-probe
if [[ "$PWD" != "$expected_root" ]]; then
  printf 'wrong checkout: %s\n' "$PWD" >&2
  exit 64
fi
if [[ "$(git branch --show-current)" != pandazki/agent-work-loop-dispose-probe ]]; then
  printf 'wrong branch\n' >&2
  exit 64
fi
kind=${1:?single or host required}
number=${2:?attempt number required}
if [[ ! "$number" =~ ^[1-9][0-9]*$ ]]; then
  printf 'invalid attempt number\n' >&2
  exit 64
fi
case "$kind" in
  single)
    command=(fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host exec vitest run tests/maintenance-dispose.process.spec.ts)
    ;;
  host)
    command=(fnm exec --using=24.21.0 -- pnpm --filter @omne-harness-lite/tenancy-host run test)
    ;;
  *) printf 'invalid kind\n' >&2; exit 64 ;;
esac
out="tmp/maintenance-dispose-investigation/runs/${kind}-${number}"
if [[ -e "${out}.log" ]]; then
  printf 'attempt already exists: %s\n' "$out" >&2
  exit 64
fi
export TMPDIR=/private/tmp
printf '%q ' "${command[@]}" > "${out}.command"
printf '\n' >> "${out}.command"
date -u +%Y-%m-%dT%H:%M:%SZ > "${out}.start"
set +e
"${command[@]}" > "${out}.log" 2>&1
status=$?
set -e
date -u +%Y-%m-%dT%H:%M:%SZ > "${out}.end"
printf '%s\n' "$status" > "${out}.exit"
printf '%s %s exit=%s log=%s\n' "$kind" "$number" "$status" "${out}.log"
exit "$status"
