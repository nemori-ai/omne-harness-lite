import { rm } from 'node:fs/promises'
import { deployment } from '../../apps/tenancy-host/tests/support/deployment.ts'

for (const fault of ['controller-error', 'storage-error', 'controller-pending', 'storage-pending']) {
  const d = await deployment(`maintenance-dispose-${fault}`)
  try {
    console.log(JSON.stringify({ fault, socketPath: d.socketPath, socketPathBytes: Buffer.byteLength(d.socketPath) }))
  } finally {
    await rm(d.root, { recursive: true, force: true })
  }
}
