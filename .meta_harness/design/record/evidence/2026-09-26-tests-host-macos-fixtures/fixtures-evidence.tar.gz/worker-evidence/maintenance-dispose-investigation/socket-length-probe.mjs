import { mkdtemp, mkdir, rm } from 'node:fs/promises'
import { createServer } from 'node:net'
import { join } from 'node:path'

const root = await mkdtemp('/private/tmp/omne-sock-length-')
const lengths = [96, 100, 103, 104, 105, 106, 108, 110, 120]
const results = []
try {
  for (const requestedBytes of lengths) {
    const nameLength = requestedBytes - Buffer.byteLength(root) - 3 // /<name>/s
    if (nameLength < 1) throw new Error('probe root too long')
    const directory = join(root, 'x'.repeat(nameLength))
    const address = join(directory, 's')
    await mkdir(directory)
    const server = createServer()
    const outcome = await new Promise(resolve => {
      server.once('error', error => resolve({ ok: false, code: error.code }))
      server.once('listening', () => resolve({ ok: true }))
      server.listen(address)
    })
    if (outcome.ok) {
      await new Promise((resolve, reject) => server.close(error => (error ? reject(error) : resolve())))
    }
    results.push({ requestedBytes, actualBytes: Buffer.byteLength(address), ...outcome })
  }
} finally {
  await rm(root, { recursive: true, force: true })
}
console.log(JSON.stringify({ platform: process.platform, node: process.version, results }, null, 2))
if (!results.some(result => result.ok) || !results.some(result => !result.ok)) process.exitCode = 1
