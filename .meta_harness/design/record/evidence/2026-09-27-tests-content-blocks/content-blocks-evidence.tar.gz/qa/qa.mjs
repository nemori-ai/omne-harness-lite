import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import {
  capabilityIdEquals,
  isCanonicalMediaType,
  judgeContentBlock,
  modalityOf,
  readJsonStrict,
  writeJsonLossless,
} from '@omne-harness-lite/content-blocks'
import { Ajv2020 } from 'ajv/dist/2020.js'

const require = createRequire(import.meta.url)
const schema = require('@omne-harness-lite/content-blocks/schema')
const frozenSchema = readFileSync(
  new URL('../../.meta_harness/design/spec/data/content-blocks/v2/content-blocks.schema.json', import.meta.url),
)
const packageSchema = readFileSync(
  new URL('../../packages/core/content-blocks/schema/content-blocks.schema.json', import.meta.url),
)
const examples = readFileSync(
  new URL('../../.meta_harness/design/spec/data/content-blocks/v2/examples.md', import.meta.url),
  'utf8',
)
const visibility = { toHuman: true, toModel: true }
const base = { id: 'b0', visibility }
const attachment = { storage: 'attachments', key: 'item', mediaType: 'image/png' }
let passed = 0
const failures = []

function check(name, run) {
  try {
    run()
    passed += 1
    console.log(`PASS ${name}`)
  } catch (error) {
    failures.push(name)
    console.error(`FAIL ${name}: ${error.stack ?? error}`)
  }
}

function parsed(text) {
  const result = readJsonStrict(text)
  assert.ok('ok' in result, `${text}: ${JSON.stringify(result)}`)
  return result.ok
}

function accepted(value) {
  const result = judgeContentBlock(value)
  assert.ok('ok' in result, JSON.stringify(result))
  return result.ok
}

function rejected(value, expected) {
  assert.deepEqual(judgeContentBlock(value), { rejected: expected })
}

function number(source) {
  return parsed(source)
}

function ref(bytes, mediaType = 'image/png') {
  return { ...attachment, mediaType, bytes }
}

function textBlock(id = 'b0') {
  return { id, kind: 'text', visibility: { ...visibility }, text: 'hello' }
}

function resultBlock(blocks = [], other = {}) {
  return {
    ...base,
    kind: 'tool_result',
    callId: 'call_' + 'a'.repeat(32),
    outcome: 'completed',
    blocks,
    ...other,
  }
}

check('frozen Schema bytes and all 22 named definitions', () => {
  assert.deepEqual(packageSchema, frozenSchema)
  assert.equal(Object.keys(schema.$defs).length, 22)
  assert.equal(schema.$schema, 'https://json-schema.org/draft/2020-12/schema')
})

check('numeric predicate guard detects changed or new constraints', () => {
  function numericPredicates(root) {
    const found = []
    function visit(value, path) {
      if (Array.isArray(value)) {
        value.forEach((child, index) => visit(child, `${path}/${index}`))
      } else if (value !== null && typeof value === 'object') {
        if (value.type === 'integer' || value.type === 'number') found.push(`${path}:type=${value.type}`)
        for (const key of [
          'minimum', 'maximum', 'exclusiveMinimum', 'exclusiveMaximum',
          'multipleOf', 'uniqueItems',
        ]) {
          if (Object.hasOwn(value, key)) found.push(`${path}:${key}=${JSON.stringify(value[key])}`)
        }
        if (typeof value.const === 'number') found.push(`${path}:const=${value.const}`)
        if (Array.isArray(value.enum) && value.enum.some(item => typeof item === 'number')) {
          found.push(`${path}:numeric-enum`)
        }
        for (const [key, child] of Object.entries(value)) visit(child, `${path}/${key}`)
      }
    }
    visit(root, '')
    return found.sort()
  }
  const allowed = [
    '/$defs/AttachmentRef/properties/bytes:minimum=0',
    '/$defs/AttachmentRef/properties/bytes:type=integer',
  ]
  const enforce = candidate => assert.deepEqual(numericPredicates(candidate), allowed)
  enforce(schema)
  const altered = structuredClone(schema)
  altered.$defs.AttachmentRef.properties.bytes.minimum = -1
  assert.throws(() => enforce(altered), assert.AssertionError)
  const expanded = structuredClone(schema)
  expanded.$defs.AttachmentRef.properties.bytes.maximum = 999
  assert.throws(() => enforce(expanded), assert.AssertionError)
  console.log('NEGATIVE_CONTROL minimum=-1 and maximum=999 rejected by predicate guard')
})

check('strict JSON syntax and decoded duplicate keys at every depth', () => {
  for (const source of ['{"a":1,}', '{"a":', '[1,]', 'NaN', '01']) {
    assert.deepEqual(readJsonStrict(source), { failed: 'syntax' })
  }
  for (const source of [
    '{"a":1,"a":2}',
    '{"a":1,"\\u0061":2}',
    '{"outer":{"a":1,"\\u0061":2}}',
    '[{"x":1},{"x":1,"x":2}]',
    '{"__proto__":1,"\\u005f_proto__":2}',
  ]) {
    assert.deepEqual(readJsonStrict(source), { failed: 'duplicate_member' }, source)
  }
  const safe = parsed('{"__proto__":{"x":1},"outer":[{"a":2},{"a":3}]}')
  assert.equal(Object.hasOwn(safe, '__proto__'), true)
  assert.equal(safe.__proto__.x, 1)
  assert.equal(safe.outer.length, 2)
})

check('lossless number round trips across magnitude and rounding boundaries', () => {
  for (const source of [
    '9007199254740993', '-9007199254740993', '12345678901234567890',
    '1.0000000000000001', '0.10000000000000001', '1e400', '-1e400',
    '1e-400', '-1e-400', '1e1000000', '-1e1000000',
    '1e-1000000', '-1e-1000000', '-0', '-0e1000000',
  ]) {
    const value = parsed(source)
    assert.equal(writeJsonLossless(value), source, source)
    assert.equal(writeJsonLossless(parsed(writeJsonLossless(value))), source, source)
  }
  const nested = parsed('{"arguments":[null,{"n":9007199254740993}],"opaque":{"n":1.0000000000000001}}')
  assert.equal(writeJsonLossless(nested), '{"arguments":[null,{"n":9007199254740993}],"opaque":{"n":1.0000000000000001}}')
})

check('each normative example targets its declared $defs; 162 Schema rows', () => {
  const ajv = new Ajv2020({ strict: true, strictRequired: false, strictTypes: false })
  ajv.addSchema(schema)
  for (const name of Object.keys(schema.$defs)) {
    assert.equal(typeof ajv.getSchema(`${schema.$id}#/$defs/${name}`), 'function', name)
  }
  const validators = new Map()
  const blockKinds = new Set()
  const callCompleteness = new Set()
  let section = 0
  let target = undefined
  let count = 0
  let yes = 0
  let no = 0
  for (const line of examples.split('\n')) {
    const heading = /^## (\d+)\./.exec(line)
    if (heading) {
      section = Number(heading[1])
      target = undefined
      continue
    }
    if (section < 1 || section > 13) continue
    const declared = /^\*\*校验对象\*\*：`\$defs\/([^`]+)`/.exec(line)
    if (declared) target = declared[1]
    const cells = line.split(' | ')
    if (section === 13) {
      if (!line.startsWith('| `$defs/')) continue
      target = /^\| `\$defs\/([^`]+)`/.exec(line)?.[1]
      cells.shift()
    } else if (!line.startsWith('| `')) {
      continue
    }
    if (target === undefined) continue
    const source = /^`(.*)`$/.exec(cells[0].replace(/^\| /, ''))?.[1]
    const expected = cells[1]
    if (source === undefined || (expected !== '通过' && expected !== '拒绝')) continue
    const value = JSON.parse(source)
    if (target === 'ContentBlock' && expected === '通过') {
      blockKinds.add(value.kind)
      if (value.kind === 'tool_call') callCompleteness.add(value.complete)
    }
    let validator = validators.get(target)
    if (validator === undefined) {
      validator = ajv.getSchema(`${schema.$id}#/$defs/${target}`)
      assert.ok(validator, target)
      validators.set(target, validator)
    }
    const actual = validator(value)
    assert.equal(actual, expected === '通过', `section ${section}, ${target}, ${source}: ${JSON.stringify(validator.errors)}`)
    count += 1
    if (actual) yes += 1
    else no += 1
    if (target === 'ContentBlock') {
      const judged = judgeContentBlock(value)
      const expectedRejection = /^`([^`]+)`$/.exec(cells[2])?.[1]
      if (expectedRejection !== undefined) {
        assert.deepEqual(judged, { rejected: expectedRejection }, `section ${section}, ${source}`)
      } else if (expected === '通过') {
        assert.ok('ok' in judged, `section ${section}, ${source}: ${JSON.stringify(judged)}`)
      }
    }
  }
  assert.equal(count, 162)
  assert.equal(yes, 60)
  assert.equal(no, 102)
  assert.deepEqual([...blockKinds].sort(), [
    'file', 'image', 'text', 'thinking', 'tool_call', 'tool_result', 'voice',
  ])
  assert.deepEqual([...callCompleteness].sort(), [false, true])
  console.log(`EXAMPLES count=${count} accepted=${yes} rejected=${no} defs=${validators.size}`)
})

check('all six rejection names follow global priority across nested siblings', () => {
  rejected({ ...base, kind: 'unknown' }, 'kind_unknown')
  rejected({ id: 'b0', kind: 'text', text: 'x' }, 'visibility_missing')
  rejected({ ...base, kind: 'tool_call', complete: false, rawArguments: '{' }, 'incomplete_call_visible')
  rejected(resultBlock([{ ...base, kind: 'tool_call', complete: true, callId: 'c', tool: 'run', arguments: {} }]), 'call_in_result')
  rejected({ ...base, kind: 'image', mediaType: 'audio/wav', data: { inline: 'UklGRiQAAABXQVZF' } }, 'modality_mismatch')
  rejected({ ...base, kind: 'text', text: 'x', extra: 1 }, 'malformed')
  const low = { ...base, kind: 'image', mediaType: 'audio/wav', data: { inline: 'UklGRiQAAABXQVZF' } }
  const high = { ...base, kind: 'tool_call', complete: false, rawArguments: '{', visibility: { toHuman: true, toModel: false } }
  rejected(resultBlock([low, high]), 'incomplete_call_visible')
  rejected(resultBlock([high, low]), 'incomplete_call_visible')
  rejected(resultBlock([low, { id: 'nested', kind: 'unknown', visibility }]), 'kind_unknown')
  rejected(resultBlock([low, { id: 'nested', kind: 'text', text: 'x' }]), 'visibility_missing')
  rejected(resultBlock([low, { ...base, kind: 'tool_call', complete: true, callId: 'c', tool: 'run', arguments: {} }]), 'call_in_result')
})

check('bytes exact integer and minimum across file, media, offloaded and nesting', () => {
  const legal = [number('9007199254740993'), number('1e400'), number('-0'), 0]
  const illegal = [number('-9007199254740993'), number('-1e400'), number('1.0000000000000001'), number('1e-400'), -1, 0.5]
  const wrap = bytes => [
    { ...base, kind: 'file', attachment: ref(bytes) },
    { ...base, kind: 'image', mediaType: 'image/png', data: ref(bytes) },
    { ...base, kind: 'voice', mediaType: 'audio/wav', data: ref(bytes, 'audio/wav') },
    resultBlock([], { offloaded: ref(bytes) }),
    resultBlock([{ ...base, kind: 'file', attachment: ref(bytes) }]),
    { ...base, kind: 'image', mediaType: 'image/png', data: { inline: 'iVBORw0KGgo=' },
      renderings: [{ producedBy: 'system', blocks: [{ ...base, id: 'child', kind: 'voice', mediaType: 'audio/wav', data: ref(bytes, 'audio/wav') }] }], transcript: 'x' },
  ]
  for (const bytes of legal) for (const block of wrap(bytes)) {
    const got = accepted(block)
    assert.ok(writeJsonLossless(got).includes(writeJsonLossless(bytes)))
  }
  for (const bytes of illegal) for (const block of wrap(bytes)) rejected(block, 'malformed')
})

check('number visibility is malformed; opaque and arguments retain original numbers', () => {
  for (const raw of ['9007199254740993', '1e400']) {
    rejected({ ...base, kind: 'text', text: 'x', visibility: number(raw) }, 'malformed')
  }
  const opaque = parsed('{"n":9007199254740993,"nested":[null,{"x":1.0000000000000001}]}')
  const thought = accepted({ ...base, kind: 'thinking', text: 'x', opaque })
  assert.equal(writeJsonLossless(thought.opaque), writeJsonLossless(opaque))
  const call = accepted({ ...base, kind: 'tool_call', complete: true, callId: 'c', tool: 'run', arguments: opaque })
  assert.equal(writeJsonLossless(call.arguments), writeJsonLossless(opaque))
  const absent = accepted({ ...base, kind: 'thinking', text: 'x' })
  const present = accepted({ ...base, kind: 'thinking', text: 'x', opaque: null })
  assert.equal(Object.hasOwn(absent, 'opaque'), false)
  assert.equal(Object.hasOwn(present, 'opaque'), true)
  assert.equal(present.opaque, null)
})

check('media equality and derived modality are cross-member requirements', () => {
  const matching = { ...base, kind: 'image', mediaType: 'image/png', data: ref(0, 'image/png') }
  const mismatching = { ...base, kind: 'image', mediaType: 'image/png', data: ref(0, 'image/jpeg') }
  const ajv = new Ajv2020({ strict: true, strictRequired: false, strictTypes: false })
  ajv.addSchema(schema)
  const shape = ajv.getSchema(`${schema.$id}#/$defs/ContentBlock`)
  assert.ok(shape)
  assert.equal(shape(matching), true)
  assert.equal(shape(mismatching), true)
  accepted(matching)
  rejected(mismatching, 'malformed')
  console.log('MEDIA_CROSS_MEMBER matching=ok mismatching=malformed schema_accepts_both=true bytes=0')
  rejected({ ...base, kind: 'image', mediaType: 'image/png', data: { inline: 'iVBORw0KGgo=' },
    renderings: [{ producedBy: 'system', blocks: [{ ...base, id: 'child', kind: 'image', mediaType: 'image/jpeg', data: { inline: 'iVBORw0KGgo=' } }] }], transcript: 'x' }, 'malformed')
  accepted({ ...base, kind: 'image', mediaType: 'image/png', data: { inline: 'iVBORw0KGgo=' },
    renderings: [{ producedBy: 'system', blocks: [textBlock('child')] }], transcript: 'x' })
  assert.equal(isCanonicalMediaType('image/png'), true)
  assert.equal(isCanonicalMediaType('Image/PNG'), false)
  assert.equal(modalityOf('video/mp4'), 'video')
  assert.equal(capabilityIdEquals({ category: 'tool', name: 'x' }, { category: 'skill', name: 'x' }), false)
})

check('successful output is a deep-frozen independent copy, input remains mutable', () => {
  const input = resultBlock([{ ...base, kind: 'thinking', text: 'thought', opaque: { rows: [{ value: 1 }] } }])
  const before = writeJsonLossless(input)
  const output = accepted(input)
  assert.equal(writeJsonLossless(input), before)
  assert.notEqual(output, input)
  assert.notEqual(output.blocks, input.blocks)
  assert.equal(Object.isFrozen(input), false)
  for (const node of [output, output.visibility, output.blocks, output.blocks[0], output.blocks[0].opaque, output.blocks[0].opaque.rows, output.blocks[0].opaque.rows[0]]) {
    assert.equal(Object.isFrozen(node), true)
  }
  input.blocks[0].opaque.rows[0].value = 99
  assert.equal(output.blocks[0].opaque.rows[0].value, 1)
  assert.throws(() => { output.blocks[0].opaque.rows[0].value = 7 }, TypeError)
})

check('forged numeric shell and non-JSON objects reject without data loss', () => {
  const real = number('9007199254740993')
  const forged = Object.create(Object.getPrototypeOf(real))
  rejected({ ...base, kind: 'thinking', text: 'x', opaque: forged }, 'malformed')
  const cyclic = textBlock()
  cyclic.self = cyclic
  rejected(cyclic, 'malformed')
  const sparse = [textBlock('child')]
  sparse.length = 2
  rejected(resultBlock(sparse), 'malformed')
  const extra = [textBlock('child')]
  extra.extra = 1
  rejected(resultBlock(extra), 'malformed')
  const nonEnumerable = textBlock()
  Object.defineProperty(nonEnumerable, 'hidden', { value: 1 })
  rejected(nonEnumerable, 'malformed')
  const accessor = textBlock()
  Object.defineProperty(accessor, 'extra', { get() { throw new Error('should not run') }, enumerable: true })
  rejected(accessor, 'malformed')
  rejected({ ...cyclic, kind: 'alien' }, 'kind_unknown')
  rejected(resultBlock([textBlock('child')], { offloaded: { ...attachment, bytes: 1n } }), 'malformed')
})

check('accepted lexical identifiers are broader than generator output', () => {
  accepted(textBlock('b0'))
  accepted(textBlock('b' + 'a'.repeat(26)))
  accepted({ ...base, kind: 'tool_call', complete: true, callId: 'call_' + 'a'.repeat(32), tool: 'run', arguments: {} })
  accepted({ ...base, kind: 'tool_call', complete: true, callId: 'c', tool: 'run', arguments: {} })
})

console.log(`RESULT passed=${passed} failed=${failures.length}`)
if (failures.length > 0) process.exitCode = 1
