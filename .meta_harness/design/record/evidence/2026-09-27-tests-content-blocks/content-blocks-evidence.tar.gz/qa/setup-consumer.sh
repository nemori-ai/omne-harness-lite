#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"
consumer_dir="$repo_root/tmp/content-blocks-qa"
cd -- "$repo_root"

test -f packages/core/content-blocks/dist/index.d.ts
test -f packages/core/identity-values/dist/index.d.ts
test -f packages/core/content-blocks/node_modules/ajv/package.json
test -f packages/core/content-blocks/node_modules/@types/node/package.json

mkdir -p "$consumer_dir/node_modules/@omne-harness-lite" "$consumer_dir/node_modules/@types"
ln -sfn ../../../../packages/core/content-blocks \
  "$consumer_dir/node_modules/@omne-harness-lite/content-blocks"
ln -sfn ../../../packages/core/content-blocks/node_modules/ajv \
  "$consumer_dir/node_modules/ajv"
ln -sfn ../../../../packages/core/content-blocks/node_modules/@types/node \
  "$consumer_dir/node_modules/@types/node"

test -f "$consumer_dir/node_modules/@omne-harness-lite/content-blocks/package.json"
test -f "$consumer_dir/node_modules/ajv/package.json"
test -f "$consumer_dir/node_modules/@types/node/package.json"
