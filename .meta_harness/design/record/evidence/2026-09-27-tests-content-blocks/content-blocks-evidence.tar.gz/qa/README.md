# content-blocks 独立验收记录（2026-09-27）

**结论：Pass，限 D-068 采用的 `data.content-blocks/v2` 纯模块。**这是一份独立符合性意见，不是主线最终接受。没有发现可复现的产品缺陷。`data.messages` 的消息级 BlockId 判重、会话 CallId 唯一、附件解引用与租户判定、日志落盘后不变、真实接收边界及每一跳无损、完整 Agent 和 pi 入口均未由本次模块运行证明。

## 固定输入与环境

- 执行仓库：`/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-content-blocks-qa`；分支 `pandazki/agent-work-loop-content-blocks-qa`；HEAD `e45d52cf1aac235f83d7e462c0606a169c308b15`。受跟踪文件始终无改动。
- 设计工作区：此检出 `.meta_harness/design/` 的冻结 CBv2、D-068、节点验证。实施与验收安排由 HUB `tmp/next-iteration/tasks/content-blocks-independent-qa.md` 正式释放。
- Node `v24.21.0`（`/Users/pandazki/.local/share/fnm/node-versions/v24.21.0/installation/bin/node`），`TMPDIR=/private/tmp`，pnpm `10.28.1`，TypeScript `6.0.3`，Ajv `8.20.0`，macOS arm64。无网络、模型或密钥调用。离线安装复用本机 pnpm store，spoke 内独立生成 `node_modules` 与两个包的 `dist`。
- 输入 SHA256：契约 `ae963e2bcd8c5005951f6e31be9d893e555aad24b12e230fa12e95bddfbca532`；规范实例 `d768208409b0957affdcf467df9ec6f13c3107a5535acfec88c257ef6eec8a0b`；冻结 Schema 与包内副本均 `ed9c7d15f35edfd1b24cef510367449a3a8ed5eefd5305464709220304ee6b21`；D-068 决定 `70caa8c21507184bae0c7209d9e293df33c8d6ac6abad1a2812c1ca2910f4ea2`；`pnpm-lock.yaml` 为 `47494d3c7b5b603aeee5f3476bbe0c4b4f2596ebf19107c8353f8a5cc24fdbce`。
- 构建后公开 `dist/index.d.ts` SHA256 `6c3bec27c6179685747b34047f8f85ba495ed5fc47c9639b31515dc26824d2b7`，与释放值一致。

## 逐义务结果

| 义务与依据 | 独立观察 | 结果 |
| --- | --- | --- |
| V-1 / S-1～21、S-24～25；七类八形、22 个 `$defs` | 22 个定义均由 Ajv Draft 2020-12 编译。规范实例第 1～13 节按每行声明的定义执行 162 行：60 接受、102 拒绝；`ContentBlock` 行另核公开 judge 的具名值。七个 `kind` 与调用完整/半截两形均被覆盖。根空 Schema 未作判据。 | Pass |
| V-2 / S-26；六种拒绝与全局次序 | 六个拒绝值独立构造；规范第 12 节六行及嵌套、多兄弟、逆序多违例均按 `kind_unknown > visibility_missing > incomplete_call_visible > call_in_result > modality_mismatch > malformed` 得到预期。 | Pass |
| V-3 本模块部分 / S-7、S-10、S-19、S-27 | 复验用合法 `bytes: 0` 构造相同媒体类型的正例与同模态不同媒体类型的反例。冻结 Schema 的 `ContentBlock` 定义对两者均接受，公开 judge 前者通过、后者 `malformed`，因此隔离了跨成员相等判据；原/派生同模态被拒，合法跨模态通过，大小写错误不被修补。 | Pass（定向复验后） |
| V-6 与 V-11 本模块部分 / S-9、S-12、S-24 | 语法错误及根、内层、数组内、转义后同名、`__proto__` 的重复成员均拒；大正负整数、舍入临界小数、巨大正负指数、负零读写回读保留；`opaque` 与 `arguments` 的嵌套数值、缺席与 `null` 保留。 | Pass |
| NS-1 / S-21；`bytes` 精确 `integer` 且 ≥0 | 文件、引用图/语音、结果 `offloaded`、工具结果嵌套、派生块中的 6 条路径，各取 4 个合法与 6 个非法长度共 60 次；`9007199254740993`、`1e400`、`-0` 合法；负整数、非整数、极小指数非法。 | Pass |
| NS-2 / S-26～27；私有视图与原值 | 数值 `visibility` 为 `malformed`；具名拒绝压过坏数；成功值返回独立深冻结副本，原输入仍可变；后改原输入不影响结果；伪造数值外壳拒绝；`opaque`/`arguments` 数值未被代表值污染。 | Pass |
| NS-3 / D-068 数值视图边界 | 包内 Schema 与冻结原件逐字节相等。守卫枚举当前唯一数值叶子谓词：`AttachmentRef.bytes` 的 `type: integer`、`minimum: 0`；内存中改成 `minimum: -1` 或增加 `maximum: 999`，同一守卫均抛断言错误。没有修改冻结文件。 | Pass |
| IS-1 本模块部分 / S-31 接收词法 | `b0`、26 字符普通式、`call_` 加 32 字符式及短合法 CallId 均接受；没有把生成器词法写成接收限制。 | Pass |
| 输入值代数、非 JSON 值 / D-068 N-A | 自环、`bigint`、稀疏数组、数组附属性、非枚举成员、访问器成员均拒而未修补或静默丢弃；可安全判的 `kind_unknown` 在自环并存时仍优先。未对任意敌意 Proxy 声称沙箱安全。 | Pass |
| 公开消费与纯模块边界 / 节点设计 | 独立 NodeNext strict TS 消费者仅从包名 `exports` 导入并编译通过；无源码私有 helper 或路径别名。静态检索本包 `src`/package 声明没有 Cordis、kernel-basis、storage 导入。 | Pass |

## 实际命令、原始输出与退出码

以下命令从上述 spoke 根执行，所有 Node/pnpm 命令前带 `PATH=/Users/pandazki/.local/share/fnm/node-versions/v24.21.0/installation/bin:$PATH TMPDIR=/private/tmp`：

1. `pnpm install --offline --frozen-lockfile --ignore-scripts` → exit 0；原始输出 `install.log`，77 包全部从本机 store 复用，下载 0。
2. `pnpm --filter @omne-harness-lite/identity-values run build` → exit 0；`identity-build.log`。
3. `pnpm --filter @omne-harness-lite/content-blocks run build` → exit 0；`content-build.log`。
4. `tmp/content-blocks-qa/setup-consumer.sh` → exit 0；重建本地消费者所需的三个符号链接，原始 stdout/stderr 为空，见 `setup-consumer.log`。脚本 SHA256 `cdfa49a32b5caa1faf7f661b291ad54dce5100c7b9c75ee16fa436c88e7f48be`。
5. `node tmp/content-blocks-qa/qa.mjs` → exit 0；`qa.log`，`RESULT passed=12 failed=0`，且明确记录 `MEDIA_CROSS_MEMBER matching=ok mismatching=malformed schema_accepts_both=true bytes=0`。脚本 SHA256 `9945fa823b3d045849e3a4f7c66760305c24bce35036db9f00e58564366cf513`；日志 SHA256 `6c1d90a4c17246c476f511f266ff52163aed23ee308f9ca781f1443394c6b818`。
6. `packages/core/content-blocks/node_modules/.bin/tsc -p tmp/content-blocks-qa/tsconfig.json` → exit 0；空 stdout/stderr 见 `consumer-typecheck.log`；`consumer.ts` SHA256 `b4a3ef63856876d93ed7a72fadb661d74b25abd497fd152ffac74782d8d26172`。
7. `rg -n '@deepseek-ai/cordis|@omne-harness-lite/kernel-basis|@omne-harness-lite/storage|Context|Fiber' packages/core/content-blocks/src packages/core/content-blocks/package.json` → exit 1（无命中）；这是静态边界佐证，不替代依赖图或运行符合性。

独立消费者的 `tmp/content-blocks-qa/node_modules` 只含指向本 spoke 已安装包的本地符号链接；没有借 HUB 的 `dist` 或 `node_modules`。归档不含这个 `node_modules` 时，先按步骤 1～3 在目标检出离线安装与构建，再运行步骤 4；它精确执行：

```sh
mkdir -p tmp/content-blocks-qa/node_modules/@omne-harness-lite tmp/content-blocks-qa/node_modules/@types
ln -sfn ../../../../packages/core/content-blocks tmp/content-blocks-qa/node_modules/@omne-harness-lite/content-blocks
ln -sfn ../../../packages/core/content-blocks/node_modules/ajv tmp/content-blocks-qa/node_modules/ajv
ln -sfn ../../../../packages/core/content-blocks/node_modules/@types/node tmp/content-blocks-qa/node_modules/@types/node
```

相对路径从每个链接所在目录计算；脚本还在链接前后验证目标存在。`tmp/` 被仓库格式脚本排除，不属于共享格式化的受维护目标；未对产品或受维护测试运行格式化写入。

## 测量设施的失败记录与修正

- `qa-first.log`：本地包符号链接相对路径多退一级，进程在模块解析前退出。`qa-second.log`：脚本读取设计文件的相对路径多退一级，同样在测试前退出。修正路径后才开始计算场景结果。
- `qa-third.log`：首轮数值守卫把数组长度的 `minItems` 也算作数值**叶子**谓词，导致守卫失败。D-068 R2 数值桥只替换 JSON 数值叶子，`minItems` 约束数组长度，故守卫改为监测 `type: number/integer`、数值范围与倍数、数值常量/枚举及会比较数值叶子的 `uniqueItems`；不降低 `AttachmentRef.bytes` 的 `integer`/`minimum 0` 判据。最终 `qa.log` 的两个内存负对照均检出变更。
- 初次 `consumer-typecheck` 因独立 fixture 缺 `@types/node` 报 `node:crypto` 声明不可见；**该次原始 stdout/stderr 未保存为文件，不能充作可重跑的原始结果**。为消费者配置 `types: ["node"]` 并链接本 spoke 的冻结安装类型后 exit 0。没有改产品声明、根配置或锁文件。
- 主线复核发现前版 V-3 媒体相等反例误用了 `ref(undefined, 'image/jpeg')`，它含 own `bytes: undefined`，在 JSON 值代数检查已应为 `malformed`，因此前版 `qa-pre-v3.log` 的同名组通过**不能支持媒体相等结论**。本版把正反例都改为合法 `bytes: 0`，让冻结 Schema 对两者均通过后再观察 judge 的分叉；`qa.log` 是本版原始结果。旧日志 SHA256 `e1bb9f57bc2a57c9c4d65137966bcdaf1ac5101686403ba513024805e1ce7712`，保留作前后证据，不计作 V-3 通过。

## 未覆盖与证据边界

- 规范第 14 节属于多 owner：消息内 ID 重复归 messages；落盘不变归日志写入方；组装合取归 PF-010；参数只解析一次归流装配；附件落块归受理方。此处只验证媒体两处相等、派生模态、非规范不修补及严格 codec 的本模块部分。
- V-4、V-5、V-7、V-8、V-9 的真实接收、存储、组装和跨进程行为，以及 V-6/V-11 的每一跳端到端无损，均无本次真实组合证据。SC-2/SC-3 的跨消费者静态规则亦不由这个包的纯模块试验闭合。
- JSON Schema 校验、替身输入的公开函数试验、静态导入检索、独立 TS 消费者各自只支持表中所述结论；本次没有有限模型检查、机器证明或实机 Agent 运行。
- **非代码阻断的导航问题**：`spec/data/content-blocks/README.md` 尚有 `identity-values v2`、`v1` 版本标签及 `v2` 候选状态旧句；`spec/data/content-blocks/verification.md` 顶部仍称本契约 candidate/未冻结/无源码。当前契约正文、registry catalog、`frozen.json` 与 D-068 均把本 QA 采用的 CBv2 / identity-values v1 及冻结资源定清，故不改变上述 Pass 范围。主线已确认由设计拥有者回填这些可更新导航，不原地改冻结正文。
