import {
  capabilityIdEquals,
  isCanonicalMediaType,
  judgeContentBlock,
  modalityOf,
  readJsonStrict,
  writeJsonLossless,
  type AttachmentRef,
  type BlockId,
  type CallId,
  type CapabilityId,
  type ContentBlock,
  type JsonNumber,
  type JsonValue,
  type LosslessNumber,
  type ToolResultBlock,
} from '@omne-harness-lite/content-blocks'

export function consume(value: unknown): string {
  const result = judgeContentBlock(value)
  if ('rejected' in result) return result.rejected
  const block: ContentBlock = result.ok
  const encoded: string = writeJsonLossless(block)
  const decoded = readJsonStrict(encoded)
  if ('failed' in decoded) return decoded.failed
  const json: JsonValue = decoded.ok
  const modal = modalityOf('image/png')
  const canonical: boolean = isCanonicalMediaType('image/png')
  const left: CapabilityId = { category: 'tool', name: 'read' }
  const right: CapabilityId = { category: 'tool', name: 'read' }
  const same: boolean = capabilityIdEquals(left, right)
  return `${encoded}:${String(json !== null)}:${modal}:${canonical}:${same}`
}

export function publicTypes(
  attachment: AttachmentRef,
  blockId: BlockId,
  callId: CallId,
  result: ToolResultBlock,
  number: JsonNumber,
  lossless: LosslessNumber,
): readonly unknown[] {
  return [attachment, blockId, callId, result, number, lossless]
}
