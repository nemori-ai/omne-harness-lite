import { describe, expect, it } from 'vitest'
import { judgeContentBlock, readJsonStrict } from '../src/index.ts'

const visible = { toHuman: true, toModel: true }

describe('S-26 fixed rejection order', () => {
  it('kind_unknown wins over missing visibility and malformed extras', () => {
    expect(judgeContentBlock({ id: 'b', kind: 'video', extra: undefined })).toEqual({
      rejected: 'kind_unknown',
    })
  })

  it('visibility_missing wins over a visible incomplete call', () => {
    const input = {
      id: 'b',
      kind: 'tool_call',
      complete: false,
      rawArguments: '',
      visibility: { toHuman: true },
    }
    expect(judgeContentBlock(input)).toEqual({ rejected: 'visibility_missing' })
  })

  it('incomplete_call_visible wins over call_in_result', () => {
    const input = {
      id: 'root',
      kind: 'tool_result',
      visibility: visible,
      callId: 'c',
      outcome: 'completed',
      blocks: [
        {
          id: 'call',
          kind: 'tool_call',
          complete: false,
          rawArguments: '',
          visibility: { toHuman: true, toModel: false },
        },
      ],
    }
    expect(judgeContentBlock(input)).toEqual({ rejected: 'incomplete_call_visible' })
  })

  it('call_in_result wins over a sibling modality mismatch and malformed result', () => {
    const input = {
      id: 'root',
      kind: 'tool_result',
      visibility: visible,
      callId: 'c',
      blocks: [
        {
          id: 'image',
          kind: 'image',
          visibility: visible,
          mediaType: 'video/mp4',
          data: { inline: 'iVBORw0KGgo=' },
        },
        {
          id: 'call',
          kind: 'tool_call',
          complete: true,
          callId: 'c2',
          tool: 'read_file',
          arguments: {},
          visibility: visible,
        },
      ],
    }
    expect(judgeContentBlock(input)).toEqual({ rejected: 'call_in_result' })
  })

  it('modality_mismatch wins over malformed extras and noncanonical media is only malformed', () => {
    const image = {
      id: 'b',
      kind: 'image',
      visibility: visible,
      mediaType: 'video/mp4',
      data: { inline: 'iVBORw0KGgo=' },
      extra: undefined,
    }
    expect(judgeContentBlock(image)).toEqual({ rejected: 'modality_mismatch' })
    expect(judgeContentBlock({ ...image, mediaType: 'Image/PNG' })).toEqual({
      rejected: 'malformed',
    })
  })

  it('malformed is the final residual, including section-14 cross-member constraints', () => {
    const mediaDisagreement = {
      id: 'image',
      kind: 'image',
      visibility: visible,
      mediaType: 'image/png',
      data: { storage: 's', key: 'k', mediaType: 'image/jpeg' },
    }
    expect(judgeContentBlock(mediaDisagreement)).toEqual({ rejected: 'malformed' })
    const sameModalityRendering = {
      ...mediaDisagreement,
      data: { storage: 's', key: 'k', mediaType: 'image/png' },
      renderings: [
        {
          producedBy: 'system',
          blocks: [
            {
              id: 'derived',
              kind: 'image',
              visibility: visible,
              mediaType: 'image/jpeg',
              data: { inline: 'iVBORw0KGgo=' },
            },
          ],
        },
      ],
      transcript: 'image',
    }
    expect(judgeContentBlock(sameModalityRendering)).toEqual({ rejected: 'malformed' })
    expect(readJsonStrict('{"id":"b","kind":"text","kind":"tool_call"}')).toEqual({
      failed: 'duplicate_member',
    })
    const missingVisibility = { id: 'b', kind: 'text', text: 'hello' }
    expect(judgeContentBlock(missingVisibility)).toEqual({ rejected: 'visibility_missing' })
    expect(Object.hasOwn(missingVisibility, 'visibility')).toBe(false)
    const noncanonical = { ...mediaDisagreement, mediaType: 'Image/PNG' }
    expect(judgeContentBlock(noncanonical)).toEqual({ rejected: 'malformed' })
    expect(noncanonical.mediaType).toBe('Image/PNG')
  })

  it('named outcomes still win when an unrelated non-JSON cycle exists', () => {
    const unknown: Record<string, unknown> = { id: 'b', kind: 'video', visibility: visible }
    unknown.self = unknown
    expect(judgeContentBlock(unknown)).toEqual({ rejected: 'kind_unknown' })
    const cyclic: Record<string, unknown> = {
      id: 'b',
      kind: 'tool_call',
      complete: false,
      rawArguments: '',
      visibility: { toHuman: true, toModel: false },
    }
    cyclic.self = cyclic
    expect(judgeContentBlock(cyclic)).toEqual({ rejected: 'incomplete_call_visible' })
  })
})
