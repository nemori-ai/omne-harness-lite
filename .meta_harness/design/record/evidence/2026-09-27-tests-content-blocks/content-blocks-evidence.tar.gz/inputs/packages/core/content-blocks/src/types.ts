import type { OpaqueIdentifier } from '@omne-harness-lite/identity-values'
import type { JsonNumber, JsonValue } from './json.ts'

export type BlockId = OpaqueIdentifier<'BlockId'>
export type CallId = OpaqueIdentifier<'CallId'>
export type ModelToolName = string
export type MediaType = string
export type InlineBytes = string
export type Modality = 'text' | 'image' | 'audio' | 'video'

export interface Visibility {
  readonly toHuman: boolean
  readonly toModel: boolean
}

export interface CapabilityId {
  readonly category:
    | 'skill'
    | 'tool'
    | 'mcp'
    | 'connector'
    | 'loop_extension'
    | 'slash_command'
    | 'plugin'
    | 'agent_definition'
  readonly name: string
}

export interface AttachmentRef {
  readonly storage: OpaqueIdentifier<'AttachmentStorage'>
  readonly key: OpaqueIdentifier<'AttachmentKey'>
  readonly mediaType: MediaType
  readonly bytes?: JsonNumber
  readonly name?: string
}

export interface DerivedRendering {
  readonly producedBy: 'system'
  readonly blocks: readonly (TextBlock | DerivedImageBlock | DerivedVoiceBlock)[]
}

export interface BlockBase {
  readonly id: BlockId
  readonly visibility: Visibility
}

type RenderingState =
  | { readonly renderings?: never; readonly transcript?: never }
  | { readonly renderings: readonly DerivedRendering[]; readonly transcript: string }

export type RenderableBlock = BlockBase & RenderingState

export interface OriginTag {
  readonly kind:
    'slash_command_args' | 'skill_body' | 'slash_command_expansion' | 'slash_command_record'
  readonly command?: string
  readonly skill?: string
}

export interface TextBlock extends BlockBase {
  readonly kind: 'text'
  readonly text: string
  readonly origin?: OriginTag
}

export interface ThinkingBlock extends BlockBase {
  readonly kind: 'thinking'
  readonly text: string
  readonly opaque?: JsonValue
}

export type MediaData =
  | { readonly inline: InlineBytes; readonly storage?: never }
  | (AttachmentRef & { readonly inline?: never })

interface VoiceFields {
  readonly kind: 'voice'
  readonly mediaType: MediaType
  readonly data: MediaData
}
export type VoiceBlock = RenderableBlock & VoiceFields
export type DerivedVoiceBlock = BlockBase & VoiceFields

interface ImageFields {
  readonly kind: 'image'
  readonly mediaType: MediaType
  readonly data: MediaData
}
export type ImageBlock = RenderableBlock & ImageFields
export type DerivedImageBlock = BlockBase & ImageFields

export type FileBlock = RenderableBlock & {
  readonly kind: 'file'
  readonly attachment: AttachmentRef
}

interface CompleteToolCallBase extends BlockBase {
  readonly kind: 'tool_call'
  readonly complete: true
  readonly callId: CallId
  readonly tool: ModelToolName
}
export type ToolCallBlock = CompleteToolCallBase &
  (
    | { readonly arguments: JsonValue; readonly rawArguments?: never; readonly unparseable?: never }
    | { readonly arguments?: never; readonly rawArguments: string; readonly unparseable: true }
  )

export interface IncompleteToolCallBlock extends BlockBase {
  readonly kind: 'tool_call'
  readonly complete: false
  readonly visibility: { readonly toHuman: false; readonly toModel: false }
  readonly callId?: CallId
  readonly tool?: string
  readonly rawArguments: string
}

export type ExecutionOutcome =
  'completed' | 'failed' | 'unavailable' | 'backgrounded' | 'interrupted' | 'no_answer'

export type PlaceholderReason =
  | 'user_interrupted'
  | 'backgrounded_auto'
  | 'backgrounded_by_user'
  | 'backgrounded_by_preemption'
  | 'interrupted_by_preemption'
  | 'human_declined'
  | 'session_archived'
  | 'abnormal_interruption'
  | 'backgrounded_at_start'
  | 'run_cancelled'
  | 'foreground_timeout'

interface ToolResultBase extends BlockBase {
  readonly kind: 'tool_result'
  readonly callId: CallId
  readonly blocks: readonly ContentBlock[]
  readonly offloaded?: AttachmentRef
}
type BackgroundReason =
  | 'backgrounded_auto'
  | 'backgrounded_by_user'
  | 'backgrounded_by_preemption'
  | 'backgrounded_at_start'
type InterruptedReason =
  | 'user_interrupted'
  | 'interrupted_by_preemption'
  | 'human_declined'
  | 'session_archived'
  | 'run_cancelled'
  | 'terminated_by_agent'
  | 'foreground_timeout'
export type ToolResultBlock = ToolResultBase &
  (
    | { readonly outcome: 'completed' | 'unavailable' | 'no_answer'; readonly reason?: never }
    | {
        readonly outcome: 'backgrounded'
        readonly reason: { readonly code: BackgroundReason; readonly text: string }
      }
    | {
        readonly outcome: 'interrupted'
        readonly reason: { readonly code: InterruptedReason; readonly text: string }
      }
    | {
        readonly outcome: 'failed'
        readonly reason?: { readonly code: 'abnormal_interruption'; readonly text: string }
      }
  )

export type ContentBlock =
  | TextBlock
  | ThinkingBlock
  | VoiceBlock
  | ImageBlock
  | FileBlock
  | ToolCallBlock
  | IncompleteToolCallBlock
  | ToolResultBlock

export type ContentBlockRejection =
  | 'kind_unknown'
  | 'visibility_missing'
  | 'incomplete_call_visible'
  | 'call_in_result'
  | 'modality_mismatch'
  | 'malformed'
