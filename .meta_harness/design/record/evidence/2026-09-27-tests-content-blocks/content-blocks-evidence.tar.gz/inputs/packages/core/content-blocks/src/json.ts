import type { ContentBlock } from './types.ts'

/** A JSON number whose decimal value cannot safely be represented by a JS number. */
class LosslessNumberValue {
  readonly #source: string

  private constructor(source: string) {
    this.#source = source
    Object.freeze(this)
  }

  static fromParsedSource(source: string): LosslessNumberValue {
    return new LosslessNumberValue(source)
  }

  static is(value: unknown): value is LosslessNumberValue {
    return typeof value === 'object' && value !== null && #source in value
  }

  static sourceOf(value: LosslessNumberValue): string {
    return value.#source
  }
}

export type LosslessNumber = LosslessNumberValue
export type JsonNumber = number | LosslessNumber
export interface JsonObject {
  readonly [name: string]: JsonValue
}
export type JsonValue = null | boolean | string | JsonNumber | readonly JsonValue[] | JsonObject

interface Decimal {
  readonly negative: boolean
  readonly coefficient: string
  readonly exponent: bigint
}

/** Normalize a syntactically valid JSON number without expanding its exponent. */
function decimal(source: string): Decimal {
  const match = /^(-?)(0|[1-9][0-9]*)(?:\.([0-9]+))?(?:[eE]([+-]?[0-9]+))?$/.exec(source)
  if (match === null) throw new Error('JSON parser supplied an invalid number source')
  const negative = match[1] === '-'
  const integer = match[2] ?? ''
  const fraction = match[3] ?? ''
  const coefficient = (integer + fraction).replace(/^0+/, '').replace(/0+$/, '')
  if (coefficient.length === 0) return { negative, coefficient: '0', exponent: 0n }
  const trailingZeros = (integer + fraction).length - (integer + fraction).replace(/0+$/, '').length
  const exponent = BigInt(match[4] ?? '0') - BigInt(fraction.length) + BigInt(trailingZeros)
  return { negative, coefficient, exponent }
}

function sameDecimalValue(left: Decimal, right: Decimal): boolean {
  return (
    left.coefficient === right.coefficient &&
    left.exponent === right.exponent &&
    (left.coefficient === '0' || left.negative === right.negative)
  )
}

/** Exact sign and integrality; no conversion through Number and no exponent expansion. */
export function classifyJsonNumber(
  value: JsonNumber,
): 'nonnegative_integer' | 'negative_integer' | 'positive_fraction' | 'negative_fraction' {
  const source = LosslessNumberValue.is(value)
    ? LosslessNumberValue.sourceOf(value)
    : JSON.stringify(value)
  if (source === undefined) throw new Error('non-finite number is not a JSON value')
  const parsed = decimal(source)
  if (parsed.coefficient === '0' || parsed.exponent >= 0n) {
    return parsed.negative && parsed.coefficient !== '0'
      ? 'negative_integer'
      : 'nonnegative_integer'
  }
  return parsed.negative ? 'negative_fraction' : 'positive_fraction'
}

function exactNumber(value: number, source: string): JsonNumber {
  const original = decimal(source)
  // Preserve signed zero's spelling. It is a valid JSON value with a distinct round trip.
  if (!Number.isFinite(value) || (original.negative && original.coefficient === '0')) {
    return LosslessNumberValue.fromParsedSource(source)
  }
  return sameDecimalValue(original, decimal(JSON.stringify(value)))
    ? value
    : LosslessNumberValue.fromParsedSource(source)
}

function stringEnd(text: string, start: number): number {
  let at = start + 1
  while (at < text.length) {
    if (text[at] === '\\') {
      at += 2
    } else if (text[at] === '"') {
      return at + 1
    } else {
      at += 1
    }
  }
  throw new Error('JSON parser accepted an unterminated string')
}

/** The engine has already established syntax; this scan only tracks decoded object keys. */
function hasDuplicateMember(text: string): boolean {
  const stack: Array<
    { kind: 'object'; keys: Set<string>; expectingKey: boolean } | { kind: 'array' }
  > = []
  for (let at = 0; at < text.length; at += 1) {
    const char = text[at]
    if (char === '{') {
      stack.push({ kind: 'object', keys: new Set(), expectingKey: true })
    } else if (char === '[') {
      stack.push({ kind: 'array' })
    } else if (char === '}' || char === ']') {
      stack.pop()
    } else if (char === ',') {
      const frame = stack.at(-1)
      if (frame?.kind === 'object') frame.expectingKey = true
    } else if (char === '"') {
      const end = stringEnd(text, at)
      const frame = stack.at(-1)
      if (frame?.kind === 'object' && frame.expectingKey) {
        const key: string = JSON.parse(text.slice(at, end))
        if (frame.keys.has(key)) return true
        frame.keys.add(key)
        frame.expectingKey = false
      }
      at = end - 1
    }
  }
  return false
}

export function isLosslessNumber(value: unknown): value is LosslessNumber {
  return LosslessNumberValue.is(value)
}

export function readJsonStrict(
  text: string,
): { readonly ok: JsonValue } | { readonly failed: 'syntax' | 'duplicate_member' } {
  let value: JsonValue
  try {
    // TypeScript's ES2024 library omits the Node 24 source-context overload.
    const parseWithSource = JSON.parse as (
      text: string,
      reviver: (key: string, value: unknown, context: { source?: string }) => unknown,
    ) => unknown
    value = parseWithSource(text, (_key: string, parsed: unknown, context: { source?: string }) => {
      if (typeof parsed !== 'number') return parsed
      if (context.source === undefined) throw new Error('JSON.parse did not supply number source')
      return exactNumber(parsed, context.source)
    }) as JsonValue
  } catch (error) {
    if (error instanceof SyntaxError) return { failed: 'syntax' }
    throw error
  }
  if (hasDuplicateMember(text)) return { failed: 'duplicate_member' }
  return { ok: value }
}

export function writeJsonLossless(value: JsonValue | ContentBlock): string {
  // Node >=24.18 exposes rawJSON; the compiler's ES2024 lib does not yet declare it.
  const jsonWithRaw = JSON as typeof JSON & { rawJSON(source: string): object }
  const written = JSON.stringify(value, (_key: string, item: unknown) =>
    LosslessNumberValue.is(item) ? jsonWithRaw.rawJSON(LosslessNumberValue.sourceOf(item)) : item,
  )
  if (written === undefined) throw new Error('value is not JSON')
  return written
}
