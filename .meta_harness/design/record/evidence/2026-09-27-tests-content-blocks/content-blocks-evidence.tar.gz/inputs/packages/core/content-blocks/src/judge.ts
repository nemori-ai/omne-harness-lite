import { createRequire } from 'node:module'
import { Ajv2020 } from 'ajv/dist/2020.js'
import { isCanonicalMediaType, modalityOf } from './helpers.ts'
import { classifyJsonNumber, isLosslessNumber, type JsonValue } from './json.ts'
import type { ContentBlock, ContentBlockRejection, Modality } from './types.ts'

const require = createRequire(import.meta.url)
const schema: unknown = require('../schema/content-blocks.schema.json')
if (!isRecord(schema) || typeof schema.$id !== 'string') {
  throw new Error('content-blocks Schema has no identifier')
}
// The frozen schema uses required/properties in subschemas without local type declarations.
const ajv = new Ajv2020({
  strict: true,
  strictRequired: false,
  strictTypes: false,
  allErrors: false,
})
ajv.addSchema(schema)
const contentBlockValidator = ajv.getSchema(`${schema.$id}#/$defs/ContentBlock`)
if (contentBlockValidator === undefined) throw new Error('ContentBlock definition is missing')

function matchesSchema(value: unknown): boolean {
  const validator = contentBlockValidator
  if (validator === undefined) throw new Error('ContentBlock definition is missing')
  return validator(value) === true
}

const kinds: ReadonlySet<string> = new Set([
  'text',
  'thinking',
  'voice',
  'image',
  'file',
  'tool_call',
  'tool_result',
])

function isRecord(value: unknown): value is Record<string, unknown> {
  return (
    typeof value === 'object' && value !== null && !Array.isArray(value) && !isLosslessNumber(value)
  )
}

function own(value: Record<string, unknown>, key: string): boolean {
  return Object.hasOwn(value, key)
}

const NON_DATA = Symbol('non-data member')

function dataMember(value: object, key: string): unknown | typeof NON_DATA {
  const descriptor = Object.getOwnPropertyDescriptor(value, key)
  return descriptor !== undefined && 'value' in descriptor ? descriptor.value : NON_DATA
}

function dataItems(value: readonly unknown[]): unknown[] {
  const items: unknown[] = []
  for (let index = 0; index < value.length; index += 1) {
    const item = dataMember(value, String(index))
    if (item !== NON_DATA) items.push(item)
  }
  return items
}

interface BlockLocation {
  readonly value: unknown
  readonly inResult: boolean
}

/** Walk only members which the frozen Schema names as child blocks. */
function blocksIn(value: unknown): BlockLocation[] {
  const found: BlockLocation[] = []
  const pending: BlockLocation[] = [{ value, inResult: false }]
  const seenOrdinary = new WeakSet<object>()
  const seenResult = new WeakSet<object>()
  while (pending.length > 0) {
    const location = pending.pop()
    if (location === undefined) break
    found.push(location)
    const block = location.value
    if (!isRecord(block)) continue
    const seen = location.inResult ? seenResult : seenOrdinary
    if (seen.has(block)) continue
    seen.add(block)
    const kind = dataMember(block, 'kind')
    const blocks = dataMember(block, 'blocks')
    if (kind === 'tool_result' && Array.isArray(blocks)) {
      for (const child of dataItems(blocks)) pending.push({ value: child, inResult: true })
    }
    const renderings = dataMember(block, 'renderings')
    if (Array.isArray(renderings)) {
      for (const rendering of dataItems(renderings)) {
        if (!isRecord(rendering)) continue
        const derivedBlocks = dataMember(rendering, 'blocks')
        if (!Array.isArray(derivedBlocks)) continue
        for (const child of dataItems(derivedBlocks)) {
          pending.push({ value: child, inResult: location.inResult })
        }
      }
    }
  }
  return found
}

function expectedModality(block: Record<string, unknown>): Modality | undefined {
  if (block.kind === 'voice') return 'audio'
  if (block.kind === 'image') return 'image'
  if (block.kind === 'file' && isRecord(block.attachment)) {
    const mediaType = block.attachment.mediaType
    return typeof mediaType === 'string' ? modalityOf(mediaType) : undefined
  }
  if (block.kind === 'text' || block.kind === 'thinking' || block.kind === 'tool_call') {
    return 'text'
  }
  return undefined
}

function mismatchedMediaType(value: unknown, expected: Modality): boolean {
  return typeof value === 'string' && isCanonicalMediaType(value) && modalityOf(value) !== expected
}

function hasJsonShape(value: unknown, ancestors = new WeakSet<object>()): value is JsonValue {
  if (
    value === null ||
    typeof value === 'string' ||
    typeof value === 'boolean' ||
    isLosslessNumber(value)
  )
    return true
  if (typeof value === 'number') return Number.isFinite(value)
  if (typeof value !== 'object') return false
  const prototype: unknown = Object.getPrototypeOf(value)
  if (prototype !== Object.prototype && prototype !== null && !Array.isArray(value)) return false
  if (ancestors.has(value)) return false
  ancestors.add(value)
  let valid: boolean
  if (Array.isArray(value)) {
    valid = Reflect.ownKeys(value).length === value.length + 1
    for (let index = 0; valid && index < value.length; index += 1) {
      const descriptor = Object.getOwnPropertyDescriptor(value, String(index))
      valid =
        descriptor !== undefined &&
        'value' in descriptor &&
        descriptor.enumerable === true &&
        hasJsonShape(descriptor.value, ancestors)
    }
  } else {
    valid = Reflect.ownKeys(value).every(key => {
      if (typeof key !== 'string') return false
      const descriptor = Object.getOwnPropertyDescriptor(value, key)
      return (
        descriptor !== undefined &&
        'value' in descriptor &&
        descriptor.enumerable === true &&
        hasJsonShape(descriptor.value, ancestors)
      )
    })
  }
  ancestors.delete(value)
  return valid
}

/** The four representatives preserve only integer/minimum 0 in CB v2. */
function validationView(value: JsonValue): unknown {
  if (isLosslessNumber(value)) {
    switch (classifyJsonNumber(value)) {
      case 'nonnegative_integer':
        return 0
      case 'negative_integer':
        return -1
      case 'positive_fraction':
        return 0.5
      case 'negative_fraction':
        return -0.5
    }
  }
  if (Array.isArray(value)) return value.map(validationView)
  if (value !== null && typeof value === 'object') {
    const copy: Record<string, unknown> = Object.create(null)
    for (const [key, child] of Object.entries(value)) {
      Object.defineProperty(copy, key, {
        value: validationView(child),
        enumerable: true,
        configurable: true,
        writable: true,
      })
    }
    return copy
  }
  return value
}

function frozenCopy(value: JsonValue): JsonValue {
  if (value === null || typeof value !== 'object' || isLosslessNumber(value)) return value
  if (Array.isArray(value)) return Object.freeze(value.map(frozenCopy))
  const copy: Record<string, JsonValue> = Object.create(null)
  for (const [key, child] of Object.entries(value)) {
    Object.defineProperty(copy, key, {
      value: frozenCopy(child),
      enumerable: true,
      configurable: false,
      writable: false,
    })
  }
  return Object.freeze(copy)
}

function violatesCrossMembers(locations: readonly BlockLocation[]): boolean {
  for (const { value } of locations) {
    if (!isRecord(value)) continue
    if ((value.kind === 'voice' || value.kind === 'image') && isRecord(value.data)) {
      const reference = value.data
      if (own(reference, 'mediaType') && reference.mediaType !== value.mediaType) return true
    }
    if (value.kind !== 'voice' && value.kind !== 'image' && value.kind !== 'file') continue
    const sourceModality = expectedModality(value)
    if (!Array.isArray(value.renderings) || sourceModality === undefined) continue
    for (const rendering of value.renderings) {
      if (!isRecord(rendering) || !Array.isArray(rendering.blocks)) continue
      for (const derived of rendering.blocks) {
        if (isRecord(derived) && expectedModality(derived) === sourceModality) return true
      }
    }
  }
  return false
}

/**
 * S-26 checks have their own order; Ajv decides only the final malformed case.
 * A successful return owns a frozen copy, never the caller's objects.
 */
export function judgeContentBlock(
  value: unknown,
): { readonly ok: ContentBlock } | { readonly rejected: ContentBlockRejection } {
  const locations = blocksIn(value)
  if (
    locations.some(({ value: block }) => {
      if (!isRecord(block) || !own(block, 'kind')) return false
      const kind = dataMember(block, 'kind')
      return kind !== NON_DATA && (typeof kind !== 'string' || !kinds.has(kind))
    })
  ) {
    return { rejected: 'kind_unknown' }
  }
  if (
    locations.some(({ value: block }) => {
      if (!isRecord(block)) return false
      if (!own(block, 'visibility')) return true
      const visibility = dataMember(block, 'visibility')
      return isRecord(visibility) && (!own(visibility, 'toHuman') || !own(visibility, 'toModel'))
    })
  )
    return { rejected: 'visibility_missing' }
  if (
    locations.some(({ value: block }) => {
      if (
        !isRecord(block) ||
        dataMember(block, 'kind') !== 'tool_call' ||
        dataMember(block, 'complete') !== false
      )
        return false
      const visibility = dataMember(block, 'visibility')
      return (
        isRecord(visibility) &&
        (dataMember(visibility, 'toHuman') === true || dataMember(visibility, 'toModel') === true)
      )
    })
  )
    return { rejected: 'incomplete_call_visible' }
  if (
    locations.some(
      ({ value: block, inResult }) =>
        inResult && isRecord(block) && dataMember(block, 'kind') === 'tool_call',
    )
  ) {
    return { rejected: 'call_in_result' }
  }
  if (
    locations.some(({ value: block }) => {
      if (!isRecord(block)) return false
      const kind = dataMember(block, 'kind')
      const expected = kind === 'voice' ? 'audio' : kind === 'image' ? 'image' : undefined
      if (expected === undefined) return false
      if (mismatchedMediaType(dataMember(block, 'mediaType'), expected)) return true
      const data = dataMember(block, 'data')
      return isRecord(data) && mismatchedMediaType(dataMember(data, 'mediaType'), expected)
    })
  )
    return { rejected: 'modality_mismatch' }
  if (!hasJsonShape(value)) return { rejected: 'malformed' }
  if (!matchesSchema(validationView(value)) || violatesCrossMembers(locations)) {
    return { rejected: 'malformed' }
  }
  // Ajv checked an equivalent numeric view; this copy retains the original value.
  return { ok: frozenCopy(value) as unknown as ContentBlock }
}
