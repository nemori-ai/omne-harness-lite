# @omne-harness-lite/content-blocks

Pure TypeScript functions for the accepted [data.content-blocks v2 contract](../../../.meta_harness/design/spec/data/content-blocks/v2/contract.md). The [provider design](../../../.meta_harness/design/realization/packages/core/content-blocks/design.md) records its exact adoption boundary. The package's `schema/content-blocks.schema.json` is a byte-for-byte copy of the frozen Schema; tests compare it with the workspace source.

Run `pnpm --filter @omne-harness-lite/content-blocks run build`, `typecheck`, and `test` from the repository root with Node 24.21. The package has no runtime service or storage binding. Runtime callers must map `readJsonStrict` failures at their own boundary and own message-level identity checks, durable writes, and attachment access.
