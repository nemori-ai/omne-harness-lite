import { describe, expect, it } from 'vitest'
import {
  judgeContentBlock,
  readJsonStrict,
  writeJsonLossless,
  type JsonNumber,
} from '../src/index.ts'
import { isLosslessNumber } from '../src/json.ts'

const visible = { toHuman: true, toModel: true }

function numberFrom(text: string): JsonNumber {
  const result = readJsonStrict(text)
  if (!('ok' in result)) throw new Error(`invalid test number: ${text}`)
  if (typeof result.ok === 'number') return result.ok
  if (isLosslessNumber(result.ok)) return result.ok
  throw new Error(`not a number: ${text}`)
}

function byteLocations(bytes: JsonNumber): readonly unknown[] {
  const pdf = { storage: 's', key: 'k', mediaType: 'application/pdf', bytes }
  const audio = { storage: 's', key: 'a', mediaType: 'audio/wav', bytes }
  const image = { storage: 's', key: 'i', mediaType: 'image/png', bytes }
  return [
    { id: 'f', kind: 'file', visibility: visible, attachment: pdf },
    { id: 'v', kind: 'voice', visibility: visible, mediaType: 'audio/wav', data: audio },
    { id: 'i', kind: 'image', visibility: visible, mediaType: 'image/png', data: image },
    {
      id: 'r',
      kind: 'tool_result',
      visibility: visible,
      callId: 'c',
      outcome: 'completed',
      blocks: [],
      offloaded: pdf,
    },
    {
      id: 'r2',
      kind: 'tool_result',
      visibility: visible,
      callId: 'c2',
      outcome: 'completed',
      blocks: [{ id: 'nested', kind: 'file', visibility: visible, attachment: pdf }],
    },
    {
      id: 'source',
      kind: 'voice',
      visibility: visible,
      mediaType: 'audio/wav',
      data: { inline: 'UklGRiQAAABXQVZF' },
      renderings: [
        {
          producedBy: 'system',
          blocks: [
            {
              id: 'derived',
              kind: 'image',
              visibility: visible,
              mediaType: 'image/png',
              data: image,
            },
          ],
        },
      ],
      transcript: 'a sound',
    },
  ]
}

describe('NS-1: every AttachmentRef.bytes location', () => {
  for (const literal of ['9007199254740993', '1e400', '1e1000000', '-0']) {
    it(`accepts and preserves ${literal} at six paths`, () => {
      for (const input of byteLocations(numberFrom(literal))) {
        const result = judgeContentBlock(input)
        expect('ok' in result, literal).toBe(true)
        if ('ok' in result) expect(writeJsonLossless(result.ok)).toContain(`"bytes":${literal}`)
      }
    })
  }

  for (const literal of ['-1e400', '-0.1', '0.5', '1.0000000000000001']) {
    it(`rejects exact negative or nonintegral ${literal} at six paths`, () => {
      for (const input of byteLocations(numberFrom(literal))) {
        expect(judgeContentBlock(input), literal).toEqual({ rejected: 'malformed' })
      }
    })
  }
})
