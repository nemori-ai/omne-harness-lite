import type { CapabilityId, Modality } from './types.ts'

// Same anchored grammar as the frozen MediaType definition.
const MEDIA_TYPE =
  /^[a-z0-9][a-z0-9!#$&^_.+-]{0,126}\/[a-z0-9][a-z0-9!#$&^_.+-]{0,126}(?:;[a-z0-9!#$%&'*+.^_`|~-]+=[A-Za-z0-9!#$%&'*+.^_`|~-]+)*(?![\s\S])/

export function isCanonicalMediaType(value: string): boolean {
  return MEDIA_TYPE.test(value)
}

export function modalityOf(mediaType: string): Modality | undefined {
  if (!isCanonicalMediaType(mediaType)) return undefined
  const type = mediaType.slice(0, mediaType.indexOf('/'))
  switch (type) {
    case 'text':
    case 'image':
    case 'audio':
    case 'video':
      return type
    default:
      return undefined
  }
}

export function capabilityIdEquals(a: CapabilityId, b: CapabilityId): boolean {
  return a.category === b.category && a.name === b.name
}
