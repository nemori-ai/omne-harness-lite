import { describe, expect, it } from 'vitest'
import { readJsonStrict, writeJsonLossless, type JsonValue } from '../src/index.ts'
import { isLosslessNumber } from '../src/json.ts'

function decoded(text: string): JsonValue {
  const result = readJsonStrict(text)
  if ('failed' in result) throw new Error(`unexpected parse failure: ${result.failed}`)
  return result.ok
}

describe('strict lossless JSON', () => {
  it('keeps exact decimal values, signed zero and huge exponents without Number conversion', () => {
    const literals = [
      '9007199254740993',
      '0.1000000000000000055511151231257827',
      '1e400',
      '1e1000000',
      '1.0000000000000001',
      '-0',
      '-0.0',
    ]
    for (const literal of literals) {
      const value = decoded(literal)
      expect(isLosslessNumber(value), literal).toBe(true)
      expect(writeJsonLossless(value), literal).toBe(literal)
      expect(writeJsonLossless(decoded(writeJsonLossless(value))), literal).toBe(literal)
    }
    for (const literal of ['0.1', '42', '1.0', '1e0']) {
      const value = decoded(literal)
      expect(typeof value, literal).toBe('number')
      expect(writeJsonLossless(value)).toBe('1.0' === literal || '1e0' === literal ? '1' : literal)
    }
  })

  it('rejects duplicate decoded keys at every depth, before returning a partial value', () => {
    for (const text of [
      '{"a":1,"a":2}',
      '{"a":1,"\\u0061":2}',
      '{"x":[{"y":1,"\\u0079":2}]}',
      '{"__proto__":1,"__proto__":2}',
    ]) {
      expect(readJsonStrict(text)).toEqual({ failed: 'duplicate_member' })
    }
    expect(readJsonStrict('{"a":1,}')).toEqual({ failed: 'syntax' })
  })

  it('preserves __proto__ as a data key, escaping, arrays and absent versus null', () => {
    const value = decoded(
      '{"__proto__":{"x":1},"text":"a\\n\\u0062","array":[null,9007199254740993]}',
    )
    expect(writeJsonLossless(value)).toBe(
      '{"__proto__":{"x":1},"text":"a\\nb","array":[null,9007199254740993]}',
    )
    if (value === null || typeof value !== 'object') throw new Error('expected JSON object')
    expect(Object.hasOwn(value, '__proto__')).toBe(true)
    expect(Object.hasOwn(value, 'missing')).toBe(false)
  })

  it('does not accept a forged number-shaped object as an opaque numeric leaf', () => {
    expect(isLosslessNumber({ source: '9007199254740993' })).toBe(false)
    expect(isLosslessNumber(Object.create(null))).toBe(false)
    const genuine = decoded('9007199254740993')
    expect(isLosslessNumber(Object.create(Object.getPrototypeOf(genuine)))).toBe(false)
  })
})
