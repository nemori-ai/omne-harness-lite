import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { describe, expect, it } from 'vitest'
import {
  capabilityIdEquals,
  isCanonicalMediaType,
  judgeContentBlock,
  modalityOf,
  readJsonStrict,
  writeJsonLossless,
  type JsonValue,
} from '../src/index.ts'

const specSchema = resolve(
  import.meta.dirname,
  '../../../../.meta_harness/design/spec/data/content-blocks/v2/content-blocks.schema.json',
)

function strict(text: string): JsonValue {
  const result = readJsonStrict(text)
  if ('failed' in result) throw new Error(result.failed)
  return result.ok
}

const visibility = { toHuman: true, toModel: true }

function numericKeywordLocations(value: unknown, path = ''): string[] {
  if (value === null || typeof value !== 'object') return []
  const hits: string[] = []
  for (const [key, child] of Object.entries(value)) {
    const next = `${path}/${key}`
    if (
      (key === 'type' &&
        (child === 'integer' ||
          child === 'number' ||
          (Array.isArray(child) && child.some(item => item === 'integer' || item === 'number')))) ||
      [
        'minimum',
        'maximum',
        'exclusiveMinimum',
        'exclusiveMaximum',
        'multipleOf',
        'uniqueItems',
      ].includes(key) ||
      (key === 'const' && typeof child === 'number') ||
      (key === 'enum' && Array.isArray(child) && child.some(item => typeof item === 'number'))
    )
      hits.push(`${next}=${String(child)}`)
    hits.push(...numericKeywordLocations(child, next))
  }
  return hits
}

describe('CB1 local shape and helpers', () => {
  it('keeps the frozen Schema byte identical and guards the only numeric constraint', () => {
    // The authoritative path is supplied by the task environment, not package runtime.
    const original = readFileSync(specSchema)
    const copy = readFileSync(resolve(import.meta.dirname, '../schema/content-blocks.schema.json'))
    expect(copy.equals(original)).toBe(true)
    const schema: unknown = JSON.parse(copy.toString('utf8'))
    const allowed = [
      '/$defs/AttachmentRef/properties/bytes/type=integer',
      '/$defs/AttachmentRef/properties/bytes/minimum=0',
    ]
    expect(numericKeywordLocations(schema)).toEqual(allowed)

    const changed: unknown = JSON.parse(copy.toString('utf8'))
    if (changed === null || typeof changed !== 'object' || !('$defs' in changed)) {
      throw new Error('invalid Schema test fixture')
    }
    const defs = changed.$defs
    if (defs === null || typeof defs !== 'object' || !('AttachmentRef' in defs)) {
      throw new Error('missing attachment definition')
    }
    const attachment = defs.AttachmentRef
    if (attachment === null || typeof attachment !== 'object' || !('properties' in attachment)) {
      throw new Error('missing attachment properties')
    }
    const properties = attachment.properties
    if (properties === null || typeof properties !== 'object' || !('bytes' in properties)) {
      throw new Error('missing bytes property')
    }
    const bytes = properties.bytes
    if (bytes === null || typeof bytes !== 'object') throw new Error('invalid bytes property')
    Object.assign(bytes, { maximum: 42, enum: [1, 2] })
    expect(numericKeywordLocations(changed)).not.toEqual(allowed)
  })

  it('uses the exact media grammar and category/name equality', () => {
    expect(isCanonicalMediaType('audio/pcm;rate=24000')).toBe(true)
    for (const bad of ['Audio/pcm', 'audio/pcm ', 'audio/*', 'audio/pcm;Rate=1', 'audio/pcm\n']) {
      expect(isCanonicalMediaType(bad), bad).toBe(false)
    }
    expect(modalityOf('video/mp4')).toBe('video')
    expect(modalityOf('application/pdf')).toBeUndefined()
    expect(
      capabilityIdEquals({ category: 'tool', name: 'A' }, { category: 'tool', name: 'A' }),
    ).toBe(true)
    expect(
      capabilityIdEquals({ category: 'tool', name: 'A' }, { category: 'skill', name: 'A' }),
    ).toBe(false)
  })

  it('accepts lossless attachment lengths through the private view and freezes an independent copy', () => {
    const input = strict(
      '{"id":"b0","kind":"file","visibility":{"toHuman":true,"toModel":false},"attachment":{"storage":"s","key":"k","mediaType":"video/mp4","bytes":9007199254740993}}',
    )
    const before = writeJsonLossless(input)
    const result = judgeContentBlock(input)
    expect('ok' in result).toBe(true)
    if (!('ok' in result)) return
    expect(writeJsonLossless(result.ok)).toBe(before)
    expect(Object.isFrozen(result.ok)).toBe(true)
    expect(Object.isFrozen(result.ok.visibility)).toBe(true)
    if (result.ok.kind !== 'file') throw new Error('expected file block')
    expect(Object.isFrozen(result.ok.attachment)).toBe(true)
    expect(Object.isFrozen(input)).toBe(false)
    expect(writeJsonLossless(input)).toBe(before)
    expect(result.ok).not.toBe(input)
  })

  it('classifies large and fractional lengths exactly, including nested and offloaded', () => {
    for (const literal of ['1e400', '9007199254740993', '1.0e400', '-0']) {
      const input = strict(
        `{"id":"b0","kind":"file","visibility":{"toHuman":true,"toModel":false},"attachment":{"storage":"s","key":"k","mediaType":"application/pdf","bytes":${literal}}}`,
      )
      const result = judgeContentBlock(input)
      expect('ok' in result, literal).toBe(true)
      if ('ok' in result) expect(writeJsonLossless(result.ok)).toContain(`"bytes":${literal}`)
    }
    for (const literal of ['-1e400', '-0.1', '0.5', '1.0000000000000001']) {
      const input = strict(
        `{"id":"b0","kind":"file","visibility":{"toHuman":true,"toModel":false},"attachment":{"storage":"s","key":"k","mediaType":"application/pdf","bytes":${literal}}}`,
      )
      expect(judgeContentBlock(input), literal).toEqual({ rejected: 'malformed' })
    }
    const nested = strict(
      '{"id":"b0","kind":"tool_result","visibility":{"toHuman":true,"toModel":true},"callId":"c0","outcome":"completed","blocks":[{"id":"b1","kind":"file","visibility":{"toHuman":true,"toModel":true},"attachment":{"storage":"s","key":"k","mediaType":"application/pdf","bytes":9007199254740993}}],"offloaded":{"storage":"s","key":"k2","mediaType":"application/pdf","bytes":1e400}}',
    )
    const result = judgeContentBlock(nested)
    expect('ok' in result).toBe(true)
    if ('ok' in result) expect(writeJsonLossless(result.ok)).toContain('"bytes":1e400')
  })

  it('distinguishes genuine numeric visibility from a missing visibility object', () => {
    expect(
      judgeContentBlock(strict('{"id":"b0","kind":"text","text":"x","visibility":1e400}')),
    ).toEqual({ rejected: 'malformed' })
    expect(judgeContentBlock({ id: 'b0', kind: 'text', text: 'x' })).toEqual({
      rejected: 'visibility_missing',
    })
  })

  it('keeps named rejection priority ahead of a malformed numeric leaf', () => {
    const visibleHalfCall = strict(
      '{"id":"b0","kind":"tool_call","complete":false,"rawArguments":"","visibility":{"toHuman":true,"toModel":false},"extra":1e400}',
    )
    expect(judgeContentBlock(visibleHalfCall)).toEqual({ rejected: 'incomplete_call_visible' })
    const unknownKind = strict(
      '{"id":"b0","kind":"video","visibility":{"toHuman":true,"toModel":true},"bytes":-1e400}',
    )
    expect(judgeContentBlock(unknownKind)).toEqual({ rejected: 'kind_unknown' })
  })

  it('does not mutate caller-owned objects or let later mutation change the accepted value', () => {
    const input = {
      id: 'b0',
      kind: 'thinking',
      visibility: { ...visibility },
      text: '',
      opaque: { nested: [1, { key: 'before' }] },
    }
    const result = judgeContentBlock(input)
    expect('ok' in result).toBe(true)
    if (!('ok' in result)) return
    input.opaque.nested[1] = { key: 'after' }
    input.visibility.toHuman = false
    expect(result.ok.visibility.toHuman).toBe(true)
    expect(writeJsonLossless(result.ok)).toContain('"key":"before"')
    if (result.ok.kind !== 'thinking') throw new Error('expected thinking block')
    expect(Object.isFrozen(result.ok.opaque)).toBe(true)
  })

  it('rejects cycles and non-JSON leaves without returning a repaired value', () => {
    const cyclic: Record<string, unknown> = { id: 'b0', kind: 'thinking', text: '', visibility }
    cyclic.opaque = cyclic
    expect(judgeContentBlock(cyclic)).toEqual({ rejected: 'malformed' })
    expect(
      judgeContentBlock({ id: 'b0', kind: 'text', text: 'x', visibility, extra: undefined }),
    ).toEqual({ rejected: 'malformed' })
    const sparse = [1, , 3]
    expect(
      judgeContentBlock({ id: 'b0', kind: 'thinking', text: '', visibility, opaque: sparse }),
    ).toEqual({ rejected: 'malformed' })
    const sparseWithNamedProperties = Object.assign(new Array<number>(2), { a: 1, b: 2 })
    expect(
      judgeContentBlock({
        id: 'b0',
        kind: 'thinking',
        text: '',
        visibility,
        opaque: sparseWithNamedProperties,
      }),
    ).toEqual({ rejected: 'malformed' })
    const hidden = {}
    Object.defineProperty(hidden, 'important', { value: 'kept?', enumerable: false })
    expect(
      judgeContentBlock({ id: 'b0', kind: 'thinking', text: '', visibility, opaque: hidden }),
    ).toEqual({ rejected: 'malformed' })
  })

  it('never evaluates a getter while judging an invalid object', () => {
    const input = { id: 'b0', text: '', visibility }
    Object.defineProperty(input, 'kind', {
      get() {
        throw new Error('getter-invoked')
      },
      enumerable: true,
    })
    expect(judgeContentBlock(input)).toEqual({ rejected: 'malformed' })
    let called = false
    const withSafeUnknownKind = { id: 'b0', kind: 'video', visibility }
    Object.defineProperty(withSafeUnknownKind, 'extra', {
      get() {
        called = true
        throw new Error('getter-invoked')
      },
      enumerable: true,
    })
    expect(judgeContentBlock(withSafeUnknownKind)).toEqual({ rejected: 'kind_unknown' })
    expect(called).toBe(false)
  })

  it('revisits a shared child when the result-container context changes', () => {
    const nestedCall = {
      id: 'call-block',
      kind: 'tool_call',
      complete: true,
      callId: 'call-id',
      tool: 'read_file',
      visibility,
      arguments: {},
    }
    const sharedImage = {
      id: 'shared',
      kind: 'image',
      visibility,
      mediaType: 'image/png',
      data: { inline: 'iVBORw0KGgo=' },
      renderings: [{ producedBy: 'system', blocks: [nestedCall] }],
      transcript: 'image',
    }
    const input = {
      id: 'root',
      kind: 'tool_result',
      visibility,
      callId: 'root-call',
      outcome: 'completed',
      blocks: [sharedImage],
      renderings: [{ producedBy: 'system', blocks: [sharedImage] }],
    }
    expect(judgeContentBlock(input)).toEqual({ rejected: 'call_in_result' })
  })
})
