import { describe, expectTypeOf, it } from 'vitest'
import type {
  BlockId,
  CallId,
  ContentBlock,
  JsonNumber,
  LosslessNumber,
  Modality,
  ToolCallBlock,
  Visibility,
} from '../src/index.ts'

describe('public types', () => {
  it('keeps distinct identifiers and closed modalities', () => {
    expectTypeOf<BlockId>().not.toMatchTypeOf<CallId>()
    expectTypeOf<Modality>().toEqualTypeOf<'text' | 'image' | 'audio' | 'video'>()
  })
  it('exposes lossless numbers as numeric leaves and a discriminated block union', () => {
    expectTypeOf<LosslessNumber>().toMatchTypeOf<JsonNumber>()
    expectTypeOf<
      Extract<ContentBlock, { kind: 'tool_call'; complete: true }>
    >().toEqualTypeOf<ToolCallBlock>()
  })
  it('requires exactly one complete-call parameter shape', () => {
    type Base = {
      id: BlockId
      visibility: Visibility
      kind: 'tool_call'
      complete: true
      callId: CallId
      tool: string
    }
    expectTypeOf<Base & { arguments: null }>().toMatchTypeOf<ToolCallBlock>()
    expectTypeOf<
      Base & { arguments: null; rawArguments: string; unparseable: true }
    >().not.toMatchTypeOf<ToolCallBlock>()
    expectTypeOf<Base>().not.toMatchTypeOf<ToolCallBlock>()
  })
})
