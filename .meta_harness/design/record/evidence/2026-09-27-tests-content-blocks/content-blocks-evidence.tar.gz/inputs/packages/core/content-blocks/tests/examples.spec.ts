import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { Ajv2020 } from 'ajv/dist/2020.js'
import { describe, expect, it } from 'vitest'
import { isCanonicalMediaType, judgeContentBlock, readJsonStrict } from '../src/index.ts'

const specDir = resolve(
  import.meta.dirname,
  '../../../../.meta_harness/design/spec/data/content-blocks/v2',
)
const schema = JSON.parse(readFileSync(resolve(specDir, 'content-blocks.schema.json'), 'utf8')) as {
  $id: string
  $defs: Record<string, unknown>
}
const examples = readFileSync(resolve(specDir, 'examples.md'), 'utf8')
const ajv = new Ajv2020({
  strict: true,
  strictRequired: false,
  strictTypes: false,
  allErrors: false,
})
ajv.addSchema(schema)

interface Example {
  readonly section: number
  readonly line: number
  readonly defName: string
  readonly source: string
  readonly schemaExpected: '通过' | '拒绝'
  readonly rejection: string | undefined
}

function rows(): Example[] {
  const found: Example[] = []
  let section = 0
  let defName = ''
  for (const [index, line] of examples.split('\n').entries()) {
    const heading = /^## (\d+)\./.exec(line)
    if (heading !== null) {
      section = Number(heading[1])
      defName = ''
      continue
    }
    if (section < 1 || section > 13) continue
    if (section !== 13) {
      const target = /\*\*校验对象\*\*：`\$defs\/(\w+)`/.exec(line)
      if (target !== null) defName = target[1] ?? ''
    }
    let match: RegExpExecArray | null
    if (section === 13) {
      match = /^\| `\$defs\/(\w+)` \| `([^\`]+)` \| (通过|拒绝) \| (—|`(\w+)`) \|/.exec(line)
      if (match === null) continue
      found.push({
        section,
        line: index + 1,
        defName: match[1] ?? '',
        source: match[2] ?? '',
        schemaExpected: match[3] === '通过' ? '通过' : '拒绝',
        rejection: match[5],
      })
    } else {
      match = /^\| `([^\`]+)` \| (通过|拒绝) \| (—|`(\w+)`) \|/.exec(line)
      if (match === null) continue
      found.push({
        section,
        line: index + 1,
        defName,
        source: match[1] ?? '',
        schemaExpected: match[2] === '通过' ? '通过' : '拒绝',
        rejection: match[4],
      })
    }
  }
  return found
}

const examplesRows = rows()

describe('frozen content-blocks v2 examples, sections 1–13', () => {
  it('reads every normative machine-check row and its named definition', () => {
    expect(examplesRows).toHaveLength(162)
    expect(examplesRows.filter(row => row.schemaExpected === '通过')).toHaveLength(60)
    expect(examplesRows.filter(row => row.schemaExpected === '拒绝')).toHaveLength(102)
    expect(new Set(examplesRows.filter(row => row.defName === '').map(row => row.line))).toEqual(
      new Set(),
    )
    for (const row of examplesRows) expect(row.defName in schema.$defs).toBe(true)
  })

  for (const row of examplesRows) {
    it(`section ${row.section} line ${row.line}: ${row.defName} Schema and owned boundary`, () => {
      const parsed = readJsonStrict(row.source)
      expect('ok' in parsed, row.source).toBe(true)
      if (!('ok' in parsed)) return
      const validator = ajv.getSchema(`${schema.$id}#/$defs/${row.defName}`)
      expect(validator, row.defName).toBeDefined()
      expect(validator?.(parsed.ok), row.source).toBe(row.schemaExpected === '通过')
      if (row.defName === 'ContentBlock') {
        const judged = judgeContentBlock(parsed.ok)
        if (row.rejection === undefined) {
          expect('ok' in judged, row.source).toBe(true)
        } else {
          expect(judged, row.source).toEqual({ rejected: row.rejection })
        }
      }
      if (row.defName === 'MediaType') {
        expect(isCanonicalMediaType(parsed.ok as string), row.source).toBe(
          row.schemaExpected === '通过',
        )
      }
    })
  }
})
