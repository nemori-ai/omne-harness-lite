import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createServer } from 'node:net'
import { exchangeGovernance, readPublicHealth } from '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/packages/frontend/governance-center-client/dist/index.js'
import { bootAssembly } from '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/packages/core/kernel-basis/dist/testing/index.js'
import { generateHandoffKeyPair } from '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/packages/core/identity-values/dist/index.js'
import { composeMigrations } from '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/packages/core/storage/dist/index.js'
import { storageSqlPlugin } from '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/packages/infra/storage-sql/dist/index.js'
import { credentialsPlugin } from '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/packages/tenancy/credential-verification/dist/index.js'
import { accountIdentityPlugin, accountIdentityMigrations, ACCOUNT_TABLE, ACCOUNT_ID_COLUMN } from '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/packages/tenancy/account-identity/dist/index.js'
import { organizationGovernancePlugin, organizationGovernanceMigrations } from '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/packages/tenancy/organization-governance/dist/index.js'
import { registrationPlugin } from '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/packages/tenancy/account-registration/dist/index.js'
import { governanceCenterEntryPlugin, governanceCenterMigrations } from '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/packages/tenancy/governance-center-entry/dist/index.js'
const activation = generateHandoffKeyPair(), purge = generateHandoffKeyPair()
const reservation = createServer()
await new Promise(resolve => reservation.listen(0, '127.0.0.1', resolve))
const port = reservation.address().port
await new Promise(resolve => reservation.close(resolve))
const certs = '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/packages/tenancy/governance-center-entry/tests/fixtures/tls/'
let allowOpen
const openSignal = new Promise(resolve => { allowOpen = resolve })
const assembly = await bootAssembly({
  services: [{name: 'clock', value: {now: () => Date.UTC(2026,8,25)}}],
  plugins: [
    {plugin: storageSqlPlugin, config: { dialect: 'sqlite', file: '/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish/tmp/production-cli-onboarding/client2-integration/macos.sqlite', synchronous: 'full', migrations: composeMigrations([
      ...accountIdentityMigrations,
      ...organizationGovernanceMigrations({ownerAccountReference: {table: ACCOUNT_TABLE, column: ACCOUNT_ID_COLUMN}, ownerAccountForeignKey: 'org_owner_fk'}),
      ...governanceCenterMigrations,
    ]), upgrade: false}},
    {plugin: credentialsPlugin, config: {cost:1024,blockSize:8,parallelization:1,saltBytes:16,keyBytes:32}},
    {plugin: accountIdentityPlugin, config: {credentialPolicy: {minLength: 8}, unactivatedRetention: 3600000, activationVerificationKeyPem: activation.publicKeyPem, purgeVerificationKeyPem: purge.publicKeyPem}},
    {plugin: organizationGovernancePlugin, config: {invitationTtlDefault:3600000, affiliationRequestTtlDefault:3600000, teamCreationKeyRetention:86400000,purgeSigningKeyPem:purge.privateKeyPem}},
    {plugin: registrationPlugin, config: {activationSigningKeyPem:activation.privateKeyPem}},
    {plugin: governanceCenterEntryPlugin, config: { listen:{host:'127.0.0.1',port}, tls:{certificateChainPem:readFileSync(certs+'chain.pem','utf8'),privateKeyPem:readFileSync(certs+'leaf.key','utf8')}, version:'entry2-linux-probe',drainTimeoutMs:1000,clockReadyTimeoutMs:1000,openSignal}},
  ],
})
const ready = new Promise(resolve => assembly.ctx.on('governance-center-entry/serving', resolve))
allowOpen()
await ready
const og = n => `capability.organization-governance/v2#S-${n}`
const ai = n => `capability.account-identity/v3#S-${n}`
let expectedCenter
async function call(operation, payload, login) {
  const options = { url: `https://localhost:${port}/`, trust: {mode:'ca',certificateAuthorities:readFileSync(certs+'ca.pem')} }
  const health = await readPublicHealth(options)
  assert.equal(health.kind,'health')
  expectedCenter ??= health.reply.centerId
  assert.equal(health.reply.centerId,expectedCenter)
  const answer = await exchangeGovernance(options,{protocolVersion:'2',operation,payload,...(login ? {presentedLoginState:login.loginState} : {})})
  assert.equal(answer.sendAttempted,true)
  assert.notEqual(answer.kind,'unavailable')
  return answer.kind === 'reply' ? answer.reply : answer.answer
}

async function result(operation,payload,login) { const reply=await call(operation,payload,login);assert.ok(reply && typeof reply==='object' && 'result' in reply, 'expected successful operation');return reply.result }
try {
  for(const loginIdentifier of ['alice','bob']) assert.equal(await result('composition.account-registration/v2#S-8',{loginIdentifier,credential:'original-password'}),'registered')
  const alice = await result(ai(15),{loginIdentifier:'alice',credential:'original-password'})
  const bob = await result(ai(15),{loginIdentifier:'bob',credential:'original-password'})
  const personal = await result(og(36),{},alice)
  const team = await result(og(21),{creationKey:'linux-team'},alice)
  const tenant={organization:team,account:personal.account}
  assert.equal(await result(og(37),{expectedTenant:personal,targetTenant:tenant},alice),'ok')
  assert.deepEqual(await call(og(58),{expectedTenant:personal},alice),{failure:'expectedTenantMismatch'})
  const invitation=await result('composition.governance-center-entry/v2#S-50',{expectedTenant:tenant,loginIdentifier:'bob'},alice)
  assert.equal(await result(og(61),{invitation},bob),'ok')
  assert.deepEqual(await call(og(25),{invitation},bob),{failure:'offerNoLongerValid'})
  const list=await result(ai(37),{},alice)
  assert.deepEqual(Object.keys(list[0]),['loginStateHandle','issuedAt','lastActivityAt','absoluteExpiresAt','idleExpiresAt'])
  assert.equal(await result(ai(50),{currentCredential:'original-password',newCredential:'replacement-password'},alice),'ok')
  assert.equal(await call(og(27),{},alice),'login-state-rejected')
  const fresh=await result(ai(15),{loginIdentifier:'alice',credential:'replacement-password'})
  assert.equal(await result(ai(16),{loginStateHandle:fresh.loginStateHandle},fresh),'ok')
  assert.equal(await call(og(27),{},fresh),'login-state-rejected')
  console.log(JSON.stringify({status:'PASS',platform:process.platform,arch:process.arch,node:process.version,checks:['registration/login','create/switch','stale identity rejection','named invitation/decline','bounded login list','credential change invalidates old login','new login/logout'],scope:'Product governance client against built real provider assembly and HTTPS, with health binding check per call; not CLI/TUI, independent machine or disaster acceptance'}))
} finally { await assembly.dispose() }
