import type { Kysely } from 'kysely'

/**
 * 协议不为消费者的表建类型：`db` 是未收窄的 Kysely 实例，消费者用自己的表接口收窄（{@link narrow}）。
 * 这是 D-026 选定查询层的直接代价：换查询层等于换一版协议。
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type UntypedDb = Kysely<any>

export interface ReadTx {
  /** 绑定在本事务连接上的查询构建器。 */
  readonly db: UntypedDb
}

export interface WriteTx extends ReadTx {
  /** 对 key 命中的那一行取排他锁（P-4）；行不存在则什么也不锁。pg：`FOR UPDATE`；sqlite：`BEGIN IMMEDIATE` 下不发语句。 */
  lockRow(table: string, key: Readonly<Record<string, unknown>>): Promise<void>
  /** 部署级互斥（P-5）：同名的另一个写事务在本事务结束前不进入其 `lockSentinel` 之后的部分。 */
  lockSentinel(name: string): Promise<void>
}

export interface Storage {
  /** 一次只读事务：整个 fn 内看到同一个已提交快照（P-6）；fn 内的写语句 ⇒ `StorageDefect`。 */
  read<T>(fn: (tx: ReadTx) => Promise<T>): Promise<T>
  /**
   * 一次写事务（P-1）：fn 正常返回 ⇒ 提交并返回其值；fn 抛出 ⇒ 回滚并**原样**上抛。
   * 语句级失败不废事务（P-2）：`UniqueViolation`／`ReferenceViolation` 之后同一 tx 仍可读写并提交。
   * 同一进程内并发发起的 write 不互相阻塞线程、不以 busy 失败（P-12）。
   */
  write<T>(fn: (tx: WriteTx) => Promise<T>): Promise<T>
}

/** 显式共同事务中的临时操作面；不是普通 Storage，也不代表独立提交。 */
export interface StorageUnit {
  /** 参与提供者必须核验自己使用的是同一存储实例。 */
  assertStorage(expected: Storage): void
  /** 顺序参与操作可嵌套；逃出此边界的异常使整单元不可提交。 */
  run<T>(fn: () => Promise<T>): Promise<T>
  /** 同一写事务上的查询；只给只读类型，不承诺 query_only。 */
  query<T>(fn: (tx: ReadTx) => Promise<T>): Promise<T>
  /** 暂存写入。P-2 冲突仅可在所属 run 内处理，不可恢复异常不得吞掉。 */
  mutate<T>(fn: (tx: WriteTx) => Promise<T>): Promise<T>
  /** 真正提交后尽力通知；不等待，不提供可靠投递。不得携带秘密。 */
  afterCommit(notify: () => void): void
}

/** 显式扩展，不改变普通 read/write 的独立提交或嵌套拒绝。 */
export interface AtomicStorage extends Storage {
  atomic<T>(fn: (unit: StorageUnit) => Promise<T>): Promise<T>
}

/** 提供者实例（套件与装配用）：`close` 关准入 → 等在途 → 关句柄，之后的 read/write ⇒ `StorageUnavailable`。 */
export interface StorageInstance extends Storage {
  close(): Promise<void>
}

/** 消费者按自己的表接口收窄 `db`。只是类型断言：协议不核对表是否存在，那由装配的迁移与消费者的测试保证。 */
export function narrow<DB>(tx: ReadTx): Kysely<DB> {
  return tx.db as Kysely<DB>
}
