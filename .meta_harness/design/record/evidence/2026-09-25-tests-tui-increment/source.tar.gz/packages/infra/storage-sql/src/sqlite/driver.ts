// 自写 node:sqlite Driver：一个写句柄 + 进程内写队列；读句柄独立、query_only=ON；BEGIN IMMEDIATE 忙时异步重试（P-12）。
// 复用 kysely 的 SqliteAdapter / SqliteQueryCompiler / SqliteIntrospector。
import { DatabaseSync } from 'node:sqlite'
import {
  CompiledQuery,
  SqliteAdapter,
  SqliteIntrospector,
  SqliteQueryCompiler,
  type DatabaseConnection,
  type Dialect,
  type Driver,
  type Kysely,
  type QueryResult,
  type TransactionSettings,
} from 'kysely'
import { StorageUnavailable } from '@omne-harness-lite/storage'
import { isSqliteBusy, translateSqliteError, type StatementKind } from './errors.ts'
import { UniqueConstraintResolver } from './constraints.ts'

export interface NodeSqliteDialectOptions {
  readonly file: string
  /** 缺省 NORMAL；治理中心装配按 D-039 显式选 FULL。 */
  readonly synchronous?: 'normal' | 'full'
  /** 本 Kysely 实例只做读或只做写：提供者为两种事务各开一个实例，事务种类因此在构造期就定了。 */
  readonly role: 'write' | 'read'
  /** 写锁争用的总等待上限；超过 ⇒ StorageUnavailable。 */
  readonly writeLockTimeoutMs?: number
}

const WRITE_LOCK_TIMEOUT_MS = 5000
/** 读句柄上限（候选常量）：峰值并发读之外的调用排队等释放，不无限开句柄。 */
const MAX_READERS = 4
const RETRY_BACKOFF_MS = [1, 2, 4, 8, 16, 32, 50] as const

const sleep = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms))

function statementKind(sql: string): StatementKind {
  const head = sql.trimStart().slice(0, 6).toLowerCase()
  if (head.startsWith('select') || head.startsWith('with') || head.startsWith('pragma'))
    return 'select'
  if (head.startsWith('insert')) return 'insert'
  if (head.startsWith('update')) return 'update'
  if (head.startsWith('delete')) return 'delete'
  return 'other'
}

function returnsRows(sql: string): boolean {
  const head = sql.trimStart().toLowerCase()
  return (
    head.startsWith('select') ||
    head.startsWith('with') ||
    head.startsWith('pragma') ||
    / returning /i.test(sql)
  )
}

class NodeSqliteConnection implements DatabaseConnection {
  constructor(
    readonly db: DatabaseSync,
    readonly role: 'write' | 'read',
    private readonly resolver: UniqueConstraintResolver,
  ) {}

  async executeQuery<R>(compiled: CompiledQuery): Promise<QueryResult<R>> {
    const kind = statementKind(compiled.sql)
    try {
      const statement = this.db.prepare(compiled.sql)
      const parameters = compiled.parameters as readonly (
        null | number | bigint | string | Uint8Array
      )[]
      if (returnsRows(compiled.sql)) {
        const rows = statement.all(...parameters) as R[]
        return { rows }
      }
      const result = statement.run(...parameters)
      return {
        rows: [],
        numAffectedRows: BigInt(result.changes),
        insertId: BigInt(result.lastInsertRowid),
      }
    } catch (error) {
      throw translateSqliteError(
        error,
        kind,
        message => this.resolver.resolve(this.db, message),
        this.role,
      )
    }
  }

  // eslint-disable-next-line require-yield
  async *streamQuery<R>(): AsyncIterableIterator<QueryResult<R>> {
    throw new Error(
      'streamQuery is not supported by the node:sqlite driver (the storage protocol has no streaming read face)',
    )
  }
}

export class NodeSqliteDriver implements Driver {
  #writer: NodeSqliteConnection | undefined
  #readers: NodeSqliteConnection[] = []
  #openReaders = 0
  #readerWaiters: ((c: DatabaseConnection) => void)[] = []
  #writeQueue: Promise<void> = Promise.resolve()
  #closed = false
  readonly #resolver = new UniqueConstraintResolver()

  constructor(private readonly options: NodeSqliteDialectOptions) {}

  async init(): Promise<void> {
    if (this.options.role === 'write') {
      this.#writer = new NodeSqliteConnection(this.#open('write'), 'write', this.#resolver)
    } else {
      // 读句柄按需开；这里开一个以便打开失败在启动期暴露
      this.#readers.push(new NodeSqliteConnection(this.#open('read'), 'read', this.#resolver))
      this.#openReaders = 1
    }
  }

  #open(role: 'write' | 'read'): DatabaseSync {
    const db = new DatabaseSync(this.options.file, {
      enableForeignKeyConstraints: true,
      timeout: role === 'write' ? 0 : 5000,
    })
    try {
      db.exec('PRAGMA journal_mode = WAL')
      db.exec(
        this.options.synchronous === 'full'
          ? 'PRAGMA synchronous = FULL'
          : 'PRAGMA synchronous = NORMAL',
      )
      db.exec('PRAGMA foreign_keys = ON')
      if (role === 'read') db.exec('PRAGMA query_only = ON')
      return db
    } catch (error) {
      // The pool does not own this handle until initialization succeeds.
      try {
        db.close()
      } catch (closing) {
        throw new AggregateError([error, closing], 'sqlite initialization and cleanup failed')
      }
      throw error
    }
  }

  async acquireConnection(): Promise<DatabaseConnection> {
    if (this.#closed) throw new StorageUnavailable('sqlite storage is closed')
    if (this.options.role === 'read') {
      const idle = this.#readers.pop()
      if (idle !== undefined) return idle
      if (this.#openReaders < MAX_READERS) {
        const connection = new NodeSqliteConnection(this.#open('read'), 'read', this.#resolver)
        this.#openReaders += 1
        return connection
      }
      // 到上限：排队等一个读句柄被释放
      return new Promise<DatabaseConnection>(resolve => this.#readerWaiters.push(resolve))
    }
    if (this.#writer === undefined) throw new StorageUnavailable('sqlite storage is closed')
    // 写：进程内队列，同一实例的多个 write 顺序共用一个句柄
    const previous = this.#writeQueue
    let release!: () => void
    this.#writeQueue = new Promise<void>(resolve => {
      release = resolve
    })
    await previous
    if (this.#closed || this.#writer === undefined) {
      release()
      throw new StorageUnavailable('sqlite storage is closed')
    }
    this.#writerRelease = release
    return this.#writer
  }
  #writerRelease: (() => void) | undefined

  async beginTransaction(
    connection: DatabaseConnection,
    settings: TransactionSettings,
  ): Promise<void> {
    const c = connection as NodeSqliteConnection
    if (c.role === 'read') {
      c.db.exec('BEGIN')
      return
    }
    if (settings.accessMode === 'read only')
      throw new Error('read transaction requested on the write handle (provider bug)')
    const deadline = Date.now() + (this.options.writeLockTimeoutMs ?? WRITE_LOCK_TIMEOUT_MS)
    let attempt = 0
    for (;;) {
      try {
        c.db.exec('BEGIN IMMEDIATE')
        return
      } catch (error) {
        if (!isSqliteBusy(error) || Date.now() >= deadline) {
          throw translateSqliteError(error, 'other', () => undefined)
        }
        await sleep(RETRY_BACKOFF_MS[Math.min(attempt, RETRY_BACKOFF_MS.length - 1)]!)
        attempt += 1
      }
    }
  }

  async commitTransaction(connection: DatabaseConnection): Promise<void> {
    const c = connection as NodeSqliteConnection
    try {
      c.db.exec('COMMIT')
    } catch (error) {
      throw translateSqliteError(error, 'other', () => undefined)
    }
  }

  async rollbackTransaction(connection: DatabaseConnection): Promise<void> {
    const c = connection as NodeSqliteConnection
    try {
      if (c.db.isTransaction) c.db.exec('ROLLBACK')
    } catch (error) {
      throw translateSqliteError(error, 'other', () => undefined)
    }
  }

  async releaseConnection(connection: DatabaseConnection): Promise<void> {
    const c = connection as NodeSqliteConnection
    if (c.role === 'write') {
      const release = this.#writerRelease
      this.#writerRelease = undefined
      release?.()
      return
    }
    if (this.#closed) {
      c.db.close()
      return
    }
    const waiter = this.#readerWaiters.shift()
    if (waiter !== undefined) {
      waiter(c)
      return
    }
    this.#readers.push(c)
  }

  /** 关准入 → 等在途写排空 → 关全部句柄。 */
  async destroy(): Promise<void> {
    if (this.#closed) return
    this.#closed = true
    await this.#writeQueue
    this.#writer?.db.close()
    this.#writer = undefined
    for (const reader of this.#readers) reader.db.close()
    this.#readers = []
  }
}

export class NodeSqliteDialect implements Dialect {
  readonly driver: NodeSqliteDriver
  constructor(options: NodeSqliteDialectOptions) {
    this.driver = new NodeSqliteDriver(options)
  }
  createDriver(): Driver {
    return this.driver
  }
  createQueryCompiler() {
    return new SqliteQueryCompiler()
  }
  createAdapter() {
    return new SqliteAdapter()
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  createIntrospector(db: Kysely<any>) {
    return new SqliteIntrospector(db)
  }
}
