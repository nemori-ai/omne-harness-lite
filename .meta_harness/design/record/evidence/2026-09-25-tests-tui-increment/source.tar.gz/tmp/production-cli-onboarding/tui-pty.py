import os,pty,subprocess,termios,fcntl,struct,select,time,tempfile,signal,json,sys
node=sys.argv[1];cli=os.path.abspath('apps/cli/dist/main.js')
results=[]
for scenario in ['normal','signal','paste-signal','unsupported']:
 with tempfile.TemporaryDirectory(prefix='omne-tui-') as root:
  root=os.path.realpath(root)
  master,slave=pty.openpty();fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',40,100,0,0))
  original=termios.tcgetattr(slave)
  p=subprocess.Popen([node,cli,'tui','--terminal-profile','xterm-379','--state-dir',root+'/state','--setup'],stdin=slave,stdout=slave,stderr=slave,start_new_session=True)
  transcript=b'';mode=2;queries=0;began=False;entered=False;typing=None;tail_at=None;menu_at=None;deadline=time.monotonic()+10
  try:
   while time.monotonic()<deadline and p.poll() is None:
    ready,_,_=select.select([master],[],[],.02)
    if ready:
     chunk=os.read(master,65536);transcript+=chunk
     # Handle control protocol in actual stream order, not by substring class.
     scan=chunk
     import re
     for control in re.findall(rb'\x1b\[\?2004(?:h|l|\$p)',scan):
      if control.endswith(b'h'):mode=1
      elif control.endswith(b'l'):mode=2
      else:
       queries+=1;os.write(master,b'\x1b[?2004;'+str(0 if scenario=='unsupported' else mode).encode()+b'$y')
     if not began and b'One action per setup invocation' in transcript:
      began=True;menu_at=time.monotonic()
      if scenario=='normal':os.write(master,b'1');typing=time.monotonic()
      elif scenario=='signal':p.send_signal(signal.SIGTERM)
      elif scenario=='paste-signal':
       os.write(master,b'\x1b[200~unfinished');time.sleep(.05);p.send_signal(signal.SIGTERM);tail_at=time.monotonic()+.2
    if typing and not entered and time.monotonic()-typing>.08:
     os.write(master,b'\r');entered=True
    if tail_at and time.monotonic()>=tail_at:
     assert p.poll() is None,'exited before actual paste tail'
     assert mode==1,'restored mode before actual paste tail'
     os.write(master,b'\x1b[201~');tail_at=None
   if p.poll() is None:raise AssertionError('timeout: '+transcript[-1000:].decode(errors='replace'))
   while select.select([master],[],[],0)[0]:
    try:transcript+=os.read(master,65536)
    except OSError:break
   expected=2 if scenario=='unsupported' else 0
   assert p.returncode==expected,(scenario,p.returncode,transcript[-1500:])
   assert termios.tcgetattr(slave)==original,'OS attributes not restored'
   assert mode==2,'2004 not restored'
   results.append({'scenario':scenario,'status':'PASS','exit':p.returncode,'queries':queries,'termiosRestored':True,'modeRestored':True})
  finally:
   if p.poll() is None:p.kill();p.wait()
   os.close(master);os.close(slave)
print(json.dumps({'status':'PASS','platform':sys.platform,'cases':results,'scope':'real Node subprocess and PTY/OS termios; scripted terminal mode responses, not actual emulator or IME'},indent=2))
