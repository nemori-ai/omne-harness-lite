#!/bin/sh
set -eu
xterm -xrm 'XTerm*allowPasteControls: false' -geometry 110x40 -title OMNE-TUI-ACCEPTANCE -e node /work/tmp/production-cli-onboarding/tui-xterm-wrapper.mjs &
terminal_pid=$!
trap 'kill "$terminal_pid" 2>/dev/null || true' EXIT
window=''
for n in $(seq 1 100); do
  window=$(xdotool search --name '^OMNE-TUI-ACCEPTANCE$' 2>/dev/null || true)
  [ -n "$window" ] && break
  sleep .1
done
[ -n "$window" ]
xdotool windowfocus --sync "$window"
sleep 2
xdotool type --clearmodifiers --delay 100 '1'
sleep .2
xdotool key Return
for n in $(seq 1 100); do
  [ -f /work/tmp/production-cli-onboarding/tui-xterm-result.json ] && break
  sleep .1
done
cat /work/tmp/production-cli-onboarding/tui-xterm-result.json
wait "$terminal_pid"
trap - EXIT
