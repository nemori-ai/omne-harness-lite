import { spawn, execFileSync } from 'node:child_process'
import { writeFileSync } from 'node:fs'
const before=execFileSync('stty',['-g'],{stdio:[0,'pipe','pipe'],encoding:'utf8'}).trim()
const child=spawn(process.execPath,['/work/apps/cli/dist/main.js','tui','--setup','--terminal-profile','xterm-379','--state-dir','/tmp/tui-xterm-state'],{stdio:'inherit'})
const code=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',resolve)})
const after=execFileSync('stty',['-g'],{stdio:[0,'pipe','pipe'],encoding:'utf8'}).trim()
writeFileSync('/work/tmp/production-cli-onboarding/tui-xterm-result.json',JSON.stringify({code,termiosRestored:before===after,node:process.version,scope:'actual XTerm379 normal menu exit and OS attributes; not IME or full business journey'})+'\n')
if(code!==0||before!==after)process.exitCode=1
