import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { mkdtemp, realpath, writeFile, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { makeCa, makeServerCertificate, keygen, freePort, opsDirectory, envOf, opsSocketOf, SETTINGS, CenterProcess } from '../../apps/tenancy-host/tests/e2e/deploy.ts'
const root=await mkdtemp(join(await realpath(tmpdir()),'omne-tui-host-'))
const logs=[], results=[];const record=x=>logs.push(x)
const ca=makeCa(root,'ca',record),tls=makeServerCertificate(root,'leaf',ca,['DNS:localhost','IP:127.0.0.1'],record)
const deployment={dbFile:join(root,'center.sqlite'),keys:await keygen(join(root,'keys'),record),tls,host:'127.0.0.1',port:await freePort(),opsDir:opsDirectory(root),settings:SETTINGS}
const host=CenterProcess.serve('tui-center',envOf(deployment),record)
const cli=process.argv[3]??new URL('../../apps/cli/dist/main.js',import.meta.url).pathname
const drive=new URL('./tui-drive.py',import.meta.url).pathname
const state=join(root,'client'),secret='tui-test-credential-VERY-PRIVATE'
await writeFile(join(root,'credential'),secret,{mode:0o600})
async function processRun(command,args){return new Promise((resolve,reject)=>{const child=spawn(command,args,{stdio:['ignore','pipe','pipe']});let stdout='',stderr='';child.stdout.on('data',x=>stdout+=x);child.stderr.on('data',x=>stderr+=x);child.on('error',reject);child.on('close',code=>resolve({code,stdout,stderr}))})}
async function machine(args){const x=await processRun(process.execPath,[cli,'machine',...args,'--state-dir',state]);assert.equal(x.code,0,x.stderr+x.stdout);return JSON.parse(x.stdout)}
async function tui(name,setup,steps,exit=0){const input=join(root,name+'.json'),out=join(root,name+'-out.json');await writeFile(input,JSON.stringify({setup,steps,exit,secrets:[secret]}));const x=await processRun('python3',[drive,process.execPath,cli,state,input,out]);assert.equal(x.code,0,x.stderr+x.stdout);results.push({name,...JSON.parse(await readFile(out,'utf8'))})}
const s=(screen,value)=>({screen,value})
try{
 await host.ready(opsSocketOf(deployment))
 await machine(['center','configure','--endpoint',`https://localhost:${deployment.port}/`,'--ca-file',join(root,'ca.pem')])
 await tui('register',true,[s('Connection and login','2'),s('Login identifier','tui-alice'),s('Credential file',join(root,'credential')),s('Confirm: Register','2')])
 await tui('login',true,[s('Connection and login','3'),s('Login identifier','tui-alice'),s('Credential file',join(root,'credential')),s('Confirm: Login','2')])
 const before=(await machine(['tenant','current','--refresh'])).view.data.reply.result
 const forms=JSON.parse(await readFile(new URL('../../apps/cli/forms/forms.json',import.meta.url),'utf8')).filter(x=>x.phase==='governance')
 const menu=id=>String(forms.findIndex(x=>x.id===id)+3)
 await tui('create-organization',false,[s('Refresh identity and inboxes',menu('organization create')),s('Creation reference','1'),s('Confirm: Organization create','2'),s('Refresh identity and inboxes','1')])
 const all=(await machine(['tenant','list','--refresh'])).view.data.reply.result
 const target=all.find(t=>t.organization!==before.organization);assert.ok(target)
 await tui('switch',false,[s('Refresh identity and inboxes',menu('tenant switch')),s('Target tenant identity: account ID',target.account),s('Target tenant identity: organization ID',target.organization),s('Confirm: Tenant switch','2'),s('Refresh identity and inboxes','1')])
 assert.deepEqual((await machine(['tenant','current','--refresh'])).view.data.reply.result,target)
 await tui('logout',false,[s('Refresh identity and inboxes',menu('logout')),s('Confirm: Logout','2')],4)
 const x=await processRun(process.execPath,[cli,'machine','tenant','current','--state-dir',state]);assert.equal(x.code,4)
 await writeFile(process.argv[2],JSON.stringify({status:'PASS',platform:process.platform,checks:['TUI registration/login via protected files','initial fixed-use identity and inboxes','organization creation','identity switch followed by real current-tenant read','logout and machine CLI status parity','all PTY termios and mode restoration'],results,host:host.stderr(),commands:logs,scope:'real host/process/default credentials and PTY; scripted terminal replies, not simulator or IME'},null,2))
 console.log('PASS real host / TUI PTY integration')
}finally{if(host.running)await host.terminate().catch(()=>host.kill());await rm(root,{recursive:true,force:true})}
