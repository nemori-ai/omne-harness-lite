import os,pty,subprocess,termios,fcntl,struct,select,time,json,sys,re
# Main-line integration driver. Real PTY, scripted mode responses, no emulator claim.
node,cli,state,scenario_file,out=sys.argv[1:]
scenario=json.load(open(scenario_file));steps=list(scenario['steps']);done=[]
master,slave=pty.openpty();fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',50,110,0,0));original=termios.tcgetattr(slave)
p=subprocess.Popen([node,cli,'tui','--terminal-profile','xterm-379','--state-dir',state]+(['--setup'] if scenario.get('setup') else []),stdin=slave,stdout=slave,stderr=slave,start_new_session=True)
mode=2;transcript=b'';pending=b'';last=b'';action=None;deadline=time.monotonic()+45
try:
 while p.poll() is None and time.monotonic()<deadline:
  ready,_,_=select.select([master],[],[],.015)
  if ready:
   chunk=os.read(master,262144);transcript+=chunk;pending+=chunk
   for control in re.findall(rb'\x1b\[\?2004(?:h|l|\$p)',chunk):
    if control.endswith(b'h'):mode=1
    elif control.endswith(b'l'):mode=2
    else:os.write(master,b'\x1b[?2004;'+str(mode).encode()+b'$y')
   if b'\x1b[H\x1b[2J' in pending:
    frame=pending.rsplit(b'\x1b[H\x1b[2J',1)[1]
    if b'PgUp/PgDn: pages' in frame:
     text=re.sub(rb'\x1b\[[0-9;]*[A-Za-z]',b'',frame).decode('utf8',errors='strict')
     if frame!=last and action is None:
      last=frame;page=re.search(r'Page (\d+)/(\d+)',text)
      if page and int(page[1])<int(page[2]):action=(time.monotonic()+.04,'page',None)
      elif 'exit status' in text:action=(time.monotonic()+.04,'enter',None)
      elif steps and steps[0]['screen'] in text:
       step=steps.pop(0);done.append(step['screen']);action=(time.monotonic()+.04,'text',step['value'])
     pending=b'\x1b[H\x1b[2J'+frame
  if action and time.monotonic()>=action[0]:
   _,kind,value=action;action=None
   if kind=='page':os.write(master,b'\x1b[6~');last=b''
   elif kind=='enter':os.write(master,b'\r');last=b''
   else:
    os.write(master,b'\x1b[200~'+value.encode()+b'\x1b[201~');action=(time.monotonic()+.08,'enter',None)
 if p.poll() is None:raise AssertionError('TUI timeout, remaining='+repr(steps)+' last='+repr(transcript[-2000:]))
 while select.select([master],[],[],0)[0]:
  try:transcript+=os.read(master,262144)
  except OSError:break
 assert not steps,('unfinished steps',steps)
 assert p.returncode==scenario.get('exit',0),(p.returncode,transcript[-3000:])
 assert termios.tcgetattr(slave)==original,'termios not restored'
 assert mode==2,'2004 not restored'
 for secret in scenario.get('secrets',[]):assert secret.encode() not in transcript,'secret leaked'
 json.dump({'status':'PASS','exit':p.returncode,'steps':done,'termiosRestored':True,'modeRestored':True,'screen':transcript.decode('utf8')},open(out,'w'),ensure_ascii=False,indent=2)
finally:
 if p.poll() is None:p.kill();p.wait()
 os.close(master);os.close(slave)
