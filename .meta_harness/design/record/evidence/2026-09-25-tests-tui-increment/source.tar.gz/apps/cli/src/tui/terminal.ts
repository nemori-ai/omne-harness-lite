import { fstatSync } from 'node:fs'
import { InputFailure } from '../diagnostic.ts'
import { InputFramer, type TerminalInput } from './framer.ts'

export interface TerminalPort {
  readonly size: { readonly columns: number; readonly rows: number }
  listen(handler: (event: TerminalInput) => void, resized: () => void): void
  write(bytes: string): Promise<void>
  stopInput(): Promise<void>
  restore(): Promise<void>
}
function output(bytes: string): Promise<void> {
  return new Promise((resolve, reject) => {
    process.stdout.write(bytes, error =>
      error ? reject(new InputFailure('output-failed')) : resolve(),
    )
  })
}
class DirectTerminal implements TerminalPort {
  #handler: (event: TerminalInput) => void = () => {}
  #resized: () => void = () => {}
  #mode: ((value: number) => void) | undefined
  #changed = false
  #restored = false
  #eof = false
  readonly #framer = new InputFramer(event => {
    if (event.kind === 'mode') this.#mode?.(event.value)
    else {
      if (event.kind === 'eof') this.#eof = true
      this.#handler(event)
    }
  })
  readonly #data = (bytes: Buffer) => this.#framer.feed(bytes)
  readonly #end = () => this.#framer.eof()
  readonly #resize = () => this.#resized()
  readonly #error = () => this.#framer.eof()
  get size() {
    return { columns: process.stdout.columns, rows: process.stdout.rows }
  }
  listen(handler: (event: TerminalInput) => void, resized: () => void): void {
    this.#handler = handler
    this.#resized = resized
  }
  async start(): Promise<void> {
    process.stdin.setRawMode(true)
    process.stdin.on('data', this.#data)
    process.stdin.on('end', this.#end)
    process.stdin.on('error', this.#error)
    process.stdout.on('resize', this.#resize)
    process.stdin.resume()
    try {
      const mode = await this.#query()
      if (mode !== 1 && mode !== 2) throw new InputFailure('tty-unsupported')
      if (mode === 2) {
        // Set before writing: a failed/partial external write is not rollback.
        this.#changed = true
        await output('\x1b[?2004h')
        if ((await this.#query()) !== 1) throw new InputFailure('tty-unsupported')
      }
    } catch (error) {
      await this.stopInput()
      await this.restore()
      throw error
    }
  }
  async #query(): Promise<number> {
    if (this.#mode || this.#eof) throw new InputFailure('tty-unsupported')
    const pending = Promise.withResolvers<number>()
    const timer = setTimeout(() => pending.reject(new InputFailure('tty-unsupported')), 2000)
    this.#mode = pending.resolve
    // Observe rejection while an actual write is still outstanding. Awaiting that
    // write remains mandatory; the query timeout is not an output drain deadline.
    void pending.promise.catch(() => {})
    try {
      await output('\x1b[?2004$p')
      return await pending.promise
    } finally {
      clearTimeout(timer)
      this.#mode = undefined
    }
  }
  write(bytes: string): Promise<void> {
    return output(bytes)
  }
  stopInput(): Promise<void> {
    this.#handler = () => {}
    this.#resized = () => {}
    process.stdout.off('resize', this.#resize)
    return this.#framer.stop()
  }
  async restore(): Promise<void> {
    if (this.#restored) return
    let failed = false
    try {
      if (this.#changed) {
        await output('\x1b[?2004l')
        if ((await this.#query()) !== 2) failed = true
      }
    } catch {
      failed = true
    } finally {
      try {
        process.stdin.setRawMode(false)
      } catch {
        failed = true
      }
      process.stdin.pause()
      process.stdin.off('data', this.#data)
      process.stdin.off('end', this.#end)
      process.stdin.off('error', this.#error)
      process.stdout.off('resize', this.#resize)
      this.#framer.dispose()
      this.#restored = true
    }
    if (failed) throw new InputFailure('input-restore-failed')
  }
}
export async function openTerminal(profile: string): Promise<TerminalPort> {
  if (profile !== 'xterm-379') throw new InputFailure('tty-unsupported')
  if (!process.stdin.isTTY || !process.stdout.isTTY) throw new InputFailure('tty-required')
  const input = fstatSync(process.stdin.fd),
    screen = fstatSync(process.stdout.fd)
  if (
    !input.isCharacterDevice() ||
    !screen.isCharacterDevice() ||
    input.rdev !== screen.rdev ||
    process.stdin.isRaw ||
    process.stdin.readableFlowing === true ||
    process.stdin.listenerCount('data') !== 0 ||
    process.stdin.readableEncoding !== null ||
    process.stdout.columns < 60 ||
    process.stdout.rows < 16
  )
    throw new InputFailure('tty-unsupported')
  const terminal = new DirectTerminal()
  await terminal.start()
  return terminal
}
