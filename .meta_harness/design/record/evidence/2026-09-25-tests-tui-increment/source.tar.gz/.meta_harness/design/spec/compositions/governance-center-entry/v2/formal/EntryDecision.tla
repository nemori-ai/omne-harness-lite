---------------------------- MODULE EntryDecision ----------------------------
(* v2: classification order only. A "decision" is a temporary classification,
   not a sent reply or a committed result. S49 commit/reply obligations are
   separately modeled by EntryCommit; expected identity by ExpectedTenant.
   Late invalidity is an abstract input: inside the protected region it can
   represent clock expiry, and in a preparation gap it can also represent
   revocation/revision changes. This is not a SQL concurrency refinement.
   Concrete failure literals/route payloads are checked by the wire Schema. *)
EXTENDS Naturals, TLC

CONSTANT Mutation

Mutations == {"none",
              "passthroughStateNotValid",   \* ③ 读到「出示的登录状态已不作数」时原样透传
              "unavailableAsRejected",      \* ② 读不到时答「无效」
              "readPresentationBeforeVersion", \* 核版本之前先看出示物
              "inputBeforeAuth",            \* 要认人的路由先看载荷再认人
              "gateUnavailableAsDenied",    \* 补授权读不到时答成拒绝
              "defectAsResult",             \* 缺陷原样当结果交出
              "authBeforeEnvelope",         \* 要认人的路由先认人再核信封（①′ 排到 ② 之后）
              "deriveBeforePayload"}        \* 先做身份推导与补授权，再核载荷

ASSUME Mutation \in Mutations

(* 路由类别：公开体检；免认人（注册、登录）；要认人；要认人且有补授权。 *)
Routes     == {"publicHealth", "exempt", "auth", "authGated"}
AuthRoutes == {"auth", "authGated"}

(* 出示物的七种情形。前三种不用查就判得了；后四种要查（现读 AI S-44）。 *)
(* 拿 LoginStateId 当出示物，AI S-44 的答复与 neverIssued 相同，不另列。 *)
PresKinds     == {"absent", "multiple", "malformed",
                  "valid", "revoked", "neverIssued", "otherCenter"}
LookupFree    == {"absent", "multiple", "malformed"}
NotIssuedHere == {"revoked", "neverIssued", "otherCenter"}

(* 四种入口答复（S-6），加上公开体检答复与路由结果（领域成功值或具名结果原样透传）。 *)
EntryAnswers == {"versionMismatch", "loginStateRejected", "unavailable", "invalidInput"}
Replies      == EntryAnswers \cup {"health", "result"}

Stages == {"start", "envelope", "payloadEarly", "auth", "payload",
           "derive", "gate", "dispatch", "classified"}

VARIABLES
    route, versionOk, envelopeOk, pres, payloadOk,   \* 请求的形状，初始状态里定下
    pc, decision,
    invalidated,            \* 出示的登录状态已失效（时间/准备间隙的抽象输入）
    presentationRead,   \* 入口看过出示物
    passedAuth,         \* 第 ② 步认出了人
    postAuthRead,       \* 身份推导或补授权做过一次现读
    gatePassed,         \* 补授权通过
    domainCalled,       \* 领域操作被调用
    lookupFailed,       \* 本请求里某一次现读判不了
    rejectionJudged,    \* 「无效」是一次判出来的结论（不用查即知，或查到了）
    stateNotValidSeen,  \* ③ 或身份推导读到「出示的登录状态此刻不作数」
    defectRecorded      \* 某一次现读或领域操作给出了失败集合之外的东西（S-14 的缺陷）

vars == <<route, versionOk, envelopeOk, pres, payloadOk, pc, decision, invalidated,
          presentationRead, passedAuth, postAuthRead, gatePassed, domainCalled,
          lookupFailed, rejectionJudged, stateNotValidSeen, defectRecorded>>

TypeOK ==
    /\ route \in Routes
    /\ versionOk \in BOOLEAN /\ envelopeOk \in BOOLEAN /\ payloadOk \in BOOLEAN
    /\ pres \in PresKinds
    /\ pc \in Stages
    /\ decision \in Replies \cup {"none"}
    /\ invalidated \in BOOLEAN /\ presentationRead \in BOOLEAN /\ passedAuth \in BOOLEAN
    /\ postAuthRead \in BOOLEAN
    /\ gatePassed \in BOOLEAN /\ domainCalled \in BOOLEAN /\ lookupFailed \in BOOLEAN
    /\ rejectionJudged \in BOOLEAN /\ stateNotValidSeen \in BOOLEAN
    /\ defectRecorded \in BOOLEAN
    /\ (pc = "classified") <=> (decision # "none")

Init ==
    /\ route \in Routes
    /\ versionOk \in BOOLEAN
    /\ envelopeOk \in BOOLEAN
    /\ pres \in PresKinds
    /\ payloadOk \in BOOLEAN
    /\ pc = "start"
    /\ decision = "none"
    /\ invalidated = FALSE
    /\ presentationRead = FALSE
    /\ passedAuth = FALSE
    /\ postAuthRead = FALSE
    /\ gatePassed = FALSE
    /\ domainCalled = FALSE
    /\ lookupFailed = FALSE
    /\ rejectionJudged = FALSE
    /\ stateNotValidSeen = FALSE
    /\ defectRecorded = FALSE

Answer(r) == /\ decision' = r
             /\ pc' = "classified"

(* 缺陷对来者的答复：正确映射是 unavailable；变异 defectAsResult 把它当结果交出。 *)
DefectReply == IF Mutation = "defectAsResult" THEN "result" ELSE "unavailable"

(* S-18：公开体检不看版本、不看出示物、不读存储。 *)
PublicHealth ==
    /\ pc = "start" /\ route = "publicHealth"
    /\ Answer("health")
    /\ UNCHANGED <<route, versionOk, envelopeOk, pres, payloadOk, invalidated,
                   presentationRead, passedAuth, postAuthRead, gatePassed, domainCalled,
                   lookupFailed, rejectionJudged, stateNotValidSeen, defectRecorded>>

(* S-10 第 ① 步：版本核对先于一切；对不上只答 versionMismatch，不读出示物。 *)
CheckVersion ==
    /\ pc = "start" /\ route # "publicHealth"
    /\ presentationRead' = (Mutation = "readPresentationBeforeVersion" /\ route \in AuthRoutes)
    /\ IF ~versionOk
         THEN Answer("versionMismatch")
         ELSE /\ pc' = IF Mutation = "authBeforeEnvelope" /\ route \in AuthRoutes
                         THEN "auth" ELSE "envelope"
              /\ UNCHANGED decision
    /\ UNCHANGED <<route, versionOk, envelopeOk, pres, payloadOk, invalidated, passedAuth,
                   postAuthRead, gatePassed, domainCalled, lookupFailed, rejectionJudged,
                   stateNotValidSeen, defectRecorded>>

(* S-10 第 ①′ 步：信封本身（路由在不在表内、有无表外成员、成员有无重复）——不用查。 *)
CheckEnvelope ==
    /\ pc = "envelope"
    /\ IF ~envelopeOk
         THEN Answer("invalidInput")
         ELSE /\ pc' = IF route = "exempt" THEN "payload"
                       ELSE IF Mutation = "inputBeforeAuth" THEN "payloadEarly"
                       ELSE IF Mutation = "authBeforeEnvelope" THEN "payload"
                       ELSE "auth"
              /\ UNCHANGED decision
    /\ UNCHANGED <<route, versionOk, envelopeOk, pres, payloadOk, invalidated,
                   presentationRead, passedAuth, postAuthRead, gatePassed, domainCalled,
                   lookupFailed, rejectionJudged, stateNotValidSeen, defectRecorded>>

(* 变异 inputBeforeAuth 才会走到这一格：先看载荷，再认人。 *)
CheckPayloadEarly ==
    /\ pc = "payloadEarly"
    /\ IF ~payloadOk
         THEN Answer("invalidInput")
         ELSE /\ pc' = "auth"
              /\ UNCHANGED decision
    /\ UNCHANGED <<route, versionOk, envelopeOk, pres, payloadOk, invalidated,
                   presentationRead, passedAuth, postAuthRead, gatePassed, domainCalled,
                   lookupFailed, rejectionJudged, stateNotValidSeen, defectRecorded>>

(* S-11 第 ② 步：认人。不用查即判得了的三种照判「无效」；要查的读不到 ⇒ unavailable；
   AI S-44 给出失败集合之外的东西（未列出的值、没有返回、抛出）⇒ 缺陷。 *)
Authenticate ==
    /\ pc = "auth"
    /\ presentationRead' = TRUE
    /\ \/ /\ pres \in LookupFree
          /\ rejectionJudged' = TRUE
          /\ Answer("loginStateRejected")
          /\ UNCHANGED <<lookupFailed, passedAuth, defectRecorded>>
       \/ /\ pres \notin LookupFree
          /\ lookupFailed' = TRUE
          /\ Answer(IF Mutation = "unavailableAsRejected"
                      THEN "loginStateRejected" ELSE "unavailable")
          /\ UNCHANGED <<rejectionJudged, passedAuth, defectRecorded>>
       \/ /\ pres \notin LookupFree
          /\ defectRecorded' = TRUE
          /\ Answer(DefectReply)
          /\ UNCHANGED <<lookupFailed, rejectionJudged, passedAuth>>
       \/ /\ pres \notin LookupFree
          /\ (pres \in NotIssuedHere \/ invalidated)
          /\ rejectionJudged' = TRUE
          /\ Answer("loginStateRejected")
          /\ UNCHANGED <<lookupFailed, passedAuth, defectRecorded>>
       \/ /\ pres = "valid" /\ ~invalidated
          /\ passedAuth' = TRUE
          /\ pc' = CASE Mutation = "inputBeforeAuth"     -> "derive"
                     [] Mutation = "authBeforeEnvelope"  -> "envelope"
                     [] Mutation = "deriveBeforePayload" -> "derive"
                     [] OTHER                            -> "payload"
          /\ UNCHANGED <<decision, lookupFailed, rejectionJudged, defectRecorded>>
    /\ UNCHANGED <<route, versionOk, envelopeOk, pres, payloadOk, invalidated, postAuthRead,
                   gatePassed, domainCalled, stateNotValidSeen>>

(* S-10：载荷的表示层校验。要认人的路由在认出人之后才看；免认人的版本对上就看。不用查。 *)
CheckPayload ==
    /\ pc = "payload"
    /\ IF ~payloadOk
         THEN Answer("invalidInput")
         ELSE /\ pc' = IF route = "exempt" \/ Mutation = "deriveBeforePayload"
                         THEN "dispatch" ELSE "derive"
              /\ UNCHANGED decision
    /\ UNCHANGED <<route, versionOk, envelopeOk, pres, payloadOk, invalidated,
                   presentationRead, passedAuth, postAuthRead, gatePassed, domainCalled,
                   lookupFailed, rejectionJudged, stateNotValidSeen, defectRecorded>>

(* S-12：身份推导（现读 OG S-36）。读到「出示的登录状态已不作数」由失效输入表达；
   invalidInput、失败集合之外的东西，或返回的 account 分量不等于认人所得 AccountId
   （S-14 矛盾清单 ③）都是缺陷。 *)
Derive ==
    /\ pc = "derive"
    /\ postAuthRead' = TRUE
    /\ \/ /\ lookupFailed' = TRUE
          /\ Answer("unavailable")
          /\ UNCHANGED <<rejectionJudged, stateNotValidSeen, defectRecorded>>
       \/ /\ invalidated
          /\ stateNotValidSeen' = TRUE
          /\ rejectionJudged' = TRUE
          /\ Answer("loginStateRejected")
          /\ UNCHANGED <<lookupFailed, defectRecorded>>
       \/ /\ defectRecorded' = TRUE
          /\ Answer(DefectReply)
          /\ UNCHANGED <<lookupFailed, rejectionJudged, stateNotValidSeen>>
       \/ /\ pc' = IF route = "authGated" THEN "gate"
                   ELSE IF Mutation = "deriveBeforePayload" THEN "payload"
                   ELSE "dispatch"
          /\ UNCHANGED <<decision, lookupFailed, rejectionJudged, stateNotValidSeen,
                         defectRecorded>>
    /\ UNCHANGED <<route, versionOk, envelopeOk, pres, payloadOk, invalidated,
                   presentationRead, passedAuth, gatePassed, domainCalled>>

(* S-13：补授权（现读 OG S-26，多个组织时全部读完再合成）。无效 ⇒ notAuthorized，作为路由结果；
   读不到 ⇒ unavailable；invalidInput 或集合之外 ⇒ 缺陷。 *)
Gate ==
    /\ pc = "gate"
    /\ postAuthRead' = TRUE
    /\ \/ /\ lookupFailed' = TRUE
          /\ Answer(IF Mutation = "gateUnavailableAsDenied" THEN "result" ELSE "unavailable")
          /\ UNCHANGED <<gatePassed, defectRecorded>>
       \/ /\ Answer("result")                \* 该组织里无效 ⇒ notAuthorized 原样作为路由结果
          /\ UNCHANGED <<lookupFailed, gatePassed, defectRecorded>>
       \/ /\ defectRecorded' = TRUE
          /\ Answer(DefectReply)
          /\ UNCHANGED <<lookupFailed, gatePassed>>
       \/ /\ gatePassed' = TRUE
          /\ pc' = IF Mutation = "deriveBeforePayload" THEN "payload" ELSE "dispatch"
          /\ UNCHANGED <<decision, lookupFailed, defectRecorded>>
    /\ UNCHANGED <<route, versionOk, envelopeOk, pres, payloadOk, invalidated,
                   presentationRead, passedAuth, domainCalled, rejectionJudged,
                   stateNotValidSeen>>

(* S-14：第 ③ 步，路由到领域操作并映射它的答复。 *)
Dispatch ==
    /\ pc = "dispatch"
    /\ domainCalled' = TRUE
    /\ \/ /\ Answer("result")                \* 成功值，或其余具名结果原样透传
          /\ UNCHANGED <<lookupFailed, rejectionJudged, stateNotValidSeen, defectRecorded>>
       \/ /\ lookupFailed' = TRUE            \* unavailable / storage-unavailable
          /\ Answer("unavailable")
          /\ UNCHANGED <<rejectionJudged, stateNotValidSeen, defectRecorded>>
       \/ /\ Answer("invalidInput")         \* 领域判出来自载荷的项在表示层不合格
          /\ UNCHANGED <<lookupFailed, rejectionJudged, stateNotValidSeen, defectRecorded>>
       \/ /\ route \in AuthRoutes /\ invalidated \* 领域再读登录状态，读到它已不作数
          /\ stateNotValidSeen' = TRUE
          /\ rejectionJudged' = (Mutation # "passthroughStateNotValid")
          /\ Answer(IF Mutation = "passthroughStateNotValid"
                      THEN "result" ELSE "loginStateRejected")
          /\ UNCHANGED <<lookupFailed, defectRecorded>>
       \/ /\ defectRecorded' = TRUE          \* 缺陷：集合之外、结构上到不了的值、矛盾清单
          /\ Answer(DefectReply)
          /\ UNCHANGED <<lookupFailed, rejectionJudged, stateNotValidSeen>>
    /\ UNCHANGED <<route, versionOk, envelopeOk, pres, payloadOk, invalidated,
                   presentationRead, passedAuth, postAuthRead, gatePassed>>

(* 抽象环境：分类前失效。不是共同事务内允许其他写者提交的声明。 *)
Invalidate ==
    /\ pc # "classified" /\ pres = "valid" /\ ~invalidated
    /\ invalidated' = TRUE
    /\ UNCHANGED <<route, versionOk, envelopeOk, pres, payloadOk, pc, decision,
                   presentationRead, passedAuth, postAuthRead, gatePassed, domainCalled,
                   lookupFailed, rejectionJudged, stateNotValidSeen, defectRecorded>>

Pipeline == PublicHealth \/ CheckVersion \/ CheckEnvelope \/ CheckPayloadEarly
            \/ Authenticate \/ CheckPayload \/ Derive \/ Gate \/ Dispatch

Next == Pipeline \/ Invalidate

Spec == Init /\ [][Next]_vars /\ WF_vars(Pipeline)

-----------------------------------------------------------------------------
(* 断言。每一条都写明它对着哪一条条款；变异配置各改坏其中至少一条。 *)

(* 答了就恰是六类之一。由 TypeOK 的两个合取项（decision 的取值域、pc = classified ⇔ decision # none）
   直接推出，不单独绑定任何条款；S-7 的闭合见 DefectIsUnavailable 与 Schema。 *)
AnsweredClosed == pc = "classified" => decision \in Replies

(* S-8、S-10 ①：版本对不上时，除公开体检外只答 versionMismatch，且出示物没被看过、领域没被调用。 *)
VersionFirst ==
    (route # "publicHealth" /\ ~versionOk) =>
        /\ ~presentationRead
        /\ ~domainCalled
        /\ (pc = "classified" => decision = "versionMismatch")

(* S-10 ①′ 先于 ②：要认人的路由，版本对得上而信封不合格时，出示物没被看过、领域没被调用，
   答复是 invalidInput。 *)
EnvelopeBeforeAuth ==
    (route \in AuthRoutes /\ versionOk /\ ~envelopeOk) =>
        /\ ~presentationRead
        /\ ~domainCalled
        /\ (pc = "classified" => decision = "invalidInput")

(* S-18：公开体检不受任何一关挡，不看出示物，不读存储。 *)
HealthUnconditional ==
    route = "publicHealth" =>
        /\ ~presentationRead /\ ~domainCalled /\ ~lookupFailed
        /\ (pc = "classified" => decision = "health")

(* S-19：免认人的两条路由不看出示物。 *)
ExemptIgnoresPresentation == route = "exempt" => ~presentationRead

(* S-10、S-11：「判不了优先于无效」——本请求里有一次现读判不了，答复就是 unavailable。 *)
CannotJudgeIsUnavailable == (pc = "classified" /\ lookupFailed) => decision = "unavailable"

(* S-6、S-11：「无效」只来自一次判出来的结论，从不来自读不到。 *)
RejectionOnlyWhenJudged == decision = "loginStateRejected" => rejectionJudged

(* S-11：版本对得上、信封合格、判得了时，没带／多个／表示层非法／撤销／从没签发／别的中心签的，
   同一个答复。「判得了」＝ 没有读不到，也没有缺陷（缺陷是 S-14 的「答不出」）。 *)
RejectionUniform ==
    ( /\ pc = "classified" /\ route \in AuthRoutes /\ versionOk /\ envelopeOk
      /\ ~lookupFailed /\ ~defectRecorded
      /\ (pres \in LookupFree \/ pres \in NotIssuedHere) )
    => decision = "loginStateRejected"

(* S-33：认人之后才读到「出示的登录状态已不作数」，答复与在 ② 被拒逐字相同。 *)
LateInvalidationUniform == (pc = "classified" /\ stateNotValidSeen) => decision = "loginStateRejected"

(* S-10：要认人的路由，「输入不合格」只在认出人之后给出。 *)
InputAfterAuth ==
    (route \in AuthRoutes /\ envelopeOk /\ decision = "invalidInput") => passedAuth

(* S-10 载荷先于身份推导与补授权：要认人的路由载荷不合格时，身份推导与补授权都没读过、
   领域没被调用；认出了人的，答复就是 invalidInput（推导或补授权此刻读不读得到都一样）。 *)
PayloadBeforeDerive ==
    (route \in AuthRoutes /\ ~payloadOk) =>
        /\ ~postAuthRead
        /\ ~domainCalled
        /\ ((pc = "classified" /\ passedAuth) => decision = "invalidInput")

(* S-10、S-19：免认人的路由，载荷不合格不用查就判——存储此刻读不到也照判。 *)
ExemptInputWithoutLookup ==
    (pc = "classified" /\ route = "exempt" /\ versionOk /\ envelopeOk /\ ~payloadOk)
        => decision = "invalidInput"

(* S-10、S-13：领域操作只在版本、信封、载荷都过、要认人的已认出、要补授权的已通过之后被调用。 *)
NoDomainWithoutGates ==
    domainCalled =>
        /\ versionOk /\ envelopeOk /\ payloadOk
        /\ (route \in AuthRoutes => passedAuth)
        /\ (route = "authGated" => gatePassed)

(* S-7、S-11、S-12、S-13、S-14：缺陷——无论出在认人、身份推导、补授权还是领域操作——对来者一律 unavailable。 *)
DefectIsUnavailable == (pc = "classified" /\ defectRecorded) => decision = "unavailable"

Safety == /\ AnsweredClosed /\ VersionFirst /\ EnvelopeBeforeAuth /\ HealthUnconditional
          /\ ExemptIgnoresPresentation /\ CannotJudgeIsUnavailable
          /\ RejectionOnlyWhenJudged /\ RejectionUniform /\ LateInvalidationUniform
          /\ InputAfterAuth /\ PayloadBeforeDerive /\ ExemptInputWithoutLookup
          /\ NoDomainWithoutGates /\ DefectIsUnavailable

(* S-10 的进展：流水线有弱公平时，每个请求终会完成暂定分类；不表达发送或业务静止。 *)
EventuallyClassified == <>(pc = "classified")

-----------------------------------------------------------------------------
(* 有效性核对用的「否定可达」谓词：每一条都预期被违反（证明那一类答复可达）。
   只出现在 Validity_Reachability.cfg，不登记为 formal task。 *)
NeverHealth             == decision # "health"
NeverResult             == decision # "result"
NeverVersionMismatch    == decision # "versionMismatch"
NeverRejected           == decision # "loginStateRejected"
NeverUnavailable        == decision # "unavailable"
NeverInvalidInput       == decision # "invalidInput"
NeverLateInvalidation     == ~stateNotValidSeen
NeverGatePassed         == ~gatePassed
NeverDefect             == ~defectRecorded
=============================================================================
