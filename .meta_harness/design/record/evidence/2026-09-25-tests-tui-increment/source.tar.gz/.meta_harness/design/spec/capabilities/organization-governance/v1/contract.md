# capability.organization-governance v1

- **契约坐标**：`(omne-harness-lite-design-2026-09-15, capability.organization-governance, 1)`
- **设计依据**（PF-001 rev 15）：
  [§4 组织](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)、
  [§4 未激活的账号记录不会永久占着那个名字](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#未激活的账号记录不会永久占着那个名字)、
  [§4 隶属关系怎么建立与解除](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#隶属关系怎么建立与解除)、
  [§4 两种邀约都会过期](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)、
  [§4 个人组织](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#个人组织)、
  [§4 租户](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#租户)、
  [§4 退出之后再加入，回来的是同一个租户](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#退出之后再加入回来的是同一个租户)、
  [§4 当前租户身份](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#当前租户身份)、
  [§4 角色](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#角色)、
  [§6.1 层次](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#61-层次)、
  [§6.4 隔离](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)、
  [§6.6 撤销不等于强制停止](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#66-撤销不等于强制停止)、
  [§6.7 创作与归属](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#67-创作与归属)；
  [flows §1.4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#14-创建组织)～[§1.8](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#18-切换当前组织)、
  [flows §2 分支与异常](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常)、
  [flows §3.3 成员关系](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)、
  [flows §4 角色与操作](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)；
  [acceptance](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md)；
  [decisions §一 2026-09-22 九条确认](../../../../product/PF-001-identity-scope-and-agent-constraints/decisions.md#2026-09-22--九条正文规则逐条确认为产品要求)
- **其中三处依据是 rev 13 落下来的，逐一点名**（**正文已落盘，不再是「已裁未落」**）：
  [S-23](#s-23-发出邀请) 的授权前置「**本版即超级管理员**」（rev 13 flows §4 把「管理资格」那处笔误改掉）；
  [S-7](#s-7-上级组织属性) 的「上级组织**创建时为空**，只有隶属请求一条建立路径」（rev 13 §4 组织删掉了属性表里的「创建时可指定」）；
  [S-53](#s-53-清除未激活账号的个人组织) 的产品依据（rev 13 §4 写明未激活记录到期清除时，**为它准备的个人组织与第一个租户身份随之消失**）。
  **这三条都不登记缺口**——正文已经写着它们
- **rev 14 落下来的是三条读面的授权**（[缺口 G-11](#十一已知缺口) 随之闭合）：
  [flows §4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作) 补上了
  「查看成员名单」「查看本组织发出的邀约」「查看本组织收到的隶属请求」三行——
  **成员名单对本组织每一位有效成员可见**（[S-59](#s-59-列出组织成员) ②按此放宽），
  **两类邀约只归超级管理员**（[S-58](#s-58-列出组织发出的邀请与隶属请求)／[S-60](#s-60-列出组织收到的隶属请求) ②维持不变，
  但**不再是「本契约自己取的一档」，是产品已定**）。三条的失败集合都没有变
- **rev 15 落下来的是成员名单里「已解除的那些」归谁**：
  [flows §4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)
  把成员名单拆成两行——**「查看成员名单（有效成员）」普通成员可，「查看已解除的成员」只归超级管理员**。
  落点是 [S-59](#s-59-列出组织成员) ①那个过滤开关：**两档分别授权**，默认档（只要有效的）仍是该组织的有效成员、任一角色，
  「连无效的一起要」这一档**只给该组织的超级管理员**。**失败集合不变、不新增失败值**——`notAuthorized` 本来就在。
  其余条款一条未动
- **相邻依据**：[PF-002 §5.2](../../../../product/PF-002-assets-settings-and-permissions/design.md#52-设置与权限是资产的两种属性)（rev 9）、
  [PF-003 §5.2](../../../../product/PF-003-asset-transfer-and-sharing/design.md#52-边界是那棵隶属树不是单个组织)、
  [PF-003 §6.2](../../../../product/PF-003-asset-transfer-and-sharing/design.md#62-谁能流向谁)、
  [PF-003 §6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)（rev 4）、
  [PF-015 §6.12](../../../../product/PF-015-session-lifecycle-and-ownership/design.md#612-会话持有创建那一刻的租户身份)（rev 8）、
  [PF-007 §4 一笔授权表达有三个维度](../../../../product/PF-007-meta-capabilities/design.md#一笔授权表达有三个维度)（rev 15）；
  [SYS-TENANT](../../../../foundation/cross-system-constraints/requirements.md#sys-tenant)、
  [SYS-DEPLOY](../../../../foundation/cross-system-constraints/requirements.md#sys-deploy)
- **精确语义依赖**（三项，消费 clauses 见 [S-4](#s-4-依赖方向与被消费的面)）：
  - `omne-harness-lite-design-2026-09-15 · data.identity-values · v1`
  - `omne-harness-lite-design-2026-09-15 · data.offer-expiry · v1`
  - `omne-harness-lite-design-2026-09-15 · capability.account-identity · v1`
- **条款编号**：`S-n`，**只在本契约本版本内有效**；外部引用须写全坐标，如
  `capability.organization-governance/v1#S-28`。
  **编号在本版本内只追加，不重排**：后补的条款取下一个未用的号并放进它语义所属的那一节，
  因此节内的号**不一定连续递增**。这样做是为了让已被别的契约引用的条款号（`#S-20`、`#S-23`）
  **不因本版内的增补而漂移**

---

## 一、含义与使用范围

### S-1 本契约拥有什么

本契约拥有**一个组织里谁说了算、谁在里面、它跟别的组织是什么关系**这一整件事，
以及**一次登录此刻站在哪个租户身份上**这项选择。具体为六组事实：

| # | 拥有的事实 | 正文 |
|---|---|---|
| 1 | **组织**：它的标识、它是哪一种变体、它的[上级组织](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-parent-organization--上级组织--parent-organization)属性 | [S-5](#s-5-组织)～[S-7](#s-7-上级组织属性) |
| 2 | **成员关系**：一个[租户](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-tenant--租户--tenant)此刻有没有效、持什么[租户角色](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-tenant-role--租户角色--tenant-role) | [S-8](#s-8-成员关系记录)、[S-9](#s-9-成员资格判定结果两值不可用是读面失败) |
| 3 | **[邀请](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-invitation--邀请--invitation)**与**[隶属请求](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-affiliation-request--隶属请求--affiliation-request)**的全生命周期：发出、撤回、接受、过期 | [S-10](#s-10-邀请)、[S-11](#s-11-隶属请求) |
| 4 | **[上级链](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-ancestor-chain--上级链--ancestor-chain)**与**有共同上级**这两个读面 | [S-12](#s-12-上级链与有共同上级) |
| 5 | **身份带来的那两层**：组织级与租户级的[层身份](#s-13-层身份读面) | [S-13](#s-13-层身份读面) |
| 6 | **[当前租户身份](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-current-tenant-identity--当前租户身份--current-tenant-identity)**这项选择：查询与切换 | [S-14](#s-14-当前租户身份是登录状态上的一项选择) |

**「成员关系」不是一个独立的对象。**它是[租户「此刻有没有效」那一面](../../../../domain_objects/objects.md#ul-tenant--租户)——
对象清单已就此裁过：**身份是值，有效性是记录**。本契约因此不为它铸任何标识，
它的键就是 `TenantId` 本身（[S-8](#s-8-成员关系记录)）。

### S-2 本契约不拥有什么

| 不拥有 | 归谁 |
|---|---|
| 账号事实、登录状态、凭据校验 | `capability.account-identity` v1（本契约**消费**其中两个读面，见 [S-4](#s-4-依赖方向与被消费的面)） |
| 身份值的形状与隔离义务 | `data.identity-values` v1 |
| 一份待接受的邀约**何时不再可被接受** | `data.offer-expiry` v1（本契约**引用**它的判定式与求值次序，[S-10](#s-10-邀请)、[S-11](#s-11-隶属请求)） |
| 资产持有、属性配值、求值 | PF-002 的契约 |
| 资产复制与分享 | PF-003 的契约 |
| 会话 | PF-015 的契约 |
| 使用成本的计量与明细 | 尚无 owner，见[缺口 G-3](#十一已知缺口) |

### S-3 本契约明确不承诺什么

- **不铸租户标识。**`TenantId` 就是 (OrganizationId, AccountId)，
  由 `data.identity-values` v1 定义；本契约既不生成它，也不销毁它。
  解除成员关系**不铸新的**（[S-38](#s-38-解除只改成员关系的有效性)）。
- **不承诺投递。**「对方收到了一份邀请」在本契约里的含义**只是「对方查询得到它」**。
  内核不提供可靠投递，任何依赖投递的正确性都不能挂在这里。
- **不定义组织的一般终结路径。**[PF-001 非目标](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#非目标)不要求解散组织；
  本契约**不为「组织被解散」预埋任何写路径**，见 [S-11](#s-11-隶属请求) 与[缺口 G-2](#十一已知缺口)。
  **唯一的例外是 [S-53](#s-53-清除未激活账号的个人组织)**：清除一个**从未激活过**的账号的个人组织。
  它不是解散功能的第一步，**边界写死在那一条里**——[团队组织没有这条路径，已激活账号的个人组织也没有](#s-53-清除未激活账号的个人组织)。
- **不发出任何停止信号。**[撤销不等于强制停止](#s-44-撤销不发出停止信号)。
- **不承诺对外交换格式。**本版不附 Schema，理由在[包入口](../README.md#版本包)。
- **不定义界面。**「个人组织里没有邀请入口」是界面的事；本契约给的是[可查的判定](#s-15-结构性禁止不是权限判定)。
- **不承诺角色矩阵之外的中间角色。**[本版只有两种角色](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#角色)，
  [flows §4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作) 覆盖不到的组合回产品正文，本契约不自行补。

### S-4 依赖方向与被消费的面

**依赖方向是单向的：治理 → 账号。**本契约 inject 账号能力的读面，
账号能力**不得**反向依赖本契约的任何面。

| 被消费的面 | 用在哪 | 消费 clauses |
|---|---|---|
| **账号存在判定**（给定 AccountId，这个账号在不在） | [S-20 创建个人组织](#s-20-创建个人组织) | `capability.account-identity/v1#S-18`——**读账号**，`account-not-found` 即不存在 |
| **账号已激活判定** | [S-21](#s-21-创建团队组织)、[S-23 发出邀请](#s-23-发出邀请)、[S-25 接受邀请](#s-25-接受邀请)、[S-53 清除未激活账号的个人组织](#s-53-清除未激活账号的个人组织)（反过来用：要求**未**激活） | `capability.account-identity/v1#S-18` 返回值里的**激活状态**（同一个读面，不是第二个面） |
| **账号记录是否已过留存期限** | [S-20 创建个人组织](#s-20-创建个人组织) 的前置②（要求**未**过期）、[S-53 清除未激活账号的个人组织](#s-53-清除未激活账号的个人组织) 的前置②（要求**已**过期） | `capability.account-identity/v1#S-18` 返回值里的**是否已过留存期限**（仍是同一个读面）。**本契约依赖它的单调性**：一旦读到「是」，此后每一次读都是「是」——[那条性质写在该条款里](../../../capabilities/account-identity/v1/contract.md#s-18-读账号)，不是本契约的假设。**两处方向相反，正是这一对把两条链隔开**：同一个单调事实为假时只有 S-20 能过，为真时只有 S-53 能过 |
| **激活的前置与依据核实**（激活须出示激活依据、在自己提交里现读「是否已过留存期限」） | 第七节「已激活的账号 ⇒ 恰有一个个人组织」的「至少一个」一半 | `capability.account-identity/v1#S-14`——前置③与第 3 条 |
| **已激活不回退、不消失** | [S-25 接受邀请](#s-25-接受邀请) ②「本版判不出真」的理由 | `capability.account-identity/v1#S-20` |
| **`identifier-held-by-expired-record` 只流向组合** | [S-53 清除未激活账号的个人组织](#s-53-清除未激活账号的个人组织) 的调用面论证 | `capability.account-identity/v1#S-22` |
| **清除链 ②（清除到期的未激活账号记录）** | [S-53](#s-53-清除未激活账号的个人组织) ⑤「本版不作废」的重放安全全靠它前置②③的现读；③的「至多一个」与一一约束 | `capability.account-identity/v1#S-38`——前置②③④ |
| **登录状态校验面**（LoginStateId → **AccountId** ／ **`login-state-rejected`** ／ **`invalid-input`** ／ **`storage-unavailable`**，**四出口**） | [S-36 当前租户身份查询](#s-36-当前租户身份查询)、[S-37 切换](#s-37-切换当前租户身份) | `capability.account-identity/v1#S-17` |

**登录状态校验面的四个出口逐一映射到本契约的收场**，[S-36](#s-36-当前租户身份查询) 与
[S-37](#s-37-切换当前租户身份) 的 ⑧ 就是这张映射：

| `capability.account-identity/v1#S-17` 的出口 | 本契约的收场 | 为什么不能合并 |
|---|---|---|
| **AccountId** | 继续往下判 | — |
| **`login-state-rejected`**（查不到、已撤销、所属账号未激活，值不区分原因） | `loginStateNotValid` | 这是一个成立的结论，调用方该做的是**重新登录** |
| **`invalid-input`**（那条 `LoginStateId` 在**表示层**就不合格） | `invalidInput`。**但这一支在本契约里到不了**，见下 | 两边是同一类东西（都是[表示层校验，不是判定结果](#s-16-缺席时的默认答案)），所以映射是显然的；它**不能**被折进 `loginStateNotValid` 或 `unavailable` |
| **`storage-unavailable`** | `unavailable` | 这不是结论，调用方该做的是**按当时实际状态重试**（[S-16](#s-16-缺席时的默认答案)） |

> **第三行为什么写「到不了」，以及它靠什么前提。**
> 本契约的每个操作**先做自己的表示层校验**（[S-16](#s-16-缺席时的默认答案) 的第三类）：
> `LoginStateId` 不合词法在**本契约这一侧**就已收成 `invalidInput`，不会被带下去调那个面。
> **这句话的前提是两侧的词法约束同源**——
> 两边判「合不合形状」用的是同一条
> [`data.identity-values/v1#S-31` 不透明标识的交换表示](../../../data/identity-values/v1/contract.md#s-31-不透明标识的交换表示)。
> **前提一旦不成立**（任一侧自行收紧或放宽词法），这一支立刻可达，
> 而映射已经写在这里，**收场是 `invalidInput`，不是 `unavailable`**。
> **这一行因此不是冗余：它是那个前提失效时的收场，写出来才不会在实现里被顺手折成别的值。**

#### 身份值侧的被消费面（`data.identity-values` v1，27 条）

**这一格此前是空的**：正文里大多以散文引用、不给条款号，登记时无从收齐（原[缺口 G-10](#十一已知缺口) 的后半）。
下表逐条给号，**catalog 的 `clauses` 以它为准**。

**下表每个 `#S-n` 的完整坐标是 `omne-harness-lite-design-2026-09-15 · data.identity-values · v1 · S-n`**；
表内省去前缀只为可读，引用到本表之外时一律写全坐标。

| 被消费的条款 | 用在哪 |
|---|---|
| `#S-1` AccountId | [S-20](#s-20-创建个人组织)、[S-21](#s-21-创建团队组织)、[S-23](#s-23-发出邀请)、[S-25](#s-25-接受邀请)、[S-27](#s-27-我的租户)、[S-53](#s-53-清除未激活账号的个人组织) 的输入 |
| `#S-3` OrganizationId | [S-5](#s-5-组织) 的标识；**不回收**这条由它给（[S-53](#s-53-清除未激活账号的个人组织)） |
| `#S-4` OrganizationKind | [S-5](#s-5-组织)、[S-6](#s-6-两个变体与四条结构性禁止) 的两个变体与结构性禁止。**四条禁止的权威在本契约 [S-6](#s-6-两个变体与四条结构性禁止)**，身份值那边只拥有判别式的形状 |
| `#S-5` TenantId 的构成与相等 | [S-3](#s-3-本契约明确不承诺什么)「不铸租户标识」、[S-8](#s-8-成员关系记录) 的键、[S-35](#s-35-层身份) 的两半 |
| `#S-6` TenantId 无生灭路径 | [S-38](#s-38-解除只改成员关系的有效性)「`TenantId` 永久可被引用」、[S-39](#s-39-回来的是同一个租户) |
| `#S-7` TenantId 的规范序列化形式 | [S-8](#s-8-成员关系记录) 的**记录键**——成员关系以 `TenantId` 为键，键要能被写进存储、被逐字比较；[S-27](#s-27-我的租户)／[S-59](#s-59-列出组织成员) 返回的列表里每一项也是这个形式 |
| `#S-8` TenantRole | [S-8](#s-8-成员关系记录) 的角色字段、[S-28](#s-28-调整角色) |
| `#S-9` LoginStateId | [S-14](#s-14-当前租户身份是登录状态上的一项选择)、[S-36](#s-36-当前租户身份查询)、[S-37](#s-37-切换当前租户身份) |
| `#S-10` MembershipStanding | [S-9](#s-9-成员资格判定结果两值不可用是读面失败)、[S-26](#s-26-成员资格判定) 的返回值与它的 failure 支 |
| `#S-11` ScopeLayerIdentity | [S-13](#s-13-层身份读面)、[S-35](#s-35-层身份) |
| `#S-12` 缺席与空值都不是身份值 | [S-16](#s-16-缺席时的默认答案) 的「任何身份参数都没有默认值」 |
| `#S-14` 上级组织与上级链 | **[S-12](#s-12-上级链与有共同上级) 的上级链定义的权威**，本契约引用不复制 |
| `#S-15` shareAncestor | **[S-12](#s-12-上级链与有共同上级) 的「有共同上级」判据的权威**，同上 |
| `#S-16` 按归属层显式携带身份值 | [S-14](#s-14-当前租户身份是登录状态上的一项选择) 第 4 条、[S-38](#s-38-解除只改成员关系的有效性) 的「不可达」前提 |
| `#S-17` 身份参数没有默认值 | [S-16](#s-16-缺席时的默认答案) |
| `#S-18` 缺席即拒绝 | [S-16](#s-16-缺席时的默认答案)、各操作的⑧ |
| `#S-19` 不可用即明确失败 | [S-9](#s-9-成员资格判定结果两值不可用是读面失败)、[S-16](#s-16-缺席时的默认答案)、[S-43](#s-43-依赖的提供者不可用)；**各读面读不到时的 `unavailable` 一律按它** |
| `#S-26` 成员无效使租户级持有不可达但不销毁 | [S-38](#s-38-解除只改成员关系的有效性) 的三条「不做」 |
| `#S-27` 每道准入现读 | [S-18](#s-18-每道准入现读) |
| `#S-28` 当前租户身份在创建那一刻捕获 | [S-14](#s-14-当前租户身份是登录状态上的一项选择) 第 2／3 条与 [S-37](#s-37-切换当前租户身份)「切换只影响此后新建的东西」——**捕获发生在别人那里，本契约只保证切换不回头改已捕获的值** |
| `#S-29` 层事实只以显式身份值为键 | [S-37](#s-37-切换当前租户身份)「切换写不到任何一层去」 |
| `#S-30` 跨边界须重新验证 | [S-42](#s-42-装配给的保证-vs-协议须给的保证) 的「协议给」那一列 |
| `#S-31` 不透明标识的交换表示 | `InvitationId`／`AffiliationRequestId` 的词法约束（[S-45](#s-45-本版选用哪些形式工件)）；**[S-30](#s-30-发出隶属请求)「指向自己」那一步的相等判定按它逐码点比较** |
| `#S-32` 判别式集合闭合 | `OrganizationKind`（[S-5](#s-5-组织)）、`TenantRole`（[S-8](#s-8-成员关系记录)）、`MembershipStanding`（[S-9](#s-9-成员资格判定结果两值不可用是读面失败)）、`ScopeLayerIdentity`（[S-13](#s-13-层身份读面)）**各自的取值集合是封闭的**；**收到一个不在集合内的取值一律拒绝**（[S-16](#s-16-缺席时的默认答案) 的 `invalidInput`），不得当成「未知就放行」或映射到某个默认取值 |
| `#S-33` 表示层校验与判定分开 | [S-16](#s-16-缺席时的默认答案) 的 `invalidInput`、[S-23](#s-23-发出邀请)／[S-30](#s-30-发出隶属请求) 的 `invalidOfferDuration` |
| `#S-34` 语义身份与实现地址分开 | 本契约返回与收受的一律是**语义身份值**（`OrganizationId`、`TenantId`、`InvitationId`…），**不是存储行号、URL 或任何实现地址**；[S-53](#s-53-清除未激活账号的个人组织)「`OrganizationId` 不回收」也靠它——标识是身份，不是一个可被重新分配的位置 |
| **`#S-35` 交接凭证 Handoff Warrant** | [S-53](#s-53-清除未激活账号的个人组织) ⑤ 产出的**清除依据**就是它的一个实例 |

> **`data.identity-values/v1#S-13 sameAccountDistinctTenants` 不在这张表里，这是有意的。**
> 那个谓词的消费者是 **PF-003 的资产契约**（「同一账号在两边都是成员」这条复制前提）。
> 本契约只在[十二、消费者核对](#十二消费者核对)里**提到**它，用来说明那条前提落在哪——
> **提到不是消费**：本契约自己没有任何操作求值它，
> 它要的两次成员资格判定走的是 [S-26](#s-26-成员资格判定)，「同一账号」由
> `TenantId` 账号那一半的结构相等（`data.identity-values/v1#S-5`）得出。
> 把它登进消费清单，会让「换掉 `data.identity-values/v1#S-13` 要不要重审本契约」得到一个错误的答案。

#### 过期语义侧的被消费面（`data.offer-expiry` v1）

**整块引用不复制**（[S-10](#s-10-邀请)、[S-11](#s-11-隶属请求)），具体条款号由正文里按号引用的位置收齐。
**`data.offer-expiry/v1#S-19`（指向对象的存在性读面归属）必须一并登记**：
[S-25](#s-25-接受邀请) 与 [S-32](#s-32-接受隶属请求) 的⑧把「组织存在性读面不可用」收成 `unavailable`，
依据正是那一条把读面责任派给了持有该对象的契约——**本契约就是那个契约**。

#### 不消费什么，以及这条契约级边界买到什么

**本契约不消费凭据校验。**
[`capability.account-identity/v1#S-15`](../../../capabilities/account-identity/v1/contract.md#s-15-验证凭据并签发登录状态)
那一条操作与组织治理没有任何共同的判定输入或不变量，本契约的任何一条前置都用不到它。

**理由不是重启半径。**本契约 inject 的是账号能力的读面，
**那个提供者换代本来就会重跑本契约**——多消费或少消费它的一条操作**都不改变这个半径**。
真正的理由与本节把
[`data.identity-values/v1#S-13`](../../../data/identity-values/v1/contract.md#s-13-sameaccountdistincttenants)
排除在消费清单之外**是同一条**：把一条本契约并不据以判定的条款登进消费清单，
会让「换掉它要不要重审本契约」得到一个错误的答案。

**那么账号与治理之间这条契约级边界买到的是什么**，四样，
与 [`composition.account-registration/v1#S-2`](../../../compositions/account-registration/v1/contract.md#s-2-参与方与精确承诺)
的后注**同一口径**：

| 拆开买到什么 | 落点 |
|---|---|
| **反方向的半径收敛** | 本契约 inject 账号读面，**账号提供者换代本来就会重跑本契约**；那个方向合不合并都一样。拆开收的是**另一个方向**：只需要「来者是谁」的那些消费者（[`capability.account-identity/v1#S-17`](../../../capabilities/account-identity/v1/contract.md#s-17-校验登录状态)、[`#S-18`](../../../capabilities/account-identity/v1/contract.md#s-18-读账号)）**不因组织治理换代而重跑** |
| **契约层的失败隔离** | 账号面不可用时本契约的相关操作以具名值**明确失败、不静默降级**（[S-43](#s-43-依赖的提供者不可用)）；反过来，账号能力**只依赖存储**、不消费任何其他契约（[`capability.account-identity/v1#S-28`](../../../capabilities/account-identity/v1/contract.md#s-28-依赖不可用撤除与重启时的在途归属)），本契约不可用不使它失效。**两句话各写在自己那份契约里；合成一份之后它们没有地方可写** |
| **SYS-DEPLOY 的分布式缝已逐条标价** | 两侧各自把「本版由装配给、跨进程后须由协议重新兑现」的保证**逐条点名**（[S-42](#s-42-装配给的保证-vs-协议须给的保证)、[`capability.account-identity/v1#S-30`](../../../capabilities/account-identity/v1/contract.md#s-30-装配给的保证-vs-协议须给的保证)），跨两侧的交接由 [`composition.account-registration/v1#S-25`](../../../compositions/account-registration/v1/contract.md#s-25-装配给的保证-vs-协议须给的保证) 点名。合成一份会把这些缝藏进一次进程内调用，[SYS-DEPLOY](../../../../foundation/cross-system-constraints/requirements.md#sys-deploy) 要的「语义不变地拆成分布式」届时**无从逐条兑现** |
| **账号身份事实不是范围化对象** | [`capability.account-identity/v1#S-12`](../../../capabilities/account-identity/v1/contract.md#s-12-账号身份事实不是范围化对象) 兑现 [SYS-TENANT](../../../../foundation/cross-system-constraints/requirements.md#sys-tenant) 的方式是**它什么也不提供**：没有任何操作接受层身份作参数。与本契约（它持有组织、成员关系与[层身份](#s-13-层身份读面)）合并之后，这条负向承诺**失去它的结构依据**，只剩一句自律 |

> **这四条里没有「换一次认证提供者会把整个组织治理重启一遍」，那是有意的。**
> 那句话在契约层**不成立**，理由见上面「理由不是重启半径」那一段。
>
> **上表里的坐标是边界理由的依据，不是本契约据以写出承诺、判定、映射或证据落点的条款**，
> 按[登记口径](../../../README.md#当前状态)**不登记为消费**——本契约的消费面仍以本节前面三张表为准。

> **登录状态校验这一条比施工简报的操作表多。**简报只写了「当前租户身份（查询）：输入
> LoginStateId」。但[这项选择随登录状态走，那次登录失效它随之不存在](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#当前租户身份)，
> 而失效判定不在本契约手上——不校验就会把一条已撤销的登录状态上的选择继续当成有效答案。
> 本契约因此把它写成显式前置（[S-36](#s-36-当前租户身份查询)、[S-37](#s-37-切换当前租户身份)）。

---

## 二、概念、身份与必要状态

**本节的身份值一律引用 `data.identity-values` v1，不复制其定义**：
`AccountId`、`OrganizationId`、`OrganizationKind`、`TenantId`、`TenantRole`、
`LoginStateId`、`MembershipStanding`、`ScopeLayerIdentity`。

### S-5 组织

一个[组织](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-organization--组织--organization)是一个协作范围，
由 `OrganizationId` 标识。它持有三项本契约拥有的事实：

| 事实 | 取值 | 何时确定 | 可变？ |
|---|---|---|---|
| `OrganizationId` | 不透明标识 | 创建时，由存储生成 | 否 |
| `OrganizationKind` | `personal` / `team` | 创建时 | **否，无写路径** |
| 上级组织 | 至多一个 `OrganizationId`，可以为空 | 创建时为空 | 是，见 [S-7](#s-7-上级组织属性) |

**本版组织只有一条终结路径，且它够不到任何邀约**：
[S-53](#s-53-清除未激活账号的个人组织) 清除一个**从未激活过**的账号的个人组织
（[S-3](#s-3-本契约明确不承诺什么)）。除它之外，组织一经创建即永久存在。

**「指向的组织已不存在」这个分支因此仍然没有触发源**（[缺口 G-2](#十一已知缺口)），
理由是一条结构性事实而不是巧合：**个人组织既发不出邀请、也不参与隶属关系**
（[S-6](#s-6-两个变体与四条结构性禁止) 的禁止 1 与 3，由 [S-23](#s-23-发出邀请)、[S-30](#s-30-发出隶属请求) 的失败值兑现），
所以**没有任何邀约能指向一个个人组织**，唯一会消失的那种组织正好是唯一没有邀约指向它的那种。
团队组织仍然没有终结路径，而邀约只在团队组织之间。

**能观察到「组织不存在」的只有 [S-22 读组织](#s-22-读组织)**，且只在它被清除之后。

### S-6 两个变体与四条结构性禁止

`OrganizationKind` 把组织分成两个[变体](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-personal-organization--个人组织--personal-organization)：
`personal` 是[个人组织](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-personal-organization--个人组织--personal-organization)，
`team` 是[团队组织](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-team-organization--团队组织--team-organization)。
个人组织身上有**四条结构性禁止**：

> **这四条的权威在本条。**`data.identity-values` v1 的 `OrganizationKind` 只拥有**判别式的形状**，
> 不拥有「个人组织不能做什么」；那份契约引用本条，不自列一份。

| # | 禁止 | 在本契约里怎么表达 |
|---|---|---|
| 1 | 不能发出邀请 | [S-23](#s-23-发出邀请) 的失败集合项 **`issuerIsPersonalOrganization`** |
| 2 | 唯一的那个成员不能解除自己的成员关系 | [S-29](#s-29-解除成员) 的失败集合项 `personalOrganizationMemberCannotLeave` |
| 3 | 上级恒空，且不能作别人的上级 | [S-30](#s-30-发出隶属请求)、[S-32](#s-32-接受隶属请求) 的失败集合项 `personalOrganizationTakesNoPartInAffiliation` |
| 4 | 除创建者外不得有第二个成员关系 | 由 1 与[S-20](#s-20-创建个人组织) 共同兑现：没有任何操作能给个人组织加第二个成员 |

**每个账号恰有一个个人组织**（[PF-001 §4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#个人组织)）。
本契约把这句产品话拆成[第七节的两条单向式](#不变量)：**至多一个**由 [S-20](#s-20-创建个人组织) 的幂等边界与存储上的一一约束兑现，
**至少一个**只对已激活的账号成立、挂在激活侧的前置上。
**「每个账号」指的是每一条存在的账号记录**：账号记录被清除之后它不再是「一个账号」，
这条约束也就不再指向任何东西——见下面那条例外。

#### 这四条禁止之外，个人组织另有一条例外：它有唯一的销毁路径

上面四条说的是**个人组织能做什么**。还有一件事要写在这里，否则读者会从
[S-5](#s-5-组织) 的「组织没有终结路径」推出一个本版不成立的结论：

> **个人组织的唯一销毁路径是 [S-53](#s-53-清除未激活账号的个人组织)，
> 且它只对[从未激活过](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#31-账号)的账号成立。**
> **已激活账号的个人组织，本版没有任何销毁路径**；团队组织也没有。

它是[账号那一侧「未激活记录有留存期限」这条产品规则](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#未激活的账号记录不会永久占着那个名字)
在本契约的落点：一条未激活记录到期被清掉时，
[注册第 2 步](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#11-注册)为它建起来的那个个人组织必须一起清掉，
否则会留下一个**没有账号的个人组织**——那正是
`omne-harness-lite-design-2026-09-15 · composition.account-registration · v1` 的
[S-13](../../../compositions/account-registration/v1/contract.md#s-13-一个可用账号有且仅有一个个人组织) 要排除的形态的镜像。

**这条例外不放宽任何别的东西**：它不给个人组织加成员、不让它参与隶属关系、
不给团队组织开一条解散路径，**也不是「组织解散」这件事的第一步**（[缺口 G-2](#十一已知缺口) 依然开着）。

### S-7 上级组织属性

上级组织是**组织的一项属性**，不是一套关系表，也不是一层。三条约束：

- **至多一个。**属性容纳一个值，不存在写入第二个值的路径。**这条由数据形状兑现，
  不是一次运行期检查。**
- **不成环。**`o` 的上级链上不得出现 `o` 自己。这条**不由形状兑现**，
  要在写入的同一次提交内读多行判定（[S-32](#s-32-接受隶属请求)）。
- **个人组织恒空且不作上级**（[S-6](#s-6-两个变体与四条结构性禁止)）。

**这个属性只有两条写路径**：[接受一份隶属请求](#s-32-接受隶属请求)填上值，
[解除隶属](#s-33-解除隶属)清空值。**没有第三条**——特别是，
没有任何「单方面指定下级」的路径（[PF-001 §4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#隶属关系怎么建立与解除)：
那不是隶属关系，那是后门）。

> **创建时也不能指定，这一格已经裁过。**PF-001 **rev 12** 的属性表曾写「上级组织：创建时可指定」，
> 与同节「单方面指定不允许」**相互矛盾**：创建者不可能同时是两个组织的超管这一点没有任何前置去保证，
> 于是「创建时指定」就成了绕开接受那一步的第三条写路径。
> **产品负责人已裁定删掉它，rev 13 正文已落盘**（[PF-001 §4 组织](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)）：
> 上级**创建时一律为空**，此后只能经隶属请求建立。本条因此**不变**，
> [S-5](#s-5-组织) 的「何时确定：创建时为空」也不变——**变的是产品正文那一处自相矛盾的表述**。

**上级组织不进[作用域层](../../../../ubiquitous_language/terms/scope-and-resolution.md#ul-scope-layer--作用域层--scope-layer)。**
下级组织不自动继承上级组织的任何东西；[S-13](#s-13-层身份读面) 给出的两层与上级链无关。

### S-8 成员关系记录

成员关系是一条**以 `TenantId` 为键**的持久记录，属性有两项：

| 属性 | 取值 | 说明 |
|---|---|---|
| 有效性 | 有效 / 无效 | [无 → 成员 → 无 → 再成员](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)，全在同一条记录上 |
| 角色 | `TenantRole` **单值** | 一个租户在其组织内**只持一个**角色 |

**键就是 `TenantId`，本契约不铸第二个标识。**由此直接得到两条：
同一个 (组织, 账号) 无论断续多少次都是同一条记录（[S-39](#s-39-回来的是同一个租户)）；
角色是这条记录上的一项值，**不进 `TenantId`**——
[所以升职降职不改变归属与署名](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#作者用租户身份标识)。

### S-9 成员资格判定结果两值，不可用是读面失败

成员资格判定的**结果值**是 `MembershipStanding`，**恰两个值**：

| 值 | 含义 | 消费者该怎么办 |
|---|---|---|
| **effective**（带角色） | 这条记录此刻有效，角色是这个 | 按角色继续判 |
| **ineffective** | 这条记录此刻无效，或从未建立 | 拒绝 |

**「判不出来」不是第三个值，是这个读面的一次失败。**存储或依赖提供者读不到时，
[S-26](#s-26-成员资格判定) **以 `unavailable` 失败，不返回任何 `MembershipStanding`**。

**这个区分是这一条的全部理由。**把「判不出来」做成一个 standing 取值，
它就会沿着「值」的那条路被消费者当成一个结论顺下去；做成失败，消费者除了失败没有别的路可走。
把它折成 `ineffective`，一次基础设施抖动会被当成一次失权；折成 `effective` 则是放行。
[PF-001 §6.4 要求的是「目标范围不可用或成员失权时明确失败，
不静默回退到个人范围」](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)——
**失权与不可用是两件事，两者都不放行，但两者的收场不同**：前者是一个成立的拒绝结论，后者是没有结论。

> **正式名取自词表**：[UL-membership-standing · 成员资格效力 · Membership Standing](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-membership-standing--成员资格效力--membership-standing)。
> 词条与本条同形——**恰两个取值**，且**「目标范围不可用」不是第三个取值，那是失败**。
> 形状归 `data.identity-values` v1（`MembershipStanding` 与 `MembershipStandingResult` 两支）。

### S-10 邀请

[邀请](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-invitation--邀请--invitation)是**组织发给账号**的加入邀约，
由 `InvitationId` 标识（不透明、部署内唯一、由存储生成）。它携带：

| 字段 | 含义 |
|---|---|
| 发出它的组织 | `OrganizationId`；**同时是 offer-expiry 判定用的那个指向对象** |
| 被邀请的账号 | `AccountId`；**不参与过期判定** |
| 指定的角色 | `TenantRole`，缺省为普通成员 |
| `OfferTiming` | `data.offer-expiry/v1#S-4`，本契约不复制其定义 |

**过期语义整块引用 `data.offer-expiry` v1**：派生状态四值、判定式、读时派生、
接受在同一提交内重新求值、到期不可接受、过期与撤回收场相同与拒绝理由不区分来路，
分别是 `data.offer-expiry/v1#S-7`～`#S-13`。**本契约不复制其中任何一条，也不改写它们。**

**判定用的指向对象只有发出它的那个组织**，这是 `data.offer-expiry/v1#S-2` 已经定下的；
被邀请的账号不进判定。

**这一份的有效时长由发出它的人在 [S-23](#s-23-发出邀请) 指定，不指定就按邀请这一类的默认值**
（部署配置，[PF-001 §4 两种邀约都会过期](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)、
[flows §1.5](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#15-邀请与加入)）。
**指定值是这份数据的一个参数，跟着这份邀约走、随它结束而消失，不进[作用域层](../../../../ubiquitous_language/terms/scope-and-resolution.md#ul-scope-layer--作用域层--scope-layer)**；
它落进 `OfferTiming` 的方式归 `data.offer-expiry/v1#S-14`，本契约不复制。

### S-11 隶属请求

[隶属请求](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-affiliation-request--隶属请求--affiliation-request)是**组织发给组织**的建立隶属邀约，
由 `AffiliationRequestId` 标识。它携带：

| 字段 | 含义 |
|---|---|
| 发起方组织、接收方组织 | 两个 `OrganizationId`。**offer-expiry 判定用的指向对象只有接收方组织**（`data.offer-expiry/v1#S-2`、`data.offer-expiry/v1#S-6`）——它就是产品正文说的[「它指向的那个组织」](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)。**发起方组织不进判定**：本版它不可能消失（见下） |
| 方向 | 请对方作自己的上级 / 请对方作自己的下级 |
| `OfferTiming` | 同 [S-10](#s-10-邀请) |

**过期语义同样整块引用 `data.offer-expiry` v1**，不复制。

**这一份的有效时长由发出它的人在 [S-30](#s-30-发出隶属请求) 指定，不指定就按隶属请求这一类的默认值**
（部署配置，[flows §1.7](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#17-建立与解除组织隶属)）。
**两类各有各的默认值**，邀请与隶属请求**不共用一个取值**；指定值与 [S-10](#s-10-邀请) 同形，
是这份数据的参数，不进作用域层。

**「指向的组织不存在」这一分支本版没有触发源**（[S-5](#s-5-组织)）。
规则照 `data.offer-expiry/v1#S-8` 写全，**但实现不得为它造一个当前不存在的事件源**，
也不得为「组织被解散」预埋写路径。见[缺口 G-2](#十一已知缺口)。

> **发起方组织为什么不进判定式。**产品正文给的是单数——[「它指向的那个组织不存在了」](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)；
> 而本版把它写成两个对象的合取，**在语义上多承诺了一件产品没说过的事**。
> 更要紧的是这一格在本版**判不出真**：隶属请求的两端都只能是团队组织
> （[S-6](#s-6-两个变体与四条结构性禁止) 的禁止 3），而**团队组织没有任何终结路径**（[S-5](#s-5-组织)）。
> **这是推导，不是省略**：发起方消失这件事本版没有触发源，写进判定式也只是一条永远为假的析取项。
> 团队组织有了终结路径那天，「发起方是否也该进判定」要由产品重新裁——
> 那属语义变更，归 `data.offer-expiry` v1 的新版本，不在本契约里自行补。

> **隶属请求的宿主「正文未述」，本契约不受阻。**
> [对象清单登记了这项未裁](../../../../domain_objects/objects.md#ul-affiliation-request--隶属请求)：
> 两端都是组织，正文只点了「它**指向的**那个组织」。**本契约不依赖宿主**——
> 它按 `AffiliationRequestId` 持久存在，按**接收方组织这一个**指向对象判过期
> （[上一段](#s-11-隶属请求)、`data.offer-expiry/v1#S-2`、`data.offer-expiry/v1#S-6`），
> 两件事都不需要先知道它挂在谁身上。裁决见[缺口 G-4](#十一已知缺口)。
>
> **「按接收方单数判」与「宿主未裁」是两件事，不要用前者去答后者。**
> 判过期用哪个对象，[产品正文给了单数](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)，
> 已经定了；**宿主是「这份请求挂在谁身上、随谁一起消失」**，那一问正文没答，所以 G-4 还开着。
> **本契约两处都不受阻**，但它们**各有各的依据**：前者引产品正文，后者等裁决。

### S-12 上级链与有共同上级

**这两个谓词的定义式不在本契约，本契约引用不复制。**权威是
[`data.identity-values/v1#S-14`](../../../data/identity-values/v1/contract.md#s-14-上级组织与上级链)（上级链
`ancestorChain(o)`，**不含 `o` 自己**）与
[`data.identity-values/v1#S-15`](../../../data/identity-values/v1/contract.md#s-15-shareancestor)
（`shareAncestor(o1, o2)`，**把各自算进自己的链之后求交**）。
**函数名以那两条为准**，本契约与形式模型一律用 `ancestorChain`，不另起别名。

**本契约拥有的是它们在组织治理上的三件事**，不是定义：
① [S-34](#s-34-上级链与有共同上级) 那个**读面**（谁能调、返回什么形状、读不到怎么收场）；
② [S-32](#s-32-接受隶属请求) 的**判环前置**——写入的同一次提交内求值；
③ 下面这几条由上级组织属性的形状（[S-7](#s-7-上级组织属性)）推出的**推论**。

两者都是**读时求值的派生视图**，不是被写下来的字段——
[PF-001 §4 的判据原文](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)（rev 15，**该判据自 rev 12 定下后未再改动**）与身份值契约同形。

**它等价于「同一棵隶属树（根相同）」。**上级属性至多一个值（[S-7](#s-7-上级组织属性)）、
链不成环（[S-32](#s-32-接受隶属请求)），所以每个组织顺着上级走必定终于唯一的一个根；
两条含自身的链有交，当且仅当两个根是同一个。
**这与 [PF-003 §5.2 把流转边界画成「同一棵隶属树」是同一句话](../../../../product/PF-003-asset-transfer-and-sharing/design.md#52-边界是那棵隶属树不是单个组织)**，
不是两个判据。

> **「把自己算进来」这一步不能省。**上级链本身不含自己，
> [若只比两条不含自己的链，一个组织与它自己的上级就不算有共同上级](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)——
> 而团队与它所属的公司分明在同一棵树上。**这处差异此前登记为缺口 G-5**，
> [Alloy 模型在给定规模内给出过那个反例](formal/README.md)；
> PF-001 rev 12 已裁定取**把自己算进来**的那一种，缺口随之关闭。

**个人组织的上级链恒空**（[S-6](#s-6-两个变体与四条结构性禁止)），把它自己算进来也只有它一个，
因此对**任意与它不同的** `x`，`shareAncestor(personal, x)` **恒假**——
[不是把门收紧了，是那把尺子量不到它](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-ancestor-chain--上级链--ancestor-chain)。
[「任何两个个人组织都不会有共同上级」因此仍然成立](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)：
它们各自是一棵单点树，互不同树。

> **「与它不同」这个限定是新读法带来的，必须写出来。**
> 含自身的读法下 `shareAncestor(o, o)` 对**任何**组织都为真，个人组织也不例外——
> 一个组织当然与它自己同树。**这不是把个人组织的门放宽了**：
> 消费者拿这个谓词判的是[两个不同组织之间能不能流转](../../../../product/PF-003-asset-transfer-and-sharing/design.md#52-边界是那棵隶属树不是单个组织)，
> 同一个组织内部不需要过这道判定。**实现不得把 `o` 与自己的那一次求值当成一条跨组织放行依据。**

### S-13 层身份读面

[作用域层](../../../../ubiquitous_language/terms/scope-and-resolution.md#ul-scope-layer--作用域层--scope-layer)共四层，
本契约只回答其中**两层「谁是这一层」**，不回答「这一层持有什么、怎么求值」（那是 PF-002）：

| 层 | 本契约给不给 | 给什么 |
|---|---|---|
| 出厂默认 | **不给** | 这一层**没有身份值**，也不得为它铸一个「平台租户」 |
| **组织级** | **给** | `ScopeLayerIdentity` 的 organization 变体，值为该 `TenantId` 的组织那一半 |
| **租户级** | **给** | `ScopeLayerIdentity` 的 tenant 变体，值为该 `TenantId` 本身 |
| 会话级 | **不给，是缺口** | 归 PF-015，见[缺口 G-1](#十一已知缺口)。**本版不填一个看起来合理的默认值** |

**账号不在这四层里**——[它的求值是恒等的，不占一格](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#61-层次)。
[上级组织也不进这四层](#s-7-上级组织属性)。

> **正式名取自词表**：[UL-scope-layer-identity · 作用域层身份 · Scope Layer Identity](../../../../ubiquitous_language/terms/scope-and-resolution.md#ul-scope-layer-identity--作用域层身份--scope-layer-identity)。
> 词条与上表同形——**出厂默认那一格没有身份对象**，**工作区不在其列**。
> 形状归 `data.identity-values` v1。

### S-14 当前租户身份是登录状态上的一项选择

[当前租户身份](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-current-tenant-identity--当前租户身份--current-tenant-identity)是
**按 `LoginStateId` 记的一项选择**，不是一个对象。**本契约整体拥有它——存、取、写与生灭**，五条：

1. **初值是个人组织里的那个租户。**一次登录成立之后第一次查询它，
   答案是 (该账号的个人组织, 该账号)（[flows §1.2](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#12-登录)）。
2. **切换只改这项选择，不改别的任何东西**（[S-37](#s-37-切换当前租户身份)）。
3. **它不是[范围化对象](../../../../ubiquitous_language/terms/scope-and-resolution.md#ul-scoped-object--范围化对象--scoped-object)**：
   不参与任何一层的求值，也不被任何一层配值。
4. **它不是授权依据。**任何受租户所有权约束的操作**仍然显式携带** `TenantId` 并独立判定
   （`data.identity-values` v1 的隔离义务）。把它当成环境里的「当前租户」直接放行，
   会让一条没有携带租户身份的调用路径看起来合法——[SYS-TENANT](../../../../foundation/cross-system-constraints/requirements.md#sys-tenant) 要挡的正是这个。
5. **它是本契约拥有的一条独立记录，以 `LoginStateId` 为键引用账号契约的登录状态记录；它的生灭归本契约。**
   登录状态记录归 `capability.account-identity/v1`（[`#S-9`](../../../capabilities/account-identity/v1/contract.md#s-9-登录状态记录)），
   这项选择不是那条记录上的字段，账号契约撤销或让它过期时**不动这项选择、也不需要知道它**。
   登录状态一旦失效，这项选择**不可达**——[S-36](#s-36-当前租户身份查询)／[S-37](#s-37-切换当前租户身份) 每次都先走登录状态校验
   （[S-4](#s-4-依赖方向与被消费的面) 的四出口），校验不过就到不了这条记录；
   **失效后残留的记录由本契约的提供者定期清扫**（S-36／S-37 校验不过就到不了那条记录，所以「读到失效即删」没有执行点；清扫的触发、节奏与它消费的失效读面归装配，[G-13](#十一已知缺口)），这是卫生工作，
   不产生任何可观察结果、不是产品动作、不进失败集合。「一条记录两个 owner」因此不存在：
   是两条记录，一条引用另一条。

**它不随成员资格的失效而被改写。**选中的那个 `TenantId` 此刻有没有效，
由[每道准入现读](#s-18-每道准入现读)回答；**本契约不在成员关系失效时把这项选择悄悄改回个人组织租户**——
那正是 [PF-001 §6.4 禁止的「静默回退到个人范围」](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)。

---

## 三、贯穿全部操作的四条规矩

### S-15 结构性禁止不是权限判定

[S-6](#s-6-两个变体与四条结构性禁止) 的四条禁止**写成失败集合里的具名项，不写成授权判定**。
两者的可观察差别是实在的：

- 授权判定的答案随角色变化——**超管在个人组织里也没有这个动作**，
  [acceptance 判据明写「有入口但点了报错，那说明它被实现成了权限判定」](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#三判据)。
- 结构性禁止是**由 `OrganizationKind` 决定的、与发起者无关的**事实。

因此本契约**给出可查的判定**：[读组织](#s-22-读组织)返回 `OrganizationKind`，
界面据此不呈现入口；操作侧仍保留同一个失败值作为兜底。
**两者必须给出同一个答案**：读面说不可邀请，操作就必须拒；读面说可邀请，操作不得因变体而拒。

### S-16 缺席时的默认答案

**一律拒绝或明确失败，不放行、不空集、不回退。**两类要分开：

| 情形 | 结果 | 为什么不能合并 |
|---|---|---|
| **判定得出「不该放行」** | **拒绝**（一个具名的拒绝值） | 这是一次成立的授权结论，重试不会改变答案 |
| **判定做不出来**（存储不可用、依赖提供者不在 `ACTIVE`、读不到） | **`unavailable` 失败** | 这不是结论，是没有结论。按当时实际状态重试可能得出不同答案 |

**成员资格读面在存储不可用时以 `unavailable` 失败，不返回 `ineffective`。**
这一条是 [S-9](#s-9-成员资格判定结果两值不可用是读面失败) 的操作面投影，
也是本契约最容易在实现里被一个「读不到就当没有」抹掉的地方。

**任何身份参数都没有默认值。**`TenantId`、`OrganizationId`、`AccountId`、`LoginStateId`、
`InvitationId`、`AffiliationRequestId` 缺席即拒绝，不得由环境值、进程上下文或「当前租户」补齐
（`data.identity-values/v1#S-17`、`data.identity-values/v1#S-18`）。

**「身份参数」这个限定是必要的**：本契约的**非**身份参数是带默认值的。写成「任何参数」会把它们一并禁掉，
而其中一格是产品明写的取值规则。**逐一列出，不含糊**：

| 带默认值的非身份参数 | 在哪 | 缺席时取什么 |
|---|---|---|
| **这一份邀约的有效时长** | [S-23](#s-23-发出邀请)①、[S-30](#s-30-发出隶属请求)① | **该类邀约的默认值**（部署配置，`data.offer-expiry/v1#S-14`）。**这一格是产品明写的**：[缺席按这一类的默认值，非法则拒绝](#s-23-发出邀请) |
| **邀请指定的角色** | [S-23](#s-23-发出邀请)① | **普通成员**（[S-10](#s-10-邀请)、[PF-001 §4 角色](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#角色)）。它是一个 `TenantRole` 取值，**给了就按 `data.identity-values/v1#S-32` 判集合闭合**，集合外 ⇒ `invalidInput` |
| **创建键** | [S-21](#s-21-创建团队组织)① | **不去重**（本次调用不认回任何此前的调用）。它没有「默认值」——缺席就是一种取值；写在这里是因为它是**非**身份参数、缺席**不**拒绝 |
| **列表面的过滤开关** | [S-57](#s-57-列出账号收到的待接受邀请)①、[S-58](#s-58-列出组织发出的邀请与隶属请求)①、[S-59](#s-59-列出组织成员)①、[S-60](#s-60-列出组织收到的隶属请求)① | **各自条款里写死的那个默认**：三条邀约列表面默认**只要 `pending` 的**，[S-59](#s-59-列出组织成员) 默认**只要有效的**。**它不是一项部署配置，是这条操作的取值规则，四条一致如此**。**[S-59](#s-59-列出组织成员) 那一格另有一句**：它的两档**授权不同**（默认档＝该组织的有效成员，另一档＝超管），所以**缺席取默认这件事顺带决定了走哪一道授权**；**这不改变「它没有默认值就该拒绝」的判法**——缺席仍然取默认，取完再按②判那一档 |

**这三行的共同点只有一个：它们都不是身份参数**，所以「缺席即拒绝」那条不适用。
**不同点要写出来**：第一行的默认值来自**部署配置**（配错了按 `data.offer-expiry/v1#S-17` 启动即失败），
第二、三行的默认值**写死在本契约条款里**，没有任何可配之处。
**这张表是穷举的**：本契约缺席不拒绝的非身份参数就这几个，写操作里是前三行，读面里是第四行。

#### 输入不合形状是第三类，收成 `invalidInput`

前两行说的都是**一个形状正确的输入判出了什么**。还有一类：**输入根本不合形状**——
字段缺席、类型不对、不透明标识不满足词法约束（`data.identity-values/v1#S-31`）、
时长不是一个正的时段。

**这一类一律收成 `invalidInput`，它进本契约每一个操作的失败集合。**口径取
[`data.identity-values/v1#S-33`](../../../data/identity-values/v1/contract.md#s-33-表示层校验与判定分开)：
它是一次**表示层校验**，在进入任何判定之前发生，
**不表示「该对象不存在」或「该主体无资格」，也不得被记成一次判定结果**。

**它与 `unavailable` 必须分开，这是本轮改掉的一处。**把不合形状的输入收成 `unavailable`，
等于告诉调用方「重试可能成功」——而重试一万次也不会成功，**错在那次调用本身**。
`invalidOfferDuration`（[S-23](#s-23-发出邀请)、[S-30](#s-30-发出隶属请求)）是这一类里
**被单独具名的一项**：它同属表示层校验，只是收场值更精确，因为[静默替换它的后果是实在的](#s-23-发出邀请)。

### S-17 同一组织的成员写入序列化

**同一个组织的成员关系写入（加入、角色调整、解除）必须被序列化。**
也就是说：对同一个 `OrganizationId`，任意两次成员写入不得交错——
后一次看到的必须是前一次提交之后的状态。

**这一条撑着「任何时刻至少一位有效超管」。**那条是
[任何时刻都成立的事实，不是每次动作各自检查一遍的前置条件](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)：
两次动作各自看都满足前置、合起来把超管清空，**这种结果不允许存在**。
把前置检查与写入放进同一次提交**还不够**——两次提交仍可各自读到旧状态；
必须序列化，才使「检查—写入」这个窗口对同组织的第二个写入者关闭。

> [行为模型把这一条检查成了会失败的断言](formal/README.md)：
> 去掉序列化的配置能产生反例，保留序列化的配置在已检查范围内不变量恒成立。

### S-18 每道准入现读

**角色与成员资格在每一次准入判定时重新读取。**
[撤销、退出、降级只影响下一道尚未通过的准入](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#66-撤销不等于强制停止)，
**向后生效，不回溯**。

由此得到一条给实现的硬要求：**任何缓存了角色或成员资格的地方都要写明失效条件**。
不写，「旧菜单继续当授权」就会从缓存这一侧复活——
而那是 [acceptance 点名的坏结果](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#二绝不能发生的事)。

**本契约因此不需要任何「广播撤销」的机制**：现读天然向后生效。
反过来说，**实现不得用一个撤销广播代替现读**——广播漏一次就留下一个仍在放行的判定点。

---

## 四、操作

### S-19 这一节每个操作写全九件事

| # | 写什么 |
|---|---|
| ① | **输入** |
| ② | **前置与授权** |
| ③ | **结构性禁止**（[S-15](#s-15-结构性禁止不是权限判定)；不适用写「无」） |
| ④ | **提交点与原子性** |
| ⑤ | **成功返回** |
| ⑥ | **失败集合**（枚举封闭，**没有「其他」**） |
| ⑦ | **幂等与重复** |
| ⑧ | **缺席时的默认答案**（[S-16](#s-16-缺席时的默认答案)） |
| ⑨ | **事件**（[S-40](#s-40-事件都是通知)） |

失败值一律是**封闭枚举里的具名值**，[不得用一个成功布尔掩盖拒绝、部分完成或结果未知](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#二绝不能发生的事)。

**每个操作的⑥都含 `invalidInput`**（[S-16](#s-16-缺席时的默认答案)），下面逐条列出、不省略。
**每个读操作也一样**：读面同样收得到不合形状的标识。

**本节共 25 个操作**：写操作十一个（[S-20](#s-20-创建个人组织)、[S-21](#s-21-创建团队组织)、
[S-23](#s-23-发出邀请)、[S-24](#s-24-撤回邀请)、[S-25](#s-25-接受邀请)、[S-28](#s-28-调整角色)、
[S-29](#s-29-解除成员)、[S-30](#s-30-发出隶属请求)、[S-31](#s-31-撤回隶属请求)、
[S-32](#s-32-接受隶属请求)、[S-33](#s-33-解除隶属)），
再加[S-37 切换](#s-37-切换当前租户身份)与[S-53 清除个人组织](#s-53-清除未激活账号的个人组织)两个；
读操作十二个（[S-22](#s-22-读组织)、[S-26](#s-26-成员资格判定)、[S-27](#s-27-我的租户)、
[S-34](#s-34-上级链与有共同上级)、[S-35](#s-35-层身份)、[S-36](#s-36-当前租户身份查询)、
[S-55](#s-55-读邀请)～[S-60](#s-60-列出组织收到的隶属请求)）。

### S-20 创建个人组织

| # | 内容 |
|---|---|
| ① | `AccountId` |
| ② | **恰两条**：该账号**存在**（消费账号存在判定，[S-4](#s-4-依赖方向与被消费的面)）；该账号记录**未过留存期限**（同一个读面的「是否已过留存期限」为否，见下）。**「尚无个人组织」不是前置**——已有时按⑦幂等返回，**不是一次拒绝**。**也不要求账号已激活**——[激活的前置正是个人组织已存在](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#31-账号)，要求已激活会让注册无法完成 |
| ③ | 无 |
| ④ | **单次提交**：组织行（`kind = personal`，上级为空）＋ 成员关系记录（有效）＋ 角色为超级管理员，**三者同时成立**。**不存在「有组织但没有管理员」的中间状态**（[flows §1.4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#14-创建组织)）。**②的两条账号判定（存在、未过期）必须与这次写入落在同一提交边界内**；**幂等那一路（不写入）同样在一次提交内现读这两条** |
| ⑤ | `OrganizationId`（以及由它与输入账号确定的 `TenantId`）。**幂等那一路返回的是已有的那一个**，形状完全相同——调用方**不需要、也不能**区分这两路 |
| ⑥ | `accountDoesNotExist` · **`accountRecordExpired`** · `invalidInput` · `unavailable`。**没有 `personalOrganizationAlreadyExists`**：那不是一种失败 |
| ⑦ | **幂等，边界是 `AccountId`。**该账号已有个人组织时返回那一个，不产生第二个，**也不报错**——这使[注册中途失败后用同一标识重来能接着完成](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#一可观察场景)。**幂等那一路仍要过②的两条判定**：记录已过期时返回 `accountRecordExpired`，**不返回那个已有的个人组织** |
| ⑧ | 账号读面不可用 ⇒ `unavailable`；**不得跳过存在判定直接建**，也**不得**把「读不到过期状态」当成「未过期」。`AccountId` 缺席或不合形状 ⇒ `invalidInput`（[S-16](#s-16-缺席时的默认答案)） |
| ⑨ | **不发。**注册的收场由组合契约裁决，不靠本操作的事件 |

**`accountRecordExpired` 不是一条多余的谨慎，它撑着一条不变量。**
没有它，下面这个交错会留下一个**谁也到不了、谁也再清不掉**的个人组织：
[清除链](../../../compositions/account-registration/v1/contract.md#s-34-第二条动作链未激活到期清除)的第 ① 步先跑
（清掉个人组织），注册主链的第 ② 步**随后**提交（又建了一个），
清除链的第 ② 步再把账号记录删掉——组织留下了，它的账号没了。

**这条前置之所以挡得住，靠的是「已过期」这个事实是单调的**
（`capability.account-identity/v1#S-18` 明写了这条性质）：
清除链 ① 能跑说明那一刻已经过期，而过期不会翻回去，
所以本操作**此后每一次**现读都读到「已过期」，**不可能在清除链 ① 之后成功**。
**两边读的是同一个事实，各自在自己的提交里读**——这就是收场，不需要跨 owner 的协调。

**它与 `accountDoesNotExist` 分开，不合并。**记录确实存在，只是不再算数；
合并会让调用方以为自己传错了 AccountId。
两者在组合契约那一侧收成同一个终结结果（`interrupted`），
但那是**组合**做的映射，不是本契约把两个事实揉成一个值。

> **「已有个人组织」为什么不是失败值。**本操作的唯一调用方是[注册组合](../../../compositions/account-registration/v1/contract.md#s-8-三步次序与责任交接)，
> 而它**必须能重跑**：一次回执丢失之后用同一标识重来，第二步会再调一次本操作。
> 把「已有」收成拒绝，重跑就在第二步停住，[「中途失败可以用同一标识接着完成」](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#一可观察场景)
> 这条验收判据当场不成立。**幂等与拒绝在这里不是口味问题，是两种不同的产品行为。**
> [「每个账号至多一个个人组织」这条不变量](#不变量)**由幂等边界兑现**（[S-20](#s-20-创建个人组织) ⑦ ＋ 存储的一一约束），
> **不由一个失败值兑现**——失败值只会在调用方重试时把它变成一条死路。

### S-21 创建团队组织

| # | 内容 |
|---|---|
| ① | 创建者 `AccountId`；**可选：创建键**——调用方给出的一个不透明去重标识（本操作的幂等键），**缺席不是拒绝，是「本次不去重」**（不是身份参数，[S-16](#s-16-缺席时的默认答案) 的表有它一行） |
| ② | 该账号**已激活**（[flows §2](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常)：发起者账号未激活 ⇒ 无新组织） |
| ③ | 无 |
| ④ | **单次提交**：组织行（`kind = team`，上级为空）＋ 创建者的成员关系记录（有效）＋ 角色为超级管理员＋**（带键时）创建键登记**。**不存在无超管的中间态**；键登记与组织行不落在同一提交里，回执丢失的窗口就仍然开着 |
| ⑤ | `OrganizationId` |
| ⑥ | `accountNotActivated` · `accountDoesNotExist` · `invalidInput` · `unavailable` |
| ⑦ | **幂等边界 = (创建者 `AccountId`, 创建键)**。带键重放（同创建者、同键，键仍在保留期内）⇒ **返回首次创建的那个 `OrganizationId`，无二次效果**——这就是 [PF-001 §6.8](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#68-管理结果)「未知结果后的重试认回同一逻辑操作」在本操作上的兑现处。**不带键 ⇒ 不幂等**：同一账号可以创建一个或多个团队组织（[PF-001 §4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)），重复调用产生的是**另一个**组织，且本版无终结路径，重复不可撤。键的作用域是创建者，两个账号用同一个键互不相干；键的**保留期** `team_creation_key_retention` 是部署配置（写成参数、不填值），过期后同键 ⇒ 新组织 |
| ⑧ | 账号读面不可用、**或创建键登记读不到** ⇒ `unavailable`（不得在读不到登记时当作「没见过这个键」去创建——那正是回执丢失后最常见的重复来路）；`AccountId` 缺席或不合形状、**创建键给了但不合形状** ⇒ `invalidInput`。**失败集合不变**，仍是 ⑥ 那四个 |
| ⑨ | 不发 |

**创建键不是一个概念，是本操作的一个输入**：它由调用方生成、本契约不解释、不与任何标识族混用（[`data.identity-values/v1#S-31`](../../../data/identity-values/v1/contract.md#s-31-不透明标识的交换表示) 的词法约束同样适用于它的形状）。
它回答的只有一个问题——「这一次调用和上一次是不是同一个逻辑操作」——所以它绑定创建者，不绑定任何租户身份，也不进 [S-27](#s-27-我的租户) 一类的读面。
**这一格是 architecture-reviewer 2026-09-22 阻断 2 的闭合**（[G-12](#十一已知缺口)）：此前 ⑦ 写「调用方须自带幂等键——本契约不提供」，而 ① 没有任何输入能携带它，调用方无法履行；
注册链早已有幂等边界（[`composition.account-registration/v1#S-9`](../../../compositions/account-registration/v1/contract.md#s-9-幂等边界)），创建团队组织没有理由例外。

### S-22 读组织

| # | 内容 |
|---|---|
| ① | `OrganizationId` |
| ② | 无授权前置。**本操作只返回组织自身的结构事实，不返回成员名单**——名单走 [S-59 列出组织成员](#s-59-列出组织成员)（**超管**），单个租户的效力走 [S-26 成员资格判定](#s-26-成员资格判定) |
| ③ | 无 |
| ④ | 只读，无提交 |
| ⑤ | `{ OrganizationId, OrganizationKind, 上级组织（有或无） }` |
| ⑥ | `organizationDoesNotExist`（本版**只在一种情形下被触发**：该组织是一个已被 [S-53](#s-53-清除未激活账号的个人组织) 清除的个人组织，见 [S-5](#s-5-组织)）· `invalidInput` · `unavailable` |
| ⑦ | 只读，天然可重复 |
| ⑧ | 读不到 ⇒ `unavailable`，**不得返回「不存在」**——[不可用 ≠ 不存在](../../../data/offer-expiry/v1/contract.md#s-20-不可用--不存在)；`OrganizationId` 缺席或不合形状 ⇒ `invalidInput`，**同样不得收成 `organizationDoesNotExist`**（[S-16](#s-16-缺席时的默认答案)：表示层校验不是一次判定结果） |
| ⑨ | 不发 |

**这个读面是 [S-15](#s-15-结构性禁止不是权限判定) 的兑现点**：`OrganizationKind` 让界面在不发起操作的前提下就知道「这里没有这个动作」。

### S-23 发出邀请

| # | 内容 |
|---|---|
| ① | 发起者 `TenantId`、目标 `AccountId`、指定角色（缺省普通成员）、**可选：这一份的有效时长**。**缺席不是拒绝，是按邀请这一类的默认值**（[S-10](#s-10-邀请)）——时长与指定角色是本操作两个有默认值的输入（[S-16](#s-16-缺席时的默认答案) 有表，读面的过滤开关另算），都不是身份参数，[S-16](#s-16-缺席时的默认答案) 那条「没有默认值」约束的是身份参数 |
| ② | 发起者在该组织的成员资格**有效且是超级管理员**；目标账号**已激活**；目标账号在该组织**尚无有效成员关系** |
| ③ | **有**：发起者 `TenantId` 的组织是个人组织 ⇒ **`issuerIsPersonalOrganization`**。**这不是权限判定**（[S-15](#s-15-结构性禁止不是权限判定)） |
| ④ | 写入一份邀请（带 `OfferTiming`，`data.offer-expiry/v1#S-5`：两个时刻在这次提交内定死、此后不可改；`expiresAt` 由①的指定时长算出，①缺席时由邀请这一类的默认值算出）。**单次提交** |
| ⑤ | `InvitationId` |
| ⑥ | **`issuerIsPersonalOrganization`** · `notAuthorized` · `accountNotActivated` · `accountDoesNotExist` · `alreadyAnEffectiveMember` · **`invalidOfferDuration`** · `invalidInput` · `unavailable` |
| ⑦ | **不幂等。**每次调用产生一份新的邀请。**本契约不去重未决邀请**——[过期与撤回是它们唯一的收场](../../../data/offer-expiry/v1/contract.md#s-12-过期与撤回收场相同)，多发几份不制造任何新状态，而去重要引入一个「什么算同一份」的判据，正文没有给 |
| ⑧ | 成员资格判定以 `unavailable` 失败，或账号读面不可用 ⇒ 本操作以 `unavailable` 失败；**不得按「读不到就不是成员」拒绝**，那会把失败说成失权。身份参数缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | `invitation.issued`（**必发**，通知） |

**授权前置就是超级管理员，不是第三种资格。**[flows §4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)
rev 12 曾在普通成员那一行写过「被授予管理资格时」可邀请新成员，而同 topic 的
[design §4 只有两种角色](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#角色)。
**产品负责人已裁定那是笔误，rev 13 正文已落盘**（[flows §4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)）：本版没有「管理资格」这样东西可授予，
邀请的资格**就是超级管理员**。**本契约因此不为它留任何扩展位**——
[S-3](#s-3-本契约明确不承诺什么) 已写明「不承诺角色矩阵之外的中间角色」，
将来真要加第三种角色，那是产品改角色矩阵，**不是在这里放宽一个前置**。

> **`notAuthorized` 不区分「不是成员」与「是成员但不是超管」。**两者都是一次成立的授权拒绝，
> 收场相同；分开会让调用方据失败值反推组织的成员名单，而[读成员名单要走 S-59](#s-59-列出组织成员)、
> 那里自己有授权前置。

**`invalidOfferDuration`：指定的时长非正或不合形状 ⇒ 拒绝，不写入任何东西。**
它是一次**表示层校验**，在进入任何判定之前发生，口径取
[`data.identity-values/v1#S-33`](../../../data/identity-values/v1/contract.md#s-33-表示层校验与判定分开)：
**这次拒绝不表示「该对象不存在」或「该主体无资格」，也不得被记成一次判定结果**。

**为什么不能省掉它、让一个非正时长「按默认值算」**：
那会把一份发起者以为立刻过期的邀请变成一份按默认值长期有效的邀请——
[指定时长是发起者对这一份的判断](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)，
把它静默替换成别的值，正是[缺席被当成放行理由](#s-16-缺席时的默认答案)的那类错误。
**缺席与非法是两件事**：缺席按这一类的默认值（[S-10](#s-10-邀请)），非法**拒绝**。

### S-24 撤回邀请

| # | 内容 |
|---|---|
| ① | 发起者 `TenantId`、`InvitationId` |
| ② | 该邀请由**发起者 `TenantId` 的那个组织**发出；发起者在该组织成员资格有效且是超级管理员 |
| ③ | 无（能发出的组织才有邀请可撤） |
| ④ | 写入终结记录 `withdrawn`（`data.offer-expiry/v1#S-7`）。单次提交。**这次提交内须先按 `data.offer-expiry/v1#S-8` 现读一次**：已终结**或已过期**的不写（见⑦） |
| ⑤ | `ok` |
| ⑥ | `invitationDoesNotExist` · `notAuthorized` · `alreadyConcluded` · `invalidInput` · `unavailable` |
| ⑦ | **幂等到本操作自己写的那条终结记录为止**：已 `withdrawn` ⇒ **`ok`**，无二次效果（这是一次重入，不是撞上别人的结论）。已 `accepted` ⇒ `alreadyConcluded`——[已经有了答复的邀约不再改写](../../../data/offer-expiry/v1/contract.md#s-8-判定式)。**已过期** ⇒ `alreadyConcluded`，**不写终结记录**（见下面的定义） |
| ⑧ | 邀请读不到、**过期判定读不到**（时间源不可用，`data.offer-expiry/v1#S-16`；**或[组织存在性读面](#s-22-读组织)不可用**，`data.offer-expiry/v1#S-20`）⇒ `unavailable`，**不写终结记录**。**存在性读面不可用一律收 `unavailable`，绝不得据此判成「组织不存在」从而判成已过期**——那会把一次抖动写成这份邀请的永久失效。`InvitationId` 缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | 不发 |

**`alreadyConcluded` 的定义写在这里，本契约是它的权威。**
[`data.offer-expiry/v1#S-8`](../../../data/offer-expiry/v1/contract.md#s-8-判定式) 只提一条**禁止**
（已过期的不得再被写入终结记录），**那个失败值叫什么、哪些情形算「已终结」，归本条**：

> **`alreadyConcluded` ＝ 存在一条本操作不会再写的终结记录（即 `accepted`），
> 或这份邀请已按 [`data.offer-expiry/v1#S-8`](../../../data/offer-expiry/v1/contract.md#s-8-判定式) 过期。**

**`withdrawn` 不在这个定义里，这是关键的一格。**它正是本操作**自己会写的**那条终结记录，
所以再撤回一份已 `withdrawn` 的**不是撞上别人的结论，是本操作的一次幂等重入** ⇒ **`ok`**（⑦）。
**「本操作不会再写的」这个限定不能省**：写成「终结记录存在」就把 `withdrawn` 一并括进来，
与⑦的幂等承诺当场矛盾——**那正是上一轮这里写错的地方**。

**过期那一支的理由**：[那份契约写明已过期的邀约不得再被写入任何终结记录](../../../data/offer-expiry/v1/contract.md#s-8-判定式)，
本操作**写不下去**，所以它与「已经有了答复」收场相同。
**不这样写会出什么**：一份 `expiresAt` 已过、却带着 `withdrawn` 记录的邀请，
读它时终结记录先截住 S-8，**派生状态从 `expired` 翻回 `withdrawn`**——
一个读时派生的状态被一次事后写入改掉了。收场相同不等于可以乱写：
[三种收场在接受路径上本来就同值](../../../data/offer-expiry/v1/contract.md#s-12-过期与撤回收场相同)，
撤回一份已过期的**本来就没有任何事可做**。

**「这份邀请不是你的组织发出的」返回 `invitationDoesNotExist`，不是 `notAuthorized`。**
`InvitationId` 是不透明标识（`data.identity-values/v1#S-31`），调用方不可能把它猜出来；
但**一旦拿到一个**，两个值的差别就是一次存在性泄漏——`notAuthorized` 等于确认「有这么一份，只是不归你」。
**这条对下面每一个按标识定位的操作一致成立**：[S-31](#s-31-撤回隶属请求)、[S-55](#s-55-读邀请)、[S-56](#s-56-读隶属请求)。

### S-25 接受邀请

| # | 内容 |
|---|---|
| ① | 接受者 `AccountId`、`InvitationId` |
| ② | 接受者**就是被邀请的那个账号**；**接受者的账号已激活**（消费账号已激活判定，[S-4](#s-4-依赖方向与被消费的面)）；该邀请按 `data.offer-expiry/v1#S-8` 求值为 `pending`——**这次求值必须在写入效果的同一次提交内重新做**（`data.offer-expiry/v1#S-10`），不得沿用调用前的读数 |
| ③ | 无 |
| ④ | **单次提交，且受 [S-17](#s-17-同一组织的成员写入序列化) 序列化**：过期重判 ＋ 成员关系记录置为有效 ＋ 角色写为邀请指定的那个 ＋ 邀请写入终结记录 `accepted`，**四者同时成立**。**②的账号已激活判定也落在这次提交内** |
| ⑤ | `TenantId` = (发出邀请的组织, 接受者账号) |
| ⑥ | `invitationDoesNotExist` · `offerNoLongerValid` · `notTheInvitedAccount` · **`accountNotActivated`** · **`accountDoesNotExist`** · `alreadyAnEffectiveMember` · `invalidInput` · `unavailable` |
| ⑦ | **幂等到成员关系为止**：同一份邀请再次接受 ⇒ **`offerNoLongerValid`**——依据是 `data.offer-expiry/v1#S-13`，`accepted` 是那条的**第三条来路**，与过期、撤回给同一个值。**已是有效成员时不产生第二条记录**（键是 `TenantId`，[S-8](#s-8-成员关系记录)） |
| ⑧ | 过期判定读不到（时间源或组织存在性读面不可用）⇒ `unavailable`，**不得放行，也不得判成已失效**（`data.offer-expiry/v1#S-20`）；账号读面不可用 ⇒ `unavailable`；`InvitationId`／`AccountId` 缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | `membership.changed`（通知） |

**`offerNoLongerValid` 是一个值，不是三个。**过期、撤回、**以及「已经被接受过了」**给出
**同一个拒绝结果**（`data.offer-expiry/v1#S-13`），
[flows §2 把「已过期或被撤回」与「发出邀请的组织不存在了」写成同一行反馈](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常)。
**本契约因此不设 `alreadyAccepted`，也不在这里借用 `alreadyConcluded`**——
后者是[撤回](#s-24-撤回邀请)那条操作的失败值，两条操作的收场不同，值不能串用。

**②补的「接受者账号已激活」是[本版到不了的观测点](#s-53-清除未激活账号的个人组织)，前置仍然保留。**
[发出](#s-23-发出邀请)那一步已经判过一次已激活，而**本版没有任何路径能让一个已激活的账号在此后消失或退回未激活**：
账号记录的唯一清除路径 `capability.account-identity/v1#S-38` **只对未激活且已过留存期限的记录成立**，
[已激活不回退、不消失](../../../capabilities/account-identity/v1/contract.md#s-20-已激活不回退不消失)。
**所以这两支在本版判不出真**——与 [S-53](#s-53-清除未激活账号的个人组织) ③那条空真的守卫是同一种东西。

**它仍然写进前置与失败集合，理由有三条，都不是「以防万一」：**

- **它是那条禁止在本操作上的观测点。**「已激活的账号不会消失」这件事不由本契约保证，
  它归[账号契约](../../../capabilities/account-identity/v1/contract.md#s-20-已激活不回退不消失)；
  **本操作现读一次，就是在本契约这一侧把那条禁止变成可被观察的**。少了它，那条禁止一旦被破，
  本操作会**静默**写出一条指向不存在账号的 `TenantId`，而没有任何地方会发现。
- **[唯一有意义的判定时点是写入的那一刻](#s-30-发出隶属请求)**——这与判环那条是同一个道理：
  「上游已经判过了」在两次提交之间不成立，而发出与接受**确实是两次提交**。
- **发出那一步的判定前提是产品规则，不是数据形状。**目标账号已激活这条前提今天由
  [S-23](#s-23-发出邀请) ②兑现；一旦将来多一条产生邀请的路径（或产品放宽那条前置），
  这两支**当场可达**，而收场已经写在这里。

`accountDoesNotExist` 与 `accountNotActivated` **分开**，理由同 [S-20](#s-20-创建个人组织)。
**不得把它们折进 `unavailable`**：它们是成立的拒绝结论，重试不会改变答案。

### S-26 成员资格判定

| # | 内容 |
|---|---|
| ① | `TenantId` |
| ② | 无授权前置。**这是一个纯读面**——放行与否由调用它的那个操作自己决定 |
| ③ | 无 |
| ④ | 只读，无提交。**每次调用现读**（[S-18](#s-18-每道准入现读)） |
| ⑤ | **判定做出来时**：一个 `MembershipStanding`——`effective`（带角色）/ `ineffective`，**恰两值**（[S-9](#s-9-成员资格判定结果两值不可用是读面失败)） |
| ⑥ | **`invalidInput`**；**以及 [`MembershipStandingResult`](../../../data/identity-values/v1/contract.md#s-10-membershipstanding) 的失败支 `failure = unavailable`**。**这两样都不是 `MembershipStanding` 的取值**——失败时不返回任何 standing |
| ⑦ | 只读，天然可重复。**返回值不得被缓存后复用而不写明失效条件**（[S-18](#s-18-每道准入现读)） |
| ⑧ | 读不到 ⇒ 以 `unavailable` **失败**，**不是返回 `ineffective`**。这是本契约最不能被折叠的一条。`TenantId` 缺席或不合形状 ⇒ `invalidInput`，**同样不是 `ineffective`** |
| ⑨ | 不发 |

**本操作的返回值是一个闭合和，恰两支：**

```text
S-26 的返回  ≝  invalidInput  |  MembershipStandingResult
```

- **左支 `invalidInput`：表示层拒绝，判定根本没有发生。**口径取
  [`data.identity-values/v1#S-33`](../../../data/identity-values/v1/contract.md#s-33-表示层校验与判定分开)，
  它是本契约[每个操作都有的那一项](#s-16-缺席时的默认答案)，**不是这个读面特有的东西**。
- **右支 [`MembershipStandingResult`](../../../data/identity-values/v1/contract.md#s-10-membershipstanding)：
  判定发生了，成或不成。**它的形状**归 `data.identity-values` v1，本契约引用不自定义**——
  那里写死它**恰有两支**：一个 `MembershipStanding`，或 `{ failure: "unavailable" }`。

> **`invalidInput` 为什么不是 `MembershipStandingResult` 的第三支。**
> 那个类型是**「判定结果」**的类型；而表示层拒绝按
> [`data.identity-values/v1#S-33`](../../../data/identity-values/v1/contract.md#s-33-表示层校验与判定分开) **不是一次判定结果**。
> 把它塞进去，那个类型就同时表示「判出来了」「判不出来」「没开始判」三件事，
> **而它的全部价值恰恰是逼消费者在前两者之间分支**。
> 所以分层是这样的：**操作的返回值分两支，右支再分两支**；
> [那份契约已就此写明](../../../data/identity-values/v1/contract.md#s-10-membershipstanding)——
> 表示层拒绝**在该类型之外，由操作自己的失败集合承载**。

**三样东西一律由返回值承载，一个都不走带外通道。**
`MembershipStanding`、`failure = unavailable` 与 `invalidInput`：

- **不得抛出一个调用方可以不接的异常，不得靠日志、事件或旁路信号传达。**
  走带外，一个**没有接住它**的调用方就会拿到一个看起来像 `ineffective` 的空值继续往下判，
  而[那正是「把不可用折成失权」](#s-9-成员资格判定结果两值不可用是读面失败)——
  这一次是由类型系统而不是由实现者引入的。
- **两种拒绝更不能走两条不同的通道**：消费者只会接住其中一条，
  漏掉的那条会沿着「没拿到 standing ⇒ 当作没有」滑进 `ineffective` 那一侧。
- **也不得把任何失败折进成功支**：`MembershipStanding` 只有两个取值（[S-9](#s-9-成员资格判定结果两值不可用是读面失败)），
  没有第三格可以放「判不出来」，更没有第四格放「没开始判」。

**超管读不到成员的私域，靠的就是这个读面。**成员的私域是他**个人组织**下的那个租户；
超管的账号不是那个个人组织的成员，判定结果是「无效」，访问被拒
（[flows §4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)：「读取成员的个人范围」对超管是**不可**）。
**这条成立的前提在别处**：各 owner 的访问点必须显式携带 `TenantId` 并调用本读面
（`data.identity-values` v1 的隔离义务）。本契约给判定，**不给强制**。

### S-27 我的租户

| # | 内容 |
|---|---|
| ① | `AccountId` |
| ② | 无授权前置 |
| ③ | 无 |
| ④ | 只读，无提交 |
| ⑤ | 该账号**此刻有效**的 `TenantId` 列表。**可以为空**，见⑧ |
| ⑥ | `unavailable` · `invalidInput` |
| ⑦ | 只读 |
| ⑧ | 读不到 ⇒ `unavailable`，**不得返回空列表**——空列表是一个会被当真的答案，读不到不是答案。`AccountId` 缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | 不发 |

**空列表什么时候是对的，写清楚。**[产品正文说「每个账号至少有一个有效租户」](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#租户)，
但那句话**只对已激活的账号成立**：

| 输入的账号 | 空列表 | 为什么 |
|---|---|---|
| **已激活** | **本版不可能，出现即是缺陷** | 个人组织没有销毁路径（[S-6](#s-6-两个变体与四条结构性禁止) 的例外只对未激活账号成立），[唯一成员又不能解除自己](#s-29-解除成员) |
| **未激活** | **可能，且是正确答案** | [S-53](#s-53-清除未激活账号的个人组织) 已经把它的个人组织清掉、而 `capability.account-identity/v1#S-38` 还没把账号记录清掉的那一段窗口里，这个账号确实一个有效租户也没有 |
| **不存在** | 见⑧ | 本操作**不判账号存在性**（②无授权前置、无账号读面消费）；一个不存在的 `AccountId` 得到的是空列表，**这不泄漏存在性**——它与「存在但没有有效租户」不可区分，[那正是想要的](../../../capabilities/account-identity/v1/contract.md#s-22-账号存在性不从登录路径泄漏) |

**因此⑧写的是「读不到不得返回空列表」，不是「空列表一定是错的」。**
两者的差别在清除窗口里是实在的：把空列表一律当成缺陷，
一个刚被清掉个人组织的未激活账号会让本操作报出一个**并不存在的**故障。

**这是[「聚合」那件事](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#账号)的兑现点，而它只是一个视图**：
它让人**看见**自己有哪些租户，**不给他任何跨组织的东西**。

### S-28 调整角色

| # | 内容 |
|---|---|
| ① | 发起者 `TenantId`、目标 `TenantId`（同一组织）、目标角色 |
| ② | 发起者成员资格有效且是超级管理员；目标的成员关系记录有效；**调整之后该组织仍有至少一位有效超级管理员** |
| ③ | 无 |
| ④ | **单次提交，且受 [S-17](#s-17-同一组织的成员写入序列化) 序列化**：上面那条「之后仍 ≥1 超管」的前置**与角色写入在同一次提交内**。**不得先查后写** |
| ⑤ | `ok` |
| ⑥ | `notAuthorized` · `membershipNotEffective` · `wouldLeaveNoSuperAdministrator` · `invalidInput` · `unavailable` |
| ⑦ | **幂等**：目标已经持有该角色 ⇒ `ok`，无二次效果 |
| ⑧ | 成员资格判定以 `unavailable` 失败 ⇒ 本操作以 `unavailable` 失败。**不得把读不到当成「没有别的超管」而拒**，也不得当成「还有别的超管」而放行。两个 `TenantId` 或目标角色缺席、不合形状、不在 `TenantRole` 的取值内 ⇒ `invalidInput` |
| ⑨ | `role.changed`（通知） |

**角色调整不改变 `TenantId`。**[flows §3.3 那一行「从成员到成员」不是冗余](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)——
角色变了，身份没变，此前的归属与署名不受影响。

### S-29 解除成员

| # | 内容 |
|---|---|
| ① | 发起者 `TenantId`、目标 `TenantId`（同一组织） |
| ② | 发起者**是目标本人**（退出），**或**发起者是该组织的超级管理员（移除）；目标的成员关系记录有效；**解除之后该组织仍有至少一位有效超级管理员** |
| ③ | **有**：目标组织是个人组织 ⇒ `personalOrganizationMemberCannotLeave`。[账号不能退出自己的个人组织](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#16-退出组织) |
| ④ | **单次提交，且受 [S-17](#s-17-同一组织的成员写入序列化) 序列化**：前置与「把成员关系记录置为无效」在同一次提交内 |
| ⑤ | `ok` |
| ⑥ | `personalOrganizationMemberCannotLeave` · `notAuthorized` · `membershipNotEffective` · `wouldLeaveNoSuperAdministrator` · `invalidInput` · `unavailable` |
| ⑦ | **幂等**：目标已无效 ⇒ `membershipNotEffective`，无二次效果 |
| ⑧ | 同 [S-28](#s-28-调整角色)，含 `invalidInput` 那一路 |
| ⑨ | `membership.changed`（通知） |

**并发移除对方只有一种收场。**两位超级管理员在不同地方同时移除或降级对方时，
**先成的一方成功，后成的一方被拒**，且被拒方拿到的是
**与单次被拒完全相同的那个值** `wouldLeaveNoSuperAdministrator`
（[flows §3.3](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)、
[flows §2](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常)、
[acceptance §三](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#三判据)）。
**被拒的一方不产生任何部分效果**，并且**可以按当时的实际状态重新发起**。

> **这句话在单机与分布式部署下是同一句话**——那正是
> [SYS-DEPLOY](../../../../foundation/cross-system-constraints/requirements.md#sys-deploy)「不改变领域语义」要的表述。
> 它的兑现物不是这句话本身，是 [S-17](#s-17-同一组织的成员写入序列化)。

### S-30 发出隶属请求

| # | 内容 |
|---|---|
| ① | 发起者 `TenantId`、接收方 `OrganizationId`、方向（请对方作上级 / 请对方作下级）、**可选：这一份的有效时长**。缺席按**隶属请求这一类**的默认值（[S-11](#s-11-隶属请求)），与邀请那一类**不共用取值** |
| ② | 发起者是**发起方组织**的超级管理员；接收方组织存在；**接收方组织不是发起方组织自己** |
| ③ | **有**：任一方是个人组织 ⇒ `personalOrganizationTakesNoPartInAffiliation` |
| ④ | 写入一份隶属请求（带 `OfferTiming`，同 [S-23](#s-23-发出邀请)；`expiresAt` 由①的指定时长算出，①缺席时由隶属请求这一类的默认值算出）。单次提交 |
| ⑤ | `AffiliationRequestId` |
| ⑥ | `personalOrganizationTakesNoPartInAffiliation` · `notAuthorized` · `organizationDoesNotExist` · **`wouldFormACycle`** · **`invalidOfferDuration`** · `invalidInput` · `unavailable` |
| ⑦ | **不幂等**，理由同 [S-23](#s-23-发出邀请) |
| ⑧ | 读不到 ⇒ `unavailable`；身份参数或方向缺席、不合形状 ⇒ `invalidInput` |
| ⑨ | **不发。接收方靠 [S-60 列出组织收到的隶属请求](#s-60-列出组织收到的隶属请求) 发现它**——[送达面是读面，不是事件](#s-40-事件都是通知) |

**此处不判一般的环，也不判「己方已有上级」。**两者都放在[接受](#s-32-接受隶属请求)那一步——
发出与接受之间隔着一段时间，在这里判出来的结论到接受时可能已经不成立，
而**唯一有意义的判定时点是写入的那一刻**。

**唯一在这里就判的是「指向自己」**：接收方组织就是发起方组织。
它与别的环不同——**它不随时间变**：两个 `OrganizationId` 相不相等，
[按不透明标识的交换表示逐码点比较即可算出，不读任何记录](../../../data/identity-values/v1/contract.md#s-31-不透明标识的交换表示)，
到接受时也是同一个答案。
**`OrganizationId` 是不透明标识，没有分量可拆**（`data.identity-values/v1#S-3`）——
可拆分量的是 `TenantId`（它是一对），不是这个。

**失败值就是 `wouldFormACycle`，不另立一个。**
自环是环的最短形态：`o` 的上级是 `o`，则 `o` 出现在自己的上级链上，
[这正是 S-7 那条「不成环」被违反的样子](#s-7-上级组织属性)。
为它单开一个 `cannotAffiliateWithItself` 会让消费者以为这是两类不同的拒绝，
而它们的收场完全相同：**这条边建不起来，换一个组织再来**。
[S-32](#s-32-接受隶属请求) 的判环同样覆盖这一情形——**两处用的是同一个判据、同一个值**。

**两个组织的超级管理员是同一个人时，他自己发起、自己接受，不设特例**
（[PF-001 §4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#隶属关系怎么建立与解除)）。

### S-31 撤回隶属请求

| # | 内容 |
|---|---|
| ① | 发起者 `TenantId`、`AffiliationRequestId` |
| ② | 该请求由**发起者 `TenantId` 的那个组织**发起；发起者是该组织的超级管理员 |
| ③ | 无 |
| ④ | 写入终结记录 `withdrawn`。单次提交。**这次提交内须先现读一次过期判定**，同 [S-24](#s-24-撤回邀请) ④ |
| ⑤ | `ok` |
| ⑥ | `affiliationRequestDoesNotExist` · `notAuthorized` · `alreadyConcluded` · `invalidInput` · `unavailable` |
| ⑦ | 幂等到**本操作自己写的那条**终结记录为止，同 [S-24](#s-24-撤回邀请)：已 `withdrawn` ⇒ **`ok`**。**`alreadyConcluded` 在这里是[同一个定义](#s-24-撤回邀请)**——存在一条本操作不会再写的终结记录（即 `accepted`），或已按 `data.offer-expiry/v1#S-8` 过期。**`withdrawn` 不在其内** |
| ⑧ | 请求读不到、**过期判定读不到**（时间源不可用；**或[接收方组织的存在性读面](#s-22-读组织)不可用**，`data.offer-expiry/v1#S-20`）⇒ `unavailable`，**不写终结记录**，**且不得据读不到判成「组织不存在」从而判成已过期**；`AffiliationRequestId` 缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | 不发 |

**「这份请求不是你的组织发起的」返回 `affiliationRequestDoesNotExist`**，理由同 [S-24](#s-24-撤回邀请)：
不泄漏存在性。**注意这一条只对发起方成立**——接收方组织的超管**撤不了**别人发来的请求，
他能做的是[不接受它、让它过期](../../../data/offer-expiry/v1/contract.md#s-12-过期与撤回收场相同)；
本版**没有「拒绝一份隶属请求」这个动作**，[产品正文没有给](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#17-建立与解除组织隶属)，本契约不自行补。

> **本操作比施工简报的操作表多一条。**[统一语言的词条写明隶属请求「被接受之前它可以被撤回」](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-affiliation-request--隶属请求--affiliation-request)，
> 而 `data.offer-expiry/v1#S-7` 的 `withdrawn` 对四类消费者一律成立。
> 没有这条操作，`withdrawn` 对隶属请求就是一个写不进去的状态。

### S-32 接受隶属请求

| # | 内容 |
|---|---|
| ① | 接受者 `TenantId`、`AffiliationRequestId` |
| ② | 接受者是**接收方组织**的超级管理员；该请求按 `data.offer-expiry/v1#S-8` 求值为 `pending`（**同提交内重判**，`#S-10`）；**由方向确定的那个下级组织尚无上级**；**接受之后不成环**（判据见④③） |
| ③ | **有**：任一方是个人组织 ⇒ `personalOrganizationTakesNoPartInAffiliation` |
| ④ | **单次提交**：① 过期重判 ＋ ② 「下级尚无上级」判定 ＋ ③ **判环** ＋ ④ 写入下级组织的上级组织属性 ＋ ⑤ 请求写入终结记录 `accepted`，**五者同时成立**。判环要读多条组织行，**这次读必须与写入落在同一提交边界内**。**判环的精确判据**：`newParent` **不是** `child` 自己，**且** `child` 不在 `newParent` 的上级链上——等价的一句是 **`child` 不在 `newParent` 含自身的上级链上**（`child ∉ {newParent} ∪ ancestorChain(newParent)`） |
| ⑤ | `ok` |
| ⑥ | `affiliationRequestDoesNotExist` · `offerNoLongerValid` · `notAuthorized` · `alreadyHasAParentOrganization` · `wouldFormACycle` · `personalOrganizationTakesNoPartInAffiliation` · `invalidInput` · `unavailable` |
| ⑦ | **幂等到上级属性为止**：同一份请求再次接受 ⇒ `offerNoLongerValid`——依据同 [S-25](#s-25-接受邀请) ⑦，`accepted` 是 `data.offer-expiry/v1#S-13` 的第三条来路。上级属性已是同一个值时不重复写 |
| ⑧ | 过期判定读不到（时间源不可用，`data.offer-expiry/v1#S-16`；**或[接收方组织的存在性读面](#s-22-读组织)不可用**，`data.offer-expiry/v1#S-20`）⇒ `unavailable`，**不得放行，也不得判成已失效**——与 [S-25](#s-25-接受邀请) ⑧同形；判环读不到 ⇒ `unavailable`，**不得在读不到部分组织行的情况下判定「不成环」**——那是把失败当成放行。`TenantId`／`AffiliationRequestId` 缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | 不发 |

**判环那一条为什么要写成两半。**只写「`child` 不在 `newParent` 的上级链上」是**不够的**：
[上级链按定义不含自己](#s-12-上级链与有共同上级)，所以 `child = newParent` 时这一条**恒真**——
三条前置全过，写进去的是一条 `o → o` 的自环。
**这不是推演出来的担忧**：[Alloy 的 `AcceptPreservesAcyclic` 在本机执行时正是给出了这个反例](formal/README.md)
（`child = newParent`，一份取值里 `parent = {(o, o)}`）。
**契约按反例改了判据，不是模型按契约改了断言。**

发出那一步已经挡掉了一部分（[S-30](#s-30-发出隶属请求) 的「指向自己」⇒ `wouldFormACycle`），
但**本条不得因此省掉自己这一半**：发出与接受是两次提交，
[唯一有意义的判定时点是写入的那一刻](#s-30-发出隶属请求)；
一份绕过 [S-30](#s-30-发出隶属请求) 写进来的请求、或将来多一条产生请求的路径，
都会让「上游已经挡过了」这句话失效。**判环是本操作自己的前置。**

**接受一份隶属请求不产生任何租户。**它只给一个属性填上值
（[PF-001 §4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#隶属关系怎么建立与解除)）。
本契约里**没有任何从这条路径通向成员关系写入的路**。

**单方面指定不允许，哪怕发起方是上级。**建立必须是 [S-30](#s-30-发出隶属请求) 与本操作各做一次。

### S-33 解除隶属

| # | 内容 |
|---|---|
| ① | 发起者 `TenantId`、被解除的那条隶属关系（下级 `OrganizationId`） |
| ② | 发起者是**任一方**组织的超级管理员——**单方面即可**，不需要一份隶属请求（[PF-001 §4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#隶属关系怎么建立与解除)） |
| ③ | 无 |
| ④ | 清空下级组织的上级组织属性。单次提交 |
| ⑤ | `ok` |
| ⑥ | `noSuchAffiliation` · `notAuthorized` · `invalidInput` · `unavailable` |
| ⑦ | **幂等**：属性已空 ⇒ `noSuchAffiliation`，无二次效果 |
| ⑧ | 读不到 ⇒ `unavailable`；`TenantId`／下级 `OrganizationId` 缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | `affiliation.dissolved`（通知） |

**解除之后各方还剩什么，不是本契约的事。**
[PF-003 §6.12 拥有那一格](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)：
分享失效、复制留着。**而分享失效不靠 `affiliation.dissolved` 这个事件**，见 [S-40](#s-40-事件都是通知)。

### S-53 清除未激活账号的个人组织

**编号排在后面，是因为本版编号只追加不重排（见抬头的「条款编号」）；它是一个与上面同级的写操作。**

| # | 内容 |
|---|---|
| ① | **`AccountId`，只收这一个。**不再收 `OrganizationId`——见下面「输入为什么收窄」 |
| ② | **求值次序固定，三步，不得调换**：**表示层校验** → **读账号**（`capability.account-identity/v1#S-18`）→ **读组织**。两条路各自的前置如下。**无授权前置**——它不是一条用户动作，调用面由装配限定（[S-42](#s-42-装配给的保证-vs-协议须给的保证)）<br>**（甲）账号读到了**：该账号**未激活**，**且该账号记录已过留存期限**——`capability.account-identity/v1#S-18` 返回值里的**激活状态**与**是否已过留存期限**（同一个读面的两个字段，[S-4](#s-4-依赖方向与被消费的面)），**两条都在本操作自己这一次提交内现读**。再读它的个人组织：**存在**则先过③（是个人组织）再清（④）；**已不存在**就按⑦幂等返回<br>**（乙）账号读不到**（`capability.account-identity/v1#S-18` 给 `account-not-found`）：**不在这一步失败，继续读组织**——**组织也已不存在 ⇒ `ok` 并返回依据**（两样都不在了，它断言的那件事本来就成立）；**组织仍在 ⇒ `accountDoesNotExist`**，**不删、不产出依据**（见下） |
| ③ | **有**：由 `AccountId` 定位到的那个组织的 `OrganizationKind` 不是 `personal` ⇒ `organizationIsNotPersonal`。**这是结构性禁止，不是权限判定**（[S-15](#s-15-结构性禁止不是权限判定)）：团队组织**没有**这条路径，谁来调都没有。**本版由 `AccountId` 定位到的只可能是它的个人组织**（存储上「账号 → 个人组织」的一一约束，[「每个账号至多一个个人组织」那条不变量](#不变量)），**因此这一支是空真的守卫**，仍写出来——它是「团队组织没有销毁路径」在本操作上的观测点。**次序**：本判定在②的三步**之后**——先读账号、再读组织，读到组织才判它的变体；**②乙先浮出**：账号读不到时走②乙的两支（`ok` 或 `accountDoesNotExist`），**不判③** |
| ④ | **单次提交，且受 [S-17](#s-17-同一组织的成员写入序列化) 序列化**：删除个人组织记录 ＋ 删除它那条唯一的成员关系记录，**两者同时成立**。**②甲的两条现读也在这次提交的判定里**——不得先读、放一会儿、再写。**②乙那一路不写入任何东西** |
| ⑤ | `ok`，**并返回一份清除依据**——它是 [`data.identity-values/v1#S-35` 交接凭证](../../../data/identity-values/v1/contract.md#s-35-交接凭证-handoff-warrant) 的一个**实例**：不透明值、由本操作产出、**绑定该 `AccountId`**、**不可伪造**、**本版不作废**（由 [`capability.account-identity/v1#S-38`](../../../capabilities/account-identity/v1/contract.md#s-38-清除到期的未激活账号记录) 核实，核实之后**不失效**；重放安全由 `capability.account-identity/v1#S-38` 前置②③的现读承担，见下）。它断言的只有一件事：「这个 `AccountId` 的个人组织已不存在」。**幂等那两路（组织本来就不存在）同样返回依据**——它们断言的是同一件事实 |
| ⑥ | `organizationIsNotPersonal` · `accountIsActivated` · **`accountNotExpired`** · **`accountDoesNotExist`**（**只在「账号不在、组织仍在」那一支**，②乙） · `invalidInput` · `unavailable`。**恰六个**。**个人组织已不存在 ⇒ `ok` 并返回依据**（见⑦），不是一个失败值 |
| ⑦ | **幂等，边界是那个账号**，**有两路**：<br>**（甲）账号仍在、个人组织已不存在**（被上一次清除掉）⇒ `ok` 并返回依据，无二次效果。**这一路仍要过②甲的两条现读**——组织没了不等于那个账号此刻还该被清（一个已激活的账号若因别的缺陷丢了个人组织，这里必须给 `accountIsActivated`，不能顺手发一份依据）。<br>**（乙）账号与个人组织都已不存在** ⇒ `ok` 并返回依据。**这一路过不了②甲的两条现读，因为读不到账号**；它成立靠的是另一条：**依据断言的那件事此刻为真**（这个 `AccountId` 的个人组织确实不在）。<br>这两路使[清除链可以安全重扫](../../../compositions/account-registration/v1/contract.md#s-34-第二条动作链未激活到期清除)：一次崩溃之后重来，无论崩在两步之间还是两步之后，都不会因为「已经清过了」而停住。**「组织没了不等于那个账号此刻还该被清」这句话只对甲成立**——乙那一路根本没有账号可判 |
| ⑧ | 账号读面**以 `storage-unavailable` 失败**、或组织行读不到 ⇒ 本操作以 `unavailable` 失败，**不清除、不产出依据**。**这与②乙的「账号不存在」是两件事，绝不可互相折叠**：`account-not-found` 是一个**成立的结论**（那条记录真的不在了），按②乙继续读组织；`storage-unavailable` 是**没有结论**，只能失败。**绝不得**把「判不出账号」当成「账号未激活」「已过期」或「账号不存在」而往下走——前两者会删掉一个已激活账号的个人组织，而[那是本版没有任何路径能做的事](#s-6-两个变体与四条结构性禁止)，或者删掉一个**正在注册的人**的空间；后者会在组织已不存在时发出一份**根本没有依据**的清除依据。`AccountId` 缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | `organization.purged`（**通知**）。携带被清除的 `OrganizationId` 与那个 `AccountId`。派发语义同[其余事件](#s-40-事件都是通知)：单向、不等待、无投递保证、**不是控制点**。**幂等重入（本就不存在）不再发**。**有意不发 `membership.changed`**，见下 |

**输入为什么收窄到只收 `AccountId`。**原来允许给 `OrganizationId`，理由是「两者定位到同一条记录」。
但②的**两条现读都是账号那一侧的事实**——给 `OrganizationId` 就得先反查出账号，
**而那条反查在组织已被清除之后就没有了**（幂等那一路正是组织不存在的那一路）。
于是「给 `OrganizationId` 且组织已不存在」这一支**取不到账号，既判不出前置、也产不出与账号绑定的依据**，
只能收成一个说不清的失败。**收窄到 `AccountId`，幂等那一路才和成功那一路一样完整。**
调用方（清除链）本来就握着 `AccountId`——[它是那条链的输入](../../../compositions/account-registration/v1/contract.md#s-34-第二条动作链未激活到期清除)。

**`accountDoesNotExist` 只在「账号不在、组织仍在」那一支给出，不是「读不到账号就失败」。**
读不到账号**本身不是结论**——[清除链的第二步做完之后，账号记录本来就该不在了](../../../compositions/account-registration/v1/contract.md#s-34-第二条动作链未激活到期清除)。
所以②乙先看组织：

| 账号 | 个人组织 | 收场 | 它说明什么 |
|---|---|---|---|
| 不在 | **也不在** | **`ok` ＋ 依据**（⑦乙） | **两步都已做完，这是一次重扫。**依据断言的「这个 `AccountId` 的个人组织已不存在」此刻为真 |
| 不在 | **还在** | **`accountDoesNotExist`**（**缺陷观测**） | [「个人组织存在 ⇒ 对应的账号记录存在」这条不变量已经被破](#七性质与前提)：次序反了，账号先于组织被清 |

**没有这个分岔，两种完全不同的局面会收成同一个值**：一次正常的重扫会被报成一次结构性缺陷，
于是清除链在重扫时停住，而[它必须能安全重扫](../../../compositions/account-registration/v1/contract.md#s-34-第二条动作链未激活到期清除)；
反过来，把两种都收成 `ok` 则会让一条真被破的不变量**没有任何地方会发现**。

**缺陷那一支是缺陷观测支（不删组织、不产依据、须报出），不是「顺手把组织删了」。本操作只报，不改**
（它在清除链上属哪一类、怎么处置，分类词归 [`composition.account-registration/v1#S-34` 的三分类](../../../compositions/account-registration/v1/contract.md#s-34-第二条动作链未激活到期清除)，本契约不自立分类）：

- **不删那个组织。**这条不变量被破意味着次序出了问题（账号先于组织被清），
  而此刻**判不出这个组织该不该留**——②甲的两条现读都读账号，账号没了就无从判起。
  删它等于在一个已知有缺陷的状态上再做一次不可逆的写。
- **不产出依据。**依据断言的是「组织已不存在」，而它还在。
- **它是这条不变量唯一的运行期观测点**：除了这里，没有别的地方会同时看到「组织在、账号不在」。
  实现**必须**让这个失败值可被观测到（日志、计量、告警由提供者设计决定），
  **不得把它折进 `unavailable`**——那会把一次结构性缺陷伪装成一次基础设施抖动。

**有意不发 `membership.changed`。**本操作确实删掉了一条成员关系记录，
但那个事件的契约含义是[「这个 `TenantId` 的有效性变了」](#s-40-事件都是通知)，
**消费者据它去刷新可达性判定**。这里的 `TenantId` **连同它的组织一起不存在了**，
没有任何可达性需要被刷新；发一条指向已消失对象的 `membership.changed`，
消费者拿它去调 [S-26](#s-26-成员资格判定) 只会得到 `ineffective`，**什么也没说明**。
需要知道这件事的消费者听 `organization.purged`——**它携带足够的信息，而且形状是对的**。

**`OrganizationId` 不回收。**被清除的那个标识**不复用、不重新分配**
（`data.identity-values/v1#S-3`）。因此一条指向它的历史记录不会指到别的组织身上，
[S-22 读组织](#s-22-读组织) 对它永远给 `organizationDoesNotExist`，而不是给出另一个组织。

**②甲的两条现读都是硬拒绝，不是时序竞争的安慰值。**

- **`accountIsActivated`**：[注册主链的第 3 步一旦提交，那个账号就永久可用](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#31-账号)；
  本操作在同一次提交里现读激活状态，**读到已激活就终止**，
  清除链因此[不可能在激活成立之后还把个人组织删掉](../../../compositions/account-registration/v1/contract.md#s-34-第二条动作链未激活到期清除)。
- **`accountNotExpired`**：记录还在留存期限内就**不能清**。
  没有这一条，本操作就只能**信任调用方**关于「这条记录该清了」的判断——
  而一个实现错了的清扫提供者会据此删掉一个**刚注册、正走在注册流程中**的人的个人空间，
  使他的[注册第 3 步再也激活不了](../../../compositions/account-registration/v1/contract.md#s-8-三步次序与责任交接)。
  **本操作因此自己判，不接受任何形式的代判。**

> **它与 `capability.account-identity/v1#S-38` 的 `not-expired` 是对称的一对。**
> 清除链的两步**各自现读同一个单调事实**——`capability.account-identity/v1#S-18` 的「是否已过留存期限」——
> 在各自的提交里判，**谁也不替谁判、谁也不信谁的断言**。
> 这与[本契约挡住孤儿个人组织用的是同一招](#s-20-创建个人组织)：
> **找一个单调的事实，让每个写入者在自己的提交里读它。**
> 两步的防御强度因此相同；少掉任何一边，那一边就退化成「信任上游」。

**本操作不碰账号记录，但它为账号那一半产出依据。**
账号记录由 `capability.account-identity/v1#S-38` 清除，
**次序与理由归** `omne-harness-lite-design-2026-09-15 · composition.account-registration · v1`
的[第二条动作链](../../../compositions/account-registration/v1/contract.md#s-34-第二条动作链未激活到期清除)。

本操作成功时产出的那份**清除依据**，断言的**只有一件事**：
**这个 `AccountId` 的个人组织已不存在。**它**不断言**那个账号此刻仍未激活、仍已过期——
那两条由 `capability.account-identity/v1#S-38` [自己的前置照判](../../../capabilities/account-identity/v1/contract.md#s-38-清除到期的未激活账号记录)。
依据是**次序的凭证**，不是**状态的快照**。

**它绑定一个对象标识，本版不作废。**
[`data.identity-values/v1#S-35` 的性质 3 与 4](../../../data/identity-values/v1/contract.md#s-35-交接凭证-handoff-warrant)
要求每个实例写死「绑定哪个对象标识」与「作不作废」，**本条就是清除依据这一侧的落点**：

| 项 | 本实例是什么 |
|---|---|
| 绑定的对象标识 | **输入的那个 `AccountId`**。一份为 A 产出的依据**不能**用在 B 身上 |
| 作废 | **不作废。**被 [`capability.account-identity/v1#S-38`](../../../capabilities/account-identity/v1/contract.md#s-38-清除到期的未激活账号记录) 核实之后**不失效**。重扫既可以重放旧的一份，也可以重新调本操作取一份新的——本操作对「组织本来就不存在」幂等返回成功并**再产出一份**（⑦）——**两份断言的是同一件事实，在语义上可互换** |

**为什么本版不作废。**依据断言的只有「这个 `AccountId` 的个人组织已不存在」。
个人组织只在[注册第 ② 步](../../../compositions/account-registration/v1/contract.md#s-8-三步次序与责任交接)为一条**未过留存期限**的记录创建（[S-20](#s-20-创建个人组织) 前置②），
而「已过留存期限」是单调的（`capability.account-identity/v1#S-18`）、本操作又只对已过期的记录成功（②甲）——
所以一份依据一经产出，那个 `AccountId` 的记录此后再也建不出个人组织，**断言一经成立永远为真**。
重放一份旧依据因此造不成任何错误删除：`capability.account-identity/v1#S-38` 在**自己的提交里**现读前置②③（未激活、已过期），
一份依据放行不了任何被那两条现读挡住的记录——即便那个 `AccountId` 之后对应一条新记录，那条记录未过期，`capability.account-identity/v1#S-38` 前置③的现读就挡住它。
**「核实后作废」因此是一个没有收益的运行时状态**，本版不设；两个实例（激活依据、清除依据）本版都不作废，
口径与 [`data.identity-values/v1#S-35` 性质 4](../../../data/identity-values/v1/contract.md#s-35-交接凭证-handoff-warrant) 同句：**重放安全由核实方在自己提交里的前置现读承担**。

**「依据」这样东西不是本契约自造的，它有拥有者。**
[`data.identity-values/v1#S-35` 交接凭证 Handoff Warrant](../../../data/identity-values/v1/contract.md#s-35-交接凭证-handoff-warrant)
定义了这一类值的全部性质——不透明、由一步操作产出、绑定一个对象标识、由下一步操作核实、
**不可伪造是契约承诺**（怎么做到归 realization）。
本操作产出的清除依据与 `capability.account-identity/v1#S-14` 消费的激活依据，
**是同一个概念的两个实例**，三份契约引用同一条，**不各写一份**。

**「不可伪造」是承诺，不是实现细节。**没有它，
[S-53](#s-53-清除未激活账号的个人组织) → `capability.account-identity/v1#S-38`
这条次序守卫就是空的：任何能构造出一个像依据的值的调用方，
都能让 `capability.account-identity/v1#S-38` 在组织根本没清的情况下删掉账号记录。
**核实方必须能确认这份依据由产出方签发、且绑定该 `AccountId`。**

#### 本操作的产品依据

[PF-001 §4「未激活的账号记录不会永久占着那个名字」](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#未激活的账号记录不会永久占着那个名字)
**rev 12** 只说了**账号记录**被清掉，**没说它的个人组织与第一个租户身份怎么办**——
本操作因此一度是一条产品正文不支持的规格层推导。
**产品负责人已裁定补上，rev 13 正文已落盘**：
**为它准备的个人组织与第一个租户身份随之消失——它们从未承载任何东西。**
本操作是那句话的落点。**这一条不登记缺口**：正文已经写着它。

本契约**不发起 `capability.account-identity/v1#S-38`、不等待它、也不核实它做没做**——
[依赖方向是单向的：治理 → 账号](#s-4-依赖方向与被消费的面)，反过来的一条也没有。
**产出依据不构成一条反向依赖**：依据是本操作的返回值，交给调用方（清除链），
由调用方带给 `capability.account-identity/v1#S-38`；本契约不知道它被拿去做了什么。

### S-34 上级链与有共同上级

| # | 内容 |
|---|---|
| ① | 一个 `OrganizationId`（求上级链）或两个（求有共同上级） |
| ② | 无授权前置 |
| ③ | 无 |
| ④ | 只读，**读时求值**（[S-12](#s-12-上级链与有共同上级)），不返回缓存的旧结果 |
| ⑤ | 上级链：组织序列，**不含自己**，个人组织**恒为空序列**；有共同上级：布尔，判据是**两条含自身的链有交**（[S-12](#s-12-上级链与有共同上级)），也就是**同一棵隶属树**。个人组织与**任何与它不同的**组织**恒假** |
| ⑥ | `organizationDoesNotExist` · `invalidInput` · `unavailable` |
| ⑦ | 只读 |
| ⑧ | 链上任一组织行读不到 ⇒ `unavailable`，**不得返回一条截断的链**——截断的链会让 `shareAncestor` 悄悄变成假，而假在这里就是「不许流转」，一次抖动变成一次拒绝。`OrganizationId` 缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | 不发 |

**两个返回值的口径不同，这是有意的**：上级链**不含自己**（它回答「我上面有谁」），
`shareAncestor` **把各自算进来**（它回答「我们在不在同一棵树上」）。
**实现不得用本操作返回的那条链直接求交来算 `shareAncestor`**——
那正是 [PF-001 rev 12 改掉的那个读法](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)，
它会把**一个组织与它自己的上级**判成不同树。
消费者要「同一棵树」这个答案，**调 `shareAncestor` 这一支，不要自己从链上算**。
两个谓词的定义式归 `data.identity-values/v1#S-14`／`#S-15`（[S-12](#s-12-上级链与有共同上级)），本操作只是它们的读面。

### S-35 层身份

| # | 内容 |
|---|---|
| ① | `TenantId` |
| ② | 无授权前置。**本操作不判定这个租户此刻有没有效**——那是 [S-26](#s-26-成员资格判定) 的事，两者要分开调 |
| ③ | 无 |
| ④ | 只读，纯派生（`TenantId` 的两半就是答案） |
| ⑤ | `{ 组织级: ScopeLayerIdentity(organization), 租户级: ScopeLayerIdentity(tenant) }` |
| ⑥ | **`invalidInput`，就这一个。****没有 `unavailable`**——本操作不读存储、不调任何提供者，**不存在「判不出来」这种情形** |
| ⑦ | 纯计算 |
| ⑧ | 输入缺席或不合形状 ⇒ `invalidInput`，**不得由环境补齐**（[S-16](#s-16-缺席时的默认答案)） |
| ⑨ | 不发 |

**`unavailable` 被删掉了，这不是简化。**原来写的是「`unavailable`（仅当输入本身不合形状时）」——
那把两件事揉在一个值上：`unavailable` 的契约含义是**没有结论、按当时实际状态重试可能得出不同答案**
（[S-16](#s-16-缺席时的默认答案)），而一个不合形状的 `TenantId` **重试一万次也是同一个答案**。
本操作是纯计算，**它永远有结论**；[表示层校验那一类归 `invalidInput`](#s-16-缺席时的默认答案)。

**会话级那一格不在返回值里，而不是返回一个空值。**[缺口 G-1](#十一已知缺口)：
返回一个 `null` 等于替 PF-015 答了「这一层没有身份」，而正文没说过这句话。

### S-36 当前租户身份查询

| # | 内容 |
|---|---|
| ① | `LoginStateId` |
| ② | 该登录状态**此刻仍有效**（消费登录状态校验面，[S-4](#s-4-依赖方向与被消费的面)） |
| ③ | 无 |
| ④ | 只读。**该登录状态尚未做过任何切换时，答案是 (该账号的个人组织, 该账号)**——这是[初值](#s-14-当前租户身份是登录状态上的一项选择)，不是一次写入 |
| ⑤ | `TenantId` |
| ⑥ | `loginStateNotValid` · `invalidInput` · `unavailable` |
| ⑦ | 只读 |
| ⑧ | 登录状态校验读不到（`capability.account-identity/v1#S-17` 的 `storage-unavailable`）⇒ `unavailable`；**校验说「拒绝」（同条的 `login-state-rejected`）⇒ `loginStateNotValid`**。两者不得合并。**那项选择本身读不到**（存储不可用，分不清「没切换过」与「读失败」）⇒ `unavailable`，**不得收成④的初值**——初值是「尚未做过任何切换」这个**已判出的事实**的答案，读不到没有这个事实，填初值等于把一次抖动说成「你还没切换过」并把调用方悄悄放回个人组织租户（[§6.4 禁止的静默回退](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)）。`LoginStateId` 缺席或不合形状 ⇒ `invalidInput`，**不是 `loginStateNotValid`**——后者是一次成立的校验结论，前者根本没进校验 |
| ⑨ | 不发 |

**返回的 `TenantId` 不承诺此刻有效。**成员关系可能在切换之后被解除；
**本契约不在那时改写这项选择**（[S-14](#s-14-当前租户身份是登录状态上的一项选择)）。
调用方要放行，仍须走 [S-26](#s-26-成员资格判定) 现读。

### S-37 切换当前租户身份

| # | 内容 |
|---|---|
| ① | `LoginStateId`、目标 `TenantId` |
| ② | 该登录状态此刻仍有效；**目标 `TenantId` 的账号那一半就是这个登录状态所属的账号**；目标的成员资格判定为**有效** |
| ③ | 无 |
| ④ | 写入这项选择。单次提交 |
| ⑤ | `ok` |
| ⑥ | `loginStateNotValid` · `notOwnTenant` · `membershipNotEffective` · `invalidInput` · `unavailable` |
| ⑦ | **幂等**：切到已选中的那个 ⇒ `ok`，无二次效果 |
| ⑧ | **两处各自分开收场，共四种**：登录状态校验读不到 ⇒ `unavailable`，**校验说「拒绝」⇒ `loginStateNotValid`**（`capability.account-identity/v1#S-17` 的两个不放行出口，见 [S-4](#s-4-依赖方向与被消费的面)）；成员资格判定以 `unavailable` 失败 ⇒ 本操作以 `unavailable` 失败，**不是 `membershipNotEffective`**。[目标范围不可用时明确失败，不静默回退到个人范围](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)。`LoginStateId` 或目标 `TenantId` 缺席／不合形状 ⇒ `invalidInput` |
| ⑨ | 不发 |

**切换只影响此后新建的东西。**先前在别的租户身份下建起来的东西**一律不动**：
它们持有创建那一刻的那个 `TenantId`，成本、归属与求值一概照它算
（[PF-001 §4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#当前租户身份)、
[flows §1.8](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#18-切换当前组织)）。

**切换不把任何一层的事实复制到另一层，方向两边都算**，也不改变账号身份
（[PF-001 §6.4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)、
[decisions 九条确认第 6 条](../../../../product/PF-001-identity-scope-and-agent-constraints/decisions.md#2026-09-22--九条正文规则逐条确认为产品要求)）。
**本操作写的是一项选择，写不到任何一层去**——它[不是范围化对象](#s-14-当前租户身份是登录状态上的一项选择)。

### 六个读面：邀约与成员现在是什么样

**编号 S-55～S-60 排在后面，是因为本版编号只追加不重排（见抬头的「条款编号」）。**

**这六条补的是一个真实的空洞。**本契约此前拥有[邀请](#s-10-邀请)与[隶属请求](#s-11-隶属请求)的
**全生命周期**，却**一个都读不出来**：

- `data.offer-expiry/v1#S-9` 要求派生状态**在读的那一刻求值**，
  可本契约**没有任何读面**能返回那个状态——那条规矩因此在本契约里**没有落点**；
- [S-3](#s-3-本契约明确不承诺什么) 写着「对方收到了一份邀约」的含义**就是「对方查询得到它」**，
  而本契约**没有给他可以查询的那个面**——**隶属请求这一侧尤其致命**：
  它连 `invitation.issued` 那样的通知都没有，
  [接收方因此在系统内根本无从得知一份请求存在](#s-60-列出组织收到的隶属请求)，
  [flows §1.7 那条「对方组织的超管接受」在契约里走不通](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#17-建立与解除组织隶属)；
- [S-22](#s-22-读组织) 明说它**不返回成员名单**，并把读者指向 [S-26](#s-26-成员资格判定)——
  但 [S-26](#s-26-成员资格判定) 只回答「这一个 `TenantId` 有没有效」，**列不出名单**。

**授权按[能力间内部面的口径](#s-42-装配给的保证-vs-协议须给的保证)**：调用方身份由入口层核实，
本契约仍在每条里写明**该由谁看**——这是判定，不是「反正上游会挡」。

#### S-55 读邀请

| # | 内容 |
|---|---|
| ① | 调用方身份、`InvitationId`。**调用方身份是一个带判别式的值，恰两支**：`account`（携一个 `AccountId`）／ `tenant`（携一个 `TenantId`）。**判别式集合封闭**（`data.identity-values/v1#S-32`）：**收到集合外的判别式一律 `invalidInput`**，不得靠「哪个字段有值就是哪一支」去猜 |
| ② | **两类人之一，与①的两支一一对应**：判别式为 `account` ⇒ 它必须是**被邀请的那个账号**本人；判别式为 `tenant` ⇒ 它的组织必须是**发出这份邀请的那个组织**，且该 `TenantId` 的成员资格有效、角色是**超级管理员**。**其余一律不给** |
| ③ | 无 |
| ④ | 只读，**读时求值**（`data.offer-expiry/v1#S-9`） |
| ⑤ | `{ InvitationId, 发出它的组织, 被邀请的账号, 指定的角色, OfferTiming, 派生状态 }`。**派生状态四值**：`pending`／`accepted`／`withdrawn`／**`expired`**，按 `data.offer-expiry/v1#S-8` 在**本次读取的时点**求出，**不得返回缓存的旧值** |
| ⑥ | `invitationDoesNotExist` · `invalidInput` · `unavailable` |
| ⑦ | 只读，天然可重复。**返回的派生状态不得被缓存后复用**（同[S-18](#s-18-每道准入现读) 的口径） |
| ⑧ | 邀请读不到、时间源读不到（`data.offer-expiry/v1#S-16`）、**或[组织存在性读面](#s-22-读组织)读不到**（`data.offer-expiry/v1#S-20`）⇒ `unavailable`，**不得返回一个缺了派生状态的结果，也不得把派生状态填成 `pending`**，**更不得据存在性读不到就把它判成 `expired`**。②的 `tenant` 支要做成员资格判定：**成员资格判定以 `unavailable` 失败 ⇒ 本操作以 `unavailable` 失败，不得收成 `invitationDoesNotExist`**——那是把失败说成「没有这份」（[S-9](#s-9-成员资格判定结果两值不可用是读面失败)），与 [S-59](#s-59-列出组织成员) ⑧同形。`InvitationId` 缺席、不合形状，或①的判别式不在集合内 ⇒ `invalidInput` |
| ⑨ | 不发 |

**②不满足时返回 `invitationDoesNotExist`，不是 `notAuthorized`**（理由见 [S-24](#s-24-撤回邀请)：不泄漏存在性）。
**按不透明标识定位的四条操作一致如此**——[S-24](#s-24-撤回邀请)、[S-31](#s-31-撤回隶属请求)、
本条与 [S-56](#s-56-读隶属请求)：**拿不到那个标识的人不该知道它对应的东西在不在**，
而拒绝值一旦可区分，`notAuthorized` 就等于确认「有这么一份，只是不归你」。
**按组织定位的 [S-58](#s-58-列出组织发出的邀请与隶属请求)／[S-59](#s-59-列出组织成员)／[S-60](#s-60-列出组织收到的隶属请求) 不在其内**：
调用方本来就拿着自己的 `TenantId`，**没有存在性可泄漏**，所以那三条给 `notAuthorized`。

#### S-56 读隶属请求

| # | 内容 |
|---|---|
| ① | 调用方 `TenantId`、`AffiliationRequestId` |
| ② | 调用方是**发起方组织或接收方组织**的**超级管理员**。**两端都能读**——[接受要由接收方做](#s-32-接受隶属请求)，读不到就无从决定 |
| ③ | 无 |
| ④ | 只读，读时求值 |
| ⑤ | `{ AffiliationRequestId, 发起方组织, 接收方组织, 方向, OfferTiming, 派生状态 }`。派生状态口径同 [S-55](#s-55-读邀请)；**判过期用的指向对象只有接收方组织**（[S-11](#s-11-隶属请求)） |
| ⑥ | `affiliationRequestDoesNotExist` · `invalidInput` · `unavailable` |
| ⑦ | 只读 |
| ⑧ | 同 [S-55](#s-55-读邀请) ⑧，含那一支：**成员资格判定以 `unavailable` 失败 ⇒ 本操作以 `unavailable` 失败，不得收成 `affiliationRequestDoesNotExist`** |
| ⑨ | 不发 |

**②不满足同样返回 `affiliationRequestDoesNotExist`。**

#### S-57 列出账号收到的待接受邀请

| # | 内容 |
|---|---|
| ① | `AccountId`、**可选**：只要 `pending` 的，还是连已终结的一起要（**默认只要 `pending` 的**） |
| ② | **无授权前置**，写法同 [S-27 我的租户](#s-27-我的租户)：**输入的 `AccountId` 就是调用者本人**，这个身份由入口层核实（[S-42](#s-42-装配给的保证-vs-协议须给的保证) 的「调用方身份已经核实过」）。**本操作不自己核实，也不因此变成「谁都能读」**——它返回的全部内容都以那一个 `AccountId` 为界。**没有第二类人**：[超管看不到某个人在别处收了哪些邀请](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)，那是跨组织的信息，**本操作也没有任何输入能表达那个请求** |
| ③ | 无 |
| ④ | 只读，**列表里每一项的派生状态都在本次读取时点求值** |
| ⑤ | 该账号收到的邀请列表，每项形状同 [S-55](#s-55-读邀请) ⑤。**默认只含此刻派生状态为 `pending` 的那些**；①要求「连已终结的一起要」时，`accepted`／`withdrawn`／`expired` 的也在内，**各带它此刻求出的那个派生状态**。**默认那一路里已过期的不在列表中**（它此刻不是 `pending`），**但这不是一次写入**——它们没有被标记，只是没被这次求值选中 |
| ⑥ | `invalidInput` · `unavailable` |
| ⑦ | 只读 |
| ⑧ | 读不到、时间源读不到、**或[组织存在性读面](#s-22-读组织)读不到** ⇒ `unavailable`，**不得返回空列表，也不得返回一份少了几项的列表**——空列表在这里是一个会被当真的答案（「你没有待处理的邀请」）。**更不得据存在性读不到就把某一项判成 `expired` 从而把它从默认列表里滤掉**。`AccountId` 缺席、不合形状，或过滤开关不在取值集合内 ⇒ `invalidInput` |
| ⑨ | 不发 |

**空列表是正常结果**：大多数账号任何时刻都没有待接受的邀请。
⑧禁的是**把读失败说成空列表**，不是禁止空列表本身——与 [S-27](#s-27-我的租户) ⑧同一口径。

**①那个开关的形状与 [S-58](#s-58-列出组织发出的邀请与隶属请求)／[S-59](#s-59-列出组织成员)／[S-60](#s-60-列出组织收到的隶属请求) 一致，默认也一致**
（三条邀约列表面默认只要 `pending` 的，[S-59](#s-59-列出组织成员) 默认只要有效的）。
**四条读面同形不是凑整齐**：它们是同一种东西——**按某个主体列出一批东西，默认只给「现在还要你处理的那些」**。
形状分叉会让调用方在四条之间各记一套规矩，而这一格没有任何理由分叉。

> **为什么要给这个开关，而不是只给 `pending`。**
> 一份已被接受的邀请**仍然是这个账号收到过的东西**，
> 而本账号是[唯一能看见它的人](#十二消费者核对)——
> 没有这个开关，他**没有任何面**能回看「我当初接受的那份邀请是哪个组织发的、给的什么角色」，
> 而 [S-55](#s-55-读邀请) 要按 `InvitationId` 读，那个标识不透明、他早已丢掉。
> **默认仍是只要 `pending` 的**：绝大多数调用要的是待办，把已终结的默认带上只会让列表越用越长。

#### S-58 列出组织发出的邀请与隶属请求

| # | 内容 |
|---|---|
| ① | 调用方 `TenantId`、**可选**：只要 `pending` 的，还是连已终结的一起要（**默认只要 `pending` 的**，与 [S-57](#s-57-列出账号收到的待接受邀请)／[S-60](#s-60-列出组织收到的隶属请求) 同形） |
| ② | 调用方是**该 `TenantId` 的那个组织**的超级管理员。**产品已定**（[PF-001 rev 15 flows §4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)）：本组织发出的邀约**只有超级管理员看得见**，普通成员不可——**这不再是本契约自己取的一档** |
| ③ | 无 |
| ④ | 只读，每项派生状态读时求值 |
| ⑤ | 两段：该组织**发出的邀请**（形状同 [S-55](#s-55-读邀请) ⑤）与该组织**发起的隶属请求**（形状同 [S-56](#s-56-读隶属请求) ⑤）。**接收方那一侧的隶属请求不在这里**，它归 [S-60 列出组织收到的隶属请求](#s-60-列出组织收到的隶属请求)——**两个方向分成两条操作，不合并**：本条回答「我发出去的还悬着几份」，那条回答「有谁在等我点头」，授权相同但**用途与读者的动作不同**（前者接着可能去[撤回](#s-31-撤回隶属请求)，后者接着可能去[接受](#s-32-接受隶属请求)） |
| ⑥ | `notAuthorized` · `invalidInput` · `unavailable` |
| ⑦ | 只读 |
| ⑧ | 存储读不到、**时间源读不到**（`data.offer-expiry/v1#S-16`）、**或[组织存在性读面](#s-22-读组织)读不到**（`data.offer-expiry/v1#S-20`）⇒ `unavailable`，**不得返回空列表，也不得返回一份少了几项的列表**。**本条每一项都带派生状态**（⑤引的两个形状里都有它），**求不出派生状态就没有结果可返回**——不得把它填成 `pending`，也不得据存在性读不到就判成 `expired`。②的成员资格判定以 `unavailable` 失败 ⇒ 本操作以 `unavailable` 失败，**不得收成 `notAuthorized`**（与 [S-59](#s-59-列出组织成员) ⑧同形）。`TenantId` 缺席、不合形状，或过滤开关不在取值集合内 ⇒ `invalidInput` |
| ⑨ | 不发 |

**这一条的失败值是 `notAuthorized`，不是 `…DoesNotExist`**——
与 [S-55](#s-55-读邀请)／[S-56](#s-56-读隶属请求) 不同：那两条按**不透明标识**定位，
拒绝值一旦可区分就泄漏该标识对应的东西在不在；本条按**组织**定位，
而调用方本来就拿着自己的 `TenantId`，**没有存在性可泄漏**。

#### S-59 列出组织成员

| # | 内容 |
|---|---|
| ① | 调用方 `TenantId`、**可选**：只要有效的，还是连无效的一起要（**默认只要有效的**）。**这个开关跨一道授权分界**，②按档分别判 |
| ② | **按①那一档判，两档不同**。**默认档（只要有效的）**：调用方是**该 `TenantId` 的那个组织**的有效成员，**任一[租户角色](#s-8-成员关系记录)都可以**——[产品已定：成员名单对本组织每一位有效成员可见](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)（PF-001 rev 15 flows §4）；**判的只有成员资格，不判角色**。**「连无效的一起要」这一档**：调用方是**该组织的超级管理员**——[产品已定：查看已解除的成员只归超级管理员](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)（同上），**普通成员请求这一档 ⇒ `notAuthorized`**。**两档共同**：非本组织的一律不给 |
| ③ | 无 |
| ④ | 只读，**每次调用现读**（[S-18](#s-18-每道准入现读)） |
| ⑤ | 该组织的成员关系记录列表，每项 `{ TenantId, 角色, 有效性 }`——**恰好是[成员关系记录](#s-8-成员关系记录)的三样**。**默认只返回有效的那些**；无效的那些**只在超管走「连无效的一起要」那一档时才出现**（②）。**普通成员拿到的列表里不含任何无效项**——不是把它们的字段隐去，**是它们不在这份列表里**。**每一项的角色与有效性是本次读取时点的投影，不得作准入依据**：准入仍按 [S-18](#s-18-每道准入现读) 在那一道现读 [S-26](#s-26-成员资格判定)——[`data.identity-values/v1#S-10`](../../../data/identity-values/v1/contract.md#s-10-membershipstanding) 里 `MembershipStanding` 是一次判定的结果，名单上的那一格不是那次判定 |
| ⑥ | `notAuthorized` · `invalidInput` · `unavailable` |
| ⑦ | 只读。**返回值不得被缓存后复用而不写明失效条件**（[S-18](#s-18-每道准入现读)）。**两档的返回值不得互相复用**：超管那一档取回的整份列表，**不得被裁剪之后当作默认档的结果交给另一个调用方**——那是拿一次超管授权下的读取去兑一次普通成员的读取 |
| ⑧ | 成员资格读面以 `unavailable` 失败 ⇒ 本操作以 `unavailable` 失败，**不得返回一份不全的名单**——不全的名单会让调用方据它得出「他不是成员」，那是把失败说成失权（[S-9](#s-9-成员资格判定结果两值不可用是读面失败)）；**②自己那次判定不可用也一样 ⇒ `unavailable`，不得收成 `notAuthorized`**，**两档都是**（超管那一档要多判一次角色，角色读不到同样是 `unavailable`）。**「连无效的一起要」被拒时给的是 `notAuthorized`，不得降级成「按默认档返回」**——静默降级会让调用方以为这个组织从没解除过谁。`TenantId` 缺席、不合形状，或过滤开关不在取值集合内 ⇒ `invalidInput`（**这一类在②之前发生**，[S-16](#s-16-缺席时的默认答案) 第三类） |
| ⑨ | 不发 |

**它返回 `TenantId` 而不是 `AccountId`。**成员关系的键就是 `TenantId`（[S-8](#s-8-成员关系记录)），
账号那一半可以从它按分量取出（`data.identity-values/v1#S-5`）。
**返回 `TenantId` 使调用方拿到的是一个可以直接再去调 [S-26](#s-26-成员资格判定)／[S-28](#s-28-调整角色)／[S-29](#s-29-解除成员) 的值**，
不必自己拼。**后两条本来就只有超管能调**——本条默认档让普通成员读得到名单，
**不使任何写操作跟着放宽**：普通成员拿到的是一个能用于判定与引用的值，
不是一条可以据以改动别人的路径。

> **这条是 [S-22 读组织](#s-22-读组织) 那句「后者要走 S-26」的真正落点。**
> [S-26](#s-26-成员资格判定) 回答的是「**这一个**租户有没有效」，它**列不出名单**；
> 把读者指向它，读者会以为自己漏看了什么。**名单在这里。**

> **它不给跨组织的任何东西。**调用方在这里看到的全是**他自己这个组织**的成员关系；
> 一个成员在别处有哪些租户，[只有本人能看](#s-27-我的租户)。
> [超管读不到成员的私域](#s-26-成员资格判定)这条不因本读面改变——
> 名单上的 `TenantId` 全都以**这个组织**为一半。
> **两档都一样**：本条给的是**这个组织这一层**的成员与角色，
> 产品正文把这一层的有效成员[定成协作可见](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)，
> 别的层一样够不着——**超管走「连无效的一起要」那一档多拿到的是本组织已解除的成员，不是别的层**。

> **①那个开关的两档，授权不同，这是产品已定**（[PF-001 rev 15](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)）。
> 产品把成员名单拆成两行：**有效成员那一份对本组织每一位有效成员可见，已解除的那些只归超级管理员**——
> 理由是共事到有效成员就用完了，而「谁被解除过」是超管管理成员（移除、再次邀请）才要用的一面。
> **所以这个开关不是纯粹的取值过滤，它跨了一道授权分界**：
> 按「有效性只是[成员关系记录](#s-8-成员关系记录)的一个字段、两档同一个前置」实现，
> **普通成员就能把这个组织解除过谁全部读出来**。
> **失败集合不变、不新增失败值**——被拒的那一档给的是 `notAuthorized`，它本来就在⑥里。

#### S-60 列出组织收到的隶属请求

| # | 内容 |
|---|---|
| ① | 调用方 `TenantId`、**可选**：只要 `pending` 的，还是连已终结的一起要（**默认只要 `pending` 的**） |
| ② | 调用方是**该 `TenantId` 的那个组织**的超级管理员。**只有超管**——[接受一份隶属请求本来就只有超管能做](#s-32-接受隶属请求)，给普通成员看它没有任何可接的动作。**产品已定**（[PF-001 rev 15 flows §4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)）：本组织收到的隶属请求**只有超级管理员看得见**，理由与这里写的是同一条——**这不再是本契约自己取的一档** |
| ③ | 无 |
| ④ | 只读，**列表里每一项的派生状态都在本次读取时点求值**（`data.offer-expiry/v1#S-9`） |
| ⑤ | 以该组织为**接收方**的隶属请求列表，每项 `{ AffiliationRequestId, 发起方组织, 方向, OfferTiming, 派生状态 }`。**派生状态四值**：`pending`／`accepted`／`withdrawn`／**`expired`**，按 `data.offer-expiry/v1#S-8` 求出；**判过期用的指向对象是接收方组织，也就是调用方自己**（[S-11](#s-11-隶属请求)），所以本列表里**不可能**出现因指向对象消失而过期的项 |
| ⑥ | `notAuthorized` · `invalidInput` · `unavailable` |
| ⑦ | 只读，天然可重复。**返回的派生状态不得被缓存后复用**（同 [S-55](#s-55-读邀请) ⑦） |
| ⑧ | 存储读不到、时间源读不到、**或[组织存在性读面](#s-22-读组织)读不到**（`data.offer-expiry/v1#S-20`）⇒ `unavailable`，**不得返回一份残缺的列表**——少了几项的列表会让超管以为某份请求已经不在了，而它可能正悬着、马上要过期。**也不得返回空列表充当读失败**（同 [S-57](#s-57-列出账号收到的待接受邀请) ⑧、[S-59](#s-59-列出组织成员) ⑧的口径）。**存在性那一支在本条格外要写明**：判过期用的指向对象**就是调用方自己的组织**（⑤），读不到它**绝不得**判成「组织不存在 ⇒ 全表过期」——那会把一次抖动变成「你收到的请求一份都不剩」。②的成员资格判定以 `unavailable` 失败 ⇒ 本操作以 `unavailable` 失败，**不得收成 `notAuthorized`**（与 [S-59](#s-59-列出组织成员) ⑧同形）。`TenantId` 缺席、不合形状，或过滤开关不在取值集合内 ⇒ `invalidInput` |
| ⑨ | 不发 |

**这一条补的是隶属请求唯一的发现路径。**在它之前，一份隶属请求发出去之后，
**接收方在系统内没有任何办法知道它存在**：[S-56](#s-56-读隶属请求) 要按 `AffiliationRequestId` 读，
而那个标识是不透明的（`data.identity-values/v1#S-31`），接收方猜不出来；
[S-58](#s-58-列出组织发出的邀请与隶属请求) 只列**自己发出的**；
[S-30 发出隶属请求⑨不发任何事件](#s-30-发出隶属请求)。
于是[flows §1.7 那条「对方组织的超管接受」](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#17-建立与解除组织隶属)
**在契约里走不通**——他永远等不到可以接受的那一刻。

> **补的是读面，不是事件，这一步是有意的。**邀请那一侧有 `invitation.issued`，
> 隶属请求这一侧**仍然不发**（[S-30](#s-30-发出隶属请求) ⑨不变）。
> 理由与 [S-40](#s-40-事件都是通知) 那段一致：
> **送达面是读面，不是事件**——[内核不提供可靠投递](../../../../foundation/cross-system-constraints/requirements.md#sys-deploy)，
> 把「对方得知道」挂在一个可能漏发的通知上，漏一次就留下一份没人看得见的请求。
> [S-3](#s-3-本契约明确不承诺什么) 早写过：「对方收到了」的含义**就是「对方查询得到它」**。
> 本条使这句话对隶属请求**第一次成立**。

> **空列表是正常结果。**大多数组织任何时刻都没有待处理的隶属请求。
> ⑧禁的是**把读失败说成空列表**，不是禁止空列表本身。

---

## 五、解除之后剩下什么

### S-38 解除只改成员关系的有效性

解除成员关系（[S-29](#s-29-解除成员)）**只做一件事**：把那条记录置为无效。

**它不做的三件事，逐条写明**：

| 不做 | 为什么这条要写进契约 |
|---|---|
| **不删除任何租户级持有** | [他在这个组织里的 customized 资产与租户级配值留在原处，不可达但不销毁](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)。[acceptance 把「被清掉」列为绝不能发生](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#二绝不能发生的事) |
| **不铸任何新身份** | `TenantId` 由 (组织, 账号) 确定，[不因成员关系断续而变](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#退出之后再加入回来的是同一个租户) |
| **不发出任何删除、迁移或清理指令** | 「不可达」的含义是**没有有效身份能到达它**，不是把数据搬走或删掉 |

**「不可达」这件事的兑现点不在本契约。**本契约给的是 [S-26](#s-26-成员资格判定) 的判定；
**资产 owner 必须以成员关系的有效性判可达、且不因无效而删持有**——
那是 `data.identity-values` v1 的隔离义务条款，不是本契约能强制的事。

**组织范围创作的资产留在组织，作者记录照旧**
（[PF-001 §6.7](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#67-创作与归属)）。
本契约对此只承诺一件事：**`TenantId` 永久可被引用**——它没有销毁路径，
所以一条指向它的历史记录永远不会变成孤儿。

### S-39 回来的是同一个租户

再次被邀请并接受（[S-25](#s-25-接受邀请)），**把同一条记录重新置为有效**，
返回的是**同一个 `TenantId`**。

**这不是一次恢复动作**：没有东西被删过，也就没有东西需要恢复
（[PF-001 §4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#退出之后再加入回来的是同一个租户)）。
**角色不继承**——新的角色由这次邀请指定，缺省是普通成员（[S-10](#s-10-邀请)）。

---

## 六、事件

### S-40 事件都是通知

| 事件 | 何时发出 | 携带什么 |
|---|---|---|
| `membership.changed` | [S-25 接受邀请](#s-25-接受邀请)、[S-29 解除成员](#s-29-解除成员)提交之后 | `TenantId`、新的有效性 |
| `role.changed` | [S-28 调整角色](#s-28-调整角色)提交之后 | `TenantId`、新的角色 |
| `affiliation.dissolved` | [S-33 解除隶属](#s-33-解除隶属)提交之后 | 两个 `OrganizationId` |
| `invitation.issued` | [S-23 发出邀请](#s-23-发出邀请)提交之后 | `InvitationId`、发出它的组织 |
| `organization.purged` | [S-53 清除未激活账号的个人组织](#s-53-清除未激活账号的个人组织)提交之后 | 被清除的 `OrganizationId`、那个 `AccountId` |

**`invitation.issued` 不再是「可选」。**原来标成可选，是把「发不发」留给了实现——
而一个**发**的部署与一个**不发**的部署，在消费者看来是两份不同的契约。
**本契约的事件本来就不承担任何必须发生的后果**（见下三条负向承诺），
所以「必发」不给任何人新的保证，**它只是把这一格从实现选项变回契约事实**：
消费者可以据它写出一条会失败的断言（「发出邀请之后观察到一条 `invitation.issued`」），
而一个可选的事件连断言都写不出来。

> **必发不等于必达。**[内核不提供可靠投递](../../../../foundation/cross-system-constraints/requirements.md#sys-deploy)；
> 「必发」约束的是**发出方在提交之后必定派发一次**，不约束任何监听者收没收到。
> **邀请的送达面是 [S-55](#s-55-读邀请)／[S-57](#s-57-列出账号收到的待接受邀请) 那两个读面，不是这个事件**——
> [S-3](#s-3-本契约明确不承诺什么) 早就写明「对方收到了」的含义是「对方查询得到它」。

**五个都是通知，含义是三条负向承诺：**

1. **发出方不等待任何监听者，也不读取监听者的返回值。**
2. **监听者失败、缺席或根本没有，不改变已经提交的那个事实。**
3. **事件不承担任何必须发生的后果。**没有任何一条性质靠「某个监听者收到了它」成立。

**`affiliation.dissolved` 特别要写明：[PF-003 的分享失效不靠它](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)。**
分享是否仍然成立，是一次**求值条件**——每次使用时按 [S-34](#s-34-上级链与有共同上级) 现读判定。
靠事件就意味着漏一次通知留下一份仍然生效的分享，而
[内核不提供可靠投递](../../../../foundation/cross-system-constraints/requirements.md#sys-deploy)。
**同理 `membership.changed` 不是撤销的兑现点**——[撤销靠每道准入现读](#s-18-每道准入现读)。

### S-41 本版不开控制类事件

**跨租户放行、接受邀约前校验，本版都不开成事件。**它们是操作自身的**同步前置**，
在同一提交边界内求值（[S-25](#s-25-接受邀请)、[S-28](#s-28-调整角色)、[S-32](#s-32-接受隶属请求)）。

**将来若开成控制类扩展点，本契约先立一条：**

> 任何参与放行判定的扩展点，**要么是同步前置，要么是逐个等待其结论的顺序派发**；
> **不得使用「发出即不等待」的派发**。

**这条是语言无关的。**它在本项目内核上的具体投影——异步控制必须用 `serial` 派发、
**不得用 `bail`**（`bail` 不 await，返回的 Promise 不是 bail 值，授权检查会静默放行）——
**是提供者设计的绑定，不是本契约的条款**；写在这里只为让扩展点落地时不必重新推一遍。

---

## 七、性质与前提

性质的来源一律引 PF 小节；**编号只在本表内作行标，不是可外部引用的条款号**。

### 不变量

| 性质 | 谁在何处保护 | 前提 | 来源 |
|---|---|---|---|
| **任何组织在任何时刻至少有一位有效的超级管理员** | [S-28](#s-28-调整角色)、[S-29](#s-29-解除成员) 的同提交前置 ＋ [S-17](#s-17-同一组织的成员写入序列化) 的序列化 | 存储兑现序列化。**量化在「存在的组织」上，对 [S-53](#s-53-清除未激活账号的个人组织) 空真**：它在同一提交内把个人组织与它唯一的成员关系记录一起删掉，被清除的组织不在量化域内——那不是一条「把超管清空」的路径，也不是这条不变量的反例 | [§4 角色](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#角色)、[flows §3.3](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)、[acceptance §二](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#二绝不能发生的事) |
| **至多一个上级组织** | [S-7](#s-7-上级组织属性)：数据形状，不存在写第二个值的路径 | — | [§4 组织](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织) |
| **上级链不成环，自环也不行** | [S-32](#s-32-接受隶属请求) 的同提交判环（**两半**：`newParent` 不是 `child` 自己，且 `child` 不在 `newParent` 的上级链上）＋ [S-30](#s-30-发出隶属请求) 的「指向自己」前置 | 判环读到的组织行与写入同源。**只写后一半会漏掉自环**——[Alloy 给出过那个反例](formal/README.md) | [§4 组织](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)、[decisions 第 4 条](../../../../product/PF-001-identity-scope-and-agent-constraints/decisions.md#2026-09-22--九条正文规则逐条确认为产品要求) |
| **个人组织：上级恒空、不作上级、不可邀请、唯一成员不可解除** | [S-6](#s-6-两个变体与四条结构性禁止)＋[S-23](#s-23-发出邀请)/[S-29](#s-29-解除成员)/[S-30](#s-30-发出隶属请求)/[S-32](#s-32-接受隶属请求) 的失败集合项 | — | [§4 个人组织](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#个人组织) |
| **每个账号至多一个个人组织** | [S-20](#s-20-创建个人组织) 的幂等边界 ＋ 存储上「账号 → 个人组织」一一约束 | 存储兑现唯一约束；**「每个账号」指每一条存在的账号记录**（[S-6](#s-6-两个变体与四条结构性禁止)）。**只写「至多」，不写「恰有」**：「至少一个」在两个可达窗口里为假——注册第 ② 步提交之前那条记录还没有个人组织；[S-53](#s-53-清除未激活账号的个人组织) 把个人组织删掉之后、`capability.account-identity/v1#S-38` 把账号记录删掉之前，那条记录也没有——「至少一个」只对已激活的账号成立，**挂在下面「已激活的账号 ⇒ 恰有一个个人组织」那一行** | [§4 个人组织](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#个人组织) |
| **已激活的账号至少有一个有效租户** | [S-20](#s-20-创建个人组织) 的提交（组织＋成员关系＋超管三者同时成立）＋ [S-6](#s-6-两个变体与四条结构性禁止) 的禁止 2（唯一成员不能解除自己）＋ [S-53](#s-53-清除未激活账号的个人组织) ②的 `accountIsActivated` | **这一条是从 [S-27](#s-27-我的租户) ⑧拆出来的单向式，不是 ⇔**。反方向（**未**激活的账号也至少有一个有效租户）**在清除窗口里为假**，[S-27](#s-27-我的租户) 因此写明未激活账号的空列表是正确答案 | [§4 租户](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#租户) |
| **个人组织存在 ⇒ 对应的账号记录存在** | **保护点是清除链的次序 ＋ 依据**：[S-53](#s-53-清除未激活账号的个人组织) 是个人组织唯一的销毁路径，它成功时**产出一份清除依据**，而 `capability.account-identity/v1#S-38` **把「持有与该 AccountId 绑定的清除依据」写成了自己的前置**——组织先于账号被清；建的那一侧由 [S-20](#s-20-创建个人组织) 的前置②守住（账号存在且未过期才建得出个人组织） | **本契约只兑现一步**（产出依据、同提交删两条记录），**次序由组合承担**；**⇒ 由「依据」这条运行期凭证兑现**——`capability.account-identity/v1#S-38` 没有依据就拒绝，因此**次序在运行期有对应物**，不只是组合契约的一句条款。**依据只证明「组织那半已做」**，不证明账号此刻仍可清，那两条由 `capability.account-identity/v1#S-38` 自己的前置照判。**与组合契约 [S-35](../../../compositions/account-registration/v1/contract.md#s-35-个人组织不会变成孤儿) 逐字同形**——反方向（账号记录存在 ⇒ 个人组织存在）**不是不变量**，上一行已写明它在两个窗口里为假 | [flows §1.1](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#11-注册)、[§3.1](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#31-账号)、组合契约 [S-35](../../../compositions/account-registration/v1/contract.md#s-35-个人组织不会变成孤儿) |
| **已激活的账号 ⇒ 恰有一个个人组织** | **至多一个**：上面「每个账号至多一个个人组织」那一行；**至少一个**：激活侧的前置——激活要出示[激活依据](../../../data/identity-values/v1/contract.md#s-35-交接凭证-handoff-warrant)（`capability.account-identity/v1#S-14` 前置③，依据由 [S-20](#s-20-创建个人组织) 成功产出），[S-20](#s-20-创建个人组织) ④在同一提交里把组织、成员关系与超管一起建起来；此后 [S-53](#s-53-清除未激活账号的个人组织) ②甲的 `accountIsActivated` 与 [S-6](#s-6-两个变体与四条结构性禁止) 的例外（已激活账号的个人组织没有销毁路径）守住它不消失 | 「至少一个」那一半**不由本契约独立兑现**——激活侧的前置在账号契约里，[S-20](#s-20-创建个人组织) 只保证「建了就三者同在」。**与组合契约 [S-13](../../../compositions/account-registration/v1/contract.md#s-13-一个可用账号有且仅有一个个人组织) 是同一条不变量**（那边的措辞是「一个可用账号有且仅有一个个人组织」，「可用账号」即已激活的账号）；那一条的另一面「不存在已激活却没有个人组织的账号」是同一条，不单列 | [§4 个人组织](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#个人组织)、[§3.1](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#31-账号)、组合契约 [S-13](../../../compositions/account-registration/v1/contract.md#s-13-一个可用账号有且仅有一个个人组织) |
| **租户身份跨成员关系断续保持同一** | [S-8](#s-8-成员关系记录) 的键 ＋ [S-38](#s-38-解除只改成员关系的有效性)／[S-39](#s-39-回来的是同一个租户) | — | [§4 退出之后再加入](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#退出之后再加入回来的是同一个租户) |
| **一个租户在其组织内只持一个角色** | [S-8](#s-8-成员关系记录)：单值字段 | — | [§4 角色](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#角色) |

### 安全性质（绝不能发生）

| 绝不能发生 | 谁在何处保护 | 前提 | 来源 |
|---|---|---|---|
| **两次同时的动作各自合法、合起来把超管清空** | [S-17](#s-17-同一组织的成员写入序列化) | 存储兑现序列化；跨节点须真正协调（[S-42](#s-42-装配给的保证-vs-协议须给的保证)） | [flows §3.3](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)、[acceptance §三](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#三判据) |
| **一份已过期、已撤回或已被接受过的邀约，被再次接受之后产生了效果** | [S-25](#s-25-接受邀请)、[S-32](#s-32-接受隶属请求)：同提交重判（`data.offer-expiry/v1#S-10`），三条来路同收 `offerNoLongerValid`（`data.offer-expiry/v1#S-13`） | 时间源同源可用 | [§4 两种邀约都会过期](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期) |
| **接受一份隶属请求产生了租户** | [S-32](#s-32-接受隶属请求)：没有通向成员写入的路径 | — | [§4 隶属关系怎么建立与解除](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#隶属关系怎么建立与解除) |
| **单方面建立隶属关系** | [S-32](#s-32-接受隶属请求) 的授权前置：接收方组织的超管 | — | 同上 |
| **切换把某一层的事实复制到另一层，或账号事实进了某一层** | [S-37](#s-37-切换当前租户身份)：本操作只写一项选择，**没有写向任何层的路径** | 各 owner 的层事实写路径只以显式 `TenantId`／`OrganizationId` 为键（隔离义务） | [§6.4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)、[decisions 第 6 条](../../../../product/PF-001-identity-scope-and-agent-constraints/decisions.md#2026-09-22--九条正文规则逐条确认为产品要求) |
| **撤销之后旧菜单、缓存或历史成功继续当授权** | [S-18](#s-18-每道准入现读) | 任何缓存写明失效条件——**各 owner 的责任** | [§6.6](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#66-撤销不等于强制停止)、[decisions 第 8 条](../../../../product/PF-001-identity-scope-and-agent-constraints/decisions.md#2026-09-22--九条正文规则逐条确认为产品要求) |
| **目标范围不可用时静默回退到个人范围** | [S-9](#s-9-成员资格判定结果两值不可用是读面失败)、[S-16](#s-16-缺席时的默认答案)、[S-37](#s-37-切换当前租户身份) ⑧ | 调用方据 `unavailable` 失败、不自行回退——**各 owner 的责任** | [§6.4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)、[decisions 第 5 条](../../../../product/PF-001-identity-scope-and-agent-constraints/decisions.md#2026-09-22--九条正文规则逐条确认为产品要求) |
| **超级管理员读到成员的个人范围** | [S-26](#s-26-成员资格判定)：超管的账号不是那个个人组织的成员，判定为「无效」 | 各 owner 的访问点显式携带 `TenantId` 并调用本读面（隔离义务） | [flows §4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)、[acceptance §二](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#二绝不能发生的事) |
| **解除成员把他的租户级持有清掉，或再加入时换了身份** | [S-38](#s-38-解除只改成员关系的有效性)、[S-39](#s-39-回来的是同一个租户) | 资产 owner 不因成员关系无效而删持有（隔离义务） | [flows §3.3](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)、[acceptance §二](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#二绝不能发生的事) |
| **角色变更回溯改写已发生的归属或署名** | [S-8](#s-8-成员关系记录)：角色不进 `TenantId` | 作者记录存 `TenantId` 而非角色——**资产 owner 的责任** | [§6.7 作者用租户身份标识](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#作者用租户身份标识) |
| **拒绝之后留下部分效果** | 全部写操作的④：前置与写入同提交 | 存储的单次提交原子性 | [flows §2](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常) |

### 进展性质（全部有界）

| 性质 | 上界 | 前提 | 来源 |
|---|---|---|---|
| 接受邀请成功返回之后，**下一次**成员资格判定即为有效 | 下一次判定 | 存储可用 | [flows §1.5](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#15-邀请与加入) |
| 一份未接受也未撤回的邀约，**不迟于 `issuedAt + offer_ttl`** 进入不可接受 | `offer_ttl`，**不依赖任何定时器** | 时间源可用、同源，且 **`now` 不后退**（[`data.offer-expiry/v1#S-17` 的「`now` 不后退」行](../../../data/offer-expiry/v1/contract.md#s-17-装配给的保证-vs-协议须给的保证)：单机装配给，跨进程归它的缺口） | [§4 两种邀约都会过期](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期) |
| 第二次动作（接受）成功返回之后，隶属关系即成立 | 该次返回 | 存储可用 | [flows §1.7](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#17-建立与解除组织隶属) |
| 解除成员成功返回之后，**下一道**准入被拒 | 下一道准入 | 各 owner 现读、缓存写明失效条件 | [flows §1.6](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#16-退出组织)、[§6.6](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#66-撤销不等于强制停止) |
| 角色调整成功返回之后，**第一道**准入按新角色判 | 第一道准入 | 同上 | [§4 角色](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#角色) |
| 重新加入成功返回之后，原租户级私有部分**原样可用** | 该次返回 | 资产侧未销毁（[S-38](#s-38-解除只改成员关系的有效性) 的前提） | [flows §3.3](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系) |
| 被拒的操作**立即**返回一个具名拒绝值，且不留部分效果 | 该次返回 | 存储原子性 | [flows §2](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常) |

**「不迟于」「下一次」「下一道」这些措辞是有意的**：它们写得出会失败的断言。
[规格入口要求进展性质有证据形式](../../../README.md#按需展开形式化工件)——
「最终会生效」写不出，「下一道准入就生效」写得出。

---

## 八、装配给的保证 vs 协议须给的保证

### S-42 装配给的保证 vs 协议须给的保证

[SYS-DEPLOY](../../../../foundation/cross-system-constraints/requirements.md#sys-deploy) 要求领域语义在分布式演化中不变，
因此右列不是「以后再说」，而是**本契约已经记下的待兑现项**。

| 保证 | 本版（单机）由谁给 | 跨进程之后谁重新兑现 |
|---|---|---|
| **任何时刻至少一位有效超管**（[S-17](#s-17-同一组织的成员写入序列化)） | **装配给**：同一存储对同一组织的成员写入天然序列化 | **协议给**：跨节点必须真正协调（分布式锁、单一写者或等价协议）。**「以后加锁」不是一个答案**——[S-29](#s-29-解除成员) 那句话在两种部署下必须是同一句话 |
| **上级链不成环**（[S-32](#s-32-接受隶属请求)） | **装配给**：判环读到的多行与写入在同一次存储提交内 | **协议给**：须定义跨节点判环的一致性级别，并说明两次并发接受各自判出「不成环」时的收场 |
| **每个账号至多一个个人组织**（[S-20](#s-20-创建个人组织)） | **装配给**：存储上的一一约束 | **协议给**：跨节点的唯一性分配 |
| **[S-53](#s-53-清除未激活账号的个人组织) 只由清除链调用** | **装配给**：那条操作自己**没有授权前置**，它在本版成立靠的是「只有 `composition.account-registration` v1 的清除链够得着它」——与该组合契约的 [S-25](../../../compositions/account-registration/v1/contract.md#s-25-装配给的保证-vs-协议须给的保证) 同句 | **协议给**：跨进程后「够不着」不再成立，须在接收边界鉴别调用方并为它定义授权。**做不到就等于给了一条直接删任何账号个人组织的入口**——它前面那三条现读（未激活、已过期、是个人组织）挡得住误删，**挡不住有权限的人删错目标** |
| **成员资格的可见性**（[S-18](#s-18-每道准入现读)、[S-26](#s-26-成员资格判定)） | **装配给**：写入即可被下一次读看到 | **协议给**：须定义传播时延上界，并把它纳入契约；在上界内旧判定仍被放行这件事必须写明，不能默认为零 |
| **当前租户身份这项选择的可见性**（[S-36](#s-36-当前租户身份查询)、[S-37](#s-37-切换当前租户身份)） | **装配给**：切换写入即可被下一次查询看到 | **协议给**：同上。**切换之后立刻创建的东西落在哪个租户身份上**，在传播窗口内必须有确定答案 |
| **邀约过期判定的时钟同源**（`data.offer-expiry/v1#S-17`） | **装配给** | **协议给**：由 `data.offer-expiry` v1 拥有，本契约不重复承诺 |
| **调用方身份已经核实过**（全部写操作与读面，**[S-36](#s-36-当前租户身份查询)／[S-37](#s-37-切换当前租户身份) 两条除外，理由见下**） | **装配给**：本契约的面是**能力间内部面**，不是终端 API。入口层（apps 装配）先把 `LoginStateId` 换成当前租户身份（[S-36](#s-36-当前租户身份查询)）或校验出 `AccountId`（`capability.account-identity/v1#S-17`），再带着那个身份值调本契约；**本契约不再核实这个身份是不是调用者本人的** | **协议给**：跨进程时调用必须**携带授权依据**，并**在接收边界重新验证**（`data.identity-values/v1#S-30`）。**不得只靠「上游已经验过了」**——那句话在同一进程里由调用链保证，跨进程之后什么也不保证 |
| **读面的调用方身份**（[S-22](#s-22-读组织)、[S-26](#s-26-成员资格判定)、[S-27](#s-27-我的租户)、[S-34](#s-34-上级链与有共同上级)、[S-35](#s-35-层身份)、[S-55](#s-55-读邀请)～[S-60](#s-60-列出组织收到的隶属请求)，**十一条读面，一条不漏**） | **装配给**：同上一行 | **协议给**：同上一行 |

**这两行是本轮补的，补的是一处真实的缺口。**评审指出：本契约的写操作只收发起者的
`TenantId`／`AccountId`，**从不核实调用方确实是那个身份**；几个读面连授权前置都没有
（[S-22](#s-22-读组织)、[S-26](#s-26-成员资格判定)、[S-27](#s-27-我的租户)、[S-34](#s-34-上级链与有共同上级)、[S-35](#s-35-层身份) 的②写着「无授权前置」）。

**主线裁定：这批是能力间内部面，终端 API 归 apps 装配。**这个裁决有代价，代价写在这里：

- **本契约的授权判定全部以「身份值是真的」为前提。**这个前提**不由本契约兑现**，
  谁拿到一个 `TenantId` 就能以那个身份调用本契约的每一个操作。
- **因此本契约的面不得被直接暴露成终端 API。**装配必须在它前面放一层做身份核实的入口。
- **这与 `capability.account-identity/v1#S-18`／`#S-30` 同形**——那份契约的读账号面也没有授权前置，
  理由与收场都一样。
- **「无授权前置」的读面不是「谁都能读」**：[S-59](#s-59-列出组织成员)、[S-58](#s-58-列出组织发出的邀请与隶属请求)、[S-60](#s-60-列出组织收到的隶属请求) 有自己的
  `notAuthorized`，[S-55](#s-55-读邀请)、[S-56](#s-56-读隶属请求) 有自己的两类人判定，
  [S-27](#s-27-我的租户)、[S-57](#s-57-列出账号收到的待接受邀请) 以「输入的 `AccountId` 就是调用者本人」为界；
  这一行说的是**那些判定所依据的身份值本身**由谁保证为真。

> **[S-36 当前租户身份查询](#s-36-当前租户身份查询) 有意不在那一行里。**
> 十二个读操作里只有它**不收身份值，收的是 `LoginStateId`**，
> 而它②**自己就带一道校验**——`capability.account-identity/v1#S-17` 现读那条登录状态是否仍有效
> （[S-4](#s-4-依赖方向与被消费的面) 的四出口映射）。
> **它因此不依赖「入口层已经核实过」这个前提**：它自己就是那道核实的一部分，
> [装配正是先用它把 `LoginStateId` 换成当前租户身份，再带着那个身份值去调别的面](#s-42-装配给的保证-vs-协议须给的保证)。
> **把它列进去会让这张表自指**——那条前提由它兑现，不能又以它为前提。
> [S-37 切换](#s-37-切换当前租户身份) 同理，它是写操作，同样自带那道校验。

---

## 九、交接、缺席与恢复

### S-43 依赖的提供者不可用

**账号读面或登录状态校验面不可用时，依赖它的操作明确失败，不静默降级。**
具体为 [S-20](#s-20-创建个人组织)、[S-21](#s-21-创建团队组织)、[S-23](#s-23-发出邀请)、
[S-25](#s-25-接受邀请)、[S-36](#s-36-当前租户身份查询)、[S-37](#s-37-切换当前租户身份) 各自 ⑧ 列的 `unavailable`。

**不得以任何形式绕过**：不得跳过已激活判定直接建、不得把「读不到」当成「已激活」、
不得把一条无法校验的 `LoginStateId` 当成有效。
依据是 [PF-001 §6.4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离) 与
[S-16](#s-16-缺席时的默认答案) 的通用收场。

**本能力自己被撤除或替换时**，它拥有的全部事实都在存储里（[S-5](#s-5-组织)～[S-14](#s-14-当前租户身份是登录状态上的一项选择)），
**没有一条只活在运行实例内**：没有定时器承担正确性（`data.offer-expiry/v1#S-18`），
没有需要按顺序释放的资源，没有在途的多步事务。因此**重启不改变任何判定结果**，
**也没有在途工作需要交接**。

**这不是运气，是[所有操作都在单次提交内结算](#s-19-这一节每个操作写全九件事)的直接结果**，
并且它是一条**可被推翻的承诺**：任何引入跨提交在途状态的修改都会使它失效，
那时必须回到本节重写交接责任。

### S-44 撤销不发出停止信号

角色调整、解除成员、解除隶属**都只影响下一道尚未通过的准入**。
本契约**不发出任何停止、中断或取消信号**，也不承诺任何正在运行的工作会因此停下。

[已经开始的调用是否停止，由独立的运行控制决定](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#66-撤销不等于强制停止)
（[decisions 第 8 条](../../../../product/PF-001-identity-scope-and-agent-constraints/decisions.md#2026-09-22--九条正文规则逐条确认为产品要求)）。
**那一半不在本契约，也尚无 owner 契约**，见[缺口 G-6](#十一已知缺口)。

---

## 十、规范表达与验证义务

### S-45 本版选用哪些形式工件

| 性质 | 表达 | 理由 |
|---|---|---|
| [S-17](#s-17-同一组织的成员写入序列化) ＋「至少一位有效超管」 | **TLA+ 行为模型**（[`formal/Membership.tla`](formal/Membership.tla)） | 这是一条**自定义并发协议**：两位超管交错移除／降级，各自的前置都成立、合起来违反不变量。只有行为模型能表达交错，并在去掉序列化时**给出反例** |
| [S-7](#s-7-上级组织属性) 的三条结构约束 ＋ [S-12](#s-12-上级链与有共同上级) 的谓词 | **Alloy 结构模型**（[`formal/Affiliation.als`](formal/Affiliation.als)） | 这是结构关系，不是交错；在给定规模内找反例正是 Alloy 的用法 |
| 邀约三收场、过期后接受被拒 | **规范场景**（[S-46](#s-46-邀约的三种收场)～[S-48](#s-48-并发移除对方只有先成的一方成立)） | 判定式本身归 `data.offer-expiry` v1，本契约要证的是**它在这两个操作上被按时求值** |
| [S-53](#s-53-清除未激活账号的个人组织) 的三条拒绝与幂等 | **规范场景**（[S-54](#s-54-清除只对未激活账号成立)） | 这条操作的全部内容是「**在什么情况下不删**」，而拒绝路径只有真跑才看得见。**跨契约的那一半**（个人组织存在 ⇒ 账号记录存在）**不在本包**：它跨两个提交边界，行为模型归 `omne-harness-lite-design-2026-09-15 · composition.account-registration · v1` |
| 其余条款 | **规范场景** | 见下 |

**本版不附 JSON Schema。**本契约的数据形状（`TenantId`、`MembershipStanding`、
`ScopeLayerIdentity`、`OfferTiming`）全部由 `data.identity-values` v1 与
`data.offer-expiry` v1 拥有，**在这里再建一份就是第二份权威**。
本契约自己新增的形状只有 `InvitationId` 与 `AffiliationRequestId` 两个不透明标识，
它们的词法约束由 `data.identity-values` v1 的不透明标识条款覆盖。

条款到模型的精确映射、检查范围与未覆盖部分在 [`formal/README.md`](formal/README.md)；
执行状态与结果在[验证入口](../verification.md)，**不写进本版本目录**。

### 规范场景

#### S-46 邀约的三种收场

对**邀请**与**隶属请求**各演练一遍：发出一份，分别让它 ① 被接受 ② 被撤回 ③ 放到过期。

**必须观察到**：① 产生该邀约约定的那一个效果（邀请 ⇒ 成员关系有效并返回 `TenantId`；
隶属请求 ⇒ 下级的上级组织属性有了值，**且没有任何租户产生**）；
②③ **不产生任何效果**，且此后接受被拒的结果值**逐字相同**（`offerNoLongerValid`）。

②③ **必须在同一次演练里对比**——分开跑证明不了「相同」。
**同一次再跑第四支**：对①已被接受的那一份**再接受一次**，
观察拿到的是与②③**逐字相同**的 `offerNoLongerValid`（`data.offer-expiry/v1#S-13` 的第三条来路），
且**没有第二份效果**。

> **本条与 `data.offer-expiry/v1#S-23`～`#S-25` 不是重复登记。**
> 那三条断言的是**判定式**：什么时候不再可被接受、三种来路的拒绝值逐字相同、上界是 `offer_ttl`。
> **本条断言的是本契约自己那个具名值 `offerNoLongerValid` 与本契约自己的效果面**
> （成员关系、租户、上级组织属性），判定式**引用不重证**。
> **一次执行可以同时兑现两边**，但[两边各自记结果](../verification.md)，谁也不填谁的空。

#### S-47 过期之后接受被拒，且没有中间状态

以 `offer_ttl = T` 发出一份邀请，**不运行任何后台清理**，在 `issuedAt + T` 之后接受。

**必须观察到**：接受被拒，理由 `offerNoLongerValid`；
**成员关系与 `TenantId` 从头到尾没产生过**
（[acceptance §一](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#一可观察场景)）。
这条同时是 `data.offer-expiry/v1#S-18` 的反面证据：清理停着，结论不变。

#### S-48 并发移除对方只有先成的一方成立

一个组织内恰有两位超级管理员，让他们**在不同地方同时**移除或降级对方。

**必须观察到**：先成的一方成功；后成的一方被拒，拿到的是
`wouldLeaveNoSuperAdministrator`——**与单次被拒时逐字相同的那个值**；
后成的一方**不产生任何部分效果**；组织**自始至终**有超管。

**这条必须真跑并发，不能用两次顺序调用代替**——顺序调用不会经过 [S-17](#s-17-同一组织的成员写入序列化) 要保护的那个窗口。

#### S-49 解除之后再加入，回来的是同一个租户

成员在组织的租户级建若干持有并配值 → 解除成员关系 → 观察 → 重新邀请并接受。

**必须观察到**：解除期间那些东西**没有任何身份能到达**，但**一条都没被删**；
重新加入后**原样可用**；返回的 `TenantId` 与解除前**是同一个值**
（[acceptance §一](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#一可观察场景)）。

**这条跨契约**：本契约只兑现「记录重新有效、身份不变」；「没被删」由资产 owner 兑现。
**演练必须两侧一起跑**，只跑本契约这一半证明不了它。

#### S-50 切换只影响此后新建的东西

在组织 O 下创建一个会话 → [S-37](#s-37-切换当前租户身份) 切到 P → 查那个会话的归属。

**必须观察到**：仍然是 `(O, 该账号)`；切换前后**各层的事实集合都不因切换本身增减**
（[acceptance §三](../../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#三判据)）。

**这条跨契约**：会话那一侧归 PF-015 的契约（[§6.12](../../../../product/PF-015-session-lifecycle-and-ownership/design.md#612-会话持有创建那一刻的租户身份)）。

#### S-51 个人组织里没有这个动作

对一个个人组织依次调用 [S-23 发出邀请](#s-23-发出邀请)、[S-29 解除成员](#s-29-解除成员)、
[S-30 发出隶属请求](#s-30-发出隶属请求)，**发起者是该组织的超级管理员**。

**必须观察到**：三次都被拒，理由分别是三个结构性失败值
（`issuerIsPersonalOrganization`、`personalOrganizationMemberCannotLeave`、
`personalOrganizationTakesNoPartInAffiliation`）；
且 [S-22 读组织](#s-22-读组织) 返回的 `OrganizationKind = personal` **足以在不发起操作的前提下得出同一结论**
（[S-15](#s-15-结构性禁止不是权限判定)）。

**发起者必须是超管**——这正是区分结构性禁止与权限判定的那个输入。

#### S-54 清除只对未激活账号成立

对**四个**目标各调一次 [S-53 清除未激活账号的个人组织](#s-53-清除未激活账号的个人组织)：
① 一个**未激活且已过留存期限**账号的个人组织；② 一个**已激活**账号的个人组织；
③ 一个**未激活但仍在留存期限内**账号的个人组织；④ **构造态**：一个**未激活且已过留存期限**的账号（与①同前提），构造「由该 `AccountId` 定位到的组织**不是个人组织**」——前提不满足时本操作在读组织之前就以 `accountIsActivated`／`accountNotExpired` 返回，④到不了。

**必须观察到**：① `ok`，组织记录与那条成员关系记录**一起**没了，**并拿到一份与该 `AccountId` 绑定的清除依据**；
② `accountIsActivated`，**组织原样还在**，该账号仍然可用；
③ **`accountNotExpired`**，**组织原样还在**，该账号**随后仍能完成注册**（[主链第 3 步激活得了](../../../compositions/account-registration/v1/contract.md#s-8-三步次序与责任交接)）；
④ `organizationIsNotPersonal`，**不产生任何效果**。

**④为什么是构造态，与下面的「缺陷观测」那一支同形。**本操作①只收 `AccountId`，
而本版由 `AccountId` 定位到的只可能是它的个人组织（[③那条空真的守卫](#s-53-清除未激活账号的个人组织)）——
**没有任何正常输入能表达「对一个团队组织调本操作」**。
演练因此要像⑦支那样**直接构造那个状态**（让「账号 → 组织」的定位指到一个 `kind = team` 的组织），
再调本操作；观察的是那条守卫**在状态已坏时仍然拒绝、不删、不产依据**。

**同一次演练须再跑四支**：

- **幂等（账号仍在）**：对①的目标再调一次 ⇒ `ok`、**仍返回依据**，无二次效果；
- **幂等（账号也已不在）**：在①之后**再把那条账号记录清掉**（`capability.account-identity/v1#S-38`），
  然后**用同一个 `AccountId` 再调一次** ⇒ **`ok` 并仍然返回依据**（②乙 ＋ ⑦乙）。
  **绝不能观察到** `accountDoesNotExist`——那会让[清除链在重扫时停住](../../../compositions/account-registration/v1/contract.md#s-34-第二条动作链未激活到期清除)；
- **缺陷观测**：构造「**账号记录已不在、个人组织还在**」，调本操作 ⇒ **`accountDoesNotExist`**，
  **组织原样还在、不产出依据**，且这次失败**可被观测**（不折进 `unavailable`）。
  **这一支与上一支必须挨着跑**——两者的输入都是「账号读不到」，
  **区别只在组织在不在**；分开跑证明不了实现真的分了这个岔，
  而一个不分岔的实现要么把重扫报成缺陷，要么让一条真被破的不变量悄无声息；
- **故障注入**：让账号读面**以 `storage-unavailable` 失败**，再调一次 ⇒ `unavailable`，
  **组织原样还在、不产出依据**。
  **绝不能观察到**「判不出账号就当它未激活」「就当它已过期」而把组织删掉——
  前者会删掉一个已激活账号的个人组织（[本版没有任何路径能做这件事](#s-6-两个变体与四条结构性禁止)），
  后者会删掉一个正在注册的人的空间；
  **也绝不能观察到**它被当成「账号不存在」而走进上面那两支。

**八支必须在同一次演练里对比**：这条操作是本契约唯一的销毁路径，
它的全部内容就是「**在什么情况下不删**」，而一个把三种拒绝中任意一种漏掉的实现，
在只跑成功那一支时看起来完全正常。**这一步删错，删掉的是一个人已经在用、或正要开始用的空间。**

**第 ③ 支是[跨契约那条不变量](../../../compositions/account-registration/v1/contract.md#s-35-个人组织不会变成孤儿)之外、本操作自己那一半防御的唯一证据**：
它证明本操作**不替调用方相信「该清了」**。少了它，一个只判「未激活」的实现会全绿通过其余七支。

#### S-52 成员资格不可用时明确失败

让成员资格读面不可用（故障注入），然后分别调用
[S-26](#s-26-成员资格判定)、[S-28](#s-28-调整角色)、[S-37 切换](#s-37-切换当前租户身份)。

**必须观察到**：[S-26](#s-26-成员资格判定) 以 `unavailable` **失败**，而不是返回 `ineffective`；
[S-28](#s-28-调整角色) 与 [S-37](#s-37-切换当前租户身份) 以 `unavailable` 失败，
**不是** `membershipNotEffective`，**也不回退到个人范围**。

**这条最容易在实现里被一个「读不到就当没有」抹掉，必须真跑。**

---

## 十一、已知缺口

**缺口不填默认值。**下列各项等待具名 owner 裁决，实现不得据一个看起来合理的猜测推进。

| # | 缺口 | owner | 闭合条件 |
|---|---|---|---|
| G-1 | **会话级层身份**（[S-13](#s-13-层身份读面)）：四层里的第四格「谁是这一层」无人定义。本契约**不返回它，也不返回空值** | PF-015 的 owner（该 topic 仍是草稿） | PF-015 正文写明会话级的层身份是什么；本契约的 [S-13](#s-13-层身份读面) 随之补一格，**判定式与其余三层不变** |
| G-2 | **「指向的组织已不存在」这一分支本版没有触发源**（[S-5](#s-5-组织)、[S-11](#s-11-隶属请求)）：**团队组织**没有终结路径，而[S-53](#s-53-清除未激活账号的个人组织) 只清个人组织——**没有任何邀约指向个人组织**（[S-6](#s-6-两个变体与四条结构性禁止) 的禁止 1 与 3）。因此 [S-46](#s-46-邀约的三种收场)～[S-47](#s-47-过期之后接受被拒且没有中间状态) 仍然覆盖不到它 | PF-001 的 owner（[产品正文已自认](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#非目标)） | **团队组织**的终结路径成立，或产品正文明确「此分支为将来而立、本版不验收」。**在此之前不得实现事件源** |
| G-3 | **使用成本的计量口径未定**：[PF-001 §6.4 要求成本按租户归属并能出明细](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)，但一条明细是什么、怎么归集，[没有任何 topic 拥有](../../../../domain_objects/pending.md)。本契约只承诺 `TenantId` 可被每次调用携带 | 产品负责人（观测与计量尚无 topic） | 有 topic 认领计量并说明一条明细是什么 |
| G-4 | **隶属请求的宿主未裁**（[S-11](#s-11-隶属请求)）：两端都是组织，正文只点了「它指向的那个组织」 | PF-001 的 owner，[已记入该 topic 的「已知的来源问题」](../../../../product/PF-001-identity-scope-and-agent-constraints/decisions.md#四已知的来源问题) | 正文写明宿主。**本契约不受阻**——它按 `AffiliationRequestId` 持久、按**接收方组织这一个**指向对象判过期（[S-11](#s-11-隶属请求)），两件事都不需要先知道宿主。**注意别把这两件事并成一句**：判定对象是单数这件事[产品正文已经定了](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)，**未裁的只有宿主** |
| G-10 | **已闭合（2026-09-22，评审轮一）**：本契约与三份依赖均已登记进 catalog（状态 `candidate`）；[S-4](#s-4-依赖方向与被消费的面) 的**身份值侧被消费面已按条款逐条补齐，共 27 条**（`S-1`、`S-3`～`S-12`、`S-14`～`S-19`、`S-26`～`S-35`，**含交接凭证 `#S-35`**；`#S-13` 有意排除），过期语义侧补上 `data.offer-expiry/v1#S-19`。编号保留不重排。**catalog 的 `clauses` 随之更新，那是 registry 一侧的动作，不在本契约内**。**编号说明**：这一条此前占用 `G-5`，与下表里已关闭的旧 G-5（shareAncestor 读法差异）一号两指，评审轮三改用下一个未用的号；`G-8`、`G-9` 已删除不复用 | — | — |
| G-6 | **运行控制的承接方缺席**（[S-44](#s-44-撤销不发出停止信号)）：「已经开始的调用是否停止」归独立的运行控制，而那一侧尚无契约 | PF-012／PF-015 的 owner | 有契约拥有运行控制，并说明它怎样与成员资格变化衔接 |
| G-7 | **跨进程的协调、传播上界与判环一致性级别未定义**（[S-42](#s-42-装配给的保证-vs-协议须给的保证) 右列） | 架构设计（本版单机不阻断） | 分布式演化启动时给出协调协议、传播上界与判环一致性级别，**并作为本契约的新版本发布** |
| G-11 | **已闭合（2026-09-22，PF-001 rev 14）**：问的是普通成员能否查看本组织的成员名单，以及两类邀约（本组织发出的邀请与隶属请求、本组织收到的隶属请求）。**产品负责人的答复**：**成员名单对同组织所有有效成员可见；发出的邀约与收到的隶属请求只有超级管理员可见**，已落进 [flows §4 的角色与操作表](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)（三行）。**落点**：[S-59](#s-59-列出组织成员) ②由超管**放宽为该组织的有效成员、任一角色**；[S-58](#s-58-列出组织发出的邀请与隶属请求)／[S-60](#s-60-列出组织收到的隶属请求) ②**维持超管**，两处「待产品确认」的标注删除——**它们不再是本契约自己取的一档**。三条的失败集合都不变；编号保留不重排 | — | — |
| G-12 | **已闭合（2026-09-22，产品负责人选 (b)）**：[S-21](#s-21-创建团队组织) ① 加**可选创建键**，⑦ 幂等边界改为 (创建者 `AccountId`, 创建键)，带键重放返回首次的 `OrganizationId`，键登记与组织行同一提交（④），保留期 `team_creation_key_retention` 为部署配置；失败集合不变。原缺口：⑦ 曾写「调用方须自带幂等键——本契约不提供」而 ① 无输入可带，[PF-001 §6.8](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#68-管理结果) 的认回规则对本操作无拥有者。编号保留不重排 | — | — |
| G-13 | **当前租户身份残留记录的清扫未定触发与节奏。**[S-14](#s-14-当前租户身份是登录状态上的一项选择) ⑤ 把登录状态失效后残留的选择记录交给本契约提供者清扫，但登录状态记录本版永不删除、每次登录新建一条，残留随之单调增长；谁触发、多久一次、消费 `capability.account-identity/v1#S-17` 还是别的失效读面，未写。无正确性影响 | 架构与提供者设计（与组合契约 G-6 同形） | 装配给出清扫的发起方式与节奏；本契约条款不因此改变 |

**本版关掉了一条缺口，它不再出现在上表**（PF-001 **rev 12**，
见[该 topic 的 changelog](../../../../product/PF-001-identity-scope-and-agent-constraints/changelog.md)）：

| 原编号 | 原来是什么 | 现在怎么了 |
|---|---|---|
| 旧 G-5 | 「有共同上级」与「同一棵隶属树」不等价——一个组织与它自己的上级落在两种读法的缝里 | **闭合。**rev 12 把判据改成[「把各自算进自己的上级链之后，两条链有交集，也就是同一棵隶属树（根相同）」](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)，并明写这与 [PF-003 §5.2 是同一句话](../../../../product/PF-003-asset-transfer-and-sharing/design.md#52-边界是那棵隶属树不是单个组织)。[S-12](#s-12-上级链与有共同上级) 的定义式随之改写，[S-34](#s-34-上级链与有共同上级) 的读面同步；**两个判据合一，消费者此后可以把它们当同一个用**。[缺口关闭也使 Alloy 的 `ShareAncestorIsSameAffiliationTree` 从「预期反例」变成「预期无反例」](formal/README.md) |

---

## 十二、消费者核对

本节不新增承诺，只走一遍具名消费者的路径，核对本契约给的面是否够用。
**发现不够用时回到本契约补条款，不在消费者那边自己算一份。**

| 消费者 | 它要什么 | 本契约给什么 | 够不够 |
|---|---|---|---|
| **PF-002 配值资格**（[§5.2](../../../../product/PF-002-assets-settings-and-permissions/design.md#52-设置与权限是资产的两种属性)）：超管配组织层、成员配租户层 | 「这个 `TenantId` 此刻是不是有效成员、持什么角色」＋「它带来哪两层」 | [S-26](#s-26-成员资格判定) ＋ [S-35](#s-35-层身份) | **够。**注意 PF-002 的另一半前提是**持有**——「配值的资格来自持有」，那一半归资产契约，本契约不给 |
| **PF-003 复制前提**（[§6.2](../../../../product/PF-003-asset-transfer-and-sharing/design.md#62-谁能流向谁)）：同一账号在两边**都是成员** | 两个 `TenantId` 各自的成员资格判定 | [S-26](#s-26-成员资格判定) 调两次；「同一账号」由 `TenantId` 的账号那一半结构相等判定（`data.identity-values` v1） | **够** |
| **PF-003 分享边界**（[§5.2](../../../../product/PF-003-asset-transfer-and-sharing/design.md#52-边界是那棵隶属树不是单个组织)）：同一棵隶属树 | `shareAncestor` | [S-34](#s-34-上级链与有共同上级) | **够。**PF-001 rev 12 已裁定两者是同一个判据，[S-12](#s-12-上级链与有共同上级) 的定义式改为**把各自算进自己的上级链**；此前登记的差异（旧缺口 G-5）随之关闭。**消费者直接用 `shareAncestor` 这一支，不要自己从上级链求交** |
| **PF-003 关系解除之后**（[§6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)）：分享失效 | 每次使用时的求值条件，**不是一个事件** | [S-34](#s-34-上级链与有共同上级) 现读 ＋ [S-40](#s-40-事件都是通知) 的负向承诺 | **够**，且本契约明写不得靠 `affiliation.dissolved` |
| **PF-015 会话创建**（[§6.12](../../../../product/PF-015-session-lifecycle-and-ownership/design.md#612-会话持有创建那一刻的租户身份)）：捕获创建那一刻的租户身份 | 「这次登录此刻站在哪」 | [S-36](#s-36-当前租户身份查询) | **够。**捕获之后的持有归 PF-015；本契约只保证 [S-37](#s-37-切换当前租户身份) 的切换**不回头改**已创建的东西 |
| **PF-007 全局授权表达**（[§4](../../../../product/PF-007-meta-capabilities/design.md#一笔授权表达有三个维度)）：「全局」那一档落成**租户层**的权限设置值，且「写这个值要有写它的权限」 | 「这一层是哪个租户」＋「他此刻是不是有效成员、持什么角色」 | [S-35](#s-35-层身份) ＋ [S-26](#s-26-成员资格判定) | **够**。写值本身的资格判定归 PF-002 的契约 |
| **注册组合** | 建个人组织并使之可被激活前置查到 | [S-20](#s-20-创建个人组织)，**幂等边界是 `AccountId`**，且**不要求账号已激活** | **够**，见 [S-20](#s-20-创建个人组织) ② |
| **注册组合的清除链**（[第二条动作链](../../../compositions/account-registration/v1/contract.md#s-34-第二条动作链未激活到期清除)） | 清掉个人组织并拿到一份可交给 `capability.account-identity/v1#S-38` 的依据 | [S-53](#s-53-清除未激活账号的个人组织)，**输入只收 `AccountId`**，成功与幂等成功**都返回**[交接凭证](../../../data/identity-values/v1/contract.md#s-35-交接凭证-handoff-warrant) | **够。**「依据不可伪造」是那条身份值条款的承诺，**不是本契约的**；实现路径归 realization |
| **被邀请的那个人**（[flows §1.5](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#15-邀请与加入)）：看见自己收到了什么，并判断它还能不能接受 | 一份邀请的全部字段 ＋ **此刻**的派生状态；以及「我现在有哪些待处理的」 | [S-55](#s-55-读邀请) ＋ [S-57](#s-57-列出账号收到的待接受邀请) | **够。**这两条是本轮补的；在此之前[S-3](#s-3-本契约明确不承诺什么) 说的「对方查询得到它」**没有面** |
| **发出邀约的那个组织**：看自己发了什么、还悬着几份 | 两类邀约各自的列表与派生状态 | [S-58](#s-58-列出组织发出的邀请与隶属请求) ＋ [S-55](#s-55-读邀请)／[S-56](#s-56-读隶属请求) | **够** |
| **收到隶属请求的那个组织**（[flows §1.7](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#17-建立与解除组织隶属)）：知道有谁在等我点头，然后去接受 | 以本组织为接收方的隶属请求列表 ＋ 每项**此刻**的派生状态 | [S-60](#s-60-列出组织收到的隶属请求) ＋ [S-56](#s-56-读隶属请求) ＋ [S-32](#s-32-接受隶属请求) | **够。**[S-60](#s-60-列出组织收到的隶属请求) 是本轮补的；在它之前**这一格是空的**——`AffiliationRequestId` 不透明猜不出、[S-58](#s-58-列出组织发出的邀请与隶属请求) 只列发出的、[S-30](#s-30-发出隶属请求) ⑨不发事件，**接收方无从得知一份请求存在**，那条产品流程在契约里走不通 |
| **组织里的任何一位有效成员**（[flows §4](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)）：超管管理成员前先看到成员，普通成员共事前先知道这里有谁 | 本组织的成员名单，带角色与效力 | [S-59](#s-59-列出组织成员) | **够。**[S-22](#s-22-读组织) 此前把读者指向 [S-26](#s-26-成员资格判定)，而那条**列不出名单**。**授权是 PF-001 rev 15 定的那两档**：有效成员那一份任一角色都能读，**已解除的那些只归超管**；[两类邀约同样只归超管](#s-58-列出组织发出的邀请与隶属请求) |
| **`data.offer-expiry/v1#S-9`**（读时派生）：它要求有一个按读取时点求值的读面 | 邀请与隶属请求的派生状态读面 | [S-55](#s-55-读邀请)～[S-58](#s-58-列出组织发出的邀请与隶属请求)、[S-60](#s-60-列出组织收到的隶属请求) | **够**（本契约这两类，**两个方向都有**）。**另两类消费者（复制通知、分享邀请）的读面不在本契约**，归资产领域的规格 |

---

## 十三、版本差异与规范工件

**本版是首版**，没有被采用的旧版本，因此没有语义或表示差异可记。

2026-09-17 曾在 PF-001 rev 1 上建过一批候选契约，**已于 2026-09-22 由产品负责人整体废弃**；
它们从未被接受或冻结，**不构成本契约的前身，本契约不继承其任何条款**，
也不与之建立 lineage 关系。见[规格容器的当前状态](../../../README.md#当前状态)。

**2026-09-22 architecture-reviewer 评审后的修订同样直接落在 v1 上**：[S-21](#s-21-创建团队组织) 加可选创建键与幂等边界（语义改动，候选版本原地改，失败集合不变）；
[S-14](#s-14-当前租户身份是登录状态上的一项选择) ⑤ 明写那项选择是本契约整体拥有的独立记录；
[S-4](#s-4-依赖方向与被消费的面) 末段改写拆分理由。**模型与检查配置未动**（它们不涉及这三处）。

**本版的规范工件**：本文件、[`formal/Membership.tla`](formal/Membership.tla) 与其检查配置、
[`formal/Affiliation.als`](formal/Affiliation.als)，映射在 [`formal/README.md`](formal/README.md)。
接受状态、冻结记录与执行结果都在本版本目录之外维护，本文件不填进度、通过状态或哈希。
