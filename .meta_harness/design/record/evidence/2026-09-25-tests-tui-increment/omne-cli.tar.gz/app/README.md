# omne governance CLI

Requires preinstalled Node.js 24.21.0. Tested: macOS arm64, Linux arm64 and amd64. macOS Intel has not been verified.

Obtain this archive AND its SHA256 through a trusted channel. A checksum verifies bytes, not authorship. Compare with shasum -a 256 ARCHIVE (macOS) or sha256sum ARCHIVE (Linux), then extract into a NEW empty directory:

    mkdir chosen-new-directory
    tar -xzf ARCHIVE -C chosen-new-directory
    node chosen-new-directory/app/dist/main.js --version
    node chosen-new-directory/app/dist/main.js --help

Run machine commands for redirected output. Human governance commands require a terminal. This increment requires protected credential files; no interactive password input or TUI. Use an explicit --state-dir absolute directory to preserve the intended local identity across code upgrades. Its parent must already exist; do not copy state into this code directory.

For a code upgrade, unpack into another new directory and retain the old code. Retention does not guarantee older code can read newer state. This tool performs no migration, automatic rollback, global install, download or upload. Do not overwrite an active installation. Center compatibility must be checked before use.

build-info.json lists packaged files and relative symlinks. BUILD_ID identifies that list (excluding itself and build-info.json). This is not a byte-reproducible-build claim. Never store credentials or local client state inside this artifact directory.
