import assert from 'node:assert/strict'
import { mkdtemp, mkdir, copyFile, writeFile, rm } from 'node:fs/promises'
import { join } from 'node:path'
import { spawn } from 'node:child_process'
const root=await mkdtemp('/private/tmp/omne-version-process-'), results=[]
async function run(broken=false){return new Promise((resolve,reject)=>{const p=spawn(process.execPath,[join(root,'dist/cli.js'),'--version'],{env:{},stdio:['ignore','pipe','pipe']});let stdout='',stderr='';if(broken)p.stdout.destroy();else p.stdout.on('data',x=>stdout+=x);p.stderr.on('data',x=>stderr+=x);p.on('error',reject);p.on('close',(code,signal)=>resolve({code,signal,stdout,stderr}))})}
try{
 await mkdir(join(root,'dist'));await writeFile(join(root,'package.json'),'{"type":"module"}')
 for(const name of ['cli.js','build-version.js','version.js'])await copyFile(join('/private/tmp/omne-host-d052-yze0taxs/app/dist',name),join(root,'dist',name))
 // There is no boot.js or node_modules in this directory; accidental eager loading fails.
 const missing=await run();assert.equal(missing.code,0);assert.equal(missing.stdout,'tenancy-host 0.0.0 development\n');results.push({case:'no marker/config/boot/dependencies',...missing})
 await writeFile(join(root,'BUILD_ID'),'a'.repeat(64)+'\n');const marked=await run();assert.equal(marked.code,0);assert.ok(marked.stdout.includes('a'.repeat(64)));results.push({case:'valid marker',...marked})
 const pipe=await run(true);assert.equal(pipe.code,1);assert.equal(pipe.stderr,'tenancy-host: version unavailable\n');results.push({case:'real EPIPE stdout',...pipe})
 await writeFile(join(root,'BUILD_ID'),'do-not-disclose-this-marker');const bad=await run();assert.equal(bad.code,1);assert.ok(!JSON.stringify(bad).includes('do-not-disclose'));results.push({case:'malformed marker',...bad})
 await writeFile(process.argv[2],JSON.stringify({status:'PASS',node:process.version,results},null,2)+'\n');console.log('PASS 4 actual version-only processes')
}finally{await rm(root,{recursive:true,force:true})}
