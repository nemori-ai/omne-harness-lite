from pathlib import Path
import shutil,tempfile,json,subprocess,os
r=Path.cwd(); t=r/'tmp/production-cli-onboarding'; dest=Path(tempfile.mkdtemp(prefix='omne-d052-clean-',dir='/private/tmp'))
for name in ['packages','apps','tools/ts-checks','tools/artifact-builder','scripts','docs']:
 shutil.copytree(r/name,dest/name,ignore=shutil.ignore_patterns('node_modules','dist','__pycache__','.turbo'))
for name in ['package.json','pnpm-workspace.yaml','pnpm-lock.yaml','tsconfig.base.json','README.md']:
 shutil.copyfile(r/name,dest/name)
assert not list(dest.rglob('dist'))
assert not list(dest.rglob('node_modules'))
(t/'host-package-clean-location.json').write_text(json.dumps({'source':str(dest),'beforeBuild':'no dist, no node_modules; independent snapshot of current working source, not git HEAD'},indent=2)+'\n')
commands=[['pnpm','install','--offline','--frozen-lockfile','--ignore-scripts'],['bash','scripts/package-tenancy-host.sh',str(t/'omne-host-d052-r1.tar.gz')],['bash','scripts/package-cli.sh',str(t/'omne-cli-d052-r1.tar.gz')]]
with (t/'host-package-clean-build-r1.log').open('w') as log:
 for command in commands:
  log.write(json.dumps(command)+'\n');log.flush()
  p=subprocess.run(['fnm','exec','--using','24',*command],cwd=dest,stdout=log,stderr=subprocess.STDOUT)
  if p.returncode:raise SystemExit(p.returncode)
print(json.dumps({'status':'PASS','source':str(dest),'commands':len(commands)}))
