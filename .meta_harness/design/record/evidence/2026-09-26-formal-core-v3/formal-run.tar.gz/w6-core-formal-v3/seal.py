from __future__ import annotations
import hashlib, json, pathlib, subprocess
from run import EVIDENCE, ROOT, dump, now, sha
EXCLUDED={'SHA256SUMS','FNV1A32SUMS','FNV1A64SUMS','FILE_MANIFEST.json','seal.json'}
def fnv(data,bits):
    value=0x811c9dc5 if bits==32 else 0xcbf29ce484222325
    prime=0x01000193 if bits==32 else 0x100000001b3
    for byte in data:value=((value^byte)*prime)&((1<<bits)-1)
    return f'{value:0{bits//4}x}'
assert fnv(b'',32)=='811c9dc5' and fnv(b'hello',32)=='4f9f2cab'
assert fnv(b'',64)=='cbf29ce484222325' and fnv(b'hello',64)=='a430d84680aabd0b'
# Recheck immutable authority and executed snapshots before sealing.
inputs=json.loads((EVIDENCE/'input-index.json').read_text())
for item in inputs:
    require=sha(EVIDENCE/'input'/item['path'])==item['sha256']
    assert require,item['path']
    assert sha(ROOT/'.meta_harness/design'/item['path'])==item['sha256'],item['path']
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()==''
rows=[]
for p in sorted(EVIDENCE.rglob('*')):
    if p.is_file() and p.name not in EXCLUDED:
        data=p.read_bytes();rows.append({'path':str(p.relative_to(EVIDENCE)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'fnv1a32':fnv(data,32),'fnv1a64':fnv(data,64)})
dump(EVIDENCE/'FILE_MANIFEST.json',{'format':1,'scope':'All owned evidence payload files; listed manifest self exclusions only','self_excluded':sorted(EXCLUDED),'files':rows})
for bits in [32,64]:(EVIDENCE/f'FNV1A{bits}SUMS').write_text(''.join(f"{r[f'fnv1a{bits}']}  {r['path']}\n" for r in rows))
dump(EVIDENCE/'seal.json',{'format':1,'sealed_at_utc':now(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'sha256_scope':'All files, including FNV/JSON/seal manifests, except SHA256SUMS itself','fnv_scope':'Owned payload files listed in FILE_MANIFEST.json; FNV-1a on raw bytes, little-independent unsigned 32/64 modular multiplication; excludes SHA/FNV/JSON/seal manifest files to avoid circular hashes','payload_file_count':len(rows),'payload_bytes':sum(r['bytes'] for r in rows),'file_manifest_sha256':sha(EVIDENCE/'FILE_MANIFEST.json'),'fnv32_manifest_sha256':sha(EVIDENCE/'FNV1A32SUMS'),'fnv64_manifest_sha256':sha(EVIDENCE/'FNV1A64SUMS'),'source_snapshot_rechecked':True,'tracked_tree_clean':True,'fnv_known_vectors_passed':['32(empty)=811c9dc5','32(hello)=4f9f2cab','64(empty)=cbf29ce484222325','64(hello)=a430d84680aabd0b'],'technical_acceptance':'not claimed by worker'})
paths=[p for p in sorted(EVIDENCE.rglob('*')) if p.is_file() and p.name!='SHA256SUMS']
(EVIDENCE/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(EVIDENCE)}\n' for p in paths))
print(json.dumps({'files_total':len(paths)+1,'sha256_entries':len(paths),'payload_files':len(rows),'sha256_manifest_sha256':sha(EVIDENCE/'SHA256SUMS'),'fnv64_manifest_sha256':sha(EVIDENCE/'FNV1A64SUMS'),'fnv32_manifest_sha256':sha(EVIDENCE/'FNV1A32SUMS')},indent=2))
