from run import EVIDENCE, run
AE_TARGETS={1:['LockTruncates','ReplacementCannotEscapePermission'],2:['DisableIsDisjunction'],3:['WorkspaceNeverSourcesPermission'],4:['OfficialLowerBound'],5:['TeamAssetsStayInTree'],6:['WorkspaceNeverSourcesPlacement'],7:['ReplacementCannotEscapePermission','UnusableKeepsBounds'],8:['NonFittingPickNeverSources'],9:['UnusableNeverEffective'],10:['OfficialLowerBound'],11:['UnusableKeepsBounds'],12:['ForbidIsBound'],13:['WorkspaceNeverSourcesGovernance']}
MSG_TARGETS={1:'NewBlocksBornReadable',2:'NewBlocksBornReadable',3:'OutstandingPlaceholderStaysReadable',4:'OutstandingPlaceholderStaysReadable',5:'NestedReadableImpliesContainersReadable'}
def get(label,model,command):
    run(label,['/usr/local/bin/alloy','exec','-f','-c',command,'-t','xml','-o',str(EVIDENCE/'runs'/label/'solutions'),str(model)],EVIDENCE,600,0)
for command in ['fourLayerInstance','replacementConstrained','pickSkipped','usableByFallback','unusableConstrains','unlockedForbid']:
    get('ae3-original-xml-'+command,EVIDENCE/'input/spec/capabilities/asset-evaluation/v3/formal/Evaluation.als',command)
for n,commands in AE_TARGETS.items():
    for command in commands:
        if n==1 and command=='LockTruncates': continue # Existing actual probe retained and read.
        get(f'ae3-M{n}-xml-'+command,EVIDENCE/f'mutants/asset-evaluation/M{n}/Evaluation.als',command)
for command in ['placeholderNamedOnlyAfterItEnded','aNestedBlockSilencedAlone']:
    get('msg3-original-xml-'+command,EVIDENCE/'input/spec/data/messages/v3/formal/Readable.als',command)
for n,command in MSG_TARGETS.items():
    get(f'msg3-M{n}-xml-'+command,EVIDENCE/f'mutants/messages/M{n}/Readable.als',command)
