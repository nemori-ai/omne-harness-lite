# W6：已接受 core v3 的独立形式执行证据

执行完成，全部指定预期与实际一致；待主调度技术复核，本角色没有接受权限。本轮只交付模型执行与结果读取证据，不代表 core 产品实现、真实组合或用户最终交付验收。

源检出：`panqiwei/core-delivery-stream-guards`，HEAD `8c03105243e1ae25697dd78b0d9c317c43d076bf`。按派发授权从旧 SC1 提交 `a3cd11eb50feabf7e44afc5d84ec820d12b77a2a` 无冲突合入 `f8c76d60dd3f01c9a8cd1e29a94c4accbb9ec361`；[position.json](position.json) 保存 merge 与位置。本任务没有修改 tracked 工具、产品、规格、registry、frozen 或旧证据；所有新增材料在此独立目录。

## 输入与版本

采用当前 D-068 的精确接受：[决定快照](input/record/decisions/core-implementation-spec-reconciliation/decision.md)、[acceptance.json](input/record/decisions/core-implementation-spec-reconciliation/acceptance.json)。八条 accepted catalog 项、32 个接受资源分别对 frozen 验证 SHA-256；当前 frozen 共 351 个资源。32 个快照只是接受依据，执行范围只有下表三个既定模型义务。

本次执行的七个 `.tla` / `.cfg` / `.als` 文件全部与正式源 v2 同字节，分别封存本次 v3、源 v2 和实际历史 v1 原输入的 SHA：[lineage.json](lineage.json)。历史 SA/AE 原输入仍有旧版号或 D-040 的注释坐标，差异保存在 `lineage-history-*.diff`；旧运行没有重标、覆盖或拿来充当本次 v3 执行。

| 指定义务 | 实际输入与条款 | 本次结果 |
|---|---|---|
| SA V-1 | `capability.stream-assembly/v3` S-6、S-9、S-27、S-30；[formal 入口](input/spec/capabilities/stream-assembly/v3/formal/README.md)与四份配置 | 正配置 exit 0；三份变异各 exit 12，并命中相应不变量和规定轨迹 |
| AE V-1 | `capability.asset-evaluation/v3` S-17～S-19、S-23～S-25、S-39、S-32；[formal 入口](input/spec/capabilities/asset-evaluation/v3/formal/README.md) | 原 18 命令：6 run SAT、12 check UNSAT；13 既定变异分别重跑同 18 命令，全部符合规定与历史有效性读法 |
| Messages V-11 | `data.messages/v3` S-28～S-30，嵌套合取采用 CB3 S-5；[formal 入口](input/spec/data/messages/v3/formal/README.md) | 原 6 命令：2 run SAT、4 check UNSAT；M1～M5 各只执行对应 check，全部 SAT |

Alloy 主结果合计 263 个命令读数（AE 252、Messages 11），不能按进程退出码判读。另对 28 个有解的实例／反例命令补 XML 格式输出，同输入和作用域、仅选择单命令与 `-t xml`；这是可读关系补取，不计为新增性质覆盖。[formal-results.json](formal-results.json) 完整逐条登记，[xml-readouts.json](xml-readouts.json) 记录 XML 的 sig、关系元组、skolem 与作用域。

## TLC 实际范围与反例

正配置是 [formal-tasks 快照](input/registry/formal-tasks.json) 的 `stream-assembly-v3-assembly`；[registered-tlc-task.json](registered-tlc-task.json) 保存原数组、展开后的 argv 与执行 cwd。严格使用 1 worker、600 秒 timeout。为把生成物限制在本任务目录，把 frozen 输入按原 `spec/...` 路径放在此处 `input/`，从它执行原登记 argv；输入字节经过 frozen 核验。三个变异只改变 `-config` 与独立 `-metadir`，timeout/worker 保持。

| 配置 | exit | generated / distinct | depth | 实际读到的有效性轨迹 |
|---|---:|---:|---:|---|
| Assembly | 0 | 871519 / 826411 | 9 | 探索完成，队列 0，无反例；约 65.5 秒 |
| OrderByClose | 12 | 18457 / 18219 | 7 | 开 0、开 1、封 1、封 0、abandon；结果顺序 1、0；`BlockOrderIsOpenOrder` |
| ReplaceAsAppend | 12 | 4454 / 4405 | 6 | 以 replace 开 0、填 a、再填 a、abandon；实际归约 a a，正确替换归约 a；`SplitInvariance` |
| OneShotCloseFirst | 12 | 3362 / 3323 | 6 | 开 0、填 a、封 0、abandon；变异 OneShot 把封口排在填之前；`OneShotAccepted` |

输入只含 2 个索引、2 个片段符号、最多 6 个接受事件；abandon 补的 finish 不占上限。无公平性假设，死锁检查关闭。只支持 P-1 与 P-7（后者两半）的有限范围检查；P-2～P-6 的六个守卫复述按构造，不作证据。参数解析、真实载荷、砍过的调用、快照、首个内容、砍的汇总、完整表示与失败优先级、宿主前提、跨进程均未由此模型验证。

## Alloy 有效性读法

每次实际输出保存 `receipt.json`、实例文件、原 stdout/stderr 与 argv/起止/exit。读取器对 stderr SAT/UNSAT 与 receipt 是否存在可读 solution 交叉核对，并核对命令全集、原 command source 和 scope；`check` SAT 是反例，`run` SAT 是一致性实例。正常 exit 0 本身没有通过含义。

AE M1～M13 使用已维护历史证据的原十三个 patch，仅在新副本应用；`patch --fuzz=0` 全部成功，部分只有行号 offset。原 patch 与实际 diff 都保留在 `mutants/asset-evaluation/`。M1 推翻 LockTruncates 与 ReplacementCannotEscapePermission，M7 推翻 ReplacementCannotEscapePermission 与 UnusableKeepsBounds，M8 推翻 NonFittingPickNeverSources 且 run pickSkipped 为 UNSAT；其余各推翻 formal 入口指定一项，其余原命令保持预期。Messages 五个改法逐一与当前 formal 入口一致，在 `mutants/messages/` 保存唯一替换、diff、输入 hash 与对应断言。

AE 沿文件命令自身的作用域（overall 6、Cap ≤4、Assign ≤4 或5、Owner ≤3，个别 Holding ≤7、Item ≤4）。Messages run 的 Msg 恰 6/5 条、check 恰 6 条，其余签名按各自 scope 有限；更短日志由前缀覆盖。这些不是任意规模结论。

AE TeamAssetsStayInTree 的两半、根身份／composition 起点均按构造，不作求值保护证据；M5 只显示对 PRE-2 fact 的依赖。具体权限值合成、tenantAutoWritable、正文与版本选择、环及 categoryUnsupported 失败、plugin 设置、读入与前提兑现均不在模型。

Messages A1 是合法名单 fact 与 readable 合起来的推论，不能推断接收边界已判名单合法；A3 前提“块不变”按构造、无变异。不存在块引用、无 SystemMessage、日志配对与唯一等被类型/事实吸收的内容不作证据；请求区间、卡片占位、形状、并发和真实日志实现不在模型。

## 工具、命令与测量有效性

own `.venv` 由 `uv sync --locked` 准备；`make formal-tools` exit 0。Java 21.0.12.1，TLC2 2026.09.12.025210 rev 867aefb，Alloy 6.2.0 / SAT4J / symmetry 20 / unrolls -1。[tool-paths.json](tool-paths.json) 固定 Java 与两个实际 JAR SHA，[execution-environment.json](execution-environment.json) 固定环境、CPU affinity 与资源读数。执行复用系统 Alloy wrapper、frozen TLC 模型及既定 patch，不新增正式任务或更改模型。

新临时脚本分别为 `run.py`（只记录运行）、`execute_tlc.py`、`execute_alloy.py`、`execute_xml.py`、`read_xml_probe.py`、`parse_results.py`。已执行的完整 argv、cwd、timeout、开始/结束/elapsed、exit 和 raw 在 `runs/<label>/`；无需从 shell 字符串重建。TLC 原始随机 fp/seed、heap 与工具警告在 raw 原文。

读取器 8 个有效负控均检出：只有 exit 0 的空回执、缺命令、缺 solver 行、check 找到反例仍 exit 0、validity run UNSAT、scope 改动、SAT 无可读实例、stderr 与 receipt 矛盾，见 [measurement-selftests.json](measurement-selftests.json)。XML 仅是具体求解器关系读取，不宣称独立重放全部模型或机器证明。

保留一次探查失败：Alloy 不支持 `exec --help`，退出 1，其 usage/stdout/stderr 在 `runs/alloy-exec-help/`。这不是模型检查失败，全部正式命令、变异命令和 XML 补取均无超时、执行错误或漏执行。Alloy 默认 table 输出省略部分关系值，所以保留原 table 并补 XML，未修改原记录。

## 封存与交接

SHA256SUMS 覆盖本目录全部文件（自身除外），FNV-1a 32/64 与 JSON manifest 覆盖内容清单；算法与排除规则在 `seal.json`。`seal.py` 校验 FNV 已知向量并封存，清单包含实际模型、配置、工具版本、脚本、输入、patch、raw、回执、XML 与读取结果。

旧 `tmp/w6-stream-guards/` 的 727 文件与其 seal 原样保留，不参与本轮结果。没有源码提交，也没有主分支、HUB、远程或共享目录操作。主调度负责技术接受、长期 evidence 归档与设计绑定；用户保留最终总体交付验收。
