#!/bin/sh
# Alloy Analyzer — installed at /opt/alloy
exec /opt/java/jdk-21.0.12.1+1-jre/bin/java -jar /opt/alloy/alloy.jar "$@"
