import json, os
from run import EVIDENCE, ROOT, run, dump
TASKS=json.loads((EVIDENCE/'input/registry/formal-tasks.json').read_text())
task=next(x for x in TASKS['tasks'] if x['id']=='stream-assembly-v3-assembly')
argv=[os.path.expandvars(x) for x in task['command']]
assert not any('${' in x for x in argv)
assert argv[argv.index('-workers')+1]=='1' and task['timeout_seconds']==600
dump(EVIDENCE/'registered-tlc-task.json',{'registered':task,'expanded_argv':argv,'snapshot_cwd':str(EVIDENCE/'input'),'model_source':str(ROOT/'.meta_harness/design'/task['artifacts'][0]),'input_equal_frozen':True,'metadir_within_owned_evidence':True})
run('sa3-positive',argv,EVIDENCE/'input',task['timeout_seconds'],0)
for cfg,inv in [('Assembly_OrderByClose','BlockOrderIsOpenOrder'),('Assembly_ReplaceAsAppend','SplitInvariance'),('Assembly_OneShotCloseFirst','OneShotAccepted')]:
    mutant=list(argv)
    mutant[mutant.index('-metadir')+1]='tmp/tlc/'+cfg
    mutant[mutant.index('-config')+1]='spec/capabilities/stream-assembly/v3/formal/'+cfg+'.cfg'
    run('sa3-'+cfg,mutant,EVIDENCE/'input',task['timeout_seconds'],12)
