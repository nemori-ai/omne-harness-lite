from __future__ import annotations
import datetime, hashlib, json, os, pathlib, subprocess, time
ROOT = pathlib.Path(__file__).resolve().parents[2]
EVIDENCE = pathlib.Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def dump(p, x): p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def run(label, argv, cwd, timeout=600, expected_exit=None):
    out=EVIDENCE/'runs'/label
    out.mkdir(parents=True, exist_ok=False)
    start=now(); tick=time.monotonic()
    meta={'label':label,'argv':argv,'cwd':str(cwd),'timeout_seconds':timeout,'start_utc':start,'expected_exit':expected_exit}
    dump(out/'invocation.json',meta)
    with (out/'stdout.log').open('wb') as stdout, (out/'stderr.log').open('wb') as stderr:
        proc=subprocess.Popen(argv,cwd=cwd,stdout=stdout,stderr=stderr,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        timed_out=False
        try: code=proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True; proc.kill(); code=proc.wait()
    meta.update({'end_utc':now(),'elapsed_seconds':time.monotonic()-tick,'exit_code':code,'timed_out':timed_out,'exit_expectation_matches':None if expected_exit is None else code==expected_exit and not timed_out})
    dump(out/'result.json',meta)
    print(json.dumps({'label':label,'exit_code':code,'timed_out':timed_out,'elapsed_seconds':meta['elapsed_seconds']},ensure_ascii=False),flush=True)
    return meta

def prepare():
    design=ROOT/'.meta_harness/design'
    frozen=json.loads((design/'registry/frozen.json').read_text())
    accepted=json.loads((design/'record/decisions/core-implementation-spec-reconciliation/acceptance.json').read_text())
    catalog=json.loads((design/'registry/catalog.json').read_text())
    assert len(frozen['files'])==351 and accepted['status']=='accepted'
    inputs=[]
    for e in accepted['accepts']:
        coord=e['coordinate']
        c=[x for x in catalog['contracts'] if x['coordinate']==coord]
        assert len(c)==1 and c[0]['status']=='accepted'
        for rel,h in e['resources'].items():
            p=design/rel
            assert sha(p)==h and frozen['files'][rel]==h,(rel,sha(p),h)
            target=EVIDENCE/'input'/rel; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(p.read_bytes())
            inputs.append({'path':rel,'sha256':h,'catalog_status':'accepted','frozen':True})
    for rel in ['registry/catalog.json','registry/frozen.json','registry/formal-tasks.json','record/decisions/core-implementation-spec-reconciliation/decision.md','record/decisions/core-implementation-spec-reconciliation/acceptance.json','spec/capabilities/stream-assembly/verification.md','spec/capabilities/asset-evaluation/verification.md','spec/data/messages/verification.md']:
        p=design/rel; t=EVIDENCE/'input'/rel;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(p.read_bytes())
        inputs.append({'path':rel,'sha256':sha(p),'authority_snapshot':True})
    for rel in ['Makefile','docs/verification.md','pyproject.toml','uv.lock','tools/spec-tools/src/omne_harness_lite_spec_tools/check_tool_environment.py']:
        p=ROOT/rel;t=EVIDENCE/'input/development'/rel;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(p.read_bytes())
    models=['spec/capabilities/stream-assembly/v3/formal/'+n for n in ['Assembly.tla','Assembly.cfg','Assembly_OrderByClose.cfg','Assembly_ReplaceAsAppend.cfg','Assembly_OneShotCloseFirst.cfg']]+['spec/data/messages/v3/formal/Readable.als','spec/capabilities/asset-evaluation/v3/formal/Evaluation.als']
    lineage=[]
    for rel in models:
        source=rel.replace('/v3/','/v2/');assert (design/rel).read_bytes()==(design/source).read_bytes()
        t=EVIDENCE/'lineage'/source;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes((design/source).read_bytes())
        lineage.append({'current':rel,'source':source,'current_sha256':sha(design/rel),'source_sha256':sha(design/source),'byte_identical':True})
    for rel in ['record/evidence/2026-09-25-formal-assets-runtimes/stream-assembly-v1-assembly/input/Assembly.tla','record/evidence/2026-09-25-formal-assets-runtimes/stream-assembly-v1-assembly/input/Assembly.cfg','record/evidence/2026-09-25-alloy-asset-evaluation/unregistered-alloy-asset-evaluation/input/Evaluation.als']:
        p=design/rel;t=EVIDENCE/'history'/rel;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(p.read_bytes())
        lineage.append({'historical_raw_path':rel,'historical_sha256':sha(p),'historical_only':True,'run_not_relabelled':True})
    dump(EVIDENCE/'input-index.json',inputs);dump(EVIDENCE/'lineage.json',lineage)
    git=lambda args:subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
    dump(EVIDENCE/'position.json',{'root':str(ROOT),'branch':git(['branch','--show-current']),'head':git(['rev-parse','HEAD']),'status_porcelain':git(['status','--porcelain']),'merge':git(['show','--no-patch','--format=fuller','HEAD']),'authorized_dependency':'f8c76d60dd3f01c9a8cd1e29a94c4accbb9ec361','previous_head':'a3cd11eb50feabf7e44afc5d84ec820d12b77a2a','frozen_resource_count':len(frozen['files']),'at_utc':now()})
    dump(EVIDENCE/'tool-paths.json',{k:{'configured':os.environ.get(k),'resolved':str(pathlib.Path(os.environ[k]).resolve()),'sha256':sha(pathlib.Path(os.environ[k]))} for k in ['JAVA_BIN','TLA2TOOLS_JAR','ALLOY_ANALYZER_JAR']})

if __name__=='__main__':
    import sys
    if sys.argv[1]=='prepare': prepare()
    if sys.argv[1]=='tools':
        run('uv-sync',['uv','sync','--locked'],ROOT,600,0)
        run('formal-tools',['make','formal-tools'],ROOT,600,0)
        run('java-version',[os.environ['JAVA_BIN'],'-version'],ROOT,60,0)
        run('alloy-version',['/usr/local/bin/alloy','version'],EVIDENCE,60,0)
        run('alloy-exec-help',['/usr/local/bin/alloy','exec','--help'],EVIDENCE,60,None)
