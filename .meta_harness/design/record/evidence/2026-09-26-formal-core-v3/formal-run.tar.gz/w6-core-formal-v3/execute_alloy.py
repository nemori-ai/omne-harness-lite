import difflib, json, pathlib, shutil, sys
from run import EVIDENCE, ROOT, run, dump, sha
DESIGN=ROOT/'.meta_harness/design'
PREFIX=DESIGN/'record/evidence/2026-09-25-alloy-asset-evaluation/unregistered-alloy-asset-evaluation/mutants'

def ae():
    model=EVIDENCE/'input/spec/capabilities/asset-evaluation/v3/formal/Evaluation.als'
    targets=[]
    for n in range(1,14):
        base=EVIDENCE/'mutants/asset-evaluation'/f'M{n}'
        base.mkdir(parents=True,exist_ok=False)
        target=base/'Evaluation.als';target.write_bytes(model.read_bytes())
        patch=base/f'M{n}.patch';patch.write_bytes((PREFIX/f'M{n}.patch').read_bytes())
        result=run(f'ae3-apply-M{n}',['patch','--batch','--fuzz=0',str(target),str(patch)],EVIDENCE,60,0)
        assert result['exit_expectation_matches'],f'Frozen patch M{n} failed; stop dependent model execution'
        (base/'applied.diff').write_text(''.join(difflib.unified_diff(model.read_text().splitlines(True),target.read_text().splitlines(True),fromfile='accepted-v3/Evaluation.als',tofile=f'M{n}/Evaluation.als')))
        targets.append((n,target))
    run('ae3-original',['/usr/local/bin/alloy','exec','-f','-o',str(EVIDENCE/'runs/ae3-original/solutions'),str(model)],EVIDENCE,600,0)
    for n,target in targets:
        run(f'ae3-M{n}',['/usr/local/bin/alloy','exec','-f','-o',str(EVIDENCE/f'runs/ae3-M{n}/solutions'),str(target)],EVIDENCE,600,0)

def messages():
    model=EVIDENCE/'input/spec/data/messages/v3/formal/Readable.als'
    source=model.read_text()
    mutations=[
      ('M1','c.names.owner in prevs[c]','c.names.owner in upTo[c]','NewBlocksBornReadable'),
      ('M2','c.names.owner in prevs[c]','c.names.owner in Msg','NewBlocksBornReadable'),
      ('M3','no r : EndReminder & P | r.ends = t.call','no r : EndReminder | r.ends = t.call','OutstandingPlaceholderStaysReadable'),
      ('M4','(b.owner = t) and (no r : EndReminder & P | r.ends = t.call)','(b.owner = t) and (no b.container) and (no r : EndReminder & P | r.ends = t.call)','OutstandingPlaceholderStaysReadable'),
      ('M5','fun path[b : Block] : set Block { b.*container }','fun path[b : Block] : set Block { b }','NestedReadableImpliesContainersReadable')]
    targets=[]
    for label,before,after,assertion in mutations:
        assert source.count(before)==1,(label,source.count(before))
        base=EVIDENCE/'mutants/messages'/label;base.mkdir(parents=True,exist_ok=False)
        changed=source.replace(before,after)
        target=base/'Readable.als';target.write_text(changed)
        (base/'applied.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='accepted-v3/Readable.als',tofile=label+'/Readable.als')))
        dump(base/'mapping.json',{'label':label,'before':before,'after':after,'assertion':assertion,'coordinate':'data.messages/v3/formal/README.md#Alloy','original_sha256':sha(model),'mutant_sha256':sha(target),'expected':'SAT counterexample','scope_unmodified':True})
        targets.append((label,target,assertion))
    run('msg3-original',['/usr/local/bin/alloy','exec','-f','-o',str(EVIDENCE/'runs/msg3-original/solutions'),str(model)],EVIDENCE,600,0)
    for label,target,assertion in targets:
        run('msg3-'+label,['/usr/local/bin/alloy','exec','-f','-c',assertion,'-o',str(EVIDENCE/('runs/msg3-'+label)/'solutions'),str(target)],EVIDENCE,600,0)

if __name__=='__main__': {'ae':ae,'messages':messages}[sys.argv[1]]()
