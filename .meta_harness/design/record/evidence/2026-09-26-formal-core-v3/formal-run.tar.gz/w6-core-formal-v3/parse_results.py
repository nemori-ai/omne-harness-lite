from __future__ import annotations
import copy, json, pathlib, re, sys, xml.etree.ElementTree as ET
from run import EVIDENCE, ROOT, dump, sha
AE_TARGETS={1:['LockTruncates','ReplacementCannotEscapePermission'],2:['DisableIsDisjunction'],3:['WorkspaceNeverSourcesPermission'],4:['OfficialLowerBound'],5:['TeamAssetsStayInTree'],6:['WorkspaceNeverSourcesPlacement'],7:['ReplacementCannotEscapePermission','UnusableKeepsBounds'],8:['NonFittingPickNeverSources'],9:['UnusableNeverEffective'],10:['OfficialLowerBound'],11:['UnusableKeepsBounds'],12:['ForbidIsBound'],13:['WorkspaceNeverSourcesGovernance']}
MSG_TARGETS={1:'NewBlocksBornReadable',2:'NewBlocksBornReadable',3:'OutstandingPlaceholderStaysReadable',4:'OutstandingPlaceholderStaysReadable',5:'NestedReadableImpliesContainersReadable'}

def require(condition, message):
    if not condition: raise ValueError(message)
def declarations(model):
    return {m.group(2):{'type':m.group(1),'source':m.group(0),'expected':'SAT' if m.group(1)=='run' else 'UNSAT'} for m in re.finditer(r'^(run|check)\s+(\w+)[^\n]*$',model.read_text(),re.M)}
def evaluate(receipt, stderr, expected, source_commands):
    require(receipt.get('solver')=='sat4j','unexpected or absent solver')
    commands=receipt.get('commands',{})
    require(set(commands)==set(expected),'command set incomplete or unexpected')
    table={}
    for kind,label,status in re.findall(r'^\d+\.\s+(run|check)\s+(\w+)[^\n]*?\b(UNSAT|SAT)\s*$',stderr.replace('\b',''),re.M):
        require(label not in table,'duplicate solver row');table[label]=(kind,status)
    require(set(table)==set(expected),'solver output rows missing or unexpected')
    results=[]
    for label,c in commands.items():
        source=source_commands[label]
        require(c['source']==source['source'] and c['type']==source['type'],'command scope/type changed')
        solutions=c.get('solution',[])
        actual='SAT' if solutions else 'UNSAT'
        require(table[label]==(c['type'],actual),'stdout/receipt disagreement')
        require(actual==expected[label],f'{label}: expected {expected[label]}, got {actual}')
        require(all(x.get('instances') for x in solutions),'SAT without readable instances')
        results.append({'command':label,'kind':c['type'],'source':c['source'],'scope':{'overall':c['overall'],'scopes':c.get('scopes',[]),'bitwidth':c['bitwidth'],'maxseq':c['maxseq']},'expected':expected[label],'actual':actual,'solution_count':len(solutions),'receipt_instances_read':sum(len(x['instances']) for x in solutions),'matches':True})
    return results

def read_alloy(label,expected,source_commands):
    base=EVIDENCE/'runs'/label
    meta=json.loads((base/'result.json').read_text())
    require(meta['exit_code']==0 and not meta['timed_out'],'execution failed')
    receipt=json.loads((base/'solutions/receipt.json').read_text())
    rows=evaluate(receipt,(base/'stderr.log').read_text(),expected,source_commands)
    for r in rows:
        if r['actual']=='SAT':
            p=base/'solutions'/f"{r['command']}-solution-0.md"
            if not p.exists():p=p.with_suffix('.xml')
            require(p.is_file() and p.stat().st_size>0,'missing solution payload')
            r['solution_path']=str(p.relative_to(EVIDENCE));r['solution_sha256']=sha(p)
    return {'label':label,'exit_code':meta['exit_code'],'elapsed_seconds':meta['elapsed_seconds'],'results':rows,'solver':receipt['solver'],'symmetry':receipt['symmetry'],'unrolls':receipt['unrolls'],'receipt_sha256':sha(base/'solutions/receipt.json')}

def selftest(receipt,stderr,expected,commands):
    failures=[]
    def reject(name,rec,log,exp,cmds):
        try: evaluate(rec,log,exp,cmds)
        except ValueError as e: failures.append({'fixture':name,'detected':True,'error':str(e)});return
        raise ValueError('measurement failed to reject '+name)
    reject('exit_zero_empty_receipt',{},'',expected,commands)
    rec=copy.deepcopy(receipt);rec['commands'].pop(next(iter(rec['commands'])))
    reject('missing_registered_command',rec,stderr,expected,commands)
    reject('exit_zero_without_solver_rows',receipt,'',expected,commands)
    check=next(k for k,v in commands.items() if v['type']=='check')
    rec=copy.deepcopy(receipt);rec['commands'][check]['solution']=copy.deepcopy(next(v['solution'] for v in receipt['commands'].values() if v.get('solution')))
    log=stderr.replace('\b','');log=re.sub(r'(check\s+'+check+r'[^\n]*?)\bUNSAT\b',r'\1SAT',log)
    reject('check_counterexample_despite_exit_zero',rec,log,expected,commands)
    run=next(k for k,v in commands.items() if v['type']=='run');rec=copy.deepcopy(receipt);rec['commands'][run].pop('solution')
    log=re.sub(r'(run\s+'+run+r'[^\n]*?)\bSAT\b',r'\1UNSAT',stderr.replace('\b',''))
    reject('validity_run_unsat_despite_exit_zero',rec,log,expected,commands)
    rec=copy.deepcopy(receipt);rec['commands'][run]['source']+=' but 1 Cap'
    reject('changed_command_scope',rec,stderr,expected,commands)
    rec=copy.deepcopy(receipt);rec['commands'][run]['solution'][0]['instances']=[]
    reject('sat_without_readable_solution',rec,stderr,expected,commands)
    reject('receipt_solver_output_disagree',receipt,stderr.replace('UNSAT','SAT'),expected,commands)
    return failures

def xml_summary(path):
    root=ET.parse(path).getroot();instances=root.findall('instance');require(len(instances)==1,'unexpected XML instance count')
    inst=instances[0]
    def tuples(e):return [[a.attrib['label'] for a in t.findall('atom')] for t in e.findall('tuple')]
    sigs=[{'label':x.attrib['label'],'id':x.attrib['ID'],'parent_id':x.attrib.get('parentID'),'atoms':[a.attrib['label'] for a in x.findall('atom')]} for x in inst.findall('sig')]
    fields=[{'label':x.attrib['label'],'parent_id':x.attrib.get('parentID'),'tuples':tuples(x)} for x in inst.findall('field')]
    skolems=[{'label':x.attrib['label'],'tuples':tuples(x)} for x in inst.findall('skolem')]
    require(fields and any(x['tuples'] for x in fields),'XML without relationship tuples')
    return {'xml_path':str(path.relative_to(EVIDENCE)),'sha256':sha(path),'instance_metadata':inst.attrib,'signatures':sigs,'fields':fields,'skolems':skolems,'interpretation':'Concrete solver instance/counterexample relation readout, not an independent proof or implementation replay.'}

def tlc():
    rows=[]
    for label,inv in [('sa3-positive',None),('sa3-Assembly_OrderByClose','BlockOrderIsOpenOrder'),('sa3-Assembly_ReplaceAsAppend','SplitInvariance'),('sa3-Assembly_OneShotCloseFirst','OneShotAccepted')]:
        base=EVIDENCE/'runs'/label;meta=json.loads((base/'result.json').read_text());log=(base/'stdout.log').read_text()
        require(meta['exit_code']==(0 if inv is None else 12) and not meta['timed_out'],'TLC execution/exit mismatch')
        require('with 1 worker' in log,'TLC worker count changed')
        require('Model checking completed. No error has been found.' in log if inv is None else f'Error: Invariant {inv} is violated.' in log,'TLC property outcome missing')
        stats=re.search(r'(\d+) states generated, (\d+) distinct states found, (\d+) states left on queue.',log)
        require(stats is not None,'TLC counts missing');depth=re.search(r'The depth of the complete state graph search is (\d+)',log)
        if inv is None:require(stats.group(3)=='0','positive TLC exploration incomplete')
        actions=re.findall(r'^State \d+: <([^\n]+)>',log,re.M)
        if inv=='BlockOrderIsOpenOrder':
            expect=['e |-> "open", i |-> 0','e |-> "open", i |-> 1','e |-> "close", i |-> 1','e |-> "close", i |-> 0']
            accept=[x for x in actions if x.startswith('Accept(')];require(len(accept)==4 and all(s in a for s,a in zip(expect,accept)),'order mutation trace mismatch')
        if inv=='SplitInvariance':
            accept=[x for x in actions if x.startswith('Accept(')];require(len(accept)==3 and 'm |-> "replace"' in accept[0] and all('e |-> "fill", i |-> 0' in x for x in accept[1:]),'replace mutation trace mismatch')
        if inv=='OneShotAccepted':
            accept=[x for x in actions if x.startswith('Accept(')];require(len(accept)==3 and 'e |-> "open"' in accept[0] and 'e |-> "fill"' in accept[1] and 'e |-> "close"' in accept[2],'oneshot mutation trace mismatch')
        rows.append({'label':label,'exit_code':meta['exit_code'],'violated_invariant':inv,'generated_states':int(stats.group(1)),'distinct_states':int(stats.group(2)),'queue_remaining':int(stats.group(3)),'depth':int(depth.group(1)),'elapsed_seconds':meta['elapsed_seconds'],'trace_actions_read':actions,'matches':True,'complete_exploration':inv is None})
    return rows

def main():
    am=EVIDENCE/'input/spec/capabilities/asset-evaluation/v3/formal/Evaluation.als';mm=EVIDENCE/'input/spec/data/messages/v3/formal/Readable.als'
    ae=declarations(am);msg=declarations(mm);require(len(ae)==18 and len(msg)==6,'normative command count changed')
    all_rows=[]
    exp={k:v['expected'] for k,v in ae.items()};all_rows.append(read_alloy('ae3-original',exp,ae))
    fixture_base=EVIDENCE/'runs/ae3-original'
    tests=selftest(json.loads((fixture_base/'solutions/receipt.json').read_text()),(fixture_base/'stderr.log').read_text(),exp,ae)
    for n,targets in AE_TARGETS.items():
        expected=dict(exp);expected.update({k:'SAT' for k in targets})
        if n==8:expected['pickSkipped']='UNSAT'
        all_rows.append(read_alloy(f'ae3-M{n}',expected,ae))
    all_rows.append(read_alloy('msg3-original',{k:v['expected'] for k,v in msg.items()},msg))
    for n,command in MSG_TARGETS.items():all_rows.append(read_alloy(f'msg3-M{n}',{command:'SAT'},msg))
    xmls=[]
    for p in sorted((EVIDENCE/'runs').glob('*xml*/solutions/receipt.json')):
        label=p.parents[1].name;rec=json.loads(p.read_text());model=pathlib.Path(json.loads((p.parents[1]/'invocation.json').read_text())['argv'][-1]);cmds=declarations(model)
        require(len(rec['commands'])==1,'XML selected more than one command')
        k=next(iter(rec['commands']));row=read_alloy(label,{k:'SAT'},cmds);all_rows.append(row)
        xmls.append(xml_summary(p.parent/f'{k}-solution-0.xml'))
    require(len(xmls)==28,'SAT XML witness set incomplete')
    dump(EVIDENCE/'measurement-selftests.json',{'positive_case_matches':True,'negative_cases':tests,'passed':len(tests)==8})
    dump(EVIDENCE/'xml-readouts.json',xmls)
    dump(EVIDENCE/'formal-results.json',{'tool_environment':'runs/formal-tools/result.json','TLC':tlc(),'Alloy':all_rows,'Alloy_normative_and_mutant_commands':263,'Alloy_XML_supplemental_commands':28,'Alloy_total_command_readouts':sum(len(x['results']) for x in all_rows),'SAT_XML_witnesses':len(xmls),'all_expected_results_match':True,'unexecuted_triggered_formal_tasks_within_assigned_scope':[],'source_head':json.loads((EVIDENCE/'position.json').read_text())['head'],'technical_acceptance':'pending parent review; not self accepted','implementation_conformity':'not checked by this task'})
    print('TLC 4 runs; Alloy 263 primary + 28 XML; 28 concrete relation readouts; 8 measurement negative controls PASS')
if __name__=='__main__':main()
