from run import EVIDENCE, run
run('ae3-M1-xml-probe',['/usr/local/bin/alloy','exec','-f','-c','LockTruncates','-t','xml','-o',str(EVIDENCE/'runs/ae3-M1-xml-probe/solutions'),str(EVIDENCE/'mutants/asset-evaluation/M1/Evaluation.als')],EVIDENCE,600,0)
