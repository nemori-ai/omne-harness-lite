// Real macOS/Linux networking acceptance driver. No business implementation imports.
import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { mkdtemp, realpath, mkdir, writeFile, readFile, cp, rm } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { makeCa, makeServerCertificate, keygen, freePort, opsDirectory, envOf, opsSocketOf, SETTINGS, CenterProcess } from '../maintenance-probe/deploy.ts'

const mode=process.argv[2], evidence=resolve(process.argv[3])
assert.ok(['linux-center','mac-center'].includes(mode))
assert.equal(process.platform,'darwin')
await mkdir(evidence,{recursive:true})
const root=await mkdtemp(join(await realpath('/tmp'),'omne-cross-'))
const image='node@sha256:0e0ff40c39bc087845bfb27465a0df4ea419520094bc35842ff83dd8cbe6f9b6'
const cli=process.env.OMNE_CROSS_CLI??'/private/tmp/omne-cli-d051-r2-gbcxikmq/app'
const hostApp='/private/tmp/omne-host-portable-probe-20260925'
const id=`omne-cross-${mode}-${process.pid}`, network=id+'-net', center=id+'-center', client=id+'-client'
const logs=[], reports=[], checks=[], fixtures=[]
const password='cross-os-test-password-12345', changed='cross-os-changed-password-67890'
const track=x=>logs.push(x)
let macHost, dockerCenter=false, dockerClient=false, networkCreated=false, counter=0, sequence=0
const commands=JSON.parse(await readFile(join(cli,'commands/governance.json'),'utf8'))
const og=n=>`capability.organization-governance/v2#S-${n}`, ai=n=>`capability.account-identity/v3#S-${n}`
async function run(command,args,timeout=90000){
  return new Promise((resolve,reject)=>{
    const p=spawn(command,args,{stdio:['ignore','pipe','pipe']});let stdout='',stderr=''
    p.stdout.on('data',x=>stdout+=x);p.stderr.on('data',x=>stderr+=x)
    const timer=setTimeout(()=>{p.kill('SIGKILL');reject(Error(`process timeout: ${command}`))},timeout)
    p.on('error',e=>{clearTimeout(timer);reject(e)})
    p.on('close',(code,signal)=>{clearTimeout(timer);resolve({code,signal,stdout,stderr})})
  })
}
async function docker(args,success=true){const x=await run('docker',args);if(success)assert.equal(x.code,0,JSON.stringify(x));return x}
async function recordProcess(label,x){await writeFile(join(evidence,`${String(sequence++).padStart(3,'0')}-${label}.json`),JSON.stringify(x,null,2)+'\n')}
const macRoot=join(root,'mac-clients'), linuxRoot=join(root,'linux-clients'), centerRoot=join(root,'center')
for(const path of [macRoot,linuxRoot,centerRoot])await mkdir(path,{mode:0o700})
const ca=makeCa(centerRoot,'ca',track), wrongCa=makeCa(centerRoot,'wrong-ca',track)
const tls=makeServerCertificate(centerRoot,'leaf',ca,['DNS:localhost','IP:127.0.0.1','DNS:host.docker.internal',`DNS:${center}`],track)
for(const path of [macRoot,linuxRoot]){await cp(ca.certFile,join(path,'ca.pem'));await cp(wrongCa.certFile,join(path,'wrong-ca.pem'))}
const port=await freePort(), containerPort=8443
const macEndpoint=`https://localhost:${port}/`, linuxEndpoint=mode==='linux-center'?`https://${center}:${containerPort}/`:`https://host.docker.internal:${port}/`
function actor(name,platform){return {name,platform,root:platform==='linux'?linuxRoot:macRoot,visible:platform==='linux'?'/clients':macRoot,endpoint:platform==='linux'?linuxEndpoint:macEndpoint}}
async function file(actor,content){const name=`input-${counter++}`;await writeFile(join(actor.root,name),content,{mode:0o600});return join(actor.visible,name)}
async function call(actor,input){
  const command=commands.find(c=>c.action===input.action&&(input.action!=='invoke'||c.operation===input.operation));assert.ok(command)
  const args=['machine',...command.command,'--state-dir',join(actor.visible,actor.name)]
  if(input.action==='configure')args.push('--endpoint',input.endpoint??actor.endpoint,'--ca-file',join(actor.visible,input.badCa?'wrong-ca.pem':'ca.pem'))
  else {
    const payload={...input.payload}
    for(const field of command.secretFields){args.push('--'+(field==='credential'?'credential-file':field==='currentCredential'?'current-credential-file':'new-credential-file'),await file(actor,payload[field]));delete payload[field]}
    if(command.payloadSource!=='none')args.push('--payload-file',await file(actor,JSON.stringify(payload)))
    if(input.readMode==='refresh')args.push('--refresh')
  }
  const x=actor.platform==='linux'?await docker(['exec',client,'node','/cli/dist/main.js',...args],false):await run(process.execPath,[join(cli,'dist/main.js'),...args])
  await recordProcess(actor.platform+'-'+command.command.join('-'),x)
  assert.equal(x.signal,null);assert.equal(x.stdout.trim().split('\n').length,1,x.stderr)
  const report=JSON.parse(x.stdout);assert.equal(report.defect,undefined,JSON.stringify(report));reports.push({actor:actor.name,platform:actor.platform,action:command.command,code:x.code,report})
  return {code:x.code,report}
}
async function setup(actor){assert.equal((await call(actor,{action:'configure'})).code,0);return actor}
async function action(actor,input,status='success'){
  const x=await call(actor,input);assert.equal(x.report.remote.status,status,JSON.stringify(x));
  if(status==='success')assert.equal(x.code,x.report.use==='reenter-required'?4:0,JSON.stringify(x))
  return x.report
}
async function result(actor,operation,payload={},read=false){return (await action(actor,{action:'invoke',operation,payload,...(read?{readMode:'refresh'}:{})})).remote.reply.reply.result}
const login=(actor,name,credential=password)=>action(actor,{action:'login',payload:{loginIdentifier:name,credential}})
async function ready(actor){
  for(let n=0;n<80;n++){const x=await call(actor,{action:'health'});if(x.report.remote.status==='success')return;await new Promise(r=>setTimeout(r,250))}
  throw Error('public HTTPS health did not become available')
}
async function hostLog(){return mode==='linux-center'?(await docker(['logs',center],false)).stderr:macHost.stderr()}
async function restart(crash){
  if(mode==='linux-center'){
    if(crash)await docker(['kill','--signal','KILL',center]);else await docker(['stop','--time','45',center]);
    const exit=await docker(['inspect','--format','{{.State.ExitCode}}',center]);assert.equal(Number(exit.stdout.trim()),crash?137:0)
    await docker(['start',center])
  }else{
    if(crash)await macHost.kill();else assert.equal((await macHost.terminate()).code,0)
    fixtures.push(macHost);macHost=CenterProcess.serve('cross-restarted',macEnv,track);await macHost.ready(macSocket)
  }
}
let macEnv, macSocket
try {
  await docker(['network','create',network]);networkCreated=true
  await docker(['run','-d','--name',client,'--network',network,'--mount',`type=bind,src=${cli},dst=/cli,readonly`,'--mount',`type=bind,src=${linuxRoot},dst=/clients`,image,'node','-e','setInterval(()=>{},3600000)']);dockerClient=true
  const versions=await docker(['exec',client,'node','-p','JSON.stringify({platform:process.platform,arch:process.arch,node:process.version})']);await recordProcess('linux-client-runtime',versions)
  if(mode==='linux-center'){
    const keyRun=await docker(['run','--rm','--mount',`type=bind,src=${hostApp},dst=/host,readonly`,'--mount',`type=bind,src=${centerRoot},dst=/center`,image,'node','/host/dist/cli.js','keygen','/center/keys']);await recordProcess('linux-keygen',keyRun)
    const env=envOf({dbFile:'/center/center.sqlite',keys:JSON.parse(keyRun.stdout).files,tls:{chainFile:'/center/leaf.chain.pem',keyFile:'/center/leaf.key'},host:'0.0.0.0',port:containerPort,opsDir:'/center/ops',settings:SETTINGS})
    await mkdir(join(centerRoot,'ops'),{mode:0o700})
    const envArgs=Object.entries(env).flatMap(([k,v])=>['-e',`${k}=${v}`])
    await docker(['run','-d','--name',center,'--network',network,'-p',`127.0.0.1:${port}:${containerPort}`,'--mount',`type=bind,src=${hostApp},dst=/host,readonly`,'--mount',`type=bind,src=${centerRoot},dst=/center`,...envArgs,image,'node','/host/dist/cli.js','serve']);dockerCenter=true
  }else{
    const deployment={dbFile:join(centerRoot,'center.sqlite'),keys:await keygen(join(centerRoot,'keys'),track),tls,host:'127.0.0.1',port,opsDir:opsDirectory(root),settings:SETTINGS}
    macEnv=envOf(deployment);macSocket=opsSocketOf(deployment);macHost=CenterProcess.serve('cross-mac-center',macEnv,track);await macHost.ready(macSocket)
  }
  const alice=await setup(actor('alice','mac')),bob=await setup(actor('bob','linux')),oldAlice=await setup(actor('alice-other','linux'))
  await ready(alice);await ready(bob);checks.push('Both OS clients reach same center through verified HTTPS')
  const wrong=await setup(actor('untrusted','mac'));await call(wrong,{action:'configure',badCa:true})
  const before=(await hostLog()).split(ai(15)).length
  const refused=await call(wrong,{action:'login',payload:{loginIdentifier:'alice',credential:password}})
  assert.equal(refused.report.remote.transportFailure,'trust');assert.notEqual(refused.code,0)
  assert.equal((await hostLog()).split(ai(15)).length,before);checks.push('Wrong CA rejected before login route is reached')
  for(const [person,name]of [[alice,'alice'],[bob,'bob']]){await action(person,{action:'register',payload:{loginIdentifier:name,credential:password}});await login(person,name)}
  await login(oldAlice,'alice')
  const a=await result(alice,og(36),{},true),b=await result(bob,og(36),{},true)
  const child=await result(alice,og(21),{creationKey:'cross-child'}),parent=await result(alice,og(21),{creationKey:'cross-parent'})
  const at={account:a.account,organization:child},bt={account:b.account,organization:child},pt={account:a.account,organization:parent}
  await result(alice,og(37),{expectedTenant:a,targetTenant:at})
  const offer=await result(alice,'composition.governance-center-entry/v2#S-50',{expectedTenant:at,loginIdentifier:'bob'})
  assert.equal((await result(bob,og(57),{},true)).length,1);await result(bob,og(25),{invitation:offer});await result(bob,og(37),{expectedTenant:b,targetTenant:bt})
  assert.deepEqual(await result(bob,og(26),{tenant:bt},true),{standing:'effective',role:'member'})
  await result(alice,og(28),{expectedTenant:at,targetTenant:bt,role:'superAdministrator'})
  await result(bob,og(60),{expectedTenant:bt},true)
  await result(alice,og(28),{expectedTenant:at,targetTenant:bt,role:'member'})
  assert.equal((await action(bob,{action:'invoke',operation:og(60),payload:{expectedTenant:bt},readMode:'refresh'},'rejected')).view.source,'none')
  checks.push('Mac invitation and role changes observed and enforced by Linux client')
  const req=await result(alice,og(30),{expectedTenant:at,recipientOrganization:parent,direction:'recipientAsParent'})
  await result(alice,og(37),{expectedTenant:at,targetTenant:pt});await result(alice,og(32),{expectedTenant:pt,affiliationRequest:req})
  assert.deepEqual(await result(alice,og(34),{organizations:[child]},true),[parent])
  await result(alice,og(33),{expectedTenant:pt,childOrganization:child});assert.deepEqual(await result(alice,og(34),{organizations:[child]},true),[])
  await result(alice,og(37),{expectedTenant:pt,targetTenant:at});checks.push('Affiliation request, acceptance, read and detach')
  const simultaneous=await Promise.all([result(alice,og(36),{},true),result(bob,og(36),{},true)])
  assert.deepEqual(simultaneous,[at,bt]);checks.push('Concurrent clients preserve separate account/tenant identities')
  await result(alice,og(29),{expectedTenant:at,targetTenant:bt})
  assert.deepEqual((await action(bob,{action:'invoke',operation:og(26),payload:{tenant:bt},readMode:'refresh'},'rejected')).remote.reply.reply,{failure:'notAuthorized'})
  await result(alice,ai(50),{currentCredential:password,newCredential:changed})
  assert.equal((await action(oldAlice,{action:'invoke',operation:og(27),payload:{},readMode:'refresh'},'rejected')).remote.answer,'login-state-rejected')
  await login(alice,'alice',changed);checks.push('Membership removal and credential change invalidate remote access')
  if(mode==='linux-center'){
    const scenario=join(root,'tui.json'),output=join(evidence,'mac-tui-linux-center.json')
    await writeFile(scenario,JSON.stringify({steps:[{screen:'Refresh identity and inboxes',value:'1'}],secrets:[password,changed]}))
    const x=await run('python3',[resolve('tmp/production-cli-onboarding/tui-drive.py'),process.execPath,join(cli,'dist/main.js'),join(macRoot,'alice'),scenario,output]);await recordProcess('mac-tui-linux-center',x);assert.equal(x.code,0,JSON.stringify(x))
    const screen=(JSON.parse(await readFile(output,'utf8'))).screen;assert.ok(screen.includes(a.account));checks.push('Mac real PTY TUI initial reads from Linux center and terminal restoration (scripted terminal replies)')
  }
  const identity=await result(alice,og(36),{},true)
  for(const crash of [false,true]){await restart(crash);await ready(alice);assert.deepEqual(await result(alice,og(36),{},true),identity);checks.push(crash?'SIGKILL/restart preserves confirmed identity':'SIGTERM/restart preserves confirmed identity')}
  const oldReenter=await login(oldAlice,'alice',password).then(()=>null,e=>e);assert.ok(oldReenter,'old credential must not work after restart')
  await action(alice,{action:'logout'});assert.equal((await call(alice,{action:'invoke',operation:og(36),payload:{}})).report.admission.reason,'not-logged-in')
  checks.push('Old credential still refused after restart; logout removes local use')
  const publicData=JSON.stringify(reports)+await hostLog();assert.ok(!publicData.includes(password)&&!publicData.includes(changed)&&!publicData.includes('presentedLoginState'))
  await writeFile(join(evidence,'result.json'),JSON.stringify({status:'PASS',mode,checks,mac:{platform:process.platform,arch:process.arch,node:process.version},linux:JSON.parse(versions.stdout),network:{macEndpoint,linuxEndpoint,ports:'Docker publishes only on host 127.0.0.1; Mac center listens only on 127.0.0.1',clientState:'separate client directories, no center database or private-key mounts in client container'},scope:'Docker Desktop Linux VM/bridge/port-forward plus macOS process; not two physical machines, company DNS/firewall, IME, disk loss or production service installation'},null,2)+'\n')
  console.log(JSON.stringify({status:'PASS',mode,checks:checks.length}))
}catch(error){await writeFile(join(evidence,'failure.txt'),String(error.stack)+'\n');throw error}
finally{
  if(dockerCenter){await recordProcess('center-log',await docker(['logs',center],false));await docker(['rm','-f',center],false)}
  if(macHost){fixtures.push(macHost);if(macHost.running)await macHost.terminate().catch(()=>macHost.kill());await writeFile(join(evidence,'center-processes.json'),JSON.stringify(fixtures.map(h=>({label:h.label,stdout:h.stdout(),stderr:h.stderr()})),null,2)+'\n')}
  if(dockerClient)await docker(['rm','-f',client],false)
  if(networkCreated)await docker(['network','rm',network],false)
  await writeFile(join(evidence,'reports.json'),JSON.stringify(reports,null,2)+'\n')
  await writeFile(join(evidence,'fixture-commands.json'),JSON.stringify(logs,null,2)+'\n')
  await rm(root,{recursive:true,force:true})
}
