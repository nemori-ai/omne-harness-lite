#!/usr/bin/env python3
"""CQ2 S1/S2/S11 acceptance on the detached portable CLI artifact."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

node, cli, evidence = sys.argv[1:4]
evidence = Path(evidence)
evidence.mkdir(parents=True, exist_ok=True)
cases = []
with tempfile.TemporaryDirectory(prefix="omne-qa-smoke-") as base:
    base = os.path.realpath(base)
    probes = [
        ("tui-help", ["tui", "--help"], 0, "Usage: omne tui", None),
        ("non-tty", ["tui", "--terminal-profile", "xterm-379", "--state-dir", base + "/state"], 2, "tty-required", base + "/state"),
        ("bad-profile", ["tui", "--terminal-profile", "unknown", "--state-dir", base + "/state2"], 2, "tty-unsupported", base + "/state2"),
        ("bad-options", ["tui", "--terminal-profile", "xterm-379", "--terminal-profile", "xterm-379", "--state-dir", base + "/state3"], 2, "invalid-options", base + "/state3"),
        ("machine-tui", ["machine", "tui", "--state-dir", base + "/state4"], 2, "invalid-command", base + "/state4"),
    ]
    for name, args, code, marker, directory in probes:
        run = subprocess.run([node, cli, *args], stdin=subprocess.DEVNULL, capture_output=True, timeout=10)
        stdout, stderr = run.stdout.decode("utf-8", "replace"), run.stderr.decode("utf-8", "replace")
        passed = run.returncode == code and marker in (stdout + stderr) and (not directory or not os.path.exists(directory))
        record = {"name": name, "result": "PASS" if passed else "FAIL", "exit_code": run.returncode,
                  "stdout": stdout, "stderr": stderr, "stateAbsent": not directory or not os.path.exists(directory)}
        cases.append(record)
        (evidence / (name + ".json")).write_text(json.dumps(record, indent=2) + "\n")
        print(name, record["result"], "exit", run.returncode)
(evidence / "smoke-summary.json").write_text(json.dumps(cases, indent=2) + "\n")
ok = all(item["result"] == "PASS" for item in cases)
print("PASS" if ok else "FAIL", "CQ2 S1/S2/S11 smoke", sum(x["result"] == "PASS" for x in cases), "/", len(cases))
sys.exit(0 if ok else 1)
