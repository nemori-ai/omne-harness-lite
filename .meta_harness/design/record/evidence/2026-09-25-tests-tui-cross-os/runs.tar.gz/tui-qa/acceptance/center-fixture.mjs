// External service fixture for CQ2 S3/S4/S6/S9 acceptance. This runs the real
// tenancy-host dist/cli.js with new TLS/key material; deploy.ts is used only
// for process setup/record capture, never as the test oracle.
import { writeFileSync } from 'node:fs'
import { join } from 'node:path'
import {
  makeCa, makeServerCertificate, keygen, freePort, opsDirectory,
  envOf, opsSocketOf, SETTINGS, CenterProcess,
} from '../../../../apps/tenancy-host/tests/e2e/deploy.ts'

const root = process.argv[2], evidence = process.argv[3]
if (!root || !evidence) throw new Error('fixture needs root and evidence directory')
const commands = []
const log = line => commands.push(line)
const ca = makeCa(root, 'ca', log)
const tls = makeServerCertificate(root, 'leaf', ca, ['DNS:localhost', 'IP:127.0.0.1'], log)
const deployment = {
  dbFile: join(root, 'center.sqlite'), keys: await keygen(join(root, 'keys'), log),
  tls, host: '127.0.0.1', port: await freePort(), opsDir: opsDirectory(root), settings: SETTINGS,
}
const host = CenterProcess.serve('qa-center', envOf(deployment), log)
await host.ready(opsSocketOf(deployment))
console.log(JSON.stringify({ ready: true, endpoint: `https://localhost:${deployment.port}/`, ca: ca.certFile, pid: host.pid }))
let closing = false
async function close() {
  if (closing) return
  closing = true
  const exit = await host.terminate().catch(error => ({ error: String(error) }))
  writeFileSync(join(evidence, 'center.json'), JSON.stringify({ exit, commands, records: host.records() }, null, 2) + '\n')
  writeFileSync(join(evidence, 'center.stdout.raw'), host.stdout())
  writeFileSync(join(evidence, 'center.stderr.raw'), host.stderr())
  process.exit(0)
}
process.on('SIGTERM', () => { void close() })
process.on('SIGINT', () => { void close() })
process.stdin.resume()
