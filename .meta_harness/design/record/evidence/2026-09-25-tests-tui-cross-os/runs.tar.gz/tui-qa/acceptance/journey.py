#!/usr/bin/env python3
"""CQ2 S3/S4/S6/S8/S9: portable TUI against a real center and independent CLI oracle.

Usage: journey.py NODE CLI EVIDENCE_DIR
The PTY answers DECRQM and records raw output. It is a protocol peer, not a
claim that an actual XTerm or IME has been accepted.
"""
import errno
import fcntl
import json
import os
from pathlib import Path
import pty
import re
import select
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time

NODE, CLI, EVIDENCE = sys.argv[1:4]
EVIDENCE = Path(EVIDENCE)
EVIDENCE.mkdir(parents=True, exist_ok=True)
FIXTURE = Path(__file__).with_name('center-fixture.mjs')
CONTROL = re.compile(rb'\x1b\[\?2004(?:\$p|h|l)')
results = []
machine = []

def screen(raw):
    data = bytes(raw).split(b'\x1b[2J')[-1]
    data = re.sub(rb'\x1b\[[0-9;?]*[ -/]*[@-~]', b'', data)
    return data.decode('utf-8', 'replace').replace('\r', '')

class Peer:
    def __init__(self, directory, setup=False):
        self.master, slave = pty.openpty()
        self.slave = slave
        self.resize(120, 100, notify=False)
        self.original = termios.tcgetattr(slave)
        args = [NODE, CLI, 'tui', '--terminal-profile', 'xterm-379', '--state-dir', directory]
        if setup:
            args.append('--setup')
        self.proc = subprocess.Popen(args, stdin=slave, stdout=slave, stderr=slave,
                                     start_new_session=True,
                                     env={**os.environ, 'TERM':'xterm', 'LC_ALL':'en_US.UTF-8'})
        self.raw = bytearray()
        self.consumed = 0
        self.mode = 2
        self.screens = []
        self.closed = False
    def resize(self, columns, rows, notify=True):
        fcntl.ioctl(self.slave, termios.TIOCSWINSZ, struct.pack('HHHH', rows, columns, 0, 0))
        if notify:
            self.proc.send_signal(signal.SIGWINCH)
    def poll(self, timeout=0.05):
        ready, _, _ = select.select([self.master], [], [], timeout)
        if ready:
            try:
                chunk = os.read(self.master, 65536)
            except OSError as error:
                if error.errno != errno.EIO: raise
                chunk = b''
            if chunk:
                self.raw.extend(chunk)
                for match in CONTROL.finditer(self.raw, max(0, self.consumed - 12)):
                    if match.end() <= self.consumed: continue
                    token = match.group()
                    if token.endswith(b'h'): self.mode = 1
                    elif token.endswith(b'l'): self.mode = 2
                    else: os.write(self.master, b'\x1b[?2004;' + str(self.mode).encode() + b'$y')
                    self.consumed = match.end()
                if b'\x1b[2J' in chunk:
                    self.screens.append(screen(self.raw))
                if len(self.raw) > 3_000_000: raise AssertionError('unbounded output')
        return screen(self.raw)
    def wait(self, predicate, label, timeout=15):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            current = self.poll()
            if predicate(current): return current
            if self.proc.poll() is not None:
                raise AssertionError(f'exited before {label}: {self.proc.returncode}: {current[-900:]}')
        raise AssertionError(f'timeout waiting {label}: {screen(self.raw)[-900:]}')
    def write(self, data): os.write(self.master, data)
    def page_all(self):
        visited = []
        current = self.wait(lambda s: re.search(r'Page \d+/\d+', s) is not None,
                            'page marker')
        while True:
            match = re.search(r'Page (\d+)/(\d+)', current)
            if not match: raise AssertionError(f'page missing: {current[-600:]}')
            current_page, total = map(int, match.groups())
            visited.append(current)
            if current_page == total: return visited
            self.write(b'\x1b[6~')
            next_page = current_page + 1
            current = self.wait(lambda s: f'Page {next_page}/{total}' in s,
                                f'page {next_page}/{total}')
    def enter(self): self.write(b'\r')
    def choose(self, label):
        pages = self.page_all()
        found = re.search(r'(?m)^(\d+)\. ' + re.escape(label) + r'$', '\n'.join(pages))
        if not found: raise AssertionError(f'option not found: {label}')
        number = found.group(1)
        self.write(number.encode())
        self.wait(lambda s: '> ' + number in s, f'choice {label} echo')
        self.enter()
    def finish_dialog(self, title):
        self.wait(lambda s: title in s and re.search(r'Page \d+/\d+', s) is not None, title)
        self.page_all()
        self.enter()
    def finish(self, name):
        try:
            deadline = time.monotonic() + 15
            while self.proc.poll() is None and time.monotonic() < deadline:
                self.poll()
            if self.proc.poll() is None:
                self.proc.kill()
            code = self.proc.wait(timeout=3)
            self.poll(0)
            info = {'name': name, 'exitCode': code, 'termiosRestored':termios.tcgetattr(self.slave)==self.original,
                    'mode2004Restored':self.mode==2, 'frames':len(self.screens)}
            (EVIDENCE / f'{name}.raw').write_bytes(self.raw)
            (EVIDENCE / f'{name}.screens.txt').write_text('\n\n=== FRAME ===\n\n'.join(self.screens))
            (EVIDENCE / f'{name}.json').write_text(json.dumps(info, indent=2)+'\n')
            return info
        finally:
            if self.proc.poll() is None:
                self.proc.kill(); self.proc.wait()
            os.close(self.master); os.close(self.slave)
            self.closed = True

def cli(*args, expect=0):
    command = [NODE, CLI, 'machine', *args]
    run = subprocess.run(command, stdin=subprocess.DEVNULL, capture_output=True, timeout=40)
    out = run.stdout.decode('utf-8', 'replace')
    err = run.stderr.decode('utf-8', 'replace')
    if run.returncode != expect: raise AssertionError(f'CLI {args[:2]} exit {run.returncode} expected {expect}: {out[-1000:]} {err[-500:]}')
    if out.count('\n') != 1: raise AssertionError('machine output not a single JSON record')
    report = json.loads(out)
    machine.append({'args':list(args[:2]), 'exitCode':run.returncode, 'report':report, 'stderr':err})
    return report

def result(report):
    return report['remote']['reply']['reply']['result']

with tempfile.TemporaryDirectory(prefix='omne-qa-center-', dir=os.path.realpath('/tmp')) as work:
    work = os.path.realpath(work)
    fixture = subprocess.Popen([NODE, str(FIXTURE), work, str(EVIDENCE.resolve())],
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               text=True)
    peers = []
    try:
        if not select.select([fixture.stdout], [], [], 55)[0]: raise AssertionError('center readiness timeout')
        ready = json.loads(fixture.stdout.readline())
        if not ready.get('ready'): raise AssertionError(f'center failed: {ready}')
        endpoint, ca = ready['endpoint'], ready['ca']
        (EVIDENCE/'fixture-ready.json').write_text(json.dumps(ready,indent=2)+'\n')
        secret = os.path.join(work, 'credential')
        with open(secret, 'w') as file: file.write('qa-original-password')
        os.chmod(secret, 0o600)
        alice = os.path.join(work, 'alice')
        bob = os.path.join(work, 'bob')
        alice_other = os.path.join(work, 'alice-other')
        def configure(directory):
            return cli('center','configure','--state-dir',directory,'--endpoint',endpoint,'--ca-file',ca)
        def login(directory, name):
            return cli('login','--state-dir',directory,'--login-identifier',name,'--credential-file',secret)
        for directory in (alice,bob,alice_other): configure(directory)
        cli('register','--state-dir',alice,'--login-identifier','qa-alice','--credential-file',secret)
        cli('register','--state-dir',bob,'--login-identifier','qa-bob','--credential-file',secret)
        login(alice,'qa-alice'); login(bob,'qa-bob'); login(alice_other,'qa-alice')
        alice_id = result(cli('tenant','current','--state-dir',alice,'--refresh'))['account']
        bob_id = result(cli('tenant','current','--state-dir',bob,'--refresh'))['account']
        before_tenants = result(cli('tenant','list','--state-dir',alice_other,'--refresh'))

        # Setup has no Use. Health is an actual center read and the screen exits
        # after one root action without entering a governance menu.
        setup = Peer(alice, setup=True); peers.append(setup)
        setup.wait(lambda s:'Connection and login' in s and 'Center health' in s, 'setup menu')
        setup.choose('Center health')
        setup.finish_dialog('Center health — exit status')
        setup_info = setup.finish('setup-health')
        setup_pass = setup_info['exitCode']==0 and setup_info['termiosRestored'] and setup_info['mode2004Restored']
        results.append({'id':'Q02', 'result':'PASS' if setup_pass else 'FAIL', 'evidence':setup_info})

        tui = Peer(alice); peers.append(tui)
        for title in ('Tenant current — exit status', 'Invitation inbox — exit status',
                      'Affiliation inbox — exit status'):
            tui.finish_dialog(title)
        menu = tui.wait(lambda s:'Governance' in s and 'Organization create' in s, 'governance menu')
        identity = f'Account: {alice_id}' in menu and 'Identity source:' in menu
        inbox = all(title in bytes(tui.raw).decode('utf-8','replace') for title in
                    ('Tenant current', 'Invitation inbox', 'Affiliation inbox'))
        results.append({'id':'Q03','result':'PASS' if identity and inbox else 'FAIL',
                        'aliceId':alice_id,'initialReadTitles':inbox,'identityVisible':identity})

        tui.resize(60, 16)
        tui.wait(lambda s:'Page ' in s and 'Governance' in s, 'resized governance menu')
        tui.choose('Organization create')
        tui.wait(lambda s:'Creation reference' in s and 'Specify a value' in s,
                 'creation reference optional choice')
        tui.choose('Specify a value')
        tui.wait(lambda s:'Creation reference' in s and 'Do not specify' not in s,
                 'creation reference field')
        key = 'qa-org-20260925'
        tui.write(key.encode())
        tui.wait(lambda s:'> '+key in s, 'creation key echo')
        tui.enter()
        preview = tui.wait(lambda s:'Confirm: Organization create' in s and 'Page ' in s, 'write preview')
        first = re.search(r'Page (\d+)/(\d+)', preview)
        pages = int(first.group(2)) if first else 0
        if pages <= 1: raise AssertionError('preview did not paginate at 60x16')
        tui.write(b'2')
        tui.wait(lambda s:'> 2' in s,'early confirmation echo')
        tui.enter()
        rejected = tui.wait(lambda s:'Read every page' in s and 'Confirm: Organization create' in s,
                            'early confirmation rejected')
        no_early_result = 'Organization create — exit status' not in rejected
        tui.page_all(); tui.enter()
        tui.finish_dialog('Organization create — exit status')
        tui.wait(lambda s:'Governance' in s and re.search(r'Page \d+/\d+',s) is not None,
                 'menu after create')
        after_tenants = result(cli('tenant','list','--state-dir',alice_other,'--refresh'))
        write_once = isinstance(after_tenants,list) and len(after_tenants)==len(before_tenants)+1
        results.append({'id':'Q04','result':'PASS' if no_early_result and write_once else 'FAIL',
                        'previewPages':pages,'earlyConfirmationRejected':no_early_result,
                        'tenantCountBefore':len(before_tenants),'tenantCountAfter':len(after_tenants)})

        # Another process changes CLS selection after the successful write.
        # The already-open use must never silently become Bob: a conflict or
        # reentry result is allowed by CG2 and must be shown as such.
        login(alice,'qa-bob')
        selected = result(cli('tenant','current','--state-dir',alice,'--refresh'))['account']
        tui.choose('Tenant current')
        tui.wait(lambda s:'Read source' in s and 'Read from center' in s,'read source')
        tui.choose('Read from center')
        tui.finish_dialog('Tenant current — exit status')
        tui_info = tui.finish('governance-create')
        transcript = bytes(tui.raw).decode('utf-8','replace')
        fixed = selected==bob_id and f'Account: {alice_id}' in transcript and f'Account: {bob_id}' not in transcript
        conflict = 'Tenant current — exit status 4' in transcript and tui_info['exitCode']==4
        results.append({'id':'Q05','result':'PASS' if fixed and conflict else 'FAIL',
                        'selectedCLIAccount':selected,'tuiAccount':alice_id,
                        'noBobIdentityInTui':fixed,'conflictReported':conflict,'tuiExit':tui_info['exitCode']})
    except Exception as error:
        results.append({'id':'journey-exception','result':'FAIL','error':repr(error)})
        print('FAIL',repr(error),flush=True)
    finally:
        for peer in peers:
            if peer.closed: continue
            if peer.proc.poll() is None:
                peer.proc.send_signal(signal.SIGTERM)
                deadline = time.monotonic()+5
                while peer.proc.poll() is None and time.monotonic()<deadline: peer.poll()
            if peer.proc.poll() is None: peer.proc.kill()
            peer.proc.wait()
            # A failing scenario still retains its raw stream.
            name = 'unfinished-'+str(peers.index(peer))
            if not (EVIDENCE/f'{"setup-health" if peers.index(peer)==0 else "governance-create"}.raw').exists():
                (EVIDENCE/f'{name}.raw').write_bytes(peer.raw)
            try: os.close(peer.master); os.close(peer.slave)
            except OSError: pass
        fixture.send_signal(signal.SIGTERM)
        try: fixture.wait(timeout=45)
        except subprocess.TimeoutExpired:
            fixture.kill(); fixture.wait()
        (EVIDENCE/'fixture.stderr.raw').write_text(fixture.stderr.read())
        (EVIDENCE/'machine.json').write_text(json.dumps(machine,indent=2)+'\n')

(EVIDENCE/'journey-summary.json').write_text(json.dumps(results,indent=2)+'\n')
for item in results: print(item['id'],item['result'])
okay = results and all(item['result']=='PASS' for item in results)
print('PASS' if okay else 'FAIL','CQ2 real-center journey',sum(x['result']=='PASS' for x in results),'/',len(results))
sys.exit(0 if okay else 1)
