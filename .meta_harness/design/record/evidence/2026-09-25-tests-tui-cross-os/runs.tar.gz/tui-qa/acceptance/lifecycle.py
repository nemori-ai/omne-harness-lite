#!/usr/bin/env python3
"""CQ2 S7/S10 PTY acceptance: actual process, scripted DECRQM peer.

Usage: lifecycle.py NODE CLI EVIDENCE_DIR
The DECRQM peer is a test double for XTerm, so this does not accept a terminal
profile or IME. The 120 ms split is the specified adversarial input condition,
not a readiness wait. Readiness is always a screen predicate.
"""
import errno
import fcntl
import json
import os
import pty
import re
import select
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time
from pathlib import Path

NODE, CLI, DEST = sys.argv[1:4]
DEST = Path(DEST)
DEST.mkdir(parents=True, exist_ok=True)
CONTROL = re.compile(rb"\x1b\[\?2004(?:\$p|h|l)")
SCENARIOS = ("normal", "signal", "split-paste", "paste-signal")
results = []

def stripped(data):
    screen = data.split(b"\x1b[2J")[-1]
    screen = re.sub(rb"\x1b\[[0-9;?]*[ -/]*[@-~]", b"", screen)
    return screen.decode("utf-8", "replace")

for case in SCENARIOS:
    with tempfile.TemporaryDirectory(prefix="omne-qa-pty-") as work:
        work = os.path.realpath(work)
        master, slave = pty.openpty()
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 40, 100, 0, 0))
        original = termios.tcgetattr(slave)
        proc = subprocess.Popen(
            [NODE, CLI, "tui", "--terminal-profile", "xterm-379", "--state-dir",
             os.path.join(work, "state"), "--setup"],
            stdin=slave, stdout=slave, stderr=slave, start_new_session=True,
            env={**os.environ, "TERM": "xterm", "LC_ALL": "en_US.UTF-8"},
        )
        raw = bytearray()
        controls = []
        consumed = 0
        mode = 2
        menu = False
        sent = False
        enter_sent = False
        split_start = None
        signal_sent = False
        tail_sent = False
        premature_exit = False
        deadline = time.monotonic() + 15
        try:
            while time.monotonic() < deadline:
                readable, _, _ = select.select([master], [], [], 0.02)
                if readable:
                    try:
                        chunk = os.read(master, 65536)
                    except OSError as err:
                        if err.errno != errno.EIO:
                            raise
                        chunk = b""
                    if chunk:
                        raw.extend(chunk)
                        # Match across OS read boundaries and answer each query once.
                        for found in CONTROL.finditer(raw, max(0, consumed - 12)):
                            if found.end() <= consumed:
                                continue
                            token = found.group()
                            controls.append([found.start(), token.decode("ascii", "replace")])
                            if token.endswith(b"h"):
                                mode = 1
                            elif token.endswith(b"l"):
                                mode = 2
                            else:
                                os.write(master, b"\x1b[?2004;" + str(mode).encode() + b"$y")
                            consumed = found.end()
                        if not menu and "One action per setup invocation" in stripped(raw):
                            menu = True
                    if len(raw) > 2_000_000:
                        raise AssertionError("unbounded output")
                if menu and not sent:
                    sent = True
                    if case == "normal":
                        os.write(master, b"1")
                    elif case == "signal":
                        proc.send_signal(signal.SIGTERM)
                        signal_sent = True
                    elif case == "split-paste":
                        os.write(master, b"\x1b")
                        split_start = time.monotonic()
                    else:
                        os.write(master, b"\x1b[200~unfinished")
                        proc.send_signal(signal.SIGTERM)
                        signal_sent = True
                        split_start = time.monotonic()
                if case == "normal" and sent and not enter_sent and "> 1" in stripped(raw):
                    os.write(master, b"\r")
                    enter_sent = True
                if split_start and not tail_sent and time.monotonic() - split_start >= 0.12:
                    premature_exit = proc.poll() is not None
                    if not premature_exit:
                        os.write(master, b"[200~1\x1b[201~" if case == "split-paste" else b"\x1b[201~")
                        tail_sent = True
                        if case == "split-paste":
                            # Pasted '1' is data, never a menu confirmation.
                            proc.send_signal(signal.SIGTERM)
                            signal_sent = True
                    else:
                        break
                if proc.poll() is not None:
                    if split_start and not tail_sent:
                        premature_exit = True
                    # Drain remaining bytes for final diagnostic and restoration evidence.
                    while select.select([master], [], [], 0)[0]:
                        try:
                            more = os.read(master, 65536)
                        except OSError:
                            break
                        if not more:
                            break
                        raw.extend(more)
                    break
            timed_out = proc.poll() is None
            if timed_out:
                proc.kill()
            code = proc.wait(timeout=3)
            restored = termios.tcgetattr(slave) == original
            checks = {
                "menuObserved": menu,
                "exitCode": code,
                "termiosRestored": restored,
                "mode2004Restored": mode == 2,
                "prematureExitBeforeTail": premature_exit,
                "tailSent": tail_sent,
                "timedOut": timed_out,
            }
            expected_exit = 0 if case == "normal" else 2
            passed = (menu and not timed_out and restored and mode == 2
                      and code == expected_exit and not premature_exit
                      and (case in ("normal", "signal") or tail_sent))
            if case == "split-paste":
                # The split START must not have been treated as an Esc cancel.
                passed = passed and signal_sent and tail_sent
            result = {"case": case, "result": "PASS" if passed else "FAIL", **checks,
                      "modeControls": controls, "screenTail": stripped(raw)[-1500:]}
            results.append(result)
            (DEST / f"{case}.raw").write_bytes(raw)
            (DEST / f"{case}.json").write_text(json.dumps(result, indent=2) + "\n")
            print(json.dumps({"case": case, "result": result["result"], "checks": checks}), flush=True)
        finally:
            if proc.poll() is None:
                proc.kill()
                proc.wait()
            os.close(master)
            os.close(slave)

(DEST / "lifecycle-summary.json").write_text(json.dumps(results, indent=2) + "\n")
all_pass = all(item["result"] == "PASS" for item in results)
print("PASS" if all_pass else "FAIL", "CQ2 S7/S10 lifecycle", sum(item["result"] == "PASS" for item in results), "/", len(results))
sys.exit(0 if all_pass else 1)
