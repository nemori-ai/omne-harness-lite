#!/usr/bin/env python3
"""CQ2 S5/S6/S12: 34 frozen forms through the detached TUI and CG preview.

Usage: forms_coverage.py NODE CLI FROZEN_FORMS COMMANDS EVIDENCE_DIR
Writes are cancelled at the actual CG Preview; reads may reach the real center.
This verifies Intent mapping, not success semantics for actions lacking live offers.
"""
import errno
import fcntl
import json
import os
from pathlib import Path
import pty
import re
import select
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time

NODE, CLI, FROZEN, COMMANDS, EVIDENCE = sys.argv[1:6]
EVIDENCE=Path(EVIDENCE);EVIDENCE.mkdir(parents=True,exist_ok=True)
forms=json.loads(Path(FROZEN).read_text())
commands=json.loads(Path(COMMANDS).read_text())
fixture=Path(__file__).with_name('center-fixture.mjs')
CTRL=re.compile(rb'\x1b\[\?2004(?:\$p|h|l)')
records=[];machine=[]

def clean(data):
    data=re.sub(rb'\x1b\[[0-9;?]*[ -/]*[@-~]',b'',bytes(data))
    return data.decode('utf-8','replace').replace('\r','')
def screen(raw):return clean(bytes(raw).split(b'\x1b[2J')[-1])

class Peer:
    def __init__(self,directory,setup=False):
        self.master,self.slave=pty.openpty()
        fcntl.ioctl(self.slave,termios.TIOCSWINSZ,struct.pack('HHHH',100,120,0,0))
        self.original=termios.tcgetattr(self.slave)
        self.proc=subprocess.Popen(
            [NODE,CLI,'tui','--terminal-profile','xterm-379','--state-dir',directory,*(['--setup'] if setup else [])],
            stdin=self.slave,stdout=self.slave,stderr=self.slave,start_new_session=True,
            env={**os.environ,'TERM':'xterm','LC_ALL':'en_US.UTF-8'})
        self.raw=bytearray();self.scanned=0;self.mode=2;self.closed=False
    def poll(self,t=.03):
        ready,_,_=select.select([self.master],[],[],t)
        if ready:
            try:chunk=os.read(self.master,65536)
            except OSError as error:
                if error.errno!=errno.EIO:raise
                chunk=b''
            if chunk:
                self.raw.extend(chunk)
                for hit in CTRL.finditer(self.raw,max(0,self.scanned-12)):
                    if hit.end()<=self.scanned:continue
                    token=hit.group()
                    if token.endswith(b'h'):self.mode=1
                    elif token.endswith(b'l'):self.mode=2
                    else:os.write(self.master,b'\x1b[?2004;'+str(self.mode).encode()+b'$y')
                    self.scanned=hit.end()
                if len(self.raw)>15_000_000:raise AssertionError('unbounded output')
        return screen(self.raw)
    def wait(self,predicate,label,seconds=12):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            shown=self.poll()
            if predicate(shown):return shown
            if self.proc.poll() is not None:
                raise AssertionError(f'process exited before {label}: {self.proc.returncode}: {shown[-600:]}')
        raise AssertionError(f'timeout {label}: {screen(self.raw)[-650:]}')
    def write(self,text):os.write(self.master,text if isinstance(text,bytes) else text.encode())
    def page_all(self):
        shown=self.wait(lambda s:re.search(r'Page \d+/\d+',s) is not None,'page marker')
        pages=[]
        while True:
            match=re.search(r'Page (\d+)/(\d+)',shown)
            current,total=map(int,match.groups())
            pages.append(shown)
            if current==total:return pages
            self.write(b'\x1b[6~')
            shown=self.wait(lambda s:f'Page {current+1}/{total}' in s,'next page')
    def choose(self,label):
        all_pages='\n'.join(self.page_all())
        match=re.search(r'(?m)^(\d+)\. '+re.escape(label)+r'$',all_pages)
        if not match:raise AssertionError(f'option {label} missing: {all_pages[-500:]}')
        number=match.group(1)
        self.write(number);self.wait(lambda s:'> '+number in s,'choice echo');self.write(b'\r')
    def text(self,value,label):
        self.wait(lambda s:label in s and re.search(r'Page \d+/\d+',s) is not None,label)
        self.write(value)
        self.wait(lambda s:'> '+value in s,'field echo '+label)
        self.write(b'\r')
    def finish_report(self,label):
        self.wait(lambda s:label+' — exit status' in s and 'Page ' in s,'result '+label)
        self.page_all();self.write(b'\r')
    def finish_report(self,label):
        self.wait(lambda s:label+' — exit status' in s and 'Page ' in s,'result '+label)
        self.page_all();self.write(b'\r')
    def end(self,name):
        if self.closed:return None
        if self.proc.poll() is None:self.proc.send_signal(signal.SIGTERM)
        until=time.monotonic()+15
        while self.proc.poll() is None and time.monotonic()<until:self.poll()
        if self.proc.poll() is None:self.proc.kill()
        code=self.proc.wait(timeout=3);self.poll(0)
        outcome={'exitCode':code,'termiosRestored':termios.tcgetattr(self.slave)==self.original,
                 'mode2004Restored':self.mode==2,'rawLength':len(self.raw)}
        (EVIDENCE/f'{name}.raw').write_bytes(self.raw)
        (EVIDENCE/f'{name}.json').write_text(json.dumps(outcome,indent=2)+'\n')
        os.close(self.master);os.close(self.slave);self.closed=True
        return outcome

def intent_from(segment,label):
    texts=[]
    for part in bytes(segment).split(b'\x1b[H\x1b[2J'):
        shown=clean(part)
        if 'Preview source:' in shown and label in shown:
            texts.append(shown)
    if not texts:raise AssertionError(f'CG Preview for {label} never rendered')
    shown=max(texts,key=len)
    marker=shown.index('Preview source:')
    start=shown.find('{',marker)
    if start<0:raise AssertionError('preview JSON not visible')
    return json.JSONDecoder().raw_decode(shown[start:])[0],shown

def cli(*args):
    run=subprocess.run([NODE,CLI,'machine',*args],stdin=subprocess.DEVNULL,capture_output=True,timeout=45)
    out=run.stdout.decode('utf-8','replace')
    if run.returncode!=0 or out.count('\n')!=1:
        raise AssertionError(f'CLI {args[:2]} exit{run.returncode}: {out[-500:]} {run.stderr[-500:]}')
    reply=json.loads(out)
    machine.append({'command':list(args[:2]),'report':reply})
    return reply
def value(report):return report['remote']['reply']['reply']['result']

with tempfile.TemporaryDirectory(prefix='omne-qa-forms-',dir=os.path.realpath('/tmp')) as root:
    root=os.path.realpath(root)
    server=subprocess.Popen([NODE,str(fixture),root,str(EVIDENCE.resolve())],
                            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    peers=[]
    try:
        if not select.select([server.stdout],[],[],55)[0]:raise AssertionError('center readiness timeout')
        ready=json.loads(server.stdout.readline())
        endpoint,ca=ready['endpoint'],ready['ca']
        directory=os.path.join(root,'alice')
        credential=os.path.join(root,'credential')
        secret='QA-CREDENTIAL-CONTENT-DO-NOT-RENDER'
        Path(credential).write_text(secret);os.chmod(credential,0o600)
        cli('center','configure','--state-dir',directory,'--endpoint',endpoint,'--ca-file',ca)
        cli('register','--state-dir',directory,'--login-identifier','qa-form-alice','--credential-file',credential)
        cli('login','--state-dir',directory,'--login-identifier','qa-form-alice','--credential-file',credential)
        tenant=value(cli('tenant','current','--state-dir',directory,'--refresh'))
        known={'account':tenant['account'],'organization':tenant['organization'],
               'endpoint':endpoint,'caFile':ca,'credential':credential}

        # Independent static crosswalk: frozen CQ2 list to CQ1 commands, then
        # actual TUI screens below. This does not count as runtime coverage.
        bundled=json.loads((Path(CLI).parent.parent/'forms'/'forms.json').read_text())
        if forms!=bundled:raise AssertionError('bundled form definitions differ from frozen source')
        for form in forms:
            counterpart=next((c for c in commands if ' '.join(c['command'])==form['id']),None)
            if counterpart is None or counterpart['action']!=form['action'] or \
               counterpart.get('operation')!=form.get('operation'):
                raise AssertionError('CQ1 command crosswalk mismatch: '+form['id'])

        def choose_field(peer,field,draft):
            if field.get('when') and draft.get(field['when']['field'])!=field['when']['equals']:
                return
            if field['kind']=='current-tenant':return
            label=field['label']
            if not field['required']:
                peer.wait(lambda s:label in s and 'Do not specify; use center default' in s,
                          'optional '+label)
                peer.choose('Do not specify; use center default')
                return
            kind=field['kind'];name=field['name']
            if kind=='enum':
                option='system-ca' if name=='trustMode' else field['options'][-1]
                peer.wait(lambda s:label in s and option in s,'enum '+label)
                peer.choose(option);draft[name]=option
            elif kind=='boolean':
                peer.choose('True');draft[name]=True
            elif kind=='tenant':
                peer.text(known['account'],label+': account ID')
                peer.text(known['organization'],label+': organization ID')
                draft[name]={'account':known['account'],'organization':known['organization']}
            elif kind=='organizations':
                peer.choose('One organization')
                peer.text(known['organization'],'Organization 1 ID')
                draft[name]=[known['organization']]
            else:
                if kind=='secret-file':v=credential
                elif name=='endpoint':v=endpoint
                elif name=='caFile':v=ca
                elif name in ('invitedAccount',):v=known['account']
                elif name in ('organization','recipientOrganization','childOrganization'):v=known['organization']
                elif name=='loginIdentifier':v='qa-form-alice'
                elif name=='offerTtl':v='3600000'
                else:v='qa-valid-opaque-id'
                peer.text(v,label);draft[name]=v
        def expected(form,draft):
            payload={}
            for field in form['fields']:
                name=field['name']
                if field.get('when') and draft.get(field['when']['field'])!=field['when']['equals']:
                    continue
                if field['kind']=='current-tenant':payload[name]=tenant
                elif field['kind']!='secret-file' and name in draft:payload[name]=draft[name]
            action=form['action']
            if action=='configure':
                # CG2 S6 publishes a safe trust summary in Preview; the TUI
                # submitted {mode:ca}, but the observed projection adds source.
                return {'action':'configure','endpoint':payload['endpoint'],
                        'trust':{'mode':'ca','source':'system'}}
            if action in ('health','logout'):return {'action':action}
            intent={'action':action,'payload':payload}
            if action=='invoke':
                intent['operation']=form['operation']
                if next(c for c in commands if ' '.join(c['command'])==form['id']).get('refresh'):
                    intent['readMode']='refresh'
            return intent
        def drive_form(peer,form):
            label=form['label'];start=len(peer.raw)
            peer.wait(lambda s:'Connection and login' in s if form['phase']=='setup' else 'Governance' in s,
                      'menu before '+label)
            peer.choose(label)
            draft={}
            for field in form['fields']:choose_field(peer,field,draft)
            is_read=form['action']=='health' or (form['action']=='invoke' and
                next(c for c in commands if ' '.join(c['command'])==form['id']).get('refresh'))
            if form['action']=='invoke' and is_read:
                peer.wait(lambda s:'Read source' in s and 'Read from center' in s,'read source')
                peer.choose('Read from center')
            if not is_read:
                peer.wait(lambda s:'Confirm: '+label in s and 'Page ' in s,'write preview '+label)
                peer.choose('Cancel')
            peer.wait(lambda s:label+' — exit status' in s and 'Page ' in s,'result '+label)
            actual,shown=intent_from(peer.raw[start:],label)
            want=expected(form,draft)
            mismatch=actual!=want
            leaked=secret in bytes(peer.raw[start:]).decode('utf-8','replace')
            peer.page_all();peer.write(b'\r')
            extra_read=False
            if form['id']=='tenant switch':
                after=peer.wait(lambda s:('Tenant current — exit status' in s or
                                           ('Governance' in s and '1. Exit' in s)),
                                'post-switch result or menu')
                if 'Tenant current — exit status' in after:
                    extra_read=True
                    peer.finish_report('Tenant current')
            return {'id':form['id'],'phase':form['phase'],'action':form['action'],
                    'result':'FAIL' if mismatch or leaked or extra_read else 'PASS','actualIntent':actual,
                    'expectedIntent':want,'secretLeaked':leaked,'previewRendered':True,
                    'reportRendered':True,'unexpectedReadAfterNonSuccessSwitch':extra_read}

        # Each setup run is intentionally a new process because the contract
        # allows only one root action. Governance keeps one fixed Use.
        for form in (f for f in forms if f['phase']=='setup'):
            peer=Peer(directory,True);peers.append(peer)
            try:
                item=drive_form(peer,form)
                records.append(item)
                peer.end('setup-'+form['id'].replace(' ','-'))
            except Exception as error:
                records.append({'id':form['id'],'result':'FAIL','error':repr(error)})
                peer.end('failed-setup-'+form['id'].replace(' ','-'))
        governance=Peer(directory);peers.append(governance)
        for title in ('Tenant current','Invitation inbox','Affiliation inbox'):
            governance.finish_report(title)
        ordered=[f for f in forms if f['phase']=='governance' and f['id']!='logout'] + \
                [f for f in forms if f['id']=='logout']
        for form in ordered:
            try:
                item=drive_form(governance,form)
                records.append(item)
                (EVIDENCE/('form-'+form['id'].replace(' ','-')+'.json')).write_text(json.dumps(item,indent=2)+'\n')
            except Exception as error:
                records.append({'id':form['id'],'result':'FAIL','error':repr(error)})
                break
        governance.end('governance-all')
        (EVIDENCE/'machine.json').write_text(json.dumps(machine,indent=2)+'\n')
    except Exception as error:
        records.append({'id':'fixture','result':'FAIL','error':repr(error)})
    finally:
        for index,peer in enumerate(peers):
            if not peer.closed:peer.end('unfinished-'+str(index))
        server.send_signal(signal.SIGTERM)
        try:server.wait(timeout=45)
        except subprocess.TimeoutExpired:server.kill();server.wait()
        (EVIDENCE/'fixture.stderr.raw').write_text(server.stderr.read())

(EVIDENCE/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
hits=sum(item['result']=='PASS' for item in records)
print(json.dumps({'status':'PASS' if hits==34 and len(records)==34 else 'FAIL',
                  'forms':len(records),'passed':hits,
                  'failures':[{'id':x['id'],'error':x.get('error')} for x in records if x['result']!='PASS']}))
sys.exit(0 if hits==34 and len(records)==34 else 1)
