#!/usr/bin/env python3
"""CQ2 S6/S8: a confirmation typed into an undelivered old preview is inert.

Usage: revision_backpressure.py NODE CLI EVIDENCE_DIR. A large PTY window
creates a real kernel write backlog. Resizing then supersedes the blocked
preview revision. The machine CLI checks local binding before/after fresh
confirmation. No governance center is needed for configure's local CAS.
"""
import errno,fcntl,json,os,pty,re,select,signal,struct,subprocess,sys,tempfile,termios,time
from pathlib import Path
NODE,CLI,EVIDENCE=sys.argv[1:4]
EVIDENCE=Path(EVIDENCE);EVIDENCE.mkdir(parents=True,exist_ok=True)
FIXTURE=Path(__file__).with_name('center-fixture.mjs')
CONTROL=re.compile(rb'\x1b\[\?2004(?:\$p|h|l)')
def clean(raw):
    raw=re.sub(rb'\x1b\[[0-9;?]*[ -/]*[@-~]',b'',bytes(raw))
    return raw.decode('utf8','replace').replace('\r','')
def screen(raw):return clean(bytes(raw).split(b'\x1b[2J')[-1])

class Peer:
    def __init__(self,directory):
        self.master,self.slave=pty.openpty();self.directory=directory
        self.size(100,40,False)
        self.original=termios.tcgetattr(self.slave)
        self.proc=subprocess.Popen([NODE,CLI,'tui','--terminal-profile','xterm-379',
                '--state-dir',directory,'--setup'],stdin=self.slave,stdout=self.slave,
                stderr=self.slave,start_new_session=True,
                env={**os.environ,'TERM':'xterm','LC_ALL':'en_US.UTF-8'})
        self.raw=bytearray();self.pos=0;self.mode=2
    def size(self,columns,rows,notify=True):
        fcntl.ioctl(self.slave,termios.TIOCSWINSZ,struct.pack('HHHH',rows,columns,0,0))
        if notify:self.proc.send_signal(signal.SIGWINCH)
    def poll(self,timeout=.03,maxread=65536):
        ready,_,_=select.select([self.master],[],[],timeout)
        if ready:
            try:chunk=os.read(self.master,maxread)
            except OSError as error:
                if error.errno!=errno.EIO:raise
                chunk=b''
            if chunk:
                self.raw.extend(chunk)
                for hit in CONTROL.finditer(self.raw,max(0,self.pos-12)):
                    if hit.end()<=self.pos:continue
                    token=hit.group()
                    if token.endswith(b'h'):self.mode=1
                    elif token.endswith(b'l'):self.mode=2
                    else:os.write(self.master,b'\x1b[?2004;'+str(self.mode).encode()+b'$y')
                    self.pos=hit.end()
                if len(self.raw)>3_000_000:raise AssertionError('unbounded output')
        return screen(self.raw)
    def wait(self,predicate,label,seconds=15,maxread=65536):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            shown=self.poll(maxread=maxread)
            if predicate(shown):return shown
            if self.proc.poll() is not None:
                raise AssertionError(f'exited before {label}: {self.proc.returncode}: {shown[-700:]}')
        raise AssertionError(f'timeout {label}: {screen(self.raw)[-700:]}')
    def write(self,data):os.write(self.master,data if isinstance(data,bytes) else data.encode())
    def choose(self,label):
        shown=self.wait(lambda s:label in s and re.search(r'Page \d+/\d+',s) is not None,label)
        match=re.search(r'(?m)^(\d+)\. '+re.escape(label)+r'$',shown)
        if not match:raise AssertionError(f'choice absent: {label}: {shown[-700:]}')
        number=match.group(1)
        self.write(number);self.wait(lambda s:'> '+number in s,'choice echo')
        self.write(b'\r')
    def text(self,label,value):
        self.wait(lambda s:label in s and 'Page ' in s,label)
        self.write(value);self.wait(lambda s:'> '+value in s,'text echo')
        self.write(b'\r')
    def stop(self):
        if self.proc.poll() is None:self.proc.send_signal(signal.SIGTERM)
        end=time.monotonic()+15
        while self.proc.poll() is None and time.monotonic()<end:self.poll()
        if self.proc.poll() is None:self.proc.kill()
        code=self.proc.wait(timeout=3);self.poll(0)
        state={'exitCode':code,'termiosRestored':termios.tcgetattr(self.slave)==self.original,
               'modeRestored':self.mode==2}
        (EVIDENCE/'session.raw').write_bytes(self.raw)
        (EVIDENCE/'session.screen.txt').write_text(screen(self.raw))
        os.close(self.master);os.close(self.slave)
        return state

def binding(directory):
    run=subprocess.run([NODE,CLI,'machine','center','health','--state-dir',directory],
                       stdin=subprocess.DEVNULL,capture_output=True,timeout=15)
    out=run.stdout.decode('utf8','replace')
    if out.count('\n')!=1:raise AssertionError('machine health not one JSON record')
    return {'exitCode':run.returncode,'report':json.loads(out)}

with tempfile.TemporaryDirectory(prefix='omne-qa-revision-',dir=os.path.realpath('/tmp')) as root:
    root=os.path.realpath(root);directory=os.path.join(root,'state')
    server=subprocess.Popen([NODE,str(FIXTURE),root,str(EVIDENCE.resolve())],
                            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    if not select.select([server.stdout],[],[],55)[0]:raise AssertionError('center readiness timeout')
    ready=json.loads(server.stdout.readline());endpoint,ca=ready['endpoint'],ready['ca']
    peer=Peer(directory)
    outcome={}
    try:
        peer.wait(lambda s:'Connection and login' in s and 'Center configure' in s,'setup menu')
        peer.choose('Center configure')
        peer.text('Center HTTPS address',endpoint)
        peer.wait(lambda s:'Certificate verification' in s and 'system-ca' in s,'trust choice')
        peer.choose('ca-file')
        peer.wait(lambda s:'CA certificate file' in s,'CA file field')
        peer.size(100,50000)
        # Drain the large field frame before submitting; then the next large
        # frame is known to be the CG Preview, not an earlier screen.
        peer.wait(lambda s:'CA certificate file' in s and 'Page 1/1' in s and
                  'Ctrl+C: exit' in s and len(peer.raw)>100000,'large CA field frame',25)
        # The typed-field redraw is also enormous. Observe its completion
        # before Enter so the later backlog belongs to the preview revision.
        typed_start=len(peer.raw)
        peer.write(ca)
        peer.wait(lambda s:'> '+ca in s and len(peer.raw)-typed_start>140000,
                  'large typed CA field frame delivered',25)
        peer.write(b'\r')
        baseline=binding(directory)
        preview_start=len(peer.raw)
        # First finish the initial preview. A resize now creates a different
        # revision; its huge new frame is the one deliberately backpressured.
        peer.wait(lambda s:'Confirm: Center configure' in s and 'Page 1/1' in s and
                  len(peer.raw)-preview_start>140000,
                  'initial large preview delivered',25)
        frames_before=bytes(peer.raw).count(b'\x1b[H\x1b[2J')
        peer.size(100,60000)
        redraw_start=len(peer.raw)
        peer.wait(lambda s:'Confirm: Center configure' in s and
                  bytes(peer.raw).count(b'\x1b[H\x1b[2J')>frames_before,
                  'new large preview began',maxread=4096)
        began=len(peer.raw)-redraw_start
        # macOS FIONREAD reports zero on a PTY master even while select says
        # readable. Predicate readiness proves there are still unread bytes;
        # do not use that ioctl as a byte-count oracle.
        if not select.select([peer.master],[],[],5)[0]:
            raise AssertionError('new preview did not enter PTY backlog')
        peer.write(b'2\r')
        try:
            peer.proc.wait(timeout=.3);stayed=False
        except subprocess.TimeoutExpired:stayed=True
        mode_held=peer.mode==1 and termios.tcgetattr(peer.slave)!=peer.original
        frames_before=bytes(peer.raw).count(b'\x1b[H\x1b[2J')
        peer.size(100,40)
        resumed=peer.wait(lambda s:'Confirm: Center configure' in s and 'Page 1/1' in s and
                          'Enter: continue' in s and
                          bytes(peer.raw).count(b'\x1b[H\x1b[2J')>frames_before,
                          'new small preview delivered',30)
        after_old=binding(directory)
        old_inert=after_old['report']['admission']==baseline['report']['admission']
        match=re.search(r'(?m)^> (.*?)\s*$',resumed)
        retained_input=match.group(1).strip() if match else '<missing>'
        # The old key may remain as an unsubmitted field draft across resize.
        # Only a new Enter after the complete small frame can confirm it.
        if retained_input=='2':peer.write(b'\r')
        elif retained_input=='':peer.choose('Confirm this operation')
        else:raise AssertionError('unexpected retained input: '+retained_input)
        peer.wait(lambda s:'Center configure — exit status' in s,'configure result')
        peer.write(b'\r')
        final=peer.stop();configured=binding(directory)
        new_acted=configured['report']['admission']!=baseline['report']['admission']
        passed=stayed and mode_held and old_inert and new_acted and final['termiosRestored'] and \
               final['modeRestored'] and final['exitCode']==0
        outcome={'result':'PASS' if passed else 'FAIL','oldPreviewStartedBytes':began,
                 'ptyReadableAtOldKey':True,'retainedDraftAfterResize':retained_input,
                 'stayedWhileBlocked':stayed,'modeHeldWhileBlocked':mode_held,
                 'oldConfirmationInert':old_inert,'freshConfirmationActed':new_acted,
                 'baseline':baseline,'afterOld':after_old,'afterFresh':configured,'terminal':final}
    except Exception as error:
        outcome={'result':'FAIL','error':repr(error)}
        if peer.proc.poll() is None:peer.proc.kill();peer.proc.wait()
        (EVIDENCE/'unfinished.raw').write_bytes(peer.raw)
        os.close(peer.master);os.close(peer.slave)
    server.send_signal(signal.SIGTERM)
    try:server.wait(timeout=45)
    except subprocess.TimeoutExpired:server.kill();server.wait()
    (EVIDENCE/'fixture.stderr.raw').write_text(server.stderr.read())
    (EVIDENCE/'result.json').write_text(json.dumps(outcome,indent=2)+'\n')
    print(outcome['result'],json.dumps({k:v for k,v in outcome.items() if k not in ('baseline','afterOld','afterFresh')}))
    sys.exit(0 if outcome['result']=='PASS' else 1)
