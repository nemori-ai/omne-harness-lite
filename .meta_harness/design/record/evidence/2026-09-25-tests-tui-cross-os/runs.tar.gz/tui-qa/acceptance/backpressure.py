#!/usr/bin/env python3
"""CQ2 S7/S8/S10 PTY: resize with retained field, then actual OS write backpressure.

Usage: backpressure.py NODE CLI EVIDENCE_DIR. The PTY peer scripts DECRQM,
not an actual XTerm. The 300 ms blocked-read check is a bounded observation
window after a proven large frame has started, not an output-drain deadline.
"""
import errno
import fcntl
import json
import os
from pathlib import Path
import pty
import re
import select
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time

NODE, CLI, EVIDENCE = sys.argv[1:4]
EVIDENCE = Path(EVIDENCE)
EVIDENCE.mkdir(parents=True, exist_ok=True)
CONTROL = re.compile(rb'\x1b\[\?2004(?:\$p|h|l)')
results = []

def visible(raw):
    data = bytes(raw).split(b'\x1b[2J')[-1]
    data = re.sub(rb'\x1b\[[0-9;?]*[ -/]*[@-~]', b'', data)
    return data.decode('utf-8','replace').replace('\r','')

class Session:
    def __init__(self, work, rows):
        self.master, self.slave = pty.openpty()
        self.resize(100, rows, False)
        self.original = termios.tcgetattr(self.slave)
        self.proc = subprocess.Popen(
            [NODE, CLI, 'tui', '--terminal-profile','xterm-379',
             '--state-dir',os.path.join(work,'state'),'--setup'],
            stdin=self.slave,stdout=self.slave,stderr=self.slave,start_new_session=True,
            env={**os.environ,'TERM':'xterm','LC_ALL':'en_US.UTF-8'},
        )
        self.raw=bytearray();self.scan=0;self.mode=2;self.queries=0
    def resize(self, columns, rows, notify=True):
        fcntl.ioctl(self.slave,termios.TIOCSWINSZ,struct.pack('HHHH',rows,columns,0,0))
        if notify:self.proc.send_signal(signal.SIGWINCH)
    def pump(self, timeout=.05):
        ready,_,_=select.select([self.master],[],[],timeout)
        if ready:
            try:chunk=os.read(self.master,65536)
            except OSError as error:
                if error.errno != errno.EIO:raise
                chunk=b''
            if chunk:
                self.raw.extend(chunk)
                for found in CONTROL.finditer(self.raw,max(0,self.scan-12)):
                    if found.end()<=self.scan:continue
                    token=found.group()
                    if token.endswith(b'h'):self.mode=1
                    elif token.endswith(b'l'):self.mode=2
                    else:
                        self.queries+=1
                        os.write(self.master,b'\x1b[?2004;'+str(self.mode).encode()+b'$y')
                    self.scan=found.end()
                if len(self.raw)>3_000_000:raise AssertionError('unbounded terminal output')
        return visible(self.raw)
    def until(self,condition,label,seconds=15):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            text=self.pump()
            if condition(text):return text
            if self.proc.poll() is not None:
                raise AssertionError(f'exited before {label}: {self.proc.returncode}: {text[-500:]}')
        raise AssertionError(f'timeout {label}: {visible(self.raw)[-500:]}')
    def close(self,name):
        try:
            if self.proc.poll() is None:
                self.proc.send_signal(signal.SIGTERM)
            end=time.monotonic()+15
            while self.proc.poll() is None and time.monotonic()<end:self.pump()
            timeout=self.proc.poll() is None
            if timeout:self.proc.kill()
            code=self.proc.wait(timeout=3)
            self.pump(0)
            record={
                'case':name,'exitCode':code,'timedOut':timeout,
                'termiosRestored':termios.tcgetattr(self.slave)==self.original,
                'mode2004Restored':self.mode==2,'modeQueries':self.queries,
                'rawLength':len(self.raw),
            }
            (EVIDENCE/f'{name}.raw').write_bytes(self.raw)
            (EVIDENCE/f'{name}.screen.txt').write_text(visible(self.raw))
            return record
        finally:
            if self.proc.poll() is None:self.proc.kill();self.proc.wait()
            os.close(self.master);os.close(self.slave)

with tempfile.TemporaryDirectory(prefix='omne-qa-resize-',dir=os.path.realpath('/tmp')) as work:
    session=Session(work,40)
    try:
        menu=session.until(lambda s:'Connection and login' in s and '1. Exit' in s,'setup menu')
        session.pump(0)
        os.write(session.master,b'4')
        typed=session.until(lambda s:'> 4' in s,'typed pending choice')
        session.resize(40,10)
        too_small=session.until(lambda s:'Window too small' in s,'too-small pause')
        os.write(session.master,b'\r')
        # Wait for a redraw after the ignored Enter by observing a restored frame.
        session.resize(100,40)
        resumed=session.until(lambda s:'Connection and login' in s and '> 4' in s,
                              'restored field and identity')
        retained='Center: unknown' in resumed and 'Account: unknown' in resumed and \
                 'Organization: unknown' in resumed and 'Connection and login' in resumed
        record=session.close('resize')
        passed=retained and record['exitCode']==2 and record['termiosRestored'] and \
               record['mode2004Restored'] and not record['timedOut']
        record.update({'result':'PASS' if passed else 'FAIL','fieldRetained':'> 4' in resumed,
                       'smallNotice':'Window too small' in too_small,'identityRestored':retained})
        results.append(record)
        (EVIDENCE/'resize.json').write_text(json.dumps(record,indent=2)+'\n')
    except Exception as error:
        results.append({'case':'resize','result':'FAIL','error':repr(error)})
        if session.proc.poll() is None:session.proc.kill();session.proc.wait()
        (EVIDENCE/'resize.raw').write_bytes(session.raw)
        os.close(session.master);os.close(session.slave)

with tempfile.TemporaryDirectory(prefix='omne-qa-backpressure-',dir=os.path.realpath('/tmp')) as work:
    session=Session(work,50000)
    try:
        session.until(lambda s:b'\x1b[2J' in session.raw and session.queries>=2,
                      'large frame began after 2004 enabled')
        began=len(session.raw)
        session.proc.send_signal(signal.SIGTERM)
        try:
            session.proc.wait(timeout=.3)
            stayed=False
        except subprocess.TimeoutExpired:
            stayed=True
        raw_while_blocked=termios.tcgetattr(session.slave)!=session.original
        mode_while_blocked=session.mode==1
        # Resume actual PTY consumption; only then may the write callback run.
        record=session.close('backpressure')
        reset=bytes(session.raw).rfind(b'\x1b[?2004l')
        late_frame=reset>=0 and b'\x1b[2J' in session.raw[reset:]
        passed=stayed and raw_while_blocked and mode_while_blocked and \
               record['exitCode']==2 and record['termiosRestored'] and \
               record['mode2004Restored'] and not late_frame and not record['timedOut']
        record.update({'result':'PASS' if passed else 'FAIL',
                       'largeFrameStartedBytes':began,'stayedWhileReadPaused':stayed,
                       'rawModeWhileBlocked':raw_while_blocked,
                       'mode2004WhileBlocked':mode_while_blocked,
                       'lateFrameAfterRestore':late_frame})
        results.append(record)
        (EVIDENCE/'backpressure.json').write_text(json.dumps(record,indent=2)+'\n')
    except Exception as error:
        results.append({'case':'backpressure','result':'FAIL','error':repr(error)})
        if session.proc.poll() is None:session.proc.kill();session.proc.wait()
        (EVIDENCE/'backpressure.raw').write_bytes(session.raw)
        os.close(session.master);os.close(session.slave)

(EVIDENCE/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
for item in results:print(item['case'],item['result'],json.dumps(item))
passed=all(item['result']=='PASS' for item in results)
print('PASS' if passed else 'FAIL','CQ2 resize/backpressure',sum(x['result']=='PASS' for x in results),'/',len(results))
sys.exit(0 if passed else 1)
