# D051 独立验收矩阵（预先写定）

被测制品：`tmp/production-cli-onboarding/omne-cli-d051-r1.tar.gz`，BUILD_ID `c4d55a5635b39ac5f22bf8409ebd8bbb40b3242bee226e8f1861c69fcb033d8e`，搬离仓库解包 `/private/tmp/omne-cli-d051-pj4fgj0y/app`。冻结标准：CQ2 v2 S1–12，CG2 v2；D051 只采用 `xterm-379` profile，完整 macOS/IME 验证仍是门槛。终端模拟答复的 PTY 不是 XTerm。

| ID | 标准 / 可观察触发→结果 | 场景 | oracle 与证据层 |
|---|---|---|---|
| Q01 | CQ2 S2/S11：非法调用或非TTY→退出2、稳定诊断、无状态副作用；帮助纯输出 | `smoke.py` | 原始stdout/stderr/退出码、状态目录不存在 |
| Q02 | CQ2 S3/S9：`--setup` 只有一次根级动作→结算后退出；不得在本进程自动进入治理use | `journey.py setup-login` | 真实中心请求/机读登录状态、PTY原始流及屏幕文本 |
| Q03 | CQ2 S3/S4/S8：治理进入时固定当前捕获身份，现读S36/S57/S60，身份完整且空/不可得有区别 | `journey.py governance` | 真实中心机读事实与TUI屏幕文本、原始流 |
| Q04 | CQ2 S5/S6/S8：写预览全部页面实际可见前确认无效；明确确认后才发一次目标 | `journey.py governance` | 伪终端屏幕页码与真实中心目标记录/CLI结果，按条件等待 |
| Q05 | CQ2 S3/S6/S9：另一进程改本地选择，既有TUI use保留原账号；报告与CLI事实一致 | `journey.py fixed-use` | TUI报告、独立CLI machine报告、中心记录 |
| Q06 | CQ2 S7/S10：未完粘贴+信号不会提前还终端，真尾/EOF后才恢复；正常/信号恢复termios和2004 | `lifecycle.py` | PTY原始模式问答、termios前后、进程退出 |
| Q07 | CQ2 S7/S8/S10：背压时旧帧/按键不放行未显示预览；关闭等已提交写完成且无迟到写 | `backpressure.py`验证关闭写屏障；旧修订确认另验 | PTY慢读/大帧原始字节、退出/模式序列；中心目标计数尚缺 |
| Q08 | CQ2 S7/S8：宽字符/组合字符及resize保留身份和字段；不溢出 | `backpressure.py`验证缩放字段保留；宽字符另验 | 两尺寸屏幕文本；单元属性/真实XTerm另验 |
| Q09 | CQ2 S1/S9/S11：机读CQ1不混TUI提示，Schema合法；相同动作事实一致 | `smoke.py`, `journey.py` | machine JSON单行、TUI报告、退出码 |
| Q10 | D051真实支持门槛：XTerm379普通粘贴、两终端/两尺寸、macOS GUI/IME、强杀收场 | 待真实模拟器设施 | 实际终端日志/录像；当前不能由PTY代理通过 |

在固定制品运行前记录脚本及标准哈希。每个场景独立记录失败与重试，最多三次；失败不得靠改断言转绿。脚本按屏幕/机读谓词等待，超时只是失败证据。单独列出替身边界：PTY脚本只模拟终端模式答复，真实中心进程及TLS不是替身。
