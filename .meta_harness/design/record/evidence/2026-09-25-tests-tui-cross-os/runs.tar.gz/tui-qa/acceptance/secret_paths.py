#!/usr/bin/env python3
"""CQ2 S5/S6/S9 protected files: actual TUI login/change against real center.

Usage: secret_paths.py NODE CLI EVIDENCE_DIR. Oracle: independent machine CLI
observes resulting login identity and credential replacement; raw PTY and center
records are scanned for exact secret canaries.
"""
import errno
import fcntl
import json
import os
from pathlib import Path
import pty
import re
import select
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time

NODE,CLI,EVIDENCE=sys.argv[1:4]
EVIDENCE=Path(EVIDENCE);EVIDENCE.mkdir(parents=True,exist_ok=True)
FIXTURE=Path(__file__).with_name('center-fixture.mjs')
CONTROL=re.compile(rb'\x1b\[\?2004(?:\$p|h|l)')
results=[];cli_records=[]
def clean(data):
    data=re.sub(rb'\x1b\[[0-9;?]*[ -/]*[@-~]',b'',bytes(data))
    return data.decode('utf8','replace').replace('\r','')
def screen(raw):return clean(bytes(raw).split(b'\x1b[2J')[-1])
class Peer:
    def __init__(self,directory,setup=False):
        self.master,self.slave=pty.openpty()
        fcntl.ioctl(self.slave,termios.TIOCSWINSZ,struct.pack('HHHH',100,120,0,0))
        self.original=termios.tcgetattr(self.slave)
        self.proc=subprocess.Popen([NODE,CLI,'tui','--terminal-profile','xterm-379',
                '--state-dir',directory,*(['--setup'] if setup else [])],
                stdin=self.slave,stdout=self.slave,stderr=self.slave,start_new_session=True,
                env={**os.environ,'TERM':'xterm','LC_ALL':'en_US.UTF-8'})
        self.raw=bytearray();self.pos=0;self.mode=2;self.closed=False
    def poll(self,t=.03):
        ready,_,_=select.select([self.master],[],[],t)
        if ready:
            try:chunk=os.read(self.master,65536)
            except OSError as error:
                if error.errno!=errno.EIO:raise
                chunk=b''
            if chunk:
                self.raw.extend(chunk)
                for hit in CONTROL.finditer(self.raw,max(0,self.pos-12)):
                    if hit.end()<=self.pos:continue
                    token=hit.group()
                    if token.endswith(b'h'):self.mode=1
                    elif token.endswith(b'l'):self.mode=2
                    else:os.write(self.master,b'\x1b[?2004;'+str(self.mode).encode()+b'$y')
                    self.pos=hit.end()
                if len(self.raw)>5_000_000:raise AssertionError('unbounded output')
        return screen(self.raw)
    def wait(self,predicate,label,seconds=15):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            shown=self.poll()
            if predicate(shown):return shown
            if self.proc.poll() is not None:raise AssertionError(f'exited before {label}: {self.proc.returncode}: {shown[-500:]}')
        raise AssertionError(f'timeout {label}: {screen(self.raw)[-500:]}')
    def write(self,text):os.write(self.master,text if isinstance(text,bytes) else text.encode())
    def pages(self):
        shown=self.wait(lambda s:re.search(r'Page \d+/\d+',s) is not None,'page marker')
        all_pages=[]
        while True:
            at,total=map(int,re.search(r'Page (\d+)/(\d+)',shown).groups())
            all_pages.append(shown)
            if at==total:return all_pages
            self.write(b'\x1b[6~');shown=self.wait(lambda s:f'Page {at+1}/{total}' in s,'next page')
    def choose(self,label):
        all_pages='\n'.join(self.pages())
        found=re.search(r'(?m)^(\d+)\. '+re.escape(label)+r'$',all_pages)
        if not found:raise AssertionError('choice absent: '+label)
        number=found.group(1)
        self.write(number);self.wait(lambda s:'> '+number in s,'choice echo');self.write(b'\r')
    def text(self,label,value):
        self.wait(lambda s:label in s and 'Page ' in s,label)
        self.write(value);self.wait(lambda s:'> '+value in s,'field echo');self.write(b'\r')
    def report(self,label):
        self.wait(lambda s:label+' — exit status' in s and 'Page ' in s,'report '+label)
        self.pages();self.write(b'\r')
    def finish(self,label):
        if self.closed:return None
        if self.proc.poll() is None:self.proc.send_signal(signal.SIGTERM)
        deadline=time.monotonic()+15
        while self.proc.poll() is None and time.monotonic()<deadline:self.poll()
        if self.proc.poll() is None:self.proc.kill()
        code=self.proc.wait(timeout=3);self.poll(0)
        state={'exitCode':code,'modeRestored':self.mode==2,
               'termiosRestored':termios.tcgetattr(self.slave)==self.original}
        (EVIDENCE/f'{label}.raw').write_bytes(self.raw)
        (EVIDENCE/f'{label}.json').write_text(json.dumps(state,indent=2)+'\n')
        os.close(self.master);os.close(self.slave);self.closed=True
        return state
def cli(*args,code=0):
    run=subprocess.run([NODE,CLI,'machine',*args],stdin=subprocess.DEVNULL,capture_output=True,timeout=45)
    out=run.stdout.decode('utf8','replace');err=run.stderr.decode('utf8','replace')
    if run.returncode!=code or out.count('\n')!=1:
        raise AssertionError(f'machine {args[:2]} exit {run.returncode}, expected {code}: {out[-500:]} {err[-400:]}')
    report=json.loads(out)
    cli_records.append({'command':list(args[:2]),'exitCode':run.returncode,'report':report,'stderr':err})
    return report
def value(report):return report['remote']['reply']['reply']['result']
with tempfile.TemporaryDirectory(prefix='omne-qa-secret-',dir=os.path.realpath('/tmp')) as root:
    root=os.path.realpath(root)
    server=subprocess.Popen([NODE,str(FIXTURE),root,str(EVIDENCE.resolve())],stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    peers=[]
    try:
        if not select.select([server.stdout],[],[],55)[0]:raise AssertionError('center readiness timeout')
        ready=json.loads(server.stdout.readline());endpoint,ca=ready['endpoint'],ready['ca']
        old='QA-OLD-CREDENTIAL-CANARY-2026';new='QA-NEW-CREDENTIAL-CANARY-2026'
        def secret(name,text,mode):
            path=os.path.join(root,name);Path(path).write_text(text);os.chmod(path,mode);return path
        oldfile=secret('old-credential',old,0o600)
        newfile=secret('new-credential',new,0o600)
        badfile=secret('bad-credential',old,0o644)
        seed=os.path.join(root,'seed');client=os.path.join(root,'client');bad=os.path.join(root,'bad-client')
        for directory in (seed,client,bad):
            cli('center','configure','--state-dir',directory,'--endpoint',endpoint,'--ca-file',ca)
        cli('register','--state-dir',seed,'--login-identifier','qa-secret-user','--credential-file',oldfile)
        # The seed isn't logged in yet; acquire a machine reference identity.
        cli('login','--state-dir',seed,'--login-identifier','qa-secret-user','--credential-file',oldfile)
        alice=value(cli('tenant','current','--state-dir',seed,'--refresh'))['account']

        login=Peer(client,True);peers.append(login)
        login.wait(lambda s:'Connection and login' in s and '3. Login' in s,'setup menu')
        login.choose('Login')
        login.text('Login identifier','qa-secret-user')
        login.text('Credential file',oldfile)
        login.wait(lambda s:'Confirm: Login' in s and 'Page ' in s,'login preview')
        login.choose('Confirm this operation')
        login.report('Login')
        login_state=login.finish('login')
        selected=value(cli('tenant','current','--state-dir',client,'--refresh'))['account']
        no_secret=old not in bytes(login.raw).decode('utf8','replace')
        success=login_state['exitCode']==0 and selected==alice and no_secret and \
                login_state['modeRestored'] and login_state['termiosRestored']
        results.append({'id':'login-protected-file','result':'PASS' if success else 'FAIL',
                        'tuiExit':login_state['exitCode'],'selectedAccountMatchesCLI':selected==alice,
                        'secretAbsent':no_secret})

        invalid=Peer(bad,True);peers.append(invalid)
        invalid.wait(lambda s:'Connection and login' in s and '3. Login' in s,'bad setup menu')
        invalid.choose('Login')
        invalid.text('Login identifier','qa-secret-user')
        invalid.text('Credential file',badfile)
        invalid.wait(lambda s:'Confirm: Login' in s and 'Page ' in s,'bad preview')
        invalid.choose('Confirm this operation')
        invalid.report('Login')
        invalid_state=invalid.finish('bad-login')
        unselected=cli('tenant','current','--state-dir',bad,'--refresh',code=4)
        bad_ok=invalid_state['exitCode']==2 and 'secret-permissions' in bytes(invalid.raw).decode('utf8','replace') and \
               unselected['admission']['reason']=='not-logged-in'
        results.append({'id':'bad-secret-permissions','result':'PASS' if bad_ok else 'FAIL',
                        'tuiExit':invalid_state['exitCode'],'unselected':unselected['admission']['reason'],
                        'stableDiagnostic':'secret-permissions' in bytes(invalid.raw).decode('utf8','replace')})

        change=Peer(client);peers.append(change)
        for title in ('Tenant current','Invitation inbox','Affiliation inbox'):change.report(title)
        change.wait(lambda s:'Governance' in s and 'Credential change' in s,'governance menu')
        change.choose('Credential change')
        change.text('Current credential file',oldfile)
        change.text('New credential file',newfile)
        change.wait(lambda s:'Confirm: Credential change' in s and 'Page ' in s,'change preview')
        change.choose('Confirm this operation')
        change.report('Credential change')
        change_state=change.finish('credential-change')
        old_rejected=cli('login','--state-dir',seed,'--login-identifier','qa-secret-user',
                         '--credential-file',oldfile,code=4)
        cli('login','--state-dir',seed,'--login-identifier','qa-secret-user','--credential-file',newfile)
        new_account=value(cli('tenant','current','--state-dir',seed,'--refresh'))['account']
        change_raw=bytes(change.raw).decode('utf8','replace')
        no_secret=old not in change_raw and new not in change_raw
        changed=change_state['exitCode']==4 and no_secret and new_account==alice and \
                old_rejected['remote']['status']=='rejected'
        results.append({'id':'credential-change-all-old-logins','result':'PASS' if changed else 'FAIL',
                        'tuiExit':change_state['exitCode'],'oldRejected':old_rejected['remote']['status'],
                        'newLoginAccountMatches':new_account==alice,'secretAbsent':no_secret})
    except Exception as error:
        results.append({'id':'scenario-error','result':'FAIL','error':repr(error)})
    finally:
        for index,peer in enumerate(peers):
            if not peer.closed:peer.finish('unfinished-'+str(index))
        server.send_signal(signal.SIGTERM)
        try:server.wait(timeout=45)
        except subprocess.TimeoutExpired:server.kill();server.wait()
        (EVIDENCE/'fixture.stderr.raw').write_text(server.stderr.read())
        (EVIDENCE/'machine.json').write_text(json.dumps(cli_records,indent=2)+'\n')
(EVIDENCE/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'status':'PASS' if len(results)==3 and all(x['result']=='PASS' for x in results) else 'FAIL',
                  'results':results}))
sys.exit(0 if len(results)==3 and all(x['result']=='PASS' for x in results) else 1)
