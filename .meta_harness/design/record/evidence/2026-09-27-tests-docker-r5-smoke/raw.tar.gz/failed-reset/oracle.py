#!/usr/bin/env python3
"""Independent, fail-closed reading of one R5 helper smoke run's raw outputs."""

import argparse
import json
import pathlib
import re
from datetime import datetime, timezone

HEX64 = re.compile(r"[0-9a-f]{64}\Z")
IMAGE = re.compile(r"sha256:[0-9a-f]{64}\Z")
FILE_NAME = re.compile(r"[0-9a-f]{32}\.omne-backup\Z")


def demand(value, message):
    if not value:
        raise ValueError(message)


def raw(run, commands, label, stream="stdout"):
    item = commands[label]
    path = run / item[stream]
    demand(path.is_file() and path.parent == run / "raw", f"missing raw {label}/{stream}")
    return path.read_bytes()


def one_json(data, label):
    demand(data.endswith(b"\n") and data.count(b"\n") == 1, f"{label}: one JSON+LF required")
    value = json.loads(data[:-1].decode("utf-8", "strict"))
    demand(isinstance(value, dict), f"{label}: object required")
    return value


def command(run, commands, label, code=0):
    item = commands[label]
    demand(item["returncode"] == code and not item["observation_expired"],
           f"{label}: actual command exit {code} required")
    return one_json(raw(run, commands, label), label)


def inspect_array(run, commands, label, container_id):
    item = commands[label]
    demand(item["returncode"] == 0 and not item["observation_expired"], f"{label}: inspect failed")
    data = json.loads(raw(run, commands, label).decode("utf-8", "strict"))
    demand(isinstance(data, list) and len(data) == 1 and data[0].get("Id") == container_id,
           f"{label}: wrong container ID")
    return data[0]


def metadata(value):
    demand(isinstance(value, dict) and set(value) == {
        "format", "centerId", "sourceBuildId", "migrationNames", "startedAt",
        "finishedAt", "byteLength", "sha256"}, "metadata shape")
    demand(value["format"] == "omne-center-backup/1", "backup format")
    demand(isinstance(value["byteLength"], int) and 1 <= value["byteLength"] <= 1073741824,
           "backup length")
    demand(isinstance(value["sha256"], str) and HEX64.fullmatch(value["sha256"]), "backup digest")


def canonical_metadata(value):
    metadata(value)
    normalized = dict(value)
    for key in ("startedAt", "finishedAt"):
        instant = datetime.fromisoformat(value[key].replace("Z", "+00:00"))
        demand(instant.tzinfo is not None, f"{key}: timezone required")
        normalized[key] = instant.astimezone(timezone.utc)
    demand(normalized["startedAt"] <= normalized["finishedAt"], "backup time order")
    return normalized


def service_state(run, commands, label):
    demand(commands[label]["returncode"] == 0, f"{label}: systemctl show failed")
    lines = raw(run, commands, label).decode("utf-8", "strict").splitlines()
    demand(all("=" in line for line in lines), f"{label}: malformed systemctl output")
    values = dict(line.split("=", 1) for line in lines)
    demand(len(values) == len(lines), f"{label}: duplicate systemctl property")
    return values


def timer_cell(run, commands, prefix, result, status):
    before_timer = service_state(run, commands, prefix + "-timer-before")
    after_timer = service_state(run, commands, prefix + "-timer-after")
    before_service = service_state(run, commands, prefix + "-service-before")
    after_service = service_state(run, commands, prefix + "-state")
    trigger = after_timer.get("LastTriggerUSec")
    demand(trigger not in (None, "", "n/a")
           and trigger != before_timer.get("LastTriggerUSec"), prefix + ": no timer trigger")
    start = int(after_service["ExecMainStartTimestampMonotonic"])
    end = int(after_service["ExecMainExitTimestampMonotonic"])
    prior = int(before_service["ExecMainStartTimestampMonotonic"])
    demand(start > prior and start > 0 and end >= start
           and after_service["ActiveState"] in ("inactive", "failed")
           and after_service["Result"] == result
           and after_service["ExecMainStatus"] == status,
           prefix + ": service did not actually finish as expected")
    return start


def check_mount_projection(actual, expected):
    mounts = actual["Mounts"]
    demand(isinstance(mounts, list) and len(mounts) == 2,
           "Docker inspect must report exactly the two bind mounts")
    by_destination = {mount["Destination"]: mount for mount in mounts}
    demand(len(by_destination) == 2
           and set(by_destination) == {"/state", "/secrets"},
           "actual bind destinations")
    state = by_destination["/state"]
    secrets = by_destination["/secrets"]
    demand(state["Type"] == "bind" and state["Source"] == expected["state"]
           and state["RW"] is True
           and secrets["Type"] == "bind" and secrets["Source"] == expected["secrets"]
           and secrets["RW"] is False, "actual bind sources and access")
    tmpfs = actual["HostConfig"]["Tmpfs"]
    path = "/run/omne-tenancy"
    demand(isinstance(tmpfs, dict) and set(tmpfs) == {path}
           and isinstance(tmpfs[path], str), "exactly one configured ops tmpfs")
    options = tmpfs[path].split(",")
    required = {"mode=0700", f'uid={expected["uid"]}', f'gid={expected["gid"]}',
                "nosuid", "nodev", "noexec"}
    demand(len(options) == 6 and set(options) == required,
           "exact six ops tmpfs options")


def evaluate(run):
    evidence = json.loads((run / "evidence.json").read_text())
    commands = {item["label"]: item for item in evidence["commands"]}
    demand(len(commands) == len(evidence["commands"]), "duplicate command label")
    expected = evidence["expected"]
    demand(IMAGE.fullmatch(expected["image_id"]), "expected image ID")
    demand(HEX64.fullmatch(expected["build_id"]), "expected BUILD_ID")
    demand(evidence["business_complete"] is True, "driver did not finish observations")
    order = [item["label"] for item in evidence["commands"]]
    stages = ("validate", "start", "inspect-running", "runtime-ops-tmpfs",
              "full-health", "backup", "backup-status", "verify",
              "restore", "restore-target-stat", "work-marker-stat",
              "work-marker-content", "restore-envelope-stat", "restore-envelope-hashes",
              "timer-running-state", "stop", "stop-exited",
              "timer-stopped-state", "center-events")
    demand(all(stage in commands for stage in stages)
           and [order.index(stage) for stage in stages] == sorted(order.index(stage) for stage in stages),
           "smoke stages absent or reordered")
    prefix = ["docker", "exec", "-e", f"DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock",
              expected["control"], "/usr/local/libexec/omne-center"]
    for label, action in (("validate", "validate"), ("start", "start"),
                          ("full-health", "full-health"), ("backup", "backup"),
                          ("backup-status", "backup-status"), ("verify", "verify"),
                          ("restore", "restore-isolated"), ("stop", "stop"),
                          ("stop-exited", "stop")):
        demand(commands[label]["argv"][:len(prefix) + 1] == [*prefix, action],
               f"{label}: helper command did not run in private Linux control")

    valid = command(run, commands, "validate")
    demand(valid == {"state": "deployment-structure-valid"}, "validate result")
    started = command(run, commands, "start")
    cid = started.get("containerId")
    demand(isinstance(cid, str) and HEX64.fullmatch(cid), "start ID")
    inspect_prefix = ["docker", "exec", expected["control"], "docker", "--host",
                      "unix:///opt/omne-private-docker/docker.sock", "inspect", cid]
    for label in ("inspect-running", "inspect-stopped", "inspect-after-exited-stop",
                  "inspect-after-timer"):
        demand(commands[label]["argv"] == inspect_prefix, f"{label}: wrong Engine target")
    demand(started.get("state") == "running" and started.get("health") == "healthy"
           and started.get("buildId") == expected["build_id"]
           and started.get("imageId") == expected["inner_image_id"], "start state/build/image")
    inode = [raw(run, commands, label).strip() for label in
             ("control-inode", "dind-inode", "app-inode")]
    demand(all(commands[label]["returncode"] == 0 for label in
               ("control-inode", "dind-inode", "app-inode"))
           and inode[0] == inode[1] == inode[2]
           and inode[0].endswith(f':{expected["uid"]}:{expected["gid"]}:700'.encode()),
           "shared Linux inode and ownership")
    demand(raw(run, commands, "read-view-marker").strip()
           == raw(run, commands, "app-view-marker").strip(), "cross-view marker")
    actual = inspect_array(run, commands, "inspect-running", cid)
    demand(actual["Image"] == expected["inner_image_id"], "running image ID")
    demand(actual["Config"]["User"] == f'{expected["uid"]}:{expected["gid"]}'
           and expected["uid"] > 0, "nonroot app UID/GID")
    demand(actual["Config"]["StopSignal"] == "SIGTERM"
           and actual["Config"]["StopTimeout"] == -1, "actual stop config")
    demand(actual["State"]["Running"] is True and actual["State"]["Pid"] > 0
           and actual["State"]["Health"]["Status"] == "healthy", "actual running health")
    labels = actual["Config"]["Labels"]
    demand(labels["ai.nemori.omne.project"] == expected["project"]
           and labels["ai.nemori.omne.service"] == "center"
           and labels["ai.nemori.omne.host-build-id"] == expected["build_id"], "center labels")
    check_mount_projection(actual, expected)
    probe_argv = commands["runtime-ops-tmpfs"]["argv"]
    demand(len(probe_argv) == 11
           and probe_argv[:10] == ["docker", "exec", expected["control"], "docker", "--host",
                                   "unix:///opt/omne-private-docker/docker.sock", "exec", cid,
                                   "node", "-e"], "runtime tmpfs probe provenance")
    observed_tmpfs = command(run, commands, "runtime-ops-tmpfs")
    demand(set(observed_tmpfs) == {"processUid", "processGid", "isDirectory", "uid",
                                   "gid", "mode", "mountCount", "filesystemType",
                                   "mountOptions"}
           and observed_tmpfs["processUid"] == expected["uid"]
           and observed_tmpfs["processGid"] == expected["gid"]
           and observed_tmpfs["isDirectory"] is True
           and observed_tmpfs["uid"] == expected["uid"]
           and observed_tmpfs["gid"] == expected["gid"]
           and observed_tmpfs["mode"] == 0o700
           and observed_tmpfs["mountCount"] == 1
           and observed_tmpfs["filesystemType"] == "tmpfs"
           and isinstance(observed_tmpfs["mountOptions"], str)
           and {"rw", "nosuid", "nodev", "noexec"}.issubset(
               set(observed_tmpfs["mountOptions"].split(","))),
           "running app must see private tmpfs with actual UID/GID/mode")

    health = command(run, commands, "full-health")
    for key in ("reachable", "storageReachable", "clockSane",
                "deploymentKeyPresent", "deploymentKeyComplete"):
        demand(health.get(key) is True, f"full-health {key}")
    demand(health.get("defectCount") == 0 and health.get("centerId"), "full-health identity/defects")

    backup = command(run, commands, "backup")
    demand(set(backup) == {"status", "backup"} and backup["status"] == "completed", "backup result")
    descriptor = backup["backup"]
    demand(set(descriptor) == {"fileName", "metadata"}
           and FILE_NAME.fullmatch(descriptor["fileName"]), "backup descriptor")
    backup_meta = canonical_metadata(descriptor["metadata"])
    demand(descriptor["metadata"]["centerId"] == health["centerId"], "backup center identity")
    demand(descriptor["metadata"]["sourceBuildId"] == expected["build_id"], "backup build identity")
    bstat = command(run, commands, "backup-status")
    latest = bstat.get("latest")
    demand(bstat.get("status") == "observed" and bstat.get("health") == "current"
           and isinstance(latest, dict) and latest.get("fileName") == descriptor["fileName"]
           and canonical_metadata(latest.get("metadata")) == backup_meta,
           "backup-status current descriptor")
    demand(isinstance(bstat.get("invalidCount"), int) and bstat["invalidCount"] == 0,
           "backup-status invalid count")
    source = expected["state"] + "/backups/" + descriptor["fileName"]
    demand(evidence["source"] == source, "source path must derive from backup")
    stat = raw(run, commands, "backup-file-stat").decode("ascii", "strict").strip().split(":")
    demand(commands["backup-file-stat"]["returncode"] == 0 and len(stat) == 5
           and stat[0] == "regular file" and stat[1:4] == [str(expected["uid"]),
           str(expected["gid"]), "600"] and int(stat[4]) > 0, "actual backup file")
    verified = command(run, commands, "verify")
    demand(set(verified) == {"status", "metadata", "businessOpen"}
           and verified["status"] == "verified" and verified["businessOpen"] is False
           and canonical_metadata(verified["metadata"]) == backup_meta, "verify result")
    restored = command(run, commands, "restore")
    demand(set(restored) == {"status", "metadata", "targetLocation", "businessOpen"}
           and restored["status"] == "restored-isolated"
           and canonical_metadata(restored["metadata"]) == backup_meta
           and restored["targetLocation"] == expected["target_in_container"]
           and restored["businessOpen"] is False, "restore result")
    target_stat = raw(run, commands, "restore-target-stat").decode("ascii", "strict").strip()
    demand(commands["restore-target-stat"]["returncode"] == 0
           and target_stat == f'directory:{expected["uid"]}:{expected["gid"]}:700',
           "actual private restore root")
    control = ["docker", "exec", expected["control"]]
    demand(expected["work"] == expected["state"] + "/offline-work/" + expected["project"],
           "isolated work root must derive from the state root and exact project")
    marker = expected["work"] + "/.omne-isolated"
    demand(commands["work-marker-stat"]["argv"] ==
           [*control, "stat", "-c", "%F:%u:%g:%a", marker]
           and commands["work-marker-content"]["argv"] == [*control, "cat", marker],
           "work marker must be read from the actual isolated work root")
    demand(commands["work-marker-stat"]["returncode"] == 0
           and raw(run, commands, "work-marker-stat") ==
           f'regular file:{expected["uid"]}:{expected["gid"]}:600\n'.encode(),
           "actual private work marker")
    demand(commands["work-marker-content"]["returncode"] == 0
           and raw(run, commands, "work-marker-content") == b"omne-isolated/1\n",
           "exact persisted work marker content")
    target_file = expected["target"] + "/data.omne-backup"
    demand(commands["restore-envelope-stat"]["argv"] ==
           [*control, "stat", "-c", "%F:%u:%g:%a:%s", target_file],
           "restore envelope path")
    envelope_stat = raw(run, commands, "restore-envelope-stat").decode("ascii", "strict")
    envelope_fields = envelope_stat.rstrip("\n").split(":")
    demand(commands["restore-envelope-stat"]["returncode"] == 0
           and envelope_stat.endswith("\n") and envelope_stat.count("\n") == 1
           and len(envelope_fields) == 5
           and envelope_fields[:4] == ["regular file", str(expected["uid"]),
                                        str(expected["gid"]), "600"]
           and int(envelope_fields[4]) > 0, "private restored envelope file")
    demand(commands["restore-envelope-hashes"]["argv"] ==
           [*control, "sha256sum", "--", source, target_file]
           and commands["restore-envelope-hashes"]["returncode"] == 0,
           "source-derived envelope hash command")
    hashes = raw(run, commands, "restore-envelope-hashes").decode("ascii", "strict").splitlines()
    parsed_hashes = [re.fullmatch(r"([0-9a-f]{64})  (.+)", line) for line in hashes]
    demand(len(parsed_hashes) == 2 and all(parsed_hashes)
           and [match.group(2) for match in parsed_hashes] == [source, target_file]
           and parsed_hashes[0].group(1) == parsed_hashes[1].group(1),
           "restored envelope must match the source bytes")

    running_timer_start = timer_cell(run, commands, "timer-running", "success", "0")
    stopped = command(run, commands, "stop")
    demand(stopped == {"state": "stopped", "containerId": cid,
                       "exitCode": 0, "clean": True}, "clean stop result")
    after = inspect_array(run, commands, "inspect-stopped", cid)
    demand(after["State"]["Status"] == "exited" and after["State"]["ExitCode"] == 0
           and after["State"]["Running"] is False, "actual stopped state")
    retry = command(run, commands, "stop-exited", code=1)
    demand(retry == {"state": "stop-intent-unconfirmed", "containerId": cid,
                     "exitCode": 0}, "initial exited intent")
    after_retry = inspect_array(run, commands, "inspect-after-exited-stop", cid)
    demand(after_retry["State"]["Status"] == "exited"
           and after_retry["State"]["StartedAt"] == after["State"]["StartedAt"],
           "exited stop must not start")
    stopped_service = service_state(run, commands, "timer-stopped-state")
    demand(stopped_service["ExecMainStatus"] != "0", "stopped timer must fail")
    stopped_timer_start = timer_cell(run, commands, "timer-stopped", "exit-code",
                                     stopped_service["ExecMainStatus"])
    demand(stopped_timer_start > running_timer_start, "stopped timer did not run later")
    final = inspect_array(run, commands, "inspect-after-timer", cid)
    demand(final["State"]["Status"] == "exited"
           and final["State"]["StartedAt"] == after["State"]["StartedAt"],
           "timer revived center")
    demand(commands["center-events"]["returncode"] == 0, "Engine events unavailable")
    event_argv = commands["center-events"]["argv"]
    demand(event_argv[:7] == ["docker", "exec", expected["control"], "docker", "--host",
                              "unix:///opt/omne-private-docker/docker.sock", "events"]
           and f"container={cid}" in event_argv, "Engine event provenance")
    events = [json.loads(line) for line in raw(run, commands, "center-events").splitlines()]
    demand(events and all(event.get("Actor", {}).get("ID") == cid for event in events),
           "wrong/missing event identity")
    kills = [event for event in events if event.get("Action") == "kill"]
    demand(len(kills) == 1 and kills[0].get("Actor", {}).get("Attributes", {}).get("signal")
           in ("15", "SIGTERM"), "exactly one observed TERM required")
    demand(not any(event.get("Action") == "start" for event in events),
           "unexpected center start after stop window")
    demand(evidence["cleanup_complete"] is True and evidence["cleanup_errors"] == [],
           "fixture cleanup incomplete")
    cleanup = {item["label"]: item for item in evidence["cleanup_commands"]}
    demand(len(cleanup) == len(evidence["cleanup_commands"])
           and all(item["returncode"] == 0 for item in cleanup.values()),
           "fixture cleanup command failed")
    for kind in ("container", "volume", "network"):
        label = "cleanup-final-list-" + kind
        demand(label in cleanup and raw(run, cleanup, label) == b"", f"exact-label {kind} remain")
    for group in ("project", "fixture"):
        label = f"cleanup-inner-{group}-final-list"
        demand(label in cleanup and raw(run, cleanup, label) == b"",
               f"private {group} containers remain")
    demand("cleanup-inner-all-final-list" in cleanup
           and raw(run, cleanup, "cleanup-inner-all-final-list") == b"",
           "private daemon still has containers")
    return {"status": "limited_pass", "containerId": cid, "checks": 25}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run", type=pathlib.Path)
    args = parser.parse_args()
    try:
        result = evaluate(args.run.resolve())
    except (KeyError, ValueError, TypeError, OSError, json.JSONDecodeError) as error:
        result = {"status": "failed_observation", "reason": str(error)}
    print(json.dumps(result, sort_keys=True))
    return 0 if result["status"] == "limited_pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
