# R5 helper smoke 测量器静态修订，未运行

本目录只含下一次 Linux 私有 Engine 纵向 smoke 的候选测量器。上一轮 `next-run/` 的 driver、oracle、root gate、argv、失败原始记录及 203 文件 hash 清单保持原样；该轮在 `restore-marker-stat` 对 `target/.omne-isolated` 的错误观测处停止，timer 与 stop 未执行。产品返回 `restored-isolated` 并不修正这次测量错误，也不能代替缺失的文件观察。本目录没有 root gate，不授权 Docker 执行；下一次制品身份、精确 argv 与 gate 仍由 root 独立核定。

## 本轮静态差异

- EC3 v3 S-57/58/59、tenancy-host `docker.md` §离线操作与已确认的 storage-sql `maintenance.md`「持久隔离与打开检查」将持久 `.omne-isolated` 放在本次 `--work-dir`：`state/offline-work/<project>/.omne-isolated`。driver 以只读 `stat`、`cat` 记录普通文件、实际 UID/GID、`0600` 和原字节；oracle 要求精确 `omne-isolated/1\n`，且从固定 state/project 推导 work 路径。工作根 marker 可能已由前一次 verify 建立，本 smoke 只证其在 restore 返回后仍存在，不据此声称由 restore 新建或已证明 fsync 耐久。
- tenancy governance-center-entry `maintenance.md`「离线verify/restore」规定 target 内 `data.omne-backup` 与本次输入封装同字节。保留旧 `target` 目录 `0700` 检查，新增目标普通文件 UID/GID、`0600`、非空的 `stat`，以及对由本次 backup fileName 推导的 source 和 target 的同一 `sha256sum --` 调用。oracle 要求两个完整路径和 64 位 digest 一致。`businessOpen:false`、metadata、result 状态和现有安全检查均保留。它不把封装文件当成可 serve 的 SQLite，也不要求 target marker。
- `fire_timer` 在观察 service 已到 `inactive/failed` 后，timer 仍 active 时先保存 service `Result`、`ExecMainStatus`、主进程起止时间、timer `LastTriggerUSec` 和 journal，再显式 stop timer。systemd v252 的 [Unit Garbage Collection](https://raw.githubusercontent.com/systemd/systemd/v252/man/systemd.unit.xml) 允许卸载 inactive 且无引用的 unit 并丢失执行结果；[timer 的 RemainAfterElapse](https://raw.githubusercontent.com/systemd/systemd/v252/man/systemd.timer.xml) 默认保留 elapsed timer，但不保证显式停止后仍保留 service 结果。这是避免依赖该生命周期的静态修正，上一轮尚未执行 timer，故无实机反例。`LastTriggerUSec` 必须变化、ExecMain 必须是新的实际启动与退出，oracle 判据未减。

## 余下路径静态走查

driver 的运行中 timer 路径仅在当前确切私有 project 的 `omne-center-backup@<project>.timer` 上 `start`；QA drop-in 设 `OnActiveSec=2s`，观测预算仍为 90 秒。它分别取启动前后 `LastTriggerUSec` 与 service `ExecMainStartTimestampMonotonic`，等待新触发、新启动及服务退出，再取最终 `Result=success`、`ExecMainStatus=0`。这里的 90 秒覆盖固定 systemd 252 `AccuracySec` 默认一分钟调度窗口，只是测量预算，不是产品 SLA。timer 对已停止中心的第二轮要求新的 trigger/start 和失败退出；其后再次 inspect 同一容器 ID，必须仍 `exited` 且 `StartedAt` 未变化。service unit 是 `backup --only-if-due`，不携带任何 start 命令；这些字段仍需实机原始输出证明。

正常 stop 先由 helper 接收运行中确切 ID，oracle 只接受 JSON `stopped`、相同 ID、`exitCode:0`、`clean:true`，再要求私有 Engine inspect 同一 ID 的 `exited/ExitCode=0`。第二次对初始 exited 状态 stop 必须非零并返回 `stop-intent-unconfirmed`，之后 `StartedAt` 不变；同一 ID 的 Engine events 要有恰一次 TERM kill 且无 start。D071 与 tenancy-host `docker.md` §R5 正常收场要求完整 wait 值与同 ID inspect 一致；该 helper 内部 wait 原始字节没有由本 smoke 单独采集，因此 JSON、Engine 状态和 TERM 是有限外部证据，长 IO、close error、caller 退出后本地等待客户端及并发仍属后续场景。当前工具不会把超时观察改称 stop 完成，fixture 的强制清理也不能覆盖业务 oracle。

## 离线结果与运行门

`PYTHONDONTWRITEBYTECODE=1 python3 -B self_test.py` 的合成正常样例及全部负例通过；本轮新增 wrong work path、缺 marker、错误内容/owner/mode、目标封装 owner/mode/字节不符，以及 final timer 取证先于显式 stop 的静态顺序检查。旧 created-inspect 形状、runtime tmpfs、stop、timer、cleanup 负例均保留。该测试只验证测量器识别这些反例，不是产品符合性证据。JS probe `node --check` 仅核语法。`checked_inputs` 将最终 driver/oracle、helper/Compose/unit/image/tool SHA、image ID、BUILD_ID、UID/GID、observe/timer budget 计入输入摘要；必须重新生成 root-reviewed gate。oracle 固定 read-only probe 的命令前缀，但末尾脚本文本依赖 driver SHA 和 gate 固定，这是明确的静态证据前提。
