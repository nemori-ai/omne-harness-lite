"""Root's read-only artifact checks; not a production builder or acceptance oracle."""
import hashlib
import json
import os
import pathlib
import stat
import subprocess
import sys
import tarfile

manifest_path = pathlib.Path(sys.argv[1]).resolve()
expected_manifest_hash = sys.argv[2]
hub = pathlib.Path(__file__).resolve().parents[2]
base = manifest_path.parent

def digest(path):
    with open(path, 'rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

assert digest(manifest_path) == expected_manifest_hash
m = json.loads(manifest_path.read_text())
assert m['source']['commit'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=hub, text=True).strip()
for path, expected in m['source']['inputFilesSha256'].items():
    assert digest(hub / path) == expected, path
for path, row in m['rawLogs'].items():
    assert digest(base / path) == row['sha256'], path
for row in m['deployFiles'].values():
    assert digest(hub / row['source']) == row['sourceSha256'] == row['packagedSha256']
    assert digest(base / row['packaged']) == row['packagedSha256']

result = {'manifestSha256': expected_manifest_hash, 'source': m['source']['commit'], 'archives': {}, 'images': {}}
for name, row in m['archives'].items():
    assert digest(row['path']) == row['sha256'], name
    assert digest(row['fullFileManifest']) == row['fullFileManifestSha256']
    root = base / (name + '-unpacked/app')
    assert (root / 'build-info.json').read_bytes() == pathlib.Path(row['fullFileManifest']).read_bytes()
    info = json.loads((root / 'build-info.json').read_text())
    assert info['node'] == '24.21.0' and info['pnpm'] == '10.28.1'
    assert info['format'] == row['format']
    entries = info['files']
    assert len(entries) == row['fileCount']
    expected_paths = {i['path'] for i in entries} | {'BUILD_ID', 'build-info.json'}
    assert len(expected_paths) == len(entries) + 2
    seen = set()
    for directory, dirs, files in os.walk(root, followlinks=False):
        for n in list(dirs) + files:
            p = pathlib.Path(directory) / n
            if p.is_symlink() or not p.is_dir():
                seen.add(str(p.relative_to(root)))
    assert seen == expected_paths, name
    for entry in entries:
        p = root / entry['path']
        assert p.resolve(strict=True).is_relative_to(root.resolve()), entry['path']
        mode = p.lstat().st_mode
        if entry['kind'] == 'file':
            assert stat.S_ISREG(mode) and digest(p) == entry['sha256'], entry['path']
        else:
            assert entry['kind'] == 'link' and stat.S_ISLNK(mode)
            assert os.readlink(p) == entry['target'] and not os.path.isabs(entry['target'])
    actual_build = hashlib.sha256(json.dumps(entries, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()
    assert actual_build == row['buildId'] == info['buildId']
    assert (root / 'BUILD_ID').read_text() == actual_build + '\n'
    # Compare the tar itself to the already checked unpacked tree; do not extract it.
    with tarfile.open(row['path']) as archive:
        archived = set()
        for item in archive:
            if item.isdir():
                continue
            assert item.name.startswith('app/')
            rel = item.name[4:]
            assert rel in expected_paths and rel not in archived
            archived.add(rel)
            p = root / rel
            if item.issym():
                assert p.is_symlink() and item.linkname == os.readlink(p)
            else:
                assert item.isfile() and not p.is_symlink()
                assert hashlib.file_digest(archive.extractfile(item), 'sha256').hexdigest() == digest(p)
        assert archived == expected_paths
    result['archives'][name] = {'buildId': actual_build, 'files': len(entries), 'sha256': row['sha256']}

for arch, row in m['images'].items():
    assert digest(row['archive']) == row['archiveSha256'], arch
    inspected = json.loads(subprocess.check_output(['docker', 'image', 'inspect', row['imageId']]))[0]
    assert inspected['Id'] == row['imageId'] and inspected['Architecture'] == arch and inspected['Os'] == 'linux'
    assert inspected['Config']['Labels']['ai.nemori.omne.host-build-id'] == m['archives']['host']['buildId'] == row['buildId']
    result['images'][arch] = {'id': inspected['Id'], 'sha256': row['archiveSha256'], 'architecture': arch}
result['scope'] = 'Root independent inventory, archive bytes and saved image hash/identity checks; no helper or business run.'
print(json.dumps(result, indent=2))
