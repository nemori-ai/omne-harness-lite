# 下一轮 R5 smoke 测量草稿，未运行

本目录是从已运行版 `r5-helper-prep/{driver,oracle,self_test}.py` 复制出的独立候选。最初草稿原件已封在 `revisions/v1/`，其静态清单仍可复核。旧运行工具、旧 `reviewed-gate.json`、旧 argv 与失败 run 均未改。**本草稿没有授权真实 Docker 运行**；root 须等待修复后的新 I3 制品，重新核精确 helper/镜像 hash 和本目录 driver/oracle，生成新 gate 与 argv 后才可单次放行。旧 gate 的 driver/oracle/input hash 不适用于本目录。

systemd 252 源文档 `tmp/next-iteration/docker-tmpfs-source/systemd-v252-timer.xml` SHA256 `d3a155942de499771e63a6be9ea3a13a88848624f565408a37c6affb50fafb90` 第 212～225 行写明 `AccuracySec=` 默认 **1min**，且 `OnActiveSec=` 目标时刻可能落在该精度窗口内。因此旧 30 秒 timer 观测预算不能覆盖默认调度窗。草稿把默认观测预算设 90 秒；显式 `--timer-observe-seconds 90` 仍应写入下一轮 argv。`checked_inputs` 将此值纳入 root gate 的输入哈希，30 与 90 秒的离线哈希对照已验证不同。产品 unit 与现有 QA `OnActiveSec=2s` drop-in 内容未改，oracle 仍要求真实 `LastTriggerUSec` 和新的 service 主进程起止事实；90 秒只是测量预算，不是产品 SLA。

已运行版 `inspect-running` 能在中心启动后保存原始 Docker inspect，但原 oracle 只核 `/state` bind，未核 `/run/omne-tenancy` 实际 tmpfs 或目录 UID/GID/mode。旧失败 run 停在 create 后、start 前，没有任何运行态 tmpfs 证据。固定 Moby29.1.3 的 `GetMountPoints` 只把 MountPoints 投到 `Mounts`，tmpfs 配置在 `HostConfig.Tmpfs`，不能要求 `Mounts` 有第三个 tmpfs 项。`real-created-mount-shape.json` 从旧失败 run 的原 inspect 只提取这两个数组/配置字段，带原件 SHA；离线测试确认该真实形状通过投影判据。本草稿明确要求 `Mounts` 恰有 `/state`、`/secrets` 两个 bind、确切 source/RW，`HostConfig.Tmpfs` 恰一个 `/run/omne-tenancy` key 且恰六个精确选项。

实际挂载仍须在启动后证明：草稿在 `inspect-running` 之后增加一条**应用自身 UID 下的只读** `docker exec <exact-id> node -e`，只从 `/proc/self/mountinfo` 和 `fs.statSync('/run/omne-tenancy')` 输出选定 JSON 字段。oracle 要求运行进程 UID/GID、恰一条该路径的 tmpfs mount、实际目录 owner 与 `0700`、挂载 `rw,nosuid,nodev,noexec`。它不打印完整 mountinfo、环境、PEM、密钥或业务正文。probe 只观察，不建文件、不修权限、不替产品兑现隔离。oracle 固定 exact-ID、私有 daemon、`node -e` 的 argv 前缀；最后脚本文本由 driver SHA/gate 绑定，oracle 不独立比对其文本，这是证据前提。

`PYTHONDONTWRITEBYTECODE=1 python3 -B self_test.py` 的正例与负例覆盖真实 created inspect 两 bind 形状、虚构第三项、错误 secrets source、额外 tmpfs option、UID 子串伪装，以及“配置存在但运行态未挂载”、错误文件系统类型、错误 UID/mode；原 stop/cleanup 负例继续有效。`node --check` 对 probe JS 语法通过。尚无 Linux 产品执行结果；具体运行态文件系统保证须下一轮原始输出支持。后续长 IO、取消和 daemon 场景不在此草稿。
