#!/usr/bin/env python3
"""Reviewed-only, one-run Linux control / private DinD R5 helper smoke.

This file is prepared for a later root-authorized run. Importing it does nothing.
"""

import argparse
import hashlib
import json
import pathlib
import re
import secrets
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone

HERE = pathlib.Path(__file__).resolve().parent
V0 = HERE.parent.parent / "v0c"
CONTROL = "omne-m0-v0-control-tools:20260926-fc30a6d4"
CONTROL_ID = "sha256:825773f9776113d54fb23a5de9511d5b6c7bc7550d891f7a3584bfe71c0795f6"
DIND = "docker:29.1.3-dind"
DIND_ID = "sha256:20cca7e2a7da287ded85087ce88d443a5347163eebf6a9ed0c27bc4cabe90ae7"
COMPOSE_SHA = "d26373b19e89160546d15407516cc59f453030d9bc5b43ba7faf16f7b4980137"
CLI_SHA = "544cf329807e30c9601652562a159b17179345146be0f8211bfe2ebd872eb880"
SOCKET = "unix:///opt/omne-private-docker/docker.sock"
ROOT = "/var/lib/omne-tenancy"
STATE = ROOT + "/state"
SECRETS = ROOT + "/secrets"
SETTINGS = ROOT + "/settings.env"
HELPER = "/usr/local/libexec/omne-center"
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
IMAGE = re.compile(r"sha256:[0-9a-f]{64}\Z")
OPS_TMPFS_PROBE = r"""
const fs = require('node:fs');
const path = '/run/omne-tenancy';
const matches = fs.readFileSync('/proc/self/mountinfo', 'utf8').trimEnd().split('\n')
  .map((line) => line.split(' - '))
  .filter((parts) => parts.length === 2 && parts[0].split(' ')[4] === path);
const stat = fs.statSync(path);
process.stdout.write(JSON.stringify({
  processUid: process.getuid(),
  processGid: process.getgid(),
  isDirectory: stat.isDirectory(),
  uid: stat.uid,
  gid: stat.gid,
  mode: stat.mode & 0o7777,
  mountCount: matches.length,
  filesystemType: matches.length === 1 ? matches[0][1].split(' ')[0] : null,
  mountOptions: matches.length === 1 ? matches[0][0].split(' ')[5] : null,
}) + '\n');
"""


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat()


def need(value, message):
    if not value:
        raise RuntimeError(message)


def parse_json_line(data, label):
    need(data.endswith(b"\n") and data.count(b"\n") == 1, f"{label}: one JSON+LF required")
    result = json.loads(data[:-1].decode("utf-8", "strict"))
    need(isinstance(result, dict), f"{label}: object required")
    return result


class Run:
    def __init__(self, args, inputs):
        self.args = args
        self.run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(4)
        self.run = HERE / "runs" / self.run_id
        self.run.mkdir(parents=True, mode=0o700, exist_ok=False)
        (self.run / "raw").mkdir(mode=0o700)
        self.frozen = self.run / "inputs"
        self.frozen.mkdir(mode=0o700)
        for name in ("omne-center", "compose.yaml", "compose.maintenance.yaml", "health.mjs",
                     "omne-center-backup@.service", "omne-center-backup@.timer", "oracle.py"):
            source = (args.helper_dir / name) if name != "oracle.py" else (HERE / name)
            target = self.frozen / name
            shutil.copyfile(source, target)
            key = {"omne-center": "helper", "compose.yaml": "compose",
                   "compose.maintenance.yaml": "maintenance_compose", "health.mjs": "health",
                   "omne-center-backup@.service": "service", "omne-center-backup@.timer": "timer",
                   "oracle.py": "oracle"}[name]
            need(sha(target) == inputs["sha256"][key], f"frozen {key} changed after review")
        gate_copy = self.frozen / "reviewed-gate.json"
        shutil.copyfile(args.reviewed_gate, gate_copy)
        gate = json.loads(gate_copy.read_text())
        payload = json.dumps(inputs, sort_keys=True, separators=(",", ":")).encode()
        need(gate.get("approved") is True and gate.get("reviewer") == "root"
             and gate.get("inputs_sha256") == hashlib.sha256(payload).hexdigest()
             and gate.get("driver_sha256") == inputs["sha256"]["driver"]
             and gate.get("oracle_sha256") == inputs["sha256"]["oracle"],
             "review gate changed after preflight")
        self.prefix = "omne-r5-" + self.run_id.lower().replace("t", "-").replace("z", "")
        self.label = "omne.r5.helper-prep=" + self.run_id
        self.control = self.prefix + "-control"
        self.dind = self.prefix + "-dind"
        self.network = self.prefix + "-net"
        self.volumes = [self.prefix + "-" + suffix for suffix in ("data", "socket", "daemon")]
        self.project = "r5" + secrets.token_hex(4)
        self.created = []
        self.pending_clients = []
        self.evidence = {"status": "preparing", "started_utc": utc(), "run_id": self.run_id,
                         "label": self.label, "inputs": inputs, "commands": [], "cleanup_commands": [],
                         "cleanup_complete": False, "cleanup_errors": [], "business_complete": False,
                         "reviewed_gate_sha256": sha(gate_copy)}
        self.save()

    def save(self):
        (self.run / "evidence.json").write_text(json.dumps(self.evidence, indent=2, sort_keys=True) + "\n")

    def call(self, label, argv, *, stdin=None, timeout=60, expected=0, cleanup=False):
        records = self.evidence["cleanup_commands" if cleanup else "commands"]
        need(not any(x["label"] == label for x in records), f"duplicate label {label}")
        out = pathlib.Path("raw") / f"{label}.stdout"
        err = pathlib.Path("raw") / f"{label}.stderr"
        item = {"label": label, "argv": argv, "stdout": str(out), "stderr": str(err),
                "started_utc": utc(), "returncode": None, "observation_expired": False}
        records.append(item)
        self.save()
        with (self.run / out).open("xb") as stdout, (self.run / err).open("xb") as stderr:
            source = stdin.open("rb") if isinstance(stdin, pathlib.Path) else None
            try:
                process = subprocess.Popen(argv, stdin=source if source else (subprocess.PIPE if isinstance(stdin, bytes) else subprocess.DEVNULL),
                                           stdout=stdout, stderr=stderr, close_fds=True)
                if isinstance(stdin, bytes):
                    process.stdin.write(stdin)
                    process.stdin.close()
                try:
                    item["returncode"] = process.wait(timeout=timeout)
                except subprocess.TimeoutExpired:
                    # No KILL or second TERM is sent to the product. Caller loses the result.
                    item["observation_expired"] = True
                    item["pid_still_owned_by_fixture"] = process.pid
                    self.pending_clients.append((label, process))
            finally:
                if source:
                    source.close()
        item["finished_observation_utc"] = utc()
        self.save()
        if item["observation_expired"]:
            raise RuntimeError(f"{label}: observation expired; product outcome unknown")
        if expected is not None and item["returncode"] != expected:
            raise RuntimeError(f"{label}: exit {item['returncode']}, expected {expected}")
        return (self.run / out).read_bytes()

    def outer(self, label, *argv, **opts):
        return self.call(label, ["docker", *argv], **opts)

    def control_exec(self, label, *argv, **opts):
        return self.outer(label, "exec", self.control, *argv, **opts)

    def helper(self, label, *argv, **opts):
        # Docker CLI process and helper are Linux processes in the root control container.
        # DOCKER_HOST names the private DinD socket; the host socket is never mounted.
        return self.outer(label, "exec", "-e", f"DOCKER_HOST={SOCKET}", self.control,
                          HELPER, *argv, **opts)

    def inner(self, label, *argv, **opts):
        return self.control_exec(label, "docker", "--host", SOCKET, *argv, **opts)

    def preflight_resource(self, kind, name):
        self.outer(f"absent-{kind}-{name}", kind, "inspect", name, expected=None)
        item = self.evidence["commands"][-1]
        need(item["returncode"] != 0, f"resource already exists: {kind} {name}")

    def create(self, kind, name, *argv):
        self.outer(f"create-{kind}-{name}", *argv, timeout=90)
        self.created.append((kind, name))
        self.evidence["created"] = self.created
        self.save()

    def copy(self, label, source, target):
        self.outer(label, "cp", str(source), f"{self.control}:{target}")

    def setup(self):
        for kind, name in [("network", self.network), *(('volume', v) for v in self.volumes),
                           ("container", self.control), ("container", self.dind)]:
            self.preflight_resource(kind, name)
        for image, expected in ((CONTROL, CONTROL_ID), (DIND, DIND_ID)):
            actual = json.loads(self.outer("outer-image-" + image.split(":")[0],
                                           "image", "inspect", image))[0]["Id"]
            need(actual == expected, f"fixed environment image changed: {image}")
        self.create("network", self.network, "network", "create", "--label", self.label, self.network)
        for volume in self.volumes:
            self.create("volume", volume, "volume", "create", "--label", self.label, volume)
        self.create("container", self.control, "run", "-d", "--name", self.control,
                    "--label", self.label, "--network", self.network, "--privileged",
                    "-e", f"DOCKER_HOST={SOCKET}",
                    "--cgroupns=private", "--tmpfs", "/run", "--tmpfs", "/run/lock",
                    "--tmpfs", "/tmp", "-v", f"{self.volumes[0]}:{ROOT}",
                    "-v", f"{self.volumes[1]}:/opt/omne-private-docker", CONTROL)
        self.create("container", self.dind, "run", "-d", "--name", self.dind,
                    "--label", self.label, "--network", self.network, "--privileged",
                    "-e", f"DOCKER_HOST={SOCKET}", "-e", "DOCKER_TLS_CERTDIR=",
                    "-v", f"{self.volumes[0]}:{ROOT}",
                    "-v", f"{self.volumes[1]}:/opt/omne-private-docker",
                    "-v", f"{self.volumes[2]}:/var/lib/docker", DIND,
                    "--host", SOCKET, "--tls=false")
        for outer in (self.control, self.dind):
            inspected = json.loads(self.outer("outer-inspect-" + outer, "inspect", outer))[0]
            need(all(m["Type"] == "volume" for m in inspected["Mounts"]), "outer host bind forbidden")
            need(not inspected["HostConfig"]["PortBindings"], "outer published port forbidden")
        need(self.control_exec("control-uid", "id", "-u").strip() == b"0", "control must be root")
        need(self.control_exec("control-pid1", "cat", "/proc/1/comm").strip() == b"systemd", "systemd PID1")
        self.control_exec("control-systemd-version", "systemctl", "--version")
        self.control_exec("set-private-systemd-host", "systemctl", "set-environment",
                          f"DOCKER_HOST={SOCKET}")
        manager_environment = self.control_exec("control-systemd-environment", "systemctl",
                                                 "show-environment").decode().splitlines()
        need(f"DOCKER_HOST={SOCKET}" in manager_environment,
             "systemd manager lacks private Docker socket")
        self.control_exec("mkdir-plugin", "install", "-d", "-m", "0755",
                          "/usr/local/lib/docker/cli-plugins", "/usr/local/libexec")
        self.copy("copy-docker-cli", V0 / "extracted-bin/docker", "/usr/local/bin/docker")
        self.copy("copy-compose", V0 / "docker-compose-linux-aarch64",
                  "/usr/local/lib/docker/cli-plugins/docker-compose")
        self.control_exec("chmod-cli", "chmod", "0755", "/usr/local/bin/docker",
                          "/usr/local/lib/docker/cli-plugins/docker-compose")
        for attempt in range(1, 41):
            out = self.inner(f"engine-ready-{attempt}", "version", "--format",
                             "{{.Client.Version}} {{.Server.Version}}", expected=None)
            if self.evidence["commands"][-1]["returncode"] == 0 and out.strip() == b"29.1.3 29.1.3":
                break
            time.sleep(1)
        else:
            raise RuntimeError("private engine unavailable")
        need(self.control_exec("compose-version", "docker", "compose", "version", "--short").strip()
             == b"2.40.3", "Compose version")
        for name in ("omne-center", "compose.yaml", "compose.maintenance.yaml", "health.mjs",
                     "omne-center-backup@.service", "omne-center-backup@.timer"):
            target = "/usr/local/libexec/" + name
            if name.endswith(".service") or name.endswith(".timer"):
                target = "/etc/systemd/system/" + name
            self.copy("copy-" + name, self.frozen / name, target)
        self.control_exec("chmod-helper", "chmod", "0755", HELPER)
        self.control_exec("mkdir-qa-timer-dropin", "install", "-d", "-m", "0755",
                          "/etc/systemd/system/omne-center-backup@.timer.d")
        override = b"[Timer]\nOnCalendar=\nOnActiveSec=2s\nPersistent=false\n"
        self.outer("write-qa-timer-dropin", "exec", "-i", self.control, "tee",
                   "/etc/systemd/system/omne-center-backup@.timer.d/r5-qa.conf", stdin=override)
        self.control_exec("systemd-reload", "systemctl", "daemon-reload")

    def import_image(self):
        # Host CLI is transport only. Image bytes are streamed to the private Engine.
        need(sha(self.args.image_tar) == self.evidence["inputs"]["sha256"]["image_tar"],
             "image tar changed after review")
        self.outer("load-image", "exec", "-i", self.dind, "docker", "--host", SOCKET,
                   "load", stdin=self.args.image_tar, timeout=180)
        ids = self.inner("inner-image-list", "image", "ls", "-q", "--no-trunc",
                         "--filter", f"label=ai.nemori.omne.host-build-id={self.args.build_id}")
        lines = sorted(set(ids.decode("ascii", "strict").splitlines()))
        need(len(lines) == 1 and IMAGE.fullmatch(lines[0]), "loaded image identity ambiguous")
        inner = json.loads(self.inner("inner-image-inspect", "image", "inspect", lines[0]))[0]
        outer = json.loads(self.outer("outer-product-image", "image", "inspect", self.args.image_id))[0]
        need(outer["Id"] == self.args.image_id, "outer artifact image ID")
        need(inner["RootFS"]["Layers"] == outer["RootFS"]["Layers"], "inner/outer layers differ")
        need(inner["Os"] == outer["Os"] == "linux"
             and inner["Architecture"] == outer["Architecture"] == "arm64", "platform differs")
        for image in (inner, outer):
            need(image["Config"]["Labels"]["ai.nemori.omne.host-build-id"] == self.args.build_id,
                 "image BUILD_ID differs")
            need(image["Config"]["Labels"]["ai.nemori.omne.distribution"] == "tenancy-host-docker/1",
                 "distribution label differs")
        self.image_id = lines[0]
        self.evidence["expected"] = {"image_id": self.args.image_id, "inner_image_id": self.image_id,
                                     "build_id": self.args.build_id, "project": self.project,
                                     "control": self.control, "dind": self.dind,
                                     "uid": self.args.uid, "gid": self.args.gid,
                                     "state": STATE, "secrets": SECRETS,
                                     "target": STATE + "/restores/" + self.project,
                                     "target_in_container": "/state/restores/" + self.project}
        self.save()

    def prepare_paths(self):
        uid = str(self.args.uid)
        gid = str(self.args.gid)
        self.control_exec("prepare-dirs", "install", "-d", "-m", "0700", "-o", uid, "-g", gid,
                          STATE, STATE + "/data", STATE + "/backups", STATE + "/offline-work",
                          STATE + "/restores", SECRETS)
        self.control_exec("generate-tls", "openssl", "req", "-x509", "-newkey", "rsa:2048",
                          "-sha256", "-nodes", "-days", "1", "-subj", "/CN=localhost",
                          "-addext", "subjectAltName=DNS:localhost,IP:127.0.0.1",
                          "-keyout", SECRETS + "/tls-private.pem", "-out", SECRETS + "/tls-chain.pem")
        self.control_exec("own-tls", "chown", f"{uid}:{gid}", SECRETS + "/tls-private.pem",
                          SECRETS + "/tls-chain.pem")
        self.control_exec("mode-tls", "chmod", "0600", SECRETS + "/tls-private.pem",
                          SECRETS + "/tls-chain.pem")
        self.inner("generate-keys", "run", "--rm", "--pull", "never", "--network", "none",
                   "--label", self.label, "--user", f"{uid}:{gid}", "-v", f"{SECRETS}:/secrets",
                   self.image_id, "keygen", "/secrets")
        values = {
            "OMNE_TENANCY_UNACTIVATED_RETENTION": "P7D",
            "OMNE_TENANCY_INVITATION_TTL_DEFAULT": "P14D",
            "OMNE_TENANCY_AFFILIATION_REQUEST_TTL_DEFAULT": "P14D",
            "OMNE_TENANCY_COPY_NOTICE_TTL_DEFAULT": "P7D",
            "OMNE_TENANCY_SHARING_INVITATION_TTL_DEFAULT": "P7D",
            "OMNE_TENANCY_TEAM_CREATION_KEY_RETENTION": "P1D",
            "OMNE_TENANCY_CLOCK_READY_TIMEOUT": "15000",
        }
        settings = "".join(f"{key}={value}\n" for key, value in values.items()).encode()
        self.outer("write-settings", "exec", "-i", self.control, "tee", SETTINGS, stdin=settings)
        self.control_exec("mode-settings", "chmod", "0600", SETTINGS)
        c = self.control_exec("control-inode", "stat", "-c", "%i:%u:%g:%a", STATE).strip()
        d = self.outer("dind-inode", "exec", self.dind, "stat", "-c", "%i:%u:%g:%a", STATE).strip()
        a = self.inner("app-inode", "run", "--rm", "--pull", "never", "--network", "none",
                       "--label", self.label, "--user", f"{uid}:{gid}",
                       "-v", f"{STATE}:/state", "--entrypoint", "stat", self.image_id,
                       "-c", "%i:%u:%g:%a", "/state").strip()
        need(c == d == a and c.endswith(f":{uid}:{gid}:700".encode()),
             "shared Linux inode/UID mismatch")
        marker = STATE + "/.r5-view-" + self.project
        self.control_exec("write-view-marker", "touch", marker)
        self.outer("read-view-marker", "exec", self.dind, "stat", "-c", "%i:%s", marker)
        self.inner("app-view-marker", "run", "--rm", "--pull", "never", "--network", "none",
                   "--label", self.label, "--user", f"{uid}:{gid}", "-v", f"{STATE}:/state",
                   "--entrypoint", "stat", self.image_id, "-c", "%i:%s",
                   "/state/.r5-view-" + self.project)

    def smoke(self):
        common = ["--project", self.project]
        deployment = [*common, "--image", self.image_id, "--state-dir", STATE,
                      "--secrets-dir", SECRETS, "--settings-file", SETTINGS,
                      "--publish-address", "127.0.0.1", "--publish-port", "18443",
                      "--uid", str(self.args.uid), "--gid", str(self.args.gid)]
        self.helper("validate", "validate", *deployment)
        start = parse_json_line(self.helper("start", "start", *deployment, timeout=self.args.observe_seconds), "start")
        cid = start["containerId"]
        need(HEX64.fullmatch(cid), "start did not give exact ID")
        self.inner("inspect-running", "inspect", cid)
        self.inner("runtime-ops-tmpfs", "exec", cid, "node", "-e", OPS_TMPFS_PROBE)
        self.helper("full-health", "full-health", *common)
        backup = parse_json_line(self.helper("backup", "backup", *common,
                                             timeout=self.args.observe_seconds), "backup")
        need(backup.get("status") == "completed", "backup did not complete")
        filename = backup["backup"]["fileName"]
        need(re.fullmatch(r"[0-9a-f]{32}\.omne-backup", filename), "backup filename")
        source = STATE + "/backups/" + filename
        self.evidence["source"] = source
        self.save()
        self.helper("backup-status", "backup-status", *common)
        self.control_exec("backup-file-stat", "stat", "-c", "%F:%u:%g:%a:%s", source)
        work = STATE + "/offline-work/" + self.project
        self.helper("verify", "verify", *common, "--image", self.image_id, "--state-dir", STATE,
                    "--source", source, "--work-dir", work, "--uid", str(self.args.uid),
                    "--gid", str(self.args.gid), timeout=self.args.observe_seconds)
        target = STATE + "/restores/" + self.project
        self.helper("restore", "restore-isolated", *common, "--image", self.image_id,
                    "--state-dir", STATE, "--source", source, "--work-dir", work,
                    "--target", target, "--uid", str(self.args.uid), "--gid", str(self.args.gid),
                    timeout=self.args.observe_seconds)
        self.control_exec("restore-target-stat", "stat", "-c", "%F:%u:%g:%a", target)
        self.control_exec("restore-marker-stat", "stat", "-c", "%F:%a", target + "/.omne-isolated")
        self.fire_timer("timer-running", success=True)
        event_start = utc()
        self.helper("stop", "stop", *common, timeout=self.args.observe_seconds)
        self.inner("inspect-stopped", "inspect", cid)
        self.helper("stop-exited", "stop", *common, expected=1)
        self.inner("inspect-after-exited-stop", "inspect", cid)
        self.fire_timer("timer-stopped", success=False)
        self.inner("inspect-after-timer", "inspect", cid)
        self.inner("center-events", "events", "--since", event_start, "--until", utc(),
                   "--filter", f"container={cid}", "--format", "{{json .}}", timeout=20)
        self.evidence["business_complete"] = True
        self.save()

    def systemd_state(self, label, unit, properties):
        data = self.control_exec(label, "systemctl", "show", unit,
                                 *("--property=" + name for name in properties))
        return dict(line.split("=", 1) for line in data.decode().splitlines() if "=" in line)

    def fire_timer(self, label, *, success):
        timer = f"omne-center-backup@{self.project}.timer"
        service = f"omne-center-backup@{self.project}.service"
        self.control_exec(label + "-stop-old-timer", "systemctl", "stop", timer)
        if not success:
            self.control_exec(label + "-reset-failed", "systemctl", "reset-failed", service)
        prior_timer = self.systemd_state(label + "-timer-before", timer,
                                         ("LastTriggerUSec",))
        prior_service = self.systemd_state(label + "-service-before", service,
                                           ("ExecMainStartTimestampMonotonic",))
        self.control_exec(label + "-start-timer", "systemctl", "start", timer)
        deadline = time.monotonic() + self.args.timer_observe_seconds
        for attempt in range(1, self.args.timer_observe_seconds * 2 + 2):
            current_timer = self.systemd_state(label + f"-timer-poll-{attempt}", timer,
                                               ("LastTriggerUSec",))
            current_service = self.systemd_state(label + f"-service-poll-{attempt}", service,
                                                 ("ExecMainStartTimestampMonotonic", "ActiveState"))
            if (current_timer.get("LastTriggerUSec", "n/a") not in ("", "n/a")
                    and current_timer.get("LastTriggerUSec")
                    != prior_timer.get("LastTriggerUSec")
                    and current_service.get("ExecMainStartTimestampMonotonic", "0")
                    != prior_service.get("ExecMainStartTimestampMonotonic", "0")
                    and current_service.get("ActiveState") in ("inactive", "failed")):
                break
            if time.monotonic() >= deadline:
                raise RuntimeError(label + ": timer observation expired")
            time.sleep(0.5)
        else:
            raise RuntimeError(label + ": timer observation expired")
        self.control_exec(label + "-stop-timer", "systemctl", "stop", timer)
        result = self.systemd_state(label + "-state", service,
                                    ("Result", "ExecMainStatus", "ActiveState",
                                     "ExecMainStartTimestampMonotonic",
                                     "ExecMainExitTimestampMonotonic"))
        self.systemd_state(label + "-timer-after", timer, ("LastTriggerUSec",))
        self.control_exec(label + "-journal", "journalctl", "-u", service,
                          "--no-pager", "--output=cat")
        need(result.get("Result") == ("success" if success else "exit-code"),
             label + ": service result")

    def cleanup(self):
        # Fixture teardown may force-remove only this run's labelled outer resources.
        # It is recorded after the business oracle and cannot turn unknown into clean.
        errors = []
        if ("container", self.control) in self.created and ("container", self.dind) in self.created:
            try:
                for group, filter_value, label_key, label_expected in (
                    ("project", f"label=ai.nemori.omne.project={self.project}",
                     "ai.nemori.omne.project", self.project),
                    ("fixture", f"label={self.label}", "omne.r5.helper-prep", self.run_id),
                ):
                    found = self.inner(f"cleanup-inner-{group}-list", "ps", "-aq", "--no-trunc",
                                       "--filter", filter_value, cleanup=True).decode().splitlines()
                    for index, cid in enumerate(found):
                        inspected = json.loads(self.inner(f"cleanup-inner-{group}-inspect-{index}",
                                                          "inspect", cid, cleanup=True))[0]
                        labels = inspected["Config"]["Labels"]
                        need(inspected["Id"] == cid and labels.get(label_key) == label_expected,
                             "inner cleanup identity mismatch")
                        self.inner(f"fixture-force-remove-inner-{group}-{index}", "rm", "-f", cid,
                                   timeout=90, cleanup=True)
                    remaining = self.inner(f"cleanup-inner-{group}-final-list", "ps", "-aq",
                                           "--no-trunc", "--filter", filter_value, cleanup=True)
                    if remaining.strip():
                        errors.append(f"inner {group} containers remain")
                all_remaining = self.inner("cleanup-inner-all-final-list", "ps", "-aq", "--no-trunc",
                                           cleanup=True)
                if all_remaining.strip():
                    errors.append("unlabelled or foreign private containers remain")
            except (RuntimeError, ValueError, KeyError, UnicodeError, OSError) as error:
                errors.append(f"inner cleanup uncertain: {error}")
        for kind in ("container", "volume", "network"):
            try:
                if kind == "container":
                    args = ("ps", "-aq", "--filter", f"label={self.label}")
                else:
                    args = (kind, "ls", "-q", "--filter", f"label={self.label}")
                names = self.outer("cleanup-list-" + kind, *args, cleanup=True).decode().splitlines()
                for index, name in enumerate(names):
                    # Discovery uses only this run's unique label; records keep each actual ID.
                    remove = {"container": ("rm", "-f", name), "volume": ("volume", "rm", name),
                              "network": ("network", "rm", name)}[kind]
                    self.outer(f"cleanup-{kind}-{index}", *remove, timeout=90, cleanup=True)
                remaining = self.outer("cleanup-final-list-" + kind, *args, cleanup=True)
                if remaining.strip():
                    errors.append(f"remaining exact-label {kind}: {remaining!r}")
            except (RuntimeError, UnicodeError, OSError) as error:
                errors.append(str(error))
        client_cleanup = []
        for label, process in self.pending_clients:
            action = "ended-after-private-fixture-cleanup"
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                # After attempted fixture teardown this targets only the local
                # measuring Docker CLI, never a second product TERM/KILL request.
                process.terminate()
                action = "terminated-local-docker-client-after-fixture-cleanup"
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    action = "killed-local-docker-client-after-fixture-cleanup"
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        action = "local-docker-client-still-live"
                        errors.append(f"local observation client remains: {label} pid={process.pid}")
            client_cleanup.append({"label": label, "pid": process.pid,
                                   "action": action, "returncode": process.poll()})
        self.evidence["local_client_cleanup"] = client_cleanup
        self.evidence["cleanup_errors"] = errors
        self.evidence["cleanup_complete"] = not errors
        self.evidence["finished_utc"] = utc()
        self.save()


def checked_inputs(args):
    paths = {"helper": args.helper_dir / "omne-center",
             "compose": args.helper_dir / "compose.yaml",
             "maintenance_compose": args.helper_dir / "compose.maintenance.yaml",
             "health": args.helper_dir / "health.mjs",
             "service": args.helper_dir / "omne-center-backup@.service",
             "timer": args.helper_dir / "omne-center-backup@.timer",
             "image_tar": args.image_tar,
             "driver": HERE / "driver.py", "oracle": HERE / "oracle.py",
             "compose_binary": V0 / "docker-compose-linux-aarch64",
             "docker_cli": V0 / "extracted-bin/docker"}
    actual = {name: sha(path) for name, path in paths.items()}
    for name in ("helper", "compose", "maintenance_compose", "health", "service", "timer", "image_tar"):
        need(actual[name] == getattr(args, name + "_sha256"), f"{name} SHA mismatch")
    need(actual["compose_binary"] == COMPOSE_SHA and actual["docker_cli"] == CLI_SHA,
         "fixed V0 tool input SHA mismatch")
    need(IMAGE.fullmatch(args.image_id) and HEX64.fullmatch(args.build_id), "artifact identity shape")
    need(args.uid > 0 and args.gid > 0 and args.observe_seconds > 0
         and args.timer_observe_seconds > 0, "positive UID/GID/observation")
    inputs = {"paths": {key: str(value.resolve()) for key, value in paths.items()},
              "sha256": actual, "image_id": args.image_id, "build_id": args.build_id,
              "uid": args.uid, "gid": args.gid, "observe_seconds": args.observe_seconds,
              "timer_observe_seconds": args.timer_observe_seconds}
    return inputs


def preflight(args):
    inputs = checked_inputs(args)
    need(args.reviewed_gate is not None, "root-reviewed gate required")
    gate = json.loads(args.reviewed_gate.read_text())
    payload = json.dumps(inputs, sort_keys=True, separators=(",", ":")).encode()
    need(gate.get("approved") is True and gate.get("reviewer") == "root"
         and gate.get("inputs_sha256") == hashlib.sha256(payload).hexdigest()
         and gate.get("driver_sha256") == inputs["sha256"]["driver"]
         and gate.get("oracle_sha256") == inputs["sha256"]["oracle"], "root-reviewed gate missing or stale")
    return inputs


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--helper-dir", type=pathlib.Path, required=True)
    p.add_argument("--image-tar", type=pathlib.Path, required=True)
    for name in ("helper", "compose", "maintenance_compose", "health", "service", "timer", "image_tar"):
        p.add_argument("--" + name.replace("_", "-") + "-sha256", required=True)
    p.add_argument("--image-id", required=True)
    p.add_argument("--build-id", required=True)
    p.add_argument("--uid", type=int, default=10001)
    p.add_argument("--gid", type=int, default=10001)
    p.add_argument("--observe-seconds", type=int, default=600)
    p.add_argument("--timer-observe-seconds", type=int, default=90)
    p.add_argument("--reviewed-gate", type=pathlib.Path)
    p.add_argument("--print-inputs", action="store_true")
    p.add_argument("--execute", action="store_true")
    args = p.parse_args()
    if args.print_inputs:
        inputs = checked_inputs(args)
        payload = json.dumps(inputs, sort_keys=True, separators=(",", ":")).encode()
        print(json.dumps({"inputs": inputs, "inputs_sha256": hashlib.sha256(payload).hexdigest()},
                         sort_keys=True))
        return 0
    if not args.execute:
        p.error("refusing Docker operations without --execute")
    inputs = preflight(args)
    run = Run(args, inputs)
    try:
        run.setup()
        run.import_image()
        run.prepare_paths()
        run.smoke()
        run.evidence["status"] = "observed-awaiting-oracle"
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
    finally:
        run.cleanup()
    with (run.run / "oracle.stdout").open("xb") as stdout, (run.run / "oracle.stderr").open("xb") as stderr:
        checked = subprocess.run([sys.executable, "-B", str(run.frozen / "oracle.py"), str(run.run)],
                                 stdout=stdout, stderr=stderr, check=False)
    run.evidence["oracle_exit"] = checked.returncode
    run.evidence["oracle_stdout"] = "oracle.stdout"
    run.evidence["oracle_stderr"] = "oracle.stderr"
    run.save()
    print(json.dumps({"run": str(run.run), "status": run.evidence["status"],
                      "cleanup_complete": run.evidence["cleanup_complete"],
                      "oracle_exit": checked.returncode}, sort_keys=True))
    return 0 if checked.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
