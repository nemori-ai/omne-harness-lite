# R5 helper smoke 第四次运行候选：静态测量修正，未运行

本目录是从已运行的 `next-run-2/` 单独复制的候选。旧 driver、oracle、root gate、argv、原始记录和 `post-run-files.sha256.json` 未改。本目录没有 `reviewed-gate.json`、`root-run-argv.json` 或实际 run；下一次真实执行必须经 root 重新冻结制品身份、driver/oracle SHA、输入摘要和精确 argv，再单次授权。

第三轮实际 run `20260926T195422Z-cacce7db` 在第二个 timer cell 的 `systemctl reset-failed omne-center-backup@<project>.service` 以 rc1 中止，原 stderr 明确说 service unit `not loaded`。此前第一轮 timer 确有新 `LastTriggerUSec`，service `Result=success`、`ExecMainStatus=0`、`ActiveState=inactive`，且最终状态在显式 stop timer 前落盘；正常 stop 返回相同 ID、exit0、clean true，Engine inspect 同 ID `exited/ExitCode=0`；初始 exited 的重复 stop 返回非零 `stop-intent-unconfirmed` 且未改变 `StartedAt`。第二轮 timer 尚未 start，故旧 run **不证明**停止中心后的 timer 不复活，也不构成产品不符合反例。旧 run 的 fixture cleanup 与独立 exact-label container/volume/network 查询均空，具体 bytes 和阶段见 `../next-run-2/post-run-finding.json` 与 hash 清单。

本版唯一 driver 差异是删除 `fire_timer` 里 `if not success: systemctl reset-failed service` 两行；没有忽略错误、重试、修改 unit/drop-in、放宽观察时间或引入新业务动作。每个 cell 仍先停同一私有 project 的旧 timer，通过 `systemctl show` 读取 timer/service 基线，再恰一次 `systemctl start timer`；循环仅轮询状态。观察到 service inactive/failed 后，先记录 service 结果/主进程起止、timer 最终触发时间及 journal，后停 timer。第一次要求成功退出；第二次要求真实新触发、新执行、失败退出，随后同 ID 中心仍 `exited` 且 `StartedAt` 不变。`oracle.py` 与上一轮逐字相同，marker、封装字节、stop/TERM、tmpfs 及 cleanup 判据均未变。

`PYTHONDONTWRITEBYTECODE=1 python3 -B self_test.py` 离线验证原正常样例与负例，并增加检测旧 `reset-failed` 分支、当前仅单次 start、timer 基线与最终取证顺序，以及第一 timer 非成功、第二 timer 意外成功、timer 复活中心等反例。它只证明测量器能识别这些合成错误；第二轮真实 systemd/Engine 行为仍待下一次授权执行。`--print-inputs` 的离线 30/90 秒摘要对照只用上一轮已冻结 I3 路径作检查输入，不构成新 gate，也没有 Docker 操作。
