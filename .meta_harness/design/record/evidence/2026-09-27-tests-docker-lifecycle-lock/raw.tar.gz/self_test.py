#!/usr/bin/env python3
"""Offline positive/negative mutations for the lifecycle lock raw oracle."""

import json
import pathlib
import subprocess
import tempfile

import oracle

CID = "a" * 64
BASE = "sha256:" + "b" * 64
OUTER = "sha256:" + "c" * 64
QA = "sha256:" + "d" * 64
BUILD = "e" * 64
PROJECT = "r5static"
CONTROL = "static-control"
SOCKET = "unix:///opt/omne-private-docker/docker.sock"
STATE = "/var/lib/omne-tenancy/state"
INVENTORY = [{"path": ".", "kind": "directory", "mode": 493},
             {"path": "BUILD_ID", "kind": "file", "mode": 420, "size": 65,
              "sha256": "f" * 64}]


def encoded(value):
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def image(identity, qa=False):
    return {"Id": identity, "RootFS": {"Layers": ["sha256:" + "1" * 64]},
            "Os": "linux", "Architecture": "arm64", "Config": {
                "Labels": {"ai.nemori.omne.host-build-id": BUILD,
                           "ai.nemori.omne.distribution": "tenancy-host-docker/1"},
                "Healthcheck": {"Test": ["CMD", "node",
                                         "/opt/omne/app/deploy/docker/health.mjs"]},
                "User": "10001:10001", "Entrypoint": ["node", "/opt/omne/app/dist/cli.js"],
                "Cmd": ["serve"], "WorkingDir": "/opt/omne/app",
                "Env": (["PATH=/usr/bin", "NODE_OPTIONS=--import=/probe/qa-health-delay.mjs"]
                        if qa else ["PATH=/usr/bin"])}}


def make_run(parent):
    run = parent / "run"
    (run / "raw").mkdir(parents=True)
    records, cleanup = [], []

    def add(label, output=b"", *, error=b"", code=0, argv=None,
            begun="2026-09-27T00:00:01+00:00",
            finished="2026-09-27T00:00:02+00:00", cleaned=False, asynchronous=False):
        (run / "raw" / (label + ".stdout")).write_bytes(output)
        (run / "raw" / (label + ".stderr")).write_bytes(error)
        item = {"label": label, "stdout": "raw/" + label + ".stdout",
                "stderr": "raw/" + label + ".stderr", "returncode": code,
                "observation_expired": False, "argv": argv or [], "started_utc": begun,
                "finished_observation_utc": finished}
        if asynchronous:
            item["async_local_docker_exec_client"] = True
        (cleanup if cleaned else records).append(item)

    helper = ["docker", "exec", "-e", "DOCKER_HOST=" + SOCKET, CONTROL,
              "/usr/local/libexec/omne-center"]
    deployment = ["--project", PROJECT, "--image", QA, "--state-dir", STATE,
                  "--uid", "10023", "--gid", "10024", "--startup-wait", "45",
                  "--observation-interval", "1", "--health-interval", "1s",
                  "--health-timeout", "2s", "--health-start-period", "1s",
                  "--health-retries", "1"]
    stderr = (f"omne-center: center-start-request project={PROJECT} container={CID} image={QA}\n"
              f"omne-center: startup-observation-expired project={PROJECT} container={CID}\n"
              f"omne-center: term-request container={CID}\n").encode() + encoded(
                  {"state": "stopped", "containerId": CID, "exitCode": 0, "clean": True})
    add("c-build-qa-image", argv=["docker", "exec", CONTROL, "env", "DOCKER_BUILDKIT=0",
                                   "docker", "--host", SOCKET, "build", "--pull=false",
                                   "--network=none", "--build-arg", "BASE_IMAGE=" + BASE])
    add("outer-product-image", encoded([image(OUTER)]))
    add("c-base-image-inspect", encoded([image(BASE)]))
    add("c-qa-image-inspect", encoded([image(QA, qa=True)]))
    add("c-probe-inventory", encoded({"file": True, "uid": 0, "gid": 0,
                                      "mode": 292, "sha256": "2" * 64}))
    add("c-base-app-inventory", encoded(INVENTORY))
    add("c-qa-app-inventory", encoded(INVENTORY))
    add("lock-validate", encoded({"state": "deployment-structure-valid"}),
        argv=helper + ["validate", *deployment])
    add("lock-first-start", error=stderr, code=1, argv=helper + ["start", *deployment],
        begun="2026-09-27T00:00:03+00:00", finished="2026-09-27T00:00:48+00:00",
        asynchronous=True)
    running = {"Id": CID, "Image": QA, "Config": {
        "Labels": {"ai.nemori.omne.project": PROJECT,
                   "ai.nemori.omne.host-build-id": BUILD}, "StopSignal": "SIGTERM",
        "StopTimeout": -1}, "HostConfig": {"RestartPolicy": {"Name": "unless-stopped"}},
        "RestartCount": 0, "State": {"Status": "running", "Running": True,
        "Pid": 71, "StartedAt": "2026-09-27T00:00:05Z",
        "Health": {"Status": "unhealthy", "Log": []}}}
    stopped = {**running, "State": {**running["State"], "Status": "exited",
        "Running": False, "Pid": 0, "ExitCode": 0,
        "Health": {"Status": "unhealthy", "Log": [
            {"ExitCode": -1, "Output": "Health check exceeded timeout (2s)"}]}}}
    add("lock-running-poll-1", encoded([running]))
    add("lock-root-stat-before", b"directory:0:0:700:12\n")
    add("lock-file-stat-before", b"regular empty file:0:0:600:13\n")
    add("lock-center-pre-busy", encoded([running]))
    add("lock-logs-before", b"first\n", error=b"early\n")
    add("lock-second-start", error=b"omne-center: busy\n", code=1,
        argv=helper + ["start", *deployment], begun="2026-09-27T00:00:10+00:00",
        finished="2026-09-27T00:00:11+00:00")
    add("lock-concurrent-stop", error=b"omne-center: busy\n", code=1,
        argv=helper + ["stop", "--project", PROJECT],
        begun="2026-09-27T00:00:12+00:00",
        finished="2026-09-27T00:00:13+00:00")
    add("lock-root-stat-after", b"directory:0:0:700:12\n")
    add("lock-file-stat-after", b"regular empty file:0:0:600:13\n")
    add("lock-center-post-busy", encoded([running]))
    add("lock-logs-after", b"first\nmore\n", error=b"early\nmore\n")
    add("lock-project-list-before-expiry", (CID + "\n").encode())
    event = lambda action: {"Action": action, "Actor": {"ID": CID,
        "Attributes": {"signal": "15"} if action == "kill" else {}}}
    early = [event("create"), event("start")]
    add("lock-events-before-expiry", b"".join(encoded(x) for x in early),
        finished="2026-09-27T00:00:20+00:00")
    add("lock-center-after-first", encoded([stopped]))
    add("lock-status-after-first", encoded({"state": "exited", "containerId": CID,
                                           "imageId": QA, "buildId": BUILD,
                                           "exitCode": 0, "restartCount": 0}),
        argv=helper + ["status", "--project", PROJECT])
    add("lock-project-list-final", (CID + "\n").encode())
    add("lock-events-final", b"".join(encoded(x) for x in
        [*early, event("kill"), event("die")]))
    for label in ("cleanup-final-list-container", "cleanup-final-list-volume",
                  "cleanup-final-list-network", "cleanup-inner-project-final-list",
                  "cleanup-inner-fixture-final-list", "cleanup-inner-all-final-list"):
        add(label, cleaned=True)
    sample_times = (("before concurrent calls", "2026-09-27T00:00:08+00:00"),
                    ("second start", "2026-09-27T00:00:09+00:00"),
                    ("after second start", "2026-09-27T00:00:11+00:00"),
                    ("after concurrent stop", "2026-09-27T00:00:13+00:00"),
                    ("before first helper completes", "2026-09-27T00:00:21+00:00"))
    samples = [{"phase": phase, "time_utc": when, "returncode": None}
               for phase, when in sample_times]
    evidence = {"scenario": "R4-lifecycle-lock-start-start-stop",
                "status": "observed-awaiting-oracle", "business_complete": True,
                "cleanup_complete": True, "cleanup_errors": [], "commands": records,
                "cleanup_commands": cleanup, "running_sample_label": "lock-running-poll-1",
                "first_local_exec_pending_samples": samples,
                "inputs": {"scenario": "R4-lifecycle-lock-start-start-stop",
                           "image_id": OUTER, "build_id": BUILD, "startup_wait": 45,
                           "observation_interval": 1,
                           "sha256": {"qa-context/qa-health-delay.mjs": "2" * 64},
                           "health_interval": "1s", "health_timeout": "2s",
                           "health_start_period": "1s", "health_retries": 1},
                "expected": {"center_id": CID, "qa_image_id": QA, "base_image_id": BASE,
                             "inner_image_id": BASE, "image_id": OUTER, "build_id": BUILD,
                             "project": PROJECT, "control": CONTROL, "state": STATE,
                             "uid": 10023, "gid": 10024, "app_inventory_entries": 2}}
    (run / "evidence.json").write_text(json.dumps(evidence))
    return run


def mutate_json(run, label, change):
    path = run / "raw" / (label + ".stdout")
    value = json.loads(path.read_bytes())
    change(value)
    path.write_bytes(encoded(value))


def mutate_evidence(run, change):
    path = run / "evidence.json"
    value = json.loads(path.read_text())
    change(value)
    path.write_text(json.dumps(value))


def cases():
    def second_already_running(run):
        (run / "raw/lock-second-start.stderr").write_bytes(b"omne-center: center-already-active\n")

    def stop_already_exited(run):
        (run / "raw/lock-concurrent-stop.stderr").write_bytes(b"omne-center: stop-intent-unconfirmed\n")

    def first_finished_early(run):
        mutate_evidence(run, lambda x: next(y for y in x["commands"]
            if y["label"] == "lock-first-start").update(
                finished_observation_utc="2026-09-27T00:00:11+00:00"))

    def first_unknown(run):
        mutate_evidence(run, lambda x: next(y for y in x["commands"]
            if y["label"] == "lock-first-start").update(observation_expired=True))

    def first_success(run):
        mutate_evidence(run, lambda x: next(y for y in x["commands"]
            if y["label"] == "lock-first-start").update(returncode=0))

    def wrong_lock_mode(run):
        (run / "raw/lock-file-stat-after.stdout").write_bytes(
            b"regular empty file:0:0:644:13\n")

    def replaced_lock_file(run):
        (run / "raw/lock-file-stat-after.stdout").write_bytes(
            b"regular empty file:0:0:600:999\n")

    def extra_center(run):
        (run / "raw/lock-project-list-before-expiry.stdout").write_bytes(
            (CID + "\n" + "9" * 64 + "\n").encode())

    def early_term(run):
        path = run / "raw/lock-events-before-expiry.stdout"
        value = {"Action": "kill", "Actor": {"ID": CID,
                 "Attributes": {"signal": "15"}}}
        path.write_bytes(path.read_bytes() + encoded(value))

    def duplicate_start(run):
        path = run / "raw/lock-events-before-expiry.stdout"
        path.write_bytes(path.read_bytes() + encoded(
            {"Action": "start", "Actor": {"ID": CID, "Attributes": {}}}))

    def log_loss(run):
        (run / "raw/lock-logs-after.stdout").write_bytes(b"different\n")

    def wrong_cid(run):
        mutate_json(run, "lock-center-post-busy", lambda x: x[0].update(Id="9" * 64))

    def unhealthy_not_running(run):
        mutate_json(run, "lock-center-pre-busy",
                    lambda x: x[0]["State"].update(Status="exited", Running=False))

    def no_final_term(run):
        path = run / "raw/lock-events-final.stdout"
        events = [json.loads(line) for line in path.read_bytes().splitlines()]
        path.write_bytes(b"".join(encoded(x) for x in events if x["Action"] != "kill"))

    def final_exit_wrong(run):
        mutate_json(run, "lock-center-after-first",
                    lambda x: x[0]["State"].update(ExitCode=1))

    def cleanup_leftover(run):
        (run / "raw/cleanup-final-list-container.stdout").write_bytes((CID + "\n").encode())

    return {key: value for key, value in locals().items() if callable(value)}


def main():
    with tempfile.TemporaryDirectory(prefix="omne-lock-oracle-") as temp:
        root = pathlib.Path(temp)
        assert oracle.evaluate(make_run(root / "positive"))["status"] == "limited_pass"
        negative = cases()
        for name, change in negative.items():
            run = make_run(root / name)
            change(run)
            try:
                oracle.evaluate(run)
            except (ValueError, KeyError, TypeError, UnicodeError, OSError, json.JSONDecodeError):
                continue
            raise AssertionError(name + " false pass")
        preload = pathlib.Path(__file__).resolve().parent / "qa-context/qa-health-delay.mjs"
        ordinary = subprocess.run(["node", "--import=" + str(preload), "-e",
                                   "process.stdout.write('ordinary\\n')"],
                                  capture_output=True, timeout=5)
        assert ordinary.returncode == 0 and ordinary.stdout == b"ordinary\n"
        health = subprocess.Popen(["node", "--import=" + str(preload),
                                   "/opt/omne/app/deploy/docker/health.mjs"],
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            try:
                health.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                pass
            else:
                raise AssertionError("health preload did not hold event loop")
        finally:
            health.kill()
            health.communicate(timeout=5)
        print(json.dumps({"positive": 1, "negative": len(negative),
                          "preload_branches": 2, "result": "pass"}, sort_keys=True))


if __name__ == "__main__":
    main()
