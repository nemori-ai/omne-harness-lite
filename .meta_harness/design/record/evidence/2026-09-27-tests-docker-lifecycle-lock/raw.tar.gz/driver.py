#!/usr/bin/env python3
"""Root-gated same-project start/start and start/stop lifecycle lock interleaving."""

import argparse
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import sys
import time

import fixture

HERE = pathlib.Path(__file__).resolve().parent
HEX = re.compile(r"[0-9a-f]{64}\Z")
IMAGE = re.compile(r"sha256:[0-9a-f]{64}\Z")
START = re.compile(rb"center-start-request project=([a-z0-9_-]+) container=([0-9a-f]{64}) image=(sha256:[0-9a-f]{64})")

INVENTORY = r"""
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = '/opt/omne/app';
const rows = [];
function walk(p) {
  const st = fs.lstatSync(p);
  const rel = path.relative(root, p) || '.';
  const row = {path: rel, mode: st.mode & 0o7777};
  if (st.isSymbolicLink()) { row.kind = 'link'; row.target = fs.readlinkSync(p); }
  else if (st.isDirectory()) { row.kind = 'directory'; }
  else if (st.isFile()) {
    row.kind = 'file'; row.size = st.size;
    row.sha256 = crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
  } else { throw new Error('unexpected app object: ' + p); }
  rows.push(row);
  if (st.isDirectory()) for (const name of fs.readdirSync(p).sort()) walk(path.join(p, name));
}
walk(root);
process.stdout.write(JSON.stringify(rows) + '\n');
"""
PROBE = r"""
const fs = require('node:fs');
const crypto = require('node:crypto');
const path = '/probe/qa-health-delay.mjs';
const stat = fs.lstatSync(path);
process.stdout.write(JSON.stringify({file: stat.isFile(), uid: stat.uid, gid: stat.gid,
  mode: stat.mode & 0o7777,
  sha256: crypto.createHash('sha256').update(fs.readFileSync(path)).digest('hex')}) + '\n');
"""


def need(value, message):
    if not value:
        raise RuntimeError(message)


def one_json(data, name):
    return fixture.parse_json_line(data, name)


class LockRun(fixture.Run):
    def __init__(self, args, inputs):
        super().__init__(args, inputs)
        for name, key in (("driver.py", "driver"), ("fixture.py", "fixture"),
                          ("qa-context/Dockerfile", "qa-context/Dockerfile"),
                          ("qa-context/qa-health-delay.mjs", "qa-context/qa-health-delay.mjs")):
            target = self.frozen / name
            target.parent.mkdir(exist_ok=True)
            shutil.copyfile(HERE / name, target)
            need(fixture.sha(target) == inputs["sha256"][key], "frozen tool changed: " + name)
        self.evidence["scenario"] = "R4-lifecycle-lock-start-start-stop"
        self.first_process = None
        self.save()

    def deployment(self, image):
        return ["--project", self.project, "--image", image,
                "--state-dir", fixture.STATE, "--secrets-dir", fixture.SECRETS,
                "--settings-file", fixture.SETTINGS, "--publish-address", "127.0.0.1",
                "--publish-port", "18443", "--uid", str(self.args.uid),
                "--gid", str(self.args.gid), "--startup-wait", str(self.args.startup_wait),
                "--observation-interval", str(self.args.observation_interval),
                "--health-interval", self.args.health_interval,
                "--health-timeout", self.args.health_timeout,
                "--health-start-period", self.args.health_start_period,
                "--health-retries", str(self.args.health_retries)]

    def inspect(self, label, cid):
        data = json.loads(self.inner(label, "inspect", cid))
        need(isinstance(data, list) and len(data) == 1 and data[0]["Id"] == cid,
             label + " wrong container ID")
        return data[0]

    def app_inventory(self, label, image):
        return json.loads(self.inner(label, "run", "--rm", "--pull", "never", "--network", "none",
                                     "--label", self.label, "--entrypoint", "node", image,
                                     "-e", INVENTORY).decode("utf-8", "strict"))

    def build_qa_image(self):
        self.control_exec("c-mkdir-context", "install", "-d", "-m", "0755", "/opt/omne-expiry-build")
        for name in ("Dockerfile", "qa-health-delay.mjs"):
            self.copy("c-copy-" + name, self.frozen / "qa-context" / name,
                      "/opt/omne-expiry-build/" + name)
        self.control_exec("c-build-context-stat", "stat", "-c", "%n:%F:%u:%g:%a",
                          "/opt/omne-expiry-build/Dockerfile",
                          "/opt/omne-expiry-build/qa-health-delay.mjs")
        # Only this private Engine builds; --pull=false and --network=none prevent fetches.
        tag = "omne-r5-expiry:" + self.run_id.lower().replace(":", "-")
        self.control_exec("c-build-qa-image", "env", "DOCKER_BUILDKIT=0", "docker",
                          "--host", fixture.SOCKET, "build", "--pull=false", "--network=none",
                          "--build-arg", "BASE_IMAGE=" + self.image_id, "-t", tag,
                          "/opt/omne-expiry-build", timeout=self.args.build_observe_seconds)
        values = json.loads(self.inner("c-qa-image-inspect", "image", "inspect", tag))
        need(isinstance(values, list) and len(values) == 1, "QA image inspect shape")
        qa = values[0]
        need(IMAGE.fullmatch(qa["Id"]) and qa["Id"] != self.image_id, "QA image ID")
        base = json.loads(self.inner("c-base-image-inspect", "image", "inspect", self.image_id))[0]
        need(base["Id"] == self.image_id, "base image ID")
        for key in ("Os", "Architecture"):
            need(qa[key] == base[key], "QA platform changed")
        need(qa["Config"]["Labels"] == base["Config"]["Labels"], "QA labels changed")
        need(qa["Config"]["Healthcheck"] == base["Config"]["Healthcheck"],
             "QA healthcheck changed")
        need(qa["Config"]["Healthcheck"]["Test"] ==
             ["CMD", "node", "/opt/omne/app/deploy/docker/health.mjs"],
             "unexpected product Healthcheck.Test")
        need(qa["Config"]["Env"] == base["Config"]["Env"] +
             ["NODE_OPTIONS=--import=/probe/qa-health-delay.mjs"],
             "QA preload must be sole env change")
        for key in ("User", "Entrypoint", "Cmd", "WorkingDir"):
            need(qa["Config"][key] == base["Config"][key], "QA changed image config " + key)
        probe = one_json(self.inner("c-probe-inventory", "run", "--rm", "--pull", "never",
                                    "--network", "none", "--label", self.label,
                                    "--entrypoint", "node", qa["Id"], "-e", PROBE),
                         "c-probe-inventory")
        need(probe == {"file": True, "uid": 0, "gid": 0, "mode": 0o444,
                       "sha256": self.evidence["inputs"]["sha256"]["qa-context/qa-health-delay.mjs"]},
             "QA probe bytes/mode/owner")
        original = self.app_inventory("c-base-app-inventory", self.image_id)
        delayed = self.app_inventory("c-qa-app-inventory", qa["Id"])
        need(original == delayed and len(original) > 0, "QA changed production app inventory")
        build_file = [x for x in delayed if x["path"] == "BUILD_ID"]
        need(len(build_file) == 1 and build_file[0]["kind"] == "file", "BUILD_ID missing")
        self.evidence["expected"]["qa_image_id"] = qa["Id"]
        self.evidence["expected"]["base_image_id"] = self.image_id
        self.evidence["expected"]["app_inventory_entries"] = len(delayed)
        self.save()
        return qa["Id"]

    def first_pending(self, phase):
        need(self.first_process is not None and self.first_process.poll() is None,
             "first helper finished before " + phase)
        self.evidence.setdefault("first_local_exec_pending_samples", []).append(
            {"phase": phase, "time_utc": fixture.utc(), "returncode": None})
        self.save()

    def start_first_async(self, qa):
        label = "lock-first-start"
        argv = ["docker", "exec", "-e", f"DOCKER_HOST={fixture.SOCKET}",
                self.control, fixture.HELPER, "start", *self.deployment(qa)]
        out = pathlib.Path("raw") / (label + ".stdout")
        err = pathlib.Path("raw") / (label + ".stderr")
        item = {"label": label, "argv": argv, "stdout": str(out), "stderr": str(err),
                "started_utc": fixture.utc(), "returncode": None,
                "observation_expired": False, "async_local_docker_exec_client": True}
        self.evidence["commands"].append(item)
        self.save()
        with (self.run / out).open("xb") as stdout, (self.run / err).open("xb") as stderr:
            self.first_process = subprocess.Popen(argv, stdout=stdout, stderr=stderr,
                                                  stdin=subprocess.DEVNULL, close_fds=True)
        self.evidence["first_helper_local_pid"] = self.first_process.pid
        self.save()

    def await_first(self):
        item = next(x for x in self.evidence["commands"] if x["label"] == "lock-first-start")
        try:
            item["returncode"] = self.first_process.wait(timeout=self.args.observe_seconds)
        except subprocess.TimeoutExpired:
            item["observation_expired"] = True
            self.pending_clients.append(("lock-first-start", self.first_process))
            raise RuntimeError("first helper observation expired; outcome unknown")
        finally:
            item["finished_observation_utc"] = fixture.utc()
            self.save()
        need(item["returncode"] == 1, "first helper did not finish startup failure")

    def settle_first_before_cleanup(self):
        if self.first_process is None:
            return
        item = next(x for x in self.evidence["commands"] if x["label"] == "lock-first-start")
        if item["returncode"] is not None or item["observation_expired"]:
            return
        try:
            item["returncode"] = self.first_process.wait(timeout=self.args.observe_seconds)
        except subprocess.TimeoutExpired:
            item["observation_expired"] = True
            self.pending_clients.append(("lock-first-start", self.first_process))
        item["finished_observation_utc"] = fixture.utc()
        self.save()

    def scenario_lock(self):
        qa = self.build_qa_image()
        self.helper("lock-validate", "validate", *self.deployment(qa))
        since = fixture.utc()
        self.evidence["event_since"] = since
        self.save()
        self.start_first_async(qa)
        deadline = time.monotonic() + self.args.interleave_observe_seconds
        cid = None
        while time.monotonic() < deadline:
            self.first_pending("await exact created CID")
            raw_stderr = (self.run / "raw/lock-first-start.stderr").read_bytes()
            matches = START.findall(raw_stderr)
            if matches:
                need(len(matches) == 1 and matches[0][0].decode() == self.project
                     and matches[0][2].decode() == qa,
                     "first helper created ambiguous/wrong QA center")
                cid = matches[0][1].decode()
                break
            time.sleep(0.25)
        need(cid is not None, "first helper never exposed exact created CID")
        self.evidence["expected"]["center_id"] = cid
        self.save()
        index = 0
        while time.monotonic() < deadline:
            self.first_pending("await first center running")
            index += 1
            label = f"lock-running-poll-{index}"
            values = json.loads(self.inner(label, "inspect", cid))
            need(len(values) == 1 and values[0]["Id"] == cid,
                 "first center inspect identity")
            state = values[0]["State"]
            if (state["Status"] == "running" and state["Running"] is True
                    and state["Pid"] > 0):
                self.evidence["running_sample_label"] = label
                self.save()
                break
            time.sleep(0.25)
        else:
            raise RuntimeError("first center did not become running inside interleave window")
        self.first_pending("before concurrent calls")
        self.control_exec("lock-root-stat-before", "stat", "-c", "%F:%u:%g:%a:%i",
                          "/run/omne-center")
        self.control_exec("lock-file-stat-before", "stat", "-c", "%F:%u:%g:%a:%i",
                          "/run/omne-center/" + self.project + ".lock")
        self.inspect("lock-center-pre-busy", cid)
        self.inner("lock-logs-before", "logs", cid)
        self.first_pending("second start")
        self.helper("lock-second-start", "start", *self.deployment(qa), expected=1)
        self.first_pending("after second start")
        self.helper("lock-concurrent-stop", "stop", "--project", self.project, expected=1)
        self.first_pending("after concurrent stop")
        self.control_exec("lock-root-stat-after", "stat", "-c", "%F:%u:%g:%a:%i",
                          "/run/omne-center")
        self.control_exec("lock-file-stat-after", "stat", "-c", "%F:%u:%g:%a:%i",
                          "/run/omne-center/" + self.project + ".lock")
        self.inspect("lock-center-post-busy", cid)
        self.inner("lock-logs-after", "logs", cid)
        self.inner("lock-project-list-before-expiry", "ps", "-aq", "--no-trunc", "--filter",
                   "label=ai.nemori.omne.project=" + self.project)
        self.inner("lock-events-before-expiry", "events", "--since", since,
                   "--until", fixture.utc(), "--filter", "container=" + cid,
                   "--format", "{{json .}}", timeout=30)
        self.first_pending("before first helper completes")
        self.await_first()
        self.inspect("lock-center-after-first", cid)
        self.helper("lock-status-after-first", "status", "--project", self.project)
        self.inner("lock-project-list-final", "ps", "-aq", "--no-trunc", "--filter",
                   "label=ai.nemori.omne.project=" + self.project)
        self.inner("lock-events-final", "events", "--since", since, "--until", fixture.utc(),
                   "--filter", "container=" + cid, "--format", "{{json .}}", timeout=30)
        self.evidence["business_complete"] = True
        self.save()


def checked_inputs(args):
    paths = {"helper": args.helper_dir / "omne-center",
             "compose": args.helper_dir / "compose.yaml",
             "maintenance_compose": args.helper_dir / "compose.maintenance.yaml",
             "health": args.helper_dir / "health.mjs",
             "service": args.helper_dir / "omne-center-backup@.service",
             "timer": args.helper_dir / "omne-center-backup@.timer",
             "image_tar": args.image_tar, "manifest": args.manifest,
             "oracle": HERE / "oracle.py", "driver": HERE / "driver.py",
             "fixture": HERE / "fixture.py",
             "compose_binary": fixture.V0 / "docker-compose-linux-aarch64",
             "docker_cli": fixture.V0 / "extracted-bin/docker",
             **{name: HERE / name for name in
                ("qa-context/Dockerfile",
                 "qa-context/qa-health-delay.mjs")}}
    actual = {name: fixture.sha(path) for name, path in paths.items()}
    for name in ("helper", "compose", "maintenance_compose", "health", "service", "timer",
                 "image_tar", "manifest"):
        need(actual[name] == getattr(args, name + "_sha256"), name + " SHA changed")
    need(actual["compose_binary"] == fixture.COMPOSE_SHA
         and actual["docker_cli"] == fixture.CLI_SHA, "private fixture binary changed")
    need(IMAGE.fullmatch(args.image_id) and HEX.fullmatch(args.build_id), "image/build identity")
    manifest = json.loads(args.manifest.read_text())
    need(manifest["images"]["arm64"]["imageId"] == args.image_id
         and manifest["archives"]["host"]["buildId"] == args.build_id,
         "image/build absent from frozen manifest")
    need(args.uid > 0 and args.gid > 0 and args.startup_wait > 0
         and args.observation_interval > 0 and args.observe_seconds > args.startup_wait
         and 0 < args.interleave_observe_seconds < args.startup_wait
         and args.build_observe_seconds > 0 and args.health_retries > 0
         and all(re.fullmatch(r"[1-9][0-9]*s", value) for value in
                 (args.health_interval, args.health_timeout, args.health_start_period)),
         "positive finite fixture budgets")
    return {"scenario": "R4-lifecycle-lock-start-start-stop",
            "paths": {key: str(value.resolve()) for key, value in paths.items()},
            "sha256": actual, "image_id": args.image_id, "build_id": args.build_id,
            "uid": args.uid, "gid": args.gid, "startup_wait": args.startup_wait,
            "interleave_observe_seconds": args.interleave_observe_seconds,
            "observation_interval": args.observation_interval,
            "health_interval": args.health_interval, "health_timeout": args.health_timeout,
            "health_start_period": args.health_start_period,
            "health_retries": args.health_retries,
            "observe_seconds": args.observe_seconds,
            "build_observe_seconds": args.build_observe_seconds}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--helper-dir", type=pathlib.Path, required=True)
    parser.add_argument("--image-tar", type=pathlib.Path, required=True)
    parser.add_argument("--manifest", type=pathlib.Path, required=True)
    parser.add_argument("--image-id", required=True)
    parser.add_argument("--build-id", required=True)
    for name in ("helper", "compose", "maintenance_compose", "health", "service", "timer",
                 "image_tar", "manifest"):
        parser.add_argument("--" + name.replace("_", "-") + "-sha256", required=True)
    parser.add_argument("--uid", type=int, default=10023)
    parser.add_argument("--gid", type=int, default=10024)
    parser.add_argument("--startup-wait", type=int, default=45)
    parser.add_argument("--interleave-observe-seconds", type=int, default=20)
    parser.add_argument("--observation-interval", type=int, default=1)
    parser.add_argument("--health-interval", default="1s")
    parser.add_argument("--health-timeout", default="2s")
    parser.add_argument("--health-start-period", default="1s")
    parser.add_argument("--health-retries", type=int, default=1)
    parser.add_argument("--observe-seconds", type=int, default=600)
    parser.add_argument("--build-observe-seconds", type=int, default=180)
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    inputs = checked_inputs(args)
    payload = json.dumps(inputs, sort_keys=True, separators=(",", ":")).encode()
    digest = hashlib.sha256(payload).hexdigest()
    if args.print_inputs:
        print(json.dumps({"inputs": inputs, "inputs_sha256": digest}, sort_keys=True))
        return 0
    need(args.execute and args.reviewed_gate is not None,
         "explicit execute and root-reviewed gate required")
    gate = json.loads(args.reviewed_gate.read_text())
    need(gate.get("approved") is True and gate.get("reviewer") == "root"
         and gate.get("inputs_sha256") == digest
         and all(gate.get(key + "_sha256") == inputs["sha256"][file]
                 for key, file in (("driver", "driver"), ("fixture", "fixture"),
                                   ("oracle", "oracle"))), "missing/stale review gate")
    run = LockRun(args, inputs)
    try:
        run.setup()
        run.import_image()
        run.prepare_paths()
        run.scenario_lock()
        run.evidence["status"] = "observed-awaiting-oracle"
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
    finally:
        run.save()
        run.settle_first_before_cleanup()
        run.cleanup()
    with (run.run / "oracle.stdout").open("xb") as out, (
            run.run / "oracle.stderr").open("xb") as err:
        checked = subprocess.run([sys.executable, str(run.frozen / "oracle.py"), str(run.run)],
                                 stdout=out, stderr=err)
    print(json.dumps({"run": str(run.run), "status": run.evidence["status"],
                      "cleanup_complete": run.evidence["cleanup_complete"],
                      "oracle_exit": checked.returncode}, sort_keys=True))
    return 0 if checked.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
