#!/usr/bin/env python3
"""Independent raw oracle for same-project R4 lifecycle lock interleavings."""

import argparse
import json
import pathlib
import re
from datetime import datetime

HEX = re.compile(r"[0-9a-f]{64}\Z")


def need(value, message):
    if not value:
        raise ValueError(message)


def raw(run, commands, label, stream="stdout"):
    item = commands[label]
    path = run / item[stream]
    need(path.parent == run / "raw" and path.is_file(), label + " raw missing")
    return path.read_bytes()


def success(commands, label):
    item = commands[label]
    need(item["returncode"] == 0 and item["observation_expired"] is False,
         label + " actual command failed/observation expired")


def one_json(data, label):
    need(data.endswith(b"\n") and data.count(b"\n") == 1,
         label + " must be one JSON+LF")
    value = json.loads(data[:-1].decode("utf-8", "strict"))
    need(isinstance(value, dict), label + " object required")
    return value


def one_inspect(run, commands, label, identity):
    success(commands, label)
    values = json.loads(raw(run, commands, label).decode("utf-8", "strict"))
    need(isinstance(values, list) and len(values) == 1 and values[0]["Id"] == identity,
         label + " exact inspect identity")
    return values[0]


def stat_line(run, commands, label):
    success(commands, label)
    value = raw(run, commands, label)
    need(value.endswith(b"\n") and value.count(b"\n") == 1,
         label + " stat line")
    return value.decode("utf-8", "strict").strip()


def evaluate(run):
    evidence = json.loads((run / "evidence.json").read_text())
    commands = {item["label"]: item for item in evidence["commands"]}
    need(len(commands) == len(evidence["commands"]), "duplicate measurement labels")
    need(evidence["scenario"] == "R4-lifecycle-lock-start-start-stop"
         and evidence["status"] == "observed-awaiting-oracle"
         and evidence["business_complete"] is True, "lock observation incomplete")
    expected = evidence["expected"]
    inputs = evidence["inputs"]
    cid = expected["center_id"]
    qa_id = expected["qa_image_id"]
    base_id = expected["base_image_id"]
    project = expected["project"]
    build = expected["build_id"]
    need(HEX.fullmatch(cid) and HEX.fullmatch(build)
         and base_id == expected["inner_image_id"] and qa_id != base_id,
         "expected center/image identity")
    need(inputs["scenario"] == evidence["scenario"] and
         inputs["image_id"] == expected["image_id"] and
         inputs["build_id"] == build, "frozen inputs/expectation mismatch")

    helper = ["docker", "exec", "-e",
              "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock",
              expected["control"], "/usr/local/libexec/omne-center"]
    for label, action in (("lock-validate", "validate"),
                          ("lock-first-start", "start"),
                          ("lock-second-start", "start"),
                          ("lock-concurrent-stop", "stop"),
                          ("lock-status-after-first", "status")):
        need(commands[label]["argv"][:len(helper) + 1] == [*helper, action],
             label + " not real helper/private socket")
    for label in ("lock-validate", "lock-first-start", "lock-second-start"):
        argv = commands[label]["argv"]
        for key, value in (("--project", project), ("--image", qa_id),
                           ("--state-dir", expected["state"]),
                           ("--uid", str(expected["uid"])),
                           ("--gid", str(expected["gid"])),
                           ("--startup-wait", str(inputs["startup_wait"])),
                           ("--observation-interval", str(inputs["observation_interval"])),
                           ("--health-interval", inputs["health_interval"]),
                           ("--health-timeout", inputs["health_timeout"]),
                           ("--health-start-period", inputs["health_start_period"]),
                           ("--health-retries", str(inputs["health_retries"]))):
            need(argv.count(key) == 1 and argv[argv.index(key) + 1] == value,
                 label + " fixture/helper argument changed: " + key)
    success(commands, "lock-validate")
    need(one_json(raw(run, commands, "lock-validate"), "lock-validate") ==
         {"state": "deployment-structure-valid"}, "validate structure")
    need(commands["c-build-qa-image"]["argv"][:8] ==
         ["docker", "exec", expected["control"], "env", "DOCKER_BUILDKIT=0",
          "docker", "--host", "unix:///opt/omne-private-docker/docker.sock"],
         "QA build must use private legacy Engine")
    build_argv = commands["c-build-qa-image"]["argv"]
    need("--pull=false" in build_argv and "--network=none" in build_argv
         and "BASE_IMAGE=" + base_id in build_argv,
         "QA build must use only pinned local base/no network")
    success(commands, "c-build-qa-image")
    outer = one_inspect(run, commands, "outer-product-image", expected["image_id"])
    base = one_inspect(run, commands, "c-base-image-inspect", base_id)
    qa = one_inspect(run, commands, "c-qa-image-inspect", qa_id)
    need(outer["RootFS"]["Layers"] == base["RootFS"]["Layers"]
         and outer["Os"] == base["Os"] == qa["Os"] == "linux"
         and outer["Architecture"] == base["Architecture"] == qa["Architecture"] == "arm64",
         "base import or QA platform mismatch")
    need(base["Config"]["Labels"] == qa["Config"]["Labels"]
         and qa["Config"]["Labels"]["ai.nemori.omne.host-build-id"] == build
         and qa["Config"]["Labels"]["ai.nemori.omne.distribution"] ==
         "tenancy-host-docker/1", "QA product labels/BUILD changed")
    need(base["Config"]["Healthcheck"] == qa["Config"]["Healthcheck"]
         and qa["Config"]["Healthcheck"]["Test"] ==
         ["CMD", "node", "/opt/omne/app/deploy/docker/health.mjs"],
         "QA image changed original health command")
    need(qa["Config"]["Env"] == base["Config"]["Env"] +
         ["NODE_OPTIONS=--import=/probe/qa-health-delay.mjs"],
         "QA preload must be sole env difference")
    for key in ("User", "Entrypoint", "Cmd", "WorkingDir"):
        need(base["Config"][key] == qa["Config"][key], "QA image config changed: " + key)
    success(commands, "c-probe-inventory")
    probe = one_json(raw(run, commands, "c-probe-inventory"), "c-probe-inventory")
    need(probe == {"file": True, "uid": 0, "gid": 0, "mode": 292,
                   "sha256": inputs["sha256"]["qa-context/qa-health-delay.mjs"]},
         "QA preload file bytes/mode/owner")
    for label in ("c-base-app-inventory", "c-qa-app-inventory"):
        success(commands, label)
    original = json.loads(raw(run, commands, "c-base-app-inventory"))
    delayed = json.loads(raw(run, commands, "c-qa-app-inventory"))
    need(isinstance(original, list) and original == delayed
         and len(original) == expected["app_inventory_entries"]
         and len([x for x in delayed if x["path"] == "BUILD_ID" and x["kind"] == "file"]) == 1,
         "production app files/links/BUILD_ID changed")

    order = [item["label"] for item in evidence["commands"]]
    chain = ["c-build-qa-image", "c-qa-image-inspect", "c-probe-inventory",
             "c-base-app-inventory", "c-qa-app-inventory",
             "lock-validate", "lock-first-start", "lock-root-stat-before",
             "lock-file-stat-before", "lock-center-pre-busy", "lock-logs-before",
             "lock-second-start", "lock-concurrent-stop", "lock-root-stat-after",
             "lock-file-stat-after", "lock-center-post-busy", "lock-logs-after",
             "lock-project-list-before-expiry", "lock-events-before-expiry",
             "lock-center-after-first", "lock-status-after-first",
             "lock-project-list-final", "lock-events-final"]
    need(all(label in commands for label in chain)
         and [order.index(label) for label in chain] == sorted(order.index(label) for label in chain),
         "first/busy/expiry observation order")
    first = commands["lock-first-start"]
    second = commands["lock-second-start"]
    concurrent_stop = commands["lock-concurrent-stop"]
    need(first["returncode"] == 1 and first["observation_expired"] is False
         and first.get("async_local_docker_exec_client") is True and
         raw(run, commands, "lock-first-start") == b"",
         "first start did not finish as failed asynchronous helper")
    for label, item in (("lock-second-start", second),
                        ("lock-concurrent-stop", concurrent_stop)):
        need(item["returncode"] == 1 and item["observation_expired"] is False
             and raw(run, commands, label) == b""
             and raw(run, commands, label, "stderr") == b"omne-center: busy\n",
             label + " must reject from flock with exact busy, not another refusal")
    need(concurrent_stop["argv"] == [*helper, "stop", "--project", project],
         "concurrent stop must target same project")
    def moment(value):
        return datetime.fromisoformat(value)
    need(moment(first["started_utc"]) < moment(second["started_utc"])
         and moment(second["finished_observation_utc"]) <=
             moment(concurrent_stop["started_utc"])
         and moment(concurrent_stop["finished_observation_utc"]) <
             moment(first["finished_observation_utc"]),
         "busy calls did not overlap live first helper")
    pending = evidence.get("first_local_exec_pending_samples", [])
    need({"before concurrent calls", "second start", "after second start",
          "after concurrent stop", "before first helper completes"} <=
         {x["phase"] for x in pending}
         and all(x["returncode"] is None for x in pending),
         "local Docker exec client not observed pending throughout interleaving")
    samples = {x["phase"]: moment(x["time_utc"]) for x in pending}
    need(samples["before concurrent calls"] <= samples["second start"] <=
         moment(second["started_utc"])
         and moment(second["finished_observation_utc"]) <=
             samples["after second start"] <= moment(concurrent_stop["started_utc"])
         and moment(concurrent_stop["finished_observation_utc"]) <=
             samples["after concurrent stop"] <=
             samples["before first helper completes"] <
             moment(first["finished_observation_utc"]),
         "pending snapshots do not bracket both busy calls")
    running_label = evidence["running_sample_label"]
    need(re.fullmatch(r"lock-running-poll-[1-9][0-9]*", running_label)
         and order.index("lock-first-start") < order.index(running_label) <
             order.index("lock-second-start"),
         "running observation not inside first helper window")
    initial = one_inspect(run, commands, running_label, cid)
    before = one_inspect(run, commands, "lock-center-pre-busy", cid)
    after = one_inspect(run, commands, "lock-center-post-busy", cid)
    for item in (initial, before, after):
        need(item["Image"] == qa_id and
             item["Config"]["Labels"]["ai.nemori.omne.project"] == project
             and item["Config"]["Labels"]["ai.nemori.omne.host-build-id"] == build
             and item["State"]["Status"] == "running"
             and item["State"]["Running"] is True
             and item["State"]["Pid"] > 0
             and item["State"]["Health"]["Status"] != "healthy",
             "first exact QA CID not running/unhealthy during lock interleaving")
    need(initial["State"]["StartedAt"] == before["State"]["StartedAt"] ==
         after["State"]["StartedAt"]
         and initial["RestartCount"] == before["RestartCount"] ==
         after["RestartCount"] == 0,
         "second call restarted/replaced first center")
    root_before = stat_line(run, commands, "lock-root-stat-before")
    root_after = stat_line(run, commands, "lock-root-stat-after")
    file_before = stat_line(run, commands, "lock-file-stat-before")
    file_after = stat_line(run, commands, "lock-file-stat-after")
    need(root_before == root_after and file_before == file_after
         and re.fullmatch(r"directory:0:0:700:[1-9][0-9]*", root_before)
         and re.fullmatch(r"regular (?:empty )?file:0:0:600:[1-9][0-9]*", file_before),
         "helper lifecycle lock root/file owner/mode/inode")
    for stream in ("stdout", "stderr"):
        need(raw(run, commands, "lock-logs-after", stream).startswith(
             raw(run, commands, "lock-logs-before", stream)),
             "concurrent call lost earlier center logs")
    for label in ("lock-logs-before", "lock-logs-after",
                  "lock-project-list-before-expiry", "lock-project-list-final",
                  "lock-events-before-expiry", "lock-events-final"):
        success(commands, label)
    for label in ("lock-project-list-before-expiry", "lock-project-list-final"):
        need(raw(run, commands, label) == (cid + "\n").encode(),
             "second call created/replaced a project center")
    def event_actions(label):
        values = [json.loads(line) for line in raw(run, commands, label).splitlines()]
        need(values and all(x.get("Actor", {}).get("ID") == cid for x in values),
             label + " private Engine events absent/wrong ID")
        return values, [x.get("Action", x.get("status")) for x in values]
    early_events, early_actions = event_actions("lock-events-before-expiry")
    need(early_actions.count("create") == early_actions.count("start") == 1
         and "kill" not in early_actions and "die" not in early_actions
         and "restart" not in early_actions,
         "another create/start/TERM occurred before first helper expired")
    need(moment(commands["lock-events-before-expiry"]["finished_observation_utc"]) <
         moment(first["finished_observation_utc"]),
         "pre-expiry Engine sample taken after first completion")
    stderr = raw(run, commands, "lock-first-start", "stderr").decode("utf-8", "strict")
    start_text = f"center-start-request project={project} container={cid} image={qa_id}"
    expiry_text = f"startup-observation-expired project={project} container={cid}"
    term_text = f"term-request container={cid}"
    need(stderr.count(start_text) == stderr.count(expiry_text) ==
         stderr.count(term_text) == 1
         and stderr.index(start_text) < stderr.index(expiry_text) < stderr.index(term_text)
         and "startup-process-failed" not in stderr,
         "first helper did not expire then request one normal TERM")
    results = [json.loads(line) for line in stderr.splitlines() if line.startswith("{")]
    need(results == [{"state": "stopped", "containerId": cid,
                      "exitCode": 0, "clean": True}],
         "first helper lacks same-CID actual clean exit result")
    stopped = one_inspect(run, commands, "lock-center-after-first", cid)
    state = stopped["State"]
    need(stopped["Image"] == qa_id and state["Status"] == "exited"
         and state["Running"] is False and state["ExitCode"] == 0
         and state["StartedAt"] == initial["State"]["StartedAt"]
         and stopped["RestartCount"] == 0
         and stopped["HostConfig"]["RestartPolicy"]["Name"] == "unless-stopped"
         and stopped["Config"]["StopSignal"] == "SIGTERM"
         and stopped["Config"]["StopTimeout"] == -1,
         "first helper completion not same-CID exited0")
    health = state["Health"]
    need(health["Status"] != "healthy" and any(
         x["ExitCode"] == -1 and isinstance(x["Output"], str) and x["Output"]
         for x in health["Log"]), "QA health process not observed timed out")
    status = one_json(raw(run, commands, "lock-status-after-first"),
                      "lock-status-after-first")
    success(commands, "lock-status-after-first")
    need(status["state"] == "exited" and status["containerId"] == cid
         and status["imageId"] == qa_id and status["buildId"] == build
         and status["exitCode"] == 0 and status["restartCount"] == 0,
         "final status concealed actual stopped identity")
    full_events, full_actions = event_actions("lock-events-final")
    kills = [x for x in full_events if x.get("Action", x.get("status")) == "kill"]
    need(full_actions.count("create") == full_actions.count("start") ==
         full_actions.count("kill") == full_actions.count("die") == 1
         and len(kills) == 1
         and kills[0].get("Actor", {}).get("Attributes", {}).get("signal") in
             ("15", "SIGTERM")
         and full_actions.index("create") < full_actions.index("start") <
             full_actions.index("kill") < full_actions.index("die"),
         "first helper actual create/start/TERM/die sequence")

    need(evidence["cleanup_complete"] is True and evidence["cleanup_errors"] == [],
         "fixture cleanup incomplete")
    cleanup = {x["label"]: x for x in evidence["cleanup_commands"]}
    need(len(cleanup) == len(evidence["cleanup_commands"]), "duplicate cleanup command")
    for label in ("cleanup-final-list-container", "cleanup-final-list-volume",
                  "cleanup-final-list-network", "cleanup-inner-project-final-list",
                  "cleanup-inner-fixture-final-list", "cleanup-inner-all-final-list"):
        need(cleanup[label]["returncode"] == 0 and
             raw(run, cleanup, label) == b"", label + " resources remain")
    return {"status": "limited_pass", "scenario": evidence["scenario"],
            "center_id": cid}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=pathlib.Path)
    args = parser.parse_args()
    try:
        print(json.dumps(evaluate(args.run), sort_keys=True))
    except (ValueError, KeyError, TypeError, UnicodeError, OSError, json.JSONDecodeError) as error:
        print(json.dumps({"status": "fail", "reason": str(error)}, sort_keys=True))
        raise SystemExit(1)
