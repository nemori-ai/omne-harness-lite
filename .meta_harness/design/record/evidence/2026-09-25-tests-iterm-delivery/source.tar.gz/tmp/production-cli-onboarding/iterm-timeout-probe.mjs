import { openTerminal } from '../../apps/cli/dist/tui/terminal.js'
try {
 const terminal=await openTerminal('iterm-3.7.1beta1')
 await terminal.stopInput()
 await terminal.restore()
 process.stdout.write('UNEXPECTED_SUCCESS\n')
 process.exitCode=1
} catch(e) {
 process.stdout.write('RESTORE_FINISHED:'+e.message+'\n')
 process.exitCode=0
}
