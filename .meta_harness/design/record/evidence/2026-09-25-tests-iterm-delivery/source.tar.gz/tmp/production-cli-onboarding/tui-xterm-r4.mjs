// Capture output without changing the real TTY, input source or write callbacks.
import { execFileSync } from 'node:child_process'
import { appendFileSync, writeFileSync, readFileSync } from 'node:fs'
const before=execFileSync('stty',['-g'],{stdio:[0,'pipe','pipe'],encoding:'utf8'}).trim()
const raw='/evidence/xterm-r4.raw',result='/evidence/xterm-r4.json'
writeFileSync(raw,'',{flag:'wx'})
const original=process.stdout.write
process.stdout.write=function(chunk,...args){appendFileSync(raw,chunk);return original.call(this,chunk,...args)}
process.on('exit',code=>{
  const after=execFileSync('stty',['-g'],{stdio:[0,'pipe','pipe'],encoding:'utf8'}).trim()
  const output=readFileSync(raw,'utf8')
  const checks={cancelStatus:code===2,termiosRestored:before===after,unicodeInput:output.includes('员工é😀'),pasteBody:output.includes('[201~_tail'),smallWindow:output.includes('Window too small'),modeReset:output.includes('\x1b[?2004l')}
  writeFileSync(result,JSON.stringify({status:Object.values(checks).every(Boolean)?'PASS':'FAIL',checks,code,node:process.version,scope:'Linux XTerm379 ordinary PRIMARY paste, keys, resize and cancel with real TTY; stdout tap only; no IME or full visual width oracle'},null,2)+'\n')
})
process.argv=[process.execPath,'/artifact/app/dist/main.js','tui','--setup','--terminal-profile','xterm-379','--state-dir','/tmp/omne-xterm-r4-state']
await import('/artifact/app/dist/main.js')
