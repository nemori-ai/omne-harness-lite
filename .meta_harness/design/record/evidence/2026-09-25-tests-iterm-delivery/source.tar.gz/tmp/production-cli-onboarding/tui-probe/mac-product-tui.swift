import Foundation
import AppKit
import Carbon
func main() throws {
let base = CommandLine.arguments[1]
let node = "/Users/pandazki/.local/share/fnm/node-versions/v24.21.0/installation/bin/node"
func apple(_ script: String) throws -> String {
 let p=Process();p.executableURL=URL(fileURLWithPath:"/usr/bin/osascript");p.arguments=["-e",script]
 let out=Pipe();p.standardOutput=out;try p.run();p.waitUntilExit()
 guard p.terminationStatus==0 else { throw NSError(domain:"AppleScript",code:Int(p.terminationStatus)) }
 return String(data:out.fileHandleForReading.readDataToEndOfFile(),encoding:.utf8)!.trimmingCharacters(in:.whitespacesAndNewlines)
}
func waitStage(_ wanted:String) throws {
 let end=Date().addingTimeInterval(20)
 while Date()<end {
  let s=(try? String(contentsOfFile:base+"/mac-source-r2.stage",encoding:.utf8)) ?? ""
  if s==wanted { return }; if s=="done" { throw NSError(domain:"probe-ended",code:1) }
  Thread.sleep(forTimeInterval:0.05)
 }
 throw NSError(domain:"stage-timeout",code:1)
}
func sourceID(_ source:TISInputSource)->String {
 let ptr=TISGetInputSourceProperty(source,kTISPropertyInputSourceID)!
 return Unmanaged<CFString>.fromOpaque(ptr).takeUnretainedValue() as String
}
let command=node+" "+base+"/mac-product-tui.mjs "+base+" "+CommandLine.arguments[2]
let window=try apple("with timeout of 15 seconds\ntell application \"iTerm\"\nset w to create window with default profile command \""+command+"\"\nset bounds of w to {30, 50, 1000, 800}\nactivate\nreturn id of w\nend tell\nend timeout")
try window.write(toFile:base+"/mac-product-r1.window",atomically:true,encoding:.utf8)
defer { _ = try? apple("tell application \"iTerm\" to close window id "+window) }
func waitText(_ wanted:String) throws {
 let end=Date().addingTimeInterval(15)
 while Date()<end {
  let s=(try? String(contentsOfFile:base+"/mac-product-r1.raw",encoding:.utf8)) ?? ""
  if s.contains(wanted) { return }
  Thread.sleep(forTimeInterval:0.05)
 }
 throw NSError(domain:"screen-timeout-"+wanted,code:1)
}
try waitText("Connection and login")
_ = try apple("tell application \"System Events\" to tell process \"iTerm2\"\nkeystroke \"2\"\nkey code 36\nend tell")
try waitText("Login identifier")
// Preserve all pasteboard data only in memory; never serialize or log user clipboard contents.
let board=NSPasteboard.general
let saved=(board.pasteboardItems ?? []).map { item in item.types.compactMap { type -> (NSPasteboard.PasteboardType,Data)? in guard let data=item.data(forType:type) else{return nil};return(type,data) } }
board.clearContents();board.setString("é😀\u{1b}[201~_tail",forType:.string)
let ours=board.changeCount
func restoreClipboard() {
 if board.changeCount != ours { return }
 board.clearContents();let items=saved.map { row -> NSPasteboardItem in let item=NSPasteboardItem();for(type,data)in row{item.setData(data,forType:type)};return item };board.writeObjects(items)
}
defer { restoreClipboard() }
_ = try apple("tell application \"iTerm\" to select window id "+window)
_ = try apple("tell application \"System Events\" to tell process \"iTerm2\" to keystroke \"v\" using command down")
try waitText("[201~_tail");restoreClipboard()
let original=TISCopyCurrentKeyboardInputSource().takeRetainedValue()
let sources=TISCreateInputSourceList(nil,false).takeRetainedValue() as! [TISInputSource]
guard let pinyin=sources.first(where:{sourceID($0)=="com.tencent.inputmethod.wetype.pinyin"}) else{throw NSError(domain:"Pinyin-unavailable",code:1)}
guard TISSelectInputSource(pinyin)==noErr else{throw NSError(domain:"Pinyin-select",code:1)}
defer { if sourceID(TISCopyCurrentKeyboardInputSource().takeRetainedValue())==sourceID(pinyin){TISSelectInputSource(original)} }
Thread.sleep(forTimeInterval:0.3)
print("Selected input source: " + sourceID(TISCopyCurrentKeyboardInputSource().takeRetainedValue()))
_ = try apple("tell application \"iTerm\" to select window id "+window)
print("Before keys: " + sourceID(TISCopyCurrentKeyboardInputSource().takeRetainedValue()))
_ = try apple("tell application \"System Events\" to tell process \"iTerm2\" to key code 56")
defer { _ = try? apple("tell application \"System Events\" to tell process \"iTerm2\" to key code 56") }
Thread.sleep(forTimeInterval:0.3)
_ = try apple("tell application \"System Events\" to tell process \"iTerm2\"\nkey code 45\nkey code 34\nkey code 4\nkey code 0\nkey code 31\nkey code 49\nend tell")
try waitText("你好")
_ = try apple("tell application \"iTerm\" to set bounds of window id "+window+" to {30, 50, 450, 250}")
try waitText("Window too small")
_ = try apple("tell application \"iTerm\" to set bounds of window id "+window+" to {30, 50, 1000, 800}")
Thread.sleep(forTimeInterval:0.3)
_ = try apple("tell application \"System Events\" to tell process \"iTerm2\" to keystroke \"c\" using control down")
let deadline=Date().addingTimeInterval(15)
while !FileManager.default.fileExists(atPath:base+"/mac-product-r1.json") && Date()<deadline {Thread.sleep(forTimeInterval:0.05)}
let result=try JSONSerialization.jsonObject(with:Data(contentsOf:URL(fileURLWithPath:base+"/mac-product-r1.json"))) as! [String:Any]
guard result["status"] as? String == "PASS" else {throw NSError(domain:"Source-probe-failed",code:1)}
print("Completed own iTerm window " + window + "; clipboard restored if unchanged; input source restored on exit")

}
do { try main() } catch { print("Source probe failed: \(error)"); exit(1) }
