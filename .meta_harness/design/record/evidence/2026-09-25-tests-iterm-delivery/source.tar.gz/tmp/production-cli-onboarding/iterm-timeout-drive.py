import os,pty,subprocess,termios,fcntl,struct,select,time,json,sys
node,script,scenario,out=sys.argv[1:]
master,slave=pty.openpty();fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',40,110,0,0));original=termios.tcgetattr(slave)
p=subprocess.Popen([node,script],stdin=slave,stdout=slave,stderr=slave,start_new_session=True)
transcript=b'';pending=b'';queries=0;partial_at=None;observed=False;finished=False;deadline=time.monotonic()+15
try:
 while p.poll() is None and time.monotonic()<deadline:
  if select.select([master],[],[],.02)[0]:
   chunk=os.read(master,65536);transcript+=chunk;pending+=chunk
   while b'\x1b[?2004$p' in pending:
    _,pending=pending.split(b'\x1b[?2004$p',1);queries+=1
    target=2 if scenario=='startup' else 3
    if queries==target:
     os.write(master,b'\x1b[?2004;');partial_at=time.monotonic()
    else:os.write(master,b'\x1b[?2004;'+(b'1' if queries==2 else b'2')+b'$y')
  if partial_at and not finished and time.monotonic()-partial_at>2.5:
   assert p.poll() is None,'query timeout released process with unfinished report'
   assert termios.tcgetattr(slave)!=original,'OS input returned while report was incomplete'
   assert b'RESTORE_FINISHED' not in transcript
   observed=True;finished=True;os.write(master,(b'1' if scenario=='startup' else b'2')+b'$y')
 assert p.poll() is not None,'probe did not settle after actual report completion'
 while select.select([master],[],[],0)[0]:
  try:transcript+=os.read(master,65536)
  except OSError:break
 assert observed and finished and p.returncode==0
 assert b'RESTORE_FINISHED:' in transcript and b'UNEXPECTED_SUCCESS' not in transcript
 assert termios.tcgetattr(slave)==original
 json.dump({'status':'PASS','scenario':scenario,'queries':queries,'heldBeyondQueryTimeout':observed,'termiosRestored':True,'transcript':transcript.decode(),'scope':'real PTY with scripted DECRQM responses; actual product startup/restore timeout code, not GUI emulator'},open(out,'w'),indent=2)
finally:
 if p.poll() is None:p.kill();p.wait()
 os.close(master);os.close(slave)
