import { execFileSync } from 'node:child_process'
import { appendFileSync, writeFileSync, readFileSync, mkdtempSync, realpathSync } from 'node:fs'
import { resolve } from 'node:path'
const base=process.argv[2], app=resolve(process.argv[3]), prefix=base+'/mac-product-r1'
const attrs=()=>execFileSync('/bin/stty',['-g'],{stdio:[0,'pipe','pipe'],encoding:'utf8'}).trim()
const before=attrs(), state=realpathSync(mkdtempSync('/tmp/omne-iterm-product-'))+'/state'
async function query(){
 const raw=process.stdin.isRaw??false;let buffer='',handler,timer
 process.stdin.setRawMode(true);process.stdin.resume()
 try{return await new Promise((resolve,reject)=>{handler=b=>{buffer+=b.toString('latin1');const m=/\x1b\[\?2004;([0-4])\$y/.exec(buffer);if(m)resolve(Number(m[1]))};process.stdin.on('data',handler);timer=setTimeout(()=>reject(Error('query timeout')),3000);process.stdout.write('\x1b[?2004$p')})}
 finally{clearTimeout(timer);process.stdin.off('data',handler);process.stdin.pause();process.stdin.setRawMode(raw)}
}
const initial=await query()
const raw=prefix+'.raw';writeFileSync(raw,'',{flag:'wx'})
const original=process.stdout.write
process.stdout.write=function(chunk,...args){appendFileSync(raw,chunk);return original.call(this,chunk,...args)}
process.argv=[process.execPath,app,'tui','--setup','--terminal-profile','iterm-3.7.1beta1','--state-dir',state]
await import(app)
process.stdout.write=original
const code=process.exitCode??0, after=attrs(), final=await query(), output=readFileSync(raw,'utf8')
const checks={cancelStatus:code===2,termiosRestored:before===after&&attrs()===before,modeRestored:final===initial,ime:output.includes('你好'),unicodePaste:output.includes('é😀'),filteredPaste:output.includes('[201~_tail'),smallWindow:output.includes('Window too small')}
writeFileSync(prefix+'.json',JSON.stringify({status:Object.values(checks).every(Boolean)?'PASS':'FAIL',checks,code,initial,final,state,node:process.version,scope:'actual product TUI in iTerm3.7.1beta1: ordinary keys, WeType Pinyin composition, plain-text CmdV, resize and CtrlC; stdout tap preserves real TTY/write callbacks; no business submission or cell-level visual oracle'},null,2)+'\n')
process.stdout.write('\r\nOMNE own product probe complete\r\n')
