#!/bin/sh
set -eu
xterm -u8 -xrm 'XTerm*allowPasteControls: false' -geometry 110x40 -title OMNE-TUI-R4 -e node /scripts/tui-xterm-r4.mjs &
terminal_pid=$!
trap 'kill "$terminal_pid" 2>/dev/null || true' EXIT
wait_for() {
  n=0
  while ! grep -q "$1" /evidence/xterm-r4.raw 2>/dev/null; do
    n=$((n+1)); [ "$n" -lt 100 ] || { echo "Timeout: $1"; exit 1; }
    sleep .1
  done
}
wait_for 'One action per setup'
window=$(xdotool search --name '^OMNE-TUI-R4$')
xdotool windowfocus --sync "$window"
xdotool type --clearmodifiers '2'
xdotool key Return
wait_for 'Login identifier'
printf '员工é😀\033[201~_tail' | xclip -selection primary -quiet >/evidence/xclip.log 2>&1 &
clip_pid=$!
sleep .2
xdotool key --clearmodifiers shift+Insert
wait_for '_tail'
xdotool windowsize "$window" 300 120
wait_for 'Window too small'
xdotool windowsize "$window" 900 700
sleep .3
xdotool key --clearmodifiers ctrl+c
wait "$terminal_pid" || true
kill "$clip_pid" 2>/dev/null || true
trap - EXIT
cat /evidence/xterm-r4.json
node -e 'const r=require("/evidence/xterm-r4.json");if(r.status!=="PASS")process.exit(1)'
