// 进程入口：`node apps/tenancy-host/dist/cli.js keygen <dir>` 或 `… serve`（子命令见 main.ts）。
if (process.argv.length === 3 && process.argv[2] === '--version') {
  const { printBuildVersion } = await import('./build-version.ts')
  process.stdout.on('error', () => {})
  process.stderr.on('error', () => {})
  process.exitCode = await printBuildVersion({
    stdout: text =>
      new Promise((yes, no) => process.stdout.write(text, error => (error ? no(error) : yes()))),
    stderr: text =>
      new Promise((yes, no) => process.stderr.write(text, error => (error ? no(error) : yes()))),
  })
} else {
  const { main } = await import('./main.ts')
  process.exitCode = await main(process.argv.slice(2))
}
