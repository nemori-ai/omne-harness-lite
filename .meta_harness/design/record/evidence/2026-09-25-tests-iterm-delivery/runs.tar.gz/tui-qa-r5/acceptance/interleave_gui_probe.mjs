// D054 iTerm provider in a real GUI window. A terminal DECRQM reply may be
// interleaved into ordinary CmdV bracketed-paste END bytes.
import { writeFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'

const [modulePath, resultPath, stagePath] = process.argv.slice(2)
const before = execFileSync('/bin/stty', ['-g'], { encoding: 'utf8', stdio: [0, 'pipe', 'pipe'] }).trim()
const chunks = []
const events = []
let input, asked = false, failure, paste
const observe = chunk => {
  chunks.push(Buffer.from(chunk))
  if (!asked && chunks.some(item => item.includes(Buffer.from('\x1b[200~')))) {
    asked = true
    process.stdout.write('\x1b[?2004$p')
  }
}
try {
  const { openTerminal } = await import(modulePath)
  input = await openTerminal('iterm-3.7.1beta1')
  process.stdin.on('data', observe)
  const settled = new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('paste-event-timeout')), 12000)
    input.listen(event => {
      events.push(event)
      if (event.kind === 'paste' || event.kind === 'invalid' || event.kind === 'eof') {
        clearTimeout(timer)
        resolve(event)
      }
    }, () => {})
  })
  writeFileSync(stagePath, 'paste-ready')
  process.stdout.write('\r\nD054 independent interleave probe ready\r\n')
  paste = await settled
} catch (error) {
  failure = String(error?.message ?? error)
} finally {
  process.stdin.off('data', observe)
  if (input) {
    try { await input.stopInput(); await input.restore() }
    catch (error) { failure = `restore: ${String(error?.message ?? error)}` }
  }
}
const after = execFileSync('/bin/stty', ['-g'], { encoding: 'utf8', stdio: [0, 'pipe', 'pipe'] }).trim()
const raw = Buffer.concat(chunks)
writeFileSync(resultPath + '.raw', raw)
const report = Buffer.from('\x1b[?2004;1$y')
const marker = Buffer.from('\x1b[201~')
const reportIndex = raw.indexOf(report)
const withoutReport = reportIndex < 0 ? raw : Buffer.concat([raw.subarray(0, reportIndex), raw.subarray(reportIndex + report.length)])
const rawEnd = raw.indexOf(marker), cleanEnd = withoutReport.indexOf(marker)
const expected = 'a'.repeat(758)
const result = {
  status: !failure && paste?.kind === 'paste' && paste.text === expected &&
    reportIndex >= 0 && rawEnd < 0 && cleanEnd >= 0 && before === after ? 'PASS' : 'FAIL',
  error: failure,
  reportIndex, rawEnd, cleanEnd,
  rawChunkSizes: chunks.map(item => item.length),
  pasteLength: paste?.text?.length,
  pasteMatches: paste?.text === expected,
  events: events.map(event => ({ kind:event.kind, textLength:event.text?.length })),
  termiosRestored: before === after,
  scope: 'actual iTerm plain-text CmdV with provider DECRQM query after first paste chunk',
}
writeFileSync(resultPath, JSON.stringify(result, null, 2) + '\n')
writeFileSync(stagePath, 'done')
process.stdout.write('\r\n' + result.status + ' D054 interleave probe ended\r\n')
process.exitCode = result.status === 'PASS' ? 0 : 1
