// Runs the detached D054 product entry in one QA-owned real iTerm session.
// Args: evidence-directory CLI-main.js. The stdout tap preserves the real
// write callback path while retaining raw bytes for the independent oracle.
import { execFileSync } from 'node:child_process'
import { appendFileSync, mkdtempSync, readFileSync, realpathSync, rmSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
const [evidence,entry]=process.argv.slice(2)
if (!evidence || !entry) throw new Error('missing probe paths')
const raw=join(evidence,'gui-product.raw')
const output=join(evidence,'gui-product.json')
const attrs=()=>execFileSync('/bin/stty',['-g'],{stdio:[0,'pipe','pipe'],encoding:'utf8'}).trim()
const before=attrs(), root=realpathSync(mkdtempSync('/tmp/omne-qa-d054-gui-'))
async function mode(){
  const wasRaw=process.stdin.isRaw??false
  let listener,timer,bytes=''
  process.stdin.setRawMode(true);process.stdin.resume()
  try {
    return await new Promise((resolve,reject)=>{
      listener=chunk=>{bytes+=chunk.toString('latin1');const found=/\x1b\[\?2004;([0-4])\$y/.exec(bytes);if(found)resolve(Number(found[1]))}
      process.stdin.on('data',listener)
      timer=setTimeout(()=>reject(new Error('mode query timeout')),3000)
      process.stdout.write('\x1b[?2004$p')
    })
  } finally {
    clearTimeout(timer);process.stdin.off('data',listener);process.stdin.pause();process.stdin.setRawMode(wasRaw)
  }
}
const initial=await mode()
writeFileSync(raw,'',{flag:'wx'})
const original=process.stdout.write
process.stdout.write=function(chunk,...args){appendFileSync(raw,chunk);return original.call(this,chunk,...args)}
let code,after,final,error
try {
  process.argv=[process.execPath,resolve(entry),'tui','--setup','--terminal-profile','iterm-3.7.1beta1',
                '--state-dir',join(root,'state')]
  await import(resolve(entry))
  code=process.exitCode??0
} catch (caught) {
  error=String(caught?.message??caught)
} finally {
  process.stdout.write=original
  after=attrs()
  try{final=await mode()}catch(caught){error=String(caught?.message??caught)}
  const bytes=readFileSync(raw)
  const text=bytes.toString('utf8')
  const checks={
    inputCancelled:code===2,
    termiosRestored:before===after&&attrs()===before,
    modeRestored:initial===2&&final===initial,
    ordinaryPasteData:text.includes('é😀')&&text.includes('[201~_tail'),
    imeCommitted:text.includes('你好'),
    smallWindowPause:text.includes('Window too small'),
    fullIdentityAfterResize:text.lastIndexOf('Center: unknown')>text.lastIndexOf('Window too small'),
    noAlternateScreen:!bytes.includes(Buffer.from('\x1b[?1049h')),
  }
  writeFileSync(output,JSON.stringify({status:Object.values(checks).every(Boolean)&&!error?'PASS':'FAIL',
    checks,code,initial,final,error,platform:process.platform,node:process.version,
    scope:'actual detached D054 product TUI in own iTerm3.7.1beta1 window; WeType Pinyin only; no governance target submission'},null,2)+'\n')
  rmSync(root,{recursive:true,force:true})
  process.stdout.write('\r\nD054 independent GUI probe ended\r\n')
}
