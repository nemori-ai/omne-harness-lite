#!/usr/bin/env python3
"""D054 direct-terminal PTY interleave; the mode reply is terminal-side input.

Usage: interleave.py NODE PROBE TERMINAL_MODULE EVIDENCE_DIR. This covers the
fixed provider on a real OS PTY, not an actual iTerm GUI CmdV interaction.
"""
import errno, fcntl, json, os, pty, select, struct, subprocess, sys, termios, time
from pathlib import Path

NODE, PROBE, MODULE, directory = sys.argv[1:5]
evidence = Path(directory)
evidence.mkdir(parents=True, exist_ok=True)
master, slave = pty.openpty()
fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack('HHHH', 40, 110, 0, 0))
original = termios.tcgetattr(slave)
proc = subprocess.Popen([NODE, PROBE, MODULE, str(evidence/'probe.json')],
                        stdin=slave, stdout=slave, stderr=slave,
                        start_new_session=True,
                        env={**os.environ, 'TERM':'xterm', 'LC_ALL':'en_US.UTF-8'})
raw = bytearray()
buffer = bytearray()
queries = 0
sent = False
deadline = time.monotonic() + 15
try:
    while time.monotonic() < deadline and proc.poll() is None:
        ready, _, _ = select.select([master], [], [], .02)
        if ready:
            try: chunk = os.read(master, 65536)
            except OSError as error:
                if error.errno != errno.EIO: raise
                chunk = b''
            if chunk:
                raw.extend(chunk)
                buffer.extend(chunk)
                marker = b'\x1b[?2004$p'
                while marker in buffer:
                    head, tail = buffer.split(marker, 1)
                    buffer = bytearray(tail)
                    queries += 1
                    os.write(master, b'\x1b[?2004;' + (b'1' if queries == 2 else b'2') + b'$y')
                if not sent and b'READY\r\n' in raw:
                    sent = True
                    body = 'alpha你好😀omega'.encode('utf8')
                    # The legal DECRQM report lands between END sentinel bytes.
                    for piece in [b'\x1b', b'[200~' + body[:7], body[7:] + b'\x1b[20',
                                  b'\x1b[?2004;1$', b'y', b'1~']:
                        os.write(master, piece)
        # All waits are on output/readiness or the overall bounded deadline.
    timed_out = proc.poll() is None
    if timed_out: proc.kill()
    exit_code = proc.wait(timeout=3)
    while select.select([master], [], [], 0)[0]:
        try: extra = os.read(master, 65536)
        except OSError: break
        if not extra: break
        raw.extend(extra)
    restored = termios.tcgetattr(slave) == original
    probe = json.loads((evidence/'probe.json').read_text()) if (evidence/'probe.json').exists() else None
    passed = (not timed_out and exit_code == 0 and queries == 3 and sent and restored and
              probe and probe.get('status') == 'PASS' and probe.get('termiosRestored') and
              probe.get('events') == [{'kind':'paste','text':'alpha你好😀omega'}] and
              b'\x1b[?2004h' in raw and b'\x1b[?2004l' in raw)
    result = {'status':'PASS' if passed else 'FAIL', 'exitCode':exit_code,
              'queries':queries, 'pasteSent':sent, 'termiosRestored':restored,
              'timedOut':timed_out, 'probe':probe,
              'modeEnableObserved':b'\x1b[?2004h' in raw,
              'modeDisableObserved':b'\x1b[?2004l' in raw}
    (evidence/'driver.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    (evidence/'terminal.raw').write_bytes(raw)
    print(result['status'], 'D054 legal report inside paste END sentinel', json.dumps(result, ensure_ascii=False))
    sys.exit(0 if passed else 1)
finally:
    if proc.poll() is None: proc.kill(); proc.wait()
    os.close(master); os.close(slave)
