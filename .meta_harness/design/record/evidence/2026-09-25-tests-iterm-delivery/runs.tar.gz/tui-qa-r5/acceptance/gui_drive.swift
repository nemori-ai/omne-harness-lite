// D054 independent GUI acceptance. Creates and closes only the window whose
// window ID AND session ID this process obtained. Clipboard data stays in RAM.
import Foundation
import AppKit
import Carbon

func main() throws {
let args=CommandLine.arguments
if args.count != 4 { throw NSError(domain:"usage: gui_drive.swift EVIDENCE NODE CLI",code:1) }
let evidence=URL(fileURLWithPath:args[1]).standardizedFileURL.path
let node=args[2],cli=args[3]
func shell(_ command:String,_ arguments:[String]) throws -> String {
  let process=Process();process.executableURL=URL(fileURLWithPath:command);process.arguments=arguments
  let pipe=Pipe();process.standardOutput=pipe
  let errors=Pipe();process.standardError=errors
  try process.run();process.waitUntilExit()
  guard process.terminationStatus==0 else {
    let detail=String(data:errors.fileHandleForReading.readDataToEndOfFile(),encoding:.utf8) ?? "unknown command failure"
    throw NSError(domain:"command-failed: "+detail.prefix(600),code:Int(process.terminationStatus))
  }
  return String(data:pipe.fileHandleForReading.readDataToEndOfFile(),encoding:.utf8)!.trimmingCharacters(in:.whitespacesAndNewlines)
}
func apple(_ script:String) throws -> String { try shell("/usr/bin/osascript",["-e",script]) }
func quoteApple(_ text:String) -> String { "\"" + text.replacingOccurrences(of:"\\",with:"\\\\").replacingOccurrences(of:"\"",with:"\\\"") + "\"" }
func quoteShell(_ value:String) -> String { "'" + value.replacingOccurrences(of:"'",with:"'\"'\"'") + "'" }
let probe=URL(fileURLWithPath:#filePath).deletingLastPathComponent().appendingPathComponent("gui_probe.mjs").path
let command=[node,probe,evidence,cli+"/dist/main.js"].map(quoteShell).joined(separator:" ")
let born=try apple("with timeout of 15 seconds\ntell application \"iTerm\"\nset w to create window with default profile command " + quoteApple(command) + "\nactivate\nset ownWindowId to id of w\nset ownSessionId to id of current session of w\nreturn (ownWindowId as string) & \"|\" & ownSessionId\nend tell\nend timeout")
let parts=born.split(separator:"|",maxSplits:1).map(String.init)
if parts.count != 2 { throw NSError(domain:"own window/session identity unavailable",code:1) }
let window=parts[0],session=parts[1]
try (window+"|"+session).write(toFile:evidence+"/own-window-id.txt",atomically:true,encoding:.utf8)
func ownExists() -> Bool {
  let script="tell application \"iTerm\"\nif not (exists window id " + window + ") then return \"gone\"\nif (id of current session of window id " + window + ") is not " + quoteApple(session) + " then return \"changed\"\nreturn \"own\"\nend tell"
  return (try? apple(script))=="own"
}
defer {
  if ownExists() { _ = try? apple("tell application \"iTerm\" to close window id " + window) }
}
func waitRaw(_ wanted:String,seconds:Double=20) throws {
  let deadline=Date().addingTimeInterval(seconds)
  while Date()<deadline {
    if !ownExists() {throw NSError(domain:"own-window-gone",code:1)}
    if let data=try? Data(contentsOf:URL(fileURLWithPath:evidence+"/gui-product.raw")),
       let text=String(data:data,encoding:.utf8),text.contains(wanted) {return}
    Thread.sleep(forTimeInterval:0.05)
  }
  throw NSError(domain:"gui-predicate-timeout:"+wanted,code:1)
}
func sendOwn(_ body:String) throws {
  if !ownExists() {throw NSError(domain:"own-window-gone",code:1)}
  let check="tell application \"iTerm\"\nif not (exists window id " + window + ") then error \"own window gone\"\nif (id of current session of window id " + window + ") is not " + quoteApple(session) + " then error \"session changed\"\nselect window id " + window + "\nactivate\nif (id of current window) is not " + window + " then error \"wrong current window\"\nend tell\n"
  _ = try apple(check + "tell application \"System Events\" to tell process \"iTerm2\"\n"+body+"\nend tell")
}
func boundsOwn(_ rect:String) throws {
  if !ownExists() {throw NSError(domain:"own-window-gone",code:1)}
  _ = try apple("tell application \"iTerm\" to set bounds of window id " + window + " to " + rect)
}
func sourceID(_ source:TISInputSource)->String {
  let ptr=TISGetInputSourceProperty(source,kTISPropertyInputSourceID)!
  return Unmanaged<CFString>.fromOpaque(ptr).takeUnretainedValue() as String
}
let board=NSPasteboard.general
let originalSource=TISCopyCurrentKeyboardInputSource().takeRetainedValue()
var selectedSource:String?=nil
defer {
  if let chosen=selectedSource,
     sourceID(TISCopyCurrentKeyboardInputSource().takeRetainedValue())==chosen {
    _=TISSelectInputSource(originalSource)
  }
}
var saved:[[(NSPasteboard.PasteboardType,Data)]]?=nil
var ourChangeCount:Int?=nil
func restoreClipboard() {
  guard let saved=saved,let ours=ourChangeCount,board.changeCount==ours else{return}
  board.clearContents()
  let items=saved.map { row -> NSPasteboardItem in
    let item=NSPasteboardItem();for (type,data) in row {item.setData(data,forType:type)};return item
  }
  board.writeObjects(items)
  ourChangeCount=nil
}
defer {restoreClipboard()}

do {
  try waitRaw("Connection and login")
  try boundsOwn("{30, 50, 1000, 800}")
  try sendOwn("keystroke \"3\"\nkey code 36")
  try waitRaw("Login identifier")
  saved=(board.pasteboardItems ?? []).map { item in item.types.compactMap { type -> (NSPasteboard.PasteboardType,Data)? in
    guard let data=item.data(forType:type) else{return nil};return(type,data)
  }}
  board.clearContents();board.setString("é😀\u{1b}[201~_tail",forType:.string)
  ourChangeCount=board.changeCount
  try sendOwn("keystroke \"v\" using command down")
  try waitRaw("[201~_tail")
  restoreClipboard()
  let sources=TISCreateInputSourceList(nil,false).takeRetainedValue() as! [TISInputSource]
  guard let pinyin=sources.first(where:{sourceID($0)=="com.tencent.inputmethod.wetype.pinyin"}) else {
    throw NSError(domain:"WeType-unavailable",code:1)
  }
  guard TISSelectInputSource(pinyin)==noErr else {throw NSError(domain:"WeType-select-failed",code:1)}
  selectedSource=sourceID(pinyin)
  // WeType's own Chinese/English toggle is a real key in this owned window.
  try sendOwn("key code 56")
  try sendOwn("key code 45\nkey code 34\nkey code 4\nkey code 0\nkey code 31\nkey code 49")
  try waitRaw("你好")
  try boundsOwn("{30, 50, 450, 250}")
  try waitRaw("Window too small")
  try boundsOwn("{30, 50, 1000, 800}")
  try waitRaw("Center: unknown")
  try sendOwn("keystroke \"c\" using control down")
  let deadline=Date().addingTimeInterval(20)
  while Date()<deadline && !FileManager.default.fileExists(atPath:evidence+"/gui-product.json") {
    Thread.sleep(forTimeInterval:0.05)
  }
  let data=try Data(contentsOf:URL(fileURLWithPath:evidence+"/gui-product.json"))
  let result=try JSONSerialization.jsonObject(with:data) as! [String:Any]
  guard result["status"] as? String == "PASS" else {throw NSError(domain:"product-probe-failed",code:1)}
  print("PASS own iTerm window/session, WeType Pinyin, CmdV, resize, CtrlC, mode restoration")
} catch {
  throw error
}
}
do {try main()} catch {print("FAIL limited GUI QA: \(error)");exit(1)}
