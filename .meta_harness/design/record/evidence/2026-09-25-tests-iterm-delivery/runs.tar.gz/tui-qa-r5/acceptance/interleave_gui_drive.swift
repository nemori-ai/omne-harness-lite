// D054 independent real-iTerm CmdV acceptance. Only this script's own window
// and session may receive keys; clipboard original stays in memory.
import Foundation
import AppKit

func main() throws {
  let args=CommandLine.arguments
  if args.count != 4 {throw NSError(domain:"usage: DRIVE EVIDENCE NODE MODULE",code:1)}
  let evidence=URL(fileURLWithPath:args[1]).standardizedFileURL.path
  let node=args[2],module=args[3]
  let probe=URL(fileURLWithPath:#filePath).deletingLastPathComponent().appendingPathComponent("interleave_gui_probe.mjs").standardizedFileURL.path
  func shell(_ command:String,_ arguments:[String]) throws -> String {
    let process=Process();process.executableURL=URL(fileURLWithPath:command);process.arguments=arguments
    let out=Pipe(),err=Pipe();process.standardOutput=out;process.standardError=err
    try process.run();process.waitUntilExit()
    guard process.terminationStatus==0 else {
      let detail=String(data:err.fileHandleForReading.readDataToEndOfFile(),encoding:.utf8) ?? "unknown"
      throw NSError(domain:"command-failed: "+detail.prefix(600),code:Int(process.terminationStatus))
    }
    return String(data:out.fileHandleForReading.readDataToEndOfFile(),encoding:.utf8)!.trimmingCharacters(in:.whitespacesAndNewlines)
  }
  func apple(_ script:String) throws -> String {try shell("/usr/bin/osascript",["-e",script])}
  func qApple(_ value:String)->String {"\""+value.replacingOccurrences(of:"\\",with:"\\\\").replacingOccurrences(of:"\"",with:"\\\"")+"\""}
  func qShell(_ value:String)->String {"'"+value.replacingOccurrences(of:"'",with:"'\"'\"'")+"'"}
  let result=evidence+"/gui-interleave.json",stage=evidence+"/gui-interleave.stage"
  let command=[node,probe,module,result,stage].map(qShell).joined(separator:" ")
  let born=try apple("with timeout of 15 seconds\ntell application \"iTerm\"\nset w to create window with default profile command "+qApple(command)+"\nactivate\nset ownWindowId to id of w\nset ownSessionId to id of current session of w\nreturn (ownWindowId as string) & \"|\" & ownSessionId\nend tell\nend timeout")
  let parts=born.split(separator:"|",maxSplits:1).map(String.init)
  if parts.count != 2 {throw NSError(domain:"own-identity-unavailable",code:1)}
  let window=parts[0],session=parts[1]
  try born.write(toFile:evidence+"/own-window-id.txt",atomically:true,encoding:.utf8)
  func ownExists()->Bool {
    let script="tell application \"iTerm\"\nif not (exists window id "+window+") then return \"gone\"\nif (id of current session of window id "+window+") is not "+qApple(session)+" then return \"changed\"\nreturn \"own\"\nend tell"
    return (try? apple(script))=="own"
  }
  defer {if ownExists(){_ = try? apple("tell application \"iTerm\" to close window id "+window)}}
  func waitStage(_ wanted:String,seconds:Double=20) throws {
    let deadline=Date().addingTimeInterval(seconds)
    while Date()<deadline {
      let value=(try? String(contentsOfFile:stage,encoding:.utf8)) ?? ""
      if value==wanted {return}
      if !ownExists() {throw NSError(domain:"own-window-gone-before-"+wanted,code:1)}
      Thread.sleep(forTimeInterval:0.05)
    }
    throw NSError(domain:"stage-timeout:"+wanted,code:1)
  }
  try waitStage("paste-ready")
  let board=NSPasteboard.general
  let saved=(board.pasteboardItems ?? []).map { item in item.types.compactMap { type -> (NSPasteboard.PasteboardType,Data)? in
    guard let data=item.data(forType:type) else{return nil};return(type,data)
  }}
  board.clearContents();board.setString(String(repeating:"a",count:758),forType:.string)
  let ownChangeCount=board.changeCount
  func restoreBoard() {
    guard board.changeCount==ownChangeCount else{return}
    board.clearContents()
    let items=saved.map { row -> NSPasteboardItem in
      let item=NSPasteboardItem();for(type,data) in row{item.setData(data,forType:type)};return item
    }
    board.writeObjects(items)
  }
  defer {restoreBoard()}
  if !ownExists(){throw NSError(domain:"own-window-gone-before-paste",code:1)}
  let ownCheck="tell application \"iTerm\"\nif not (exists window id "+window+") then error \"own window gone\"\nif (id of current session of window id "+window+") is not "+qApple(session)+" then error \"session changed\"\nselect window id "+window+"\nactivate\nif (id of current window) is not "+window+" then error \"wrong current window\"\nend tell\n"
  _ = try apple(ownCheck+"tell application \"System Events\" to tell process \"iTerm2\" to keystroke \"v\" using command down")
  let deadline=Date().addingTimeInterval(20)
  while Date()<deadline && !FileManager.default.fileExists(atPath:result){Thread.sleep(forTimeInterval:0.05)}
  let data=try Data(contentsOf:URL(fileURLWithPath:result))
  let object=try JSONSerialization.jsonObject(with:data) as! [String:Any]
  guard object["status"] as? String == "PASS" else {throw NSError(domain:"interleave-oracle-failed",code:1)}
  print("PASS own iTerm CmdV: legal DECRQM inside paste END, body intact, termios restored")
}
do {try main()} catch {print("FAIL D054 actual iTerm interleave: \(error)");exit(1)}
