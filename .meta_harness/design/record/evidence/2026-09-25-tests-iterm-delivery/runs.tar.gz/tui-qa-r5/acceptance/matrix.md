# D054 iTerm profile 的独立有限验收

被测制品：`tmp/production-cli-onboarding/omne-cli-d054-r1.tar.gz` SHA-256 `4fd9f7c946b1cc1f5472728568025969469524a3b54e743c0cf39597d345c131`，解包 `/private/tmp/omne-cli-d051-audit-bnic5nj8/app`，BUILD_ID `ee664ae701a2e8b398ccd029d28cf2408658ddd6e2efe4f1753bbfeaf787cc6a`。契约 CQ2 v2 S2/S7/S8/S10/S11 与 D054 iTerm 具名 provider 决定；前置为实际iTerm3.7.1beta1、普通键/普通纯文本CmdV、直接独占TTY、WeType Pinyin普通组合。仅自建窗口，本轮不声称 Apple Pinyin/其他版本/复用器支持。

| ID | 触发→可观察结果 | 场景 | 判据/边界 |
|---|---|---|---|
| G01 | 实际iTerm键入、纯文本CmdV含伪ESC尾/Unicode→单个字段保留文本而控制序列被过滤；WeType提交中文；缩窗暂停/恢复；CtrlC退出2、termios/2004回原状态 | `gui_probe.mjs` + `gui_drive.swift` | 实际iTerm窗口、原始输出、自有窗口ID、明确stage/结果。未提交真实治理动作；WeType非Apple Pinyin |
| T01 | 启动握手收到2004半答复，超过查询2s→进程仍活/raw未还；补完真实答复后才恢复/退出 | `timeout_probe.mjs` + `timeout.py` startup | 真实PTY、OS termios、查询字节与进程退出；终端答复是脚本替身 |
| T02 | 恢复握手收到半答复，超过查询2s→不提前释放；补完后恢复termios并报告失败 | 同上 restore | 同T01 |
| I01 | 实际iTerm普通粘贴尾分块时合法2004报告插入→D054 ModeReplies消去报告、不损正文、粘贴事件完整结束 | `interleave_gui_probe.mjs` + `interleave_gui_drive.swift`；PTY补充 `interleave_probe.mjs` + `interleave.py` | 实际iTerm/普通CmdV + 机制组合；额外查询由QA探针发出，仅在报告确实插入尾帧时判命中；不是整套治理业务提交 |

每个GUI动作前须确认窗口ID仍存在且正由本次探针持有；只对该窗口选中后注入键。剪贴板保存于内存，不打印原值；仅在changeCount等于本探针写入后值时恢复。输入源仅在仍为本探针选的WeType时恢复。任何GUI失败最多3次，保留原始错误；清理只关闭自建窗口。不得把主线探针的PASS当本实例验收。
