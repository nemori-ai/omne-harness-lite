// CQ2 v2 S7/S8/S10, D054 iTerm provider: a legal mode reply may arrive
// inside the bracketed-paste END sentinel. Run only in the QA-owned PTY.
import { writeFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'

const [modulePath, evidencePath] = process.argv.slice(2)
const before = execFileSync('/bin/stty', ['-g'], { encoding: 'utf8', stdio: [0, 'pipe', 'pipe'] }).trim()
const observed = []
let terminal, failure
try {
  const { openTerminal } = await import(modulePath)
  terminal = await openTerminal('iterm-3.7.1beta1')
  process.stdout.write('READY\n')
  const paste = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('paste-event-timeout')), 10000)
    terminal.listen(event => {
      observed.push(event)
      if (event.kind === 'paste' || event.kind === 'invalid' || event.kind === 'eof') {
        clearTimeout(timer)
        resolve(event)
      }
    }, () => {})
  })
  if (paste.kind !== 'paste') throw new Error('paste-event-missing')
  if (paste.text !== 'alpha你好😀omega') throw new Error('paste-body-mismatch')
} catch (error) {
  failure = String(error?.message ?? error)
} finally {
  if (terminal) {
    try { await terminal.stopInput(); await terminal.restore() }
    catch (error) { failure = `restore: ${String(error?.message ?? error)}` }
  }
}
const after = execFileSync('/bin/stty', ['-g'], { encoding: 'utf8', stdio: [0, 'pipe', 'pipe'] }).trim()
const result = {
  status: failure ? 'FAIL' : 'PASS',
  error: failure,
  events: observed,
  termiosRestored: before === after,
}
if (!result.termiosRestored) result.status = 'FAIL'
writeFileSync(evidencePath, JSON.stringify(result, null, 2) + '\n')
process.stdout.write(result.status + ' mode-report-paste-tail\n')
process.exitCode = result.status === 'PASS' ? 0 : 1
