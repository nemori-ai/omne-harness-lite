#!/usr/bin/env python3
"""CQ2 S7/S10: half mode reply cannot be treated as EOF or restored on timeout.

Usage: timeout.py NODE PROBE MODULE EVIDENCE_DIR. The deliberate 2.5-second
gap exceeds DirectTerminal's 2-second query timeout; it is a test condition,
not a readiness sleep. Predicate waits are used for all other steps.
"""
import errno,fcntl,json,os,pty,select,struct,subprocess,sys,termios,time
from pathlib import Path
NODE,PROBE,MODULE,EVIDENCE=sys.argv[1:5]
EVIDENCE=Path(EVIDENCE);EVIDENCE.mkdir(parents=True,exist_ok=True)
results=[]
for case in ('startup','restore'):
    master,slave=pty.openpty()
    fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',40,110,0,0))
    original=termios.tcgetattr(slave)
    proc=subprocess.Popen([NODE,PROBE,MODULE],stdin=slave,stdout=slave,stderr=slave,
                          start_new_session=True,env={**os.environ,'TERM':'xterm','LC_ALL':'en_US.UTF-8'})
    raw=bytearray();pending=b'';queries=0;partial_at=None;finished=False;held=False
    deadline=time.monotonic()+15
    try:
        while time.monotonic()<deadline and proc.poll() is None:
            ready,_,_=select.select([master],[],[],.02)
            if ready:
                try:chunk=os.read(master,65536)
                except OSError as error:
                    if error.errno!=errno.EIO:raise
                    chunk=b''
                if chunk:
                    raw.extend(chunk);pending+=chunk
                    marker=b'\x1b[?2004$p'
                    while marker in pending:
                        _,pending=pending.split(marker,1)
                        queries+=1
                        target=1 if case=='startup' else 3
                        if queries==target:
                            os.write(master,b'\x1b[?2004;')
                            partial_at=time.monotonic()
                        else:os.write(master,b'\x1b[?2004;'+(b'1' if queries==2 else b'2')+b'$y')
            if partial_at and not finished and time.monotonic()-partial_at>=2.5:
                held=(proc.poll() is None and termios.tcgetattr(slave)!=original and
                      b'FINISHED:' not in raw)
                finished=True
                os.write(master,(b'2' if case=='restore' else b'2')+b'$y')
        timed_out=proc.poll() is None
        if timed_out:proc.kill()
        exit_code=proc.wait(timeout=3)
        while select.select([master],[],[],0)[0]:
            try:extra=os.read(master,65536)
            except OSError:break
            if not extra:break
            raw.extend(extra)
        text=bytes(raw).decode('utf8','replace')
        restored=termios.tcgetattr(slave)==original
        result={'case':case,'exitCode':exit_code,'queries':queries,'heldBeyondTimeout':held,
                'actualPartialCompleted':finished,'termiosRestored':restored,
                'modeEnableObserved':b'\x1b[?2004h' in raw,
                'modeDisableObserved':b'\x1b[?2004l' in raw,
                'finishedMarker':'FINISHED:' in text,'unexpectedSuccess':'UNEXPECTED_SUCCESS' in text,
                'timedOut':timed_out}
        passed=(held and finished and restored and exit_code==0 and not timed_out and
                result['finishedMarker'] and not result['unexpectedSuccess'] and
                (case!='restore' or (result['modeEnableObserved'] and result['modeDisableObserved'])))
        result['result']='PASS' if passed else 'FAIL'
        results.append(result)
        (EVIDENCE/(case+'.raw')).write_bytes(raw)
        (EVIDENCE/(case+'.json')).write_text(json.dumps(result,indent=2)+'\n')
        print(case,result['result'],json.dumps(result),flush=True)
    finally:
        if proc.poll() is None:proc.kill();proc.wait()
        os.close(master);os.close(slave)
(EVIDENCE/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
okay=all(x['result']=='PASS' for x in results)
print('PASS' if okay else 'FAIL','D054 half mode replies',sum(x['result']=='PASS' for x in results),'/',len(results))
sys.exit(0 if okay else 1)
