// Invoked only inside the QA PTY. Uses the detached D054 terminal provider.
// Args: terminal-module-path. An expected startup/restore failure is reported
// after the provider has actually closed its input and restored termios.
const modulePath=process.argv[2]
if (!modulePath) throw new Error('missing terminal provider path')
const {openTerminal}=await import(modulePath)
try {
  const terminal=await openTerminal('iterm-3.7.1beta1')
  await terminal.stopInput()
  await terminal.restore()
  process.stdout.write('UNEXPECTED_SUCCESS\n')
  process.exitCode=1
} catch (error) {
  process.stdout.write('FINISHED:'+String(error?.code??error?.message??error)+'\n')
  process.exitCode=0
}
