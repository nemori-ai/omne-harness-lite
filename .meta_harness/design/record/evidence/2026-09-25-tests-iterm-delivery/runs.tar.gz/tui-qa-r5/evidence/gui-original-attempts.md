# D054 independent GUI fixture attempts before path correction

Verifier: `tui-qa`. Working directory: `/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish`. Common invocation form:

`swift tmp/production-cli-onboarding/tui-qa-r5/acceptance/gui_drive.swift tmp/production-cli-onboarding/tui-qa-r5/evidence/gui-attemptN /Users/pandazki/.local/share/fnm/node-versions/v24.21.0/installation/bin/node /private/tmp/omne-cli-d051-audit-bnic5nj8/app`

The evidence argument was **relative**. The first fixture revision passed that literal path into the new iTerm session, whose cwd was not established. Thus `gui_probe.mjs` could have failed opening its output path and exited before the AppleScript window setup. This is an evidence-backed fixture risk, not proof of the exact process error: the probe's stderr was not captured because the window had already disappeared.

| Attempt | Driver exit | Captured driver stderr / error | Window observation | Probe files |
|---|---:|---|---|---|
| `gui-attempt1` | 1 | `command-failed Code=1` (full original stderr was not retained by the first driver revision) | No owned-window identity returned. No running probe at post-failure check. | none |
| `gui-attempt2` | 1 | `498:502: execution error: Can’t make id of window id 89190 of application "iTerm" into type text. (-1700)` | Read-only `exists window id 89190` returned `false`; process listing found no matching probe. | none |
| `gui-attempt3` | 1 | `418:456: execution error: iTerm got an error: Can’t set window id 89198 to {30, 50, 1000, 800}. (-10006)` | Read-only `exists window id 89198` returned `false`; process listing found no matching probe. | none |

No keyboard or clipboard injection occurred in these three attempts: all failed before obtaining and validating the owned window/session pair. The original stdout/stderr capture is incomplete, so the subsequent corrected-path run is a **new fixture revision**, not a reinterpretation of these failures. Original tool-output transcript remains in the agent execution record; this file preserves the exact known errors, missing evidence, and cleanup observations.
