# D053 便携中心 × 治理 TUI 成功业务语义独立验收

**判决：Pass with issues（仅本次成功业务语义增量）。** 38 次真实 TUI 操作覆盖全部 **30/30 治理表单**：35 次目标中心成功，3 次按契约明确拒绝。关键写操作在随后独立 machine CLI 读取中有对应的持久结果；真实便携中心正常退出。本报告不是产品接受，也不把本轮的合成 PTY 等同于实际终端或 IME 验收。

坐标：验证者 `tui-qa`，run id `d053-r4-qa-20260925-1511z`，基线提交 `cc01c8322e71d48d784bcb66e27cb81814fd4b6f`（工作树未提交）。Node v24.21.0，macOS，120×220 真实 PTY，脚本回答 2004 模式查询。CLI 制品 `/private/tmp/omne-cli-d053-cb_mt37l/app`，归档 SHA-256 `c9d2cf3905c69f39be4547b52fdb3cf26143df94136d05b8a4fd2c0ddf47fcdd`，BUILD_ID `bd0dfee2199113a06a8b20a4362e63e9fbd96efd7b6090411bd55012c497cbb0`。中心制品 `/private/tmp/omne-host-d053-zoembsk3/app`，归档 SHA-256 `b7c1b911aaeac69a27fc414f510007740b47fd78ab41528eb2e6b81572f10939`，BUILD_ID `d7b9759c45f7121b8d43d488bdcbfb034648582376cff06854e03391886bb2d3`。制品标记与归档哈希均从实物核对，中心由其 `dist/cli.js keygen/serve` 启动，新 TLS/部署密钥及私有状态全在临时目录。最终脚本退出码 0；中心 exit0。

标准来源是冻结 CQ2 v2 S3–12、相应 OG2/AI3 操作条款和 [预置验收矩阵](acceptance/matrix.md)。[场景脚本](acceptance/scenario.py)经 [独立 PTY 驱动](acceptance/driver.py)调用固定制品；每项 TUI 的原始字节、CG Report、模式恢复记录在 [final-d053](evidence/final-d053/) 的编号文件。`machine.json` 保留独立后验查询，`host.stderr.raw` 保留中心结构化请求。表中 S=远端成功，R=预期拒绝；编号直接指向同目录 `<编号>-<表单名>.json/.raw`。每行均有实际结果，未从 Preview 推定成功。

| 表单（冻结 CQ2） | TUI 证据编号 | 后验或差分判据 |
|---|---:|---|
| organization create | 000S | 新组织可被另一命令现读 |
| organization inspect | 001S | 与 machine 同一结构事实 |
| tenant current | 002S | Alpha 身份与 machine 同值 |
| tenant list | 003S | 有效租户列表与 machine 同值 |
| tenant validate | 004S | 层身份结果与 machine 同值 |
| invitation invite-by-login | 005S | Bob 收件箱含同一邀请 ID |
| invitation inbox | 006S | Bob 待办与 machine 同值 |
| invitation inspect | 007S | Bob 对该份邀请的读数同值 |
| invitation accept | 008S | Bob 成为 Alpha 的有效普通成员 |
| invitation create | 009R、010S、012S | 普通成员发起被 `notAuthorized` 拒绝、Carol 待办不变；超管另发两份成功 |
| invitation cancel | 011S | 独立读取显示 `withdrawn` |
| invitation decline | 013S | Carol 独立读取显示 `declined` |
| membership inspect | 014S | Bob 的有效成员事实同值 |
| membership list | 015S、020S | 超管前后名单同值；移除后 Bob `effective:false` |
| membership set-role | 016S、017S、021R | Bob 超管→普通成员的两次后验；仅剩一位超管时降级 Alice 被 `wouldLeaveNoSuperAdministrator` 拒绝，角色未变 |
| organization offers | 018S | 发出待办与 machine 同值 |
| membership remove | 019S、022R | Bob 被移除；仅剩超管移除自己被同一约束拒绝 |
| affiliation create | 023S、030S、032S | 三份不同请求分别用于接受、撤回、拒绝 |
| tenant switch | 024S | 成功后 TUI 附带 S36 与新 CLI 当前租户均为 Beta |
| affiliation inbox | 025S | Beta 收件箱含请求 ID，与 machine 同值 |
| affiliation inspect | 026S | 接收方读数与 machine 同值 |
| affiliation accept | 027S | Alpha 上级链变为 `[Beta]` |
| affiliation ancestors | 028S | 上级链与 machine 同值 |
| affiliation remove | 029S | Alpha 上级链恢复为空 |
| affiliation cancel | 031S | 独立读取显示 `withdrawn` |
| affiliation decline | 033S | 独立读取显示 `declined` |
| logins list | 034S | 登录句柄、签发与绝对期限同值；两次成功访问造成的活动时间单调前进且空闲期限=活动时间+1小时 |
| logins revoke | 035S | 被撤销的另一客户端在线读取被登录状态拒绝 |
| credential change | 036S | TUI exit4 需重进；旧凭据 CLI 拒绝，新凭据登录同一账号，秘密内容不在公开证据 |
| logout | 037S | TUI exit4；随后本地 machine 返回 `not-logged-in` |

缺陷清单：**本次固定制品在上述范围未发现缺陷**。原始 `attempt1`～`attempt5` 均留存：前期驱动曾在同名可选字段旧帧过早输入；成员名单的终结表示是 `effective:false`；登录列表的活动时间会因两次成功访问自然变化。这三处是 QA 场景或比较口径的修正，不改冻结判据、不掩盖产品失败。`attempt6` 证明 30/30 表单；最终 `final-d053` 另增唯一超管两项精确拒绝和 S37 附带 S36 对照。修订均只落本 QA 目录。

未覆盖与残余：本轮是三个账号、两个主要团队组织及一台 macOS 机器上的 loopback TLS；未测十人并发、跨机器网络、服务管理、备份/隔离恢复。PTY 模式答复由脚本生成，不证明 XTerm/iTerm GUI、普通粘贴、中文输入法或终端宽度表。可选字段只覆盖本旅程所选分支，并非每一组合；各表单成功路径已实际提交或现读，但不代表所有失败分支、竞态与灾难恢复正确。密码期限只观察到在线更新的 1 小时关系，8 小时绝对到期未用加速时钟实测。

清理：本轮便携中心 SIGTERM 后 exit0；38 个 TUI 子进程均退出并恢复 termios/2004；临时中心数据库、证书、密钥、凭据和客户端状态目录已撤除。未连生产环境，未修改产品代码、现有测试或规格。源码 SHA-256：`driver.py` `8913425361000cac8d7822572309f47ea020bdedf3e3f8470dfc2bb18424e865`，`scenario.py` `93f78b233ad0ce8fd1b5e04389e8336a2c9578f036df1ed35061da171aed7246`，`portable_center.mjs` `c65a4a4780c424cf9bddc5c17872fa81d1b051e8676f17147493737b62f32185`。任何相关制品/脚本更改须另开 run id，此判决不自动延续。
