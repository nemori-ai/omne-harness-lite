# D053 便携中心与治理 TUI 成功语义增量验收

范围：CQ2 v2 S3–12、OG2 S21–37/S55–62、AI3 S16/S37/S50、EC2 线上31路由，接续 r3 独立 QA 已验证的预览映射。本轮只把**经 TUI 确认、中心成功提交并可由后续独立读取证实**的动作标成功。D053 固定归档：CLI `c9d2cf3905c69f39be4547b52fdb3cf26143df94136d05b8a4fd2c0ddf47fcdd` / BUILD_ID `bd0dfee2199113a06a8b20a4362e63e9fbd96efd7b6090411bd55012c497cbb0`；host `b7c1b911aaeac69a27fc414f510007740b47fd78ab41528eb2e6b81572f10939` / BUILD_ID `d7b9759c45f7121b8d43d488bdcbfb034648582376cff06854e03391886bb2d3`。Node24.21.0，macOS 真实 PTY 合成 xterm 模式答复，真实便携中心进程/TLS。

| 阶段 | TUI操作 | 成功后独立 oracle |
|---|---|---|
| 起始 | organization create、inspect、tenant list/current/validate | CLI 现读新组织、本人租户、层身份；中心日志一笔写 |
| 邀请 | invite-by-login、invitation inbox/inspect/accept | 受邀方待办含同ID；接受后成员有效 |
| 邀请终结 | invitation create/cancel、另发一份/decline | 独立邀请读的状态分别 withdrawn/declined；不凭操作按钮推断 |
| 成员 | membership inspect/list/set-role/remove | 角色读变为超管，再变回成员；移除后资格失效；普通成员发管理动作被明确拒绝且不变更 |
| 隶属 | affiliation create/inbox/inspect/accept/ancestors/remove | 接收方待办含同ID；接受后子组织上级链；解除后为空 |
| 隶属终结 | affiliation create/cancel、另发一份/decline | 请求读状态分别 withdrawn/declined；不建立关系 |
| 身份 | tenant switch | S37成功后TUI现读S36；新CLI命令 current 为目标，旧身份不猜测 |
| 登录 | logins list/revoke、logout | 被撤销登录在线读被拒；退出后本机现读 not-logged-in |
| 其余读面 | organization offers、affiliation inbox、membership list、tenant validate | 同输入的 machine CLI 远端结果逐值相同；不把两侧共同错误当正确 |

允许 machine CLI 为不同账号/组织建立前置关系，但每行受验动作都必须实际从 TUI 走到 `remote.success`。任何无法创建的前置条件、协议差异、拒绝或 unknown 单独记录；不得从 Preview 或已有实现测试替代成功证据。场景按谓词等待 UI/中心结果；脚本超时只界定本次无法验收。保持 r3 原报告与原始失败不变，新证据只写本目录。
