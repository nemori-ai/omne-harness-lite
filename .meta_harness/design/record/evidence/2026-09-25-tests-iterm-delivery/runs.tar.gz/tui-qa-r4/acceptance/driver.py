"""QA-owned PTY driver and machine CLI oracle for detached D053 artifacts."""
import errno
import fcntl
import json
import os
from pathlib import Path
import pty
import re
import select
import signal
import struct
import subprocess
import termios
import time

MODE = re.compile(rb'\x1b\[\?2004(?:\$p|h|l)')
def visible(data):
    data=re.sub(rb'\x1b\[[0-9;?]*[ -/]*[@-~]',b'',bytes(data))
    return data.decode('utf-8','replace').replace('\r','')
def screen(raw):return visible(bytes(raw).split(b'\x1b[2J')[-1])

class Peer:
    def __init__(self,node,executable,directory,evidence,label,setup=False):
        self.evidence=Path(evidence);self.label=label
        self.master,self.slave=pty.openpty()
        fcntl.ioctl(self.slave,termios.TIOCSWINSZ,struct.pack('HHHH',220,120,0,0))
        self.original=termios.tcgetattr(self.slave)
        self.process=subprocess.Popen([node,executable,'tui','--terminal-profile','xterm-379',
             '--state-dir',directory,*(['--setup'] if setup else [])],
             stdin=self.slave,stdout=self.slave,stderr=self.slave,start_new_session=True,
             env={**os.environ,'TERM':'xterm','LC_ALL':'en_US.UTF-8'})
        self.raw=bytearray();self.pos=0;self.mode=2;self.closed=False
    def poll(self,timeout=.03):
        ready,_,_=select.select([self.master],[],[],timeout)
        if ready:
            try:chunk=os.read(self.master,65536)
            except OSError as error:
                if error.errno!=errno.EIO:raise
                chunk=b''
            if chunk:
                self.raw.extend(chunk)
                for match in MODE.finditer(self.raw,max(0,self.pos-12)):
                    if match.end()<=self.pos:continue
                    code=match.group()
                    if code.endswith(b'h'):self.mode=1
                    elif code.endswith(b'l'):self.mode=2
                    else:os.write(self.master,b'\x1b[?2004;'+str(self.mode).encode()+b'$y')
                    self.pos=match.end()
                if len(self.raw)>8_000_000:raise AssertionError('unbounded PTY output')
        return screen(self.raw)
    def wait(self,predicate,label,seconds=15):
        deadline=time.monotonic()+seconds
        while time.monotonic()<deadline:
            shown=self.poll()
            if predicate(shown):return shown
            if self.process.poll() is not None:
                raise AssertionError(f'exited before {label}: {self.process.returncode}: {shown[-850:]}')
        raise AssertionError(f'timeout {label}: {screen(self.raw)[-850:]}')
    def send(self,data):os.write(self.master,data if isinstance(data,bytes) else data.encode())
    def pages(self):
        shown=self.wait(lambda s:re.search(r'Page \d+/\d+',s) is not None,'page marker')
        pages=[]
        while True:
            at,total=map(int,re.search(r'Page (\d+)/(\d+)',shown).groups());pages.append(shown)
            if at==total:return pages
            self.send(b'\x1b[6~')
            shown=self.wait(lambda s:f'Page {at+1}/{total}' in s,'page '+str(at+1))
    def choose(self,label):
        text='\n'.join(self.pages())
        match=re.search(r'(?m)^(\d+)\. '+re.escape(label)+r'$',text)
        if not match:raise AssertionError(f'option {label} absent: {text[-800:]}')
        number=match.group(1)
        self.send(number);self.wait(lambda s:'> '+number in s,'choice echo '+label)
        self.send(b'\r')
    def text(self,label,value):
        self.wait(lambda s:label in s and 'Page ' in s and
                  'Do not specify; use center default' not in s,label)
        self.send(value)
        self.wait(lambda s:'> '+value in s,'field echo '+label)
        self.send(b'\r')
    def result(self,label):
        shown=self.wait(lambda s:label+' — exit status' in s and 'Page ' in s,'result '+label,25)
        start=shown.find('{',shown.index(label+' — exit status'))
        if start<0:raise AssertionError('result JSON missing: '+label)
        try:report=json.JSONDecoder().raw_decode(shown[start:])[0]
        except json.JSONDecodeError as error:raise AssertionError(f'result JSON incomplete: {label}: {error}: {shown[-700:]}') from error
        self.pages();self.send(b'\r')
        return report
    def opening(self):
        return [self.result(label) for label in ('Tenant current','Invitation inbox','Affiliation inbox')]
    def finish(self):
        if self.closed:return None
        if self.process.poll() is None:self.process.send_signal(signal.SIGTERM)
        deadline=time.monotonic()+15
        while self.process.poll() is None and time.monotonic()<deadline:self.poll()
        timed_out=self.process.poll() is None
        if timed_out:self.process.kill()
        code=self.process.wait(timeout=3);self.poll(0)
        status={'exitCode':code,'timedOut':timed_out,
                'termiosRestored':termios.tcgetattr(self.slave)==self.original,
                'mode2004Restored':self.mode==2,'rawLength':len(self.raw)}
        (self.evidence/(self.label+'.raw')).write_bytes(self.raw)
        (self.evidence/(self.label+'.terminal.json')).write_text(json.dumps(status,indent=2)+'\n')
        os.close(self.master);os.close(self.slave);self.closed=True
        return status

class Machine:
    def __init__(self,node,executable,root,evidence,commands):
        self.node=node;self.executable=executable;self.root=Path(root)
        self.evidence=Path(evidence);self.commands=commands;self.records=[];self.counter=0
    def file(self,value):
        path=self.root/f'input-{self.counter:04d}.json';self.counter+=1
        path.write_text(json.dumps(value,separators=(',',':')))
        path.chmod(0o600)
        return str(path)
    def run(self,command,state,payload=None,credential=None,refresh=False,expect='success'):
        args=['machine',*command,'--state-dir',state]
        if credential is not None:args+=['--credential-file',credential]
        if payload is not None:args+=['--payload-file',self.file(payload)]
        if refresh:args+=['--refresh']
        done=subprocess.run([self.node,self.executable,*args],stdin=subprocess.DEVNULL,
                            capture_output=True,timeout=60)
        out=done.stdout.decode('utf8','replace');err=done.stderr.decode('utf8','replace')
        if out.count('\n')!=1:raise AssertionError('machine did not write one JSON record')
        report=json.loads(out)
        self.records.append({'command':command,'state':state,'payload':payload,'exitCode':done.returncode,
                             'report':report,'stderr':err})
        if expect is not None and report['remote']['status']!=expect:
            raise AssertionError(f'machine {command} expected {expect}: {json.dumps(report)[-850:]}')
        return report
    def configure(self,state,endpoint,ca):
        args=['machine','center','configure','--state-dir',state,'--endpoint',endpoint,'--ca-file',ca]
        done=subprocess.run([self.node,self.executable,*args],stdin=subprocess.DEVNULL,
                            capture_output=True,timeout=60)
        out=done.stdout.decode('utf8','replace')
        if out.count('\n')!=1:raise AssertionError('configure did not write one JSON record')
        report=json.loads(out)
        self.records.append({'command':['center','configure'],'state':state,'exitCode':done.returncode,
                             'report':report,'stderr':done.stderr.decode('utf8','replace')})
        if report['remote']['status']!='success':raise AssertionError('configure failed: '+out[-850:])
        return report
    def action(self,form,state,payload=None,refresh=None,expect='success'):
        command=next(c for c in self.commands if ' '.join(c['command'])==form)
        return self.run(command['command'],state,payload,refresh=command.get('refresh',False) if refresh is None else refresh,expect=expect)
    def save(self):
        (self.evidence/'machine.json').write_text(json.dumps(self.records,indent=2)+'\n')

def result(report):
    return report['remote']['reply']['reply'].get('result')
