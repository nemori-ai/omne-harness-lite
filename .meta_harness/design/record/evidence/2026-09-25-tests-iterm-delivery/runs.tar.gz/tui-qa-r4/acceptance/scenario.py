#!/usr/bin/env python3
"""D053 real-center successful governance TUI journey, independent QA oracle.

Usage: scenario.py NODE PORTABLE_CLI PORTABLE_HOST FROZEN_FORMS FROZEN_COMMANDS EVIDENCE_DIR
Every accepted TUI action is checked against an independent center read or
machine CLI fact. No product source/tests are imported.
"""
import json,os,re,select,signal,subprocess,sys,tempfile,time
from datetime import datetime,timedelta
from pathlib import Path
from driver import Peer, Machine, result

NODE,CLI,HOST,FORMS,COMMANDS,EVIDENCE=sys.argv[1:7]
EVIDENCE=Path(EVIDENCE);EVIDENCE.mkdir(parents=True,exist_ok=True)
forms={x['id']:x for x in json.loads(Path(FORMS).read_text())}
commands=json.loads(Path(COMMANDS).read_text())
fixture=Path(__file__).with_name('portable_center.mjs')
observations=[];peers=[]

def fail_if(condition,message):
    if condition:raise AssertionError(message)
def assert_success(report,where):
    fail_if(report['remote']['status']!='success',f'{where}: {json.dumps(report)[-1000:]}')
    return result(report)

with tempfile.TemporaryDirectory(prefix='omne-qa-r4-',dir=os.path.realpath('/tmp')) as root:
    root=os.path.realpath(root)
    host=subprocess.Popen([NODE,str(fixture),NODE,HOST,root,str(EVIDENCE.resolve())],
                          stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    machine=Machine(NODE,CLI,root,EVIDENCE,commands)
    try:
        if not select.select([host.stdout],[],[],60)[0]:raise AssertionError('portable center readiness timeout')
        ready=json.loads(host.stdout.readline())
        fail_if(not ready.get('ready'),'portable center did not become ready')
        (EVIDENCE/'center-ready.json').write_text(json.dumps(ready,indent=2)+'\n')
        endpoint,ca=ready['endpoint'],ready['ca']
        secret=Path(root)/'credential';secret.write_text('qa-r4-credential-2026');secret.chmod(0o600)
        alice,bob,carol,alice_other=[str(Path(root)/name) for name in ('alice','bob','carol','alice-other')]
        for state in (alice,bob,carol,alice_other):machine.configure(state,endpoint,ca)
        for state,name in ((alice,'qa-r4-alice'),(bob,'qa-r4-bob'),(carol,'qa-r4-carol')):
            machine.run(['register'],state,{'loginIdentifier':name},credential=str(secret))
            machine.run(['login'],state,{'loginIdentifier':name},credential=str(secret))
        other_login=machine.run(['login'],alice_other,
                                {'loginIdentifier':'qa-r4-alice'},credential=str(secret))
        alice_personal=assert_success(machine.action('tenant current',alice),'alice initial')
        bob_personal=assert_success(machine.action('tenant current',bob),'bob initial')
        carol_personal=assert_success(machine.action('tenant current',carol),'carol initial')
        context={'alice_personal':alice_personal,'bob_personal':bob_personal,
                 'carol_personal':carol_personal,'alice':alice,'bob':bob,'carol':carol,
                 'alice_other':alice_other,
                 'other_login_handle':result(other_login)['loginStateHandle']}

        def fill(peer,form,values):
            for field in form['fields']:
                name=field['name'];kind=field['kind'];label=field['label']
                if field.get('when') and values.get(field['when']['field'])!=field['when']['equals']:
                    continue
                if kind=='current-tenant':continue
                if name not in values:
                    if field['required']:raise AssertionError(f'missing required {form["id"]}.{name}')
                    peer.wait(lambda s:label in s and 'Do not specify; use center default' in s,
                              'optional '+label)
                    peer.choose('Do not specify; use center default')
                    continue
                value=values[name]
                if not field['required']:
                    peer.wait(lambda s:label in s and 'Specify a value' in s,'optional '+label)
                    peer.choose('Specify a value')
                if kind in ('enum','boolean'):
                    peer.wait(lambda s:label in s and 'Page ' in s,label)
                    peer.choose(('True' if value else 'False') if kind=='boolean' else value)
                elif kind=='tenant':
                    peer.text(label+': account ID',value['account'])
                    peer.text(label+': organization ID',value['organization'])
                elif kind=='organizations':
                    peer.choose('One organization' if len(value)==1 else 'Two organizations')
                    for index,organization in enumerate(value,1):
                        peer.text(f'Organization {index} ID',organization)
                else:peer.text(label,str(value))
        def tui(form_id,state,values=None,expected='success'):
            form=forms[form_id];values=values or {}
            index=len(observations)
            label=f'{index:03d}-{form_id.replace(" ","-")}'
            peer=Peer(NODE,CLI,state,EVIDENCE,label);peers.append(peer)
            entry=peer.opening()
            peer.wait(lambda s:'Governance' in s and '1. Exit' in s,'governance menu '+form_id)
            peer.choose(form['label'])
            fill(peer,form,values)
            command=next(c for c in commands if ' '.join(c['command'])==form_id)
            is_read=form['action']=='invoke' and command.get('refresh',False)
            if is_read:
                peer.wait(lambda s:'Read source' in s and 'Read from center' in s,'read source '+form_id)
                peer.choose('Read from center')
            else:
                peer.wait(lambda s:'Confirm: '+form['label'] in s and 'Page ' in s,'preview '+form_id)
                peer.choose('Confirm this operation')
            report=peer.result(form['label'])
            attached=None
            if form_id=='tenant switch' and report['remote']['status']=='success':
                attached=peer.result('Tenant current')
            terminal=peer.finish()
            item={'id':form_id,'state':state,'values':values,'entry':entry,'report':report,
                  'attachedCurrent':attached,'terminal':terminal}
            observations.append(item)
            (EVIDENCE/(label+'.json')).write_text(json.dumps(item,indent=2)+'\n')
            fail_if(report['remote']['status']!=expected,
                    f'TUI {form_id} expected {expected}: {json.dumps(report)[-1000:]}')
            fail_if(not terminal['termiosRestored'] or not terminal['mode2004Restored'] or terminal['timedOut'],
                    f'TUI {form_id} terminal not restored')
            return report
        def read_parity(form_id,state,payload,values=None):
            ui=tui(form_id,state,values or payload)
            machine_report=machine.action(form_id,state,payload)
            left,right=result(ui),result(machine_report)
            if form_id=='logins list':
                # A successful second read itself advances this login's
                # lastActivityAt and idleExpiresAt. Compare stable identity
                # and absolute bounds, then verify the monotonic +1h rule.
                index=lambda entries:{x['loginStateHandle']:x for x in entries}
                earlier,later=index(left),index(right)
                fail_if(set(earlier)!=set(later),'login handles changed between two reads')
                for handle,first in earlier.items():
                    second=later[handle]
                    fail_if(first['issuedAt']!=second['issuedAt'] or
                            first['absoluteExpiresAt']!=second['absoluteExpiresAt'],
                            'stable login bounds changed between reads')
                    start=datetime.fromisoformat(first['lastActivityAt'].replace('Z','+00:00'))
                    end=datetime.fromisoformat(second['lastActivityAt'].replace('Z','+00:00'))
                    fail_if(end<start,'second successful read moved activity time backward')
                    for row in (first,second):
                        activity=datetime.fromisoformat(row['lastActivityAt'].replace('Z','+00:00'))
                        idle=datetime.fromisoformat(row['idleExpiresAt'].replace('Z','+00:00'))
                        fail_if(idle-activity!=timedelta(hours=1),'idle expiry is not activity +1h')
            else:
                fail_if(left!=right,
                        f'{form_id} TUI/machine domain reply differs: {left} != {right}')
            return result(ui)

        # Start with one TUI mutation, then compare the durable organization
        # fact through an independent CLI read.
        alpha=assert_success(tui('organization create',alice,{'creationKey':'qa-r4-alpha'}),
                             'TUI organization create')
        inspected=read_parity('organization inspect',alice,{'organization':alpha})
        fail_if(inspected is None,'created organization inspect was empty')
        beta=assert_success(machine.action('organization create',alice,{'creationKey':'qa-r4-beta'}),
                            'fixture beta create')
        context.update({'alpha':alpha,'beta':beta,
                        'alice_alpha':{'organization':alpha,'account':alice_personal['account']},
                        'alice_beta':{'organization':beta,'account':alice_personal['account']},
                        'bob_alpha':{'organization':alpha,'account':bob_personal['account']}})
        # Machine-only scaffolding selects Alpha before new TUI sessions.
        machine.action('tenant switch',alice,
                       {'expectedTenant':alice_personal,'targetTenant':context['alice_alpha']})
        current=read_parity('tenant current',alice,{})
        fail_if(current!=context['alice_alpha'],'selected Alpha identity differs')
        read_parity('tenant list',alice,{})
        read_parity('tenant validate',alice,{'tenant':context['alice_alpha']})

        invitation=assert_success(tui('invitation invite-by-login',alice,
                                      {'loginIdentifier':'qa-r4-bob'}),
                                  'TUI invite Bob by login')
        inbox=read_parity('invitation inbox',bob,{})
        fail_if(invitation not in json.dumps(inbox),'Bob inbox omitted the TUI invitation')
        inspected_invitation=read_parity('invitation inspect',bob,
                                         {'invitation':invitation,'callerIdentityKind':'account'})
        fail_if(inspected_invitation is None,'Bob cannot inspect his invitation')
        assert_success(tui('invitation accept',bob,{'invitation':invitation}),
                       'Bob TUI accepts invitation')
        member=assert_success(machine.action('membership inspect',alice,
                              {'tenant':context['bob_alpha']}),'Bob membership after accept')
        fail_if(member!={'standing':'effective','role':'member'},
                'Bob was not an effective member after TUI accept')
        machine.action('tenant switch',bob,
                       {'expectedTenant':bob_personal,'targetTenant':context['bob_alpha']})
        carol_before=result(machine.action('invitation inbox',carol))
        denial=tui('invitation create',bob,{'invitedAccount':carol_personal['account']},
                   expected='rejected')
        fail_if(result(machine.action('invitation inbox',carol))!=carol_before,
                'ordinary member created an invitation despite rejection')
        fail_if(denial['remote']['reply']['reply'].get('failure')!='notAuthorized',
                'ordinary member denial was not notAuthorized')

        withdrawn=assert_success(tui('invitation create',alice,
                                     {'invitedAccount':carol_personal['account']}),
                                 'create invitation for withdrawal')
        assert_success(tui('invitation cancel',alice,{'invitation':withdrawn}),
                       'withdraw invitation')
        withdrawn_view=assert_success(machine.action('invitation inspect',carol,
                         {'invitation':withdrawn,'callerIdentityKind':'account'}),
                         'withdrawn invitation inspect')
        fail_if('withdrawn' not in json.dumps(withdrawn_view),
                'withdrawn terminal state absent after TUI cancel')
        declined=assert_success(tui('invitation create',alice,
                                    {'invitedAccount':carol_personal['account']}),
                                'create invitation for decline')
        assert_success(tui('invitation decline',carol,{'invitation':declined}),
                       'Carol declines invitation')
        declined_view=assert_success(machine.action('invitation inspect',carol,
                         {'invitation':declined,'callerIdentityKind':'account'}),
                         'declined invitation inspect')
        fail_if('declined' not in json.dumps(declined_view),
                'declined terminal state absent after TUI decline')

        read_parity('membership inspect',alice,{'tenant':context['bob_alpha']})
        read_parity('membership list',alice,{'expectedTenant':context['alice_alpha']})
        promoted=assert_success(tui('membership set-role',alice,
                         {'targetTenant':context['bob_alpha'],'role':'superAdministrator'}),
                         'promote Bob')
        promoted_view=assert_success(machine.action('membership inspect',alice,
                         {'tenant':context['bob_alpha']}),'promoted Bob inspect')
        fail_if(promoted_view.get('role')!='superAdministrator','Bob not promoted')
        assert_success(tui('membership set-role',alice,
                         {'targetTenant':context['bob_alpha'],'role':'member'}),
                         'demote Bob')
        demoted_view=assert_success(machine.action('membership inspect',alice,
                         {'tenant':context['bob_alpha']}),'demoted Bob inspect')
        fail_if(demoted_view.get('role')!='member','Bob not demoted')
        read_parity('organization offers',alice,{'expectedTenant':context['alice_alpha']})
        assert_success(tui('membership remove',alice,
                         {'targetTenant':context['bob_alpha']}),'remove Bob')
        removed=read_parity('membership list',alice,
                  {'expectedTenant':context['alice_alpha'],'includeIneffective':True})
        bob_entry=next((item for item in removed if item.get('tenant')==context['bob_alpha']),None)
        fail_if(bob_entry is None or bob_entry.get('effective') is not False,
                'removed Bob not shown as ineffective to superadministrator')
        sole_admin=tui('membership set-role',alice,
                       {'targetTenant':context['alice_alpha'],'role':'member'},
                       expected='rejected')
        fail_if(sole_admin['remote']['reply']['reply'].get('failure')!=
                'wouldLeaveNoSuperAdministrator',
                'last-superadministrator demotion did not return the precise guard')
        fail_if(result(machine.action('membership inspect',alice,
                 {'tenant':context['alice_alpha']})).get('role')!='superAdministrator',
                'rejected sole-admin demotion changed Alice role')
        sole_removal=tui('membership remove',alice,
                         {'targetTenant':context['alice_alpha']},expected='rejected')
        fail_if(sole_removal['remote']['reply']['reply'].get('failure')!=
                'wouldLeaveNoSuperAdministrator',
                'last-superadministrator removal did not return the precise guard')

        request=assert_success(tui('affiliation create',alice,
                         {'recipientOrganization':beta,'direction':'recipientAsParent'}),
                         'create Alpha→Beta affiliation request')
        switched=tui('tenant switch',alice,{'targetTenant':context['alice_beta']})
        fail_if(result(switched)!='ok','TUI switch to Beta did not return ok')
        attached=observations[-1]['attachedCurrent']
        fail_if(attached is None or assert_success(attached,'S37 attached S36')!=context['alice_beta'],
                'successful TUI switch did not visibly confirm Beta via S36')
        fail_if(assert_success(machine.action('tenant current',alice),'current Beta')!=context['alice_beta'],
                'TUI switch did not persist Beta selection')
        incoming=read_parity('affiliation inbox',alice,
                             {'expectedTenant':context['alice_beta']})
        fail_if(request not in json.dumps(incoming),'Beta inbox omitted affiliation request')
        inspected_request=read_parity('affiliation inspect',alice,
                 {'affiliationRequest':request,'expectedTenant':context['alice_beta']})
        fail_if(inspected_request is None,'Beta cannot inspect received request')
        assert_success(tui('affiliation accept',alice,{'affiliationRequest':request}),
                       'Beta accepts Alpha→Beta request')
        ancestors=read_parity('affiliation ancestors',alice,{'organizations':[alpha]})
        fail_if(ancestors!=[beta],'accepted affiliation did not form Alpha→Beta parent chain')
        assert_success(tui('affiliation remove',alice,{'childOrganization':alpha}),
                       'Beta removes Alpha parent')
        fail_if(result(machine.action('affiliation ancestors',alice,
                    {'organizations':[alpha]}))!=[],
                'removed affiliation still appears in current ancestor chain')
        machine.action('tenant switch',alice,
                       {'expectedTenant':context['alice_beta'],'targetTenant':context['alice_alpha']})

        withdrawn_request=assert_success(tui('affiliation create',alice,
                         {'recipientOrganization':beta,'direction':'recipientAsParent'}),
                         'create affiliation request for withdrawal')
        assert_success(tui('affiliation cancel',alice,
                         {'affiliationRequest':withdrawn_request}),
                         'withdraw affiliation request')
        machine.action('tenant switch',alice,
                       {'expectedTenant':context['alice_alpha'],'targetTenant':context['alice_beta']})
        withdrawn_read=assert_success(machine.action('affiliation inspect',alice,
                          {'affiliationRequest':withdrawn_request,
                           'expectedTenant':context['alice_beta']}),
                          'read withdrawn affiliation request')
        fail_if('withdrawn' not in json.dumps(withdrawn_read),
                'affiliation withdrawal not visible')
        machine.action('tenant switch',alice,
                       {'expectedTenant':context['alice_beta'],'targetTenant':context['alice_alpha']})
        declined_request=assert_success(tui('affiliation create',alice,
                         {'recipientOrganization':beta,'direction':'recipientAsParent'}),
                         'create affiliation request for decline')
        machine.action('tenant switch',alice,
                       {'expectedTenant':context['alice_alpha'],'targetTenant':context['alice_beta']})
        assert_success(tui('affiliation decline',alice,
                         {'affiliationRequest':declined_request}),
                         'Beta declines affiliation request')
        declined_read=assert_success(machine.action('affiliation inspect',alice,
                          {'affiliationRequest':declined_request,
                           'expectedTenant':context['alice_beta']}),
                          'read declined affiliation request')
        fail_if('declined' not in json.dumps(declined_read),
                'affiliation decline not visible')

        logins=read_parity('logins list',alice,{})
        fail_if(context['other_login_handle'] not in json.dumps(logins),
                'other Alice login absent before revoke')
        assert_success(tui('logins revoke',alice,
                         {'loginStateHandle':context['other_login_handle']}),
                         'revoke other Alice login')
        stale=machine.action('tenant current',alice_other,{},expect='rejected')
        fail_if(stale['remote'].get('answer')!='login-state-rejected' and
                'login-state-rejected' not in json.dumps(stale),
                'revoked login still passed online current query')
        new_secret=Path(root)/'new-credential'
        new_secret.write_text('qa-r4-new-credential-2026');new_secret.chmod(0o600)
        changed=assert_success(tui('credential change',alice,
                          {'currentCredential':str(secret),'newCredential':str(new_secret)}),
                          'active credential change')
        fail_if(observations[-1]['terminal']['exitCode']!=4 or
                changed is None,'credential change did not require reentry')
        secret_bytes=('qa-r4-credential-2026','qa-r4-new-credential-2026')
        fail_if(any(s in bytes(peers[-1].raw).decode('utf8','replace') for s in secret_bytes),
                'credential content appeared in TUI output')
        old_attempt=machine.run(['login'],alice,{'loginIdentifier':'qa-r4-alice'},
                                credential=str(secret),expect='rejected')
        fail_if(old_attempt['remote']['status']!='rejected','old credential still accepted')
        machine.run(['login'],alice,{'loginIdentifier':'qa-r4-alice'},credential=str(new_secret))
        fail_if(result(machine.action('tenant current',alice))!=alice_personal,
                'new login did not start at personal identity')
        assert_success(tui('logout',alice),'logout Alice')
        after_logout=machine.action('tenant current',alice,{},expect=None)
        fail_if(after_logout['admission'].get('reason')!='not-logged-in',
                'TUI logout did not clear local login selection')
    except Exception as error:
        observations.append({'id':'scenario-error','error':repr(error)})
        print('FAIL',repr(error),flush=True)
    finally:
        for peer in peers:
            if not peer.closed:peer.finish()
        host.send_signal(signal.SIGTERM)
        try:host.wait(timeout=45)
        except subprocess.TimeoutExpired:host.kill();host.wait()
        (EVIDENCE/'fixture.stderr.raw').write_text(host.stderr.read())
        machine.save()
        (EVIDENCE/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
    ok=not any('error' in item for item in observations)
    print(json.dumps({'status':'PASS' if ok else 'FAIL','actions':len(observations),
                      'ids':[item['id'] for item in observations]}))
    sys.exit(0 if ok else 1)
