// D053 QA-only deployment fixture: launches the detached host artifact.
// Usage: node portable_center.mjs NODE HOST_CLI ROOT EVIDENCE_DIR
import { spawn, spawnSync } from 'node:child_process'
import { chmodSync, existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { createServer, createConnection } from 'node:net'
import { join } from 'node:path'

const [node, executable, root, evidence] = process.argv.slice(2)
if (![node, executable, root, evidence].every(Boolean)) throw new Error('missing fixture paths')
const commands = []
const run = (command, args, cwd = root) => {
  commands.push({ command, args })
  const done = spawnSync(command, args, { cwd, encoding: 'utf8', timeout: 45000 })
  if (done.status !== 0) throw new Error(`${command} failed: ${done.status}: ${done.stderr}`)
  return done.stdout
}
const config = (name, contents) => {
  const path = join(root, name)
  writeFileSync(path, contents)
  return path
}
const caConf = config('ca.cnf', '[req]\nprompt = no\ndistinguished_name = dn\n[dn]\nCN = qa-ca\n[v3_ca]\nbasicConstraints = critical,CA:TRUE\nkeyUsage = critical,keyCertSign,cRLSign\nsubjectKeyIdentifier = hash\n')
run('openssl', ['req','-x509','-config',caConf,'-extensions','v3_ca','-newkey','ec','-pkeyopt','ec_paramgen_curve:P-256','-nodes','-keyout','ca.key','-out','ca.pem','-days','2'])
chmodSync(join(root,'ca.key'),0o600)
const leafConf = config('leaf.cnf', '[req]\nprompt = no\ndistinguished_name = dn\n[dn]\nCN = localhost\n')
run('openssl', ['req','-new','-config',leafConf,'-newkey','ec','-pkeyopt','ec_paramgen_curve:P-256','-nodes','-keyout','leaf.key','-out','leaf.csr'])
chmodSync(join(root,'leaf.key'),0o600)
const ext = config('leaf.ext', '[v3_leaf]\nsubjectAltName = DNS:localhost,IP:127.0.0.1\nbasicConstraints = critical,CA:FALSE\nkeyUsage = critical,digitalSignature\nextendedKeyUsage = serverAuth\nsubjectKeyIdentifier = hash\nauthorityKeyIdentifier = keyid\n')
run('openssl', ['x509','-req','-in','leaf.csr','-CA','ca.pem','-CAkey','ca.key','-CAcreateserial','-out','leaf.pem','-days','2','-sha256','-extfile',ext,'-extensions','v3_leaf'])
const chain = join(root,'leaf.chain.pem')
writeFileSync(chain,readFileSync(join(root,'leaf.pem')) + readFileSync(join(root,'ca.pem')))
const keydir = join(root,'keys')
const generated = JSON.parse(run(node,[executable,'keygen',keydir]))
if (!generated.files || typeof generated.files !== 'object') throw new Error('invalid keygen record')
const opsDir = mkdtempSync(join(root,'ops-'))
const port = await new Promise((resolve,reject) => {
  const server=createServer()
  server.once('error',reject)
  server.listen(0,'127.0.0.1',() => {
    const address=server.address()
    if (!address || typeof address==='string') reject(new Error('missing port'))
    else server.close(() => resolve(address.port))
  })
})
const env = {
  PATH: process.env.PATH ?? '',
  OMNE_TENANCY_STORAGE_FILE: join(root,'center.sqlite'),
  OMNE_TENANCY_ENTRY_LISTEN: `127.0.0.1:${port}`,
  OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE: chain,
  OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE: join(root,'leaf.key'),
  OMNE_TENANCY_OPS_SOCKET_DIR: opsDir,
  OMNE_TENANCY_UNACTIVATED_RETENTION: 'P7D',
  OMNE_TENANCY_INVITATION_TTL_DEFAULT: 'P14D',
  OMNE_TENANCY_AFFILIATION_REQUEST_TTL_DEFAULT: 'P14D',
  OMNE_TENANCY_COPY_NOTICE_TTL_DEFAULT: 'P7D',
  OMNE_TENANCY_SHARING_INVITATION_TTL_DEFAULT: 'P7D',
  OMNE_TENANCY_TEAM_CREATION_KEY_RETENTION: 'P1D',
  OMNE_TENANCY_CLOCK_READY_TIMEOUT: '15000',
  OMNE_TENANCY_CREDENTIAL_POLICY: '{"minLength":12}',
  ...generated.files,
}
commands.push({ command: node, args: [executable,'serve'], environmentNames: Object.keys(env).sort() })
const host = spawn(node,[executable,'serve'],{env,stdio:['ignore','pipe','pipe']})
let stdout='',stderr='',exited
host.stdout.setEncoding('utf8');host.stderr.setEncoding('utf8')
host.stdout.on('data',part => stdout+=part)
host.stderr.on('data',part => stderr+=part)
host.once('exit',(code,signal)=>exited={code,signal})
const opsSocket=join(opsDir,'governance-center-ops.sock')
const canConnect = () => new Promise(resolve => {
  const client=createConnection({host:'127.0.0.1',port})
  client.once('connect',()=>{client.destroy();resolve(true)})
  client.once('error',()=>resolve(false))
})
const deadline=Date.now()+45000
while (!(existsSync(opsSocket) && await canConnect())) {
  if (exited) throw new Error(`host exited before ready: ${JSON.stringify(exited)} ${stderr}`)
  if (Date.now()>deadline) throw new Error(`host readiness timeout: ${stderr}`)
  await new Promise(resolve=>setTimeout(resolve,100))
}
console.log(JSON.stringify({ready:true,endpoint:`https://localhost:${port}/`,ca:join(root,'ca.pem'),hostPid:host.pid,opsSocket}))
let closing=false
async function close() {
  if (closing) return
  closing=true
  if (!exited) {
    const stopped=new Promise(resolve=>host.once('exit',resolve))
    host.kill('SIGTERM')
    await stopped
  }
  writeFileSync(join(evidence,'host-commands.json'),JSON.stringify(commands,null,2)+'\n')
  writeFileSync(join(evidence,'host.stdout.raw'),stdout)
  writeFileSync(join(evidence,'host.stderr.raw'),stderr)
  writeFileSync(join(evidence,'host-exit.json'),JSON.stringify(exited,null,2)+'\n')
  process.exit(0)
}
process.on('SIGTERM',()=>{void close()})
process.on('SIGINT',()=>{void close()})
process.stdin.resume()
