"""Check the preserved evidence bundle; do not invoke any model checker."""

import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
data = json.loads((OUT / 'RESULTS.json').read_text())
trace_data = json.loads((OUT / 'trace-inspections.json').read_text())
fingerprints = json.loads((OUT / 'input-snapshot.json').read_text())
assert len(data['tasks']) == 20
assert len(trace_data) == 15
assert data['matched_task_count'] == 20
assert data['all_traces_manually_read']
for path, digest in fingerprints.items():
    assert hashlib.sha256((OUT / 'inputs' / path).read_bytes()).hexdigest() == digest
for task in data['tasks']:
    folder = OUT / 'tasks' / task['id']
    stdout = (folder / 'stdout.log').read_text()
    for channel in ('stdout', 'stderr'):
        assert hashlib.sha256((folder / (channel + '.log')).read_bytes()).hexdigest() == task[channel + '_sha256']
    runtime = json.loads((folder / 'runtime.json').read_text())
    assert runtime['state'] == 'completed'
    assert runtime['exit_code'] == task['exit_code']
    assert task['argv'] == runtime['argv']
    assert task['input_drift'] == {}
    assert task['termination'] is None
    task['checked_assertions'] = []
    if '-config' in task['argv']:
        config = task['argv'][task['argv'].index('-config') + 1]
        config_text = (OUT / 'inputs/.meta_harness/design' / config).read_text()
        invariant_text = config_text.split('INVARIANTS\n')[1]
        task['checked_assertions'] = [line.strip() for line in invariant_text.splitlines() if line.strip() and not line.strip().startswith(('CHECK_DEADLOCK', '\\*'))]
        if task['kind'] == 'positive':
            assert task['exit_code'] == 0
            assert task['state_counts'][2] == 0
            assert 'Model checking completed. No error has been found.' in stdout
        else:
            assert task['exit_code'] == 12
            assert task['expected_assertion'] in task['checked_assertions']
            inspection = next(item for item in trace_data if item['task'] == task['id'])
            assert inspection['trace_matches_intended_counterexample']
            assert inspection['assertion'] == task['expected_assertion']
            assert hashlib.sha256((OUT / inspection['trace_path']).read_bytes()).hexdigest() == inspection['trace_sha256']
        version = re.search(r'^TLC2 Version ([^\n]+)', stdout, re.M)
        settings = re.search(r'with fp (\d+) and seed (-?\d+)', stdout)
        task['actual_tlc_version'] = version.group(1)
        task['actual_fingerprint_index'] = int(settings.group(1))
        task['actual_seed'] = int(settings.group(2))
    else:
        assert task['exit_code'] == 0
        task['actual_sany_version'] = re.search(r'SANY2 Version ([^\n]+)', stdout).group(1)
data['evidence_integrity_checks'] = {'preserved_inputs': len(fingerprints), 'tasks': 20, 'raw_channel_hashes': 40, 'named_trace_hashes': 15, 'all_processes_completed': True, 'pass': True}
(OUT / 'RESULTS.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
inventory = {str(path.relative_to(OUT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(OUT.rglob('*')) if path.is_file() and path.name != 'artifact-inventory.json'}
(OUT / 'artifact-inventory.json').write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'integrity': data['evidence_integrity_checks'], 'results_sha256': hashlib.sha256((OUT / 'RESULTS.json').read_bytes()).hexdigest(), 'inventory_sha256': hashlib.sha256((OUT / 'artifact-inventory.json').read_bytes()).hexdigest(), 'inventory_files': len(inventory)}, indent=2))
