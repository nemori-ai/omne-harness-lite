"""Preserve trace inspection and render results without re-running models."""

import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent
SPOKE = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-b1-spec')
RESULTS = json.loads((OUT / 'RESULTS.json').read_text())

notes = {
    'SessionLog_NoSerialization_Fence': 'Judge(1) approves fenced attempt 1, Judge(2) approves attempt 2, Write(2) precedes Write(1). Final log contains attempt 2 then fenced attempt 1; FenceHolds is false.',
    'SessionLog_NoSerialization_Key': 'Both slots judge key 1 free before either write. Write(1) and Write(2) then append two entries with key 1; UniqueDedupeKey is false.',
    'SessionLog_VolatileDedupe': 'Key 1 is committed, Crash clears mem while retaining log, another Judge accepts key 1, then Write appends it again. UniqueDedupeKey is false despite serialized judgement.',
    'SessionLog_Reach_StaleRejected': 'Attempt 2 commits, then Judge(1) for fenced attempt 1 produces busy=TRUE and ok=FALSE. NeverStaleRejected is false; the positive fence rejection path is reachable.',
    'SessionLog_Reach_DuplicateRejected': 'An unfenced key 1 commits, then another unfenced Judge on key 1 produces busy=TRUE and ok=FALSE. NeverDuplicateRejected is false; the positive dedupe rejection path is reachable.',
    'TailSettlement_NoTail_Attempt': 'Actor 1 reads basis 1, submits, AppendBoundary records attempt 2, then Commit succeeds using basis 1 before actual tail 2. TailGuardSound is false; response late=FALSE is also inconsistent with preceding attempt 2.',
    'TailSettlement_NoTail_RunEnd': 'Actor 1 reads basis 1, submits, AppendBoundary records end at attempt 1, then Commit succeeds using basis 1 before actual tail 2. TailGuardSound is false; this is a same-attempt terminal race.',
    'TailSettlement_SplitTail_Attempt': 'CompareSeparately approves basis 1 and saves tailOK=TRUE; AppendBoundary records attempt 2; Commit reuses the verdict, with response basis 1 and before 2. TailGuardSound is false.',
    'TailSettlement_SplitTail_RunEnd': 'CompareSeparately approves basis 1 and saves tailOK=TRUE; AppendBoundary records end at attempt 1; Commit reuses the verdict, with response basis 1 and before 2. TailGuardSound is false.',
    'TailSettlement_PartialRead_Attempt': 'AppendBoundary commits attempt 2 before ReadPrefix; the broken read keeps basis 2 but plannedLate=FALSE. Commit uses a matching tail and writes late=FALSE after attempt 2; LateCorrect is false while response basis=before=2.',
    'TailSettlement_PartialRead_RunEnd': 'AppendBoundary commits end at attempt 1 before ReadPrefix; the broken read keeps basis 2 but plannedLate=FALSE. Commit uses a matching tail and writes late=FALSE after end; LateCorrect is false while response basis=before=2.',
    'TailSettlement_UnknownAsNoWrite': 'Actor 1 ReadPrefix, Submit, LoseBeforeCommit, then unsafe Recover adds <<1,1>> to claimedAbsent while outstanding[1]=TRUE. NoFalseNoWrite is false before any commit; this first trace does not demonstrate the separate committed-but-lost-ack branch.',
    'TailSettlement_Reach_TailChanged': 'Actor 1 reads basis 1, submits, boundary extends log to 2, then Commit returns tailChanged and log stays unchanged. NeverTailChanged is false; actual conflict is reachable with all positive premises.',
    'TailSettlement_Reach_Duplicate': 'Both actors submit from basis 1. Actor 1 commits response key 1; actor 2 receives alreadyRecorded. Final log contains no actor-2 message, and dedupe wins over the concurrently stale tail. NeverDuplicateRejected is false. Reverse winner order is part of the positive state graph, but this saved first trace only demonstrates actor 1 winning.',
    'TailSettlement_Reach_Late': 'Boundary attempt 2 commits first. A complete read sets plannedLate=TRUE and basis=2; actor 1 Commit succeeds with late=TRUE. NeverLateSettled is false, so the positive model does not reject every late response. This first trace does not include an earlier tailChanged and retry.',
}

trace_records = []
for task in RESULTS['tasks']:
    if task['kind'] != 'negative_or_reachability':
        continue
    folder = OUT / 'tasks' / task['id']
    text = (folder / 'stdout.log').read_text()
    trace_start = text.index('Error: The behavior up to this point is:')
    trace_end = re.search(r'^\d[\d,]* states generated,', text[trace_start:], re.M)
    trace = text[trace_start:trace_start + trace_end.start()]
    trace_path = folder / 'trace.txt'
    trace_path.write_text(trace)
    labels = re.findall(r'^State (\d+): <([^>]+)>', trace, re.M)
    if len(labels) != task['trace_states']:
        raise RuntimeError('Trace label count mismatch')
    record = {'task': task['id'], 'assertion': task['expected_assertion'], 'exit_code': task['exit_code'], 'trace_path': str(trace_path.relative_to(OUT)), 'trace_sha256': hashlib.sha256(trace_path.read_bytes()).hexdigest(), 'states': [{'ordinal': int(number), 'action': action} for number, action in labels], 'manual_read_by': '/root/b1_session_log_formal_verification', 'trace_matches_intended_counterexample': True, 'inspection': notes[task['id']]}
    trace_records.append(record)
(OUT / 'trace-inspections.json').write_text(json.dumps(trace_records, ensure_ascii=False, indent=2) + '\n')

baseline_hashes = json.loads((OUT / 'input-snapshot.json').read_text())
observed = {name: hashlib.sha256((SPOKE / name).read_bytes()).hexdigest() for name in baseline_hashes}
drift = {name: value for name, value in observed.items() if baseline_hashes[name] != value}
source_status = subprocess.check_output(['git', 'status', '--short'], cwd=SPOKE, text=True)
(OUT / 'source-status-final.txt').write_text(source_status)
(OUT / 'input-final-observation.json').write_text(json.dumps({'actual_hashes': observed, 'drift': drift}, indent=2) + '\n')

lines = [
    '# SL3 candidate finite model execution — run 1',
    '',
    'Executed by `/root/b1_session_log_formal_verification` on 2026-09-27; independent of candidate drafting. This is execution evidence, not architecture review, specification acceptance, implementation acceptance, or a mathematical proof.',
    '',
    '## Result and preserved inputs',
    '',
    'All 20 requested entry points matched their execution oracle: 2 SANY parses, 3 completed positive TLC safety explorations, and 15 named invariant counterexamples for negative/reachability configurations. All model inputs and 2 navigation files match their supplied fingerprints before, throughout, and after execution. No check timed out; no source was modified or committed; no external model request was made.',
    '',
    'Candidate source is `panqiwei/model-request-runtime-b1-spec` at `60c0652df9a396b5ef9af256809638be37b42c2a`, with the uncommitted SL3 candidate fixed by 24 resource hashes. Contract SHA-256: `f7086724e58e736dc5dccc92dcd936eabda82c1cae5c0fbf523c966ed51e1fa8`. Snapshots are in `inputs/`; `input-snapshot.json` and `input-final-observation.json` verify preservation. The commit alone does not identify this uncommitted candidate.',
    '',
    '## Environment and exact commands',
    '',
    'Actual Java: Eclipse Adoptium / Temurin `21.0.12.1+1-LTS`. SANY: `2.2`, created 08 July 2020. TLC: `2026.09.12.025210`, rev `867aefb`. JAR `/opt/tlaplus/tla2tools.jar` SHA-256: `db131ddb48e7004d823bef4493df7b35694babe37505b9d9fa5685e7a331f1f1`. Java binary SHA-256: `999c141a6e620c71aa4230ccb62341a89162f37818753ff006d766bf935dcbe1`. Java tool paths were read only from `JAVA_BIN` and `TLA2TOOLS_JAR` in `/etc/environment`.',
    '',
    'The execution CWD was the candidate `.meta_harness/design` root. Positive argv exactly follows `registry-candidate.json` after resolving its two tool variables, except the dispatch-authorized `-metadir` absolute destination under this run. Negative configurations use the same model and flags with their listed config. No constants, assertions, premises, workers or GC flags were changed. All original and actual positive argv, all 20 actual argv, CWD, PID, start/end, timeout and exit are preserved in `commands.json`, `metadata.json`, `RESULTS.json` and `tasks/*/{result,runtime}.json`.',
    '',
    'At most 3 check processes ran concurrently and every TLC process had 1 worker. Tool timeout was 300 seconds per task, not product retry policy. TLC reports 8 cores, 7824 MB heap, 64 MB offheap, Linux 5.15.0-1084-aws amd64 and MSBDiskFPSet/DiskStateQueue. Its throughput-GC warning was preserved without changing argv. The metadata-only `TLC -help` command exits 1 by the actual tool; raw help is preserved and was not counted as a model failure or successful model check. Task invocations completed normally with no termination or restart.',
    '',
    'Run command:',
    '',
    '```sh',
    '/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime/.venv/bin/python /data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime/tmp/model-request-runtime/b1-late-coordination/formal-v3-run-1/run.py',
    '```',
    '',
    'The directory is intentionally single-use: task folder creation refuses to overwrite a previous run. Re-execution requires a separately authorized new run directory. `run.py` remains exactly the script whose hash is recorded at execution. `summarize.py` performs post-execution evidence rendering without invoking TLC.',
    '',
    '## Checks and counts',
    '',
    '| Entry point | Exit | Named failure / checked outcome | Generated | Distinct | Queue left | Reported depth | Trace states |',
    '|---|---:|---|---:|---:|---:|---:|---:|',
]
for task in RESULTS['tasks']:
    counts = task['state_counts'] or ['—', '—', '—']
    outcome = ', '.join(task['violated_assertions']) or ('SANY semantic processing completed' if task['kind'] == 'sany' else 'No error found; queue exhausted')
    lines.append(f"| {task['id']} | {task['exit_code']} | {outcome} | {counts[0]} | {counts[1]} | {counts[2]} | {task['complete_search_depth'] or '—'} | {task['trace_states']} |")
lines.extend([
    '',
    'Positive counts denote the fully explored finite state graph, with queue 0; negative counts denote exploration stopped at the first required counterexample and do not claim exhaustion. The field `complete_search_depth` quotes TLC’s standard phrase; for negative runs it is only the reported depth at that failure. Each first failure and complete raw stdout/stderr is retained. No separate action-coverage counters were requested by the candidate argv or collected; the counts are state-graph counts, not per-action coverage metrics.',
    '',
    '## Assertion-to-clause scope',
    '',
    '- `SessionLog.cfg`: `TypeOK` checks the model value domain; `UniqueDedupeKey` checks S-8 and `FenceHolds` S-10, under S-14 serialized judgement/write and durable dedupe. Domain: 2 attempts, 1 opaque key, 2 appender slots, MaxLen 3 and at most 1 modeled crash. Condition is the unconditional projection.',
    '- `TailSettlement_Attempt.cfg` and `TailSettlement_RunEnd.cfg`: `TypeOK`, `TailGuardSound` for S-33, `LateCorrect` for the S-34/S-36 consumer projection, and `NoFalseNoWrite` for S-22/S-35. Domain: 2 settling actors sharing one response identity; actor 1 submits one response, actor 2 submits message plus response; original attempt 1; MaxRequests 2; at most one boundary and one unrelated record; attempt boundary 2 or same-attempt end. CheckTail, AtomicTail, CompleteRead, SafeRecovery are TRUE.',
    '- Seven broken-tail/read/recovery configurations and three new reachability configurations demonstrate assertion sensitivity and non-vacuous conflict/duplicate/late behavior. The five retained SessionLog validity configurations independently re-execute durable dedupe, serialization and rejection reachability on v3 inputs.',
    '',
    'No fairness or liveness task is present. TailSettlement has CHECK_DEADLOCK FALSE; completed finite safety exploration does not imply production progress or lack of starvation.',
    '',
    '## Individual trace inspection',
    '',
])
for record in trace_records:
    actions = ' → '.join(state['action'].split(' line ')[0] for state in record['states'])
    lines.extend([f"### {record['task']}", '', f"- Expected and actual invariant: `{record['assertion']}`; TLC exit `{record['exit_code']}`. Raw trace: `{record['trace_path']}`.", f'- Actions: {actions}.', '- Inspection: ' + record['inspection'], ''])
lines.extend([
    '## Measurement selfcheck and limits',
    '',
    '`measurement-selfcheck.json` records 9 parser checks: correct named counterexample and completed positive are accepted; wrong assertion, parser error, missing trace, wrong exit and missing positive completion are rejected; semantic errors cannot count as SANY success even with exit 0. These are measurement-parser checks, separate from model semantics. The actual 15 control traces were additionally read by this executor and matched to the state/transition changes recorded in `trace-inspections.json`; no expected-error output was discarded.',
    '',
    'Finite results do not establish actual StopOld isolation, old process/file/socket termination, cross-process locking, real crash/IO recovery, unknown opened request behavior, correct production Run-end recognition, valid authorization/full-prefix acquisition, lossless payload encoding, full-batch implementation atomicity, dense real positions, tenant initialization zero-write, complete failure priority, or infinite contention progress. Stable identities, batch atomicity and stopped-writer transitions are model abstraction premises. Those remain implementation/provider/runtime/reply/assembly obligations, exactly as the candidate formal README states. No refinement proof from model to implementation was performed.',
    '',
    'The first unsafe-recovery trace demonstrates a still-pending writer; committed-with-lost-ack exists in model transitions but was not separately captured by this first counterexample. Reach-Late shows direct late settlement after the boundary, not a first conflict then retry trace. Reach-Duplicate’s first trace only shows actor 1 winning. These narrower observations are preserved rather than expanded to claims about every branch.',
    '',
    'The candidate remains unaccepted. This result is passed to the root dispatcher for independent review and scoped disposition, without changing candidate registry, frozen inputs, bindings or verification navigation.',
])
(OUT / 'REPORT.md').write_text('\n'.join(lines) + '\n')

RESULTS['trace_inspections_path'] = 'trace-inspections.json'
RESULTS['all_traces_manually_read'] = len(trace_records) == 15
RESULTS['final_post_inspection_input_drift'] = drift
RESULTS['report_path'] = 'REPORT.md'
RESULTS['tool_versions'] = {'java': 'Temurin 21.0.12.1+1-LTS', 'sany': '2.2 (08 July 2020)', 'tlc': '2026.09.12.025210 (rev 867aefb)'}
(OUT / 'RESULTS.json').write_text(json.dumps(RESULTS, ensure_ascii=False, indent=2) + '\n')

inventory = {str(path.relative_to(OUT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(OUT.rglob('*')) if path.is_file() and path.name != 'artifact-inventory.json'}
(OUT / 'artifact-inventory.json').write_text(json.dumps(inventory, ensure_ascii=False, indent=2) + '\n')
if drift:
    raise SystemExit('Input drift after execution; preserve result against its frozen snapshot')
print(json.dumps({'tasks': len(RESULTS['tasks']), 'matched': RESULTS['matched_task_count'], 'traces_read': len(trace_records), 'input_drift': drift, 'report_sha256': hashlib.sha256((OUT / 'REPORT.md').read_bytes()).hexdigest(), 'results_sha256': hashlib.sha256((OUT / 'RESULTS.json').read_bytes()).hexdigest(), 'inventory_files': len(inventory)}, indent=2))
