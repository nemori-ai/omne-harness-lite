"""Execute the dispatched SL3 candidate without modifying candidate artifacts."""

import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import signal
import subprocess
import threading
import time
from datetime import datetime, timezone

SPOKE = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-b1-spec')
ROOT = SPOKE / '.meta_harness/design'
OUT = Path(__file__).resolve().parent
MANIFEST = SPOKE / 'tmp/model-request-runtime/b1-spec/output-sha256.json'
CANDIDATE = SPOKE / 'tmp/model-request-runtime/b1-spec/registry-candidate.json'
TIMEOUT = 300
EXPECTED_HEAD = '60c0652df9a396b5ef9af256809638be37b42c2a'
STOP = threading.Event()


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def parse_result(kind, expected, code, output):
    errors = bool(re.search(r'Parsing failed|Semantic errors|Lexical error|Syntax error|Error:.*(?:parse|syntax|semantic)', output, re.I))
    violated = re.findall(r'Invariant (\w+) is violated\.', output)
    states = re.findall(r'([\d,]+) states generated, ([\d,]+) distinct states found, ([\d,]+) states left on queue\.', output)
    depth = re.findall(r'The depth of the complete state graph search is (\d+)\.', output)
    trace_count = len(re.findall(r'^State \d+:', output, re.M))
    if kind == 'sany':
        passed = code == 0 and not errors and 'Semantic processing of module ' in output
    elif kind == 'positive':
        passed = code == 0 and not errors and not violated and 'Model checking completed. No error has been found.' in output and bool(states)
    else:
        passed = code == 12 and not errors and violated == [expected] and trace_count >= 2 and 'The behavior up to this point is:' in output and bool(states)
    return {'oracle_matched': passed, 'violated_assertions': violated, 'state_counts': [int(s.replace(',', '')) for s in states[-1]] if states else None, 'complete_search_depth': int(depth[-1]) if depth else None, 'trace_states': trace_count, 'syntax_or_semantic_error': errors}


def selfcheck():
    tail = '\n9 states generated, 7 distinct states found, 2 states left on queue.\n'
    negative = 'Error: Invariant TailGuardSound is violated.\nThe behavior up to this point is:\nState 1: <Initial predicate>\nState 2: <Commit>\n' + tail
    positive = 'Model checking completed. No error has been found.\n' + tail
    checks = {
        'accept_named_counterexample': parse_result('negative', 'TailGuardSound', 12, negative)['oracle_matched'],
        'reject_wrong_assertion': not parse_result('negative', 'LateCorrect', 12, negative)['oracle_matched'],
        'reject_syntax_error': not parse_result('negative', 'TailGuardSound', 12, negative + 'Syntax error')['oracle_matched'],
        'reject_missing_trace': not parse_result('negative', 'TailGuardSound', 12, tail + 'Invariant TailGuardSound is violated.')['oracle_matched'],
        'reject_zero_negative_exit': not parse_result('negative', 'TailGuardSound', 0, negative)['oracle_matched'],
        'reject_success_without_completion': not parse_result('positive', None, 0, tail)['oracle_matched'],
        'accept_completed_positive': parse_result('positive', None, 0, positive)['oracle_matched'],
        'reject_nonzero_positive': not parse_result('positive', None, 12, positive)['oracle_matched'],
        'reject_sany_error_even_exit_zero': not parse_result('sany', None, 0, 'Semantic processing of module X\nSemantic errors')['oracle_matched'],
    }
    write(OUT / 'measurement-selfcheck.json', checks)
    if not all(checks.values()):
        raise RuntimeError('Measurement parser selfcheck failed')


def check_inputs():
    actual = {path: sha(SPOKE / path) for path in frozen}
    return {path: {'expected': frozen[path], 'actual': digest} for path, digest in actual.items() if frozen[path] != digest}


def execute(task):
    folder = OUT / 'tasks' / task['id']
    folder.mkdir(parents=True, exist_ok=False)
    mismatch = check_inputs()
    if mismatch or STOP.is_set():
        STOP.set()
        result = {**task, 'status': 'not_executed_input_drift', 'input_drift': mismatch}
        write(folder / 'result.json', result)
        return result
    start = time.monotonic()
    with (folder / 'stdout.log').open('w') as stdout, (folder / 'stderr.log').open('w') as stderr:
        process = subprocess.Popen(task['argv'], cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True)
        runtime = {'id': task['id'], 'pid': process.pid, 'pgid': process.pid, 'started': now(), 'argv': task['argv'], 'cwd': str(ROOT), 'timeout_seconds': TIMEOUT, 'state': 'running'}
        write(folder / 'runtime.json', runtime)
        termination = None
        while process.poll() is None:
            if STOP.is_set():
                termination = 'input_drift_cancelled'
            elif time.monotonic() - start >= TIMEOUT:
                termination = 'tool_timeout'
            if termination:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                break
            time.sleep(0.2)
    output = (folder / 'stdout.log').read_text() + '\n' + (folder / 'stderr.log').read_text()
    after = check_inputs()
    if after:
        STOP.set()
    result = {**task, 'cwd': str(ROOT), 'started': runtime['started'], 'finished': now(), 'elapsed_seconds': round(time.monotonic() - start, 3), 'exit_code': process.returncode, 'termination': termination, 'input_drift': after, 'stdout_sha256': sha(folder / 'stdout.log'), 'stderr_sha256': sha(folder / 'stderr.log'), **parse_result(task['kind'], task.get('expected_assertion'), process.returncode, output)}
    if termination or after:
        result['oracle_matched'] = False
    result['status'] = 'matched' if result['oracle_matched'] else 'failed'
    write(folder / 'result.json', result)
    write(folder / 'runtime.json', {**runtime, 'state': 'terminated' if termination else 'completed', 'exit_code': process.returncode, 'finished': result['finished'], 'termination': termination})
    print(json.dumps({'id': task['id'], 'exit': process.returncode, 'status': result['status'], 'violation': result['violated_assertions'], 'states': result['state_counts'], 'trace_states': result['trace_states']}, ensure_ascii=False), flush=True)
    return result


def metadata_command(name, argv):
    completed = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True, timeout=30)
    (OUT / (name + '.stdout.log')).write_text(completed.stdout)
    (OUT / (name + '.stderr.log')).write_text(completed.stderr)
    return {'argv': argv, 'exit_code': completed.returncode, 'stdout_sha256': sha(OUT / (name + '.stdout.log')), 'stderr_sha256': sha(OUT / (name + '.stderr.log'))}


if __name__ == '__main__':
    branch = subprocess.check_output(['git', 'branch', '--show-current'], cwd=SPOKE, text=True).strip()
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SPOKE, text=True).strip()
    if branch != 'panqiwei/model-request-runtime-b1-spec' or head != EXPECTED_HEAD:
        raise RuntimeError('Spoke baseline mismatch')
    frozen = json.loads(MANIFEST.read_text())
    if frozen['.meta_harness/design/spec/capabilities/session-log/v3/contract.md'] != 'f7086724e58e736dc5dccc92dcd936eabda82c1cae5c0fbf523c966ed51e1fa8' or check_inputs():
        raise RuntimeError('Initial candidate hash mismatch')
    variables = {}
    for line in Path('/etc/environment').read_text().splitlines():
        match = re.match(r'^(JAVA_BIN|TLA2TOOLS_JAR)=(.*)$', line)
        if match:
            variables[match[1]] = shlex.split(match[2])[0]
    java = variables['JAVA_BIN']
    jar = variables['TLA2TOOLS_JAR']
    if jar != '/opt/tlaplus/tla2tools.jar':
        raise RuntimeError('Unexpected tool JAR path')
    selfcheck()
    snapshots = {}
    for relative in frozen:
        target = OUT / 'inputs' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SPOKE / relative, target)
        snapshots[relative] = sha(target)
    for original in (MANIFEST, CANDIDATE, SPOKE / 'tmp/model-request-runtime/b1-spec/SL3-CONSTRUCTION-BRIEF.md'):
        target = OUT / 'inputs' / original.name
        shutil.copyfile(original, target)
    write(OUT / 'input-snapshot.json', snapshots)
    candidate = json.loads(CANDIDATE.read_text())
    metadata = {'executor': '/root/b1_session_log_formal_verification', 'source_worktree': str(SPOKE), 'branch': branch, 'source_head': head, 'design_root': str(ROOT), 'started': now(), 'max_concurrent_processes': 3, 'workers_per_tlc_process': 1, 'timeout_seconds': TIMEOUT, 'jar_path': jar, 'jar_resolved_path': str(Path(jar).resolve()), 'jar_sha256': sha(Path(jar)), 'java_path': java, 'java_binary_sha256': sha(Path(java)), 'manifest_sha256': sha(MANIFEST), 'registry_candidate_sha256': sha(CANDIDATE), 'runner_sha256': sha(Path(__file__)), 'java_version': metadata_command('java-version', [java, '-version']), 'tlc_help': metadata_command('tlc-help', [java, '-cp', jar, 'tlc2.TLC', '-help']), 'argv_difference': 'Only -metadir target is replaced with the explicitly authorized absolute task evidence path. Registered model, config, flags and constants are unchanged.'}
    write(OUT / 'metadata.json', metadata)
    tasks = []
    formal = 'spec/capabilities/session-log/v3/formal/'
    for model in ('SessionLog', 'TailSettlement'):
        tasks.append({'id': 'sany-' + model, 'kind': 'sany', 'expected_assertion': None, 'argv': [java, '-cp', jar, 'tla2sany.SANY', formal + model + '.tla'], 'artifacts': [formal + model + '.tla']})
    positives = []
    for task in candidate['formal_tasks_append']:
        argv = [variables.get(arg[2:-1], arg) if arg.startswith('${') and arg.endswith('}') else arg for arg in task['command']]
        argv[argv.index('-metadir') + 1] = str(OUT / 'metadir' / task['id'])
        positives.append({'id': task['id'], 'kind': 'positive', 'expected_assertion': None, 'registered_argv': task['command'], 'argv': argv, 'artifacts': task['artifacts']})
    assertions = {'SessionLog_NoSerialization_Fence': 'FenceHolds', 'SessionLog_NoSerialization_Key': 'UniqueDedupeKey', 'SessionLog_Reach_DuplicateRejected': 'NeverDuplicateRejected', 'SessionLog_Reach_StaleRejected': 'NeverStaleRejected', 'SessionLog_VolatileDedupe': 'UniqueDedupeKey', 'TailSettlement_UnknownAsNoWrite': 'NoFalseNoWrite', 'TailSettlement_Reach_Duplicate': 'NeverDuplicateRejected', 'TailSettlement_Reach_Late': 'NeverLateSettled', 'TailSettlement_Reach_TailChanged': 'NeverTailChanged'}
    negatives = []
    for config in candidate['negative_configs_not_tasks']:
        name = Path(config).stem
        expected = assertions.get(name, 'LateCorrect' if '_PartialRead_' in name else 'TailGuardSound')
        model = 'SessionLog' if name.startswith('SessionLog_') else 'TailSettlement'
        template = next(task for task in positives if task['artifacts'][0].endswith('/' + model + '.tla'))
        argv = template['argv'].copy()
        argv[argv.index('-config') + 1] = config
        argv[argv.index('-metadir') + 1] = str(OUT / 'metadir' / name)
        negatives.append({'id': name, 'kind': 'negative_or_reachability', 'expected_assertion': expected, 'argv': argv, 'artifacts': [formal + model + '.tla', config]})
    write(OUT / 'commands.json', tasks + positives + negatives)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(execute, tasks))
        if all(result['oracle_matched'] for result in results):
            results.extend(executor.map(execute, positives + negatives))
    write(OUT / 'RESULTS.json', {'metadata': metadata, 'finished': now(), 'tasks': results, 'expected_task_count': 20, 'executed_task_count': len(results), 'matched_task_count': sum(result.get('oracle_matched', False) for result in results), 'final_input_drift': check_inputs(), 'candidate_accepted': False, 'real_implementation_verified': False, 'coverage': 'Finite safety exploration only. No fairness, infinite contention, actual StopOld/resource isolation, real IO/unknown-opened, full-batch implementation atomicity or production Run recognition is established.'})
    raise SystemExit(0 if len(results) == 20 and all(result.get('oracle_matched', False) for result in results) and not check_inputs() else 1)
