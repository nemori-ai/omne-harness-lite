from pathlib import Path
import json, hashlib, os, tarfile, shutil

root = Path.cwd()
source = root / 'tmp/model-request-runtime/b1-late-coordination/formal-v3-run-1'
run = root / '.meta_harness/design/record/evidence/2026-09-27-formal-session-log-v3'
assert not run.exists(), 'Never overwrite a run'
manifest = json.loads((source / 'artifact-inventory.json').read_text())
for name, digest in manifest.items():
    assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest, name
result = json.loads((source / 'RESULTS.json').read_text())
assert result['executed_task_count'] == result['matched_task_count'] == 20
assert not result['final_input_drift'] and not result['final_post_inspection_input_drift']
assert result['all_traces_manually_read'] and not result['candidate_accepted']
run.mkdir()
archive = run / 'inputs-and-raw-outputs.tar.gz'
members = []
with tarfile.open(archive, 'x:gz', dereference=False) as tar:
    for base, dirs, files in os.walk(source):
        dirs[:] = sorted(n for n in dirs if n not in ('metadir', '__pycache__'))
        for name in sorted(files):
            path = Path(base, name)
            assert not path.is_symlink(), path.name
            relative = str(path.relative_to(source))
            tar.add(path, arcname='formal-run-1/' + relative)
            members.append({'path': relative, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size})
    tar.add(Path(__file__), arcname='archive-formal-run-1.py')
with tarfile.open(archive, 'r:gz') as tar:
    for item in members:
        value = tar.extractfile('formal-run-1/' + item['path']).read()
        assert len(value) == item['bytes'] and hashlib.sha256(value).hexdigest() == item['sha256'], item['path']
for name in ['REPORT.md', 'RESULTS.json', 'commands.json', 'input-snapshot.json', 'artifact-inventory.json', 'measurement-selfcheck.json', 'trace-inspections.json']:
    shutil.copyfile(source / name, run / name)
inventory = {'files': members, 'readbackAllArchivedBytes': True, 'originalExecutorManifestVerified': len(manifest), 'excludedGeneratedDirectories': ['metadir', '__pycache__'], 'archives': [{'path': archive.name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size}]}
(run / 'input-and-output-hashes.json').write_text(json.dumps(inventory, indent=2) + '\n')
print(json.dumps({'run': str(run.relative_to(root)), 'files': len(members), 'executorManifestEntries': len(manifest), 'archive': inventory['archives'][0]}))
