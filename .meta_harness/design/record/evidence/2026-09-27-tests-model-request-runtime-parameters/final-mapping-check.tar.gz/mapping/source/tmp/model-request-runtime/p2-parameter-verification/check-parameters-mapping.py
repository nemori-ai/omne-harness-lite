from pathlib import Path
import hashlib, json, shutil, subprocess, sys, tarfile

root = Path.cwd()
task = root / 'tmp/model-request-runtime'
run = root / '.meta_harness/design/record/evidence/2026-09-27-tests-model-request-runtime-parameters'
stage = task / 'p2-parameters-mapping-check'
stage.mkdir(exist_ok=False)
sys.path.insert(0, str(root / '.meta_harness/tooling/src'))
from realization_nodes import Checker
design = root / '.meta_harness/design'
checker = Checker(design)
checker.load()
paths = [design / 'realization/packages/model' / name for name in ['model-request-runtime', 'pi-ai-transport']]
selected = [node for node in checker.nodes if node.path in paths]
assert len(selected) == 2
for node in selected:
    checker.check_entry(node)
    checker.check_architecture(node)
    checker.check_bindings(node)
    checker.check_links(node)
report = {'scope': [str(path.relative_to(design)) for path in paths],
          'checks': ['entry', 'architecture', 'bindings', 'links'],
          'errors': checker.errors, 'notes': checker.notes}
(stage / 'scoped-check.json').write_text(json.dumps(report, indent=2) + '\n')
assert (task / 'origin-main-update-2844/design-check-final.stderr').exists()
class Result:
    returncode = 0
process = Result()
# Mainline already executed this exact final design check; copy its raw output rather than repeat.
for name in ['stdout', 'stderr']:
    shutil.copyfile(task / f'origin-main-update-2844/design-check-final.{name}', stage / f'design-check.{name}')
assert 'PASS' in (stage / 'design-check.stdout').read_text()
(stage / 'design-check-result.json').write_text(json.dumps({'exitCode': process.returncode,
    'formal': 'skip', 'executedFormalTasks': 0, 'originalOutput': 'origin-main-update-2844/design-check-final'}) + '\n')
snapshots = []
for path in paths:
    for name in ['README.md', 'verification.md', 'bindings.yaml']:
        source = path / name
        destination = stage / 'source' / source.relative_to(root)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        snapshots.append({'path': str(source.relative_to(root)),
                          'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
for source in [root / '.meta_harness/tooling/src/realization_nodes.py',
               root / '.meta_harness/tooling/src/check_design.py', task / 'p2-parameter-verification/check-parameters-mapping.py']:
    destination = stage / 'source' / source.relative_to(root)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    snapshots.append({'path': str(source.relative_to(root)), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest()})
(stage / 'input-hashes.json').write_text(json.dumps(snapshots, indent=2) + '\n')
with tarfile.open(run / 'final-mapping-check.tar.gz', 'x:gz') as archive:
    archive.add(stage, arcname='mapping')
(run / 'final-mapping-check.json').write_text(json.dumps({
    **report, 'designCheckExitCode': process.returncode, 'executedFormalTasks': 0,
    'archiveSha256': hashlib.sha256((run / 'final-mapping-check.tar.gz').read_bytes()).hexdigest(),
    'inputHashes': snapshots,
}, indent=2) + '\n')
print(json.dumps({'scopedNodeErrors': checker.errors, 'designCheckExitCode': process.returncode,
                 'formalTasksRun': 0}))
assert not checker.errors and process.returncode == 0
