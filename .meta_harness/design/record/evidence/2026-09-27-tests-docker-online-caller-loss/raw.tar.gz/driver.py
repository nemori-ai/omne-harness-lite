#!/usr/bin/env python3
"""Static online backup caller-loss candidate. Docker requires a root review gate."""

import argparse
import hashlib
import io
import json
import pathlib
import re
import shutil
import subprocess
import sys
import tarfile
import time

import base_driver as base

HERE = pathlib.Path(__file__).resolve().parent
I3_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
BUILD_ID = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
IMAGE_ID = "sha256:27c0665146265afefe39012aaea26bdae7499784eaaeb74aea712a6fcdfc03f2"
IMAGE_TAR_SHA = "503fc0c6006d5d654e1e288bbff1af806ec041163d56223bac7e322391653de2"
HELPER_SHA = "71ba9f3c31b34c171dd2a4048d9e249af31f7948abcf66ee603da5ffb7d1b365"
DOCKER_SPEC_SHA = "3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223"
FD_PATH = re.compile(r"/state/backups/\.quarantine/export-[0-9a-f]{32}\Z")
MARKER = base.STATE + "/backups/.quarantine/.omne-isolated"
CLI = "/opt/omne/app/dist/cli.js"
HT3_SHA = "1836b2ba0a08ed03d28d98617cf5ca8d35ac6619863ab9cbf2b8d347df02c91a"
EC3_SHA = "8c638900033558faffb077a4a67d34be51c94c580c171745533eb4c8a73aae19"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def canonical_hash(value):
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


def checked_inputs(args):
    base.V0 = args.v0_dir
    paths = {
        "driver": HERE / "driver.py", "base_driver": HERE / "base_driver.py",
        "oracle": HERE / "oracle.py", "gate": HERE / "gate.mjs",
        "gate_availability": HERE / "gate_availability.mjs",
        "inventory": HERE / "inventory.mjs",
        "client_probe": HERE / "client_probe.mjs",
        "client_signal": HERE / "client_signal.mjs",
        "client_absence": HERE / "client_absence.mjs",
        "backup_directory": HERE / "backup_directory.mjs",
        "i3_manifest": args.i3_manifest,
        "image_tar": args.image_tar,
        "host_build_info": args.helper_dir.parents[1] / "build-info.json",
        "host_build_id": args.helper_dir.parents[1] / "BUILD_ID",
        "helper": args.helper_dir / "omne-center",
        "compose": args.helper_dir / "compose.yaml",
        "maintenance_compose": args.helper_dir / "compose.maintenance.yaml",
        "health": args.helper_dir / "health.mjs",
        "service": args.helper_dir / "omne-center-backup@.service",
        "timer": args.helper_dir / "omne-center-backup@.timer",
        "compose_binary": args.v0_dir / "docker-compose-linux-aarch64",
        "docker_cli": args.v0_dir / "extracted-bin/docker",
        "docker_spec": args.design_root / "realization/apps/tenancy-host/docker.md",
        "ec3_contract": args.design_root / "spec/compositions/governance-center-entry/v3/contract.md",
        "ht3_contract": args.design_root / "spec/compositions/governance-center-entry-https-json/v3/contract.md",
        "ops_plugin": HERE.parents[1] / "packages/tenancy/governance-center-entry/src/ops/plugin.ts",
        "maintenance_command": HERE.parents[1] / "apps/tenancy-host/src/maintenance-command.ts",
    }
    actual = {name: base.sha(path) for name, path in paths.items()}
    manifest = json.loads(args.i3_manifest.read_text())
    arm = manifest["images"]["arm64"]
    host = manifest["archives"]["host"]
    require(actual["i3_manifest"] == I3_SHA and actual["docker_spec"] == DOCKER_SPEC_SHA
            and actual["ec3_contract"] == EC3_SHA and actual["ht3_contract"] == HT3_SHA,
            "adopted inputs changed")
    require(manifest["source"]["commit"] == "f8f286c95cb9458fe3173190edbeab6076339b08",
            "I3 source commit changed")
    require(arm["imageId"] == IMAGE_ID and arm["archiveSha256"] == IMAGE_TAR_SHA
            and arm["buildId"] == BUILD_ID and host["buildId"] == BUILD_ID,
            "I3 artifact identity changed")
    require(actual["image_tar"] == IMAGE_TAR_SHA, "final I3 image tar differs")
    require(actual["host_build_info"] == host["fullFileManifestSha256"] and
            paths["host_build_id"].read_text().strip() == BUILD_ID and
            json.loads(paths["host_build_info"].read_text())["buildId"] == BUILD_ID,
            "final I3 packaged host inventory differs")
    require(actual["helper"] == HELPER_SHA and
            all(actual[name] == manifest["deployFiles"][filename]["packagedSha256"]
                for name, filename in (("compose", "compose.yaml"),
                                       ("maintenance_compose", "compose.maintenance.yaml"),
                                       ("health", "health.mjs"),
                                       ("service", "omne-center-backup@.service"),
                                       ("timer", "omne-center-backup@.timer"))),
            "final I3 helper files changed")
    require(actual["compose_binary"] == base.COMPOSE_SHA and actual["docker_cli"] == base.CLI_SHA,
            "fixed V0 tool bytes changed")
    require(args.uid == 10001 and args.gid == 10001 and args.hold_seconds >= 31.25,
            "reviewed UID or hold lower bound changed")
    require(args.scenario == "client-killed", "only one caller-loss scenario")
    require(args.observe_seconds >= 90 and args.client_observe_seconds > 0,
            "observation budget invalid")
    # Relocation of the exact immutable artifact is allowed; the packaged app
    # build-info and every deployment file are checked by bytes, not source path.
    return {"paths": {key: str(value.resolve()) for key, value in paths.items()},
            "sha256": actual, "image_id": IMAGE_ID, "build_id": BUILD_ID,
            "host_manifest_sha256": host["fullFileManifestSha256"],
            "uid": args.uid, "gid": args.gid, "scenario": args.scenario,
            "hold_seconds": args.hold_seconds, "observe_seconds": args.observe_seconds,
            "client_observe_seconds": args.client_observe_seconds}


def reviewed_inputs(args, inputs):
    require(args.reviewed_gate is not None, "root-reviewed gate required")
    gate = json.loads(args.reviewed_gate.read_text())
    require(gate.get("approved") is True and gate.get("reviewer") == "root"
            and gate.get("inputs_sha256") == canonical_hash(inputs)
            and gate.get("driver_sha256") == inputs["sha256"]["driver"]
            and gate.get("oracle_sha256") == inputs["sha256"]["oracle"],
            "missing or stale root-reviewed gate")


class IoRun(base.Run):
    def __init__(self, args, inputs):
        super().__init__(args, inputs)
        for name in ("driver.py", "base_driver.py", "gate.mjs", "gate_availability.mjs",
                     "inventory.mjs", "client_probe.mjs", "client_signal.mjs",
                     "client_absence.mjs", "backup_directory.mjs"):
            source = HERE / name
            target = self.frozen / name
            shutil.copyfile(source, target)
            require(base.sha(target) == inputs["sha256"][name.removesuffix(".py").removesuffix(".mjs")],
                    "script changed during freeze")
        shutil.copyfile(args.i3_manifest, self.frozen / "i3-manifest.json")
        self.evidence["scenario"] = args.scenario
        self.evidence["hold_seconds"] = args.hold_seconds
        self.evidence["artifact_manifest_sha256"] = inputs["sha256"]["i3_manifest"]
        self.save()
        self.async_clients = {}

    def asynchronous(self, label, argv):
        require(label not in self.async_clients, "duplicate async client")
        out = pathlib.Path("raw") / f"{label}.stdout"
        err = pathlib.Path("raw") / f"{label}.stderr"
        item = {"label": label, "argv": argv, "stdout": str(out), "stderr": str(err),
                "started_utc": base.utc(), "started_monotonic_ns": time.monotonic_ns(),
                "returncode": None, "observation_expired": False}
        self.evidence["commands"].append(item)
        self.save()
        stdout = (self.run / out).open("xb")
        stderr = (self.run / err).open("xb")
        try:
            process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=stdout,
                                       stderr=stderr, close_fds=True)
        finally:
            stdout.close()
            stderr.close()
        self.async_clients[label] = (item, process)
        self.pending_clients.append((label, process))
        return process

    def finish_async(self, label, timeout):
        item, process = self.async_clients[label]
        try:
            item["returncode"] = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            item["observation_expired"] = True
        item["finished_utc"] = base.utc()
        item["finished_monotonic_ns"] = time.monotonic_ns()
        self.save()
        require(not item["observation_expired"], label + ": result unknown after observation budget")

    def await_file(self, label, path, seconds=30):
        deadline = time.monotonic() + seconds
        for attempt in range(1, int(seconds * 5) + 2):
            observed = self.control_exec(f"{label}-poll-{attempt}", "test", "-f", path,
                                         expected=None, timeout=8)
            if self.evidence["commands"][-1]["returncode"] == 0:
                return json.loads(self.control_exec(label, "cat", path))
            if time.monotonic() >= deadline:
                break
            time.sleep(0.2)
        raise RuntimeError(label + ": file absent, outcome unknown")

    def prepare_qa(self):
        uid = str(self.args.uid)
        gid = str(self.args.gid)
        self.control_exec("qa-dir", "install", "-d", "-m", "0700", "-o", uid, "-g", gid,
                          base.STATE + "/qa")
        self.outer("qa-mode", "exec", "-i", self.control, "tee", base.STATE + "/qa/mode",
                   stdin=b"write-hold\n")
        self.control_exec("qa-mode-owner", "chown", f"{uid}:{gid}", base.STATE + "/qa/mode")
        self.control_exec("qa-mode-permission", "chmod", "0600", base.STATE + "/qa/mode")
        dockerfile = (f"FROM {self.image_id}\nUSER 0:0\n"
                      "RUN install -d -m 0755 -o 0 -g 0 /probe\n"
                      "COPY --chown=10001:10001 gate.mjs /probe/gate.mjs\n"
                      "RUN chmod 0444 /probe/gate.mjs\n"
                      "USER 10001:10001\nENV NODE_OPTIONS=--import=/probe/gate.mjs\n"
                      "LABEL ai.nemori.omne.qa-fixture=online-caller-loss/r1\n")
        context = self.run / "qa-context.tar"
        with tarfile.open(context, "w") as tar:
            for name, contents in (("Dockerfile", dockerfile.encode()),
                                   ("gate.mjs", (self.frozen / "gate.mjs").read_bytes())):
                entry = tarfile.TarInfo(name)
                entry.size = len(contents)
                entry.mode = 0o644
                entry.mtime = 0
                tar.addfile(entry, io.BytesIO(contents))
        self.evidence["qa_context_sha256"] = base.sha(context)
        self.qa_tag = "omne-r5-io-qa:" + self.run_id.lower().replace("t", "-").replace("z", "")
        self.outer("qa-build", "exec", "-i", self.control, "docker", "--host", base.SOCKET,
                   "build", "--network=none", "--pull=false", "--no-cache", "-t", self.qa_tag,
                   "-", stdin=context, timeout=600)
        qa = json.loads(self.inner("qa-image-inspect", "image", "inspect", self.qa_tag))[0]
        require(qa["Id"] != self.image_id and qa["Config"]["User"] == "10001:10001"
                and qa["Config"]["Labels"].get("ai.nemori.omne.qa-fixture") == "online-caller-loss/r1",
                "QA image boundary invalid")
        self.qa_id = qa["Id"]
        self.evidence["qa_image_id"] = self.qa_id
        for label, image in (("original-inventory", self.image_id),
                             ("qa-inventory", self.qa_id)):
            self.outer(label, "exec", "-i", self.control, "docker", "--host", base.SOCKET,
                       "run", "--rm", "-i", "--pull", "never", "--network", "none",
                       "--label", self.label, "--entrypoint", "node", "-e", "NODE_OPTIONS=",
                       "-e", f"EXPECTED_BUILD_ID={BUILD_ID}",
                       "-e", f"EXPECTED_MANIFEST_SHA256={self.evidence['inputs']['host_manifest_sha256']}",
                       image, "--input-type=module", "-", stdin=self.frozen / "inventory.mjs",
                       timeout=180)
        original = json.loads((self.run / "raw/original-inventory.stdout").read_text())
        checked = json.loads((self.run / "raw/qa-inventory.stdout").read_text())
        require(original == checked and original.get("status") == "verified",
                "QA app inventory differs from production")
        gate_sha = self.evidence["inputs"]["sha256"]["gate"]
        self.outer("gate-availability", "exec", "-i", self.control, "docker", "--host", base.SOCKET,
                   "run", "--rm", "-i", "--pull", "never", "--network", "none",
                   "--label", self.label, "--user", f"{uid}:{gid}", "--entrypoint", "node",
                   "-e", "NODE_OPTIONS=", "-e", f"EXPECTED_GATE_SHA256={gate_sha}",
                   "-e", f"EXPECTED_UID={uid}", "-e", f"EXPECTED_GID={gid}",
                   self.qa_id, "--input-type=module", "-",
                   stdin=self.frozen / "gate_availability.mjs")
        avail = json.loads((self.run / "raw/gate-availability.stdout").read_text())
        require(avail.get("status") == "pass" and avail["directory"]["mode"] == "755",
                "QA preload unavailable to application UID")
        self.save()

    def await_client_pid(self, cid, pid_path):
        deadline = time.monotonic() + self.args.client_observe_seconds
        for attempt in range(1, 101):
            if time.monotonic() >= deadline:
                break
            label = f"client-pid-{attempt}"
            data = self.inner(label, "exec", cid, "cat", pid_path, expected=None, timeout=8)
            if self.evidence["commands"][-1]["returncode"] == 0:
                try:
                    pid = int(data.strip())
                except ValueError as error:
                    raise RuntimeError("client pidfile malformed") from error
                require(pid > 1, "pidfile points at server PID1 or unsafe PID")
                script = (self.frozen / "client_probe.mjs").read_text()
                probe_label = f"client-probe-{attempt}"
                output = self.inner(probe_label, "exec", cid, "node", "--input-type=module",
                                    "-e", script, str(pid), expected=None, timeout=8)
                if self.evidence["commands"][-1]["returncode"] != 0:
                    time.sleep(0.15)
                    continue
                observed = base.parse_json_line(output, probe_label)
                args = observed.get("argv")
                if (observed.get("pid") == pid and isinstance(args, list) and
                        len(args) == 6 and pathlib.PurePosixPath(args[0]).name == "node" and
                        args[1:] == [CLI, "ops", "--socket-dir", "/run/omne-tenancy", "backup"]):
                    self.evidence["client_pid"] = pid
                    self.evidence["client_pid_label"] = label
                    self.evidence["client_probe_label"] = probe_label
                    self.save()
                    return pid
                time.sleep(0.15)
            if self.async_clients["backup-client"][1].poll() is not None:
                break
            time.sleep(0.15)
        raise RuntimeError("exact inner backup client PID not observed; outcome unknown")

    def await_client_absence(self, cid, pid):
        deadline = time.monotonic() + self.args.client_observe_seconds
        script = (self.frozen / "client_absence.mjs").read_text()
        for attempt in range(1, 101):
            if time.monotonic() >= deadline:
                break
            label = f"client-absence-{attempt}"
            result = base.parse_json_line(self.inner(label, "exec", cid, "node",
                "--input-type=module", "-e", script, str(pid)), label)
            require(result.get("pid") == pid, "absence probe checked another PID")
            if result.get("absent") is True and result.get("reason") == "ENOENT":
                self.evidence["client_absence_label"] = label
                self.save()
                return
            time.sleep(0.15)
        raise RuntimeError("signalled inner client PID did not disappear; outcome unknown")

    def observe_owner(self, cid, held, stage):
        fd = f"/proc/1/fd/{held['fd']}"
        self.inner(stage + "-inspect", "inspect", cid)
        self.inner(stage + "-fd-readlink", "exec", cid, "readlink", fd)
        self.inner(stage + "-fd-stat", "exec", cid, "stat", "-Lc", "%d:%i:%u:%g:%a", fd)
        self.control_exec(stage + "-marker-stat", "stat", "-c", "%F:%d:%i:%u:%g:%a:%s", MARKER)
        self.control_exec(stage + "-marker-content", "cat", MARKER)
        self.helper(stage + "-full-health", "full-health", "--project", self.project)

    def candidate_directory(self, label):
        script = (self.frozen / "backup_directory.mjs").read_text()
        result = base.parse_json_line(self.control_exec(label, "node", "--input-type=module",
            "-e", script, base.STATE + "/backups"), label)
        require(result.get("directory") == base.STATE + "/backups" and
                isinstance(result.get("names"), list), "candidate directory probe invalid")
        return result["names"]

    def scenario(self):
        common = ["--project", self.project]
        deployment = [*common, "--image", self.qa_id, "--state-dir", base.STATE,
                      "--secrets-dir", base.SECRETS, "--settings-file", base.SETTINGS,
                      "--publish-address", "127.0.0.1", "--publish-port", "18443",
                      "--uid", str(self.args.uid), "--gid", str(self.args.gid)]
        self.helper("validate", "validate", *deployment)
        started = base.parse_json_line(self.helper("start", "start", *deployment,
            timeout=self.args.observe_seconds), "start")
        cid = started.get("containerId")
        require(isinstance(cid, str) and base.HEX64.fullmatch(cid), "center exact ID absent")
        self.evidence["center_id"] = cid
        self.save()
        self.await_file("gate-ready", base.STATE + "/qa/ready")
        self.inner("center-before", "inspect", cid)
        self.helper("initial-full-health", "full-health", *common)
        require(self.candidate_directory("candidates-before") == [],
                "private fixture unexpectedly has existing backups")
        self.control_exec("held-before-arm", "test", "!", "-e", base.STATE + "/qa/held")
        self.control_exec("arm-gate", "touch", base.STATE + "/qa/arm")
        pidfile = "/run/omne-tenancy/qa-ops-backup-client.pid"
        self.inner("client-pidfile-absent", "exec", cid, "sh", "-c",
                   'test ! -e "$1"', "sh", pidfile)
        event_start = base.utc()
        self.evidence["event_start_utc"] = event_start
        self.save()
        shell = 'printf "%s\\n" "$$" > "$1"; shift; exec "$@"'
        argv = ["docker", "exec", self.control, "docker", "--host", base.SOCKET,
                "exec", cid, "sh", "-c", shell, "sh", pidfile, "node", CLI,
                "ops", "--socket-dir", "/run/omne-tenancy", "backup"]
        self.asynchronous("backup-client", argv)
        pid = self.await_client_pid(cid, pidfile)
        held = self.await_file("gate-held", base.STATE + "/qa/held")
        require(held.get("stage") == "write" and held.get("pid") == 1 and
                type(held.get("fd")) is int and held["fd"] >= 0 and
                isinstance(held.get("path"), str) and FD_PATH.fullmatch(held["path"]),
                "gate missed real online backup FileHandle")
        self.evidence["held"] = held
        self.evidence["held_monotonic_ns"] = time.monotonic_ns()
        self.save()
        self.observe_owner(cid, held, "pre-kill")
        probe_script = (self.frozen / "client_probe.mjs").read_text()
        current = base.parse_json_line(self.inner("client-probe-before-kill", "exec", cid,
            "node", "--input-type=module", "-e", probe_script, str(pid)),
            "client-probe-before-kill")
        words = current.get("argv")
        require(current.get("pid") == pid and isinstance(words, list) and
                len(words) == 6 and pathlib.PurePosixPath(words[0]).name == "node" and
                words[1:] == [CLI, "ops", "--socket-dir", "/run/omne-tenancy", "backup"],
                "known client PID changed before SIGKILL")
        signal_script = (self.frozen / "client_signal.mjs").read_text()
        self.inner("signal-client", "exec", cid, "node", "--input-type=module",
                   "-e", signal_script, str(pid))
        self.evidence["kill_monotonic_ns"] = time.monotonic_ns()
        self.save()
        self.await_client_absence(cid, pid)
        self.finish_async("backup-client", self.args.observe_seconds)
        self.evidence["client_outcome"] = {
            "outer_docker_returncode": self.async_clients["backup-client"][0]["returncode"],
            "stdout_bytes": (self.run / "raw/backup-client.stdout").stat().st_size,
        }
        self.save()
        self.observe_owner(cid, held, "after-kill")
        self.helper("status-busy", "backup-status", *common, expected=2)
        require(self.candidate_directory("candidates-held") == [],
                "backup published before held FD released")
        time.sleep(self.args.hold_seconds)
        self.evidence["midpoint_monotonic_ns"] = time.monotonic_ns()
        self.save()
        self.observe_owner(cid, held, "after-hold")
        self.helper("status-busy-late", "backup-status", *common, expected=2)
        self.control_exec("release-gate", "touch", base.STATE + "/qa/release")
        self.evidence["release_monotonic_ns"] = time.monotonic_ns()
        self.save()
        deadline = time.monotonic() + self.args.observe_seconds
        for attempt in range(1, 101):
            if time.monotonic() >= deadline:
                break
            label = f"status-poll-{attempt}"
            output = self.helper(label, "backup-status", *common,
                                 expected=None, timeout=30)
            code = self.evidence["commands"][-1]["returncode"]
            observed = base.parse_json_line(output, label)
            if (code == 0 and observed.get("status") == "observed" and
                    observed.get("health") == "current"):
                self.evidence["final_status_label"] = label
                self.save()
                break
            require(code == 2 and observed == {"status": "busy"},
                    "status after release neither busy nor current; outcome unknown")
            time.sleep(0.25)
        else:
            raise RuntimeError("published backup status not observed in finite budget")
        require("final_status_label" in self.evidence,
                "published backup status not observed in finite budget")
        names = self.candidate_directory("candidates-final")
        require(len(names) == 1 and re.fullmatch(r"[0-9a-f]{32}\.omne-backup", names[0]),
                "unique published backup absent")
        source = base.STATE + "/backups/" + names[0]
        self.evidence["source"] = source
        self.control_exec("source-stat", "stat", "-c", "%F:%u:%g:%a:%s", source)
        self.control_exec("source-sha-before", "sha256sum", source)
        work = base.STATE + "/offline-work/" + self.project + "-confirm"
        self.control_exec("verify-work-absent", "test", "!", "-e", work)
        self.helper("verify-published", "verify", *common, "--image", self.image_id,
                    "--state-dir", base.STATE, "--source", source, "--work-dir", work,
                    "--uid", str(self.args.uid), "--gid", str(self.args.gid),
                    timeout=self.args.observe_seconds)
        self.control_exec("source-sha-final", "sha256sum", source)
        self.control_exec("marker-stat-final", "stat", "-c", "%F:%d:%i:%u:%g:%a:%s", MARKER)
        self.control_exec("marker-content-final", "cat", MARKER)
        self.inner("center-final", "inspect", cid)
        self.helper("final-full-health", "full-health", *common)
        self.inner("center-events", "events", "--since", event_start,
                   "--until", base.utc(), "--filter", f"container={cid}",
                   "--format", "{{json .}}", timeout=20)
        self.evidence["business_complete"] = True
        self.evidence["status"] = "observed-awaiting-oracle"
        self.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=("client-killed",), required=True)
    parser.add_argument("--i3-manifest", type=pathlib.Path, required=True)
    parser.add_argument("--image-tar", type=pathlib.Path, required=True)
    parser.add_argument("--helper-dir", type=pathlib.Path, required=True)
    parser.add_argument("--v0-dir", type=pathlib.Path, required=True)
    parser.add_argument("--design-root", type=pathlib.Path, required=True)
    parser.add_argument("--uid", type=int, default=10001)
    parser.add_argument("--gid", type=int, default=10001)
    parser.add_argument("--hold-seconds", type=float, default=31.5)
    parser.add_argument("--client-observe-seconds", type=float, default=15.0)
    parser.add_argument("--observe-seconds", type=int, default=180)
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    inputs = checked_inputs(args)
    if args.print_inputs:
        print(json.dumps({"inputs": inputs, "inputs_sha256": canonical_hash(inputs)}, sort_keys=True))
        return 0
    require(args.execute, "Docker execution requires --execute")
    reviewed_inputs(args, inputs)
    # base.Run expects exact input identities when it freezes final packaged files.
    args.image_id = IMAGE_ID
    args.build_id = BUILD_ID
    run = IoRun(args, inputs)
    try:
        run.setup()
        run.import_image()
        run.prepare_paths()
        run.prepare_qa()
        run.scenario()
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
        run.save()
    finally:
        run.cleanup()
        for kind, argv in (("container", ["ps", "-aq", "--filter", f"label={run.label}"]),
                           ("network", ["network", "ls", "-q", "--filter", f"label={run.label}"]),
                           ("volume", ["volume", "ls", "-q", "--filter", f"label={run.label}"])):
            try:
                output = run.outer("independent-host-" + kind, *argv, expected=0)
                require(not output.strip(), "independent exact-label host query found " + kind)
            except BaseException as error:
                run.evidence.setdefault("independent_host_errors", []).append(str(error))
                run.save()
    with (run.run / "oracle.stdout").open("xb") as stdout, (run.run / "oracle.stderr").open("xb") as stderr:
        checked = subprocess.run([sys.executable, "-B", str(run.frozen / "oracle.py"), str(run.run)],
                                 stdout=stdout, stderr=stderr, check=False)
    run.evidence["oracle_exit"] = checked.returncode
    run.save()
    print(json.dumps({"run": str(run.run), "scenario": args.scenario,
                      "oracle_exit": checked.returncode,
                      "cleanup_complete": run.evidence["cleanup_complete"]}, sort_keys=True))
    return 0 if checked.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
