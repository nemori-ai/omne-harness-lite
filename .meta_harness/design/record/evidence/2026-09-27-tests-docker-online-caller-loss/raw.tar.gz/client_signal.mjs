// Signal only the previously probed app-container client PID.
const text = process.argv[1]
if (!/^[1-9][0-9]*$/.test(text)) throw new Error('positive client PID required')
const pid = Number(text)
if (!Number.isSafeInteger(pid) || pid <= 1) throw new Error('unsafe client PID')
process.kill(pid, 'SIGKILL')
process.stdout.write(JSON.stringify({ pid, signal: 'SIGKILL', accepted: true }) + '\n')
