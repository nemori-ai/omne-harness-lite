// Direct candidate-name listing only. Do not emit the protected backup bytes.
import { readdir } from 'node:fs/promises'
const directory = process.argv[1]
if (directory !== '/var/lib/omne-tenancy/state/backups') throw new Error('wrong backup directory')
const names = (await readdir(directory)).filter(name => /^[0-9a-f]{32}\.omne-backup$/.test(name)).sort()
process.stdout.write(JSON.stringify({ directory, names }) + '\n')
