#!/usr/bin/env python3
"""Raw-output oracle for one known inner ops-backup client SIGKILL."""

import base64
from datetime import date
import hashlib
import json
import pathlib
import re
import sys

BUILD_ID = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
ORIGINAL = "sha256:27c0665146265afefe39012aaea26bdae7499784eaaeb74aea712a6fcdfc03f2"
I3_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
SOCKET = "unix:///opt/omne-private-docker/docker.sock"
STATE = "/var/lib/omne-tenancy/state"
HELPER = "/usr/local/libexec/omne-center"
CLI = "/opt/omne/app/dist/cli.js"
MARKER = STATE + "/backups/.quarantine/.omne-isolated"
MARKER_CONTENT = b"omne-isolated/1\n"
SOURCE = re.compile(r"/state/backups/\.quarantine/export-[0-9a-f]{32}\Z")
FILE = re.compile(r"[0-9a-f]{32}\.omne-backup\Z")
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
UTC = re.compile(r"([0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2})(?:\.([0-9]+))?Z\Z")
META = {"format", "centerId", "sourceBuildId", "migrationNames", "startedAt",
        "finishedAt", "byteLength", "sha256"}
HEALTH = {"reachable", "centerId", "version", "startedAt", "storageReachable",
          "deploymentKeyPresent", "deploymentKeyComplete", "clockSane", "defectCount",
          "deploymentParameters"}


def demand(ok, message):
    if not ok:
        raise ValueError(message)


def one(data, label):
    demand(data.endswith(b"\n") and data.count(b"\n") == 1,
           label + ": one JSON+LF required")
    result = json.loads(data)
    demand(isinstance(result, dict), label + ": object required")
    return result


def utc(value, label):
    demand(isinstance(value, str), label + ": time text required")
    match = UTC.fullmatch(value)
    demand(match is not None, label + ": UTC Z shape required")
    prefix, fraction = match.groups()
    try:
        date(int(prefix[:4]), int(prefix[5:7]), int(prefix[8:10]))
    except ValueError as error:
        raise ValueError(label + ": invalid Gregorian day") from error
    demand(int(prefix[11:13]) < 24 and int(prefix[14:16]) < 60 and
           int(prefix[17:19]) < 60, label + ": invalid clock time")
    fraction = (fraction or "").rstrip("0")
    return prefix + ("." + fraction if fraction else "") + "Z"


def metadata_equal(source, inspected, label):
    demand(isinstance(source, dict) and isinstance(inspected, dict) and
           set(source) == set(inspected) == META, label + ": metadata keys")
    for key in META - {"startedAt", "finishedAt"}:
        demand(type(source[key]) is type(inspected[key]) and source[key] == inspected[key],
               label + ": non-time metadata changed " + key)
    for key in ("startedAt", "finishedAt"):
        original = utc(source[key], label + ".source." + key)
        actual = utc(inspected[key], label + ".inspected." + key)
        demand(original == source[key], label + ": online time not HT3 minimal")
        demand(original == actual, label + ": timepoint changed " + key)


def marker_stat(data, label):
    parts = data.decode("ascii", "strict").strip().split(":")
    demand(len(parts) == 7 and parts[0] == "regular file" and
           all(part.isdigit() for part in parts[1:]), label + ": marker stat")
    return tuple(map(int, parts[1:]))


def numeric_stat(data, label, count):
    parts = data.decode("ascii", "strict").strip().split(":")
    demand(len(parts) == count and all(part.isdigit() for part in parts), label + ": stat")
    return tuple(map(int, parts))


def evaluate_observation(e, raw):
    entries = e["commands"]
    rows = {item["label"]: item for item in entries}
    demand(len(rows) == len(entries), "duplicate command label")
    demand(e["scenario"] == "client-killed" and e["business_complete"] is True and
           e["status"] == "observed-awaiting-oracle" and
           e["artifact_manifest_sha256"] == I3_SHA and
           e["inputs"]["build_id"] == BUILD_ID and e["inputs"]["image_id"] == ORIGINAL,
           "business observation or I3 input incomplete")
    order = [item["label"] for item in entries]
    stages = ["original-inventory", "qa-inventory", "gate-availability", "validate", "start",
              "gate-ready", "center-before", "initial-full-health", "candidates-before",
              "held-before-arm", "arm-gate", "client-pidfile-absent", "backup-client",
              "gate-held", "pre-kill-inspect", "pre-kill-fd-stat",
              "client-probe-before-kill",
              "signal-client", "after-kill-inspect", "after-kill-fd-stat",
              "status-busy", "candidates-held", "after-hold-inspect",
              "after-hold-fd-stat", "status-busy-late", "release-gate",
              "candidates-final", "source-stat", "source-sha-before",
              "verify-work-absent", "verify-published", "source-sha-final",
              "marker-stat-final", "marker-content-final", "center-final",
              "final-full-health", "center-events"]
    demand(all(label in rows for label in stages) and
           [order.index(label) for label in stages] == sorted(order.index(label) for label in stages),
           "scenario stage/order missing")

    def row(label, code=0):
        item = rows[label]
        demand(item["returncode"] == code and item.get("observation_expired") is False,
               label + ": client rc or observation expired")
        return item

    def out(label, stream="stdout"):
        value = raw.get((label, stream))
        demand(isinstance(value, bytes), label + ": missing raw " + stream)
        return value

    def obj(label, code=0):
        row(label, code)
        return one(out(label), label)

    def inspect(label, cid):
        row(label)
        result = json.loads(out(label))
        demand(isinstance(result, list) and len(result) == 1 and result[0].get("Id") == cid,
               label + ": wrong exact CID")
        return result[0]

    original = obj("original-inventory")
    demand(original == obj("qa-inventory") ==
           {"status": "verified", "buildId": BUILD_ID, "files": 2851, "links": 115,
            "manifestSha256": e["inputs"]["host_manifest_sha256"], "node": "v24.21.0"},
           "full app file/link inventory changed")
    qa = inspect("qa-image-inspect", e["qa_image_id"])
    product = inspect("inner-image-inspect", e["expected"]["inner_image_id"])
    outer = inspect("outer-product-image", ORIGINAL)
    demand(qa["Id"] != product["Id"] and
           qa["RootFS"]["Layers"][:len(product["RootFS"]["Layers"])] ==
           product["RootFS"]["Layers"] == outer["RootFS"]["Layers"] and
           qa["Config"]["Labels"].get("ai.nemori.omne.qa-fixture") ==
           "online-caller-loss/r1" and qa["Config"]["User"] == "10001:10001" and
           sorted(qa["Config"]["Env"]) == sorted([*product["Config"]["Env"],
                 "NODE_OPTIONS=--import=/probe/gate.mjs"]) and
           qa["Config"]["Entrypoint"] == product["Config"]["Entrypoint"] and
           qa["Config"]["Cmd"] == product["Config"]["Cmd"],
           "QA image exceeded preload boundary")
    gate_avail = obj("gate-availability")
    demand(gate_avail.get("status") == "pass" and gate_avail.get("uid") ==
           gate_avail.get("gid") == 10001 and gate_avail.get("directory", {}).get("mode") ==
           "755" and gate_avail.get("file", {}).get("mode") == "444" and
           gate_avail.get("actualSha256") == e["inputs"]["sha256"]["gate"],
           "QA preload unavailable/wrong bytes")
    cid = e["center_id"]
    demand(isinstance(cid, str) and HEX64.fullmatch(cid), "center CID invalid")
    control = e["expected"]["control"]
    helper_prefix = ["docker", "exec", "-e", "DOCKER_HOST=" + SOCKET, control, HELPER]
    inner_prefix = ["docker", "exec", control, "docker", "--host", SOCKET]
    for label, action in (("validate", "validate"), ("start", "start"),
                          ("initial-full-health", "full-health"),
                          ("pre-kill-full-health", "full-health"),
                          ("after-kill-full-health", "full-health"),
                          ("after-hold-full-health", "full-health"),
                          ("final-full-health", "full-health"),
                          ("status-busy", "backup-status"),
                          ("status-busy-late", "backup-status"),
                          ("verify-published", "verify")):
        demand(rows[label]["argv"][:len(helper_prefix) + 1] == [*helper_prefix, action],
               label + ": not official private helper")
    demand(not any(item["argv"][:len(helper_prefix) + 1] == [*helper_prefix, "backup"]
                   for item in entries) and
           not any(item["argv"][:len(helper_prefix) + 1] == [*helper_prefix, "stop"]
                   for item in entries) and
           sum(1 for item in entries if item["label"] == "backup-client") == 1 and
           sum(any(item["argv"][index:index + 5] ==
                   [CLI, "ops", "--socket-dir", "/run/omne-tenancy", "backup"]
                   for index in range(len(item["argv"]))) for item in entries) == 1,
           "backup replay or server stop appeared")
    started = obj("start")
    demand(started.get("containerId") == cid and started.get("state") == "running" and
           started.get("health") == "healthy" and started.get("buildId") == BUILD_ID and
           started.get("imageId") == e["qa_image_id"], "QA center not actually started")
    ready = obj("gate-ready")
    held = obj("gate-held")
    demand(ready == {"stage": "ready", "mode": "write-hold", "pid": 1, "armed": False} and
           held == e["held"] and held.get("stage") == "write" and held.get("pid") == 1 and
           type(held.get("fd")) is int and held["fd"] >= 0 and
           isinstance(held.get("path"), str) and SOURCE.fullmatch(held["path"]) and
           type(held.get("dev")) is int and type(held.get("ino")) is int,
           "gate did not hold real online export FileHandle")
    row("held-before-arm")
    row("arm-gate")
    demand(rows["arm-gate"]["argv"] == ["docker", "exec", control,
           "touch", STATE + "/qa/arm"], "gate arm wrong path")
    server = inspect("center-before", cid)
    running = [server]
    marker_first = None
    for stage in ("pre-kill", "after-kill", "after-hold"):
        prefix = stage + "-"
        running.append(inspect(prefix + "inspect", cid))
        fd = "/proc/1/fd/" + str(held["fd"])
        row(prefix + "fd-readlink")
        demand(rows[prefix + "fd-readlink"]["argv"] ==
               [*inner_prefix, "exec", cid, "readlink", fd] and
               out(prefix + "fd-readlink").decode().strip() == held["path"],
               stage + ": FD link changed")
        row(prefix + "fd-stat")
        demand(rows[prefix + "fd-stat"]["argv"] ==
               [*inner_prefix, "exec", cid, "stat", "-Lc", "%d:%i:%u:%g:%a", fd] and
               numeric_stat(out(prefix + "fd-stat"), stage, 5) ==
               (held["dev"], held["ino"], 10001, 10001, 600),
               stage + ": original FD/inode/owner released")
        row(prefix + "marker-stat")
        marker = marker_stat(out(prefix + "marker-stat"), stage)
        demand(rows[prefix + "marker-stat"]["argv"][-1] == MARKER and
               rows[prefix + "marker-content"]["argv"][-1] == MARKER and
               marker[2:] == (10001, 10001, 600, len(MARKER_CONTENT)) and
               out(prefix + "marker-content") == MARKER_CONTENT,
               stage + ": protection marker changed")
        row(prefix + "marker-content")
        marker_first = marker if marker_first is None else marker_first
        demand(marker == marker_first, stage + ": marker inode changed")
    final = inspect("center-final", cid)
    for item in (*running, final):
        demand(item["Image"] == e["qa_image_id"] and
               item["Config"]["User"] == "10001:10001" and
               item["Config"]["StopSignal"] == "SIGTERM" and
               item["HostConfig"]["RestartPolicy"]["Name"] == "unless-stopped" and
               item["State"]["Status"] == "running" and
               item["State"]["Pid"] == server["State"]["Pid"] > 0 and
               item["State"]["StartedAt"] == server["State"]["StartedAt"] and
               any(m.get("Destination") == "/state" and
                   m.get("Source") == e["expected"]["state"] for m in item["Mounts"]),
               "server PID1/source owner changed or stopped")
    pid = e["client_pid"]
    demand(type(pid) is int and pid > 1, "unsafe known inner client PID")
    pidfile = "/run/omne-tenancy/qa-ops-backup-client.pid"
    row("client-pidfile-absent")
    demand(rows["client-pidfile-absent"]["argv"] ==
           [*inner_prefix, "exec", cid, "sh", "-c", 'test ! -e "$1"', "sh", pidfile],
           "client pidfile was not checked absent")
    wrapper = rows["backup-client"]["argv"]
    expected_wrapper = [*inner_prefix, "exec", cid, "sh", "-c",
                        'printf "%s\\n" "$$" > "$1"; shift; exec "$@"', "sh",
                        pidfile, "node", CLI, "ops", "--socket-dir", "/run/omne-tenancy", "backup"]
    demand(wrapper == expected_wrapper, "backup client not original one-shot app CLI")
    probe_label = e["client_probe_label"]
    pid_label = e["client_pid_label"]
    demand(re.fullmatch(r"client-probe-[0-9]+", probe_label) and
           re.fullmatch(r"client-pid-[0-9]+", pid_label) and
           probe_label in rows and pid_label in rows and
           order.index("backup-client") < order.index(pid_label) <
           order.index(probe_label) < order.index("gate-held"),
           "known client PID/probe not anchored before FileHandle hold")
    probe = obj(probe_label)
    probe_command = rows[probe_label]["argv"]
    demand(probe_command[:len(inner_prefix) + 5] ==
           [*inner_prefix, "exec", cid, "node", "--input-type=module", "-e"] and
           len(probe_command) == len(inner_prefix) + 7 and probe_command[-1] == str(pid) and
           hashlib.sha256(probe_command[-2].encode()).hexdigest() ==
           e["inputs"]["sha256"]["client_probe"],
           "client probe not exact reviewed /proc script")
    decoded = base64.b64decode(probe["cmdlineBase64"], validate=True)
    demand(decoded.endswith(b"\0") and len(decoded) > 1 and
           decoded[:-1].decode("utf8", "strict").split("\0") == probe["argv"] and
           probe["pid"] == pid and len(probe["argv"]) == 6 and
           pathlib.PurePosixPath(probe["argv"][0]).name == "node" and
           probe["argv"][1:] == [CLI, "ops", "--socket-dir", "/run/omne-tenancy", "backup"],
           "known PID not the inner app backup client")
    second_probe = obj("client-probe-before-kill")
    second_command = rows["client-probe-before-kill"]["argv"]
    demand(second_command == probe_command and second_probe == probe and
           order.index("pre-kill-fd-stat") < order.index("client-probe-before-kill") <
           order.index("signal-client"),
           "known inner client PID changed before SIGKILL")
    pid_record = row(pid_label)
    demand(pid_record["argv"] == [*inner_prefix, "exec", cid, "cat", pidfile] and
           int(out(pid_label).strip()) == pid,
           "pidfile did not prove the probed inner PID")
    signal = obj("signal-client")
    signal_argv = rows["signal-client"]["argv"]
    demand(signal_argv[:len(inner_prefix) + 5] ==
           [*inner_prefix, "exec", cid, "node", "--input-type=module", "-e"] and
           len(signal_argv) == len(inner_prefix) + 7 and signal_argv[-1] == str(pid) and
           hashlib.sha256(signal_argv[-2].encode()).hexdigest() ==
           e["inputs"]["sha256"]["client_signal"] and
           signal == {"pid": pid, "signal": "SIGKILL", "accepted": True} and
           sum(item["label"] == "signal-client" for item in entries) == 1,
           "one exact inner-client SIGKILL not proved")
    absence_label = e["client_absence_label"]
    absence = obj(absence_label)
    absence_argv = rows[absence_label]["argv"]
    demand(order.index("signal-client") < order.index(absence_label) <
           order.index("after-kill-inspect") and
           absence_argv[:len(inner_prefix) + 5] ==
           [*inner_prefix, "exec", cid, "node", "--input-type=module", "-e"] and
           len(absence_argv) == len(inner_prefix) + 7 and absence_argv[-1] == str(pid) and
           hashlib.sha256(absence_argv[-2].encode()).hexdigest() ==
           e["inputs"]["sha256"]["client_absence"] and
           absence == {"pid": pid, "absent": True, "reason": "ENOENT"},
           "signalled inner client PID not actually gone")
    client = row("backup-client", rows["backup-client"]["returncode"])
    demand(type(client["returncode"]) is int and
           out("backup-client") == b"" and
           e["client_outcome"]["outer_docker_returncode"] == client["returncode"] and
           e["client_outcome"]["stdout_bytes"] == 0 and
           client["finished_monotonic_ns"] < e["release_monotonic_ns"] and
           order.index("backup-client") < order.index("gate-held") <
           order.index("signal-client") < order.index("release-gate"),
           "lost client produced false completed output or lived beyond release")
    demand(e["midpoint_monotonic_ns"] - e["kill_monotonic_ns"] >=
           31_000_000_000 and e["release_monotonic_ns"] > e["midpoint_monotonic_ns"] and
           e["held_monotonic_ns"] < e["kill_monotonic_ns"],
           "known-client loss hold/release order wrong")
    for label in ("status-busy", "status-busy-late"):
        demand(obj(label, 2) == {"status": "busy"}, label + ": busy became missing/success")
    def check_health(label):
        result = obj(label)
        demand(set(result) == HEALTH and result["reachable"] is True and
               result["storageReachable"] is True and result["clockSane"] is True and
               result["deploymentKeyPresent"] is True and
               result["deploymentKeyComplete"] is True and
               result["centerId"] == health_before["centerId"] and
               result["startedAt"] == health_before["startedAt"] and
               result["version"] == health_before["version"] and
               type(result["defectCount"]) is int and result["defectCount"] == 0 and
               result["deploymentParameters"] == health_before["deploymentParameters"],
               label + ": full-health/server identity not current")
        return result
    health_before = obj("initial-full-health")
    demand(set(health_before) == HEALTH and health_before["reachable"] is True and
           health_before["storageReachable"] is True and
           health_before["clockSane"] is True and
           health_before["deploymentKeyPresent"] is True and
           health_before["deploymentKeyComplete"] is True and
           type(health_before["defectCount"]) is int and
           health_before["defectCount"] == 0 and
           set(health_before["deploymentParameters"]) ==
           {"unactivatedRetention", "invitationTtlDefault",
            "affiliationRequestTtlDefault", "copyNoticeTtlDefault",
            "sharingInvitationTtlDefault"} and
           all(type(value) is int and value > 0 for value in
               health_before["deploymentParameters"].values()) and
           re.fullmatch(r"[0-9a-f]{32}", health_before["centerId"]),
           "initial full-health unavailable")
    for label in ("pre-kill-full-health", "after-kill-full-health",
                  "after-hold-full-health", "final-full-health"):
        check_health(label)
    directory_script = e["inputs"]["sha256"]["backup_directory"]
    def directory(label):
        command = row(label)["argv"]
        demand(command[:5] == ["docker", "exec", control, "node", "--input-type=module"] and
               command[5] == "-e" and len(command) == 8 and
               hashlib.sha256(command[6].encode()).hexdigest() == directory_script and
               command[7] == STATE + "/backups", label + ": wrong directory probe")
        result = obj(label)
        demand(result["directory"] == STATE + "/backups" and
               isinstance(result["names"], list) and
               all(isinstance(name, str) and FILE.fullmatch(name) for name in result["names"]),
               label + ": candidate listing invalid")
        return result["names"]
    demand(directory("candidates-before") == directory("candidates-held") == [],
           "backup candidate appeared before gate release")
    row("release-gate")
    demand(rows["release-gate"]["argv"] ==
           ["docker", "exec", control, "touch", STATE + "/qa/release"],
           "gate release wrong path")
    poll_labels = [item["label"] for item in entries if re.fullmatch(r"status-poll-[0-9]+", item["label"])]
    demand(poll_labels and poll_labels[-1] == e["final_status_label"] and
           order.index("release-gate") < order.index(poll_labels[0]) and
           order.index(poll_labels[-1]) < order.index("candidates-final"),
           "explicit new status confirmation absent")
    latest = None
    for label in poll_labels:
        argv = rows[label]["argv"]
        demand(argv[:len(helper_prefix) + 1] == [*helper_prefix, "backup-status"],
               label + ": status poll replayed backup")
        code = rows[label]["returncode"]
        result = obj(label, code)
        if label == poll_labels[-1]:
            demand(code == 0 and result.get("status") == "observed" and
                   result.get("health") == "current" and result.get("invalidCount") == 0 and
                   isinstance(result.get("latest"), dict),
                   "explicit status did not confirm current published backup")
            latest = result["latest"]
        else:
            demand(code == 2 and result == {"status": "busy"},
                   "interim status was not busy")
    names = directory("candidates-final")
    demand(len(names) == 1 and latest.get("fileName") == names[0] and
           isinstance(latest.get("metadata"), dict) and
           set(latest) == {"fileName", "metadata"},
           "status latest not unique published file")
    source = e["source"]
    demand(source == STATE + "/backups/" + names[0], "source path not latest")
    row("source-stat")
    source_stat = out("source-stat").decode().strip().split(":")
    demand(len(source_stat) == 5 and source_stat[0] == "regular file" and
           source_stat[1:4] == ["10001", "10001", "600"] and
           source_stat[4].isdigit() and int(source_stat[4]) > 0,
           "published archive not owned/private/nonempty")
    row("source-sha-before")
    row("source-sha-final")
    demand(out("source-sha-before") == out("source-sha-final") and
           source.encode() in out("source-sha-final"), "published archive changed")
    verified = obj("verify-published")
    verify_argv = rows["verify-published"]["argv"]
    demand(verify_argv.count("--image") == 1 and
           verify_argv[verify_argv.index("--image") + 1] == e["expected"]["inner_image_id"] and
           verify_argv.count("--source") == 1 and
           verify_argv[verify_argv.index("--source") + 1] == source and
           verify_argv.count("--work-dir") == 1 and
           verify_argv[verify_argv.index("--work-dir") + 1] ==
           STATE + "/offline-work/" + e["expected"]["project"] + "-confirm" and
           verified.get("status") == "verified" and verified.get("businessOpen") is False and
           set(verified) == {"status", "metadata", "businessOpen"},
           "original image did not verify same unique archive")
    metadata_equal(latest["metadata"], verified["metadata"], "verify")
    demand(latest["metadata"]["centerId"] == health_before["centerId"],
           "confirmed backup belongs to another center")
    marker_final = marker_stat(out("marker-stat-final"), "final")
    demand(row("marker-stat-final")["argv"][-1] == MARKER and
           row("marker-content-final")["argv"][-1] == MARKER and
           out("marker-content-final") == MARKER_CONTENT and
           marker_final == marker_first,
           "protection marker removed/replaced after close")
    row("marker-content-final")
    events = [json.loads(line) for line in out("center-events").splitlines() if line.strip()]
    row("center-events")
    demand(f"container={cid}" in rows["center-events"]["argv"] and
           not any(event.get("Action") in ("kill", "die", "start", "restart") and
                   event.get("Actor", {}).get("ID") == cid for event in events),
           "server was signalled or restarted")
    demand(e.get("cleanup_complete") is True and not e.get("cleanup_errors") and
           not e.get("independent_host_errors"), "private fixture cleanup incomplete")
    for kind in ("container", "network", "volume"):
        label = "independent-host-" + kind
        row(label)
        demand(out(label).strip() == b"", "host exact-label resources remain")
    return {"status": "limited_pass", "scenario": "client-killed", "containerId": cid,
            "publishedFile": names[0], "clientPid": pid,
            "kill_to_midpoint_seconds": (e["midpoint_monotonic_ns"] - e["kill_monotonic_ns"]) / 1e9}


def evaluate(run):
    e = json.loads((run / "evidence.json").read_text())
    for name in ("driver.py", "base_driver.py", "oracle.py", "gate.mjs",
                 "inventory.mjs", "gate_availability.mjs", "client_probe.mjs",
                 "client_signal.mjs", "client_absence.mjs", "backup_directory.mjs",
                 "i3-manifest.json"):
        key = name.removesuffix(".py").removesuffix(".mjs")
        expected = I3_SHA if name == "i3-manifest.json" else e["inputs"]["sha256"][key]
        demand(hashlib.sha256((run / "inputs" / name).read_bytes()).hexdigest() == expected,
               "frozen input changed: " + name)
    raw = {}
    for item in e["commands"]:
        for stream in ("stdout", "stderr"):
            path = run / item[stream]
            demand(path.is_file() and path.parent == run / "raw", "missing raw " + item["label"])
            raw[item["label"], stream] = path.read_bytes()
    return evaluate_observation(e, raw)


if __name__ == "__main__":
    try:
        print(json.dumps(evaluate(pathlib.Path(sys.argv[1])), sort_keys=True))
    except (KeyError, ValueError, TypeError, IndexError, OSError, UnicodeError,
            json.JSONDecodeError) as error:
        print(json.dumps({"status": "unverified", "error": f"{type(error).__name__}: {error}"},
                         sort_keys=True))
        raise SystemExit(1)
