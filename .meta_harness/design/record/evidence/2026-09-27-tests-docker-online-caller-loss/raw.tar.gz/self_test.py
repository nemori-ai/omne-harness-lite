#!/usr/bin/env python3
"""Synthetic good and adversarial raw observations; never runs Docker."""

import base64
import copy
import hashlib
import json
from pathlib import Path

import oracle

HERE = Path(__file__).parent


def j(value):
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def change_verify_metadata(raw, change):
    result = json.loads(raw["verify-published", "stdout"])
    change(result["metadata"])
    raw["verify-published", "stdout"] = j(result)


def duplicate_backup(e, raw):
    existing = next(x for x in e["commands"] if x["label"] == "backup-client")
    another = copy.deepcopy(existing)
    another["label"] = "backup-client-2"
    e["commands"].insert(e["commands"].index(existing) + 1, another)
    raw["backup-client-2", "stdout"] = b""
    raw["backup-client-2", "stderr"] = b""


def fixture():
    cid = "a" * 64
    qa_id = "sha256:" + "c" * 64
    original = oracle.ORIGINAL
    project = "r5abcd"
    control = "private-control"
    source = oracle.STATE + "/backups/" + "e" * 32 + ".omne-backup"
    filename = source.rsplit("/", 1)[1]
    held_path = "/state/backups/.quarantine/export-" + "d" * 32
    held = {"stage": "write", "path": held_path, "fd": 17, "pid": 1,
            "dev": 2048, "ino": 901}
    pid = 212
    inner = ["docker", "exec", control, "docker", "--host", oracle.SOCKET]
    helper = ["docker", "exec", "-e", "DOCKER_HOST=" + oracle.SOCKET, control, oracle.HELPER]
    rows = []
    raw = {}

    def add(label, argv=None, output=b"", rc=0, stderr=b"", **extra):
        rows.append({"label": label, "argv": argv or [], "returncode": rc,
                     "observation_expired": False, **extra})
        raw[label, "stdout"] = output if isinstance(output, bytes) else j(output)
        raw[label, "stderr"] = stderr if isinstance(stderr, bytes) else j(stderr)

    def image(image_id, qa=False):
        value = {"Id": image_id, "RootFS": {"Layers": ["original-layer"]},
                 "Config": {"Env": [], "Entrypoint": ["node"], "Cmd": ["serve"],
                            "Labels": {"ai.nemori.omne.host-build-id": oracle.BUILD_ID}}}
        if qa:
            value["RootFS"]["Layers"].append("probe-layer")
            value["Config"]["User"] = "10001:10001"
            value["Config"]["Env"] = ["NODE_OPTIONS=--import=/probe/gate.mjs"]
            value["Config"]["Labels"]["ai.nemori.omne.qa-fixture"] = "online-caller-loss/r1"
        return value

    def center():
        return {"Id": cid, "Image": qa_id,
                "Config": {"User": "10001:10001", "StopSignal": "SIGTERM"},
                "HostConfig": {"RestartPolicy": {"Name": "unless-stopped"}},
                "State": {"Status": "running", "Pid": 900, "StartedAt": "once"},
                "Mounts": [{"Destination": "/state", "Source": oracle.STATE}]}

    health = {"reachable": True, "centerId": "f" * 32, "version": "1",
              "startedAt": "2026-09-27T00:00:00Z", "storageReachable": True,
              "deploymentKeyPresent": True, "deploymentKeyComplete": True,
              "clockSane": True, "defectCount": 0,
              "deploymentParameters": {"unactivatedRetention": 1,
                "invitationTtlDefault": 1, "affiliationRequestTtlDefault": 1,
                "copyNoticeTtlDefault": 1, "sharingInvitationTtlDefault": 1}}
    metadata = {"format": "omne-center-backup/1", "centerId": health["centerId"],
                "sourceBuildId": oracle.BUILD_ID, "migrationNames": ["0001_account_identity"],
                "startedAt": "2026-09-27T00:01:00Z",
                "finishedAt": "2026-09-27T00:01:00.4Z",
                "byteLength": 1000, "sha256": "9" * 64}
    inventory = {"status": "verified", "buildId": oracle.BUILD_ID, "files": 2851,
                 "links": 115, "manifestSha256": "8" * 64, "node": "v24.21.0"}
    add("inner-image-inspect", output=[image(original)])
    add("outer-product-image", output=[image(original)])
    add("qa-image-inspect", output=[image(qa_id, True)])
    add("original-inventory", output=inventory)
    add("qa-inventory", output=inventory)
    add("gate-availability", output={"status": "pass", "uid": 10001, "gid": 10001,
                                      "directory": {"mode": "755"},
                                      "file": {"mode": "444"},
                                      "actualSha256": "1" * 64})
    add("validate", [*helper, "validate"], {"state": "deployment-structure-valid"})
    add("start", [*helper, "start"], {"containerId": cid, "state": "running",
                                         "health": "healthy", "buildId": oracle.BUILD_ID,
                                         "imageId": qa_id})
    add("gate-ready", output={"stage": "ready", "mode": "write-hold", "pid": 1,
                              "armed": False})
    add("center-before", output=[center()])
    add("initial-full-health", [*helper, "full-health"], health)
    directory_script = (HERE / "backup_directory.mjs").read_text()
    directory_argv = ["docker", "exec", control, "node", "--input-type=module", "-e",
                      directory_script, oracle.STATE + "/backups"]
    add("candidates-before", directory_argv, {"directory": oracle.STATE + "/backups", "names": []})
    add("held-before-arm")
    add("arm-gate", ["docker", "exec", control, "touch", oracle.STATE + "/qa/arm"])
    pidfile = "/run/omne-tenancy/qa-ops-backup-client.pid"
    add("client-pidfile-absent", [*inner, "exec", cid, "sh", "-c",
                                  'test ! -e "$1"', "sh", pidfile])
    shell = 'printf "%s\\n" "$$" > "$1"; shift; exec "$@"'
    add("backup-client", [*inner, "exec", cid, "sh", "-c", shell, "sh", pidfile,
                          "node", oracle.CLI, "ops", "--socket-dir", "/run/omne-tenancy",
                          "backup"], rc=137, started_monotonic_ns=1_000_000_000,
        finished_monotonic_ns=5_000_000_000)
    add("client-pid-1", [*inner, "exec", cid, "cat", pidfile], f"{pid}\n".encode())
    probe_script = (HERE / "client_probe.mjs").read_text()
    probe_argv = [*inner, "exec", cid, "node", "--input-type=module", "-e",
                  probe_script, str(pid)]
    cmdline = ("/usr/local/bin/node\0" + oracle.CLI +
               "\0ops\0--socket-dir\0/run/omne-tenancy\0backup\0").encode()
    probe = {"pid": pid, "cmdlineBase64": base64.b64encode(cmdline).decode(),
             "argv": ["/usr/local/bin/node", oracle.CLI, "ops", "--socket-dir",
                      "/run/omne-tenancy", "backup"]}
    add("client-probe-1", probe_argv, probe)
    add("gate-held", output=held)
    for stage in ("pre-kill", "after-kill", "after-hold"):
        if stage == "after-kill":
            signal_script = (HERE / "client_signal.mjs").read_text()
            absence_script = (HERE / "client_absence.mjs").read_text()
            add("client-probe-before-kill", probe_argv, probe)
            add("signal-client", [*inner, "exec", cid, "node", "--input-type=module",
                                  "-e", signal_script, str(pid)],
                {"pid": pid, "signal": "SIGKILL", "accepted": True})
            add("client-absence-1", [*inner, "exec", cid, "node", "--input-type=module",
                                     "-e", absence_script, str(pid)],
                {"pid": pid, "absent": True, "reason": "ENOENT"})
        add(stage + "-inspect", output=[center()])
        fd = "/proc/1/fd/17"
        add(stage + "-fd-readlink", [*inner, "exec", cid, "readlink", fd],
            (held_path + "\n").encode())
        add(stage + "-fd-stat", [*inner, "exec", cid, "stat", "-Lc", "%d:%i:%u:%g:%a", fd],
            b"2048:901:10001:10001:600\n")
        add(stage + "-marker-stat", ["docker", "exec", control, "stat", oracle.MARKER],
            b"regular file:2048:777:10001:10001:600:16\n")
        add(stage + "-marker-content", ["docker", "exec", control, "cat", oracle.MARKER],
            oracle.MARKER_CONTENT)
        add(stage + "-full-health", [*helper, "full-health"], health)
        if stage == "after-kill":
            add("status-busy", [*helper, "backup-status"], {"status": "busy"}, rc=2)
            add("candidates-held", directory_argv,
                {"directory": oracle.STATE + "/backups", "names": []})
        if stage == "after-hold":
            add("status-busy-late", [*helper, "backup-status"], {"status": "busy"}, rc=2)
    add("release-gate", ["docker", "exec", control, "touch", oracle.STATE + "/qa/release"])
    status = {"status": "observed", "health": "current", "latest":
              {"fileName": filename, "metadata": metadata}, "invalidCount": 0}
    add("status-poll-1", [*helper, "backup-status"], status)
    add("candidates-final", directory_argv,
        {"directory": oracle.STATE + "/backups", "names": [filename]})
    add("source-stat", output=b"regular file:10001:10001:600:1100\n")
    digest = ("2" * 64 + "  " + source + "\n").encode()
    add("source-sha-before", output=digest)
    add("verify-work-absent")
    offline_metadata = copy.deepcopy(metadata)
    offline_metadata["startedAt"] = "2026-09-27T00:01:00.000Z"
    offline_metadata["finishedAt"] = "2026-09-27T00:01:00.400Z"
    add("verify-published", [*helper, "verify", "--image", original, "--source", source,
                              "--work-dir", oracle.STATE + "/offline-work/" + project + "-confirm"],
        {"status": "verified", "metadata": offline_metadata, "businessOpen": False})
    add("source-sha-final", output=digest)
    add("marker-stat-final", ["docker", "exec", control, "stat", oracle.MARKER],
        b"regular file:2048:777:10001:10001:600:16\n")
    add("marker-content-final", ["docker", "exec", control, "cat", oracle.MARKER],
        oracle.MARKER_CONTENT)
    add("center-final", output=[center()])
    add("final-full-health", [*helper, "full-health"], health)
    add("center-events", [*inner, "events", "--filter", f"container={cid}"], b"")
    for kind in ("container", "network", "volume"):
        add("independent-host-" + kind, output=b"")
    e = {"commands": rows, "scenario": "client-killed", "business_complete": True,
         "status": "observed-awaiting-oracle", "artifact_manifest_sha256": oracle.I3_SHA,
         "inputs": {"build_id": oracle.BUILD_ID, "image_id": original,
                    "host_manifest_sha256": "8" * 64,
                    "sha256": {"gate": "1" * 64,
                               "client_probe": hashlib.sha256(probe_script.encode()).hexdigest(),
                               "client_signal": hashlib.sha256(signal_script.encode()).hexdigest(),
                               "client_absence": hashlib.sha256(absence_script.encode()).hexdigest(),
                               "backup_directory": hashlib.sha256(directory_script.encode()).hexdigest()}},
         "expected": {"inner_image_id": original, "control": control,
                      "state": oracle.STATE, "project": project},
         "qa_image_id": qa_id, "center_id": cid, "held": held,
         "source": source, "client_pid": pid, "client_pid_label": "client-pid-1",
         "client_probe_label": "client-probe-1", "client_absence_label": "client-absence-1",
         "client_outcome": {"outer_docker_returncode": 137, "stdout_bytes": 0},
         "held_monotonic_ns": 2_000_000_000, "kill_monotonic_ns": 3_000_000_000,
         "midpoint_monotonic_ns": 35_000_000_000,
         "release_monotonic_ns": 37_000_000_000,
         "final_status_label": "status-poll-1", "cleanup_complete": True,
         "cleanup_errors": []}
    return e, raw


def main():
    baseline = fixture()
    assert oracle.evaluate_observation(*baseline)["status"] == "limited_pass"
    zero_outer = copy.deepcopy(baseline)
    next(x for x in zero_outer[0]["commands"] if x["label"] == "backup-client")["returncode"] = 0
    zero_outer[0]["client_outcome"]["outer_docker_returncode"] = 0
    assert oracle.evaluate_observation(*zero_outer)["status"] == "limited_pass"
    cases = {
        "wrong-client-pid": lambda e, r: e.__setitem__("client_pid", 999),
        "client-is-server": lambda e, r: e.__setitem__("client_pid", 1),
        "wrong-client-cmdline": lambda e, r: r.__setitem__(("client-probe-1", "stdout"), j({"pid":212,"cmdlineBase64":"","argv":[]})),
        "pid-reused-before-kill": lambda e, r: r.__setitem__(("client-probe-before-kill", "stdout"), j({"pid":212,"cmdlineBase64":"","argv":[]})),
        "wrong-kill-script": lambda e, r: next(x for x in e["commands"] if x["label"]=="signal-client")["argv"].__setitem__(-2,"process.exit(0)"),
        "wrong-kill-pid": lambda e, r: next(x for x in e["commands"] if x["label"]=="signal-client")["argv"].__setitem__(-1,"900"),
        "client-not-absent": lambda e, r: r.__setitem__(("client-absence-1", "stdout"),j({"pid":212,"absent":False})),
        "outer-rc-as-success": lambda e, r: r.__setitem__(("backup-client", "stdout"),j({"status":"completed"})),
        "automatic-backup-replay": duplicate_backup,
        "client-finished-after-release": lambda e, r: next(x for x in e["commands"] if x["label"]=="backup-client").__setitem__("finished_monotonic_ns",38_000_000_000),
        "short-hold": lambda e, r: e.__setitem__("midpoint_monotonic_ns",33_000_000_000),
        "server-exited": lambda e, r: r.__setitem__(("after-kill-inspect", "stdout"),j([{"Id":"a"*64,"Image":"bad"}])),
        "fd-inode-changed": lambda e, r: r.__setitem__(("after-kill-fd-stat", "stdout"),b"2048:902:10001:10001:600\n"),
        "fd-link-gone": lambda e, r: r.__setitem__(("after-hold-fd-readlink", "stdout"),b"\n"),
        "marker-gone": lambda e, r: r.__setitem__(("after-kill-marker-content", "stdout"),b""),
        "full-health-broken": lambda e, r: r.__setitem__(("after-kill-full-health", "stdout"),j({"reachable":False})),
        "busy-misread-missing": lambda e, r: r.__setitem__(("status-busy", "stdout"),j({"status":"observed","health":"missing","latest":None,"invalidCount":0})),
        "premature-published": lambda e, r: r.__setitem__(("candidates-held", "stdout"),j({"directory":oracle.STATE+"/backups","names":["e"*32+".omne-backup"]})),
        "status-not-current": lambda e, r: r.__setitem__(("status-poll-1", "stdout"),j({"status":"observed","health":"missing","latest":None,"invalidCount":0})),
        "status-replays-backup": lambda e, r: next(x for x in e["commands"] if x["label"]=="status-poll-1")["argv"].__setitem__(6,"backup"),
        "two-published-files": lambda e, r: r.__setitem__(("candidates-final", "stdout"),j({"directory":oracle.STATE+"/backups","names":["e"*32+".omne-backup","f"*32+".omne-backup"]})),
        "source-mutated": lambda e, r: r.__setitem__(("source-sha-final", "stdout"),b"changed\n"),
        "wrong-center-id": lambda e, r: r.__setitem__(("initial-full-health", "stdout"),j({"reachable":True,"centerId":"0"*32})),
        "verify-false-business-open": lambda e, r: r.__setitem__(("verify-published", "stdout"),j({"status":"verified","metadata":{},"businessOpen":True})),
        "metadata-changed": lambda e, r: r.__setitem__(("verify-published", "stdout"),j({"status":"verified","metadata":{},"businessOpen":False})),
        "metadata-time-changed-1ms": lambda e, r: change_verify_metadata(r, lambda m: m.__setitem__("finishedAt","2026-09-27T00:01:00.401Z")),
        "metadata-time-changed-subms": lambda e, r: change_verify_metadata(r, lambda m: m.__setitem__("finishedAt","2026-09-27T00:01:00.4001Z")),
        "metadata-time-invalid-day": lambda e, r: change_verify_metadata(r, lambda m: m.__setitem__("finishedAt","2026-02-30T00:01:00.4Z")),
        "metadata-time-no-zone": lambda e, r: change_verify_metadata(r, lambda m: m.__setitem__("finishedAt","2026-09-27T00:01:00.4")),
        "no-server-cleanup": lambda e, r: e.__setitem__("business_complete",False),
        "host-resource-left": lambda e, r: r.__setitem__(("independent-host-volume", "stdout"),b"left\n"),
        "server-kill-event": lambda e, r: r.__setitem__(("center-events", "stdout"),j({"Action":"kill","Actor":{"ID":"a"*64}})),
    }
    refused = []
    for name, mutation in cases.items():
        e, raw = copy.deepcopy(baseline)
        mutation(e, raw)
        try:
            oracle.evaluate_observation(e, raw)
        except (ValueError, KeyError, TypeError, IndexError, json.JSONDecodeError):
            refused.append(name)
        else:
            raise AssertionError("false pass: " + name)
    print(json.dumps({"positive": 2, "negative_refused": len(refused), "cases": refused},
                     sort_keys=True))


if __name__ == "__main__":
    main()
