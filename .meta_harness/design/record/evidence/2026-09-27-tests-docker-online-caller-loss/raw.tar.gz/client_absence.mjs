// Inspect only the recorded app-container client PID after signalling.
import { lstat } from 'node:fs/promises'
const text = process.argv[1]
if (!/^[1-9][0-9]*$/.test(text)) throw new Error('positive client PID required')
const pid = Number(text)
if (!Number.isSafeInteger(pid) || pid <= 1) throw new Error('unsafe client PID')
try {
  await lstat(`/proc/${pid}`)
  process.stdout.write(JSON.stringify({ pid, absent: false }) + '\n')
} catch (error) {
  if (error?.code !== 'ENOENT') throw error
  process.stdout.write(JSON.stringify({ pid, absent: true, reason: 'ENOENT' }) + '\n')
}
