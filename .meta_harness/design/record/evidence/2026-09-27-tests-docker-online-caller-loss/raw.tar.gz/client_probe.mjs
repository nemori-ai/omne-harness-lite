// Read only the known app-container backup client PID, never scan all processes.
import { readFile } from 'node:fs/promises'

const text = process.argv[1]
if (!/^[1-9][0-9]*$/.test(text)) throw new Error('positive client PID required')
const pid = Number(text)
if (!Number.isSafeInteger(pid) || pid <= 1) throw new Error('unsafe client PID')
const raw = await readFile(`/proc/${pid}/cmdline`)
if (raw.length < 2 || raw.at(-1) !== 0) throw new Error('missing client cmdline')
const argv = raw.subarray(0, -1).toString('utf8').split('\0')
process.stdout.write(JSON.stringify({ pid, cmdlineBase64: raw.toString('base64'), argv }) + '\n')
