import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import * as AM from '@omne-harness-lite/asset-model'
import { toolBodyContract } from '@omne-harness-lite/tool-definition'
import { loopExtensionBodyContract } from '@omne-harness-lite/loop-extension'
import { skillBodyContract } from '@omne-harness-lite/skill-package'
import { mcpBodyContract } from '@omne-harness-lite/mcp-endpoint'
import { slashCommandBodyContract } from '@omne-harness-lite/slash-command'
const bodies={tool:toolBodyContract,loop_extension:loopExtensionBodyContract,skill:skillBodyContract,mcp:mcpBodyContract,slash_command:slashCommandBodyContract}
const am=AM.createAssetModelJudge(bodies)
const current=['content-blocks','messages','model-response','loop-extension','tool-definition','asset-model']
const report=[]
for(const name of current){
 const api=await import(`@omne-harness-lite/${name}`)
 const schema=(await import(`@omne-harness-lite/${name}/schema`,{with:{type:'json'}})).default
 const old=(await import(`@omne-harness-lite/${name}/schema/v2`,{with:{type:'json'}})).default
 assert.ok(schema.$id.includes(`/v3/${name}.schema.json`))
 assert.ok(old.$id.includes(`/v2/${name}.schema.json`))
 assert.equal(api.schemaId,schema.$id)
 for(const def of api.SCHEMA_DEF_NAMES) (name==='asset-model'?am:api).validate(def,null)
 for(const v of [2,3]){
  const file=new URL(`../../packages/core/${name}/schema/${name}${v===2?'.v2':''}.schema.json`,import.meta.url)
  const original=new URL(`../../.meta_harness/design/spec/data/${name}/v${v}/${name}.schema.json`,import.meta.url)
  const bytes=readFileSync(file)
  assert.ok(bytes.equals(readFileSync(original)))
  report.push({name,version:v,defs:Object.keys(v===2?old.$defs:schema.$defs).length,sha256:createHash('sha256').update(bytes).digest('hex')})
 }
}
for(const name of ['arrival-events','call-accounts','model-profile','skill-package','mcp-endpoint','slash-command']){
 const api=await import(`@omne-harness-lite/${name}`)
 assert.ok(api.schemaId.includes(`/v2/${name}.schema.json`))
 for(const def of api.SCHEMA_DEF_NAMES) api.validate(def,null)
 report.push({name,version:2,compiled:api.SCHEMA_DEF_NAMES.length})
}
console.log(JSON.stringify({amPorts:Object.keys(bodies),currentAMDefs:AM.SCHEMA_DEF_NAMES.length,report},null,2))
