import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import * as CB from '@omne-harness-lite/content-blocks'
import * as Msg from '@omne-harness-lite/messages'
import * as MR from '@omne-harness-lite/model-response'
import * as Loop from '@omne-harness-lite/loop-extension'
import * as TD from '@omne-harness-lite/tool-definition'

const report = []
const receiver = {
  'content-blocks': CB.judgeContentBlock,
  messages: Msg.judgeMessage,
  'model-response': MR.judgeModelResponse,
  'loop-extension': Loop.judgeInput,
  'tool-definition': TD.judgeToolReturn,
}
for (const [name, judge] of Object.entries(receiver)) {
  const text = readFileSync(new URL(`../../.meta_harness/design/spec/data/${name}/v3/examples.md`, import.meta.url), 'utf8')
  const appendix = text.slice(text.indexOf('## v3 窄修订'))
  const rows = [...appendix.matchAll(/### ([^\n]+)\n\n校验对象：`\$defs\/(\w+)`。预期 Schema：`(通过|拒绝)`；契约结果：`([^`]+)`[^\n]*\n\n```json\n([\s\S]*?)\n```/gu)]
  let invoked = 0
  for (const [, , def, , expected, json] of rows) {
    if (name === 'tool-definition' && def.trim() === 'ModelToolName') continue
    const parsed = CB.readJsonStrict(json)
    assert.ok('ok' in parsed)
    let result
    if (name === 'loop-extension') {
      const at = def === 'ModelRequest'
        ? { position: 'before_model_call', subject: { request: parsed.ok } }
        : def === 'AfterModelCallCompleteReplySubject'
          ? { position: 'after_model_call', dimension: { ending: 'complete_reply' }, subject: parsed.ok }
          : { position: 'before_action', subject: parsed.ok }
      result = Loop.judgeInput({ ...at, run: 'run_1', attempt: 1, earlier: [], log: 'log_1', environment: 'env_1' })
    } else result = judge(parsed.ok)
    const wanted = expected.trim().split(/[；;（(\s]/u)[0]
    if (['ok', '—', '禁止派发'].includes(wanted)) assert.ok('ok' in result, `${name}: ${JSON.stringify(result)}`)
    else assert.equal(result.rejected, wanted, `${name}: ${JSON.stringify(result)}`)
    invoked++
  }
  assert.ok(invoked > 0, `source cases missing for ${name}`)
  report.push({ name, actualAccepted3ReceiverCases: invoked })
}

const visibility = { toHuman: false, toModel: false }
const encoded = '{"token":"x","precision":9007199254740993,"small":1.2300,"nil":null}'
function thinking(id = 'b_think') {
  const parsed = CB.readJsonStrict(encoded)
  assert.ok('ok' in parsed)
  return { id, kind: 'thinking', text: '', opaque: parsed.ok, visibility }
}
function assistant() {
  return { id: 'msg_2', type: 'assistant', response: 'rsp_01', ending: 'complete', createdAt: '2026-09-23T10:00:00Z', blocks: [thinking()] }
}
function nested() {
  return { id: 'b_result', kind: 'tool_result', callId: 'call_1', outcome: 'completed', visibility, blocks: [thinking()] }
}
function opaque(block) {
  assert.equal(block?.kind, 'thinking')
  assert.equal(CB.writeJsonLossless(CB.readOpaqueJson(block.opaque)), encoded)
}
function opaqueSubject(subject) {
  if ('message' in subject) opaque(subject.message.blocks[0])
  else if ('request' in subject) opaque(subject.request.messages[0].blocks[0])
  else if ('reply' in subject) opaque(subject.reply.blocks[0])
  else if ('result' in subject) opaque(subject.result.blocks[0])
  else assert.fail('missing normative subject path')
}
const inputBase = { earlier: [], log: 'log_1', environment: 'env_1' }
const subjects = [
  { position: 'before_persist_message', subject: { producer: 'model', message: assistant() } },
  { position: 'before_model_call', subject: { request: { target: 'vendor-a/chat-large', parameters: {}, messages: [assistant()], tools: [] } } },
  { position: 'after_model_call', dimension: { ending: 'complete_reply' }, subject: { reply: assistant(), usage: { input_tokens: 'unknown', output_tokens: 'unknown', cache_read_tokens: 'unknown', cache_write_tokens: 'unknown', source: 'none' }, cost: { cost_usd: 'unknown', source: 'none' } } },
  { position: 'after_action', dimension: { scope: 'each' }, subject: { callId: 'call_1', outcome: 'completed', result: nested() } },
]
for (const at of subjects) {
  const wire = { ...inputBase, ...at, ...(at.position === 'before_persist_message' ? {} : { run: 'run_1', attempt: 1 }) }
  const before = CB.writeJsonLossless(wire)
  const result = Loop.judgeInput(wire)
  assert.ok('ok' in result, JSON.stringify(result))
  opaqueSubject(result.ok.subject)
  const second = Loop.judgeInput(result.ok)
  assert.ok('ok' in second)
  opaqueSubject(second.ok.subject)
  const output = Loop.judgeOutput({ kind: 'rewrite', subject: at.subject })
  assert.ok('ok' in output)
  opaqueSubject(output.ok.subject)
  assert.equal(CB.writeJsonLossless(wire), before)
  assert.deepEqual(CB.readJsonStrict(CB.writeJsonLossless(result.ok)), CB.readJsonStrict(before))
  assert.equal(Object.isFrozen(wire), false)
  assert.equal(Object.isFrozen(wire.subject), false)
  assert.equal(Object.isFrozen(result.ok), true)
  assert.equal(Object.isFrozen(result.ok.subject), true)
  if (['before_persist_message', 'before_model_call', 'after_action'].includes(at.position)) {
    const conclusion = { extension: 'g', position: at.position, ...(at.dimension === undefined ? {} : { dimension: at.dimension }), ...(at.position === 'after_action' ? { callId: 'call_1' } : {}), power: 'rewrite', output: { kind: 'rewrite', subject: at.subject }, at: '2026-09-23T10:00:00Z' }
    const concluded = Loop.judgeConclusion(conclusion, { input: result.ok, extensionName: 'g' })
    assert.ok('ok' in concluded, JSON.stringify(concluded))
    opaqueSubject(concluded.ok.output.subject)
    const earlier = Loop.judgeInput({ ...wire, earlier: [conclusion] })
    assert.ok('ok' in earlier, JSON.stringify(earlier))
    opaqueSubject(earlier.ok.earlier[0].output.subject)
  }
}
const messageWire = assistant()
opaque(Msg.brandMessage(messageWire).blocks[0])
opaque(Msg.brandMessage(Msg.brandMessage(messageWire)).blocks[0])
const block = CB.judgeContentBlock(thinking())
assert.ok('ok' in block)
for (const content of [[thinking()], [block.ok], [nested()]]) {
  const wire = { content, offload: { raw: { inline: 'eA==', mediaType: 'text/plain' }, summary: [nested(), thinking('summary')] } }
  const before = CB.writeJsonLossless(wire)
  const result = TD.toolResultOf(wire, block.ok.id)
  if (result.content[0].kind === 'thinking') opaque(result.content[0])
  else opaque(result.content[0].blocks[0])
  opaque(result.offload.summary[0].blocks[0])
  opaque(result.offload.summary[1])
  assert.equal(CB.writeJsonLossless(wire), before)
  assert.equal(Object.isFrozen(wire), false)
  assert.equal(Object.isFrozen(wire.content), false)
  assert.equal(Object.isFrozen(result), true)
  assert.equal(Object.isFrozen(result.content), true)
}
assert.throws(() => CB.readOpaqueJson({ token: 'x' }), TypeError)
const rawCall = { id: 'b_raw', kind: 'tool_call', complete: true, callId: 'call_1', tool: ' bad:name\n', rawArguments: '{"n":9007199254740993,"n":1e400}', unparseable: true, visibility }
const parsed = CB.judgeContentBlock(rawCall)
assert.ok('ok' in parsed)
assert.equal(parsed.ok.rawArguments, rawCall.rawArguments)
assert.equal(parsed.ok.tool, rawCall.tool)
assert.equal(Object.hasOwn(parsed.ok, 'arguments'), false)
assert.deepEqual(TD.judgeToolReturn({ content: [rawCall] }), { rejected: 'result_call_in_content' })
assert.deepEqual(TD.judgeToolReturn({ content: [], offload: { raw: { inline: 'eA==', mediaType: 'text/plain' }, summary: [rawCall] } }), { rejected: 'result_call_in_content' })
console.log(JSON.stringify({ report, opaqueInputOutputLocations: subjects.map(x => x.position), opaqueConclusionEarlier: ['before_persist_message', 'before_model_call', 'after_action'], opaqueToolReturn: ['wire', 'branded', 'nested', 'offload.summary'], originalPrecision: encoded, ownership: 'caller unchanged/unfrozen; result copies frozen', forbiddenRawOpaque: 'TypeError', dispatchTested: false }, null, 2))
