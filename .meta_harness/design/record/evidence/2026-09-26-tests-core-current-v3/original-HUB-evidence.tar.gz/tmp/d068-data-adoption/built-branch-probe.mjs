import assert from 'node:assert/strict'
import { judgeContentBlock } from '@omne-harness-lite/content-blocks'
import { judgeToolReturn } from '@omne-harness-lite/tool-definition'
const raw={id:'b',kind:'tool_call',complete:true,callId:'c',tool:'bad:name',rawArguments:'{"n":9007199254740993}',unparseable:true,visibility:{toHuman:true,toModel:true}}
const content=judgeContentBlock(raw)
const result=judgeToolReturn({content:[raw]})
console.log(JSON.stringify({content,result}))
assert.ok('ok' in content)
assert.deepEqual(result,{rejected:'result_call_in_content'})
