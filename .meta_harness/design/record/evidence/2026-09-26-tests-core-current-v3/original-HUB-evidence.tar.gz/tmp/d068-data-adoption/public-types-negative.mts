import { readOpaqueJson, type ContentBlock, type JsonValue, type ToolCallBlock } from '@omne-harness-lite/content-blocks'
import { isWireMessage, type Message } from '@omne-harness-lite/messages'
import { isExtensionInput, isExtensionOutput, isConclusion, type ExtensionInput, type ExtensionOutput, type Conclusion } from '@omne-harness-lite/loop-extension'
import { isToolReturn, type ToolReturn } from '@omne-harness-lite/tool-definition'

declare const unknownValue: unknown
declare const wireValue: JsonValue
declare const block: ContentBlock
declare const call: ToolCallBlock
declare const plainOpaque: { readonly token: string }
// A plain object cannot impersonate the private OpaqueJson brand.
readOpaqueJson(plainOpaque)
// Honest boolean guards cannot confer a domain type on an unknown wire value.
if (isExtensionInput(unknownValue)) { const domain: ExtensionInput = unknownValue; void domain }
if (isExtensionOutput(unknownValue)) { const domain: ExtensionOutput = unknownValue; void domain }
if (isConclusion(unknownValue)) { const domain: Conclusion = unknownValue; void domain }
if (isToolReturn(unknownValue)) { const domain: ToolReturn = unknownValue; void domain }
// The explicit wire guard narrows a representation, not a branded Message.
if (isWireMessage(wireValue)) { const domain: Message = wireValue; void domain }
// Complete raw and parsed call representations remain mutually exclusive.
const both: ToolCallBlock = { id: block.id, kind: 'tool_call', visibility: block.visibility, complete: true, callId: call.callId, tool: 'bad:name', rawArguments: '{}', unparseable: true, arguments: {} }
void both

const rawThinking = { id: 'b', kind: 'thinking', text: '', opaque: { token: 'x' }, visibility: { toHuman: false, toModel: false } }
const rawMessage = { id: 'msg', type: 'assistant', response: 'rsp', ending: 'complete', createdAt: '2026-09-23T10:00:00Z', blocks: [rawThinking] }
const rawInput = { position: 'before_persist_message', subject: { producer: 'model', message: rawMessage }, earlier: [], log: 'l', environment: 'e' }
if (isExtensionInput(rawInput)) readOpaqueJson(rawThinking.opaque)
if (isToolReturn({ content: [rawThinking] })) readOpaqueJson(rawThinking.opaque)
