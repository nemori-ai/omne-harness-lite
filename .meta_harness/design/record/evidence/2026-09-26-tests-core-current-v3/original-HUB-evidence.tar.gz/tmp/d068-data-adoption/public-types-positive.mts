import { judgeContentBlock, readOpaqueJson, readJsonStrict, type ContentBlock, type ToolCallBlock } from '@omne-harness-lite/content-blocks'
import { brandMessage, isWireMessage, type Message, type Wire } from '@omne-harness-lite/messages'
import { judgeInput, judgeOutput, judgeConclusion, type ExtensionInput, type ExtensionOutput, type Conclusion } from '@omne-harness-lite/loop-extension'
import { toolResultOf, type ToolResult } from '@omne-harness-lite/tool-definition'
import { judgeModelResponse, type ModelResponse } from '@omne-harness-lite/model-response'
import { createAssetModelJudge, type BodyContracts } from '@omne-harness-lite/asset-model'
import cb3 from '@omne-harness-lite/content-blocks/schema' with { type: 'json' }
import cb2 from '@omne-harness-lite/content-blocks/schema/v2' with { type: 'json' }
import msg3 from '@omne-harness-lite/messages/schema' with { type: 'json' }
import msg2 from '@omne-harness-lite/messages/schema/v2' with { type: 'json' }
import mr3 from '@omne-harness-lite/model-response/schema' with { type: 'json' }
import mr2 from '@omne-harness-lite/model-response/schema/v2' with { type: 'json' }
import loop3 from '@omne-harness-lite/loop-extension/schema' with { type: 'json' }
import loop2 from '@omne-harness-lite/loop-extension/schema/v2' with { type: 'json' }
import td3 from '@omne-harness-lite/tool-definition/schema' with { type: 'json' }
import td2 from '@omne-harness-lite/tool-definition/schema/v2' with { type: 'json' }
import am3 from '@omne-harness-lite/asset-model/schema' with { type: 'json' }
import am2 from '@omne-harness-lite/asset-model/schema/v2' with { type: 'json' }

export const resources: readonly string[] = [cb3.$id, cb2.$id, msg3.$id, msg2.$id, mr3.$id, mr2.$id, loop3.$id, loop2.$id, td3.$id, td2.$id, am3.$id, am2.$id]
export function consumer(value: unknown, bodies: BodyContracts, response: ModelResponse): void {
  const block = judgeContentBlock(value)
  if ('ok' in block) {
    const domain: ContentBlock = block.ok
    if (domain.kind === 'thinking' && domain.opaque !== undefined) readOpaqueJson(domain.opaque)
    const result: ToolResult = toolResultOf(value, domain.id)
    const nested = result.offload?.summary?.[0]
    if (nested?.kind === 'thinking' && nested.opaque !== undefined) readOpaqueJson(nested.opaque)
    if (domain.kind === 'tool_call' && domain.complete) {
      const call: ToolCallBlock = domain
      if (call.complete && call.unparseable === true) {
        const raw: string = call.rawArguments
        const absent: undefined = call.arguments
        void [raw, absent]
      }
    }
  }
  const parsed = readJsonStrict('{}')
  if ('ok' in parsed && isWireMessage(parsed.ok)) {
    const wire: Wire<Message> = parsed.ok
    const message: Message = brandMessage(wire)
    const first = message.blocks[0]
    if (first?.kind === 'thinking' && first.opaque !== undefined) readOpaqueJson(first.opaque)
  }
  const input = judgeInput(value)
  if ('ok' in input) {
    const domain: ExtensionInput = input.ok
    const output = judgeOutput(value)
    if ('ok' in output) {
      const typed: ExtensionOutput = output.ok
      const conclusion = judgeConclusion(value, { input: domain, extensionName: 'g' })
      if ('ok' in conclusion) {
        const record: Conclusion = conclusion.ok
        void [typed, record]
      }
    }
  }
  judgeModelResponse(response)
  createAssetModelJudge(bodies)
}
