import type {
  Layer, HoldingLayer, AssetReference, CompositionRoot, SessionAssignment,
  McpActionSet, EvaluationInput, NonConnectorAssetContent, NonConnectorAssetDefinition,
  NonConnectorEvaluationInput, FilterReason, EffectiveAsset, EffectiveValue,
  FilteredOut, Unresolved, EffectiveAssembly, Condition, InputDiagnostic,
  EvaluationResult, DropReason, DroppedEntry, CarrierAssignment, CarrierHolding,
  CarrierReadResult, CarrierReadOutcome, PermissionDeclaration, PermissionAssignment,
  TierOrder, PermissionClassification, NonConnectorBodyContracts,
} from '@omne-harness-lite/asset-evaluation'

/** Every root-exported type is consumed through generated public declarations. */
export type PublicTypes = [
  Layer, HoldingLayer, AssetReference, CompositionRoot, SessionAssignment,
  McpActionSet, EvaluationInput, NonConnectorAssetContent, NonConnectorAssetDefinition,
  NonConnectorEvaluationInput, FilterReason, EffectiveAsset, EffectiveValue,
  FilteredOut, Unresolved, EffectiveAssembly, Condition, InputDiagnostic,
  EvaluationResult, DropReason, DroppedEntry, CarrierAssignment, CarrierHolding,
  CarrierReadResult, CarrierReadOutcome, PermissionDeclaration, PermissionAssignment,
  TierOrder, PermissionClassification, NonConnectorBodyContracts,
]
