#!/usr/bin/env python3
"""Rerun the retained public consumer against an explicitly supplied built workspace."""
import argparse
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("repository", type=Path)
    args = parser.parse_args()
    repository = args.repository.resolve(strict=True)
    evidence = Path(__file__).resolve().parent
    consumer = evidence / "consumer"
    targets = {
        "@omne-harness-lite/asset-evaluation": "packages/core/asset-evaluation",
        "@omne-harness-lite/asset-model": "packages/core/asset-model",
        "@omne-harness-lite/content-blocks": "packages/core/content-blocks",
        "@omne-harness-lite/identity-values": "packages/core/identity-values",
        "@types/node": "packages/core/asset-evaluation/node_modules/@types/node",
    }
    for name, relative in targets.items():
        target = (repository / relative).resolve(strict=True)
        if name.startswith("@omne-harness-lite/"):
            if not (target / "dist/index.js").is_file():
                raise SystemExit(f"Build the dependency graph first: {target}")
        link = consumer / "node_modules" / name
        link.parent.mkdir(parents=True, exist_ok=True)
        if link.is_symlink():
            if link.resolve() != target:
                raise SystemExit(f"Existing link targets a different workspace: {link}")
        elif link.exists():
            raise SystemExit(f"Refusing to overwrite a non-link consumer dependency: {link}")
        else:
            link.symlink_to(target, target_is_directory=True)
    source = [str(consumer / name) for name in ["main.mts", "negative.mts", "types.mts"]]
    subprocess.run(
        [
            "pnpm", "--filter", "@omne-harness-lite/asset-evaluation", "exec", "tsc",
            "--strict", "--module", "nodenext", "--target", "es2024", "--noEmit",
            "--verbatimModuleSyntax", "--types", "node", *source,
        ],
        cwd=repository,
        check=True,
    )
    subprocess.run(["node", str(consumer / "main.mts")], cwd=repository, check=True)


if __name__ == "__main__":
    main()
