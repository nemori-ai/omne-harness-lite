import { evaluate, readWorkspaceCarrier, defaultBodyContracts, type EvaluationInput, type NonConnectorEvaluationInput, type EffectiveAssembly } from '@omne-harness-lite/asset-evaluation'
// @ts-expect-error Private normative computation is not a public injection entry.
import { computeEvaluation } from '@omne-harness-lite/asset-evaluation'
declare const full: EvaluationInput
declare const admitted: NonConnectorEvaluationInput
// @ts-expect-error Full domain requires a Connector provider unavailable this stage.
evaluate(full)
// @ts-expect-error Four business results cannot be treated as an assembly without narrowing.
const assembly: EffectiveAssembly = evaluate(admitted)
// @ts-expect-error No fake sixth provider is exposed.
defaultBodyContracts.connector.judge({})
// @ts-expect-error Tenant identity must be checked through its owning package.
readWorkspaceCarrier({ format: 1, assets: [], assignments: [], disabled: [] }, { tenant: { organization: 'unbranded', account: 'unbranded' }, directory: '/tmp/project' })
export { assembly, computeEvaluation }
