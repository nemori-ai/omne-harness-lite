import { strict as assert } from 'node:assert'
import {
  evaluate, readWorkspaceCarrier, defaultBodyContracts,
  classifyPermissionAssignment, boundOf, pickWithinBound, evaluationInputFingerprint,
  type EvaluationInput, type NonConnectorEvaluationInput, type PermissionDeclaration,
} from '@omne-harness-lite/asset-evaluation'
import { parseTenantId, unwrap } from '@omne-harness-lite/identity-values'
import { createAssetModelJudge } from '@omne-harness-lite/asset-model'
import { toOpaqueJson, writeJsonLossless, copyJsonValue } from '@omne-harness-lite/content-blocks'

const tenant = unwrap(parseTenantId({ organization: 'org_dist', account: 'acc_owner' }))
const root = { category: 'agent_definition', name: 'root' } as const
const shell = { category: 'tool', name: 'shell' } as const
const at = '2026-09-26T00:00:00Z'
const input: NonConnectorEvaluationInput = {
  tenant, standing: { standing: 'effective', role: 'member' },
  root: { definition: root, references: [{ capability: shell, resident: true }] },
  definitions: [
    { id: 'root-record', capability: root, origin: 'official', versions: [{ number: 1, content: { category: 'agent_definition', body: toOpaqueJson({ category: 'connector' }) }, publishedAt: at }] },
    { id: 'tool-record', capability: shell, origin: 'official', versions: [{ number: 1, content: { category: 'tool', definition: { name: 'shell', description: 'dist consumer tool', paradigm: 'single', origin: { kind: 'authored' }, input: { type: 'object', properties: {} }, permissions: { execute: { default: 'ask' } } } }, publishedAt: at }] },
  ],
  holdings: [root, shell].map((capability, i) => ({ capability, asset: i === 0 ? 'root-record' : 'tool-record', holder: { layer: 'factory' }, basis: { kind: 'official' }, versionSelection: { kind: 'current' }, immutable: false, assignments: [], since: at })),
}
const before = writeJsonLossless(input)
assert.deepEqual(Object.keys(defaultBodyContracts).sort(), ['loop_extension', 'mcp', 'skill', 'slash_command', 'tool'])
assert.ok(Object.isFrozen(defaultBodyContracts))
const model = createAssetModelJudge(defaultBodyContracts)
for (const definition of input.definitions) assert.deepEqual(model.judgeAssetValue('AssetDefinition', definition), { ok: true })
const output = evaluate(input)
assert.ok('ok' in output)
assert.deepEqual(output.ok.root, root)
assert.deepEqual(output.ok.composition, [shell])
assert.equal(output.ok.assets.length, 2)
assert.equal(output.ok.values.length, 2)
assert.deepEqual(output.ok.unresolved, [])
assert.deepEqual(output.ok.filteredOut, [])
assert.ok(Object.isFrozen(output.ok.values))
assert.equal(Object.isFrozen(input), false)
assert.equal(writeJsonLossless(input), before)
assert.deepEqual(evaluate(input), output)
assert.ok('invalidInput' in evaluate({ ...input, root: { definition: shell, references: [] } }))
assert.ok('compositionCycle' in evaluate({ ...input, root: { definition: root, references: [{ capability: root }] } }))
const plugin = { category: 'plugin', name: 'unsupported' } as const
const unsupportedInput: NonConnectorEvaluationInput = {
  ...input,
  root: { definition: root, references: [{ capability: plugin }] },
  definitions: [...input.definitions, { id: 'plugin-record', capability: plugin, origin: 'official', versions: [{ number: 1, content: { category: 'plugin', members: [shell] }, publishedAt: at }] }],
  holdings: [...input.holdings, { capability: plugin, asset: 'plugin-record', holder: { layer: 'factory' }, basis: { kind: 'official' }, versionSelection: { kind: 'current' }, immutable: false, assignments: [], since: at }],
}
assert.deepEqual(evaluate(unsupportedInput), { categoryUnsupported: { category: 'plugin' } })
const connector = { category: 'connector', name: 'reference-only' } as const
const unresolved = evaluate({ ...input, root: { definition: root, references: [{ capability: connector }] } })
assert.ok('ok' in unresolved)
assert.deepEqual(unresolved.ok.unresolved, [{ capability: connector, referencedBy: root }])
const read = readWorkspaceCarrier({ format: 1, assets: [{ capability: connector, source: 'connector.json' }], assignments: [], disabled: [] }, { tenant, directory: '/tmp/project' })
assert.ok('ok' in read)
assert.equal(read.ok.holdings.length, 1)
assert.equal(Object.hasOwn(read.ok.holdings[0] ?? {}, 'since'), false)
assert.ok('invalidInput' in readWorkspaceCarrier({ format: 1, assets: [], assignments: [{ capability: connector, item: 'disabled', value: false }], disabled: [] }, { tenant, directory: '/tmp/project' }))
const execution: PermissionDeclaration = { item: 'execute', kind: 'permission', domain: { kind: 'enum', values: ['forbid', 'auto', 'ask'] }, default: 'ask' }
assert.equal(classifyPermissionAssignment(execution, { value: { allowed: ['forbid'] }, immutable: false }).role, 'bound')
assert.deepEqual(boundOf(execution, [{ allowed: ['ask', 'forbid'] }, { allowed: ['ask'] }]), { allowed: ['ask'] })
assert.equal(pickWithinBound({ allowed: ['auto'] }, { allowed: ['ask'] }), false)
const full: EvaluationInput = input
assert.match(evaluationInputFingerprint(full), /^[0-9a-f]{64}$/u)
assert.equal(evaluationInputFingerprint(full), evaluationInputFingerprint({ ...full, root: { references: input.root.references, definition: root } }))
assert.notEqual(evaluationInputFingerprint(full), evaluationInputFingerprint({ ...full, root: { definition: root, references: [] } }))
assert.deepEqual(copyJsonValue(toOpaqueJson({ category: 'connector', value: 1 })), { ok: { category: 'connector', value: 1 } })
console.log('PASS: built independent public consumer, five ports, four evaluation branches, helpers, complete carrier domain, full fingerprint and input ownership')
