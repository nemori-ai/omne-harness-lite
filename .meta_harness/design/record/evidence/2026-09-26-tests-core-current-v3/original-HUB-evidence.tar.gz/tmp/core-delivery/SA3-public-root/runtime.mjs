import assert from 'node:assert/strict'
import * as publicAssembly from '@omne-harness-lite/stream-assembly'
import { judgeContentBlock, LosslessNumber, writeJsonLossless } from '@omne-harness-lite/content-blocks'

assert.deepEqual(Object.keys(publicAssembly).sort(), ['abandon', 'accept', 'closeOut', 'snapshot', 'start'])
const { abandon, accept, closeOut, snapshot, start } = publicAssembly
const started = start({ kind: 'model_call', callId: 'mc_public', dispatch: new LosslessNumber('9007199254740993') })
assert.ok('ok' in started)
function step(state, event) {
  const result = accept(state, event)
  assert.ok('ok' in result, JSON.stringify(result))
  return result.ok
}
assert.ok('ok' in judgeContentBlock({ kind: 'tool_call', id: 'b_public', callId: 'tc_public', tool: 'ns__read', complete: true, visibility: { toHuman: true, toModel: true }, arguments: {} }))
let state = step(started.ok, {
  t: 'open', index: new LosslessNumber('1e400'), kind: 'tool_call', fill: 'append', id: 'b_public',
  visibility: { toHuman: true, toModel: true }, head: { callId: 'tc_public', tool: 'ns__read' },
})
const before = snapshot(state)
assert.equal(writeJsonLossless(before.position), '1')
assert.equal(Object.hasOwn(before.blocks[0], 'content'), false)
const raw = '{"n":9007199254740993,"d":0.1234567890123456789}'
for (const part of [raw.slice(0, 17), raw.slice(17)]) state = step(state, { t: 'fill', index: new LosslessNumber('10e399'), payload: part })
assert.equal(snapshot(state).blocks[0].content, raw)
assert.deepEqual(closeOut(state), { rejected: 'stream_not_finished' })
const partial = abandon(state)
assert.ok('ok' in partial)
assert.equal(partial.ok.ending.reason, 'lost')
assert.equal(partial.ok.blocks[0].complete, false)
assert.deepEqual(partial.ok.blocks[0].visibility, { toHuman: false, toModel: false })
state = step(state, { t: 'close', index: new LosslessNumber('1e400') })
const sealed = snapshot(state).blocks[0]
assert.equal(sealed.closed, true)
assert.equal(writeJsonLossless(sealed.block.arguments), raw)
assert.ok('ok' in judgeContentBlock(sealed.block))
state = step(state, { t: 'finish', reason: 'end' })
const settled = closeOut(state)
assert.ok('ok' in settled)
assert.equal(writeJsonLossless(closeOut(state)), writeJsonLossless(settled))
assert.deepEqual(accept(state, { t: 'fill', index: new LosslessNumber('1e400'), payload: 'late' }), { rejected: 'event_after_finish' })
assert.deepEqual(abandon(state), { rejected: 'event_after_finish' })
assert.equal(Object.hasOwn(before.blocks[0], 'content'), false)
assert.throws(() => Object.defineProperty(before.blocks[0].opened.visibility, 'toModel', { value: false }), TypeError)
assert.throws(() => Object.defineProperty(settled.ok.blocks[0].arguments, 'n', { value: 0 }), TypeError)
console.log(JSON.stringify({ publicKeys: Object.keys(publicAssembly).sort(), rawArguments: raw, oldSnapshotUnchanged: true, exactIndexAliases: true, runtime: process.version }))
