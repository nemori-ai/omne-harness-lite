# AE3 verification rerun recipes

Run from the explicitly supplied spoke `/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery-asset-evaluation`. These are rerun recipes for the preserved logs, not a replacement for the original raw output. The source manifest fixes the actual package, root configuration, generated dist and checker bytes. Node 24.18.0, pnpm 10.28.1, TypeScript 6.0.3 and Vitest 4.1.11 were used; the local version readout is saved separately.

```sh
pnpm install --frozen-lockfile --ignore-scripts
pnpm --filter '@omne-harness-lite/asset-evaluation...' build
pnpm --filter @omne-harness-lite/asset-evaluation typecheck
pnpm --filter @omne-harness-lite/asset-evaluation exec vitest run --reporter=json --outputFile=../../../tmp/w6-asset-evaluation/current-v3/runtime-complete.json
pnpm --filter @omne-harness-lite/ts-checks exec vitest run tests/core-rules.spec.ts tests/rules.spec.ts tests/schema-v2-subpaths.spec.ts --reporter=json --outputFile=../../tmp/w6-asset-evaluation/current-v3/checker-selftest.json
node --experimental-strip-types tmp/w6-asset-evaluation/current-v3/source-scan.mjs "$PWD"
python3 tmp/w6-asset-evaluation/current-v3/run-consumer.py "$PWD"
pnpm --filter @omne-harness-lite/asset-evaluation build
pnpm exec prettier --check 'packages/core/asset-evaluation/**/*.{ts,json,md}'
git diff --check
```

The first complete run on the new dependency baseline retained all original161 cases before the7 adoption tests were added. `runtime-adoption.json` isolates the new test file; `runtime-complete.json` includes all168. Checker94 contains original48 plus46 fixed-resource path controls. The consumer command invokes strict TypeScript against every generated public declaration without `skipLibCheck`, then executes the independent consumer. `typecheck-adoption.log` retains the initial test-fixture narrowing failure; the repaired result is separate.

The full dependency build writes only ordinary generated dist in the supplied workspace, with no maintained sibling edits. The unchanged checker CLI tests create and remove their own `tmp/core-rules-*` fixtures, as reported to the parent. Formal execution was performed by its independent owner: this worker verifies original SHA manifests, raw stderr and receipt bindings rather than claiming to rerun Alloy.
