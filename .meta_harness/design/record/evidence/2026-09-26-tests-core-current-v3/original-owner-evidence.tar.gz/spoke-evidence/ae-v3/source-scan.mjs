import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const repository = resolve(process.argv[2])
const { collectSources, runRules, RULES } = await import(
  pathToFileURL(resolve(repository, 'tools/ts-checks/src/index.ts')).href
)
const files = collectSources(resolve(repository, 'packages')).filter(file =>
  file.path.startsWith('core/asset-evaluation/'),
)
const violations = runRules(files)
console.log(JSON.stringify({
  rules: RULES.map(rule => rule.id),
  sourcePaths: files.filter(file => file.path.includes('/src/')).map(file => file.path),
  allPaths: files.length,
  violations,
}, null, 2))
if (violations.length !== 0) process.exitCode = 1
