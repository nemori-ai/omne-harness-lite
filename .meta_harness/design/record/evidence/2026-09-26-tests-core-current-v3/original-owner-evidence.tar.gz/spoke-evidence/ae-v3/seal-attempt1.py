#!/usr/bin/env python3
"""Bind the AE3 run to actual source, fixed inputs and independently executed formal raw."""
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

E = Path(__file__).resolve().parent
R = E.parents[2]
D = R / ".meta_harness/design"
OLD = R / "tmp/w6-asset-evaluation-current-v2"
FORMAL = Path("/data/qiwei/repos/omne-harness-lite/tmp/core-delivery/spoke-evidence/w6-core-formal-v3")
BASELINE = "eabfff0f167093f34cfa0582c7e6cf0773761016"
MATRIX = "0cdc74ec7579f7ccc5a7f1b470fb3f13fc8d3b8491bae5598d935bae1b39142f"
FORMAL_SHA = "a228cbf408af6c22163dd37a3c2faaee5375e96d56d54a8db99863fc7ce7259e"


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def files(root):
    for base, dirs, names in os.walk(root, followlinks=False):
        dirs[:] = sorted(n for n in dirs if n != "node_modules" and not (Path(base) / n).is_symlink())
        for name in sorted(names):
            p = Path(base) / name
            if p.is_file() and not p.is_symlink():
                yield p


def record(path, base=R):
    return {"path": path.relative_to(base).as_posix(), "sha256": sha(path), "bytes": path.stat().st_size}


def save(name, data):
    p = E / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=R, text=True).strip()


def test_report(path):
    raw = json.loads(path.read_text())
    tests = [{"file": Path(suite["name"]).name, "name": row["fullName"], "status": row["status"]}
             for suite in raw["testResults"] for row in suite["assertionResults"]]
    return {"summary": {k: raw.get(k, 0) for k in ["numTotalTests", "numPassedTests", "numFailedTests", "numPendingTests", "numTodoTests", "success"]},
            "assertions": tests, "raw_sha256": sha(path)}


def main():
    if (E / "sha256.txt").exists():
        raise SystemExit("Already sealed; preserve the raw epoch.")
    assert not git("status", "--porcelain")
    assert git("branch", "--show-current") == "panqiwei/core-delivery-asset-evaluation"
    source = git("rev-parse", "HEAD")
    subprocess.run(["git", "merge-base", "--is-ancestor", BASELINE, source], cwd=R, check=True)
    assert sha(OLD / "sha256.txt") == "7d0fbd89c3cf215725028a78cc0f2efad1cdd2adce176bf2463f75690fbbad5b"
    subprocess.run(["sha256sum", "--check", "sha256.txt"], cwd=OLD, stdout=subprocess.DEVNULL, check=True)
    assert sha(E / "acceptance-matrix.json") == MATRIX
    assert sha(FORMAL / "SHA256SUMS") == FORMAL_SHA
    subprocess.run(["sha256sum", "--check", "SHA256SUMS"], cwd=FORMAL, stdout=subprocess.DEVNULL, check=True)
    current = test_report(E / "runtime-complete.json")
    baseline = test_report(E / "runtime-baseline.json")
    old = test_report(OLD / "runtime-complete.json")
    checker = test_report(E / "checker-selftest.json")
    assert current["summary"]["numTotalTests"] == current["summary"]["numPassedTests"] == 168
    assert baseline["summary"]["numTotalTests"] == baseline["summary"]["numPassedTests"] == 161
    assert checker["summary"]["numTotalTests"] == checker["summary"]["numPassedTests"] == 94
    old_names = {(x["file"], x["name"]) for x in old["assertions"]}
    assert old_names == {(x["file"], x["name"]) for x in baseline["assertions"]}
    assert old_names <= {(x["file"], x["name"]) for x in current["assertions"]}
    assert all(x["status"] == "passed" for t in [current, baseline, checker] for x in t["assertions"])
    save("test-inventory.json", {"current_v3": current, "original_161_current_v3": baseline,
                                "original_48_plus_46_schema_negatives": checker, "old_names_retained": True})
    catalog = json.loads((D / "registry/catalog.json").read_text())
    frozen = json.loads((D / "registry/frozen.json").read_text())["files"]
    adopted = next(c for c in catalog["contracts"] if c["coordinate"]["contract_id"] == "capability.asset-evaluation" and c["coordinate"]["version"] == 3)
    assert adopted["status"] == "accepted"
    input_paths = ["registry/catalog.json", "registry/frozen.json", "registry/version-migrations.json",
                   "record/decisions/core-implementation-spec-reconciliation/decision.md",
                   "record/decisions/core-implementation-spec-reconciliation/acceptance.json",
                   "spec/capabilities/asset-evaluation/verification.md"] + adopted["resources"] + [
                       f"realization/packages/core/asset-evaluation/{n}" for n in ["README.md", "design.md", "verification.md", "bindings.yaml"]]
    inputs = []
    for name in input_paths:
        target = E / "inputs" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(D / name, target)
        assert sha(target) == sha(D / name)
        if name in adopted["resources"]:
            assert sha(target) == frozen[name]
        inputs.append(record(target, E))
    save("inputs-manifest.json", {"coordinate": adopted["coordinate"], "acceptance": adopted["acceptance"],
                                  "captured_resources": inputs,
                                  "dispatch_snapshots": [record(E / name, E) for name in ["acceptance-matrix.json", "implementation-delivery-plan.md", "developer-brief.md"]],
                                  "dispatch_erratum": "verification is version-external; no v3 verification file invented"})
    maintained = [R / name for name in git("ls-files", "packages/core/asset-evaluation").splitlines()]
    providers = ["identity-values", "offer-expiry", "content-blocks", "asset-model", "model-profile", "tool-definition", "call-accounts", "messages", "mcp-endpoint", "skill-package", "loop-extension", "slash-command"]
    dependencies = [R / name for provider in providers for name in git("ls-files", f"packages/core/{provider}").splitlines()]
    save("source-manifest.json", {"source_leaf": source, "dependency_baseline": BASELINE, "clean": True,
                                  "own_files": list(map(record, maintained)),
                                  "built_files": [record(p) for provider in ["asset-evaluation", *providers] for p in files(R / f"packages/core/{provider}/dist")],
                                  "provider_sources": list(map(record, dependencies)),
                                  "shared_config": [record(R / n) for n in ["pnpm-lock.yaml", "pnpm-workspace.yaml", "package.json", "tsconfig.base.json", ".prettierrc.json"]],
                                  "checker": [record(R / n) for n in git("ls-files", "tools/ts-checks").splitlines()],
                                  "tools": {"node": subprocess.check_output(["node", "--version"], text=True).strip(), "pnpm": subprocess.check_output(["pnpm", "--version"], text=True).strip()}})
    schemas = []
    for provider in providers:
        for p in files(R / f"packages/core/{provider}/schema"):
            matches = [path for path, expected in frozen.items() if expected == sha(p)]
            assert matches, p
            schemas.append({**record(p), "$id": json.loads(p.read_text()).get("$id"), "exact_frozen_matches": matches})
    assert not (R / "packages/core/asset-evaluation/schema").exists()
    save("schema-inventory.json", {"AE_own_schema": "not applicable by S-32, not a vacuous closure PASS", "real_fixed_resources": schemas,
                                   "current_graph": "AM3 all25defs compile with exact real5 defaultBodyContracts in adopted-v3.spec.ts", "retained2_consumers": "AM private exact TD2 plus public CB2/AM2; provider Skill2/MCP2/Slash2 keep fixed resources", "Connector": "resource only, no actual provider supplied"})
    formal_target = E / "independent-formal-v3"
    shutil.copytree(FORMAL, formal_target)
    raw_data = json.loads((FORMAL / "formal-results.json").read_text())
    ae_runs = [run for run in raw_data["Alloy"] if run["label"].startswith("ae3-")]
    assert len(ae_runs) == 14
    model = D / "spec/capabilities/asset-evaluation/v3/formal/Evaluation.als"
    assert sha(model) == sha(FORMAL / "input/spec/capabilities/asset-evaluation/v3/formal/Evaluation.als")
    for run in ae_runs:
        invocation = json.loads((FORMAL / "runs" / run["label"] / "result.json").read_text())
        assert not invocation["timed_out"] and invocation["exit_code"] == 0
        text = (FORMAL / "runs" / run["label"] / "stderr.log").read_text().replace("\x08", "")
        rows = re.findall(r"^\d+\.\s+(run|check)\s+(\w+).*?\b(UNSAT|SAT)\s*$", text, re.MULTILINE)
        assert len(rows) == len(run["results"]) == 18
        expected = {(row["kind"], row["command"]): row["actual"] for row in run["results"]}
        assert all(expected[(kind, name)] == actual for kind, name, actual in rows)
        assert all(row["matches"] for row in run["results"])
        receipt = json.loads((FORMAL / "runs" / run["label"] / "solutions/receipt.json").read_text())
        for row in run["results"]:
            cmd = receipt["commands"][row["command"]]
            assert cmd["source"] == row["source"]
            for field in ["overall", "scopes", "bitwidth"]:
                assert cmd[field] == row["scope"][field]
        if run["label"] != "ae3-original":
            assert any(row["kind"] == "check" and row["actual"] == "SAT" for row in run["results"])
    save("formal-v3-read.json", {"independent_run_manifest": FORMAL_SHA, "original_frozen_input_sha256": sha(model), "runs": ae_runs,
                               "readout_count": 252, "new_run_owner": "independent W6 formal verifier; this worker read raw+receipt", "raw_copy": "independent-formal-v3/",
                               "limits": ["Finite scopes only; model and TS implementation separate", "TeamAssetsStayInTree/roots by construction, PRE-2 assumed", "Values/body/version/cycle/reader/external ownership not proven by Alloy"],
                               "durable_location": ".meta_harness/design/record/evidence/2026-09-26-formal-core-v3/README.md",
                               "durable_HUB_commit": "c487d65b981511b5533a2ee2cf71b2cc468db780",
                               "durable_tar_sha256": "1f17a46d3ca8e2ae8e0bd3247085cfb555d6a5e6feb6a47a2693706f68aac76b"})
    matrix = json.loads((E / "acceptance-matrix.json").read_text())
    old_coverage = json.loads((OLD / "coverage.json").read_text())
    original_coverage = {x["id"]: x for x in old_coverage["AE_obligations"]}
    mapped = []
    for row in matrix["obligations"]:
        if row["node"] == "asset-evaluation":
            prior = original_coverage[row["id"]]
            mapped.append({"id": row["id"], "stage": row["stage"], "adopted_input": row["input_coordinate"], "actual_matrix_row": row,
                           "current_author_evidence": "external not closed" if row["stage"] == "external" else "passed in accurate NonConnector v3 domain",
                           "normative_test_files": prior["test_files"], "actual_raw": "runtime-complete.json", "test_inventory": "test-inventory.json",
                           "incremental_adoption_test": "adopted-v3.spec.ts", "technical_acceptance": "pending Root", "Connector": "deferred only where the actual row splits it"})
    mixed = [row for row in matrix["obligations"] if row.get("scope_disposition") == "split-connector-only"]
    assert len(mapped) == 12 and len(mixed) == 6
    scoped = json.loads((E / "source-rules-final.log").read_text())
    assert len(scoped["rules"]) == 27 and len(scoped["sourcePaths"]) == 9 and not scoped["violations"]
    save("coverage.json", {"coordinate": adopted["coordinate"], "source_leaf": source, "AE_obligations": mapped, "six_mixed_current_rows": mixed,
                           "real_five_combination_evidence": ["body-domain.spec.ts", "normative.spec.ts", "adopted-v3.spec.ts", "consumer/main.mts"],
                           "pure_source_scan": scoped, "SC2_SC3": "Full fingerprint/type guard evidence supplied; external consumer cache/handling not closed", "original_161_retained": True,
                           "non_applicable": ["No AE Schema; fixed real dependency graph was verified", "No Cordis service or bindable Alloy formal task"],
                           "Skill_SP3": "Undetermined unknown YAML key tags remain known reader gap; only admitted SkillPackage values consumed"})
    save("results.json", {"source_leaf": source, "dependency_baseline": BASELINE, "coordinate": adopted["coordinate"], "runtime": current["summary"],
                          "runtime_split": {"runtime": 165, "types": 3}, "checker": checker["summary"], "original_checker_48_plus_new_schema_46": True,
                          "install": "frozen lockfile; no root edits", "build_type_format_scan_consumer": "passed actual commands, raw logs retained", "public_types": 30, "negative_type_controls": 5,
                          "initial_red": "typecheck-adoption.log: new test fixture narrowing only; repaired log separately retained", "old_v2_manifest": sha(OLD / "sha256.txt"),
                          "policy_source_changes": 0, "current_implementation_complete": True, "Root_technical_acceptance": "pending", "human_overall_acceptance": "pending",
                          "Connector": "provider vertical deferred", "external_PRE_cache_runtime": "outside this stage, no closure claim", "sealed_at": datetime.now(timezone.utc).isoformat()})
    manifest = E / "sha256.txt"
    paths = sorted(files(E))
    manifest.write_text("".join(f"{sha(p)}  {p.relative_to(E).as_posix()}\n" for p in paths))
    print(json.dumps({"evidence_root": str(E), "source_leaf": source, "manifest_sha256": sha(manifest), "file_count": len(paths)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
