# W6 AE3 delivery epoch

本次显式采用 D-068 的 `capability.asset-evaluation/3`，与旧 AE2 实跑、失败日志、144 文件 seal 分开保存。派发指定 HUB `eabfff0f167093f34cfa0582c7e6cf0773761016` 无冲突合入本 spoke；原 AE2 seal 校验通过。实际版本外 verification.md 的位置勘误已纳入输入，不在冻结 v3 目录伪造文件。

实际源码采用 AM3 / TD3 / Loop3、CB3 技术投影；Skill / MCP / Slash 保留2。四步求值、输入 C1–C14、全部规范场景、完整工作区读入、整输入指纹、四种结果与拒绝优先级保持原承诺。源码增量只含包导航、description 和新的采用回归测试；9 个纯计算 src 的产品政策没有变化。

原161项用例在新3真实依赖下先独立通过；最终168项 = 原161 + 7项定点采用验证，165 runtime + 3 type，0失败／skip。新增验证：AM3当前25defs和真实五端口固定图均可编译；默认 AM3、TD3、Loop3 的真实资源身份及完整保留AM2；ToolName128/129字符、冒号转写128/129与保留相邻序列的实际 TD3拒绝到AM3再到AE3；CB3坏名调用放入Opaque根JSON仍为数据，而整输入指纹确能区分。类型初红是新测试的 Schema boolean 联合与闭包窄化失误，原 log 留存；未改规格或期望。

冻结安装、真实依赖图及最终包build、strict typecheck、共享格式与27条规则对真实9src检查通过。相关检查器94项 = 原48 + 46项精确schema/v2接线负控通过。既有CLI负控自行在本spoke tmp/core-rules-* 创建并删除临时包，父调度已知；不修改受维护源。独立built dist消费者通过四结果／30公开类型／5负型／五端口、权限函数、完整清单域与输入所有权；`run-consumer.py` 可对给定已构建执行库复跑。

`defaultBodyContracts` 只含真实五个正文端口，完整 `EvaluationInput` 保留、`evaluate`准确使用 `NonConnectorEvaluationInput`。Connector正文的记录、草稿和所有版本仍属于明确未供应域；普通Connector标识、引用或不透明JSON不被递归误排除。无第六假端口、无第五业务结果、无空成功替代。

AE无自有Schema（S-32）。`schema-inventory.json` 核实际依赖当前3和保留2的固定资源全部逐字节等于 frozen；实际AM3的25defs组合编译与真实五正文拒绝仍是独立判据，不能把零AE Schema当作空闭包通过。

新的独立AE3形式证据实际执行于2026-09-26，原18命令和13变异共252读数，本worker逐原stderr与receipt交叉核scope/source/result并保存原字节副本。完整独立run manifest SHA `a228cbf408af6c22163dd37a3c2faaee5375e96d56d54a8db99863fc7ce7259e`，实际身份与argv保持原样。旧2没有重标，本worker不冒称亲自重跑Alloy。有限scope、按构造的性质和PRE-2假定，与32组实现性质测试分列。长期入口已由Root落在 HUB `c487d65b981511b5533a2ee2cf71b2cc468db780` 的 `.meta_harness/design/record/evidence/2026-09-26-formal-core-v3/README.md`；不为这个文档增量变更当前源epoch。

`coverage.json` 给全部12 AE义务、6 mixed current行及真实源码／运行对应。Connector单纵线延期；Skill SP3未知YAML键判等仍是其reader已知gap，AE只消费admitted值。PRE-1–PRE-9真实快照／授权／文件来源、外部消费者缓存及下游行为仍归外部owner，没有用纯函数用例签收。Root独立组合／技术验收及人的最终总体验收待定。

源码leaf、actualbuilt、配置、工具、输入快照和raw hashes均由 `source-manifest.json`、`inputs-manifest.json`、`test-inventory.json`、`formal-v3-read.json`、`sha256.txt` 固定。封存不推断接受。旧证据不会清理；本spoke无push、main写入或自行技术签收。
