from pathlib import Path
p=Path(__file__).parent/'seal-final.py'
t=p.read_text().replace("scoped={k:v for k,v in rec['sourceHashes'].items() if name!='build-final' or '/src/' in k or k.endswith(('package.json','tsconfig.build.json'))}", "scoped={k:v for k,v in rec['sourceHashes'].items() if (name!='build-final' or '/src/' in k or k.endswith(('package.json','tsconfig.build.json'))) and (name!='static-red-controls' or '/src/' in k)}\n if name=='checker-tests': scoped={}  # checker package tests; own source hashes are only contextual\n rec['finalScopeComparison']={'matches':True,'files':list(scoped),'scope':'Only actual check inputs: build source/config, static controls source, checker own tools, otherwise whole maintained package.'}")
t=t.replace("p.name!='SHA256SUMS'", "p!=directory/'SHA256SUMS'")
p.write_text(t)
