from pathlib import Path
root=Path(__file__).resolve().parents[3]
t=(root/'tmp/w6-stream-assembly/run-real-guards.py').read_text().replace('parents[2]','parents[3]').replace("'tmp/w6-stream-assembly/guards-27'", "'tmp/w6-stream-assembly/current-v3/guards-27'")
(Path(__file__).parent/'run-real-guards.py').write_text(t)
