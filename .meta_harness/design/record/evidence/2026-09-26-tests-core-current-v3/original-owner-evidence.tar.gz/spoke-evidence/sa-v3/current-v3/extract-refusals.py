import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
source = ROOT / '.meta_harness/design/spec/capabilities/stream-assembly/v3/examples.md'
text = source.read_text()
digest = hashlib.sha256(source.read_bytes()).hexdigest()
states = {
    1: 'complete-model', 2: 'complete-model', 3: 'complete-model',
    4: 'closed-text-0', 5: 'open-text-3', 6: 'empty', 7: 'open-text-0',
    8: 'open-text-0', 9: 'closed-text-0', 10: 'open-text-0', 11: 'open-text-0',
    12: 'open-text-0', 13: 'open-text-0', 14: 'open-call-0', 15: 'reported-account',
    16: 'open-text-0', 17: 'open-image-2', 18: 'open-voice-0', 19: 'empty',
    20: 'empty', 21: 'none', 22: 'empty', 23: 'complete-model', 24: 'closed-image-2',
    25: 'closed-text-0', 26: 'open-text-3', 27: 'complete-model', 28: 'open-text-0',
}
records = []
section = ''
for line_number, line in enumerate(text.splitlines(), 1):
    if line.startswith('## '): section = line[3:]
    if not section.startswith('5.'): continue
    match = re.match(r'\| ([0-9]+) \|', line)
    if match is None: continue
    cells = [x.strip() for x in line.split('|')[1:-1]]
    expected = re.search(r'`([a-z_]+)`', cells[3])[1]
    operation = re.search(r'`(accept|abandon|closeOut|start)`', cells[2])[1]
    row = int(match[1])
    records.append({'id': f'EX5-{row:02d}', 'path': str(source.relative_to(ROOT)), 'sha256': digest,
                    'line': line_number, 'row': row, 'givenState': cells[1], 'stateFixture': states[row],
                    'inputDescription': cells[2], 'operation': operation, 'expected': expected,
                    'basis': cells[4], 'oracleConflictReported': False})
assert sorted(x['row'] for x in records) == list(range(1,29))
out = ROOT / 'packages/core/stream-assembly/tests/fixtures/refusal-cases.json'
out.write_text(json.dumps({'scope': 'Exact adopted v3 table rows; stateFixture resolves only the documented shorthand. Prior v2 conflicts remain in the sealed old epoch.', 'cases': records}, ensure_ascii=False, indent=2) + '\n')
print(f'{len(records)} exact refusal rows extracted; v3 adopted oracles retained')
