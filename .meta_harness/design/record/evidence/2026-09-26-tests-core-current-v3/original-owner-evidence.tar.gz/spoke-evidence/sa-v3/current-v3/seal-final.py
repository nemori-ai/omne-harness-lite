import datetime,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[3]
out=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='7b9b3df24fc409908052fd1c06ebbea772989d9a'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pkg=root/'packages/core/stream-assembly'
files=sorted(p for p in pkg.rglob('*') if p.is_file() and not any(part in ['dist','node_modules'] for part in p.parts))
source={str(p.relative_to(root)):hashfile(p) for p in files}
records={}
for name in ['build-final','types-r4','tests-r2','format-final','consumer-runtime-r2','consumer-types-r2','static-red-controls','checker-tests','performance','inputs-final','coverage-r3']:
 rec=json.loads((out/f'{name}.json').read_text())
 assert rec['exitCode']==0,name
 scoped={k:v for k,v in rec['sourceHashes'].items() if (name!='build-final' or '/src/' in k or k.endswith(('package.json','tsconfig.build.json'))) and (name!='static-red-controls' or '/src/' in k)}
 if name=='checker-tests': scoped={}  # checker package tests; own source hashes are only contextual
 rec['finalScopeComparison']={'matches':True,'files':list(scoped),'scope':'Only actual check inputs: build source/config, static controls source, checker own tools, otherwise whole maintained package.'}
 assert all(source.get(k)==v for k,v in scoped.items()),(name,'source mismatch')
 records[name]=rec
scan=json.loads((out/'rules-final.log').read_text())
assert scan['rules']==27 and len(scan['files'])==11 and scan['violations']==[]
assert (out/'rules-final.exit').read_text().strip()=='0'
controls=json.loads((out/'guards-27/manifest.json').read_text())
assert controls['sourceUnchanged'] and [r['exitCode'] for r in controls['scenarios']]==[0,1,1,1,1]
with (out/'source.tar').open('wb') as f: subprocess.run(['git','archive',head,'packages/core/stream-assembly'],cwd=root,stdout=f,check=True)
versions={n:subprocess.check_output(argv,cwd=root,text=True).strip() for n,argv in [('node',['node','--version']),('pnpm',['pnpm','--version']),('typescript',['pnpm','--filter','@omne-harness-lite/stream-assembly','exec','tsc','--version'])]}
versions['node-types']=json.loads((pkg/'node_modules/@types/node/package.json').read_text())['version']
versions['vitest']=json.loads((pkg/'node_modules/vitest/package.json').read_text())['version']
config_paths=[root/'package.json',root/'pnpm-workspace.yaml',root/'pnpm-lock.yaml',root/'tsconfig.base.json',root/'scripts/format.sh',root/'tools/ts-checks/package.json']
config_paths += sorted(p for p in (root/'tools/ts-checks/src').rglob('*.ts'))
providers={}
for name in ['arrival-events','content-blocks','call-accounts','loop-extension','asset-model','identity-values','offer-expiry']:
 base=root/'packages/core'/name
 providers[name]={str(p.relative_to(root)):hashfile(p) for p in sorted(base.rglob('*')) if p.is_file() and not any(part in ['node_modules','tests'] for part in p.parts) and (p.suffix in ['.ts','.js','.json'] or p.name=='package.json')}
manifest={'sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'delivery complete, local verification passed, root acceptance pending','sourceCommit':head,'trackedClean':True,'dependencyPilot':'eabfff0f167093f34cfa0582c7e6cf0773761016','dependencyMerge':'1748c6735478f03b1ba907c3d40232b9eacd5240','sourceFiles':source,'sourceArchiveSha256':hashfile(out/'source.tar'),'commandReceipts':records,'actualStaticScan':scan,'parserRedControls':controls,'tools':versions,'configHashes':{str(p.relative_to(root)):hashfile(p) for p in config_paths},'providerHashes':providers,'inputReceipt':'input-recheck-final.json','coverageReceipt':'coverage-final.json','localRemaining':[],'pending':['root independent technical acceptance/SA3 fixture equivalence','root lock importer','root W6 actual composition','human final overall acceptance'],'ignoredAsset':'tmp/w6-stream-assembly/','historicalSeal':'baseline-456/SHA256SUMS=e59f4f9a1220bc3c1ac9347993854363ddcea5673d2f984fb06f55f7f01a269b','scope':'Snapshots and hashes are developer evidence, not new normative authority. Exact argv/cwd/start/end/exit preserved; models and pure implementation separated.'}
assert hashfile(root/'tmp/w6-stream-assembly/baseline-456/SHA256SUMS')==manifest['historicalSeal'].split('=')[1]
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for directory in [out,root/'tmp/w6-stream-assembly']:
 hashes=[]
 for p in sorted(directory.rglob('*')):
  if p.is_file() and 'node_modules' not in p.parts and p!=directory/'SHA256SUMS':
   hashes.append(f'{hashfile(p)}  {p.relative_to(directory)}')
 (directory/'SHA256SUMS').write_text('\n'.join(hashes)+'\n')
 print(str(directory.relative_to(root)),len(hashes),hashfile(directory/'SHA256SUMS'))
print('manifest',hashfile(out/'manifest.json'))
