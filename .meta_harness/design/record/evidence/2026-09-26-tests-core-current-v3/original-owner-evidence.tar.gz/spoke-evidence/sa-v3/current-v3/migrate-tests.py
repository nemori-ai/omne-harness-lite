import re
from pathlib import Path
root=Path(__file__).resolve().parents[3]
for path in (root/'packages/core/stream-assembly/tests').glob('*.ts'):
    text=path.read_text()
    if 'acceptWithSealer' not in text: continue
    text=text.replace("import { acceptWithSealer } from '../src/accept.ts'", "import { accept } from '../src/index.ts'")
    text=text.replace("import { incompleteToolCall, parseCollectedToolCall, type ToolOpening } from '../src/close.ts'\n", '')
    text=re.sub(r'function seal\(opened: ToolOpening, raw: string, changed: boolean\) \{.*?\n\}\n', '', text, flags=re.S)
    text=text.replace('acceptWithSealer', 'accept').replace(', seal)', ')')
    text=re.sub(r'\n\s*seal,\n', '\n', text)
    text=text.replace('validate, writeJsonLossless', 'writeJsonLossless') if path.name=='normative.spec.ts' else text
    path.write_text(text)
