from pathlib import Path
root=Path(__file__).resolve().parents[3]
old=root/'tmp/w6-stream-assembly'
for name in ['extract-examples.py','extract-refusals.py']:
    text=(old/name).read_text().replace('parents[2]', 'parents[3]').replace('capabilities/stream-assembly/v2/examples.md','capabilities/stream-assembly/v3/examples.md')
    if name=='extract-examples.py':
        start=text.index('    value = json.loads(source)')
        end=text.index('\n\n\nartifacts = []', start)
        text=text[:start]+'''    source = re.sub(r'("visibility"\\s*:\\s*)"(H[01]M[01])"',
        lambda m: m[1] + json.dumps({'toHuman': m[2][1] == '1', 'toModel': m[2][3] == '1'}), source)
    json.loads(source)  # syntax check only; retain original numeric literals
    return source''' + text[end:]
    else:
        text=text.replace('row in [25, 26]', 'False').replace('Exact frozen table rows; stateFixture resolves the table shorthand into an admitted input. The two reported oracle conflicts remain original, unresolved values.', 'Exact adopted v3 table rows; stateFixture resolves only the documented shorthand. Prior v2 conflicts remain in the sealed old epoch.').replace('unresolved oracles kept unchanged', 'v3 adopted oracles retained')
    (Path(__file__).parent/name).write_text(text)
