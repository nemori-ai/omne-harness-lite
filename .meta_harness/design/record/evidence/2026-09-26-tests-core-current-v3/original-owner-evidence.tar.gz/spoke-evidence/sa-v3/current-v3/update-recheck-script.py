from pathlib import Path
p=Path(__file__).parent/'recheck-inputs.py'
t=p.read_text().replace("assert plans[2]['sha256']=='0cdc74ec7579f7ccc5a7f1b470fb3f13fc8d3b8491bae5598d935bae1b39142f'",'''original=hub/'tmp/core-delivery/acceptance-matrix.before-D068-formal-acceptance.json'
assert hashfile(original)=='0cdc74ec7579f7ccc5a7f1b470fb3f13fc8d3b8491bae5598d935bae1b39142f'
(out/'input-snapshots/acceptance-matrix.initial-0cdc74ec.json').write_bytes(original.read_bytes())
initial={r['id']:r for r in json.loads(original.read_text())['obligations'] if r['node']=='stream-assembly'}
current={r['id']:r for r in json.loads((hub/'tmp/core-delivery/acceptance-matrix.json').read_text())['obligations'] if r['node']=='stream-assembly'}
assert initial.keys()==current.keys() and len(current)==20
for key in initial:
 diff={name for name in initial[key].keys()|current[key].keys() if initial[key].get(name)!=current[key].get(name)}
 if diff: assert key=='stream-assembly.bounded-formal' and diff <= {'current_epoch_acceptance','current_epoch_evidence','delivery_state','verification_status'}
plans.append({'path':str(original),'sha256':hashfile(original),'evidenceSnapshot':'input-snapshots/acceptance-matrix.initial-0cdc74ec.json','reason':'Exact original dispatch matrix; current change is root accepted formal evidence metadata only.'})''')
p.write_text(t)
