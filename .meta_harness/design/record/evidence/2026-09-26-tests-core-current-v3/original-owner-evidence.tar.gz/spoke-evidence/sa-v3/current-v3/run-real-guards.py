import datetime
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[3]
out = root / 'tmp/w6-stream-assembly/current-v3/guards-27'
out.mkdir(exist_ok=False)
source = root / 'packages/core/stream-assembly/src'
original = {str(path.relative_to(source)): hashlib.sha256(path.read_bytes()).hexdigest() for path in source.rglob('*.ts')}
cli = root / 'tools/ts-checks/src/cli.ts'
scenarios = [('actual-repo', root / 'packages', 0)]
for name in ['missing-parser-anchor', 'missing-incomplete-anchor', 'second-strict-parser', 'second-json-parser']:
    packages = out / name / 'packages'
    target = packages / 'core/stream-assembly/src'
    shutil.copytree(source, target)
    close = target / 'close.ts'
    if name == 'missing-parser-anchor':
        close.write_text(close.read_text().replace('function parseCollectedToolCall(', 'function renamedParser('))
    elif name == 'missing-incomplete-anchor':
        close.write_text(close.read_text().replace('function incompleteToolCall(', 'function renamedIncomplete('))
    elif name == 'second-strict-parser':
        (target / 'snapshot-red.ts').write_text("import {readJsonStrict} from '@omne-harness-lite/content-blocks'; export function snapshotRed(raw: string) { return readJsonStrict(raw) }\n")
    else:
        (target / 'snapshot-red.ts').write_text('export function snapshotRed(raw: string) { return JSON.parse(raw) }\n')
    scenarios.append((name, packages, 1))
records = []
for name, packages, expected in scenarios:
    argv = ['node', '--experimental-strip-types', str(cli), str(packages)]
    begin = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out / f'{name}.log').open('w') as stream:
        result = subprocess.run(argv, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    raw = (out / f'{name}.log').read_text()
    record = {'scenario':name,'argv':argv,'cwd':str(root),'startedAt':begin,'exitCode':result.returncode,'expectedExitCode':expected,'rawLog':f'{name}.log','singleParserRuleObserved': 'single-tool-argument-parser' in raw}
    records.append(record)
    print(name,result.returncode,flush=True)
    if result.returncode != expected or (expected == 1 and not record['singleParserRuleObserved']):
        (out / 'failed-records.json').write_text(json.dumps(records,indent=2)+'\n')
        raise ValueError(f'actual CLI did not meet {name} control expectation')
unchanged = original == {str(path.relative_to(source)): hashlib.sha256(path.read_bytes()).hexdigest() for path in source.rglob('*.ts')}
if not unchanged: raise ValueError('product source changed during isolated red control')
(out / 'manifest.json').write_text(json.dumps({'sourceUnchanged':unchanged,'sourceHashes':original,'scenarios':records,'scope':'Actual CLI, actual source snapshot. Red controls mutate isolated copied fixtures only. Parser registration is static; lifecycle parse counts remain a distinct runtime obligation.'},ensure_ascii=False,indent=2)+'\n')
