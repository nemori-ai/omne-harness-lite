import datetime, hashlib, json, subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parents[3]
out=Path(__file__).parent
name=sys.argv[1]
argv=sys.argv[2:]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/f'{name}.log').open('w') as f:
    p=subprocess.run(argv,cwd=root,stdout=f,stderr=subprocess.STDOUT)
record={'name':name,'argv':argv,'cwd':str(root),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'gitHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(), 'sourceHashes':{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((root/'packages/core/stream-assembly').rglob('*')) if f.is_file() and not any(p in ['dist','node_modules'] for p in f.parts)}}
(out/f'{name}.json').write_text(json.dumps(record,indent=2)+'\n')
print(name,p.returncode)
if p.returncode: print((out/f'{name}.log').read_text()[-12000:])
sys.exit(p.returncode)
