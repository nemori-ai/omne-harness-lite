from pathlib import Path
root=Path(__file__).resolve().parents[3]
p=Path(__file__).parent/'implementation-probe.mjs'
t=(root/'tmp/w6-stream-assembly/implementation-probe.mjs').read_text()
start=t.index("import { acceptWithSealer }")
end=t.index('\n\nconst root',start)
t=t[:start]+"import { accept as acceptEvent, start, snapshot, closeOut } from '@omne-harness-lite/stream-assembly'\nimport { judgeContentBlock, writeJsonLossless } from '@omne-harness-lite/content-blocks'"+t[end:]
t=t.replace("new URL('../../',", "new URL('../../../',")
start=t.index('function seal(')
end=t.index('function initial()',start)
t=t[:start]+t[end:]
t=t.replace('acceptWithSealer(state, event, seal)', 'acceptEvent(state, event)').replace('ns::probe','ns__probe')
t=t.replace('const rawArguments =', "if (!('ok' in judgeContentBlock({ kind: 'tool_call', id: 'b_0', visibility: { toHuman: true, toModel: false }, complete: true, callId: 'tc_0', tool: 'ns__probe', arguments: {} }))) throw new Error('normal performance fixture must satisfy CB3')\nconst rawArguments =")
t=t.replace('return result.ok.blocks.length\n}))', "if (!('arguments' in result.ok.blocks[0]) || writeJsonLossless(result.ok.blocks[0].arguments) !== rawArguments || !('ok' in judgeContentBlock(result.ok.blocks[0]))) throw new Error('tool close did not exercise legal parsed-arguments branch')\n  return result.ok.blocks.length\n}))")
t=t.replace('Actual built package internal operations with temporary legal-name-only sealer; public API release and conflicting-name branch are pending adopted specification versions.', 'Actual package root built public five-operation API, adopted SA3/CB3 with AR2/CA2; legal tool-name fixture checked by CB3 and parsed arguments exact equality.')
p.write_text(t)
links=Path(__file__).parent/'node_modules/@omne-harness-lite'
links.mkdir(parents=True)
for name in ['stream-assembly','content-blocks']:
    (links/name).symlink_to(root/f'packages/core/{name}',target_is_directory=True)
