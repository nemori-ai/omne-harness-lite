from pathlib import Path
root=Path(__file__).resolve().parents[3]
for p in [Path(__file__).parent/'consumer/types.ts', root/'packages/core/stream-assembly/tests/public.spec-d.ts']:
    t=p.read_text().replace("import { AssemblyState as StateConstructor }", "import * as PublicAssembly")
    t=t.replace('new StateConstructor({})','new PublicAssembly.AssemblyState({})')
    p.write_text(t)
