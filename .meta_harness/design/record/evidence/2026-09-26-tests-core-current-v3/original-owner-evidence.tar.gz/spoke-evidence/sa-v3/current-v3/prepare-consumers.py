import shutil
from pathlib import Path
root=Path(__file__).resolve().parents[3]
out=Path(__file__).parent/'consumer'
shutil.copytree(root/'tmp/w6-stream-assembly/consumer',out)
runtime=out/'runtime.mjs'
t=runtime.read_text()
t=t.replace("let state = step(started.ok, {", "assert.ok('ok' in judgeContentBlock({ kind: 'tool_call', id: 'b_public', callId: 'tc_public', tool: 'ns__read', complete: true, visibility: { toHuman: true, toModel: true }, arguments: {} }))\nlet state = step(started.ok, {")
runtime.write_text(t)
t=(out/'types.ts').read_text().replace('temporary construction seam', 'removed construction seam')
(out/'types.ts').write_text(t)
(root/'packages/core/stream-assembly/tests/public.spec-d.ts').write_text(t.replace("'@omne-harness-lite/stream-assembly'", "'../src/index.ts'"))
links=out/'node_modules/@omne-harness-lite'
links.mkdir(parents=True)
for name in ['stream-assembly','content-blocks']:
    (links/name).symlink_to(root/f'packages/core/{name}', target_is_directory=True)
