export function snapshotRed(raw: string) { return JSON.parse(raw) }
