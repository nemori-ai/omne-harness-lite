from pathlib import Path
root=Path(__file__).resolve().parents[3]
for p in [Path(__file__).parent/'consumer/types.ts', root/'packages/core/stream-assembly/tests/public.spec-d.ts']:
    t=p.read_text().replace('const open: OpenedBlock', "declare const blockId: ContentBlock['id']\nconst open: OpenedBlock")
    t=t.replace("id: 'b_type'", 'id: blockId')
    p.write_text(t)
