import subprocess, sys
from pathlib import Path
root=Path(__file__).resolve().parents[3]
pkg=root/'packages/core/stream-assembly'
files=sorted(str(f.relative_to(root)) for f in pkg.rglob('*') if f.is_file() and not any(p in ['node_modules','dist'] for p in f.parts) and (f.suffix=='.ts' or f.name=='package.json' or f.name.startswith('tsconfig.')))
p=subprocess.run([str(root/'.venv/bin/python'),str(Path(__file__).parent/'run-gates.py'),'format-final','pnpm','format:check','--',*files],cwd=root)
sys.exit(p.returncode)
