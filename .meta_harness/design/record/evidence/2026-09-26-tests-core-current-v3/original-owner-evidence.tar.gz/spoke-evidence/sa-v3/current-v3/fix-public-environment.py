import json
from pathlib import Path
root=Path(__file__).resolve().parents[3]
out=Path(__file__).parent/'consumer'
p=out/'runtime.mjs'
p.write_text(p.read_text().replace("before.position.toString()", "writeJsonLossless(before.position)"))
p=out/'tsconfig.json'
t=json.loads(p.read_text())
t['compilerOptions']['types']=['node']
p.write_text(json.dumps(t,indent=2)+'\n')
link=out/'node_modules/@types/node'
link.parent.mkdir(exist_ok=True)
link.symlink_to((root/'packages/core/stream-assembly/node_modules/@types/node').resolve(),target_is_directory=True)
p=out/'package.json'
t=json.loads(p.read_text())
t['devDependencies']={'@types/node':'25.4.0','typescript':'6.0.3'}
# Record the actual resolved platform package rather than assuming its release.
t['devDependencies']['@types/node']=json.loads((link/'package.json').read_text())['version']
p.write_text(json.dumps(t,indent=2)+'\n')
