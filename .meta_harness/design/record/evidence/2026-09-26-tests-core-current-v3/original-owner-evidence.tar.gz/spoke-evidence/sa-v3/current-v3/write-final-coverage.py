import hashlib,json,runpy
from pathlib import Path
root=Path(__file__).resolve().parents[3]
out=Path(__file__).parent
# Reuse the previously published link definitions as data only; do not run its draft writer.
old=(root/'tmp/w6-stream-assembly/write-coverage.py').read_text()
ns={}
exec(old[old.index('links = {'):old.index('for refs in links.values():')],ns)
exec(old[old.index('clauses = {'):old.index('rows = []')],ns)
links=ns['links']; clauses=ns['clauses']
links['public-package-consumer']=['public.spec-d.ts::PUBLIC-TYPES-01']
links['schema-frozen-bytes'].append('fixtures.spec.ts::INPUT-04')
clauses.update({'S-30':[],'SC-1':['parse-once.spec.ts'],'SC-2':[],'SC-3':['refusals.spec.ts','priorities.spec.ts'],'SC-4':['immutability.spec.ts','properties.spec.ts::PROP-FORK']})
report=json.loads((out/'vitest-r2.json').read_text())
assert report['success'] and report['numTotalTests']==report['numPassedTests']==479 and report['numPendingTests']==report['numFailedTests']==0
inventory=[]
for suite in report['testResults']:
 for test in suite['assertionResults']:
  assert test['status']=='passed'
  inventory.append({'file':Path(suite['name']).name,'testID':test['fullName'],'status':test['status'],'durationMs':test.get('duration')})
assert len(inventory)==479
(out/'test-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
def tests(refs):
 found=[]
 for ref in refs:
  filename,_,prefix=ref.partition('::')
  # Old refs denoted the generic authored table title; actual expanded IDs include EX5-n.
  selected=[row for row in inventory if row['file']==filename and (not prefix or prefix in row['testID'] or (prefix=='exact $expected' and 'EX5-' in row['testID']))]
  assert selected,ref
  found.extend({'file':row['file'],'testID':row['testID']} for row in selected)
 return list({(r['file'],r['testID']):r for r in found}.values())
matrix_path=out/'input-snapshots/acceptance-matrix.json'
matrix=json.loads(matrix_path.read_text())
rows=[]
receipts={'public-package-consumer':['consumer-runtime-r2.json','consumer-types-r2.json','consumer/tsconfig.json'],
 'source-purity':['rules-final.log','guards-27/manifest.json','static-red-controls.json','checker-tests.json'],
 'schema-frozen-bytes':['input-recheck-final.json','tests-r2.json'],
 'bounded-formal':['input-recheck-final.json#formal','HUB@c487d65b:.meta_harness/design/record/evidence/2026-09-26-formal-core-v3/']}
for original in matrix['obligations']:
 if original['node']!='stream-assembly': continue
 name=original['id'].removeprefix('stream-assembly.')
 row={k:original[k] for k in ['id','owner','stage','input_coordinate','source']}
 row['testIDs']=tests(links[name]); row['receipts']=receipts.get(name,['tests-r2.json','vitest-r2.json'])
 row['status']='local-evidence-complete-await-root-technical-acceptance' if row['stage']=='core-local' else 'not-closed-here'
 if name=='bounded-formal': row['status']='root-model-accepted-P1-P7-only';row['implementationProof']=False
 if row['stage']!='core-local': row['receipts']=[]
 row['scope']='Pure current core step only; full host walkthrough stays external.' if name.endswith('core-step') else 'Full identified local obligation within accepted node boundary.'
 if row['stage']=='external': row['scope']='External host/consumer premise, not implemented or accepted by this pure package.'
 if name=='actual-core-chain': row['scope']='Actual W6 core chain is root-owned; this package supplies its released public API but does not self-accept the chain.'
 rows.append(row)
assert len(rows)==20 and sum(r['stage']=='core-local' for r in rows)==14
mapped={k:tests(v) for k,v in clauses.items()}
limits=['V6/S28 host routing, ordered exact delivery, real first-content time, record-once and on-unload abandon','V7/S29 cross-process/isolation/persistence','Whole CS1-CS4 consumer paths','S32 failed execution outcome belongs to tool runtime; this pure library never executes','Root W6 content/accounts→arrival→stream→messages/response/settlement composition']
result={'format':1,'status':'implementation and local verification complete; no self-acceptance','sourceCommit':'7b9b3df24fc409908052fd1c06ebbea772989d9a','adopted':'capability.stream-assembly/v3; data.content-blocks/v3, arrival-events/v2, call-accounts/v2','matrixPath':str(matrix_path),'matrixSha256':hashlib.sha256(matrix_path.read_bytes()).hexdigest(),'originalDispatchMatrixSha256':'0cdc74ec7579f7ccc5a7f1b470fb3f13fc8d3b8491bae5598d935bae1b39142f','obligations':rows,'clauses':mapped,'scenarioResource':'tests/fixtures/source-examples.json:205 provenance artifacts, 28 refusal rows, source hashes/source slices actually tested','passedTests':{'runtime':478,'type':1,'total':479,'files':14,'skip':0,'failure':0,'raw':'vitest-r2.json'},'historicalLimit':'Original456 seal remains exact historical input; it included ns::probe in tool fixture and is not evidence for normal ModelToolName branch. Old performance tool result excluded; current real probe uses ns__probe and checks arguments/CB3.','externalLimits':limits,'remainingLocal':[],'pendingAcceptance':['root technical package/SA3 fixture equality review','root W6 composition','human final overall acceptance']}
(out/'coverage-final.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('20 IDs = 14 local (including bounded-model-only) + root composition + 5 external; 479 actual test IDs, 38 clause/SC mappings')
