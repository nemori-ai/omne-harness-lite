import hashlib,json,subprocess,datetime
from pathlib import Path
root=Path(__file__).resolve().parents[3]
hub=root.parent/'core-delivery'
out=Path(__file__).parent
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((root/'.meta_harness/design/registry/frozen.json').read_text())['files']
catalog=json.loads((root/'.meta_harness/design/registry/catalog.json').read_text())['contracts']
versions={'capability.stream-assembly':3,'data.content-blocks':3,'data.arrival-events':2,'data.call-accounts':2}
entries=[r for r in catalog if versions.get(r['coordinate']['contract_id'])==r['coordinate']['version']]
assert len(entries)==4 and all(r['status']=='accepted' for r in entries)
inputs=[]
for r in entries:
 for rel in r['resources']:
  p=root/'.meta_harness/design'/rel
  assert hashfile(p)==frozen[rel]
  inputs.append({'coordinate':r['coordinate'],'path':str(p.relative_to(root)),'sha256':hashfile(p),'matchesFrozen':True})
assert len(inputs)==17 and len([r for r in inputs if r['coordinate']['contract_id']=='capability.stream-assembly'])==8
paths=['AGENTS.md','packages/AGENTS.md','.meta_harness/AGENTS.md','.meta_harness/design/AGENTS.md','docs/development.md','docs/defensive-patterns.md','pnpm-lock.yaml','pnpm-workspace.yaml','package.json','tsconfig.base.json','.meta_harness/design/registry/catalog.json','.meta_harness/design/registry/frozen.json','.meta_harness/design/registry/version-migrations.json','.meta_harness/design/spec/capabilities/stream-assembly/verification.md']
paths += [f'.meta_harness/design/realization/packages/core/stream-assembly/{name}' for name in ['README.md','design.md','verification.md','bindings.yaml']]
paths += [f'.meta_harness/design/record/decisions/core-implementation-spec-reconciliation/{name}' for name in ['decision.md','acceptance.json']]
context=[]
for rel in paths:
 p=root/rel
 context.append({'path':rel,'sha256':hashfile(p),'source':'spoke tracked'})
plans=[]
for rel in ['tmp/core-delivery/developer-brief.md','tmp/core-delivery/implementation-delivery-plan.md','tmp/core-delivery/acceptance-matrix.json']:
 p=hub/rel
 dest=out/'input-snapshots'/Path(rel).name
 dest.parent.mkdir(exist_ok=True)
 dest.write_bytes(p.read_bytes())
 plans.append({'path':str(p),'sha256':hashfile(p),'evidenceSnapshot':str(dest.relative_to(out))})
original=hub/'tmp/core-delivery/acceptance-matrix.before-D068-formal-acceptance.json'
assert hashfile(original)=='0cdc74ec7579f7ccc5a7f1b470fb3f13fc8d3b8491bae5598d935bae1b39142f'
(out/'input-snapshots/acceptance-matrix.initial-0cdc74ec.json').write_bytes(original.read_bytes())
initial={r['id']:r for r in json.loads(original.read_text())['obligations'] if r['node']=='stream-assembly'}
current={r['id']:r for r in json.loads((hub/'tmp/core-delivery/acceptance-matrix.json').read_text())['obligations'] if r['node']=='stream-assembly'}
assert initial.keys()==current.keys() and len(current)==20
for key in initial:
 diff={name for name in initial[key].keys()|current[key].keys() if initial[key].get(name)!=current[key].get(name)}
 if diff: assert key=='stream-assembly.bounded-formal' and diff <= {'current_epoch_acceptance','current_epoch_evidence','delivery_state','verification_status'}
plans.append({'path':str(original),'sha256':hashfile(original),'evidenceSnapshot':'input-snapshots/acceptance-matrix.initial-0cdc74ec.json','reason':'Exact original dispatch matrix; current change is root accepted formal evidence metadata only.'})
formal=hub/'.meta_harness/design/record/evidence/2026-09-26-formal-core-v3'
formal_inputs=[]
for name in ['Assembly.tla','Assembly.cfg','Assembly_OrderByClose.cfg','Assembly_ReplaceAsAppend.cfg','Assembly_OneShotCloseFirst.cfg']:
 p=formal/'stream-assembly-v3-assembly/input'/name
 rel=f'spec/capabilities/stream-assembly/v3/formal/{name}'
 assert hashfile(p)==frozen[rel]
 formal_inputs.append({'path':str(p),'sha256':hashfile(p),'frozenPath':rel,'matchesFrozen':True})
formal_runs=[]
for label,invariant in [('sa3-positive',None),('sa3-Assembly_OrderByClose','BlockOrderIsOpenOrder'),('sa3-Assembly_ReplaceAsAppend','SplitInvariance'),('sa3-Assembly_OneShotCloseFirst','OneShotAccepted')]:
 base=formal/'stream-assembly-v3-assembly'/label
 result=json.loads((base/'result.json').read_text()); stdout=(base/'stdout.log').read_text()
 expected=0 if invariant is None else 12
 assert result['exit_code']==expected and not result['timed_out']
 if invariant: assert f'Invariant {invariant} is violated' in stdout
 else: assert 'Model checking completed. No error has been found.' in stdout and '826411 distinct states' in stdout
 formal_runs.append({'label':label,'exit':expected,'violatedInvariant':invariant,'files':{str(p.relative_to(hub)):hashfile(p) for p in sorted(base.iterdir()) if p.is_file()}})
formal_receipt={'durableCommit':'c487d65b','path':str(formal),'inputs':formal_inputs,'runs':formal_runs,'readScope':'Five actual archived input hashes and four original result/stdout pairs rechecked here. Root independently verified full archive; this task did not repeat solver or 630 SHA audit.','implementationProof':False,'limits':'P1/P7 only; Indices {0,1}, Frags {a,b}, MaxEvents6, no fairness, deadlock disabled; parsing, representation, real code and hosts excluded.'}
for name in ['README.md','archive-verification.json','w6-core-formal-v3-root-readout.json','review.md']:
 formal_receipt.setdefault('contextFiles',{})[name]=hashfile(formal/name)
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'dependencyPilot':'eabfff0f167093f34cfa0582c7e6cf0773761016','dependencyMerge':'1748c6735478f03b1ba907c3d40232b9eacd5240','adoptionAccepted':'3fab92007fbd386dd9616189335a3dd18dada303','nodeAdoption':'f8c76d60','scope':'Evidence snapshots only; normative source remains design workspace. Historical epochs unchanged.','resources':inputs,'context':context,'dispatchInputs':plans,'formal':formal_receipt}
(out/'input-recheck-final.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print('17 adopted resources / 8 SA files / 4 real formal result pairs match; current matrix hash exact')
