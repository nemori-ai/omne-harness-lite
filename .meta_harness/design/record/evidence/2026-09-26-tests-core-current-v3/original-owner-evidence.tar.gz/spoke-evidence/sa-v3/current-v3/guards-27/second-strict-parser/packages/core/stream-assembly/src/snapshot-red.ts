import {readJsonStrict} from '@omne-harness-lite/content-blocks'; export function snapshotRed(raw: string) { return readJsonStrict(raw) }
