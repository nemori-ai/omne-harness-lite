import { createHash } from 'node:crypto'
import { readFileSync, writeFileSync, readdirSync } from 'node:fs'
import { performance } from 'node:perf_hooks'
import { fileURLToPath } from 'node:url'
import { accept as acceptEvent, start, snapshot, closeOut } from '@omne-harness-lite/stream-assembly'
import { judgeContentBlock, writeJsonLossless } from '@omne-harness-lite/content-blocks'

const root = fileURLToPath(new URL('../../../', import.meta.url))
const sourceDir = `${root}packages/core/stream-assembly/src/`
const sourceHashes = Object.fromEntries(readdirSync(sourceDir).sort().map(name => [
  name, createHash('sha256').update(readFileSync(`${sourceDir}${name}`)).digest('hex'),
]))
const config = Object.freeze({
  blockCounts: [8, 64, 512], fills: 128, snapshots: 24, repeatedSettlements: 12,
  voiceBytes: 8192, voiceChunks: 64, retainedStates: 96, warmup: 1, repetitions: 3,
})
let consumer = 0
function initial() {
  const result = start({ kind: 'model_call', callId: 'mc_probe', dispatch: 1 })
  if ('rejected' in result) throw new Error(`start: ${result.rejected}`)
  return result.ok
}
function accept(state, event) {
  const result = acceptEvent(state, event)
  if ('rejected' in result) throw new Error(`${event.t}: ${result.rejected}`)
  return result.ok
}
function opening(index, kind = 'text') {
  return {
    t: 'open', index, kind, fill: 'append', id: `b_${index}`,
    visibility: { toHuman: true, toModel: kind !== 'tool_call' },
    ...(kind === 'voice' ? { head: { mediaType: 'audio/wav' } }
      : kind === 'tool_call' ? { head: { tool: 'ns__probe', callId: `tc_${index}` } } : {}),
  }
}
function blocks(count) {
  let state = initial()
  for (let index = 0; index < count; index++) state = accept(state, opening(index))
  return state
}
function filled(count) {
  let state = blocks(count)
  for (let index = 0; index < config.fills; index++) {
    // Mathematical-index lookup, including blocks near the end of the record array.
    state = accept(state, { t: 'fill', index: (index * 37) % count, payload: `piece-${index}` })
  }
  return state
}
function timed(action) {
  const begin = performance.now()
  const result = action()
  return { result, elapsedMs: performance.now() - begin }
}
function median(values) { return [...values].sort((a, b) => a - b)[Math.floor(values.length / 2)] }
function measure(name, setup, action) {
  const samples = []
  for (let trial = 0; trial < config.warmup + config.repetitions; trial++) {
    const state = setup()
    const result = timed(() => action(state))
    if (trial >= config.warmup) samples.push(result.elapsedMs)
    consumer += result.result
  }
  return { name, samplesMs: samples, medianMs: median(samples) }
}
const results = []
for (const count of config.blockCounts) {
  results.push(measure(`accept-fill-${count}`, () => blocks(count), state => {
    for (let index = 0; index < config.fills; index++) {
      state = accept(state, { t: 'fill', index: (index * 37) % count, payload: `piece-${index}` })
    }
    return snapshot(state).blocks.length
  }))
  results.push(measure(`dense-snapshot-${count}`, () => filled(count), state => {
    let seen = 0
    for (let index = 0; index < config.snapshots; index++) seen += snapshot(state).blocks.length
    return seen
  }))
  results.push(measure(`direct-closeOut-${count}`, () => accept(filled(count), { t: 'finish', reason: 'end' }), state => {
    let seen = 0
    for (let index = 0; index < config.repeatedSettlements; index++) {
      const result = closeOut(state)
      if ('rejected' in result) throw new Error(result.rejected)
      seen += result.ok.blocks.length
    }
    return seen
  }))
}
const bytes = Buffer.from(Array.from({ length: config.voiceBytes }, (_, index) => index % 251))
const payloads = Array.from({ length: config.voiceChunks }, (_, index) => bytes
  .subarray(index * (config.voiceBytes / config.voiceChunks), (index + 1) * (config.voiceBytes / config.voiceChunks))
  .toString('base64'))
results.push(measure('voice-accept-and-direct-closeOut', () => accept(initial(), opening(0, 'voice')), state => {
  for (const payload of payloads) state = accept(state, { t: 'fill', index: 0, payload })
  state = accept(state, { t: 'finish', reason: 'lost' })
  const result = closeOut(state)
  if ('rejected' in result || result.ok.blocks[0]?.kind !== 'voice') throw new Error('voice settlement')
  const output = Buffer.from(result.ok.blocks[0].data.inline, 'base64')
  if (!output.equals(bytes)) throw new Error('voice bytes differ')
  return output.length
}))
if (!('ok' in judgeContentBlock({ kind: 'tool_call', id: 'b_0', visibility: { toHuman: true, toModel: false }, complete: true, callId: 'tc_0', tool: 'ns__probe', arguments: {} }))) throw new Error('normal performance fixture must satisfy CB3')
const rawArguments = `{"exact":9007199254740993,"parts":[${Array.from({ length: 64 }, (_, index) => `"value-${index}"`).join(',')}]}`
results.push(measure('accepted-tool-close-once-and-direct-closeOut', () => {
  let state = accept(initial(), opening(0, 'tool_call'))
  for (let index = 0; index < rawArguments.length; index += 32) {
    state = accept(state, { t: 'fill', index: 0, payload: rawArguments.slice(index, index + 32) })
  }
  return state
}, state => {
  state = accept(state, { t: 'close', index: 0 })
  state = accept(state, { t: 'finish', reason: 'end' })
  const result = closeOut(state)
  if ('rejected' in result || result.ok.blocks[0]?.kind !== 'tool_call' || !result.ok.blocks[0].complete) {
    throw new Error('tool settlement')
  }
  if (!('arguments' in result.ok.blocks[0]) || writeJsonLossless(result.ok.blocks[0].arguments) !== rawArguments || !('ok' in judgeContentBlock(result.ok.blocks[0]))) throw new Error('tool close did not exercise legal parsed-arguments branch')
  return result.ok.blocks.length
}))
if (typeof global.gc !== 'function') throw new Error('Use node --expose-gc')
global.gc()
const baselineHeapUsedBytes = process.memoryUsage().heapUsed
let retained = [blocks(512)]
const retainedMeasure = timed(() => {
  for (let index = 0; index < config.retainedStates; index++) {
    retained.push(accept(retained.at(-1), { t: 'fill', index: index % 512, payload: `retained-${index}` }))
  }
})
global.gc()
const postGcHeapUsedBytes = process.memoryUsage().heapUsed
const previousSnapshot = snapshot(retained[0])
if (previousSnapshot.blocks.some(block => 'content' in block)) throw new Error('old state changed')
const retainedMemory = {
  blocks: 512, retainedStates: retained.length, acceptElapsedMs: retainedMeasure.elapsedMs,
  baselineHeapUsedBytes, postGcHeapUsedBytes,
  postGcHeapDeltaBytes: postGcHeapUsedBytes - baselineHeapUsedBytes,
  scope: 'One process sample retaining 97 actual states; includes the initial 512-record state and fixture/JIT effects. Not a stable per-state bound.',
}
consumer += snapshot(retained.at(-1)).blocks.length
retained = []
const result = {
  config, tool: { node: process.version, platform: process.platform, architecture: process.arch }, sourceHashes,
  entry: 'Actual package root built public five-operation API, adopted SA3/CB3 with AR2/CA2; legal tool-name fixture checked by CB3 and parsed arguments exact equality.',
  limits: [
    'Elapsed samples are local development trends, not host latency guarantees or throughput acceptance limits.',
    'AR representation validation and exact mathematical index lookup run on each accepted event.',
    'accept-fill includes one snapshot for observable consumption; dense snapshot and direct settlement are separate.',
    'Direct closeOut is measured from finished state, without pre-materialized snapshot input or a cache.',
    'Voice case measures actual decode/concat and compares all output bytes; tool close includes the actual strict parameter parser.',
    'No domain rejection, block limit, clock, cache or mutable state was introduced in the product.',
  ],
  results, retainedMemory, consumer,
}
writeFileSync(new URL('implementation-probe.json', import.meta.url), `${JSON.stringify(result, null, 2)}\n`)
console.log(JSON.stringify({ results, retainedMemory }, null, 2))
