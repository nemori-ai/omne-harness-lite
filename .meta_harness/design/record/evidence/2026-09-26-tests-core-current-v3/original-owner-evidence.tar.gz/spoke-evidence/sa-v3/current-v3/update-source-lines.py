from pathlib import Path
import re
root=Path(__file__).resolve().parents[3]
p=root/'packages/core/stream-assembly/tests/normative.spec.ts'
t=p.read_text()
t=re.sub(r'expectedAt\((\d+)\)', lambda m:'expectedAt('+str(int(m[1])+1)+')',t)
for old in [47,262,263,276,293,319]:
    t=re.sub(r'(?<!\d)'+str(old)+r'(?!\d)',str(old+1),t) if old==47 else t
# Each source-line constant shifts once; avoid cascading replacement.
t=re.sub(r'(?<!\d)(262|263|276|293|319)(?!\d)',lambda m:str(int(m[1])+1),t)
p.write_text(t)
