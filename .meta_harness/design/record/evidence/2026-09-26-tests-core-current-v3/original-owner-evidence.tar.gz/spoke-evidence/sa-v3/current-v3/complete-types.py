from pathlib import Path
root=Path(__file__).resolve().parents[3]
extra='''
import type {
  AssemblyFailure, AssemblyRejection, AssemblyResult, OpenedBlock, ReducedContent,
  SnapshotBlock, AssemblySnapshot, AssemblyEnding, ModelAssemblyAccount, ToolAssemblyAccount,
} from '@omne-harness-lite/stream-assembly'
import type { JsonNumber, ContentBlock } from '@omne-harness-lite/content-blocks'

declare const snapshotValue: AssemblySnapshot
const position: JsonNumber = snapshotValue.position
const blocks: readonly SnapshotBlock[] = snapshotValue.blocks
const failure: AssemblyFailure = 'stream_not_finished'
const rejection: AssemblyRejection = failure
const refusal: AssemblyResult<AssemblyState> = { rejected: rejection }
const open: OpenedBlock = { kind: 'text', fill: 'append', id: 'b_type', visibility: { toHuman: true, toModel: false } }
const content: ReducedContent = ''
const unfinished: SnapshotBlock = { index: 0, closed: false, opened: open, content }
const ending: AssemblyEnding = { reason: 'lost', error: { cause: 'upstream_unavailable' } }
declare const modelAccount: ModelAssemblyAccount
declare const toolAccount: ToolAssemblyAccount
const modelSettlement: AssemblySettlement = { blocks: [], account: modelAccount, ending }
const toolSettlement: AssemblySettlement = { blocks: [], account: toolAccount, ending: { reason: 'end' } }
const contentBlocks: readonly ContentBlock[] = modelSettlement.blocks
// @ts-expect-error ending cause belongs only to lost
const wrongEnding: AssemblyEnding = { reason: 'end', error: { cause: 'upstream_unavailable' } }
// @ts-expect-error successful settlement never contains the stream snapshot position
modelSettlement.position
void [position, blocks, refusal, unfinished, toolSettlement, contentBlocks, wrongEnding]
'''
consumer=Path(__file__).parent/'consumer/types.ts'
consumer.write_text(consumer.read_text()+extra)
public=root/'packages/core/stream-assembly/tests/public.spec-d.ts'
public.write_text(public.read_text()+extra.replace("'@omne-harness-lite/stream-assembly'", "'../src/index.ts'")+'''
import { expectTypeOf, it } from 'vitest'
it('PUBLIC-TYPES-01 all five operations preserve exact required inputs and results', () => {
  expectTypeOf(start).parameters.toEqualTypeOf<[target: unknown]>()
  expectTypeOf(accept).parameters.toEqualTypeOf<[state: AssemblyState, event: unknown]>()
  expectTypeOf(snapshot).returns.toEqualTypeOf<AssemblySnapshot>()
  expectTypeOf(closeOut).returns.toEqualTypeOf<AssemblyResult<AssemblySettlement, 'stream_not_finished'>>()
  expectTypeOf(abandon).returns.toEqualTypeOf<AssemblyResult<AssemblySettlement, 'malformed' | 'event_after_finish'>>()
})
''')
