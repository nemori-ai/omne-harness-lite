from pathlib import Path
p=Path(__file__).parent/'write-final-coverage.py'
t=p.read_text().replace("(not prefix or prefix in row['testID'])", "(not prefix or prefix in row['testID'] or (prefix=='exact $expected' and ' EX5-' in row['testID']))")
p.write_text(t)
