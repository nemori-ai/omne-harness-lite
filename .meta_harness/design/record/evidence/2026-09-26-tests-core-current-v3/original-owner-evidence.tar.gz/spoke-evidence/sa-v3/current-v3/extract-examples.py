import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SOURCES = [
    ROOT / '.meta_harness/design/spec/capabilities/stream-assembly/v3/examples.md',
    ROOT / '.meta_harness/design/spec/data/arrival-events/v2/examples.md',
]


def normalize(source):
    source = re.sub(
        r'(?<=:)\s*(H[01]M[01])',
        lambda m: json.dumps({'toHuman': m[1][1] == '1', 'toModel': m[1][3] == '1'}),
        source,
    )
    source = re.sub(r'("visibility"\s*:\s*)"(H[01]M[01])"',
        lambda m: m[1] + json.dumps({'toHuman': m[2][1] == '1', 'toModel': m[2][3] == '1'}), source)
    json.loads(source)  # syntax check only; retain original numeric literals
    return source


artifacts = []
for path in SOURCES:
    raw = path.read_text()
    lines = raw.splitlines()
    section = ''
    for index, line in enumerate(lines):
        if line.startswith('## '):
            section = line[3:]
        if re.match(r'\*\*7[a-d] ', line):
            section = re.match(r'\*\*(7[a-d]) ', line)[1]
        for match in re.finditer(r'`(\{[^`]*\})`', line):
            try:
                text = json.dumps(match[1], ensure_ascii=False) if section == '7d' else normalize(match[1])
            except json.JSONDecodeError:
                continue
            row = re.match(r'\| ([0-9]+|—) \|', line)
            artifacts.append({'path': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                              'line': index + 1, 'section': section, 'row': row[1] if row else None,
                              'kind': 'inline', 'representation': 'parameter-text' if section == '7d' else 'json-value', 'source': match[1], 'json': text})
    for match in re.finditer(r'```json\n(.*?)\n```', raw, re.S):
        line_number = raw[:match.start()].count('\n') + 1
        section = ''
        for line in lines[:line_number]:
            if line.startswith('## '):
                section = line[3:]
            if re.match(r'\*\*7[a-d] ', line):
                section = re.match(r'\*\*(7[a-d]) ', line)[1]
        artifacts.append({'path': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                          'line': line_number, 'section': section, 'row': None,
                          'kind': 'json-block', 'representation': 'json-value', 'source': match[1], 'json': normalize(match[1])})

output = ROOT / 'packages/core/stream-assembly/tests/fixtures/source-examples.json'
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(json.dumps({'normalization': 'Bare visibility macro or the visibility member alone expands HxMy. Section 7d parameter texts are JSON strings preserving all raw characters, including duplicate members; other fragments are JSON values. source always keeps the exact document bytes.',
                             'artifacts': artifacts}, ensure_ascii=False, indent=2) + '\n')
print(f'{len(artifacts)} source artifacts extracted to {output.relative_to(ROOT)}')
