#!/usr/bin/env python3
"""Seal actual new runs, source bytes and obligation limits; not acceptance."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

EPOCH = Path(__file__).resolve().parent
TASK = EPOCH.parent
ROOT = TASK.parent.parent
OLD = ROOT / 'tmp/w5-arrival-events-current-v2'
HEAD = '61ef00d20637cd5cbd2828fbc0717ada953dbddd'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (EPOCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


assert subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip() == HEAD
assert not subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain'], text=True).strip()
assert not (EPOCH / 'manifest.json').exists(), 'never overwrite a sealed epoch'
summary = json.loads((EPOCH / 'gate-summary.json').read_text())
assert summary['passed'] and summary['runtime_and_type_tests'] == 673
current = json.loads((EPOCH / 'paired-result.json').read_text())
baseline = json.loads((TASK / 'epoch2-result.json').read_text())
assert current['passed'] and current['epoch'] == 3 and current['case_count'] == 202
assert len(current['definition_probes']) == 14
changes = []
by_origin = {}
for old, new in zip(baseline['cases'], current['cases']):
    assert old['id'] == new['id']
    for key in ['ar', 'wire', 'ar_shape', 'frozen_ar2_shape', 'open_queries', 'strict_decode_failed', 'frozen_cb2_shape', 'raw_arguments_utf8_sha256']:
        assert old.get(key) == new.get(key), new['id'] + ' ' + key
    by_origin[new['origin']] = by_origin.get(new['origin'], 0) + 1
    if old.get('actual_cb_shape') != new.get('actual_cb_shape'):
        assert old['actual_cb_shape'] is False and new['actual_cb_shape'] is True
        changes.append({'id': new['id'], 'old_cb_shape': False, 'new_cb_shape': True,
                        'old_cb_judgment': old['actual_cb'], 'new_cb_judgment': new['actual_cb'],
                        'old_ar': old['ar'], 'new_ar': new['ar']})
assert len(changes) == 26
save('paired-equivalence-summary.json', {'old_head': baseline['source_head'], 'new_head': HEAD,
                                        'case_count': 202, 'all_retained_AR2_outputs_equal': True,
                                        'actual_current_CB_domain_expansion_cases': changes,
                                        'origins': by_origin, 'full_AR2_defs_positive_negative': 14,
                                        'limits': 'Finite concrete paired evidence; not all possible inputs, runtime/producer/Connector or overall acceptance'})

guard_results = []
for id, epoch, supplied, text in [('current-provider-cannot-label-CB2', '2', None, 'actual CB provider epoch mismatch'),
                                  ('requires-actual-merge-HEAD', '3', 'eabfff0f167093f34cfa0582c7e6cf0773761016', HEAD),
                                  ('requires-explicit-HEAD', '3', None, 'epoch3 requires explicit authorized source release HEAD')]:
    output = EPOCH / (id + '-forbidden-output.json')
    assert not output.exists()
    argv = ['node', str(TASK / 'consumer/paired.mjs'), epoch, str(output)]
    if supplied is not None:
        argv.append(supplied)
    run = subprocess.run(argv, cwd=str(ROOT), capture_output=True, text=True)
    (EPOCH / (id + '.log')).write_text(run.stdout + run.stderr)
    assert run.returncode != 0 and text in run.stderr and not output.exists()
    guard_results.append({'id': id, 'argv': argv, 'cwd': str(ROOT), 'exit_code': run.returncode,
                          'expected_failure_observed': True, 'forbidden_result_not_created': True,
                          'log': id + '.log'})
save('mislabel-negative-controls.json', {'source_head': HEAD, 'checks': guard_results,
                                         'prior_old_CB2_mislabel_control': '../epoch3-old-provider-guard.json'})

tests = json.loads((EPOCH / 'vitest.json').read_text())
test_ids = []
for suite in tests['testResults']:
    file = str(Path(suite['name']).relative_to(ROOT))
    for assertion in suite['assertionResults']:
        assert assertion['status'] == 'passed'
        test_ids.append({'file': file, 'id': assertion['fullName'], 'status': assertion['status']})
assert len(test_ids) == len(set((t['file'], t['id']) for t in test_ids)) == 673
old_test_ids = json.loads((OLD / 'test-ids.json').read_text())['tests']
assert set((t['file'], t['id']) for t in old_test_ids) == set((t['file'], t['id']) for t in test_ids)
save('test-ids.json', {'source_head': HEAD, 'total': 673, 'runtime_tests': 670, 'type_tests': 3,
                       'skipped': 0, 'todo': 0, 'same_test_ids_as_original_v2': True, 'tests': test_ids})

frozen = json.loads((ROOT / '.meta_harness/design/registry/frozen.json').read_text())['files']
inputs = json.loads((EPOCH / 'inputs-manifest.json').read_text())
for entry in inputs['snapshots']:
    if 'path' in entry:
        actual = ROOT / entry['path']
        assert sha(actual) == entry['sha256']
        committed = subprocess.check_output(['git', '-C', str(ROOT), 'show', HEAD + ':' + entry['path']])
        assert hashlib.sha256(committed).hexdigest() == entry['sha256']
        relative = str(Path(entry['path']).relative_to('.meta_harness/design'))
        if relative in frozen:
            assert frozen[relative] == entry['sha256']
schema_data = []
for published in current['public_schemas']:
    schema_data.append(published)
save('frozen-resource-check.json', {'source_head': HEAD, 'matched_current_registry_frozen': True,
                                   'AR2_full_schema_sha256': 'bcaac3fc5c9d7a0a223f68722164956507bf978e62bc1423d56cc9c4810b74c5',
                                   'public_resources': schema_data,
                                   'unchanged_fixed_AR2_closure': {'path': '../fixed-v2-def-closure.json', 'sha256': sha(TASK / 'fixed-v2-def-closure.json'), 'roots': 14, 'reachable_defs': 40},
                                   'current_default_CB_schema': 'data.content-blocks v3',
                                   'business_implementation_compatibility_layer_added': False})

members = json.loads((EPOCH / 'build-members.json').read_text())
assert len(members) == 10
source = []
built = []
for member in members:
    base = Path(member['path'])
    assert base.is_relative_to(ROOT) if hasattr(base, 'is_relative_to') else str(base).startswith(str(ROOT) + '/')
    for path in sorted(base.rglob('*')):
        if not path.is_file() or path.is_symlink() or 'node_modules' in path.parts:
            continue
        rel = path.relative_to(base)
        entry = {'path': str(path.relative_to(ROOT)), 'sha256': sha(path), 'bytes': path.stat().st_size}
        if rel.parts[0] == 'dist':
            built.append(entry)
        elif rel.parts[0] in ['src', 'schema', 'tests'] or (len(rel.parts) == 1 and path.suffix in ['.ts', '.json']):
            source.append(entry)
configs = []
for relative in ['package.json', 'pnpm-workspace.yaml', 'pnpm-lock.yaml', 'tsconfig.base.json', '.prettierrc.json', '.prettierignore', 'scripts/format.sh']:
    path = ROOT / relative
    if path.exists():
        configs.append({'path': relative, 'sha256': sha(path), 'bytes': path.stat().st_size})
for path in sorted((ROOT / 'tools/ts-checks/src').rglob('*.ts')):
    configs.append({'path': str(path.relative_to(ROOT)), 'sha256': sha(path), 'bytes': path.stat().st_size})
save('source-config-built-hashes.json', {'source_head': HEAD, 'dependency_member_count': 10,
                                       'maintained_source_schema_tests': source, 'built': built, 'root_and_checker_configs': configs,
                                       'AR2_source_delta_only': 'src/schema.ts two exact v2 resource imports; see arrival-source-delta.patch',
                                       'local_edits_after_merge': [], 'dependency_default_CB': 3})

tool_argv = ['node', '--input-type=module', '-e',
             "import {createRequire} from 'node:module';const r=createRequire(process.cwd()+'/packages/core/arrival-events/package.json');const root=createRequire(process.cwd()+'/package.json');console.log(JSON.stringify({node:process.version,typescript:r('typescript/package.json').version,vitest:r('vitest/package.json').version,ajv:createRequire(process.cwd()+'/packages/core/content-blocks/package.json')('ajv/package.json').version,prettier:root('prettier/package.json').version},null,2))"]
tools = subprocess.run(tool_argv, cwd=str(ROOT), capture_output=True, text=True)
(EPOCH / 'toolchain.log').write_text(tools.stdout + tools.stderr)
assert tools.returncode == 0
save('toolchain.json', {'argv': tool_argv, 'cwd': str(ROOT), 'exit_code': tools.returncode, 'versions': json.loads(tools.stdout)})

matrix = json.loads((EPOCH / 'inputs/dispatch/acceptance-matrix.json').read_text())
obligations = [o for o in matrix['obligations'] if o['node'] == 'arrival-events']
assert len(obligations) == 15
evidence = {
    'arrival-events.envelopes-refusals': ['vitest.json', 'test-ids.json', 'paired-result.json', 'paired-equivalence-summary.json'],
    'arrival-events.reduce-payloads': ['vitest.json', 'test-ids.json', 'runtime-consumer.json'],
    'arrival-events.public-package-consumer': ['paired-result.json', 'runtime-consumer.json', 'positive-types-r2.log', 'negative-types.json'],
    'arrival-events.source-purity': ['static-scan.json', 'source-config-built-hashes.json', 'arrival-source-delta.patch'],
    'arrival-events.schema-frozen-bytes': ['frozen-resource-check.json', 'paired-result.json', 'inputs-manifest.json'],
    'arrival-events.walkthrough-cs-3-core-step': ['runtime-consumer.json', 'test-ids.json', 'paired-result.json'],
    'arrival-events.walkthrough-cs-4-core-step': ['runtime-consumer.json', 'paired-result.json', 'negative-types.json'],
}
rows = []
for obligation in obligations:
    local = obligation['stage'] == 'core-local'
    if local:
        assert obligation['id'] in evidence
    rows.append({'id': obligation['id'], 'stage': obligation['stage'], 'owner': obligation['owner'],
                 'current_source': obligation.get('current_source', obligation['source']),
                 'input_coordinate': obligation['input_coordinate'],
                 'actual_new_epoch_check': 'passed for assigned pure-value scope; root acceptance pending' if local else 'not performed or claimed by this AR2 packet',
                 'evidence': evidence.get(obligation['id'], []),
                 'linked_obligation_ids': obligation.get('linked_obligation_ids', obligation.get('linked_core_obligation_ids', [])),
                 'limits': 'producer/runtime/log/tenant/transport/Connector facts are not supplied by fixtures or by core-only consumer',
                 'technical_acceptance': None})
save('obligations-coverage.json', {'source_head': HEAD, 'input_coordinate': 'data.arrival-events v2',
                                  'local_checked_not_accepted': 7, 'composition_not_claimed': 3, 'external_not_claimed': 5,
                                  'obligations': rows, 'acceptance_owner': '/root', 'user_overall_acceptance': 'pending'})

commands = json.loads((EPOCH / 'commands.json').read_text())
red = [c for c in commands if not c['passed']]
assert [c['id'] for c in red] == ['tsc-version', 'positive-types']
save('preparation-issues.json', {'resolved_verification_environment_issues': [
    {'failed_command': 'tsc-version', 'exit': 254, 'cause': 'root only declares prettier; TS bin resides in package member',
     'fix': 'use pnpm --filter arrival-events exec tsc/vitest for tool version probes', 'successful_rerun': 'tsc-version-current'},
    {'failed_command': 'positive-types', 'exit': 2, 'diagnostic': 'TS2688 missing node type definition',
     'cause': 'standalone new ignored consumer initially had no @types/node link',
     'fix': 'only new consumer environment links actual member @types/node; no product change', 'successful_rerun': 'positive-types-r2'},
], 'raw_red_and_green_logs_retained': True, 'source_schema_tests_not_repaired_or_relaxed': True})
for path in [OLD / 'manifest.json', TASK / 'preparation-manifest.json']:
    assert path.exists()
old_sha = sha(OLD / 'manifest.json')
prep_sha = sha(TASK / 'preparation-manifest.json')
assert old_sha == 'b8b8096effb9b216e4d606743934eae4b280902bfb47444ddcdcabcd4ff9d268'
assert prep_sha == '2b4e384a751fabe6fcd7db15e00fd9fc3a65b2a7dc0a85d2843ca361a2afb9ca'
save('final-position.json', {'source_head': HEAD, 'branch': 'panqiwei/core-delivery-arrival-events',
                             'worktree': str(ROOT), 'tracked_status': '',
                             'root_release_ancestor': 'eabfff0f167093f34cfa0582c7e6cf0773761016',
                             'old_198_seal_sha256': old_sha, 'old_54_preparation_seal_sha256': prep_sha,
                             'accepted_input': 'data.arrival-events v2 with actual default CB3, exact CB2/Loop2 Schema/v2',
                             'acceptance_owner': '/root', 'self_accepted': False})
artifacts = []
for path in sorted(EPOCH.rglob('*')):
    if path.is_file() and not path.is_symlink() and 'node_modules' not in path.parts and path.name not in ['manifest.json', 'manifest.sha256', 'manifest-check.log']:
        artifacts.append({'path': str(path.relative_to(EPOCH)), 'sha256': sha(path), 'bytes': path.stat().st_size})
save('manifest.json', {'format': 1, 'kind': 'actual-CB3-retained-AR2-finite-paired-and-regression-verification',
                       'created_utc': datetime.datetime.utcnow().isoformat() + 'Z', 'source_head': HEAD,
                       'root_release': 'eabfff0f167093f34cfa0582c7e6cf0773761016', 'input_coordinate': 'data.arrival-events v2',
                       'current_CB_business': 'data.content-blocks v3', 'artifacts': artifacts,
                       'preserved_old_seals': {'v2_198': old_sha, 'preparation_54': prep_sha},
                       'referenced_preparation_inputs': {'consumer': {'path': '../consumer/paired.mjs', 'sha256': sha(TASK / 'consumer/paired.mjs')},
                                                         'paired_cases': {'path': '../paired-cases.json', 'sha256': sha(TASK / 'paired-cases.json')},
                                                         'baseline': {'path': '../epoch2-result.json', 'sha256': sha(TASK / 'epoch2-result.json')}},
                       'technical_acceptance': None, 'acceptance_owner': '/root', 'user_overall': 'pending',
                       'limits': 'AR2 own pure-value scope only; six-data pilot does not prove all data, external producers/runtime/Connector or overall delivery'})
(EPOCH / 'manifest.sha256').write_text(sha(EPOCH / 'manifest.json') + '  manifest.json\n')
print(json.dumps({'passed': True, 'source_head': HEAD, 'artifacts': len(artifacts), 'manifest_sha256': sha(EPOCH / 'manifest.json'),
                  'actual_paired': 202, 'actual_CB_domain_expansion_cases': 26, 'actual_regression': 673,
                  'local_checked': 7, 'composition_not_claimed': 3, 'external_not_claimed': 5}, indent=2))
