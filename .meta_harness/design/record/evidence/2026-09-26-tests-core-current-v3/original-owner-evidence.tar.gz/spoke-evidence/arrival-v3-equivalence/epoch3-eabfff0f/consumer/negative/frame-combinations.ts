import type { FailureCause } from '@omne-harness-lite/loop-extension'
declare const knownCause: FailureCause
import type {ArrivalEnvelope} from '@omne-harness-lite/arrival-events'
import type {CallId,BlockId} from '@omne-harness-lite/content-blocks'
declare const callId:CallId
declare const id:BlockId
const a:ArrivalEnvelope={target:{kind:'tool_execution',callId},event:{t:'finish',reason:'max_tokens'}}
const b:ArrivalEnvelope={target:{kind:'tool_execution',callId},event:{t:'finish',reason:'lost',error:{cause:knownCause}}}
const c:ArrivalEnvelope={target:{kind:'tool_execution',callId},event:{t:'open',kind:'text',fill:'append',id,index:0,visibility:{toHuman:true,toModel:true}}}
void [a,b,c]
