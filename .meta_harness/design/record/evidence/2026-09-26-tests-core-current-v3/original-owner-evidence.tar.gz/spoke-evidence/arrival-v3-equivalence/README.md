# AR2 拒绝等同性准备

本目录只存本轮临时取证与可重跑消费者，权威规则仍是已接受的 D-068、CB2／CB3、AR2 契约及当前 realization。2026-09-26 的实际旧实现输入为本 spoke `dc6b0556cbbd7b8e127e137c00951867d14d226b`。采用输入从 HUB `e092c87c5d871b7fd3c1f7256292bcbc6c37df34` 逐文件保存，并与该 Git 对象的原始字节核对；D-068 接受提交 `3fab9200`，八提供者采用提交 `f8c76d60`。

实际旧提供者的公开 built 包消费者已通过 202 个固定输入，AR2 的 14 个定义各有正例及三种反例；完整冻结 AR2／CB2／CA2／Loop2 的本节点可达闭包为 40 个定义节点。此闭包只覆盖 AR2 全部定义及其传递引用，不声称编译了 Loop2 等提供者的全部其它定义。原始 Schema `$id` 与完整字节均保留，AR2 Schema SHA256 为 `bcaac3fc5c9d7a0a223f68722164956507bf978e62bc1423d56cc9c4810b74c5`。

**真实 CB3＋保留 AR2 的结果待主调度释放准确 source 后执行。** `epoch2-result.json` 是真实旧实现结果，不是 CB3 结果；消费者强制核验当前 CB 默认 Schema 坐标、公开完整旧 `schema/v2` 的原字节、明确 source HEAD，并在新一轮对照逐个比较 AR2 结果。旧 CB2 被当成新 CB3 调用时必须报 `actual CB provider epoch mismatch`，该负检查只说明防止误标，不能证明新提供者。

`paired-cases.json` 的预期按冻结条款给定，两处禁整交工具调用路径为 `fill.payload`／`close.block`。每处覆盖 arguments 好／坏名、128／129 边界，complete raw 坏名及原始空白／Unicode／重复键字串，incomplete 原文、缺值及互斥形状。每处还覆盖 CB 五个具名谓词的全部 31 组非空组合和 direct visibility／incomplete 分支；帧内联与 fill 的 replace 谓词先于剩余 `malformed`。根事件 `t` 改为 open／trim／finish 后已经不再是 fill／close，相关根拒绝用独立控制例覆盖；不虚构无法同时出现的事件。合法工具原串填、无 block 的封口、原始坏名开块、其它允许整块、帧引用、账和收尾另有正控制。外层解码重复键被严格接收器拒绝，内层 rawArguments 重复键不解析；金额与 token 原始精度不丢。

本轮未修改产品源码、Schema、公开 types 或构建字节。原 v2 封存的 198 份 artifacts、旧 673 个测试记录、22 组 built 消费及 17 个负类型错误均保持字节，不重标新版本；15 项义务依旧区分本地、组合及 external，由 `obligations-disposition.json` 导航。实际等同性是这些具体 paired cases 的可复现证据，不是所有输入的穷尽证明，也不证明生产者、外部 runtime、租户路由、Connector 或总体交付。

在本 spoke 根重跑已执行的旧输入消费者（输出须另命名，保留已封存日志）：

```bash
set -euo pipefail
node tmp/w3-arrival-v3-equivalence/consumer/paired.mjs 2 tmp/w3-arrival-v3-equivalence/replayed-epoch2.json
python3 tmp/w3-arrival-v3-equivalence/verify-manifest.py
```

收到主调度明确 release、获准同步并完成本树 build／673 等原门后，使用真实新 HEAD 重跑同一个消费者；不可预先将任何旧运行改标3：

```bash
set -euo pipefail
node tmp/w3-arrival-v3-equivalence/consumer/paired.mjs 3 tmp/w3-arrival-v3-equivalence/epoch3-result.json "$(git rev-parse HEAD)"
```

技术验收归 `/root`，用户总体接受尚未发生。本目录本轮只准备对照及旧基线，phase-state 的新执行状态保持 pending。旧证据目录 `tmp/w5-arrival-events-current-v2/` 及 `tmp/w5-arrival-events/` 不能被本轮覆盖或清理；当前 spoke 仍保留消费者与唯一 ignored 证据，不可退休。
