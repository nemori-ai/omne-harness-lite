#!/usr/bin/env python3
"""New authorized epoch: all evidence writes are here; old seals are read-only."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time

EPOCH = Path(__file__).resolve().parent
TASK = EPOCH.parent
ROOT = TASK.parent.parent
OLD = ROOT / 'tmp/w5-arrival-events-current-v2'
HUB = ROOT.parent / 'core-delivery'
HEAD = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
assert HEAD == '61ef00d20637cd5cbd2828fbc0717ada953dbddd'
assert not (EPOCH / 'commands.json').exists(), 'use a new epoch output instead of overwriting runs'
commands = []


def save(name, value):
    (EPOCH / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def run(name, argv, expected=0):
    assert not (EPOCH / (name + '.log')).exists(), name + ' would overwrite a run'
    started = datetime.datetime.utcnow().isoformat() + 'Z'
    start = time.monotonic()
    result = subprocess.run(argv, cwd=str(ROOT), capture_output=True, text=True)
    (EPOCH / (name + '.log')).write_text(result.stdout + result.stderr)
    entry = {'id': name, 'argv': argv, 'cwd': str(ROOT), 'source_head': HEAD, 'started_utc': started,
             'elapsed_seconds': time.monotonic() - start, 'exit_code': result.returncode,
             'expected_exit_code': expected, 'passed': result.returncode == expected,
             'log': name + '.log'}
    commands.append(entry)
    save('commands.json', commands)
    if not entry['passed']:
        raise SystemExit(json.dumps(entry))
    print(json.dumps({'id': name, 'exit': result.returncode, 'elapsed_seconds': round(entry['elapsed_seconds'], 3)}), flush=True)
    return result


# Copy the old standalone consumer fixtures, preserving old exact source/logs.
consumer = EPOCH / 'consumer'
consumer.mkdir(exist_ok=False)
for path in (OLD / 'consumer').rglob('*'):
    if path.is_file() and 'node_modules' not in path.parts and path.suffix in ['.ts', '.json']:
        target = consumer / path.relative_to(OLD / 'consumer')
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(str(path), str(target))
config = json.loads((consumer / 'tsconfig.json').read_text())
config['extends'] = '../../../../tsconfig.base.json'
(consumer / 'tsconfig.json').write_text(json.dumps(config, indent=2) + '\n')
shutil.copyfile(str(OLD / 'consumer/runtime.mjs'), str(consumer / 'runtime.mjs'))
links = consumer / 'node_modules/@omne-harness-lite'
links.mkdir(parents=True)
for topic in ['arrival-events', 'content-blocks', 'call-accounts', 'loop-extension', 'identity-values']:
    (links / topic).symlink_to(ROOT / 'packages/core' / topic, target_is_directory=True)
shutil.copyfile(str(OLD / 'static-scan.mjs'), str(EPOCH / 'static-scan.mjs'))
# The current shared scanner entry changed ownership at merge; use the actual
# current public developer entry at this precise path, never the old snapshot.
static = (EPOCH / 'static-scan.mjs').read_text().replace("'../../tools/ts-checks/src/index.ts'", "'../../../tools/ts-checks/src/index.ts'")
(EPOCH / 'static-scan.mjs').write_text(static)

snapshots = []
design_paths = [
    'registry/catalog.json', 'registry/frozen.json',
    'record/decisions/core-implementation-spec-reconciliation/decision.md',
    'record/decisions/core-implementation-spec-reconciliation/acceptance.json',
    'realization/packages/core/arrival-events/README.md', 'realization/packages/core/arrival-events/design.md',
    'realization/packages/core/arrival-events/verification.md', 'realization/packages/core/arrival-events/bindings.yaml',
    'spec/data/arrival-events/verification.md',
]
for topic, version in [('arrival-events', 2), ('content-blocks', 2), ('content-blocks', 3),
                       ('call-accounts', 2), ('loop-extension', 2), ('loop-extension', 3)]:
    prefix = 'spec/data/{}/v{}/'.format(topic, version)
    design_paths += [prefix + 'contract.md', prefix + 'examples.md', prefix + topic + '.schema.json']
for relative in design_paths:
    source = ROOT / '.meta_harness/design' / relative
    target = EPOCH / 'inputs/design' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(str(source), str(target))
    snapshots.append({'path': str(source.relative_to(ROOT)), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                      'bytes': target.stat().st_size, 'snapshot': str(target.relative_to(EPOCH))})
for name in ['developer-brief.md', 'implementation-delivery-plan.md', 'acceptance-matrix.json']:
    source = HUB / 'tmp/core-delivery' / name
    target = EPOCH / 'inputs/dispatch' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(str(source), str(target))
    snapshots.append({'source': str(source), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                      'bytes': target.stat().st_size, 'snapshot': str(target.relative_to(EPOCH))})
save('inputs-manifest.json', {'source_head': HEAD, 'released_hub': 'eabfff0f167093f34cfa0582c7e6cf0773761016',
                             'input_coordinate': 'data.arrival-events v2', 'current_cb_business': 'data.content-blocks v3',
                             'snapshots': snapshots})
run('node-version', ['node', '--version'])
run('pnpm-version', ['pnpm', '--version'])
run('tsc-version', ['pnpm', 'exec', 'tsc', '--version'])
run('vitest-version', ['pnpm', 'exec', 'vitest', '--version'])
run('build', ['pnpm', '--filter', '@omne-harness-lite/arrival-events...', 'run', 'build'])
run('typecheck', ['pnpm', '--filter', '@omne-harness-lite/arrival-events', 'run', 'typecheck'])
run('test', ['pnpm', '--filter', '@omne-harness-lite/arrival-events', 'exec', 'vitest', 'run',
             '--reporter=json', '--outputFile=' + str(EPOCH / 'vitest.json')])
tests = json.loads((EPOCH / 'vitest.json').read_text())
assert tests['numTotalTests'] == tests['numPassedTests'] == 673
assert tests['numFailedTests'] == tests['numPendingTests'] == tests.get('numTodoTests', 0) == 0
run('paired-consumer', ['node', str(TASK / 'consumer/paired.mjs'), '3', str(EPOCH / 'paired-result.json'), HEAD])
paired = json.loads((EPOCH / 'paired-result.json').read_text())
assert paired['passed'] and paired['case_count'] == 202 and len(paired['definition_probes']) == 14
runtime = run('public-runtime', ['node', str(consumer / 'runtime.mjs')])
runtime_result = json.loads(runtime.stdout)
assert runtime_result['passed'] and len(runtime_result['checks']) == 22
save('runtime-consumer.json', runtime_result)
tsc = ['node', 'packages/core/arrival-events/node_modules/typescript/bin/tsc', '--project']
run('positive-types', tsc + [str(consumer / 'tsconfig.json')])
groups = []
for name, expected in [('brands', 3), ('mode-and-head', 4), ('event-combinations', 4), ('frame-combinations', 3), ('forbidden-payloads', 3)]:
    result = run('negative-' + name, tsc + [str(consumer / ('tsconfig-negative-' + name + '.json'))], 2)
    errors = [line for line in result.stdout.splitlines() if re.search(r'error TS\d+:', line)]
    assert len(errors) == expected
    assert all('TS2322:' in line for line in errors)
    groups.append({'name': name, 'expected': expected, 'actual': len(errors), 'diagnostics': errors})
save('negative-types.json', groups)
static_result = run('static', ['node', str(EPOCH / 'static-scan.mjs')])
static = json.loads(static_result.stdout)
assert static['passed'] and len(static['rules']) == 27
save('static-scan.json', static)
files = sorted(str(path.relative_to(ROOT)) for path in (ROOT / 'packages/core/arrival-events').rglob('*')
               if path.is_file() and not any(part in path.parts for part in ['schema', 'node_modules', 'dist'])
               and path.suffix in ['.ts', '.json'])
run('format', ['pnpm', 'exec', 'prettier', '--check'] + files)
run('diff-check', ['git', 'diff', '--check'])
run('conflict-markers', ['rg', '-n', r'^(<<<<<<<|=======|>>>>>>>)', 'packages/core/arrival-events'], 1)
run('preserve-old-v2-seal', ['python3', str(OLD / 'verify_manifest.py')])
run('preserve-preparation-seal', ['python3', str(TASK / 'verify-manifest.py')])
save('gate-summary.json', {'passed': True, 'source_head': HEAD, 'runtime_and_type_tests': 673,
                          'paired_cases': 202, 'compiled_probed_ar2_defs': 14, 'public_runtime_checks': 22,
                          'negative_expected_type_errors': 17, 'static_rules': 27, 'formatted_files': len(files),
                          'skipped': 0, 'todo': 0, 'technical_acceptance': None})
print(json.dumps({'passed': True, 'source_head': HEAD, 'test_count': 673, 'paired': 202, 'static_rules': 27}), flush=True)
