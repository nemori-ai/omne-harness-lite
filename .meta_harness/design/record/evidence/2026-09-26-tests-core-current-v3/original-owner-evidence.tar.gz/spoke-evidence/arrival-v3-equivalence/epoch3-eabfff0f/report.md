# AR2 使用真实 CB3 的拒绝等同性与回归

本树从 clean `dc6b0556` 无冲突合入主调度指定的 `eabfff0f167093f34cfa0582c7e6cf0773761016`，实际源码 HEAD 为 `61ef00d20637cd5cbd2828fbc0717ada953dbddd`，分支 `panqiwei/core-delivery-arrival-events`。采用依旧是 `data.arrival-events v2`；当前内容块业务函数采用 CB3，AR2 完整形状资源通过公开 `CB/schema/v2`、`Loop/schema/v2` 使用冻结旧资源。AR 产品相对旧基线仅有共享 owner 已交付的这两处 import 变更；本轮未改产品源码／Schema／维护测试，不新增工具参数解析。

实际检查均通过，技术接受交由 `/root` 独立复验：

| 检查                      | 当前实际结果                                                                |
| ------------------------- | --------------------------------------------------------------------------- |
| 依赖构建                  | 10 个实际成员 build 通过                                                    |
| AR typecheck／完整原测试  | 673／673，670 runtime＋3 类型测试；零 skipped／todo，原测试 ID 集合完全保留 |
| 原公开 built runtime 消费 | 22／22，独立 consumer 使用本树公开 dist 入口                                |
| 严格独立类型消费          | 正向通过，五组共 17 个预期 TS2322；无额外错误                               |
| D-068 成对对照            | 202／202，旧 dc6 真结果与当前真实 CB3＋AR2 逐例相同                         |
| 完整 AR2 定义图           | 14 个定义各有正例及三种反例，完整冻结资源与公开提供者 shape 结果相同        |
| 静态规则／格式            | 当前 27 条规则；19 个 AR 维护源码与配置格式通过                             |
| 封存保留                  | 原 v2 198 artifacts、准备阶段 54 artifacts 均保持原字节                     |

成对输入来自已接受的 AR2、CB2／CB3 及 D-068。两个禁整交入口分别是 `fill.payload`、`close.block`，涵盖 normal arguments 好／坏工具名、128／129、complete raw 坏名、原串空白与 Unicode、raw 内的重复键字串、incomplete 分支、原始缺席与互斥形状。每个入口还跑过五个 CB 具名拒绝谓词的全部 31 组非空组合，以及直接缺标注和半截可见分支。帧内联、fill replacement 谓词先于剩余 malformed；根事件拒绝另有控制例，避免虚构同一个 t 同时为不同事件。

实际有 **26 个输入**在旧 CB2 `shape:false`、当前 CB3 `shape:true`，同时当前 CB 判定进入 `{ ok }`；AR2 在这 26 个输入上仍返回与旧实现相同的具名结果。普通禁整块路径仍是 `malformed`，带开块前提的 fill 可先得到 `replace_payload_shape`，各更早具名拒绝保持原次序。其余所有 202 对照的 AR value／strict-wire／shape／当前开块查询／raw UTF-8 哈希也全部相同。外层解码重复键仍拒绝；rawArguments 字串的重复键不被解析。允许事件、帧引用、无 block 的工具调用封口及精确数账的正控制没有误拒。

公开原始完整 AR2／CB2／CA2／Loop2 Schema 字节与 `$id` 均核对冻结来源，AR2 SHA256 为 `bcaac3fc5c9d7a0a223f68722164956507bf978e62bc1423d56cc9c4810b74c5`。AR2 的 14 根／40 可达定义闭包保持原数据；这里不声称编译了 Loop 等依赖资源的其它全部定义。当前默认 CB3 完整资源另与 frozen3 核对。新消费者的误标负控实际拒绝当前提供者被标成 CB2、错误 HEAD、缺席显式 HEAD，并没有输出被伪称通过的结果；原 CB2 被标成 CB3 的旧负控仍完整保留。

两次验证环境错误保留原始红日志：根 `pnpm exec tsc` 找不到成员工具，改为明确的成员 exec；新独立 consumer 最初缺 `@types/node` 链接，导致 TS2688，仅补新临时 consumer 的环境链接后，正向与 17 个严格负向诊断通过。未改源码或放宽预期来迁就错误；命令、退出码及成功重跑见 `commands.json`、`preparation-issues.json`。

`obligations-coverage.json` 逐 15 项保持范围：7 项本地实际检查通过但未自行接受，3 项 core composition 交 W6／root，5 项 external 未执行。此次有限具体输入对照不是全输入穷尽证明，不证明真实生产者不解析、封口块等于送达归约、节流、序列／租户路由／持久日志／每一跳、Connector 或系统总体交付；六数据试点也不代替所有 data 包验收。当前 self acceptance 与技术签收均为空，用户总体门尚未发生。

复现消费者须处于本次明确源 HEAD，先按原门构建本树依赖；使用已经封存的固定输入和旧实际 baseline，输出另命名，避免覆盖本轮原始结果：

```bash
set -euo pipefail
node tmp/w3-arrival-v3-equivalence/consumer/paired.mjs 3 tmp/w3-arrival-v3-equivalence/epoch3-eabfff0f/replayed-paired.json 61ef00d20637cd5cbd2828fbc0717ada953dbddd
```

`manifest.json`／`manifest.sha256` 封本次全部精确输入、源码／构建字节、工具、运行输出、所有原红与原绿及义务导航。主调度独立复验前，本 spoke 与三轮唯一 ignored 证据继续保留，不退休，不清理。
