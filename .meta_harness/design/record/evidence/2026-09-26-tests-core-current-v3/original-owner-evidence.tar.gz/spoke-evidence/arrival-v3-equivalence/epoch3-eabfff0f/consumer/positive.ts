import { reduceFills, judgeArrivalEnvelope, judgeArrivalEnvelopeText, validate, isStandardBase64, schemaId, SCHEMA_DEF_NAMES } from '@omne-harness-lite/arrival-events'
import type { ArrivalEnvelope, ArrivalTarget, ArrivalEvent, OpenEvent, FillEvent, CloseEvent, TrimEvent, AccountEvent, FinishEvent, BlockKind, FillMode, BlockHead, PresentationHint, FinishReason, OpenBlock, ReductionMode, WholeFillBlock, ArrivalJudgment, ArrivalRejection } from '@omne-harness-lite/arrival-events'
import { LosslessNumber, type JsonNumber } from '@omne-harness-lite/content-blocks'
import { parseOpaqueIdentifier } from '@omne-harness-lite/identity-values'
const parsed = parseOpaqueIdentifier('c', 'CallId')
if ('invalidInput' in parsed) throw new Error('consumer id')
const target:ArrivalTarget={kind:'tool_execution',callId:parsed.ok}
const envelope:ArrivalEnvelope={target,event:{t:'finish',reason:'lost'}}
const mode:ReductionMode={kind:'voice',fill:'append'}
const reduction:string|WholeFillBlock|undefined=reduceFills(mode,['YQ==','Yg=='])
const number:JsonNumber=new LosslessNumber('9007199254740993')
const open:OpenBlock=(index:JsonNumber):OpenEvent|undefined => {void index;return undefined}
const judgment:ArrivalJudgment=judgeArrivalEnvelope(envelope,open)
const rejection:ArrivalRejection='frame_media_inline'
const definitions:readonly string[]=SCHEMA_DEF_NAMES
void [reduction,number,judgment,rejection,definitions,judgeArrivalEnvelopeText,validate,isStandardBase64,schemaId]
type PublicDefinitions=[ArrivalEnvelope,ArrivalTarget,ArrivalEvent,OpenEvent,FillEvent,CloseEvent,TrimEvent,AccountEvent,FinishEvent,BlockKind,FillMode,BlockHead,PresentationHint,FinishReason]
const allDefinitions:PublicDefinitions|undefined=undefined
void allDefinitions
