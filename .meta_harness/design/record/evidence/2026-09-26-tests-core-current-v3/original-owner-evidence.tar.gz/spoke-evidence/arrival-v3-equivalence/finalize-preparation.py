#!/usr/bin/env python3
"""Bind the new preparation evidence; no production writes or acceptance."""
import hashlib
import json
import subprocess
from pathlib import Path

TASK = Path(__file__).resolve().parent
ROOT = TASK.parent.parent
OLD = ROOT / 'tmp/w5-arrival-events-current-v2'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (TASK / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


head = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
status = subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain'], text=True).strip()
assert head == 'dc6b0556cbbd7b8e127e137c00951867d14d226b'
assert not status
inputs = json.loads((TASK / 'baseline-inputs.json').read_text())
correspondence = []
for entry in inputs['snapshots']:
    blob = subprocess.check_output(['git', '-C', str(ROOT), 'show', inputs['hub_read_head'] + ':.meta_harness/design/' + entry['path']])
    actual = hashlib.sha256(blob).hexdigest()
    assert actual == entry['sha256'], entry['path'] + ' not matched to recorded HUB input HEAD'
    correspondence.append({'path': entry['path'], 'sha256': actual, 'matches_committed_hub_bytes': True})
save('input-git-correspondence.json', {'hub_input_head': inputs['hub_read_head'], 'checked': correspondence})

# A public consumer cannot silently label CB2 execution as CB3. This failure is
# intentional guard evidence; it is not an actual execution of the new provider.
guard_output = TASK / 'forbidden-fake-epoch3-result.json'
assert not guard_output.exists()
with (TASK / 'epoch3-old-provider-guard.log').open('w') as log:
    run = subprocess.run(['node', str(TASK / 'consumer/paired.mjs'), '3', str(guard_output), head],
                         stdout=log, stderr=subprocess.STDOUT, cwd=str(ROOT))
assert run.returncode != 0
assert 'actual CB provider epoch mismatch' in (TASK / 'epoch3-old-provider-guard.log').read_text()
assert not guard_output.exists()
save('epoch3-old-provider-guard.json', {'purpose': 'Negative epoch guard: old CB2 must not count as actual CB3 evidence',
                                      'supplied_head_for_guard_only': head, 'returncode': run.returncode,
                                      'expected_failure_observed': True, 'no_epoch3_result_created': True,
                                      'actual_new_provider_status': 'pending explicit source release'})

old_manifest = json.loads((OLD / 'manifest.json').read_text())
for entry in old_manifest['artifacts']:
    assert sha(OLD / entry['path']) == entry['sha256']
assert sha(OLD / 'manifest.json') == json.loads((TASK / 'old-seal-check.json').read_text())['manifest_sha256']
for entry in inputs['source_and_built_files']:
    assert sha(ROOT / entry['path']) == entry['sha256'], entry['path'] + ' changed during preparation'
save('final-position.json', {'worktree': str(ROOT), 'branch': subprocess.check_output(['git', '-C', str(ROOT), 'branch', '--show-current'], text=True).strip(),
                             'head': head, 'tracked_status': status, 'product_and_built_files_unchanged': len(inputs['source_and_built_files']),
                             'old_current_v2_artifacts_unchanged': len(old_manifest['artifacts']),
                             'old_manifest_sha256': sha(OLD / 'manifest.json')})
old_coverage = json.loads((OLD / 'obligations-coverage.json').read_text())
case_doc = json.loads((TASK / 'paired-cases.json').read_text())
new_result = json.loads((TASK / 'epoch2-result.json').read_text())
assert new_result['passed'] and new_result['case_count'] == case_doc['case_count'] == 202
save('obligations-disposition.json', {'source': str((OLD / 'obligations-coverage.json').relative_to(ROOT)),
                                     'source_sha256': sha(OLD / 'obligations-coverage.json'),
                                     'scope': 'D068 additional finite retained-AR2 equivalence preparation; no old obligation status advanced',
                                     'obligations': [{'id': o['id'], 'stage': o['stage'],
                                                      'old_evidence': 'retained byte-identically; not relabeled as CB3 execution',
                                                      'new_epoch_status': 'pending actual source release; parent owns required rerun and technical acceptance'}
                                                     for o in old_coverage['obligations']]})
save('phase-state.json', {'task': 'AR2 rejection equivalence preparation under D068', 'schema_coordinate': 'data.arrival-events v2',
                         'actual_old_source': head, 'actual_baseline_case_count': 202,
                         'definition_roots_positive_negative_probed': 14,
                         'new_source': None, 'actual_cb3_comparison': 'pending root explicit source release and authorized merge',
                         'final_673_rerun': 'not run in this preparation; old v2 actual result preserved only',
                         'acceptance': {'technical_owner': '/root', 'user_overall': 'pending', 'self_accepted': False}})
artifacts = []
for path in sorted(TASK.rglob('*')):
    if path.is_file() and not path.is_symlink() and 'node_modules' not in path.parts and path.name not in ['preparation-manifest.json', 'preparation-manifest.sha256', 'manifest-check.log']:
        artifacts.append({'path': str(path.relative_to(TASK)), 'sha256': sha(path), 'bytes': path.stat().st_size})
save('preparation-manifest.json', {'format': 1, 'kind': 'finite-paired-equivalence-preparation-only',
                                  'old_source_head': head, 'new_provider_execution': 'pending',
                                  'artifacts': artifacts,
                                  'preserved_old_manifest': {'path': str((OLD / 'manifest.json').relative_to(ROOT)), 'sha256': sha(OLD / 'manifest.json')},
                                  'consumer_symlinks': {p.name: str(p.resolve()) for p in (TASK / 'consumer/node_modules/@omne-harness-lite').iterdir()},
                                  'technical_acceptance_owner': '/root', 'accepted': False})
(TASK / 'preparation-manifest.sha256').write_text(sha(TASK / 'preparation-manifest.json') + '  preparation-manifest.json\n')
print(json.dumps({'new_preparation_artifacts': len(artifacts), 'new_preparation_manifest_sha256': sha(TASK / 'preparation-manifest.json'),
                  'actual_baseline_cases': 202, 'old_v2_artifacts_unchanged': 198, 'new_epoch': 'pending'}, indent=2))
