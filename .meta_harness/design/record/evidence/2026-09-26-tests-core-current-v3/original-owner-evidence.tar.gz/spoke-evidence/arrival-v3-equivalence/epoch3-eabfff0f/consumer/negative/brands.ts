import type { BlockId,CallId } from '@omne-harness-lite/content-blocks'
import type {ArrivalTarget,OpenEvent} from '@omne-harness-lite/arrival-events'
declare const callId:CallId
const a:BlockId=callId
const target:ArrivalTarget={kind:'tool_execution',callId:'raw'}
const opened:OpenEvent={t:'open',index:0,id:callId,visibility:{toHuman:true,toModel:true},kind:'text',fill:'append'}
void [a,target,opened]
