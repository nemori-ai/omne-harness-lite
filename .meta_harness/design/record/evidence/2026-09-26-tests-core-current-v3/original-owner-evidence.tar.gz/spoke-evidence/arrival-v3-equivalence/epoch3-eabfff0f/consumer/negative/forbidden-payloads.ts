import type {FillEvent,CloseEvent,ArrivalTarget} from '@omne-harness-lite/arrival-events'
import type {BlockId,CallId} from '@omne-harness-lite/content-blocks'
declare const id:BlockId
declare const callId:CallId
const a:FillEvent={t:'fill',index:0,payload:{kind:'text',id,visibility:{toHuman:true,toModel:true},text:'x'}}
const b:CloseEvent={t:'close',index:0,block:{kind:'tool_call',id,visibility:{toHuman:true,toModel:true},complete:true,callId,tool:'x',arguments:{}}}
const c:ArrivalTarget={kind:'model_call',callId:'m',dispatch:'1'}
void [a,b,c]
