import fs from 'node:fs'
import assert from 'node:assert/strict'
import {collectSources,runRules,RULES,CORE_PURE_DEPENDENCIES,corePureImports} from '../../../tools/ts-checks/src/index.ts'
const files=collectSources('packages').filter(v=>v.path.startsWith('core/arrival-events/'))
const violations=runRules(files)
const forbidden=[
 `import '@deepseek-ai/cordis'`,
 `import type { Context } from '@deepseek-ai/cordis'`,
 `export * from '@omne-harness-lite/storage'`,
 `export { x } from '@omne-harness-lite/content-blocks/src/index'`,
 `const x = require('node:fs')`,
 `const x = import('node:fs')`,
 `const x = import('\\u006eode:fs')`,
 `import '\\u0040deepseek-ai/cordis'`,
 `import x = require('@omne-harness-lite/kernel-basis')`,
 `const p = 'node:fs'; import(p)`,
 `export type { X } from '@omne-harness-lite/infra-stub'`,
 `import { x } from '@omne-harness-lite/asset-model'`,
 `import '../../content-blocks/src/index.ts'`,
 `import { x } from '@omne-harness-lite/content-blocks/schema-runtime/private'`,
]
const positives=[`import {Buffer} from 'node:buffer'`,`import {createSchemaRuntime} from '@omne-harness-lite/content-blocks/schema-runtime'`,`import schema from '@omne-harness-lite/arrival-events/schema' with {type:'json'}`,`import {validate} from './schema.ts'`,`import type { FailureCause } from '@omne-harness-lite/loop-extension'`]
const negativeProbes=forbidden.map((text,index)=>({index,text,violations:corePureImports.check([{path:'core/arrival-events/src/probe.ts',text}])}))
const positiveProbes=positives.map((text,index)=>({index,text,violations:corePureImports.check([{path:'core/arrival-events/src/probe.ts',text}])}))
const pkg=JSON.parse(fs.readFileSync('packages/core/arrival-events/package.json','utf8'))
const allowed=[...CORE_PURE_DEPENDENCIES['arrival-events']].map(s=>'@omne-harness-lite/'+s).sort()
const declared=Object.keys(pkg.dependencies).sort()
const rejectsForeignDependency=(dependency)=>!allowed.includes(dependency)
const packageJson={path:'packages/core/arrival-events/package.json',allowed,declared,passed:JSON.stringify(allowed)===JSON.stringify(declared),foreignProbes:['@deepseek-ai/cordis','@omne-harness-lite/storage','@omne-harness-lite/asset-model','undici'].map(dependency=>({dependency,rejected:rejectsForeignDependency(dependency)}))}
const result={passed:violations.length===0&&packageJson.passed&&negativeProbes.every(p=>p.violations.length===1)&&positiveProbes.every(p=>p.violations.length===0),rules:RULES.map(r=>({id:r.id,source:r.source})),paths:files.map(f=>f.path),violations,negativeProbes,positiveProbes,packageJson,purityInspection:{productFiles:files.filter(f=>f.path.includes('/src/')).map(f=>f.path),method:'inspect fixed-schema compilation, explicit openBlock callback, local scratch arrays, Node Buffer only; no wall clock/IO/runtime state',limit:'import/structure rules do not prove real producer, routing, persistence or every hop'}}
console.log(JSON.stringify(result,null,2));assert.equal(result.passed,true)
