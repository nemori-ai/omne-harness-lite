import type { FailureCause } from '@omne-harness-lite/loop-extension'
declare const knownCause: FailureCause
import type {ArrivalError,FinishEvent,TrimEvent} from '@omne-harness-lite/arrival-events'
const a:ArrivalError={cause:knownCause,inBand:true}
const b:FinishEvent={t:'finish',reason:'end',error:{cause:knownCause}}
const c:TrimEvent={t:'trim',reason:'rate_merged',omittedBytes:1}
const d:TrimEvent={t:'trim',reason:'quota_exhausted',omittedBytes:1,merged:1}
void [a,b,c,d]
