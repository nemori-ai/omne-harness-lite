#!/usr/bin/env python3
"""Capture read-only adopted inputs and verify previous evidence without rewriting it."""
import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path
from urllib.parse import urljoin, urldefrag

TASK = Path(__file__).resolve().parent
ROOT = TASK.parent.parent
HUB = ROOT.parent / 'core-delivery'
OLD = ROOT / 'tmp/w5-arrival-events-current-v2'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root)] + list(args), text=True).strip()


def save(name, value):
    (TASK / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


assert git(ROOT, 'branch', '--show-current') == 'panqiwei/core-delivery-arrival-events'
assert not git(ROOT, 'status', '--porcelain'), 'tracked worktree must be clean'
manifest = json.loads((OLD / 'manifest.json').read_text())
old_checks = []
for entry in manifest['artifacts']:
    path = OLD / entry['path']
    actual = digest(path)
    assert actual == entry['sha256'], entry['path']
    old_checks.append({'path': str(path.relative_to(ROOT)), 'sha256': actual, 'bytes': path.stat().st_size})
assert len(old_checks) == 198
save('old-seal-check.json', {'manifest': str((OLD / 'manifest.json').relative_to(ROOT)),
                           'manifest_sha256': digest(OLD / 'manifest.json'),
                           'unchanged': True, 'artifacts': old_checks})

design = HUB / '.meta_harness/design'
frozen = json.loads((design / 'registry/frozen.json').read_text())['files']
resources = {}
snapshots = []
paths = [
    'registry/frozen.json', 'registry/catalog.json',
    'record/decisions/core-implementation-spec-reconciliation/decision.md',
    'record/decisions/core-implementation-spec-reconciliation/acceptance.json',
    'realization/packages/core/arrival-events/README.md',
    'realization/packages/core/arrival-events/design.md',
    'realization/packages/core/arrival-events/verification.md',
    'realization/packages/core/arrival-events/bindings.yaml',
    'realization/packages/core/content-blocks/design.md',
    'spec/data/arrival-events/verification.md',
]
for topic, version in [('arrival-events', 2), ('content-blocks', 2),
                       ('call-accounts', 2), ('loop-extension', 2), ('content-blocks', 3)]:
    base = 'spec/data/{}/v{}/'.format(topic, version)
    paths += [base + 'contract.md', base + topic + '.schema.json', base + 'examples.md']
for rel in paths:
    source = design / rel
    target = TASK / 'inputs' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(str(source), str(target))
    sha = digest(target)
    if rel in frozen:
        assert frozen[rel] == sha, 'frozen mismatch ' + rel
    snapshots.append({'path': rel, 'source': str(source), 'sha256': sha,
                      'bytes': target.stat().st_size, 'registered_frozen': rel in frozen})
    if rel.endswith('.schema.json') and '/v2/' in rel:
        schema = json.loads(target.read_text())
        resources[schema['$id']] = schema
        own = ROOT / '.meta_harness/design' / rel
        assert digest(own) == sha, 'original v2 input changed ' + rel
        package = ROOT / 'packages/core' / rel.split('/')[2] / 'schema' / Path(rel).name
        assert digest(package) == sha, 'original v2 public schema changed ' + rel

# Follow only refs reachable from all 14 AR2 defs. Other Loop2 defs are not claimed.
ar = next(schema for schema in resources.values() if '/arrival-events/' in schema['$id'])
nodes = {}
edges = set()


def pointer(document, fragment):
    value = document
    for part in fragment[1:].split('/') if fragment else []:
        value = value[part.replace('~1', '/').replace('~0', '~')]
    return value


def walk(value, base, owner):
    if isinstance(value, dict):
        if '$id' in value:
            base = urljoin(base, value['$id'])
        if '$ref' in value:
            ref = urljoin(base, value['$ref'])
            uri, fragment = urldefrag(ref)
            assert uri in resources, 'missing fixed resource ' + ref
            edges.add((owner, ref))
            visit(ref, pointer(resources[uri], fragment), uri)
        for key, child in value.items():
            if key != '$defs':
                walk(child, base, owner)
    elif isinstance(value, list):
        for child in value:
            walk(child, base, owner)


def visit(ref, value, base):
    if ref in nodes:
        return
    nodes[ref] = hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    walk(value, base, ref)


for name, value in ar['$defs'].items():
    visit(ar['$id'] + '#/$defs/' + name, value, ar['$id'])
assert len(ar['$defs']) == 14
save('fixed-v2-def-closure.json', {'scope': 'Only all 14 AR2 definitions and their transitive refs; not all definitions of dependency resources',
                                 'root_id': ar['$id'], 'roots': sorted(ar['$defs']),
                                 'resources': sorted(resources),
                                 'nodes': [{'ref': ref, 'canonical_subtree_sha256': sha} for ref, sha in sorted(nodes.items())],
                                 'edges': [{'from': source, 'to': target} for source, target in sorted(edges)]})

packages = ['arrival-events', 'content-blocks', 'call-accounts', 'loop-extension', 'identity-values']
owned = []
for topic in packages:
    package = ROOT / 'packages/core' / topic
    for path in sorted(package.rglob('*')):
        relative = path.relative_to(package)
        if path.is_file() and (relative.parts[0] in ['src', 'schema', 'dist'] or str(relative) in ['package.json', 'tsconfig.build.json', 'tsconfig.test.json', 'vitest.config.ts']):
            owned.append({'path': str(path.relative_to(ROOT)), 'sha256': digest(path), 'bytes': path.stat().st_size})
link_root = TASK / 'consumer/node_modules/@omne-harness-lite'
link_root.mkdir(parents=True, exist_ok=True)
for topic in packages:
    link = link_root / topic
    destination = ROOT / 'packages/core' / topic
    if not link.exists():
        os.symlink(str(destination), str(link))
    assert link.resolve() == destination

save('baseline-inputs.json', {'worktree': str(ROOT), 'branch': git(ROOT, 'branch', '--show-current'),
                             'head': git(ROOT, 'rev-parse', 'HEAD'), 'hub_read_head': git(HUB, 'rev-parse', 'HEAD'),
                             'accepted_spec_commit': '3fab9200', 'provider_adoption_commit': 'f8c76d60',
                             'node': subprocess.check_output(['node', '--version'], text=True).strip(),
                             'snapshots': snapshots, 'source_and_built_files': owned,
                             'pending': 'Real CB3 + retained AR2 source release and authorized synchronization not supplied yet; no actual epoch3 result claimed'})
print(json.dumps({'old_artifacts_unchanged': len(old_checks), 'snapshots': len(snapshots),
                  'ar_roots': len(ar['$defs']), 'reachable_nodes': len(nodes),
                  'source_and_built_files': len(owned), 'epoch3': 'pending'}, indent=2))
