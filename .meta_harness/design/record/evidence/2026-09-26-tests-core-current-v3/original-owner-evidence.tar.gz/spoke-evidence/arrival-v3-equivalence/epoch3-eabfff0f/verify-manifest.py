#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

epoch = Path(__file__).resolve().parent
manifest = epoch / 'manifest.json'
expected = (epoch / 'manifest.sha256').read_text().split()[0]
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == expected
value = json.loads(manifest.read_text())
for entry in value['artifacts']:
    path = epoch / entry['path']
    assert path.stat().st_size == entry['bytes'], entry['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256'], entry['path']
for name, entry in value['referenced_preparation_inputs'].items():
    assert hashlib.sha256((epoch / entry['path']).read_bytes()).hexdigest() == entry['sha256'], name
print(json.dumps({'passed': True, 'artifacts_checked': len(value['artifacts']), 'source_head': value['source_head'],
                  'manifest_sha256': expected, 'acceptance': 'root pending'}, indent=2))
