import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import * as ar from '@omne-harness-lite/arrival-events'
import * as cb from '@omne-harness-lite/content-blocks'
import { createSchemaRuntime } from '@omne-harness-lite/content-blocks/schema-runtime'
import arSchema from '@omne-harness-lite/arrival-events/schema' with { type: 'json' }
import cbSchema from '@omne-harness-lite/content-blocks/schema' with { type: 'json' }

const task = new URL('../', import.meta.url)
const root = fileURLToPath(new URL('../../', task))
const epoch = process.argv[2]
const output = process.argv[3]
assert(
  ['2', '3'].includes(epoch),
  'usage: node paired.mjs 2|3 <output.json> [explicit-source-head]',
)
assert(output !== undefined)
const currentHead = execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], {
  encoding: 'utf8',
}).trim()
const sourceHead = process.argv[4]
if (epoch === '3') {
  assert(sourceHead !== undefined, 'epoch3 requires explicit authorized source release HEAD')
  assert.equal(currentHead, sourceHead)
}
const caseDocument = JSON.parse(
  readFileSync(new URL('../paired-cases.json', import.meta.url), 'utf8'),
)
const cases = caseDocument.cases
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const inputs = JSON.parse(readFileSync(new URL('../baseline-inputs.json', import.meta.url), 'utf8'))
for (const relative of [
  'packages/core/arrival-events/src/types.ts',
  'packages/core/arrival-events/src/index.ts',
  'packages/core/arrival-events/dist/types.d.ts',
  'packages/core/arrival-events/dist/index.d.ts',
]) {
  const old = inputs.source_and_built_files.find(entry => entry.path === relative)
  assert(old !== undefined)
  assert.equal(
    sha(readFileSync(new URL(relative, new URL('../../', task)))),
    old.sha256,
    relative + ' retained AR2 public types must remain byte-identical',
  )
}
const snapshot = relative => readFileSync(new URL('inputs/' + relative, task))
const readStrict = bytes => {
  const read = cb.readJsonStrict(bytes.toString())
  assert('ok' in read, 'strict JSON fixture failed')
  return read.ok
}
const schemaFiles = [
  'spec/data/content-blocks/v2/content-blocks.schema.json',
  'spec/data/call-accounts/v2/call-accounts.schema.json',
  'spec/data/loop-extension/v2/loop-extension.schema.json',
  'spec/data/arrival-events/v2/arrival-events.schema.json',
]
const oldResources = schemaFiles.map(relative => readStrict(snapshot(relative)))
const oldRuntime = createSchemaRuntime(oldResources)
const oldCB = oldResources[0]
const oldAR = oldResources[3]
const cb2Validator = oldRuntime.compile({ $ref: oldCB.$id + '#/$defs/ContentBlock' })
const ar2Validators = Object.fromEntries(
  Object.keys(oldAR.$defs).map(name => [
    name,
    oldRuntime.compile({ $ref: oldAR.$id + '#/$defs/' + name }),
  ]),
)
assert.equal(Object.keys(ar2Validators).length, 14)
assert.deepEqual([...ar.SCHEMA_DEF_NAMES].sort(), Object.keys(ar2Validators).sort())
assert.deepEqual(
  Object.keys(ar).sort(),
  [
    'SCHEMA_DEF_NAMES',
    'isStandardBase64',
    'judgeArrivalEnvelope',
    'judgeArrivalEnvelopeText',
    'reduceFills',
    'schemaId',
    'validate',
  ].sort(),
)
assert.equal(ar.schemaId, oldAR.$id)
assert.equal(arSchema.$id, oldAR.$id)
assert(
  cbSchema.$id.endsWith('/content-blocks/v' + epoch + '/content-blocks.schema.json'),
  'actual CB provider epoch mismatch',
)
assert.equal(cb.schemaId, cbSchema.$id)
const publishedSchemas = []
for (const [index, topic] of [
  'content-blocks',
  'call-accounts',
  'loop-extension',
  'arrival-events',
].entries()) {
  const suffix =
    epoch === '3' && ['content-blocks', 'loop-extension'].includes(topic) ? '/schema/v2' : '/schema'
  const exported = '@omne-harness-lite/' + topic + suffix
  const actual = readFileSync(fileURLToPath(import.meta.resolve(exported)))
  assert.deepEqual(
    actual,
    snapshot(schemaFiles[index]),
    exported + ' must remain original full frozen2 bytes',
  )
  publishedSchemas.push({
    exported,
    resolved: import.meta.resolve(exported),
    sha256: sha(actual),
    bytes: actual.length,
  })
}
if (epoch === '3') {
  const actual = readFileSync(
    fileURLToPath(import.meta.resolve('@omne-harness-lite/content-blocks/schema')),
  )
  assert.deepEqual(actual, snapshot('spec/data/content-blocks/v3/content-blocks.schema.json'))
  publishedSchemas.push({
    exported: '@omne-harness-lite/content-blocks/schema',
    sha256: sha(actual),
    bytes: actual.length,
  })
}
for (const specifier of [
  '@omne-harness-lite/arrival-events',
  '@omne-harness-lite/content-blocks',
  '@omne-harness-lite/content-blocks/schema-runtime',
]) {
  const resolved = fileURLToPath(import.meta.resolve(specifier))
  assert(
    resolved.startsWith(root + 'packages/core/'),
    'consumer resolved outside this spoke: ' + resolved,
  )
  assert(resolved.includes('/dist/'), 'consumer must use built public dist entry: ' + resolved)
}
const baseline =
  epoch === '3'
    ? JSON.parse(readFileSync(new URL('../epoch2-result.json', import.meta.url), 'utf8'))
    : undefined
if (baseline) {
  assert.equal(baseline.passed, true)
  assert.equal(
    baseline.cases_sha256,
    sha(readFileSync(new URL('../paired-cases.json', import.meta.url))),
  )
  assert.equal(baseline.old_ar_schema_sha256, sha(snapshot(schemaFiles[3])))
}
const outcomes = []
const probes = []
function normalizeCB(result) {
  return 'rejected' in result ? { rejected: result.rejected } : { ok: true }
}
function freeze(value) {
  if (value !== null && typeof value === 'object') {
    Object.values(value).forEach(freeze)
    Object.freeze(value)
  }
  return value
}
for (const entry of cases) {
  const wire = entry.wire ?? JSON.stringify(entry.envelope)
  const read = cb.readJsonStrict(wire)
  let queries = []
  let view
  if (entry.opened) {
    view = freeze(readStrict(JSON.stringify(entry.opened)))
    assert.deepEqual(
      ar.validate('OpenEvent', view),
      { valid: true },
      entry.id + ' legal view shape',
    )
    assert.deepEqual(
      ar.judgeArrivalEnvelope({ target: read.ok.target, event: view }),
      { ok: true },
      entry.id + ' legal view judgment',
    )
  }
  const callback =
    view === undefined
      ? undefined
      : index => {
          assert.equal(
            cb.jsonNumberSource(index),
            cb.jsonNumberSource(view.index),
            entry.id + ' exact current-open index',
          )
          queries.push(cb.jsonNumberSource(index))
          return view
        }
  const fromWire = ar.judgeArrivalEnvelopeText(wire, callback)
  assert.deepEqual(fromWire, entry.expected_ar, entry.id + ' strict wire judgment')
  if (entry.strict_decode_failure) {
    assert('failed' in read, entry.id + ' duplicate must fail strict decode')
    outcomes.push({
      id: entry.id,
      origin: entry.origin,
      strict_decode_failed: true,
      wire: fromWire,
    })
    continue
  }
  assert('ok' in read, entry.id)
  const value = read.ok
  const before = cb.writeJsonLossless(value)
  queries = []
  const judgment = ar.judgeArrivalEnvelope(value, callback)
  assert.deepEqual(judgment, entry.expected_ar, entry.id + ' value judgment')
  assert(Object.isFrozen(judgment))
  const shape = ar.validate('ArrivalEnvelope', value).valid
  const frozenShape = ar2Validators.ArrivalEnvelope.validate(value)
  assert.equal(shape, entry.expected_ar_shape, entry.id + ' retained AR2 shape')
  assert.equal(shape, frozenShape, entry.id + ' frozen full AR2 graph')
  assert.equal(cb.writeJsonLossless(value), before, entry.id + ' no repair/mutation')
  if (view !== undefined) {
    assert.deepEqual(queries, ['0'], entry.id + ' sole current-open query')
  }
  for (const lexeme of entry.exact_lexemes ?? [])
    assert(before.includes(lexeme), entry.id + ' exact original JSON number ' + lexeme)
  const current = {
    id: entry.id,
    origin: entry.origin,
    ar: judgment,
    wire: fromWire,
    ar_shape: shape,
    frozen_ar2_shape: frozenShape,
    open_queries: queries,
  }
  if (entry.block) {
    const block = readStrict(JSON.stringify(entry.block))
    const originalBytes = cb.writeJsonLossless(block)
    const frozenCB2Shape = cb2Validator.validate(block)
    const actualCBShape = cb.validate('ContentBlock', block).valid
    const actualCBJudgment = normalizeCB(cb.judgeContentBlock(block))
    assert.equal(frozenCB2Shape, entry.expected_cb_v2_shape, entry.id + ' frozen CB2 shape')
    assert.equal(
      actualCBShape,
      entry['expected_cb_v' + epoch + '_shape'],
      entry.id + ' actual CB' + epoch + ' shape',
    )
    assert.deepEqual(
      actualCBJudgment,
      entry['expected_cb_v' + epoch],
      entry.id + ' actual CB' + epoch + ' judgment',
    )
    assert.equal(cb.writeJsonLossless(block), originalBytes, entry.id + ' CB mutation')
    if (Object.hasOwn(block, 'rawArguments')) {
      assert.deepEqual(
        Buffer.from(block.rawArguments),
        Buffer.from(entry.block.rawArguments),
        entry.id + ' original raw string bytes',
      )
      current.raw_arguments_utf8_sha256 = sha(Buffer.from(block.rawArguments))
    }
    Object.assign(current, {
      frozen_cb2_shape: frozenCB2Shape,
      actual_cb_shape: actualCBShape,
      actual_cb: actualCBJudgment,
    })
  }
  outcomes.push(current)
}
// Compile and exercise every retained definition, including the five enum/head
// roots absent as top-level producer events. This is exactly AR2's fixed graph.
const model = { kind: 'model_call', callId: 'mc_1', dispatch: 1 }
const values = {
  ArrivalEnvelope: { target: model, event: { t: 'finish', reason: 'end' } },
  ArrivalTarget: model,
  ArrivalEvent: { t: 'finish', reason: 'end' },
  OpenEvent: {
    t: 'open',
    kind: 'text',
    fill: 'append',
    id: 'b_1',
    index: 0,
    visibility: { toHuman: true, toModel: true },
  },
  FillEvent: { t: 'fill', index: 0, payload: 'raw' },
  CloseEvent: { t: 'close', index: 0 },
  TrimEvent: { t: 'trim', reason: 'rate_merged', merged: 1 },
  AccountEvent: {
    t: 'account',
    usage: {
      input_tokens: 1,
      output_tokens: 1,
      cache_read_tokens: 0,
      cache_write_tokens: 0,
      source: 'upstream',
    },
    cost: { cost_usd: 0.1, source: 'upstream_usage' },
  },
  FinishEvent: {
    t: 'finish',
    reason: 'lost',
    error: { cause: 'upstream_unavailable', statusCode: 500, inBand: true },
  },
  BlockKind: 'tool_call',
  FillMode: 'replace',
  BlockHead: { tool: 'bad:name', callId: 'call_1' },
  PresentationHint: { hint: 'log' },
  FinishReason: 'lost',
}
for (const [name, sample] of Object.entries(values)) {
  const value = readStrict(JSON.stringify(sample))
  const expected = ar2Validators[name].validate(value)
  assert(expected, name + ' independent positive fixture must be valid')
  assert.equal(ar.validate(name, value).valid, expected, name + ' fixed graph positive')
  for (const invalid of [null, [], 7]) {
    const parsed = readStrict(JSON.stringify(invalid))
    assert.equal(ar2Validators[name].validate(parsed), false, name + ' independent negative')
    assert.equal(ar.validate(name, parsed).valid, false, name + ' fixed graph negative')
  }
  probes.push({ name, positive: true, negative_samples: 3 })
}
if (baseline) {
  assert.equal(outcomes.length, baseline.cases.length)
  for (const [index, current] of outcomes.entries()) {
    const old = baseline.cases[index]
    assert.equal(current.id, old.id)
    // The current CB3 domain intentionally differs; retained AR2 and frozen CB2
    // checks must be exactly the same. We do not compare away the CB3 expansion.
    for (const key of [
      'ar',
      'wire',
      'ar_shape',
      'frozen_ar2_shape',
      'open_queries',
      'strict_decode_failed',
      'frozen_cb2_shape',
      'raw_arguments_utf8_sha256',
    ]) {
      assert.deepEqual(current[key], old[key], current.id + ' old/new AR2 ' + key)
    }
  }
}
const report = {
  epoch: Number(epoch),
  source_head: currentHead,
  passed: true,
  node: process.version,
  cases_sha256: sha(readFileSync(new URL('../paired-cases.json', import.meta.url))),
  old_ar_schema_sha256: sha(snapshot(schemaFiles[3])),
  module: import.meta.resolve('@omne-harness-lite/arrival-events'),
  cb_module: import.meta.resolve('@omne-harness-lite/content-blocks'),
  public_schemas: publishedSchemas,
  definition_probes: probes,
  case_count: cases.length,
  checks: outcomes.length,
  cases: outcomes,
  actual_epoch3_comparison:
    epoch === '3' ? 'passed for these concrete paired cases' : 'pending real CB3 source release',
  limits:
    'Finite paired pure-value check only; not sequence/producer/runtime/Connector/global acceptance',
  baseline_head: inputs.head,
}
writeFileSync(output, JSON.stringify(report, null, 2) + '\n')
console.log(
  JSON.stringify(
    {
      epoch: Number(epoch),
      source_head: currentHead,
      case_count: outcomes.length,
      compiled_and_probed_ar2_definitions: probes.length,
      passed: true,
      actual_epoch3_comparison: report.actual_epoch3_comparison,
    },
    null,
    2,
  ),
)
