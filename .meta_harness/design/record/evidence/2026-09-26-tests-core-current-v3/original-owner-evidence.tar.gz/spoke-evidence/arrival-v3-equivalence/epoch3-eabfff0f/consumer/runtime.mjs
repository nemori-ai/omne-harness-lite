import assert from 'node:assert/strict'
import * as a from '@omne-harness-lite/arrival-events'
import schema from '@omne-harness-lite/arrival-events/schema' with {type:'json'}
import {readJsonStrict,jsonNumberSource,judgeContentBlock} from '@omne-harness-lite/content-blocks'
const results=[]
function check(id,run){run();results.push({id,passed:true})}
const target={kind:'model_call',callId:'m',dispatch:1}
const frame={kind:'tool_execution',callId:'c'}
const visibility={toHuman:true,toModel:true}
const view={t:'open',index:0,kind:'voice',fill:'replace',id:'b',visibility,head:{mediaType:'audio/pcm'}}
const fill=payload=>({target,event:{t:'fill',index:0,payload}})
check('all-seven-runtime-exports',()=>assert.deepEqual(Object.keys(a).sort(),['SCHEMA_DEF_NAMES','isStandardBase64','judgeArrivalEnvelope','judgeArrivalEnvelopeText','reduceFills','schemaId','validate'].sort()))
check('schema-public-byte-resource-identity',()=>assert.equal(schema.$id,a.schemaId))
check('all-fourteen-schema-definitions',()=>assert.deepEqual([...a.SCHEMA_DEF_NAMES].sort(),Object.keys(schema.$defs).sort()))
check('schema-definitions-frozen',()=>assert(Object.isFrozen(a.SCHEMA_DEF_NAMES)))
check('shape-public-validator',()=>assert.deepEqual(a.validate('FinishReason','lost'),{valid:true}))
check('schema-invalid-definition-technical-error',()=>assert.throws(()=>a.validate('invented',{}),TypeError))
check('judgment-public-envelope',()=>assert.deepEqual(a.judgeArrivalEnvelope({target,event:{t:'finish',reason:'end'}}),{ok:true}))
check('judgment-public-text',()=>assert.deepEqual(a.judgeArrivalEnvelopeText('{"target":{"kind":"model_call","callId":"m","dispatch":1},"event":{"t":"finish","reason":"end"}}'),{ok:true}))
check('nested-duplicate-json-malformed',()=>assert.deepEqual(a.judgeArrivalEnvelopeText('{"target":{"kind":"model_call","callId":"m","dispatch":1},"event":{"t":"fill","index":0,"payload":{"x":{"y":1,"y":2}}}}'),{rejected:'malformed'}))
check('strict-padding-zero-bits',()=>assert.equal(a.isStandardBase64('YR=='),false))
check('strict-no-trailing-newline',()=>assert.equal(a.isStandardBase64('YQ==\n'),false))
check('canonical-nonempty-bytes',()=>assert.equal(a.isStandardBase64('YQ=='),true))
check('voice-append-is-byte-concatenation',()=>assert.equal(a.reduceFills({kind:'voice',fill:'append'},['YQ==','Yg==']),'YWI='))
check('tool-call-replace-is-last-raw-text',()=>assert.equal(a.reduceFills({kind:'tool_call',fill:'replace'},['{"x":1}','{"x":2,"x":3}']),'{"x":2,"x":3}'))
check('tool-call-append-never-parses-raw-text',()=>assert.equal(a.reduceFills({kind:'tool_call',fill:'append'},['{unfinished','??'] ),'{unfinished??'))
check('zero-fill-has-no-content',()=>assert.equal(a.reduceFills({kind:'tool_call',fill:'replace'},[]),undefined))
check('one-empty-replacement-is-content',()=>assert.equal(a.reduceFills({kind:'tool_call',fill:'replace'},['old','']),''))
check('invalid-reduction-mode-never-defaults',()=>{
 for(const mode of [{kind:'image',fill:'append'},{kind:'unknown',fill:'replace'},{kind:'text',fill:'merge'}])assert.throws(()=>a.reduceFills(mode,[]),TypeError)
})
check('optional-open-view-two-predicates-only',()=>{
 assert.deepEqual(a.judgeArrivalEnvelope(fill('bad!')),{ok:true})
 assert.deepEqual(a.judgeArrivalEnvelope(fill('bad!'),()=>undefined),{ok:true})
 assert.deepEqual(a.judgeArrivalEnvelope(fill('bad!'),()=>view),{rejected:'replace_payload_shape'})
 assert.deepEqual(a.judgeArrivalEnvelope({...fill('bad!'),target:frame},()=>view),{rejected:'frame_media_inline'})
})
check('precise-original-index-consumer',()=>{
 const parsed=readJsonStrict('{"target":{"kind":"model_call","callId":"m","dispatch":1},"event":{"t":"fill","index":9007199254740993,"payload":"YQ=="}}')
 assert('ok' in parsed)
 const calls=[]
 assert.deepEqual(a.judgeArrivalEnvelope(parsed.ok,index=>{calls.push(jsonNumberSource(index));return Object.freeze({...view,index})}),{ok:true})
 assert.deepEqual(calls,['9007199254740993'])
})
check('whole-replacement-copy-is-deep-immutable',()=>{
 const raw={kind:'image',id:'b',visibility,mediaType:'image/png',data:{storage:'s',key:'k',mediaType:'image/png'}}
 const block=judgeContentBlock(raw);assert('ok'in block)
 const result=a.reduceFills({kind:'image',fill:'replace'},[block.ok])
 assert.deepEqual(result,raw);assert.notEqual(result,block.ok)
 assert(Object.isFrozen(result)&&Object.isFrozen(result.visibility)&&Object.isFrozen(result.data))
})
check('judgment-result-frozen',()=>assert(Object.isFrozen(a.judgeArrivalEnvelope(fill('x')))))
console.log(JSON.stringify({package:'@omne-harness-lite/arrival-events',module:import.meta.resolve('@omne-harness-lite/arrival-events'),schema:import.meta.resolve('@omne-harness-lite/arrival-events/schema'),passed:true,checks:results},null,2))
