#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path

task = Path(__file__).resolve().parent
manifest = task / 'preparation-manifest.json'
expected = (task / 'preparation-manifest.sha256').read_text().split()[0]
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == expected
entries = json.loads(manifest.read_text())['artifacts']
for entry in entries:
    path = task / entry['path']
    assert len(path.read_bytes()) == entry['bytes'], entry['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256'], entry['path']
print(json.dumps({'artifact_count': len(entries), 'all_match': True, 'manifest_sha256': expected}, indent=2))
