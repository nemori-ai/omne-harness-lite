import type {ReductionMode,OpenEvent} from '@omne-harness-lite/arrival-events'
import type {BlockId,CallId} from '@omne-harness-lite/content-blocks'
declare const id:BlockId
declare const callId:CallId
const a:ReductionMode={kind:'image',fill:'append'}
const voice:OpenEvent={t:'open',index:0,id,visibility:{toHuman:true,toModel:true},kind:'voice',fill:'append'}
const text:OpenEvent={t:'open',index:0,id,visibility:{toHuman:true,toModel:true},kind:'text',fill:'append',head:{callId,tool:'t'}}
const result:OpenEvent={t:'open',index:0,id,visibility:{toHuman:true,toModel:true},kind:'tool_result',fill:'replace',head:{mediaType:'image/png'}}
void [a,voice,text,result]
