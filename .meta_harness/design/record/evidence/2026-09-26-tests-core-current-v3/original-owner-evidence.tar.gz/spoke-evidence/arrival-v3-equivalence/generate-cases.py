#!/usr/bin/env python3
"""Finite paired inputs with expectations fixed from accepted AR2/CB2/CB3 clauses."""
import copy
import itertools
import json
from pathlib import Path

TASK = Path(__file__).resolve().parent
rows = []
model = {'kind': 'model_call', 'callId': 'mc_1', 'dispatch': 1}
frame = {'kind': 'tool_execution', 'callId': 'call_1'}
vis = {'toHuman': True, 'toModel': True}
hidden = {'toHuman': False, 'toModel': False}
framevis = {'toHuman': True, 'toModel': False}
bad_name = 'bad:name'


def rejected(value):
    return {'rejected': value}


def call(tool='good_tool', branch='arguments', **changes):
    value = {'kind': 'tool_call', 'id': 'b_1', 'visibility': copy.deepcopy(vis),
             'complete': True, 'callId': 'call_1', 'tool': tool}
    if branch == 'arguments':
        value['arguments'] = {'value': 1}
    elif branch == 'raw':
        value.update(rawArguments='{"value":', unparseable=True)
    else:
        value.update(complete=False, visibility=copy.deepcopy(hidden), rawArguments='{"value":')
    value.update(copy.deepcopy(changes))
    return value


def text(id='text_1', visibility=vis):
    return {'kind': 'text', 'id': id, 'visibility': copy.deepcopy(visibility), 'text': 'ok'}


def image(id='image_1', visibility=vis, inline=False, media='image/png'):
    value = {'kind': 'image', 'id': id, 'visibility': copy.deepcopy(visibility), 'mediaType': media,
             'data': {'inline': 'YQ=='} if inline else {'storage': 's', 'key': 'k', 'mediaType': media}}
    return value


def result(blocks, visibility=vis):
    return {'kind': 'tool_result', 'id': 'result_1', 'visibility': copy.deepcopy(visibility),
             'callId': 'call_1', 'outcome': 'completed', 'blocks': copy.deepcopy(blocks)}


def opened(kind='text', fill='replace', visibility=vis):
    value = {'t': 'open', 'index': 0, 'id': 'b_1', 'kind': kind, 'fill': fill,
             'visibility': copy.deepcopy(visibility)}
    if kind == 'voice':
        value['head'] = {'mediaType': 'audio/pcm'}
    if kind == 'tool_call':
        value['head'] = {'callId': 'call_1', 'tool': 'good_tool'}
    return value


def row(id, envelope, expected, shape, origin='control', block=None,
        cbshape=(False, False), cbjudgments=None, opened_view=None, clauses=None, wire=None):
    entry = {'id': id, 'origin': origin, 'clauses': clauses or ['AR2 S-28/S-29'],
             'envelope': copy.deepcopy(envelope), 'expected_ar': expected,
             'expected_ar_shape': shape}
    if block is not None:
        entry['block'] = copy.deepcopy(block)
        entry['expected_cb_v2_shape'], entry['expected_cb_v3_shape'] = cbshape
        if cbjudgments is not None:
            entry['expected_cb_v2'], entry['expected_cb_v3'] = cbjudgments
    if opened_view is not None:
        entry['opened'] = copy.deepcopy(opened_view)
    if wire is not None:
        entry['wire'] = wire
    rows.append(entry)


def at(position, block, target=model):
    event = {'t': position, 'index': 0, 'payload' if position == 'fill' else 'block': copy.deepcopy(block)}
    return {'target': copy.deepcopy(target), 'event': event}


variants = []
for name, tool, shape in [('ascii', 'Good-1_tool', True), ('colon', bad_name, False),
                          ('length128', 'a' * 128, True), ('length129', 'a' * 129, False),
                          ('unicode', '工具', False), ('newline', 'good\n', False)]:
    variants.append(('arguments-' + name, call(tool), (shape, shape),
                     ({'ok': True} if shape else rejected('malformed'),) * 2))
    variants.append(('complete-raw-' + name, call(tool, 'raw'), (shape, True),
                     ({'ok': True} if shape else rejected('malformed'), {'ok': True})))
    variants.append(('incomplete-' + name, call(tool, 'incomplete'), (True, True), ({'ok': True},) * 2))
for name, tool in [('empty', ''), ('number', 7), ('null', None)]:
    for branch in ['arguments', 'raw', 'incomplete']:
        variants.append((branch + '-invalid-tool-' + name, call(tool, branch), (False, False), (rejected('malformed'),) * 2))
missing = call(branch='raw')
del missing['tool']
variants.append(('complete-raw-missing-tool', missing, (False, False), (rejected('malformed'),) * 2))
incomplete_missing = call(branch='incomplete')
del incomplete_missing['tool']
variants.append(('incomplete-tool-absent', incomplete_missing, (True, True), ({'ok': True},) * 2))
for name, raw in [('empty', ''), ('duplicate-keys', '{"x":1,"x":2}'),
                  ('escaped-duplicate-keys', '{"x":1,"\\u0078":2}'),
                  ('original-bytes', ' \n{"键":"值","x":1,"x":2}\t '),
                  ('not-json', '?? {unfinished')]:
    for tool_name in ['good_tool', bad_name]:
        good = tool_name == 'good_tool'
        variants.append(('raw-' + name + '-' + ('good' if good else 'bad'),
                         call(tool_name, 'raw', rawArguments=raw), (good, True),
                         ({'ok': True} if good else rejected('malformed'), {'ok': True})))
mixed = call(branch='arguments', rawArguments='{}', unparseable=True)
variants.append(('mutually-exclusive-branches', mixed, (False, False), (rejected('malformed'),) * 2))
for position in ['fill', 'close']:
    for name, block, shapes, judgments in variants:
        row(position + '/' + name, at(position, block), rejected('malformed'), False,
            position + '.forbidden-tool-call', block, shapes, judgments,
            clauses=['AR2 S-12' if position == 'fill' else 'AR2 S-13', 'AR2 S-28', 'CB2/CB3 S-12/S-13'])
    for name, block, reason in [
        ('direct-incomplete-visible', call(bad_name, 'incomplete', visibility=copy.deepcopy(vis)), 'incomplete_call_visible'),
        ('direct-visibility-missing', call(bad_name, 'raw', visibility={}), 'visibility_missing'),
    ]:
        row(position + '/' + name, at(position, block), rejected(reason), False,
            position + '.forbidden-tool-call.priority', block, (False, False),
            (rejected(reason),) * 2, clauses=['AR2 S-28', 'CB2/CB3 S-13/S-26'])

# All nonempty combinations of five CB named predicates. Each direct forbidden
# call is also remaining-shape-invalid; none of those shape errors may win first.
names = ['kind_unknown', 'visibility_missing', 'incomplete_call_visible', 'call_in_result', 'modality_mismatch']
components = [
    {'kind': 'unknown', 'id': 'unknown_1', 'visibility': copy.deepcopy(vis)},
    {'kind': 'text', 'id': 'missing_1', 'text': 'ok'},
    call(bad_name, 'incomplete', id='incomplete_1', visibility=copy.deepcopy(vis)),
    result([call(bad_name, 'raw', id='nested_call_1')]),
    image(id='wrong_media_1', media='audio/pcm'),
]
for position in ['fill', 'close']:
    for bits in itertools.product([False, True], repeat=5):
        if not any(bits):
            continue
        children = [copy.deepcopy(component) for bit, component in zip(bits, components) if bit]
        block = call(bad_name, 'raw', renderings=[{'blocks': children}])
        reason = next(name for name, bit in zip(names, bits) if bit)
        row(position + '/priority/' + ''.join('1' if bit else '0' for bit in bits), at(position, block),
            rejected(reason), False, position + '.forbidden-tool-call.priority', block,
            (False, False), (rejected(reason),) * 2, clauses=['AR2 S-28', 'CB2/CB3 S-26'])
    # Remaining CB malformed must defer to the AR frame predicate.
    inline_block = call(bad_name, 'raw', visibility=copy.deepcopy(framevis),
                        renderings=[{'blocks': [image(visibility=framevis, inline=True)]}])
    row(position + '/frame-inline-before-malformed', at(position, inline_block, frame),
        rejected('frame_media_inline'), False, position + '.forbidden-tool-call.priority', inline_block,
        (False, False), (rejected('malformed'),) * 2, clauses=['AR2 S-23/S-28'])
    nested = result([call(bad_name, 'raw')])
    row(position + '/enclosed-call-in-result', at(position, nested), rejected('call_in_result'), False,
        position + '.nested-tool-call.priority', nested, (False, False), (rejected('call_in_result'),) * 2)
    unknown = at(position, call(bad_name, 'raw', visibility={}))
    unknown['event']['t'] = 'unknown'
    row(position + '/event-unknown-overlay', unknown, rejected('event_unknown'), False,
        position + '.root-discriminant-overlay', clauses=['AR2 S-27/S-28'])

for kind in ['text', 'thinking', 'tool_call', 'voice', 'image', 'file', 'tool_result']:
    view = opened(kind)
    if kind == 'image':
        view['head'] = {'mediaType': 'image/png'}
    block = call(bad_name, 'raw')
    row('fill/replacement-' + kind + '-before-malformed', at('fill', block),
        rejected('replace_payload_shape'), False, 'fill.forbidden-tool-call.priority', block,
        (False, True), (rejected('malformed'), {'ok': True}), view,
        clauses=['AR2 S-12/S-28', 'CB2/CB3 S-12'])
    if kind == 'voice':
        row('fill/frame-voice-before-replacement', at('fill', block, frame),
            rejected('frame_media_inline'), False, 'fill.forbidden-tool-call.priority', block,
            (False, True), (rejected('malformed'), {'ok': True}), opened('voice', visibility=framevis))

# Remaining AR predicates cannot all coexist with a fill/close t discriminator.
# These root-event controls document that limit and exercise the fixed ordering.
for reason, event in [
    ('trim_reason_unknown', {'t': 'trim', 'reason': 'invalid', 'merged': -1}),
    ('finish_reason_unknown', {'t': 'finish', 'reason': 'invalid', 'error': {}}),
    ('presentation_invalid', dict(opened('image', 'append'), head={'mediaType': 'audio/pcm', 'presentation': {'hint': 'log'}})),
    ('head_modality_mismatch', dict(opened('image', 'append'), head={'mediaType': 'audio/pcm'})),
    ('fill_kind_not_appendable', opened('image', 'append')),
    ('visibility_missing', dict(opened('image', 'append'), visibility={}, head={'presentation': {'hint': 'log'}, 'mediaType': 'audio/pcm'})),
]:
    row('control/priority/' + reason, {'target': model, 'event': event}, rejected(reason), False,
        clauses=['AR2 S-8/S-9/S-10/S-28'])

# No legal producer parses tool arguments or ships a ToolCall whole block at AR.
for name, tool in [('good', 'good_tool'), ('colon', bad_name), ('length128', 'a' * 128), ('length129', 'a' * 129)]:
    view = opened('tool_call', 'append')
    view['head']['tool'] = tool
    row('allowed/tool-open-' + name, {'target': model, 'event': view}, {'ok': True}, True,
        clauses=['AR2 S-9'])
for name, raw in [('duplicate', '{"x":1,"x":2}'), ('unfinished', '{"x":'),
                  ('original-bytes', ' \n{"键":"值","x":1,"x":2}\t '), ('empty-replacement', '')]:
    row('allowed/tool-raw-fill-' + name, {'target': model, 'event': {'t': 'fill', 'index': 0, 'payload': raw}},
        {'ok': True}, True, opened_view=opened('tool_call'), clauses=['AR2 S-11/S-12/S-19'])
row('allowed/tool-close-without-block', {'target': model, 'event': {'t': 'close', 'index': 0}}, {'ok': True}, True,
    clauses=['AR2 S-13/S-31'])
file = {'kind': 'file', 'id': 'file_1', 'visibility': copy.deepcopy(vis),
        'attachment': {'storage': 's', 'key': 'k', 'mediaType': 'application/pdf'}}
for name, block in [('text', text()), ('thinking', dict(text(), kind='thinking')), ('image', image()),
                    ('image-inline-model', image(inline=True)), ('file', file), ('tool-result', result([text()]))]:
    if block['kind'] in ['image', 'file', 'tool_result']:
        row('allowed/fill-' + name, at('fill', block), {'ok': True}, True,
            block=block, cbshape=(True, True), cbjudgments=({'ok': True},) * 2)
    row('allowed/close-' + name, at('close', block), {'ok': True}, True,
        block=block, cbshape=(True, True), cbjudgments=({'ok': True},) * 2)
for position in ['fill', 'close']:
    block = image(visibility=framevis)
    row('allowed/frame-' + position + '-reference', at(position, block, frame), {'ok': True}, True,
        block=block, cbshape=(True, True), cbjudgments=({'ok': True},) * 2)
    row('control/frame-' + position + '-inline', at(position, image(visibility=framevis, inline=True), frame),
        rejected('frame_media_inline'), True)
for target_name, target in [('model', model), ('frame', frame)]:
    for reason in ['end', 'interrupted', 'lost'] + (['max_tokens'] if target_name == 'model' else []):
        row('allowed/' + target_name + '-finish-' + reason, {'target': target, 'event': {'t': 'finish', 'reason': reason}}, {'ok': True}, True)
usage = {'input_tokens': 1, 'output_tokens': 2, 'cache_read_tokens': 0, 'cache_write_tokens': 0, 'source': 'upstream'}
row('allowed/model-account', {'target': model, 'event': {'t': 'account', 'usage': usage, 'cost': {'cost_usd': 0.1, 'source': 'upstream_usage'}}}, {'ok': True}, True)
account_wire = '{"target":{"kind":"model_call","callId":"mc_1","dispatch":1},"event":{"t":"account","usage":{"input_tokens":9007199254740993,"output_tokens":2,"cache_read_tokens":0,"cache_write_tokens":0,"source":"upstream"},"cost":{"cost_usd":0.123456789012345678901,"source":"upstream_usage"}}}'
entry = {'id': 'allowed/model-account-exact-wire', 'origin': 'wire-control', 'clauses': ['AR2 S-15/S-26'],
         'wire': account_wire, 'expected_ar': {'ok': True}, 'expected_ar_shape': True,
         'exact_lexemes': ['9007199254740993', '0.123456789012345678901']}
rows.append(entry)
for name, wire in [
    ('event-t', '{"target":{"kind":"model_call","callId":"mc_1","dispatch":1},"event":{"t":"fill","t":"unknown","index":0,"payload":"raw"}}'),
    ('escaped-event-t', '{"target":{"kind":"model_call","callId":"mc_1","dispatch":1},"event":{"t":"fill","\\u0074":"fill","index":0,"payload":"raw"}}'),
    ('outer-target', '{"target":{"kind":"model_call","callId":"mc_1","dispatch":1},"target":{"kind":"tool_execution","callId":"call_1"},"event":{"t":"finish","reason":"end"}}'),
    ('arguments-nested', json.dumps(at('close', call()), separators=(',', ':')).replace('"arguments":{"value":1}', '"arguments":{"value":{"x":1,"x":2}}')),
]:
    rows.append({'id': 'wire/duplicate-' + name, 'origin': 'strict-wire-duplicate-control',
                 'clauses': ['CB2/CB3 S-31', 'AR2 S-26/S-28'], 'wire': wire,
                 'expected_ar': rejected('malformed'), 'strict_decode_failure': True})

ids = [r['id'] for r in rows]
assert len(ids) == len(set(ids))
(TASK / 'paired-cases.json').write_text(json.dumps({'format': 1,
    'scope': 'Finite actual paired evidence for AR2, not exhaustive proof or runtime/Connector acceptance',
    'case_count': len(rows), 'cases': rows}, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'case_count': len(rows), 'direct_fill_forbidden_cases': sum(r['origin'].startswith('fill.forbidden') for r in rows),
                  'direct_close_forbidden_cases': sum(r['origin'].startswith('close.forbidden') for r in rows),
                  'strict_wire_cases': sum(r.get('strict_decode_failure', False) for r in rows),
                  'new_epoch_execution': 'pending actual source release'}, indent=2))
