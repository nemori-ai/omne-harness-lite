import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import * as AM from '@omne-harness-lite/asset-model'
import { toolBodyContract } from '@omne-harness-lite/tool-definition'
import { loopExtensionBodyContract } from '@omne-harness-lite/loop-extension'
import { skillBodyContract } from '@omne-harness-lite/skill-package'
import { mcpBodyContract } from '@omne-harness-lite/mcp-endpoint'
import { slashCommandBodyContract } from '@omne-harness-lite/slash-command'
const bodies={tool:toolBodyContract,loop_extension:loopExtensionBodyContract,skill:skillBodyContract,mcp:mcpBodyContract,slash_command:slashCommandBodyContract}
const am=AM.createAssetModelJudge(bodies)
const legalContents = [
 { category: 'tool', definition: { name: 'read_file', description: 'Read a file', paradigm: 'single', origin: { kind: 'authored' }, input: { type: 'object', properties: {} }, permissions: { execute: { default: 'ask' } } } },
 { category: 'loop_extension', extension: { name: 'guard', position: 'before_action', power: 'veto', implementation: { kind: 'builtin', builtinName: 'guard' } } },
 { category: 'skill', body: { manifest: { name: 'review', description: 'Review' }, body: 'Review the changes', resources: [] } },
 { category: 'mcp', body: { transport: { kind: 'streamable_http', url: 'https://example.invalid/mcp' }, timeouts: { connect: 'PT5S', call: 'PT10S' }, permissions: { execute: { default: 'ask' } } } },
 { category: 'slash_command', body: { description: 'Fix', binding: { kind: 'prompt', template: 'Fix $ARGUMENTS' } } },
]
for (const value of legalContents) {
 assert.deepEqual(am.validate('AssetContent', value), { valid: true }, value.category)
 const name=value.category==='tool'?value.definition.name:value.category==='loop_extension'?value.extension.name:value.category==='skill'?value.body.manifest.name:value.category==='slash_command'?'fix':'linear'
 const record={id:`asset_${value.category}`,capability:{category:value.category,name},origin:'official',versions:[{number:1,content:value,publishedAt:'2026-09-01T00:00:00Z'}]}
 assert.deepEqual(am.validate('AssetDefinition', record), { valid: true }, value.category)
 assert.deepEqual(am.judgeAssetValue('AssetDefinition', record), { ok: true }, value.category)
}
const private2=readFileSync(new URL('../../packages/core/asset-model/schema/resources/tool-definition.v2.schema.json',import.meta.url))
assert.ok(private2.equals(readFileSync(new URL('../../.meta_harness/design/spec/data/tool-definition/v2/tool-definition.schema.json',import.meta.url))))
await assert.rejects(import('@omne-harness-lite/asset-model/schema/resources/tool-definition.v2.schema.json',{with:{type:'json'}}),{code:'ERR_PACKAGE_PATH_NOT_EXPORTED'})
const current=['content-blocks','messages','model-response','loop-extension','tool-definition','asset-model']
const report=[]
for(const name of current){
 const api=await import(`@omne-harness-lite/${name}`)
 const schema=(await import(`@omne-harness-lite/${name}/schema`,{with:{type:'json'}})).default
 const old=(await import(`@omne-harness-lite/${name}/schema/v2`,{with:{type:'json'}})).default
 assert.ok(schema.$id.includes(`/v3/${name}.schema.json`))
 assert.ok(old.$id.includes(`/v2/${name}.schema.json`))
 assert.equal(api.schemaId,schema.$id)
 for(const def of api.SCHEMA_DEF_NAMES) (name==='asset-model'?am:api).validate(def,null)
 for(const v of [2,3]){
  const file=new URL(`../../packages/core/${name}/schema/${name}${v===2?'.v2':''}.schema.json`,import.meta.url)
  const original=new URL(`../../.meta_harness/design/spec/data/${name}/v${v}/${name}.schema.json`,import.meta.url)
  const bytes=readFileSync(file)
  assert.ok(bytes.equals(readFileSync(original)))
  report.push({name,version:v,defs:Object.keys(v===2?old.$defs:schema.$defs).length,sha256:createHash('sha256').update(bytes).digest('hex')})
 }
}
for(const name of ['arrival-events','call-accounts','model-profile','skill-package','mcp-endpoint','slash-command']){
 const api=await import(`@omne-harness-lite/${name}`)
 assert.ok(api.schemaId.includes(`/v2/${name}.schema.json`))
 for(const def of api.SCHEMA_DEF_NAMES) api.validate(def,null)
 report.push({name,version:2,compiled:api.SCHEMA_DEF_NAMES.length})
}
console.log(JSON.stringify({amPorts:Object.keys(bodies),amPortSchemaIds:Object.fromEntries(Object.entries(bodies).map(([key,value])=>[key,value.schema.$id])),actualLegalBodyJudges:legalContents.map(value=>value.category),currentAMDefs:AM.SCHEMA_DEF_NAMES.length,privateTD2:{sha256:createHash('sha256').update(private2).digest('hex'),notExported:true},report},null,2))
