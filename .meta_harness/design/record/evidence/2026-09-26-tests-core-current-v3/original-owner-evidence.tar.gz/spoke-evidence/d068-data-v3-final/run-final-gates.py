import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / 'tmp/d068-data-adoption'
PACKAGES = ['content-blocks', 'messages', 'model-response', 'loop-extension', 'tool-definition', 'asset-model']

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def source_hashes():
    files = []
    for name in PACKAGES:
        files.extend((ROOT / 'packages/core' / name).rglob('*'))
    return {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(files) if path.is_file() and
            not any(part in ['dist', 'node_modules', '.vitest'] for part in path.parts)}

commands = []
if sys.argv[1] == 'build-type-scan':
    commands.append(('final-build', ['pnpm', '-r', 'run', 'build']))
    for name in PACKAGES:
        commands.append((name + '-type-final', ['pnpm', '--filter', '@omne-harness-lite/' + name, 'run', 'typecheck']))
    commands.append(('actual27-final', ['pnpm', '--filter', '@omne-harness-lite/ts-checks', 'run', 'scan']))
elif sys.argv[1] == 'tests':
    for name in PACKAGES:
        commands.append((name + '-suite-final', ['pnpm', '--filter', '@omne-harness-lite/' + name,
                         'exec', 'vitest', 'run', '--maxWorkers', '1', '--reporter=json',
                         '--outputFile=' + str(EVIDENCE / 'raw' / (name + '-suite-final.json'))]))
else:
    raise ValueError('Unknown gate set')

ledger = []
ledger_path = EVIDENCE / (sys.argv[1] + '-ledger.json')
for name, argv in commands:
    record = {'name': name, 'cwd': str(ROOT), 'argv': argv, 'start': utc(),
              'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
              'source_before': source_hashes(), 'raw': str(EVIDENCE / 'raw' / (name + '.log'))}
    with open(record['raw'], 'w') as log:
        process = subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    record.update({'exit': process.returncode, 'end': utc(), 'source_after': source_hashes()})
    ledger.append(record)
    ledger_path.write_text(json.dumps(ledger, ensure_ascii=False, indent=2) + '\n')
    print(name + ': ' + str(process.returncode), flush=True)
    if process.returncode != 0:
        print(pathlib.Path(record['raw']).read_text()[-7000:], flush=True)
        sys.exit(process.returncode)
