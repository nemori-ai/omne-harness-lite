2026-09-26 root dispatch correction to the original construction brief step 4:
“Loop before_action 的运行时消费准入/派发不得执行 unparseable；本 core Loop typed/schema judge 仍按已接受 3 的形状表示接纳，不新增 S37 拒绝。”
Authority: /root; received through collaboration message. Original brief bytes retained.
References: accepted Loop3 contract S16/S37 and lines 488/1051. Schema admission does not grant dispatch permission.
