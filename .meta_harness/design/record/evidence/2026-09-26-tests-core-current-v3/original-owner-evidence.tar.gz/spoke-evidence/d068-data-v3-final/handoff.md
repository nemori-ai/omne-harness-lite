# D068 six data v3 source handoff

This is developer implementation and verification evidence. Independent technical acceptance belongs to `/root`; final overall acceptance belongs to the user.

Execution: `/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery-data-v3`, branch `panqiwei/core-delivery-data-v3`. Initial clean baseline `f8c76d60dd3f01c9a8cd1e29a94c4accbb9ec361`. Adopted spec authority is D068 acceptance at `3fab9200`, the exact catalog/frozen accepted3 resources, and this checkout's current D068 realization append. Original construction brief SHA `95a263f45e66f15c4aa8a466ef375af84aac2c4fa6bdae78a5fdffa02e3489e3` remains untouched; `dispatch-erratum.md` records the root correction to step 4. Loop Schema admission is not runtime dispatch permission. No new Loop rejection or full embedded Message/CB business check was added.

Source commits:

- `e5129cdc13bee3a918e874e77ae4948e4b5ac584`: six full default3 Schema resources, six full public `schema/v2` resources, AM private full TD2 and fixed mixed-version resources, exact retained2 consumers' Schema bindings, initial byte tests/docs. Previously released pilot.
- `163cac60`: authorized cherry-pick of root tool fix `eabfff0f167093f34cfa0582c7e6cf0773761016`. This only allows the adopted AM self `schema/v2` subpath and preserves private-path rejection. Root-owned source change.
- `29abb185`: own six-package finishing release. Truthful conditional CB raw tool name type; actual accepted3 appendix tests; original regression cases and exact current resource assertions; transport/ownership/priority cases; private TD2 exact bytes; corrected package contract navigation.

HUB already contains the pilot and root tool fix, so only cherry-pick the finishing source commit. No source edits continue after this release.

## Acceptance evidence

| Required boundary | Evidence and actual result |
|---|---|
| Precise current3 + retained2 resources | `schema-resources.json`; six public pairs are full byte-identical to frozen3/2, retain exact `$id`, and have independent hash/`$defs` assertions. Private TD2 also exact and complete. |
| CB3 raw bad name exception; normal names remain strict | CB accepted3 appendix 17 cases; complete/incomplete, bad:name/empty/nonstring/128/129/both/neither cases; `d068-transport.spec.ts` retains raw duplicate keys, large number, overflow notation and precise fraction verbatim. No parameter parse. |
| Msg/MR/Loop exact adopted domain | Accepted3 appendix cases Msg2/MR4/Loop4; public built receiver invokes full Loop typed Input wrappers, not only primitive shape validation. Existing rejection priorities and earlier oracle cases remain. |
| TD ordered prohibition | TD appendix eight cases (four ToolReturn and four ModelToolName Schema instances), plus six actual content/summary multi-error cases. Other malformed CB wins before represented-call prohibition, which still precedes outer shape defects M17/M18. |
| Fixed mixed version Schema graph | `raw/public-graphs-final-r6.log`: current six APIs own definitions compile; retained AR/CA/MP/Skill/MCP/Slash APIs stay2 and all their owned definitions compile; AM all25 current owned definitions compile with real Tool3/Loop3/Skill2/MCP2/Slash2 ports. All five complete legal AssetDefinition values pass actual port judgments. |
| No AM→TD product edge/private public path | AM's private TD2 is a complete resource, with no TD implementation import/dependency and no new port resource resolver. Actual unauthorized subpath import rejects `ERR_PACKAGE_PATH_NOT_EXPORTED`; private resource hash is `21f6ff19640da3905b4697404b8d7c527a4f0a6ec4c870b3f0affdc558c469ae`. |
| Prior representation fix retained | Full existing CB/Msg/Loop/TD representation tests pass under3. Built consumer separately reads genuine OpaqueJson from Loop input/output/conclusion/earlier and TD direct/nested/offload.summary values, for wire and branded inputs; exact `9007199254740993`, `1.2300`, absence/null and caller ownership are covered. Shape-only media/duplicate-id controls retain prior success in Loop without adding business rejection. |
| Public declarations truthful | Strict positive consumer compiles with `skipLibCheck:false`. Negative compile yields exactly nine intended errors, verified by line and code in `public-type-negative-proof.json`: private OpaqueJson, four honest boolean guards, Wire<Message>, raw/parsed mutual exclusion and two explicit raw-opaque guard paths. No unrelated compiler errors accepted as proof. |
| Full current local tests | CB410, Msg473, MR242, Loop581, TD282, AM422 = **2410 passed**, zero skipped/pending/failure. Full IDs are in Vitest JSON. `test-inventory.json` confirms every earlier recorded case remains. Original v2 case sources/oracles are not relabeled3; their unchanged cases are run as regressions against the current provider. |
| Required repository tools | Whole workspace graph build, six package typechecks, real registered27 scan on packages/apps, changed-maintained-files format check and `git diff --check` pass. See ledgers/raw logs. No new shared dependency or lock changes. |

## Typed restoration inventory

| API / representation positions | What is actually restored / tested |
|---|---|
| CB `judgeContentBlock`, `contentBlockFromRepresentation` | Thinking payload becomes real opaque wrapper, including recursively nested normative tool_result blocks. Full receiver and shape-only adapter remain distinct. |
| Msg `brandMessage`, `brandRecord`, full Message receiver | Message blocks and nested result blocks restore CB brands; full receiver keeps business checks. Record paths have no normative thinking payload; arbitrary `opaque` keys remain neutral JSON. |
| Loop `judgeInput` | subject.message, request.messages, reply, result.blocks; earlier.output rewrite/inject; direct and already branded inputs. Compaction plan arbitrary keys stay neutral; compaction Message uses the Message adapter. |
| Loop `judgeOutput` / `judgeConclusion` | rewrite subject paths, legal inject Message, output after ordered conclusion/immutable comparison. Legal inject reminder content does not permit thinking/nested result, so no unreachable opaque fixture is invented. |
| TD `toolResultOf` | content thinking, nested result descendants, offload.summary thinking/nested descendants; structured wire and branded input. `judgeToolReturn` reports boolean success and does not claim its input has been branded. |
| MR and AM judges | Their public judgments return boolean success, not a typed copied domain value. No extra representation guarantee was invented. |

`raw/public-consumer-final-r5.log` separately confirms actual built runtime paths. Exact original opaque text is retained; ordinary JSON object member order is not a promised property and consumer comparison uses strict lossless JSON values for reconstructed outer containers.

## Failed attempts and limits

- Initial six suites failed stale current-default comparisons against frozen2; full suite outputs are preserved. AM's initial protocol-double resources retained TD2 and collided with the new private TD2; test resources now consume accepted Tool3/Loop3 and keep unchanged other2 port behavior. No original case was removed or weakened.
- An AM case exceeded unchanged default5s under six concurrent suites (6139ms). A full standalone run with `--maxWorkers 1` passed, then the final full422 suite passed with the same test timeout. No timeout increase, retry assertion weakening or skip.
- Actual27 initially rejected AM's legitimate self schema/v2. Root supplied the precise rule correction and tests; this tree consumed its authorized commit and reran actual27 successfully. Blocked logs remain.
- `branch-red-actual.log` is an actual public built consumer red invocation using complete frozen2 default resources before restoring the accepted3 resources, not merely static reasoning. Green is `branch-green-final.log` using current3. Earlier module-resolution failures are retained separately. The old red invocation's exact per-command time/source snapshot was not captured; its raw output and resource identities are bounded evidence, not a fully sealed old baseline execution.
- Public evidence harness failures (bad regex, missing own node types, invalid fixture fields/placeholder, overstrict object member order, unrelated unbranded CallId type input) are retained in earlier logs. Only final passing runtime outputs and precisely checked intended type diagnostics are used as evidence. No product rules were changed to fit these fixtures.
- Input snapshots, original plan/matrix copies and later reconciled copies are separate. The later captured matrix SHA is `0cdc74ec7579f7ccc5a7f1b470fb3f13fc8d3b8491bae5598d935bae1b39142f`, plan SHA `e3a443b7416bdc167a5a808cec73bc7daca5d2948c37058d5ad4fc88d13de9cf`; root's prior correction announcement cited a different intermediate hash, which is not substituted for these bytes.
- No Connector body implementation, all-old AM2/all-def closure, new formal run/proof, external runtime dispatch/persistence/OAuth/model action or whole-repository SC3 is claimed. The real retained AR behavior/AE/SA/W6 combinations remain their owners' acceptance work. This package release has no blocking question left.

`manifest.json` seals actual current commit, source/config/input/resource/environment evidence and raw artifact hashes. Earlier logs without per-command timing are explicitly historical/partial provenance; final gate ledgers have actual argv, cwd, time and exit. This handoff is not acceptance.
