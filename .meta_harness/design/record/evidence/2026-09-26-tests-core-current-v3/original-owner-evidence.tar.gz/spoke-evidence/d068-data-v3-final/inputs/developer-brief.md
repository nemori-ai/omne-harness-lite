# Core 包实施派发的共同输入

本文件是调度输入，不是产品/规格权威。每个任务另外给出自身执行树、branch、基线和node。首步进入该绝对路径核对 branch/status，读取实际该树输入。主调度root负责HUB集成、根配置/锁、包/波技术验收；你不独占仓库，不回滚他人修改。仅本包与本树 tmp/<task>/ 为写入范围；设计回填/root配置由root协调。

## 权威与采用

设计工作区就是你的树的 `.meta_harness/`。读取根AGENTS、packages/AGENTS，.meta_harness/AGENTS/design/AGENTS，节点 `.meta_harness/design/realization/packages/core/<node>/{README.md,design.md,verification.md,bindings.yaml}`。实际采用坐标由 `design/registry/catalog.json`（accepted）、冻结 `frozen.json`，接受 D-061/D-062/D-065；行政坐标迁移依据 D-066，formatter技术增量为D-067；旧candidate顶标不推翻明确接受。当前十二个PR9数据节点采用v2（identity仍v1；OE主包v2并公开精确OE1 Schema入口）的 contract/schema/examples和其verification在 `design/spec/data/<node>/`；两纯能力为 `design/spec/capabilities/{stream-assembly,asset-evaluation}/v2/`。读取实际相关条款、每条用例和跨节点依赖，不以root已读替代。若无独立契约（既有kernel/storage），只用已接受技术设计/R清单，不造坐标。

公开签名以节点公开面和已释放依赖源码公开exports为输入，候选命名可按明确责任实现，不改变领域规则。类型相等唯一来源、每类BodyContract按category判别；defaultBodyContracts只在W6asset-evaluation组合，正文包不组完整端口。未接受产品/legacy/第三方源码不成为规格权威。冲突/关键歧义报告具体条款与受阻动作；仅暂停依赖部分，保持独立进展。

## 施工与验收

1. 在任务树自建环境 uv sync --locked；首次宿主生成为空时按toolingREADME用 python3/uv run .meta_harness/tooling/src/compile_agents.py --source .meta_harness/agents --output .meta_harness，不手改生成物。pnpm install --frozen-lockfile --ignore-scripts 安装初始锁。新增成员/依赖后用 pnpm install --ignore-scripts --lockfile=false，禁止修改根锁/catalog/workspace，所需catalog变更报root。
2. 新包沿现有格式Node>=24.18.0 <25、workspace package名@omne-harness-lite/<node>、exports公开dist入口以及Schema子入口（纯能力无Schema另按设计），build/typecheck/test脚本，Vitest类型负例。先build依赖再consume其dist，禁止穿透兄弟src或paths替代公开入口。
3. 各表形状/examples正反行逐条机检，具名拒绝及次序由契约有序谓词，Schema只判剩余；不从Ajv错误猜拒绝，不修补输入。Schema副本逐字节等于冻结spec，外部Schema从依赖./schema取。
4. 严格JSON/JsonNumber/opaque均取content-blocks已释放实现。保留超2^53/长小数/null与缺席、重复解码键；不要普通JSON.parse跨业务文本边界。Ajv本身不知道LosslessNumber；任何投影需本字段原值的精确约束先核，不把不可用包装值当JSONobject放行。`1e400`是合法JSONnumber不是普通finite number。
5. 十五新包纯函数，不依赖Cordis/kernel/storage/noncore插件、不取墙钟、不读文件/服务/数据库/进程、不设调用方Schema的全局增长缓存。固定自有Schema编译可本包固定持有；用户Schema编译对象生命周期由调用者掌握。正文推出函数局部模块只读显式正文参数与允许actionSnapshot、不能取外部状态；保留声明交asset-model统一加。
6. 必须实际build/typecheck/test、公开dist consumer、静态规则和本包格式。性质测试可用固定seed与独立oracle，保留失败seed；不得用被测函数生成预期。交付关键条款→真实testID/结果/范围/owner，不将外部运行时/持久/每一跳性质自动闭合。各纯函数值不可变，拒绝不假成功，异常仅依规格配置/缺陷，不吞未知error。
7. npm/library采用事实可自主调研（主源版本/许可/API适配证据）；Node24.18、TS6.0.3、Vitest4.1.11、Ajv8.20.0现有catalog已定。yaml2.9.1 ISC和regexpp4.12.2 MIT已rootcatalog钉，实际适配probe仍归相关worker。不要另引依赖或额外并行职责未与root明确共享owner。

W1 content-blocks共享试点先验收再释放下游。W2asset-model基础端口释放→call-accounts；仅Connector一种资产纵线延期：其他5正文及AM/AE完整求值、工作区读入照常。W3tool/messages→W4loop/skill/mcp→W5arrival/response/slash→W6stream/evaluation。五真实正文和消息流两条组合均由tools/core-verification实际验收，不用Ctor替身冒称第6真实端口。

允许任务树人名本地提交（panqiwei/594557445@qq.com，不带AI作者trailer），禁止push/merge/操作main。你交commit、status、实际源/配置hash、原始日志/JSON、条款coverage表及唯一ignored证据路径；root先验收保存哈希再退休。没有外部真实服务/发消息授权。只自主技术验收，用户最终总体验收未发生。

用户进一步精确范围：仅Connector一种资产纵线延期，其他资产类型完整实施和交付。上一版整体延期AE两操作过宽已纠正，按最新版计划继续evaluate/readWorkspaceCarrier和五真实正文组合。ctor缺实现不是其他类型逻辑的缺口，不造替身。availability技术投影已通过独立架构复审，采用 ceb4c02d 的 AM/AE 明确实施域；与未提供ctor无关的纯规则/类型/规范例可继续。

2026-09-26采用更新：HUB已含main127d63da，后续任务须实际读D066/version-migrations及当前冻结v2；旧v1验证保持历史，不重命名为v2实跑。引用OE1 Instant的资源图须从offer-expiry/schema/v1导入原完整资源。Storage conformance按D057显式传runner、不runtime导入Vitest。新spoke精确HEAD另由派发给定。
