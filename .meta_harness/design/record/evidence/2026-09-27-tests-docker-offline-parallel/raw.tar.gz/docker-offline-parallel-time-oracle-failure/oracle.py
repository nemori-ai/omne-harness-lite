#!/usr/bin/env python3
"""Independent raw-output oracle for two concurrent, distinct offline workRoots."""

import base64
import hashlib
import json
import pathlib
import re
import sys

BUILD_ID = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
ORIGINAL = "sha256:27c0665146265afefe39012aaea26bdae7499784eaaeb74aea712a6fcdfc03f2"
I3_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
PRIVATE = "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock"
HELPER = "/usr/local/libexec/omne-center"
MARKER_CONTENT = b"omne-isolated/1\n"
HEX64 = re.compile(r"[0-9a-f]{64}\Z")


def demand(value, message):
    if not value:
        raise ValueError(message)


def one_json(data, label):
    demand(data.endswith(b"\n") and data.count(b"\n") == 1,
           label + ": one JSON+LF required")
    result = json.loads(data)
    demand(isinstance(result, dict), label + ": object required")
    return result


def stat(data, label, kind, fields):
    parts = data.decode("ascii", "strict").strip().split(":")
    demand(len(parts) == fields + 1 and parts[0] == kind and
           all(part.isdigit() for part in parts[1:]), label + ": wrong stat")
    return tuple(map(int, parts[1:]))


def numbers(data, label, count):
    parts = data.decode("ascii", "strict").strip().split(":")
    demand(len(parts) == count and all(part.isdigit() for part in parts),
           label + ": wrong numeric stat")
    return tuple(map(int, parts))


def proc_argv(encoded, label):
    data = base64.b64decode(encoded, validate=True)
    demand(data.endswith(b"\0") and len(data) > 1, label + ": empty cmdline")
    return data[:-1].decode("utf8", "strict").split("\0")


def evaluate_observation(e, raw):
    entries = e["commands"]
    rows = {item["label"]: item for item in entries}
    demand(len(rows) == len(entries), "duplicate command label")
    demand(e["scenario"] == "different-workroots" and e["business_complete"] is True and
           e["status"] == "observed-awaiting-oracle", "business observation incomplete")
    demand(e["artifact_manifest_sha256"] == I3_SHA and
           e["inputs"]["build_id"] == BUILD_ID and e["inputs"]["image_id"] == ORIGINAL,
           "wrong original I3 input")
    order = [item["label"] for item in entries]
    stages = ["original-inventory", "qa-inventory", "gate-availability", "validate", "start",
              "backup", "source-stat", "source-hash-before", "stop-center", "center-final"]
    for slot in ("a", "b"):
        stages.extend((f"{slot}-work-absent", f"verify-{slot}-client", f"{slot}-before-inspect",
                       f"{slot}-gate-ready", f"{slot}-gate-held", f"{slot}-initial-inspect",
                       f"{slot}-initial-fd-stat", f"{slot}-initial-status"))
    stages.extend(("a-dual-inspect", "a-dual-fd-stat", "a-dual-status",
                   "b-dual-inspect", "b-dual-fd-stat", "b-dual-status", "release-a",
                   "a-final-inspect", "a-final-logs", "a-final-status",
                   "b-release-still-absent", "b-after-a-inspect", "b-after-a-fd-stat",
                   "b-after-a-status", "release-b", "b-final-inspect", "b-final-logs",
                   "b-final-status", "a-after-b-inspect", "a-after-b-status",
                   "source-hash-final", "a-events", "b-events"))
    demand(all(label in rows for label in stages) and
           [order.index(label) for label in stages] == sorted(order.index(label) for label in stages),
           "missing or misordered scenario stages")

    def row(label, code=0):
        item = rows[label]
        demand(item["returncode"] == code and item.get("observation_expired") is False,
               label + ": wrong client exit or expired observation")
        return item

    def out(label, stream="stdout"):
        data = raw.get((label, stream))
        demand(isinstance(data, bytes), label + ": missing raw " + stream)
        return data

    def obj(label, code=0):
        row(label, code)
        return one_json(out(label), label)

    def inspect(label, cid):
        row(label)
        value = json.loads(out(label))
        demand(isinstance(value, list) and len(value) == 1 and value[0].get("Id") == cid,
               label + ": wrong exact CID")
        return value[0]

    inventory = {"status": "verified", "buildId": BUILD_ID, "files": 2851,
                 "links": 115, "manifestSha256": e["inputs"]["host_manifest_sha256"],
                 "node": "v24.21.0"}
    demand(obj("original-inventory") == obj("qa-inventory") == inventory,
           "whole original application inventory differs")
    qa = inspect("qa-image-inspect", e["qa_image_id"])
    origin = inspect("inner-image-inspect", e["expected"]["inner_image_id"])
    outer = inspect("outer-product-image", ORIGINAL)
    demand(qa["Id"] != origin["Id"] and
           qa["RootFS"]["Layers"][:len(origin["RootFS"]["Layers"])] == origin["RootFS"]["Layers"] ==
           outer["RootFS"]["Layers"] and
           qa["Config"]["Labels"].get("ai.nemori.omne.qa-fixture") == "offline-parallel/r1" and
           qa["Config"]["User"] == "10001:10001" and
           sorted(qa["Config"]["Env"]) == sorted([*origin["Config"]["Env"],
                 "NODE_OPTIONS=--import=/probe/gate.mjs"]) and
           qa["Config"]["Entrypoint"] == origin["Config"]["Entrypoint"] and
           qa["Config"]["Cmd"] == origin["Config"]["Cmd"], "QA image boundary changed")
    gate = obj("gate-availability")
    demand(gate.get("status") == "pass" and gate.get("uid") == gate.get("gid") == 10001 and
           gate.get("directory", {}).get("mode") == "755" and
           gate.get("file", {}).get("mode") == "444" and
           gate.get("file", {}).get("uid") == gate.get("file", {}).get("gid") == 10001 and
           gate.get("actualSha256") == e["inputs"]["sha256"]["gate"],
           "QA preload not exact/usable")
    control = e["expected"]["control"]
    prefix = ["docker", "exec", "-e", PRIVATE, control, HELPER]
    for label, action in (("validate", "validate"), ("start", "start"),
                          ("backup", "backup"), ("stop-center", "stop")):
        demand(rows[label]["argv"][:len(prefix) + 1] == [*prefix, action],
               label + ": not official private helper")
    demand(sum(item["argv"][:len(prefix) + 1] == [*prefix, "stop"] for item in entries) == 1,
           "source center stopped other than once")
    center = e["center_id"]
    demand(HEX64.fullmatch(center), "center CID invalid")
    start, backup, stop = obj("start"), obj("backup"), obj("stop-center")
    center_final = inspect("center-final", center)
    demand(start.get("containerId") == center and
           start.get("imageId") == e["expected"]["inner_image_id"] and
           start.get("state") == "running" and start.get("health") == "healthy" and
           backup.get("status") == "completed" and
           stop.get("containerId") == center and stop.get("clean") is True and
           stop.get("exitCode") == 0 and stop.get("state") == "stopped" and
           center_final["State"]["Status"] == "exited" and
           center_final["State"]["ExitCode"] == 0,
           "source backup/center settlement not real")
    metadata = backup["backup"]["metadata"]
    demand(isinstance(metadata, dict) and metadata.get("format") == "omne-center-backup/1" and
           metadata.get("sourceBuildId") == BUILD_ID,
           "source metadata invalid")
    source = e["source"]
    demand(source == "/var/lib/omne-tenancy/state/backups/" + backup["backup"]["fileName"] and
           re.fullmatch(r"/var/lib/omne-tenancy/state/backups/[0-9a-f]{32}\.omne-backup", source),
           "source not named completed backup")
    source_stat = stat(out("source-stat"), "source-stat", "regular file", 4)
    row("source-stat")
    demand(source_stat[:3] == (10001, 10001, 600) and source_stat[3] > 0,
           "source backup ownership/mode/size")
    for label in ("source-hash-before", "source-hash-final"):
        row(label)
    demand(out("source-hash-before") == out("source-hash-final") and
           source.encode() in out("source-hash-final"), "source backup changed")
    slots = e["slots"]
    demand(set(slots) == {"a", "b"}, "two slots required")
    ids = [slots[s]["cid"] for s in ("a", "b")]
    names = [slots[s]["name"] for s in ("a", "b")]
    demand(all(HEX64.fullmatch(cid) and cid != center for cid in ids) and
           len(set(ids)) == 2 and len(set(names)) == 2, "task identity shared/recreated")
    midpoint = e["dual_midpoint"]
    demand(midpoint["a_pending"] is True and midpoint["b_pending"] is True and
           midpoint["a_stdout_bytes"] == midpoint["b_stdout_bytes"] == 0 and
           midpoint["monotonic_ns"] - slots["b"]["held_monotonic_ns"] >= 31_000_000_000 and
           slots["a"]["held_monotonic_ns"] <= slots["b"]["held_monotonic_ns"] and
           e["release_a_monotonic_ns"] > midpoint["monotonic_ns"] and
           e["after_a"]["b_pending"] is True and e["after_a"]["b_stdout_bytes"] == 0 and
           e["after_a"]["monotonic_ns"] > e["release_a_monotonic_ns"] and
           e["release_b_monotonic_ns"] > e["after_a"]["monotonic_ns"],
           "concurrent hold/release ordering not proved")
    for label, command in (("release-a", "touch"), ("release-b", "touch")):
        row(label)
        slot = label[-1]
        demand(rows[label]["argv"] ==
               ["docker", "exec", control, command,
                "/var/lib/omne-tenancy/state/qa/" + slot + "/release"],
               label + ": did not release exact gate")
    row("b-release-still-absent")
    demand(rows["b-release-still-absent"]["argv"] ==
           ["docker", "exec", control, "test", "!", "-e",
            "/var/lib/omne-tenancy/state/qa/b/release"],
           "B gate was not checked before release")
    fd_ids = []
    root_ids = []
    verified_bytes = {}
    for slot in ("a", "b"):
        entry = slots[slot]
        cid, name = entry["cid"], entry["name"]
        work = "/var/lib/omne-tenancy/state/offline-work/" + e["expected"]["project"] + "-" + slot
        in_app = "/state/offline-work/" + e["expected"]["project"] + "-" + slot
        demand(entry["work"] == work and entry["marker"] == work + "/.omne-isolated" and
               re.fullmatch(r"omne-" + re.escape(e["expected"]["project"]) +
                            r"-verify-[0-9a-f]{16}", name), slot + ": wrong work/name")
        for label in (f"{slot}-work-absent", f"{slot}-gate-held-absent",
                      f"{slot}-gate-release-absent"):
            row(label)
        for label, path in ((f"{slot}-work-absent", work),
                            (f"{slot}-gate-held-absent", "/var/lib/omne-tenancy/state/qa/" + slot + "/held"),
                            (f"{slot}-gate-release-absent", "/var/lib/omne-tenancy/state/qa/" + slot + "/release")):
            demand(rows[label]["argv"] == ["docker", "exec", control, "test", "!", "-e", path],
                   label + ": wrong absence path")
        client = f"verify-{slot}-client"
        wrapper = rows[client]["argv"]
        expected_wrapper = ["docker", "exec", "-e", PRIVATE, control, "sh", "-c",
                            'printf "%s\\n" "$$" > "$1"; shift; exec "$@"', "sh"]
        demand(wrapper[:len(expected_wrapper)] == expected_wrapper and
               wrapper[len(expected_wrapper)] ==
               "/run/" + e["expected"]["project"] + "-verify-" + slot + ".pid" and
               wrapper[len(expected_wrapper) + 1:len(expected_wrapper) + 3] == [HELPER, "verify"] and
               wrapper.count("--project") == wrapper.count("--image") ==
               wrapper.count("--source") == wrapper.count("--work-dir") ==
               wrapper.count("--state-dir") == wrapper.count("--uid") ==
               wrapper.count("--gid") == 1 and
               wrapper[wrapper.index("--project") + 1] == e["expected"]["project"] and
               wrapper[wrapper.index("--image") + 1] == e["qa_image_id"] and
               wrapper[wrapper.index("--state-dir") + 1] == e["expected"]["state"] and
               wrapper[wrapper.index("--source") + 1] == source and
               wrapper[wrapper.index("--work-dir") + 1] == work and
               wrapper[wrapper.index("--uid") + 1] == "10001" and
               wrapper[wrapper.index("--gid") + 1] == "10001" and
               "--secrets-dir" not in wrapper and "--settings-file" not in wrapper,
               slot + ": helper not original offline verify")
        stderr = out(client, "stderr")
        created = re.findall(rb"maintenance-created name=([^\s]+) container=([0-9a-f]{64})", stderr)
        demand(created == [(name.encode(), cid.encode())] and
               stderr.count(("maintenance-finished container=" + cid +
                             " exit=0 interrupted=false").encode()) == 1 and
               all(other.encode() not in stderr for other in ids if other != cid),
               slot + ": helper identity/final result mixed")
        ready = entry["offline_ready"]
        demand(ready["cid"] == cid and ready["monotonic_ns"] <= entry["held_monotonic_ns"],
               slot + ": created event alone is not offline_ready")
        pid = entry["helper_pid"]
        demand(type(pid) is int and pid > 1 and int(out(ready["pid_label"]).strip()) == pid,
               slot + ": helper pidfile invalid")
        row(ready["pid_label"])
        probe_cmd = row(ready["proc_label"])["argv"]
        demand(probe_cmd[:6] == ["docker", "exec", control, "node", "--input-type=module", "-e"] and
               len(probe_cmd) == 8 and probe_cmd[-1] == str(pid) and
               hashlib.sha256(probe_cmd[-2].encode()).hexdigest() ==
               e["inputs"]["sha256"]["proc_probe"], slot + ": wrong exact PID probe")
        probe = obj(ready["proc_label"])
        helper_args = proc_argv(probe["helperCmdlineBase64"], slot + " helper")
        demand(probe["pid"] == pid and probe["helperArgv"] == helper_args and
               len(helper_args) >= 3 and pathlib.PurePosixPath(helper_args[0]).name == "bash" and
               helper_args[1:3] == [HELPER, "verify"], slot + ": not actual inner helper")
        children_raw = base64.b64decode(probe["childrenRawBase64"], validate=True)
        tokens = children_raw.decode("ascii", "strict").split()
        demand(all(token.isdigit() and int(token) > 0 for token in tokens) and
               len(set(tokens)) == len(tokens) and
               [child["pid"] for child in probe["children"]] == [int(token) for token in tokens],
               slot + ": direct /proc children mismatch")
        waiters = []
        for child in probe["children"]:
            args = proc_argv(child["cmdlineBase64"], slot + " child")
            demand(args == child["argv"], slot + ": child cmdline false")
            if len(args) == 3 and pathlib.PurePosixPath(args[0]).name == "docker" and args[1:] == ["wait", cid]:
                waiters.append(child["pid"])
        demand(waiters == [entry["wait_pid"]], slot + ": exact CID wait child absent")
        held = obj(f"{slot}-gate-held")
        demand(obj(f"{slot}-gate-ready") == {"stage": "ready", "project": e["expected"]["project"],
                                             "slot": slot, "workDir": in_app, "pid": 1} and
               held == entry["held"] and held.get("stage") == "offline-import-write" and
               held.get("slot") == slot and held.get("workDir") == in_app and
               held.get("pid") == 1 and type(held.get("fd")) is int and held["fd"] >= 0 and
               re.fullmatch(re.escape(in_app) + r"/task-[0-9a-f]{32}/snapshot\.sqlite",
                            held.get("path", "")) and
               type(held.get("dev")) is int and type(held.get("ino")) is int,
               slot + ": gate did not hold actual slot FileHandle")
        stages = ("initial", "dual", "after-a") if slot == "b" else ("initial", "dual")
        initial = inspect(f"{slot}-before-inspect", cid)
        running = [initial]
        for stage in stages:
            prefix_label = f"{slot}-{stage}"
            running.append(inspect(prefix_label + "-inspect", cid))
            row(prefix_label + "-fd-readlink")
            demand(out(prefix_label + "-fd-readlink").strip().decode() == held["path"],
                   slot + ": FileHandle link changed")
            fd_stat = numbers(out(prefix_label + "-fd-stat"), prefix_label + "-fd-stat", 5)
            row(prefix_label + "-fd-stat")
            demand(fd_stat == (held["dev"], held["ino"], 10001, 10001, 600),
                   slot + ": FileHandle inode/owner/mode changed")
            marker = stat(out(prefix_label + "-marker-stat"), prefix_label + "-marker-stat",
                          "regular file", 6)
            row(prefix_label + "-marker-stat")
            demand(marker[2:] == (10001, 10001, 600, len(MARKER_CONTENT)) and
                   out(prefix_label + "-marker-content") == MARKER_CONTENT,
                   slot + ": marker not private/exact")
            row(prefix_label + "-marker-content")
            root = stat(out(prefix_label + "-work-stat"), prefix_label + "-work-stat",
                        "directory", 5)
            row(prefix_label + "-work-stat")
            demand(root[2:] == (10001, 10001, 700), slot + ": workRoot not private")
            lock = out(prefix_label + "-lock-stat").decode("ascii", "strict").strip().split(":")
            row(prefix_label + "-lock-stat")
            demand(len(lock) == 4 and lock[0] in ("regular file", "regular empty file") and
                   lock[1:3] == ["10001", "10001"] and lock[3].isdigit(),
                   slot + ": actual owner lock absent/foreign")
            status = obj(prefix_label + "-status")
            demand(rows[prefix_label + "-status"]["argv"] ==
                   [*prefix, "maintenance-status", "--project", e["expected"]["project"],
                    "--container-id", cid] and
                   status == {"containerId": cid, "imageId": e["qa_image_id"],
                              "action": "verify", "state": "running", "exitCode": None,
                              "outputText": ""}, slot + ": status no longer exact/running")
            if stage == "initial":
                marker_initial, root_initial = marker, root
            else:
                demand(marker == marker_initial and root == root_initial,
                       slot + ": marker/workRoot inode changed while held")
        for state in running:
            demand(state["Name"] == "/" + name and
                   state["Config"]["Labels"].get("ai.nemori.omne.project") ==
                   e["expected"]["project"] and
                   state["Config"]["Labels"].get("ai.nemori.omne.action") == "verify" and
                   state["Config"]["Labels"].get("ai.nemori.omne.service") == "maintenance" and
                   state["Image"] == e["qa_image_id"] and
                   state["Config"]["User"] == "10001:10001" and
                   state["Config"]["StopSignal"] == "SIGTERM" and
                   state["HostConfig"]["RestartPolicy"]["Name"] == "no" and
                   state["HostConfig"]["NetworkMode"] == "none" and
                   len(state["Mounts"]) == 1 and state["Mounts"][0]["Type"] == "bind" and
                   state["Mounts"][0]["Destination"] == "/state" and
                   state["Mounts"][0]["Source"] == e["expected"]["state"] and
                   state["State"]["Status"] == "running" and state["State"]["Pid"] > 0 and
                   state["State"]["Pid"] == initial["State"]["Pid"] and
                   state["State"]["StartedAt"] == initial["State"]["StartedAt"],
                   slot + ": original task owner changed/ended")
        fd_ids.append((held["dev"], held["ino"]))
        root_ids.append(root_initial[:2])
        final = inspect(f"{slot}-final-inspect", cid)
        demand(final["Name"] == "/" + name and final["Image"] == e["qa_image_id"] and
               final["State"]["Status"] == "exited" and final["State"]["ExitCode"] == 0 and
               final["State"]["StartedAt"] == initial["State"]["StartedAt"],
               slot + ": app not same exited0 task")
        row(client)
        result = obj(client)
        demand(result == {"status": "verified", "metadata": metadata,
                          "businessOpen": False}, slot + ": actual verify result false/mixed")
        logs = out(f"{slot}-final-logs")
        row(f"{slot}-final-logs")
        demand(logs == out(client), slot + ": client/log output differ")
        final_status = obj(f"{slot}-final-status")
        demand(rows[f"{slot}-final-status"]["argv"] ==
               [*prefix, "maintenance-status", "--project", e["expected"]["project"],
                "--container-id", cid], slot + ": final status not exact task")
        demand(final_status == {"containerId": cid, "imageId": e["qa_image_id"],
                                "action": "verify", "state": "exited", "exitCode": 0,
                                "outputText": out(client).decode().strip()},
               slot + ": retained status/output mixed")
        verified_bytes[slot] = out(client)
        final_marker = stat(out(f"{slot}-final-marker-stat"), f"{slot}-final-marker-stat",
                            "regular file", 6)
        final_root = stat(out(f"{slot}-final-work-stat"), f"{slot}-final-work-stat",
                          "directory", 5)
        for label in (f"{slot}-final-marker-stat", f"{slot}-final-marker-content",
                      f"{slot}-final-work-stat", f"{slot}-import-file-absent"):
            row(label)
        demand(rows[f"{slot}-import-file-absent"]["argv"] ==
               ["docker", "exec", control, "test", "!", "-e",
                "/var/lib/omne-tenancy" + held["path"]],
               slot + ": import plaintext absence not checked")
        demand(final_marker == marker_initial and final_root == root_initial and
               out(f"{slot}-final-marker-content") == MARKER_CONTENT,
               slot + ": private workRoot/marker changed at completion")
        row(f"{slot}-events")
        event_argv = rows[f"{slot}-events"]["argv"]
        demand(f"container={cid}" in event_argv, slot + ": events not exact CID")
        events = [json.loads(line) for line in out(f"{slot}-events").splitlines() if line.strip()]
        demand(not any(event.get("Action") == "kill" and
                       event.get("Actor", {}).get("ID") == cid for event in events),
               slot + ": task received a kill signal")
    demand(len(set(fd_ids)) == 2 and len(set(root_ids)) == 2,
           "two tasks did not hold distinct FileHandles/workRoots")
    # Both verifications are allowed to have identical JSON because they read the same source.
    # Identity separation is through exact caller, task CID, logs and status, not different payloads.
    a_after_b = inspect("a-after-b-inspect", slots["a"]["cid"])
    a_final = inspect("a-final-inspect", slots["a"]["cid"])
    demand(a_after_b["Name"] == "/" + slots["a"]["name"] and
           a_after_b["Image"] == e["qa_image_id"] and
           a_after_b["State"]["Status"] == "exited" and
           a_after_b["State"]["ExitCode"] == 0 and
           a_after_b["State"]["StartedAt"] == a_final["State"]["StartedAt"],
           "B completion restarted or changed A task")
    demand(rows["a-after-b-status"]["argv"] ==
           [*prefix, "maintenance-status", "--project", e["expected"]["project"],
            "--container-id", slots["a"]["cid"]],
           "A after B status not exact task")
    demand(obj("a-after-b-status") ==
           {"containerId": slots["a"]["cid"], "imageId": e["qa_image_id"],
            "action": "verify", "state": "exited", "exitCode": 0,
            "outputText": verified_bytes["a"].decode().strip()},
           "B completion replaced A task/status")
    demand(e.get("cleanup_complete") is True and not e.get("cleanup_errors") and
           not e.get("independent_host_errors"), "fixture cleanup incomplete")
    for kind in ("container", "network", "volume"):
        label = "independent-host-" + kind
        row(label)
        demand(out(label).strip() == b"", "host exact-label resources remain: " + kind)
    return {"status": "limited_pass", "scenario": "different-workroots",
            "container_ids": ids,
            "both_held_seconds": (midpoint["monotonic_ns"] - slots["b"]["held_monotonic_ns"]) / 1e9,
            "source_sha256": out("source-hash-final").decode().split()[0]}


def evaluate(run):
    e = json.loads((run / "evidence.json").read_text())
    for name in ("driver.py", "base_driver.py", "oracle.py", "gate.mjs", "inventory.mjs",
                 "gate_availability.mjs", "proc_probe.mjs", "i3-manifest.json"):
        key = name.removesuffix(".py").removesuffix(".mjs")
        expected = I3_SHA if name == "i3-manifest.json" else e["inputs"]["sha256"][key]
        demand(hashlib.sha256((run / "inputs" / name).read_bytes()).hexdigest() == expected,
               "frozen input changed: " + name)
    raw = {}
    for item in e["commands"]:
        for stream in ("stdout", "stderr"):
            path = run / item[stream]
            demand(path.is_file() and path.parent == run / "raw", "missing raw " + item["label"])
            raw[item["label"], stream] = path.read_bytes()
    return evaluate_observation(e, raw)


if __name__ == "__main__":
    try:
        print(json.dumps(evaluate(pathlib.Path(sys.argv[1])), sort_keys=True))
    except (KeyError, ValueError, TypeError, IndexError, OSError, UnicodeError,
            json.JSONDecodeError) as error:
        print(json.dumps({"status": "unverified", "error": f"{type(error).__name__}: {error}"},
                         sort_keys=True))
        raise SystemExit(1)
