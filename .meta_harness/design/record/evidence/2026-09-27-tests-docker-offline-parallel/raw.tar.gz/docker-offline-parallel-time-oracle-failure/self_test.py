#!/usr/bin/env python3
"""Offline positive and adversarial mutations for the parallel oracle."""

import ast
import base64
import copy
import hashlib
import json
from pathlib import Path

import oracle

HERE = Path(__file__).parent


def j(value):
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def argv_bytes(words):
    return ("\0".join(words) + "\0").encode()


def shell_source():
    tree = ast.parse((HERE / "driver.py").read_text())
    values = [node.value.value for node in ast.walk(tree) if isinstance(node, ast.Assign) and
              any(isinstance(target, ast.Name) and target.id == "shell" for target in node.targets)
              and isinstance(node.value, ast.Constant)]
    assert len(values) == 1
    return values[0]


def fixture():
    project = "r5abcd"
    center = "a" * 64
    cids = {"a": "b" * 64, "b": "c" * 64}
    qa_id = "sha256:" + "d" * 64
    source = "/var/lib/omne-tenancy/state/backups/" + "e" * 32 + ".omne-backup"
    state = "/var/lib/omne-tenancy/state"
    control = "omne-r5-test-control"
    prefix = ["docker", "exec", "-e", oracle.PRIVATE, control, oracle.HELPER]
    labels = ["original-inventory", "qa-inventory", "gate-availability", "validate", "start",
              "backup", "source-stat", "source-hash-before", "stop-center", "center-final"]
    for slot in ("a", "b"):
        labels.extend((f"{slot}-work-absent", f"{slot}-gate-held-absent",
                       f"{slot}-gate-release-absent", f"verify-{slot}-client",
                       f"{slot}-before-inspect", f"{slot}-helper-pid-1",
                       f"{slot}-helper-proc-1", f"{slot}-gate-ready",
                       f"{slot}-gate-held"))
        labels.extend(f"{slot}-initial-{kind}" for kind in
                      ("inspect", "fd-readlink", "fd-stat", "marker-stat", "marker-content",
                       "work-stat", "lock-stat", "status"))
    for slot in ("a", "b"):
        labels.extend(f"{slot}-dual-{kind}" for kind in
                      ("inspect", "fd-readlink", "fd-stat", "marker-stat", "marker-content",
                       "work-stat", "lock-stat", "status"))
    labels.append("release-a")
    labels.extend("a-final-" + suffix for suffix in
                  ("inspect", "logs", "status", "marker-stat", "marker-content", "work-stat"))
    labels.extend(("a-import-file-absent", "b-release-still-absent"))
    labels.extend("b-after-a-" + suffix for suffix in
                  ("inspect", "fd-readlink", "fd-stat", "marker-stat", "marker-content",
                   "work-stat", "lock-stat", "status"))
    labels.append("release-b")
    labels.extend("b-final-" + suffix for suffix in
                  ("inspect", "logs", "status", "marker-stat", "marker-content", "work-stat"))
    labels.extend(("b-import-file-absent", "a-after-b-inspect", "a-after-b-status",
                   "source-hash-final", "a-events", "b-events", "qa-image-inspect",
                   "inner-image-inspect", "outer-product-image", "independent-host-container",
                   "independent-host-network", "independent-host-volume"))
    rows = [{"label": label, "argv": [], "returncode": 0, "observation_expired": False}
            for label in labels]
    by = {item["label"]: item for item in rows}
    raw = {(label, stream): b"" for label in labels for stream in ("stdout", "stderr")}

    def put(label, value, stream="stdout"):
        raw[label, stream] = value if isinstance(value, bytes) else j(value)

    inventory = {"status": "verified", "buildId": oracle.BUILD_ID, "files": 2851,
                 "links": 115, "manifestSha256": "f" * 64, "node": "v24.21.0"}
    put("original-inventory", inventory)
    put("qa-inventory", inventory)
    put("gate-availability", {"status": "pass", "uid": 10001, "gid": 10001,
                              "directory": {"mode": "755"},
                              "file": {"mode": "444", "uid": 10001, "gid": 10001},
                              "actualSha256": "1" * 64})
    origin = {"Id": oracle.ORIGINAL, "RootFS": {"Layers": ["original-layer"]},
              "Config": {"Env": [], "Entrypoint": ["node"], "Cmd": ["cli"]}}
    qa = copy.deepcopy(origin)
    qa["Id"] = qa_id
    qa["RootFS"]["Layers"].append("qa-layer")
    qa["Config"].update({"User": "10001:10001",
                         "Env": ["NODE_OPTIONS=--import=/probe/gate.mjs"],
                         "Labels": {"ai.nemori.omne.qa-fixture": "offline-parallel/r1"}})
    for label, value in (("qa-image-inspect", qa), ("inner-image-inspect", origin),
                         ("outer-product-image", origin)):
        put(label, [value])
    for label, action in (("validate", "validate"), ("start", "start"),
                          ("backup", "backup"), ("stop-center", "stop")):
        by[label]["argv"] = [*prefix, action]
    by["release-a"]["argv"] = ["docker", "exec", control, "touch", state + "/qa/a/release"]
    by["release-b"]["argv"] = ["docker", "exec", control, "touch", state + "/qa/b/release"]
    by["b-release-still-absent"]["argv"] = ["docker", "exec", control,
                                              "test", "!", "-e", state + "/qa/b/release"]
    put("start", {"containerId": center, "imageId": oracle.ORIGINAL,
                  "state": "running", "health": "healthy"})
    metadata = {"format": "omne-center-backup/1", "sourceBuildId": oracle.BUILD_ID,
                "sha256": "9" * 64}
    put("backup", {"status": "completed", "backup": {"fileName": "e" * 32 + ".omne-backup",
                                                    "metadata": metadata}})
    put("stop-center", {"containerId": center, "clean": True,
                        "exitCode": 0, "state": "stopped"})
    put("center-final", [{"Id": center, "State": {"Status": "exited", "ExitCode": 0}}])
    put("source-stat", b"regular file:10001:10001:600:1000\n")
    original_hash = ("1" * 64 + "  " + source + "\n").encode()
    put("source-hash-before", original_hash)
    put("source-hash-final", original_hash)
    probe_source = (HERE / "proc_probe.mjs").read_text()
    slots = {}

    def container(cid, name, running):
        return {"Id": cid, "Name": "/" + name, "Image": qa_id,
                "Config": {"User": "10001:10001", "StopSignal": "SIGTERM",
                           "Labels": {"ai.nemori.omne.project": project,
                                      "ai.nemori.omne.action": "verify",
                                      "ai.nemori.omne.service": "maintenance"}},
                "HostConfig": {"RestartPolicy": {"Name": "no"}, "NetworkMode": "none"},
                "Mounts": [{"Type": "bind", "Destination": "/state", "Source": state}],
                "State": {"Status": "running" if running else "exited",
                          "Pid": 201 if running else 0,
                          "StartedAt": "same-creation-" + cid[:1],
                          "ExitCode": None if running else 0}}

    for index, slot in enumerate(("a", "b"), 1):
        cid = cids[slot]
        name = f"omne-{project}-verify-" + str(index) * 16
        work = state + "/offline-work/" + project + "-" + slot
        in_app = "/state/offline-work/" + project + "-" + slot
        path = in_app + "/task-" + str(index) * 32 + "/snapshot.sqlite"
        held = {"stage": "offline-import-write", "slot": slot, "workDir": in_app,
                "path": path, "fd": 17 + index, "pid": 1, "dev": 1, "ino": 30 + index}
        for label, target in ((f"{slot}-work-absent", work),
                              (f"{slot}-gate-held-absent", state + "/qa/" + slot + "/held"),
                              (f"{slot}-gate-release-absent", state + "/qa/" + slot + "/release")):
            by[label]["argv"] = ["docker", "exec", control, "test", "!", "-e", target]
        pid = 200 + index * 10
        wait_pid = pid + 1
        client = f"verify-{slot}-client"
        by[client]["argv"] = ["docker", "exec", "-e", oracle.PRIVATE, control,
                              "sh", "-c", shell_source(), "sh",
                              f"/run/{project}-verify-{slot}.pid", oracle.HELPER, "verify",
                              "--project", project, "--image", qa_id,
                              "--state-dir", state, "--source", source,
                              "--work-dir", work, "--uid", "10001", "--gid", "10001"]
        verified = {"status": "verified", "metadata": metadata, "businessOpen": False}
        put(client, verified)
        put(client, (f"omne-center: maintenance-created name={name} container={cid}\n"
                     f"omne-center: maintenance-finished container={cid} exit=0 interrupted=false\n").encode(),
            "stderr")
        pid_label = f"{slot}-helper-pid-1"
        proc_label = f"{slot}-helper-proc-1"
        put(pid_label, f"{pid}\n".encode())
        by[proc_label]["argv"] = ["docker", "exec", control, "node", "--input-type=module",
                                  "-e", probe_source, str(pid)]
        helper_args = ["bash", oracle.HELPER, "verify", "--project", project]
        waiter_args = ["docker", "wait", cid]
        put(proc_label, {"pid": pid,
                         "helperCmdlineBase64": base64.b64encode(argv_bytes(helper_args)).decode(),
                         "helperArgv": helper_args,
                         "childrenRawBase64": base64.b64encode(f"{wait_pid} ".encode()).decode(),
                         "children": [{"pid": wait_pid,
                                       "cmdlineBase64": base64.b64encode(argv_bytes(waiter_args)).decode(),
                                       "argv": waiter_args}]})
        put(f"{slot}-gate-ready", {"stage": "ready", "project": project, "slot": slot,
                                   "workDir": in_app, "pid": 1})
        put(f"{slot}-gate-held", held)
        put(f"{slot}-before-inspect", [container(cid, name, True)])
        for stage in (("initial", "dual", "after-a") if slot == "b" else ("initial", "dual")):
            name_prefix = f"{slot}-{stage}"
            put(name_prefix + "-inspect", [container(cid, name, True)])
            put(name_prefix + "-fd-readlink", (path + "\n").encode())
            put(name_prefix + "-fd-stat", f"1:{30+index}:10001:10001:600\n".encode())
            put(name_prefix + "-marker-stat",
                f"regular file:1:{20+index}:10001:10001:600:16\n".encode())
            put(name_prefix + "-marker-content", oracle.MARKER_CONTENT)
            put(name_prefix + "-work-stat",
                f"directory:1:{10+index}:10001:10001:700\n".encode())
            put(name_prefix + "-lock-stat", b"regular empty file:10001:10001:644\n")
            put(name_prefix + "-status", {"containerId": cid, "imageId": qa_id,
                                         "action": "verify", "state": "running",
                                         "exitCode": None, "outputText": ""})
            by[name_prefix + "-status"]["argv"] = [*prefix, "maintenance-status", "--project",
                                                   project, "--container-id", cid]
        put(f"{slot}-final-inspect", [container(cid, name, False)])
        put(f"{slot}-final-logs", verified)
        put(f"{slot}-final-status", {"containerId": cid, "imageId": qa_id,
                                     "action": "verify", "state": "exited", "exitCode": 0,
                                     "outputText": j(verified).decode().strip()})
        by[f"{slot}-final-status"]["argv"] = [*prefix, "maintenance-status", "--project",
                                               project, "--container-id", cid]
        put(f"{slot}-final-marker-stat",
            f"regular file:1:{20+index}:10001:10001:600:16\n".encode())
        put(f"{slot}-final-marker-content", oracle.MARKER_CONTENT)
        put(f"{slot}-final-work-stat",
            f"directory:1:{10+index}:10001:10001:700\n".encode())
        by[f"{slot}-import-file-absent"]["argv"] = ["docker", "exec", control,
                                                      "test", "!", "-e",
                                                      "/var/lib/omne-tenancy" + path]
        by[f"{slot}-events"]["argv"] = ["docker", "exec", control, "docker", "--host",
                                         oracle.PRIVATE.removeprefix("DOCKER_HOST="),
                                         "events", "--filter", f"container={cid}"]
        slots[slot] = {"work": work, "marker": work + "/.omne-isolated",
                       "name": name, "cid": cid, "helper_pid": pid, "wait_pid": wait_pid,
                       "offline_ready": {"cid": cid, "monotonic_ns": index * 1_000_000_000,
                                         "pid_label": pid_label, "proc_label": proc_label},
                       "held_monotonic_ns": index * 1_000_000_000,
                       "held": held}
    put("a-after-b-inspect", [container(cids["a"], slots["a"]["name"], False)])
    put("a-after-b-status", {"containerId": cids["a"], "imageId": qa_id,
                             "action": "verify", "state": "exited", "exitCode": 0,
                             "outputText": j(verified).decode().strip()})
    by["a-after-b-status"]["argv"] = [*prefix, "maintenance-status", "--project",
                                       project, "--container-id", cids["a"]]
    e = {"commands": rows, "scenario": "different-workroots", "business_complete": True,
         "status": "observed-awaiting-oracle", "artifact_manifest_sha256": oracle.I3_SHA,
         "inputs": {"build_id": oracle.BUILD_ID, "image_id": oracle.ORIGINAL,
                    "host_manifest_sha256": "f" * 64,
                    "sha256": {"gate": "1" * 64,
                               "proc_probe": hashlib.sha256(probe_source.encode()).hexdigest()}},
         "qa_image_id": qa_id,
         "expected": {"inner_image_id": oracle.ORIGINAL, "control": control,
                      "state": state, "project": project},
         "center_id": center, "source": source, "slots": slots,
         "dual_midpoint": {"monotonic_ns": 34_000_000_000, "a_pending": True,
                           "b_pending": True, "a_stdout_bytes": 0, "b_stdout_bytes": 0},
         "release_a_monotonic_ns": 35_000_000_000,
         "after_a": {"monotonic_ns": 36_000_000_000, "b_pending": True,
                     "b_stdout_bytes": 0},
         "release_b_monotonic_ns": 37_000_000_000,
         "cleanup_complete": True, "cleanup_errors": []}
    return e, raw


def main():
    baseline = fixture()
    assert oracle.evaluate_observation(*baseline)["status"] == "limited_pass"
    alternate = copy.deepcopy(baseline)
    for slot in ("a", "b"):
        for stage in (("initial", "dual", "after-a") if slot == "b" else ("initial", "dual")):
            alternate[1][f"{slot}-{stage}-lock-stat", "stdout"] = \
                b"regular empty file:10001:10001:600\n"
    assert oracle.evaluate_observation(*alternate)["status"] == "limited_pass"
    cases = {
        "duplicate-cid": lambda e, r: e["slots"]["b"].__setitem__("cid", e["slots"]["a"]["cid"]),
        "duplicate-name": lambda e, r: e["slots"]["b"].__setitem__("name", e["slots"]["a"]["name"]),
        "same-workroot": lambda e, r: e["slots"]["b"].__setitem__("work", e["slots"]["a"]["work"]),
        "cross-slot-gate": lambda e, r: r.__setitem__(("b-gate-held", "stdout"), r["a-gate-held", "stdout"]),
        "same-file-inode": lambda e, r: e["slots"]["b"]["held"].__setitem__("ino", e["slots"]["a"]["held"]["ino"]),
        "wrong-task-name": lambda e, r: r.__setitem__(("b-dual-inspect", "stdout"), r["a-dual-inspect", "stdout"]),
        "short-hold": lambda e, r: e["dual_midpoint"].__setitem__("monotonic_ns", 32_000_000_000),
        "a-client-ended": lambda e, r: e["dual_midpoint"].__setitem__("a_pending", False),
        "b-client-ended-after-a": lambda e, r: e["after_a"].__setitem__("b_pending", False),
        "b-output-after-a": lambda e, r: e["after_a"].__setitem__("b_stdout_bytes", 20),
        "b-release-early": lambda e, r: next(x for x in e["commands"] if x["label"] == "b-release-still-absent").__setitem__("returncode", 1),
        "release-wrong-slot": lambda e, r: next(x for x in e["commands"] if x["label"] == "release-a")["argv"].__setitem__(-1, "/var/lib/omne-tenancy/state/qa/b/release"),
        "b-status-ended-after-a": lambda e, r: r.__setitem__(("b-after-a-status", "stdout"), r["b-final-status", "stdout"]),
        "b-inode-changed-after-a": lambda e, r: r.__setitem__(("b-after-a-fd-stat", "stdout"), b"1:99:10001:10001:600\n"),
        "b-marker-gone-after-a": lambda e, r: r.__setitem__(("b-after-a-marker-content", "stdout"), b""),
        "b-workroot-not-private": lambda e, r: r.__setitem__(("b-dual-work-stat", "stdout"), b"directory:1:12:10001:10001:755\n"),
        "a-early-exit": lambda e, r: r.__setitem__(("a-dual-inspect", "stdout"), r["a-final-inspect", "stdout"]),
        "wrong-b-wait-cid": lambda e, r: r.__setitem__(("b-helper-proc-1", "stdout"), r["a-helper-proc-1", "stdout"]),
        "wrong-b-helper-pid": lambda e, r: e["slots"]["b"].__setitem__("helper_pid", 999),
        "wrong-b-client-cid": lambda e, r: r.__setitem__(("b-final-status", "stdout"), r["a-final-status", "stdout"]),
        "b-result-metadata-mismatch": lambda e, r: r.__setitem__(("verify-b-client", "stdout"), j({"status": "verified", "metadata": {}, "businessOpen": False})),
        "b-result-no-lf": lambda e, r: r.__setitem__(("verify-b-client", "stdout"), r["verify-b-client", "stdout"].rstrip()),
        "status-query-wrong-cid": lambda e, r: next(x for x in e["commands"] if x["label"] == "b-final-status")["argv"].__setitem__(-1, "9" * 64),
        "a-false-business-open": lambda e, r: r.__setitem__(("verify-a-client", "stdout"), j({"status": "verified", "metadata": json.loads(r["backup", "stdout"])["backup"]["metadata"], "businessOpen": True})),
        "a-app-exit-wrong": lambda e, r: r.__setitem__(("a-final-inspect", "stdout"), r["a-dual-inspect", "stdout"]),
        "b-client-rc-wrong": lambda e, r: next(x for x in e["commands"] if x["label"] == "verify-b-client").__setitem__("returncode", 1),
        "source-mutated": lambda e, r: r.__setitem__(("source-hash-final", "stdout"), b"changed\n"),
        "qa-inventory-diff": lambda e, r: r.__setitem__(("qa-inventory", "stdout"), j({"status": "verified"})),
        "cleanup-not-business": lambda e, r: e.__setitem__("business_complete", False),
        "host-leftover": lambda e, r: r.__setitem__(("independent-host-volume", "stdout"), b"leftover\n"),
    }
    refused = []
    for name, mutation in cases.items():
        e, raw = copy.deepcopy(baseline)
        mutation(e, raw)
        try:
            oracle.evaluate_observation(e, raw)
        except (ValueError, KeyError, TypeError, IndexError, json.JSONDecodeError):
            refused.append(name)
        else:
            raise AssertionError("false pass: " + name)
    print(json.dumps({"positive": 2, "negative_refused": len(refused), "cases": refused},
                     sort_keys=True))


if __name__ == "__main__":
    main()
