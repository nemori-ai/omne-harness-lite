// QA-only dual gate. Each real verify process is bound to its own workRoot slot.
import { promises as fs } from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'
import { setTimeout as delay } from 'node:timers/promises'

const control = '/state/qa'

async function installGate() {
  const project = (await fs.readFile(`${control}/project`, 'utf8')).trim()
  if (!/^[a-z0-9][a-z0-9_-]{0,62}$/.test(project)) throw new Error('qa gate: invalid project')
  const words = process.argv.slice(3)
  const matches = words.flatMap((word, index) => word === '--work-dir' ? [index] : [])
  if (matches.length !== 1 || matches[0] + 1 >= words.length) {
    throw new Error('qa gate: exactly one work-dir required')
  }
  const workDir = words[matches[0] + 1]
  const slot = workDir === `/state/offline-work/${project}-a` ? 'a'
    : workDir === `/state/offline-work/${project}-b` ? 'b' : null
  if (slot === null) throw new Error('qa gate: workRoot outside A/B slots')
  const slotControl = `${control}/${slot}`
  const originalOpen = fs.open.bind(fs)
  let attached = false
  fs.open = async (...args) => {
    const handle = await originalOpen(...args)
    const path = String(args[0])
    const prefix = `${workDir}/`
    const taskPath = path.startsWith(prefix) ? path.slice(prefix.length) : ''
    if (attached || !/^task-[0-9a-f]{32}\/snapshot\.sqlite$/.test(taskPath) ||
        args[1] !== 'wx' || args[2] !== 0o600) return handle
    attached = true
    const originalWriteFile = handle.writeFile.bind(handle)
    let first = true
    handle.writeFile = async (...writeArgs) => {
      if (first) {
        first = false
        const info = await handle.stat()
        if (handle.fd < 0 || !info.isFile() || info.uid !== process.getuid() ||
            (info.mode & 0o777) !== 0o600) throw new Error('qa gate: expected owned 0600 FileHandle')
        await fs.writeFile(`${slotControl}/held`, JSON.stringify({
          stage: 'offline-import-write', slot, workDir, path,
          fd: handle.fd, pid: process.pid, dev: info.dev, ino: info.ino,
        }) + '\n', { flag: 'wx', mode: 0o600 })
        for (;;) {
          try {
            await fs.stat(`${slotControl}/release`)
            break
          } catch (error) {
            if (error?.code !== 'ENOENT') throw error
            await delay(50)
          }
        }
      }
      return originalWriteFile(...writeArgs)
    }
    return handle
  }
  syncBuiltinESMExports()
  await fs.writeFile(`${slotControl}/ready`, JSON.stringify({
    stage: 'ready', project, slot, workDir, pid: process.pid,
  }) + '\n', { flag: 'wx', mode: 0o600 })
}

if (process.argv[1] === '/opt/omne/app/dist/cli.js' && process.argv[2] === 'verify') {
  await installGate()
}
