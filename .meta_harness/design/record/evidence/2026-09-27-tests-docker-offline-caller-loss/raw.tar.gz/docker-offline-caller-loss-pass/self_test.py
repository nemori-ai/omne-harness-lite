#!/usr/bin/env python3
"""Offline synthetic oracle mutations; no Docker, product, or credentials."""

import ast
import base64
import copy
import hashlib
import json
from pathlib import Path

import oracle


def j(value):
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def raw_argv(args):
    return ("\0".join(args) + "\0").encode()


def mutate_proc(raw, change):
    data = json.loads(raw["helper-proc-1", "stdout"])
    change(data)
    raw["helper-proc-1", "stdout"] = j(data)


def mutate_object(raw, label, change):
    data = json.loads(raw[label, "stdout"])
    change(data)
    raw[label, "stdout"] = j(data)


def driver_shell():
    tree = ast.parse((Path(__file__).parent / "driver.py").read_text())
    matches = [node.value.value for node in ast.walk(tree)
               if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and
               target.id == "shell" for target in node.targets) and isinstance(node.value, ast.Constant)]
    assert len(matches) == 1
    return matches[0]


def fixture():
    project = "r5abcd"
    center, task, other = (char * 64 for char in "abc")
    qa_id = "sha256:" + "d" * 64
    control = "omne-r5-test-control"
    source = "/var/lib/omne-tenancy/state/backups/" + "e" * 32 + ".omne-backup"
    work = "/var/lib/omne-tenancy/state/offline-work/" + project
    import_path = "/state/offline-work/" + project + "/task-" + "f" * 32 + "/snapshot.sqlite"
    labels = ["original-inventory", "qa-inventory", "gate-availability", "validate", "start",
              "backup", "source-stat", "source-hash-before", "stop-center", "center-final",
              "work-absent", "verify-helper", "offline-before", "helper-pid-1",
              "helper-proc-1", "gate-ready", "gate-held", "fd-readlink", "fd-stat",
              "marker-stat-held", "marker-content-held", "work-stat-held",
              "lock-stat-held", "kill-helper", "helper-absence-1", "helper-absent-mid",
              "offline-held", "fd-readlink-held", "fd-stat-held",
              "marker-stat-mid", "marker-content-mid", "work-stat-mid",
              "offline-status-held", "offline-logs-held",
              "same-work-contender", "contender-final",
              "offline-after-contender", "fd-stat-after-contender", "release-gate",
              "app-wait", "offline-final", "offline-logs-final",
              "offline-status-final", "offline-events",
              "marker-stat-final", "marker-content-final", "work-stat-final",
              "import-file-absent",
              "source-hash-final", "qa-image-inspect", "inner-image-inspect",
              "outer-product-image", "independent-host-container", "independent-host-network",
              "independent-host-volume"]
    rows = [{"label": label, "argv": [], "returncode": 0, "observation_expired": False}
            for label in labels]
    by = {row["label"]: row for row in rows}
    raw = {(label, stream): b"" for label in labels for stream in ("stdout", "stderr")}
    def put(label, value, stream="stdout"):
        raw[label, stream] = value if isinstance(value, bytes) else j(value)
    inventory = {"status": "verified", "buildId": oracle.BUILD_ID, "files": 2851,
                 "links": 115, "manifestSha256": "f" * 64, "node": "v24.21.0"}
    put("original-inventory", inventory)
    put("qa-inventory", inventory)
    put("gate-availability", {"status": "pass", "uid": 10001, "gid": 10001,
                              "directory": {"mode": "755"},
                              "file": {"mode": "444", "uid": 10001, "gid": 10001},
                              "actualSha256": "1" * 64})
    origin = {"Id": oracle.ORIGINAL, "RootFS": {"Layers": ["layer-1"]},
              "Config": {"Env": [], "Entrypoint": ["node"], "Cmd": ["cli"],
                         "Labels": {"ai.nemori.omne.host-build-id": oracle.BUILD_ID}}}
    qa = copy.deepcopy(origin)
    qa["Id"] = qa_id
    qa["RootFS"]["Layers"].append("qa-layer")
    qa["Config"].update({"User": "10001:10001", "Env": ["NODE_OPTIONS=--import=/probe/gate.mjs"],
                         "Labels": {"ai.nemori.omne.qa-fixture": "offline-cancel/r1"}})
    for label, value in (("qa-image-inspect", qa), ("inner-image-inspect", origin),
                         ("outer-product-image", origin)):
        put(label, [value])
    prefix = ["docker", "exec", "-e", oracle.PRIVATE, control, oracle.HELPER]
    for label, action in (("validate", "validate"), ("start", "start"),
                          ("backup", "backup"), ("stop-center", "stop"),
                          ("same-work-contender", "verify"),
                          ("offline-status-held", "maintenance-status"),
                          ("offline-status-final", "maintenance-status")):
        by[label]["argv"] = [*prefix, action]
    by["same-work-contender"]["argv"] += ["--project", project, "--image", oracle.ORIGINAL,
        "--source", source, "--work-dir", work]
    by["same-work-contender"]["returncode"] = 2
    by["verify-helper"]["returncode"] = 137
    by["verify-helper"]["argv"] = ["docker", "exec", "-e", oracle.PRIVATE, control,
        "sh", "-c", driver_shell(), "sh", "/run/helper.pid",
        oracle.HELPER, "verify", "--project", project, "--image", qa_id,
        "--state-dir", "/var/lib/omne-tenancy/state", "--source", source,
        "--work-dir", work, "--uid", "10001", "--gid", "10001"]
    kill_source = (Path(__file__).parent / "kill_helper.mjs").read_text()
    absence_source = (Path(__file__).parent / "pid_absence.mjs").read_text()
    by["kill-helper"]["argv"] = ["docker", "exec", control, "node",
                                  "--input-type=module", "-e", kill_source, "200", task]
    for label in ("helper-absence-1", "helper-absent-mid"):
        by[label]["argv"] = ["docker", "exec", control, "node",
                             "--input-type=module", "-e", absence_source, "200"]
    by["app-wait"]["argv"] = ["docker", "exec", control, "docker", "--host",
                              "unix:///opt/omne-private-docker/docker.sock", "wait", task]
    probe_source = (Path(__file__).parent / "proc_probe.mjs").read_text()
    by["helper-proc-1"]["argv"] = ["docker", "exec", control, "node",
                                    "--input-type=module", "-e", probe_source, "200"]
    put("start", {"containerId": center, "imageId": oracle.ORIGINAL,
                  "state": "running", "health": "healthy"})
    metadata = {"format": "omne-center-backup/1", "centerId": "1" * 32,
                "sourceBuildId": oracle.BUILD_ID, "migrationNames": ["0001_account_identity"],
                "startedAt": "2026-09-26T21:00:00Z", "finishedAt": "2026-09-26T21:00:01Z",
                "byteLength": 1000, "sha256": "2" * 64}
    put("backup", {"status": "completed", "backup": {"fileName": "e" * 32 + ".omne-backup",
                                                     "metadata": metadata}})
    put("stop-center", {"containerId": center, "clean": True,
                        "exitCode": 0, "state": "stopped"})
    put("source-stat", b"regular file:10001:10001:600:1000\n")
    source_hash = ("1" * 64 + "  " + source + "\n").encode()
    put("source-hash-before", source_hash)
    put("source-hash-final", source_hash)
    put("center-final", [{"Id": center, "State": {"Status": "exited", "ExitCode": 0}}])
    name = "omne-" + project + "-verify-" + "1" * 16
    put("verify-helper", b"")
    put("verify-helper", (f"omne-center: maintenance-created name={name} container={task}\n").encode(),
        "stderr")
    put("helper-pid-1", b"200\n")
    helper_args = ["bash", oracle.HELPER, "verify", "--project", project]
    waiter_args = ["docker", "wait", task]
    put("helper-proc-1", {"pid": 200,
        "helperCmdlineBase64": base64.b64encode(raw_argv(helper_args)).decode(),
        "helperArgv": helper_args,
        "childrenRawBase64": base64.b64encode(b"201 ").decode(),
        "children": [{"pid": 201,
                      "cmdlineBase64": base64.b64encode(raw_argv(waiter_args)).decode(),
                      "argv": waiter_args}]})
    put("kill-helper", {"pid": 200, "cid": task, "waitPid": 201, "signal": "SIGKILL"})
    def container(cid, image, status, code=None):
        return {"Id": cid, "Image": image, "Config": {"User": "10001:10001", "StopSignal": "SIGTERM"},
                "HostConfig": {"RestartPolicy": {"Name": "no"}, "NetworkMode": "none"},
                "Mounts": [{"Destination": "/state", "Source": "/var/lib/omne-tenancy/state"}],
                "State": {"Status": status, "Pid": 2 if status == "running" else 0,
                          "StartedAt": "t1", "ExitCode": code}}
    for label in ("offline-before", "offline-held", "offline-after-contender"):
        put(label, [container(task, qa_id, "running")])
    put("offline-final", [container(task, qa_id, "exited", 0)])
    put("contender-final", [container(other, oracle.ORIGINAL, "exited", 2)])
    put("gate-ready", {"stage": "ready", "project": project, "pid": 1})
    put("gate-held", {"stage": "offline-import-write", "pid": 1, "path": import_path,
                      "fd": 17, "dev": 1, "ino": 3})
    for label in ("fd-readlink", "fd-readlink-held"):
        put(label, (import_path + "\n").encode())
    for label in ("fd-stat", "fd-stat-held", "fd-stat-after-contender"):
        put(label, b"1:3:10001:10001:600\n")
    for label in ("marker-stat-held", "marker-stat-mid", "marker-stat-final"):
        put(label, b"regular file:1:2:10001:10001:600:16\n")
    for label in ("marker-content-held", "marker-content-mid", "marker-content-final"):
        put(label, oracle.MARKER_CONTENT)
    for label in ("work-stat-held", "work-stat-mid", "work-stat-final"):
        put(label, b"directory:1:10:10001:10001:700\n")
    put("lock-stat-held", b"regular empty file:10001:10001:644\n")
    put("same-work-contender", {"status": "busy"})
    put("same-work-contender", (f"omne-center: maintenance-created name=omne-{project}-verify-"
                                f"{'2'*16} container={other}\n").encode(), "stderr")
    put("helper-absence-1", {"pid": 200, "absent": True, "reason": "ENOENT"})
    put("helper-absent-mid", {"pid": 200, "absent": True, "reason": "ENOENT"})
    put("offline-status-held", {"containerId": task, "imageId": qa_id,
                                "action": "verify", "state": "running", "exitCode": None,
                                "outputText": ""})
    verified = {"status": "verified", "metadata": metadata, "businessOpen": False}
    put("offline-logs-final", verified)
    put("offline-status-final", {"containerId": task, "imageId": qa_id, "action": "verify",
                                 "state": "exited", "exitCode": 0,
                                 "outputText": j(verified).decode().strip()})
    put("app-wait", b"0\n")
    put("offline-events", {"Action": "die", "Actor": {"ID": task,
                                      "Attributes": {"exitCode": "0"}}})
    e = {"commands": rows, "scenario": "caller-loss", "business_complete": True,
         "status": "observed-awaiting-oracle", "artifact_manifest_sha256": oracle.I3_SHA,
         "inputs": {"build_id": oracle.BUILD_ID, "image_id": oracle.ORIGINAL,
                    "host_manifest_sha256": "f" * 64,
                    "sha256": {"gate": "1" * 64,
                               "proc_probe": hashlib.sha256(probe_source.encode()).hexdigest(),
                               "kill_helper": hashlib.sha256(kill_source.encode()).hexdigest(),
                               "pid_absence": hashlib.sha256(absence_source.encode()).hexdigest()}},
         "qa_image_id": qa_id, "expected": {"inner_image_id": oracle.ORIGINAL,
             "control": control, "state": "/var/lib/omne-tenancy/state", "project": project},
         "center_id": center, "source": source, "work": work, "offline_id": task,
         "contender_id": other, "offline_name": name,
         "offline_ready": {"cid": task, "monotonic_ns": 500_000_000,
                           "proc_label": "helper-proc-1", "pid_label": "helper-pid-1"},
         "helper_pid": 200, "wait_pid": 201,
         "helper_absence": {"pid": 200, "monotonic_ns": 1_000_000_000,
                            "poll_label": "helper-absence-1"},
         "midpoint": {"outer_client_returncode": 137, "outer_client_stdout_bytes": 0,
                      "monotonic_ns": 32_500_000_000},
         "release_monotonic_ns": 33_000_000_000,
         "outer_client_observation": {"host_pid": 400, "returncode": 137,
                                      "pending_after_budget": False, "stdout_bytes": 0},
         "cleanup_complete": True, "cleanup_errors": []}
    return e, raw


def main():
    baseline = fixture()
    positive = oracle.evaluate_observation(*baseline)
    assert positive["status"] == "limited_pass"
    caller_zero = copy.deepcopy(baseline)
    next(x for x in caller_zero[0]["commands"] if x["label"] == "verify-helper")["returncode"] = 0
    caller_zero[0]["outer_client_observation"]["returncode"] = 0
    caller_zero[0]["midpoint"]["outer_client_returncode"] = 0
    assert oracle.evaluate_observation(*caller_zero)["status"] == "limited_pass"
    caller_pending = copy.deepcopy(baseline)
    pending_row = next(x for x in caller_pending[0]["commands"] if x["label"] == "verify-helper")
    pending_row["returncode"] = None
    pending_row["observation_expired"] = True
    caller_pending[0]["outer_client_observation"]["returncode"] = None
    caller_pending[0]["outer_client_observation"]["pending_after_budget"] = True
    caller_pending[0]["midpoint"]["outer_client_returncode"] = None
    assert oracle.evaluate_observation(*caller_pending)["status"] == "limited_pass"
    lock_mode = copy.deepcopy(baseline)
    lock_mode[1]["lock-stat-held", "stdout"] = b"regular empty file:10001:10001:600\n"
    assert oracle.evaluate_observation(*lock_mode)["status"] == "limited_pass"
    cases = {
        "created-only-not-ready": lambda e, r: mutate_proc(r, lambda p: (p.__setitem__("childrenRawBase64", base64.b64encode(b"").decode()), p.__setitem__("children", []))),
        "outer-client-pid-as-helper": lambda e, r: e.__setitem__("helper_pid", 999),
        "wrong-wait-cid": lambda e, r: mutate_proc(r, lambda p: (p["children"][0].__setitem__("argv", ["docker", "wait", "9" * 64]), p["children"][0].__setitem__("cmdlineBase64", base64.b64encode(raw_argv(["docker", "wait", "9" * 64])).decode()))),
        "forged-child-relation": lambda e, r: mutate_proc(r, lambda p: p.__setitem__("childrenRawBase64", base64.b64encode(b"202 ").decode())),
        "wrong-proc-script": lambda e, r: next(x for x in e["commands"] if x["label"] == "helper-proc-1")["argv"].__setitem__(-2, "process.exit(0)"),
        "wrong-kill-pid": lambda e, r: next(x for x in e["commands"] if x["label"] == "kill-helper")["argv"].__setitem__(-2, "999"),
        "wrong-kill-cid": lambda e, r: next(x for x in e["commands"] if x["label"] == "kill-helper")["argv"].__setitem__(-1, "9" * 64),
        "wrong-kill-script": lambda e, r: next(x for x in e["commands"] if x["label"] == "kill-helper")["argv"].__setitem__(-3, "process.exit(0)"),
        "wrong-kill-wait-child": lambda e, r: mutate_object(r, "kill-helper", lambda p: p.__setitem__("waitPid", 999)),
        "kill-command-failed": lambda e, r: next(x for x in e["commands"] if x["label"] == "kill-helper").__setitem__("returncode", 1),
        "helper-never-disappeared": lambda e, r: mutate_object(r, "helper-absence-1", lambda p: p.__setitem__("absent", False)),
        "helper-reappeared-mid": lambda e, r: mutate_object(r, "helper-absent-mid", lambda p: p.__setitem__("absent", False)),
        "wrong-absence-pid": lambda e, r: mutate_object(r, "helper-absence-1", lambda p: p.__setitem__("pid", 999)),
        "wrong-absence-source": lambda e, r: next(x for x in e["commands"] if x["label"] == "helper-absence-1")["argv"].__setitem__(-2, "process.exit(0)"),
        "under-31s-hold": lambda e, r: e["midpoint"].__setitem__("monotonic_ns", 30_500_000_000),
        "premature-release": lambda e, r: e.__setitem__("release_monotonic_ns", 1_000_000_001),
        "caller-fake-completion": lambda e, r: r.__setitem__(("verify-helper", "stdout"), j({"status": "verified"})),
        "caller-finish-record": lambda e, r: r.__setitem__(("verify-helper", "stderr"), r["verify-helper", "stderr"] + b"omne-center: maintenance-finished\n"),
        "outer-client-rc-misreported": lambda e, r: e["outer_client_observation"].__setitem__("returncode", 0),
        "app-kill-event": lambda e, r: r.__setitem__(("offline-events", "stdout"), j({"Action": "kill", "Actor": {"ID": e["offline_id"], "Attributes": {"signal": "15"}}})),
        "app-exited-while-held": lambda e, r: r.__setitem__(("offline-held", "stdout"), r["offline-final", "stdout"]),
        "fd-inode-changed": lambda e, r: r.__setitem__(("fd-stat-held", "stdout"), b"1:4:10001:10001:600\n"),
        "fd-gone": lambda e, r: r.__setitem__(("fd-readlink-held", "stdout"), b""),
        "marker-gone": lambda e, r: r.__setitem__(("marker-content-mid", "stdout"), b""),
        "marker-inode-changed": lambda e, r: r.__setitem__(("marker-stat-final", "stdout"), b"regular file:1:4:10001:10001:600:16\n"),
        "workroot-not-private": lambda e, r: r.__setitem__(("work-stat-mid", "stdout"), b"directory:1:10:10001:10001:755\n"),
        "workroot-inode-changed": lambda e, r: r.__setitem__(("work-stat-final", "stdout"), b"directory:1:11:10001:10001:700\n"),
        "owner-lock-foreign-owner": lambda e, r: r.__setitem__(("lock-stat-held", "stdout"), b"regular empty file:0:0:644\n"),
        "status-held-fake-exit": lambda e, r: mutate_object(r, "offline-status-held", lambda p: p.__setitem__("state", "exited")),
        "status-held-wrong-id": lambda e, r: mutate_object(r, "offline-status-held", lambda p: p.__setitem__("containerId", "9" * 64)),
        "contender-not-busy": lambda e, r: r.__setitem__(("same-work-contender", "stdout"), j({"status": "verified"})),
        "contender-other-work": lambda e, r: next(x for x in e["commands"] if x["label"] == "same-work-contender")["argv"].__setitem__(-1, "/different"),
        "contender-recreated-original": lambda e, r: e.__setitem__("contender_id", e["offline_id"]),
        "wait-cli-no-app-code": lambda e, r: r.__setitem__(("app-wait", "stdout"), b""),
        "wait-cli-wrong-id": lambda e, r: next(x for x in e["commands"] if x["label"] == "app-wait")["argv"].__setitem__(-1, "9" * 64),
        "app-exit-nonzero": lambda e, r: mutate_object(r, "offline-final", lambda p: p[0]["State"].__setitem__("ExitCode", 2)),
        "final-result-not-verified": lambda e, r: mutate_object(r, "offline-logs-final", lambda p: p.__setitem__("status", "cancelled")),
        "final-result-business-open": lambda e, r: mutate_object(r, "offline-logs-final", lambda p: p.__setitem__("businessOpen", True)),
        "final-metadata-changed": lambda e, r: mutate_object(r, "offline-logs-final", lambda p: p["metadata"].__setitem__("centerId", "9" * 32)),
        "final-status-wrong-id": lambda e, r: mutate_object(r, "offline-status-final", lambda p: p.__setitem__("containerId", "9" * 64)),
        "temporary-plaintext-remains": lambda e, r: next(x for x in e["commands"] if x["label"] == "import-file-absent").__setitem__("returncode", 1),
        "source-mutated": lambda e, r: r.__setitem__(("source-hash-final", "stdout"), b"changed\n"),
        "cleanup-as-completion": lambda e, r: e.__setitem__("business_complete", False),
        "host-resource-remains": lambda e, r: r.__setitem__(("independent-host-volume", "stdout"), b"leftover\n"),
        "app-inventory-differs": lambda e, r: r.__setitem__(("qa-inventory", "stdout"), j({"status": "verified"})),
    }
    refused = []
    for name, mutate in cases.items():
        e, raw = copy.deepcopy(baseline)
        mutate(e, raw)
        try:
            oracle.evaluate_observation(e, raw)
        except (ValueError, KeyError, TypeError, IndexError, json.JSONDecodeError):
            refused.append(name)
        else:
            raise AssertionError("false pass: " + name)
    print(json.dumps({"positive": 4, "negative_refused": len(refused), "cases": refused}, sort_keys=True))


if __name__ == "__main__":
    main()
