// Fault fixture: recheck the known helper and exact wait child, then SIGKILL once.
import { readFile } from 'node:fs/promises'

const pidText = process.argv[1]
const cid = process.argv[2]
if (!/^[1-9][0-9]*$/.test(pidText)) throw new Error('known positive helper PID required')
if (!/^[0-9a-f]{64}$/.test(cid)) throw new Error('known exact container ID required')
const pid = Number(pidText)
if (!Number.isSafeInteger(pid) || pid <= 1) throw new Error('unsafe helper PID')

function argvFrom(raw) {
  if (raw.length === 0 || raw.at(-1) !== 0) throw new Error('process cmdline unavailable')
  return raw.subarray(0, -1).toString('utf8').split('\0')
}

const helperArgs = argvFrom(await readFile(`/proc/${pid}/cmdline`))
if (helperArgs[1] !== '/usr/local/libexec/omne-center' || helperArgs[2] !== 'verify') {
  throw new Error('PID no longer names the verified inner helper')
}
const childrenText = (await readFile(`/proc/${pid}/task/${pid}/children`)).toString('ascii').trim()
if (childrenText !== '' && !/^[1-9][0-9]*( [1-9][0-9]*)*$/.test(childrenText)) {
  throw new Error('helper children list malformed')
}
const children = childrenText === '' ? [] : childrenText.split(' ').map(Number)
let waitPid = null
for (const child of children) {
  const argv = argvFrom(await readFile(`/proc/${child}/cmdline`))
  if (argv.length === 3 && argv[0].split('/').at(-1) === 'docker' &&
      argv[1] === 'wait' && argv[2] === cid) {
    if (waitPid !== null) throw new Error('duplicate exact-CID wait children')
    waitPid = child
  }
}
if (waitPid === null) throw new Error('exact-CID wait child disappeared before signal')
if (process.kill(pid, 'SIGKILL') !== true) throw new Error('helper SIGKILL was not sent')
process.stdout.write(JSON.stringify({ pid, cid, waitPid, signal: 'SIGKILL' }) + '\n')
