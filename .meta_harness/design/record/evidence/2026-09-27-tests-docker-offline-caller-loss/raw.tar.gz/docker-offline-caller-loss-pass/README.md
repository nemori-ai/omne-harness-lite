# DK-I10 offline caller loss: static SIGKILL candidate

This ignored directory is a **static measurement candidate**, not an actual
Docker result or product acceptance. It starts from the root-accepted finite
handled-TERM fixture in `../docker-offline-cancel-v4/`, whose unchanged final
run freeze is `actual-run-files.sha256.json` SHA256
`a545548d1ac805ed55c94859f864c3d7d8c20c3b8c0749fde86f4674ca65f634`.
No preceding IO/cancel directory, tracked product source, or design file is
modified. The new candidate needs independent root review and a new one-shot
gate; `run-argv-draft.json` has no execution authority.

## Adopted result boundary

D-071 and the Docker realization require a killed/lost offline caller to keep
its result **unconfirmed**, retain the exact named task container and output,
and permit `maintenance-status` on its verified CID. The app task is not
cancelled by SIGKILLing the helper. EC3 v3 S-57/S-59 and accepted storage-sql
maintenance require the original workRoot owner, 0700 workRoot, 0600 marker,
actual 0600 import FD and isolated plaintext until true completion; same-root
second owner returns `busy` without a queue. The complete valid backup
source should later verify as `{status:'verified',metadata,businessOpen:false}`
if source and dependencies stay available. Its app exit is then 0, but the
killed helper cannot turn that later fact into a normal caller return.

## One explicit scenario

1. Create a completed original-image backup with the accepted final I3
   artifact; settle the center through the official helper and hash the source.
   Build a QA image inside the unique-label private DinD only after full app
   file/link/BUILD_ID comparison. Its only runtime change is the `/probe`
   preload and `NODE_OPTIONS`; the original image is used for source creation
   and the independent same-root contender. Neither host Docker socket nor
   extra product settings, env or mounts enter the app.
2. Start one official offline `verify` in the Linux control container with a
   pidfile shell that `exec`s the helper. A `maintenance-created` line alone is
   insufficient: read the known inner helper PID's raw `/proc` cmdline and
   direct children; require a child `docker wait <exact CID>`. Hold the real
   `task-<32hex>/snapshot.sqlite` FileHandle at its first `writeFile`, verify
   its dev/inode/mode, the marker, private workRoot and owner lock. Then the
   reviewed Node fixture re-reads that PID's helper cmdline and direct
   `docker wait <exact CID>` child at the signal point, then sends **one
   SIGKILL to that inner helper PID**. A
   targeted `/proc/<pid>` query must report ENOENT, immediately and again at
   the held midpoint. There is no invented SIGKILL handler and no app TERM.
3. Hold over 31 seconds after the observed helper disappearance. The app must
   retain the same running CID/PID, FD/inode, marker and workRoot. Query
   `maintenance-status` for the exact CID: running, exitCode null, no completed
   output. Launch a separately named original-image verify on the **same**
   workRoot and require its distinct CID, app exit 2 and `{status:'busy'}`.
   This is an explicit conflict probe; it is not an automatic replay of the
   unknown first call. The source file is only read.
4. Release the gate once, without signalling the app. Use a separate read-only
   `docker wait <exact CID>` plus same-ID inspect, logs and
   `maintenance-status` to observe natural app exit 0, the exact verified
   metadata of the original backup, and retained output. Require source hash
   unchanged, temporary import file absent only after completion, permanent
   0600 marker and 0700 workRoot unchanged. The killed helper must emit no
   `maintenance-finished` or normal result. Record the host `docker exec`
   client as returned 0, returned nonzero, or still pending after a finite
   observation; none is treated as the app result. Its raw stdout must not
   claim completion. A task Engine `kill` event would refute natural progress.

The product settlement is evaluated **before** fixture cleanup. Cleanup may
force-remove only this run's unique private labels and then independently
query exact-label host containers/networks/volumes. A missing observation,
wrong identity, contradictory wait/inspect/output, or finite timeout is
`unverified` and is not retried. All command argv, complete raw stdout/stderr,
CLI return codes, fixed inputs and cleanup records remain in the run directory
even on failure. The recorded orphaned read-only `docker wait` process is a
fixture resource; teardown may affect the private control container only
after business observations, never to manufacture an app result.

`offline-self-test.json` checks the oracle with positive caller-transport
outcomes (including 0, 137 and pending with empty stdout) and negative cases
for wrong helper PID/CID/child at the signal point, fake disappearance,
app kill/early completion,
owner/FD/marker loss, false busy/success, wrong wait/status/metadata, and
cleanup masquerading as settlement. `print-inputs.json` pins final I3 bytes,
source helper, D-071, EC3, storage boundary and this tool. `manifest-static.json`
lists the candidate's exact hashes. Only root can issue a reviewed gate and
authorize one actual run.

This candidate covers **known-ID helper SIGKILL during offline verify**. It
does not test an unknown-ID creation window, a naturally lost network/host
transport, different-workRoot concurrency, physical power loss or daemon
shutdown races. Those need separate evidence.
