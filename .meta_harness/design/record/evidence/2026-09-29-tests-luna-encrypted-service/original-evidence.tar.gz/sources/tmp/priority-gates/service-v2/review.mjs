import assert from 'node:assert/strict'
import { resolve } from 'node:path'
import { usdString, usdUnits } from '../../../tools/model-probe/src/budget.mjs'
import { pricing, readFrozen, reservation, verifyCatalog } from '../core.mjs'
import { validateServiceScenario, verifyServiceSources } from './common.mjs'

if (process.argv.length !== 7)
  throw new Error(
    'usage: service-v2/review.mjs SCENARIO SCENARIO_SHA CATALOG CATALOG_SHA MAX_AGE_MS',
  )
const [scenarioPath, scenarioSha, catalogPath, catalogSha, maxAgeText] = process.argv.slice(2)
const scenario = validateServiceScenario(await readFrozen(scenarioPath, scenarioSha))
await verifyServiceSources(scenario)
const catalog = await readFrozen(catalogPath, catalogSha)
await verifyCatalog(catalog, resolve(catalogPath), scenario)
const perRequest = reservation(pricing(catalog, scenario, Number(maxAgeText)), scenario)
assert.ok(usdUnits(perRequest) > 0n)
process.stdout.write(
  JSON.stringify(
    {
      modelId: scenario.modelId,
      caseKind: scenario.caseKind,
      reviewStatus: scenario.reviewStatus,
      scenarioSha256: scenarioSha,
      catalogSha256: catalogSha,
      sourceCommit: scenario.sourceCommit,
      profileSha256: scenario.profileSha256,
      definitionRevision: scenario.definitionRevision,
      implementation: scenario.implementation,
      serviceLiveWireSha256: 'unavailable',
      requests: 3,
      estimateUsdPerRequest: perRequest,
      theoreticalThreeRequestExposureUsd: usdString(usdUnits(perRequest) * 3n),
      note: 'Each turn reserves independently against the one ledger; unknown cost stops later turns. Source/profile and durable response prove service behavior, not live wire SHA.',
    },
    null,
    2,
  ) + '\n',
)
