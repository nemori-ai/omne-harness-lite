import { typedRejection } from '../evidence.mjs'

const serviceReasons = new Set([
  'malformed',
  'route_name_empty',
  'providers_empty',
  'modalities_empty',
  'input_text_missing',
  'modality_unknown',
  'registration_unknown',
  'parameter_out_of_range',
  'max_output_exceeds_profile',
  'constraint_unknown',
  'observer_scope_mismatch',
  'modality_mismatch',
  'unknownTool',
  'input_limit_missing',
  'input_limit_exceeded',
  'input_size_unavailable',
])
const stageFailures = new Set([
  'stageClosed',
  'identityMismatch',
  'sourceScopeMismatch',
  'membershipNotEffective',
])
const providerSteps = new Set([
  'issue',
  'exchange',
  'verify',
  'currentTenant',
  'standing',
  'bind',
  'store',
  'lookup',
  'listProfiles',
  'publishLocalInputs',
  'captureSessionRecipe',
  'currentInputs',
  'evaluate',
  'assetRegistry',
  'holdingTenant',
])

export function safeServiceRejection(value) {
  if (!value || typeof value !== 'object') return null
  if (value.invalidInput && typeof value.invalidInput === 'object') {
    const result = typedRejection(value)
    if (serviceReasons.has(value.invalidInput.reason)) result.reason = value.invalidInput.reason
    return result
  }
  if (stageFailures.has(value.failure)) return { category: 'stageFailure', reason: value.failure }
  if (providerSteps.has(value.step)) return { category: 'providerFailure', step: value.step }
  if (value.unavailable === true) return { category: 'unavailable' }
  if (value.callNotFound === true) return { category: 'callNotFound' }
  if (value.alreadyEnded === true) return { category: 'alreadyEnded' }
  if (value.runtimeStopped === true) return { category: 'runtimeStopped' }
  if (value.profileNotFound === true) return { category: 'profileNotFound' }
  if (value.wrongPhase && typeof value.wrongPhase === 'object') return { category: 'wrongPhase' }
  if (value.retryRefused && typeof value.retryRefused === 'object') {
    const why = value.retryRefused.why
    return {
      category: 'retryRefused',
      ...(new Set(['already_spoke', 'fact_class', 'provider_not_allowed']).has(why) ? { why } : {}),
    }
  }
  return null
}
