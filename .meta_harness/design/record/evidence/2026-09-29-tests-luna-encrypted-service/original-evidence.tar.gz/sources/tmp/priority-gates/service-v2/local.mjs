import assert from 'node:assert/strict'
import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { openLedger } from '../../../tools/model-probe/src/budget.mjs'
import {
  certificate,
  content,
  finish,
  fixture,
  sse,
} from '../../../packages/model/pi-ai-transport/tests/support.ts'
import { budget, definition, readFrozen } from '../core.mjs'
import { validateServiceScenario, verifyServiceSources } from './common.mjs'
import { servicePaidCase } from './service-core.mjs'
import { safeServiceRejection } from './service-evidence.mjs'

if (
  process.argv.length !== 10 ||
  process.argv[2] !== '--scenario' ||
  process.argv[4] !== '--scenario-sha256' ||
  process.argv[6] !== '--case' ||
  process.argv[8] !== '--output-dir'
)
  throw new Error(
    'usage: service-v2/local.mjs --scenario PATH --scenario-sha256 SHA --case positive|encrypted_second|unknown_cost|in_band_failure|zero_http_refusal --output-dir NEW_DIR',
  )
const scenario = validateServiceScenario(await readFrozen(process.argv[3], process.argv[5]))
await verifyServiceSources(scenario)
const mode = process.argv[7]
assert.ok(
  ['positive', 'encrypted_second', 'unknown_cost', 'in_band_failure', 'zero_http_refusal'].includes(
    mode,
  ),
)
if (mode === 'encrypted_second') assert.equal(scenario.modelId, 'openai/gpt-5.6-luna')
if (mode === 'zero_http_refusal') {
  assert.deepEqual(
    safeServiceRejection({
      invalidInput: {
        reason: 'input_size_unavailable',
        metrics: ['maxInputTokens'],
        message: 'local-service-secret controlled-ciphertext-do-not-log',
        opaque: { secret: 'local-service-secret' },
      },
      body: 'local-service-secret',
    }),
    { category: 'invalidInput', reason: 'input_size_unavailable', metrics: ['maxInputTokens'] },
  )
}
const outputDir = resolve(process.argv[9])
await mkdir(outputDir, { mode: 0o700, recursive: true })
const prices = {
  prompt: '0.0000001',
  input_cache_write_1h: '0.0000002',
  completion: '0.0000005',
  request: '0',
}
const ledgerPath = join(outputDir, 'fixture-ledger.json')
const cert = certificate()
const atHttp = []
let host
let snapshot
let observedError = null
try {
  host = await fixture(
    cert.tls,
    async (response, request) => {
      const state = JSON.parse(await readFile(ledgerPath, 'utf8'))
      const latest = state.entries.at(-1)
      assert.equal(latest?.state, 'reserved', 'durable reservation required before HTTP')
      assert.equal(JSON.parse(request.body).model, scenario.modelId)
      atHttp.push({ entryId: latest.id, state: latest.state })
      const first = atHttp.length === 1
      response.setHeader('x-request-id', `local-service-${atHttp.length}`)
      if (mode === 'in_band_failure') {
        response.end(
          sse({
            id: 'local-service-inband-id',
            error: { code: 503, message: 'Rejected echo local-service-secret' },
          }) + sse('[DONE]'),
        )
        return
      }
      response.end(
        (mode === 'encrypted_second' && first
          ? sse({
              choices: [
                {
                  delta: {
                    reasoning_details: [
                      {
                        type: 'reasoning.encrypted',
                        data: 'controlled-ciphertext-do-not-log',
                        index: 0,
                        format: 'openai-responses-v1',
                        id: 'opaque-fixture',
                      },
                    ],
                  },
                },
              ],
            })
          : '') +
          content('OK') +
          (mode === 'unknown_cost'
            ? ''
            : sse({
                id: `local-service-generation-${atHttp.length}`,
                model: scenario.modelId,
                provider: scenario.provider === 'openai' ? 'OpenAI' : 'Anthropic',
                choices: [],
                usage: { prompt_tokens: 2000, completion_tokens: 2, cost: 0.0000117 },
              })) +
          finish(),
      )
    },
    {},
    undefined,
    [definition(scenario.modelId).value],
  )
  const ledger = await openLedger(ledgerPath, budget)
  try {
    if (mode === 'positive') {
      const completed = await servicePaidCase({
        scenario,
        pricing: prices,
        ledger,
        outputDir,
        credentialBytes: Buffer.from('local-service-secret'),
        developmentTransport: host.options,
      })
      assert.equal(completed.length, 3)
      assert.ok(completed.every(row => row.outcome === 'complete' && row.durable === true))
      assert.equal(host.requests.length, 3)
      assert.ok(ledger.snapshot().entries.every(row => row.state === 'settled'))
    } else {
      await assert.rejects(
        servicePaidCase({
          scenario:
            mode === 'zero_http_refusal'
              ? {
                  ...scenario,
                  maxOutputTokens:
                    definition(scenario.modelId).value.capabilities.maxOutputTokens + 1,
                }
              : scenario,
          pricing: prices,
          ledger,
          outputDir,
          credentialBytes: Buffer.from('local-service-secret'),
          developmentTransport: host.options,
        }),
        /Actual cost unknown/,
      )
      observedError = 'Actual cost unknown: stop paid verification'
      assert.equal(
        host.requests.length,
        mode === 'zero_http_refusal' ? 0 : 1,
        'no HTTP after first refusal; no second HTTP after unknown cost or later refusal',
      )
      assert.equal(ledger.snapshot().entries.at(-1)?.state, 'unknown')
      await assert.rejects(
        ledger.reserve({
          model: scenario.modelId,
          provider: scenario.provider,
          stage: 'acceptance',
          estimateUsd: '0.1',
        }),
        /Unsettled request/,
      )
    }
    snapshot = ledger.snapshot()
  } finally {
    await ledger.close()
  }
} finally {
  await host?.close()
  cert.dispose()
}
const closeName = (await readdir(outputDir)).find(name => name.startsWith('service-close-'))
assert.ok(closeName, 'real business/diagnostic/host close evidence missing')
const close = JSON.parse(await readFile(join(outputDir, closeName), 'utf8'))
assert.equal(close.businessComplete, true)
assert.equal(close.diagnosticComplete, true)
assert.equal(close.hostReleasedAfterBusiness, true)
let typedRejection = null
if (mode === 'encrypted_second' || mode === 'zero_http_refusal') {
  const receipts = await Promise.all(
    (await readdir(outputDir))
      .filter(name => name.startsWith('service-observed-'))
      .map(async name => JSON.parse(await readFile(join(outputDir, name), 'utf8'))),
  )
  const receipt = receipts.find(value => value.stage === 'service_rejected')
  assert.ok(receipt, 'typed pre-send private receipt missing')
  typedRejection = receipt.typedRejection
  assert.deepEqual(
    typedRejection,
    mode === 'encrypted_second'
      ? { category: 'invalidInput', reason: 'input_size_unavailable', metrics: ['maxInputTokens'] }
      : { category: 'invalidInput', reason: 'max_output_exceeds_profile' },
  )
  assert.equal(receipt.cost, null)
  assert.ok(!JSON.stringify(receipt).includes('controlled-ciphertext-do-not-log'))
  assert.ok(!JSON.stringify(receipt).includes('local-service-secret'))
}
if (mode === 'in_band_failure') {
  const entries = await Promise.all(
    (await readdir(outputDir))
      .filter(
        name =>
          name.startsWith('service-') &&
          name.endsWith('.json') &&
          !name.startsWith('service-close-') &&
          !name.startsWith('service-observed-'),
      )
      .map(async name => ({
        name,
        value: JSON.parse(await readFile(join(outputDir, name), 'utf8')),
      })),
  )
  const receipt = entries.find(entry => entry.value.outcome === 'failed')?.value
  assert.ok(receipt && receipt.durable === true)
  assert.ok(receipt.upstreamRequestId !== null, 'safe upstream request ID or digest required')
  if (typeof receipt.upstreamRequestId === 'object') {
    assert.equal(receipt.upstreamRequestId.omitted, true)
    assert.match(receipt.upstreamRequestId.sha256, /^[0-9a-f]{64}$/)
  }
  assert.equal(receipt.inBandStatusCode, 503)
  assert.equal(receipt.failure?.inBand, true)
  assert.ok(!JSON.stringify(receipt).includes('local-service-secret'))
  assert.ok(!JSON.stringify(receipt).includes('Rejected echo'))
}
await writeFile(
  join(outputDir, 'local-result.json'),
  JSON.stringify(
    {
      modelId: scenario.modelId,
      mode,
      scenarioSha256: process.argv[5],
      requestCount: atHttp.length,
      states: snapshot.entries.map(row => row.state),
      reservedBeforeEveryHttp: atHttp.every(row => row.state === 'reserved'),
      typedRejection,
      observedError,
      businessComplete: close.businessComplete,
      diagnosticComplete: close.diagnosticComplete,
      hostReleasedAfterBusiness: close.hostReleasedAfterBusiness,
      evidenceScope:
        'real authenticated demo service and SL3 on controlled TLS; synthetic upstream; no paid send',
    },
    null,
    2,
  ) + '\n',
  { flag: 'wx', mode: 0o600 },
)
process.stdout.write(`service local ${mode} pass: ${scenario.modelId}, HTTP=${atHttp.length}\n`)
