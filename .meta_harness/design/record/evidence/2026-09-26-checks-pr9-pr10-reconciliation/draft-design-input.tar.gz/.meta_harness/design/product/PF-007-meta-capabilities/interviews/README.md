# PF-007 设计交流笔记

设计这块产品时，人与 AI 交流过程中有价值的信息留在这里。

**这里是原始材料，不是结论。**任何一条要成为产品事实，必须经由
[decisions.md](../decisions.md) 记录，并落进 [design.md](../design.md)。
笔记本身**不得被引为依据**。

## 现有笔记

| 日期 | 笔记 | 谈了什么 |
|---|---|---|
| 2026-09-17 | [Meta Capabilities](2026-09-17-meta-capabilities.md) | 开题：meta 的定义与「必定常驻」→ 不可禁用不可替换 + 六个必需 → 调研七家 → 补五个 + Cordis 非首批 → 全部多命令范式 → 补 exec_script 与 patch → 逐扇门 review：Shell 多会话、Computer 对标 legacy、Agents 三模式 + 外部 harness、TodoItems / BkgJobs 改名 |
| 2026-09-17 | [外部实现调研](2026-09-17-survey-of-harnesses.md) | pi / DSH / opencode / deepagents / Claude Code / Codex / Cursor / Kimi Code 各自提供了什么，以及 omne-next 的现成形态 |
| 2026-09-18 | [`Agents()` 派发模式的重新设计](2026-09-18-agents-dispatch.md) | 两条通信规则 + `spawn` / `delegate` / `handoff` 各五个维度；**推翻了 rev 1 的三处写法**；留下一处 PM 不替产品负责人决定的事（`spawn` 的「继承」是共享还是复制） |
