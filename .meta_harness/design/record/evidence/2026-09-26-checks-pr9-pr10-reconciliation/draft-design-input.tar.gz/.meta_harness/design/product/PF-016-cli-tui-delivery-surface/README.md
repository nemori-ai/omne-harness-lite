---
id: PF-016
title: 这套系统交到人手上的第一面：装在自己机器上的命令行
status: active
revision: 7
relations:
  supersedes: []
  depends-on:
    - id: PF-001
      for: 账号、登录状态、组织、租户、当前租户身份、角色与隔离——全部动作都是它定义的，本 topic 只提供发起处
    - id: PF-002
      for: 设置与权限的分层求值——本 topic 只呈现「这一项的值来自哪一层」；斜杠命令的三种绑定目标与系统保留名
    - id: PF-003
      for: 资产的复制与分享，以及待确认的邀约会过期——本 topic 是发起与点头的地方
    - id: PF-005
      for: 宿主机与执行环境权限——本形态下宿主机就是用户自己的电脑
    - id: PF-008
      for: 决策卡片、决策池、答复只在卡片上做、永远等着
    - id: PF-012
      for: 会话日志是唯一真相、运行与终态、只看日志判断该不该起一副 runtime
    - id: PF-013
      for: 模型档案与切换、凭据挂在范围上——凭据的值一概不呈现
    - id: PF-014
      for: 受理面只有一个、三个去处、控制指令家族——人做的事全部接到这三个去处上
    - id: PF-015
      for: 会话的生命周期与归档、会话运行模式、存储要守住的两件事、会话日志投影
  extends: []
---

# PF-016：命令行交付面

**这套系统的产品设计已经把会话、运行、卡片、受理定得很细，却没有一处回答「人从哪里进来」。**
本 topic 给出第一个[交付面](design.md#交付面)：**一个装在用户自己机器上的命令行应用**——
同事各自安装、注册、登录、被邀请进组织，在自己的机器上开会话、跟 agent 协作、答卡片、翻历史；
研发者用同一份东西把整条链跑完并留下可核对的记录。

**边界只有一句话：它是投影与入口，不拥有任何领域语义。**
屏上的每一条都指得回[会话日志](../PF-012-agent-loop-and-run/design.md#会话日志)里的一条；
人做的每一件事都走[已有的那两类路](design.md#54-人做的每一件事走的都是已有的路)。
账号、组织、邀请、隶属归 [PF-001](../PF-001-identity-scope-and-agent-constraints/README.md)；
会话怎么活归 [PF-015](../PF-015-session-lifecycle-and-ownership/README.md)。
**本 topic 不改这些概念里的任何一个，也不在它们之上另造一套**；
它新增的[五个概念](#关系)只回答一件它们没回答过的事——
**这些事实各自落在哪一侧**，以及人从哪一面碰到它们。

**本期交付边界**：[10 人以内、Linux/macOS 的内网治理 CLI/TUI 闭环](design.md#本期交付范围)。
Agent 工作会话下一期；下表描述完整产品设计，不表示本期全部实现或验收。

## 本 rev 覆盖到哪

| 这一块 | 本 rev |
|---|---|
| **三处地方各自拥有什么** | ✅ [人面前那块屏 · 会话据点 · 治理中心](design.md#51-三处地方各自拥有什么)、[据点的身份是哪三样](design.md#52-一个账号在一处怎么被装起来)，以及[中心一侧与据点一侧的分界](design.md#56-哪些东西在中心一侧哪些在据点一侧)——**分界不是「治理 vs 会话」那么粗** |
| **注册、登录、进组织这条流程** | ✅ [flows 1.1 与 1.2](flows.md#11-第一次在自己的机器上用起来)，含**「乙必须先注册」那个次序**（[v1 照 PF-001 原样](decisions.md#二pm-推导)） |
| **在会话里干活** | ✅ [flows 1.3](flows.md#13-在一个会话里干活)；[三条入站到达的路 + 具名的那几条会话事实](design.md#54-人做的每一件事走的都是已有的路)；[进来没指名就是新会话、当前目录是本租户的工作区就默认挂上](design.md#618-进来没指定会话就是新的当前目录是本租户的工作区就默认挂上) |
| **给脚本用的那一面** | ✅ [呈现形式](design.md#呈现形式)与[两种形式同源](design.md#55-两种呈现形式同一份事实) |
| **离线、被移出组织、关机重来** | ✅ [关屏禁掉的那三件](design.md#68-关掉屏不会让任何东西丢掉)、[必须现读的那三类](design.md#69-需要现读成员资格的那几件事不拿副本放行)、[成员资格无效期间怎么办](design.md#610-成员资格无效期间本机那些会话不呈现也不删)、[中心不可达时已开着的会话照常干活](design.md#617-治理中心不可达已经开着的会话照常干活) |
| **没人开着屏的时候这一处还发生不发生事** | ✅ [照常发生](design.md#616-没人开着屏这一处照常发生事)——[PF-014 §6.8](../PF-014-inbound-intake-and-queueing/design.md#68-停机不会让一条入站到达永远悬着) 在本形态下因此成立。**机器关机期间到期归档的时钟怎么算**仍在 [§9](design.md#九未决项) |
| **凭据、池子、观感偏好在这条形态下各落在哪** | ✅ [每台机器上只有自己那一把凭据](design.md#620-每台机器上只有自己那一把凭据)、[池子按据点各一份](design.md#619-这里看到的池子是这一处的)、[观感偏好跟着账号走](design.md#观感偏好) |
| **命令怎么拼、屏怎么画、两处之间怎么通、据点靠什么运转** | ❌ **不在这里。**产品侧只定[三族的边界](design.md#57-人要做的事分三族)，其余归技术设计 |

**没覆盖的部分不要从本文推断。**未决项在 [§9](design.md#九未决项) 显式列着；
[decisions §三](decisions.md#三待裁决)本 rev 是空的——**六条待裁已全部裁完**，原话在 [decisions §一](decisions.md#一拍板记录)。

## 关系

| 关系 | 含义 | 本 topic 的情况 |
|---|---|---|
| `supersedes` | 对方全部内容被吸收 | **无。**本 topic 是新开的，不取代任何人 |
| `depends-on` | 引用对方定义，不重复展开 | **九个**，见 front-matter。**每一个都是「用它的规矩」，没有一个是「改它的规矩」** |
| `extends` | 扩展对方范围，对方继续有效 | **无** |

**本 topic [在架构内核之外](../architecture-core.md#内核之外的-pf)：它只用规矩，不立规矩。**
[交付面那两条定义性质](design.md#交付面)是已有规则在这一面上的投影，不是新协议；
**没有任何别的 topic 需要为了遵守本 topic 而改自己的定义。**
（它曾向上游报回几条张力，[筛过之后只剩一处措辞跟进](decisions.md#四已知的来源问题)——**那是请对方复核，不是改动对方**。）

**本 topic 定义的五个概念**（词条已立，出处指回 §四；形态判定的理由在 [decisions §五](decisions.md#五待立的词条与对象条目)）：
[交付面](../../ubiquitous_language/terms/interaction-and-dispatch.md#ul-delivery-surface--交付面--delivery-surface) ·
[会话据点](../../ubiquitous_language/terms/grounding-and-isolation.md#ul-session-base--会话据点--session-base) ·
[治理中心](../../ubiquitous_language/terms/grounding-and-isolation.md#ul-governance-center--治理中心--governance-center) ·
[呈现形式](../../ubiquitous_language/terms/interaction-and-dispatch.md#ul-presentation-form--呈现形式--presentation-form) ·
[观感偏好](../../ubiquitous_language/terms/interaction-and-dispatch.md#ul-look-and-feel-preference--观感偏好--look-and-feel-preference)。

**前两个是对象**，条目在[领域对象](../../domain_objects/objects.md)——
**那个「本机上的东西」不是进程**，它的身份是（一处 · 中心 · 账号）。
它们吸收了此前的两项待裁，**裁决那一半也已定**：[没人看着时这一处照常发生事](design.md#616-没人开着屏这一处照常发生事)、
[个人自托管的中心不是产品形态](design.md#二目标与非目标)。

## 按当前问题展开

| 当前问题 | 阅读入口 |
|---|---|
| 这块产品是什么：概念、模型、规则、取舍 | [产品设计](design.md) |
| 用户怎么走、哪一步失败了看到什么、谁能做什么 | [流程与状态](flows.md) |
| 做成什么样算做对了 | [验收标准](acceptance.md) |
| 哪些是拍板定的、哪些是我推的、还有什么没定 | [决策与来源](decisions.md) |
| 这块设计是怎么演变到今天的 | [变更历史](changelog.md) |

## 状态

- 产品设计：**rev 7**，本轮产品基线；前版已完成独立评审，本次单机分期已完成定向复评；2026-09-24 具体确认与 PM 推导见 [decisions](decisions.md)。此前 rev 5 的定稿登记及原接受依据保留，新稿不自动继承整稿接受状态
- 本期范围：治理 CLI/TUI；Agent 工作会话下一期，见 [design](design.md#本期交付范围)
- 未决项：既有会话与中心交互边界见 [design §九](design.md#九未决项)；本期另依赖 PF-001 的登录判定与 PF-017 的恢复方案
- 待裁决：本 topic 无新增独立政策选择，跨 topic 依赖尚未闭合
- 已知来源问题：本次来源复核见 [decisions](decisions.md#rev-6-来源与消费者复核)
- 技术投影：**尚未开始**

## 本包的文件

```text
PF-016-cli-tui-delivery-surface/
├── README.md         本页：定位、关系、状态          ← 必须
├── design.md         概念、模型、规则、取舍、边界      ← 必须
├── flows.md          旅程、异常分支、状态流转、角色矩阵
├── acceptance.md     产品视角的验收标准
├── decisions.md      拍板记录 / PM 推导 / 待裁决 / 来源问题 / 待立词条 / 调研参照   ← 必须
└── changelog.md      产品设计本身的演进                ← 必须
```

**没有 `interviews/`**：本 rev 的原始输入只有[转录下来的那五条原话](decisions.md#一拍板记录)，
没有独立的交流场次可记。**没有 `projection/`**：技术设计尚未开始，
那个目录[由步骤 G 落盘](../README.md#与技术设计的关系)，不预先建空壳。
