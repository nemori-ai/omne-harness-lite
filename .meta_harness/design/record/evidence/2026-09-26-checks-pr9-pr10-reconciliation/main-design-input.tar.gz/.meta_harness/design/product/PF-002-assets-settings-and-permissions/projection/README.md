# PF-002-assets-settings-and-permissions：设计投影

需求与契约正文仍是权威，投影是精确来源的派生阅读入口。

| 版本 | 状态 | 需求修订 | 发布日期 | 来源与接受 |
|---|---|---|---|---|
| [v2](v2/projection.md) | **当前，accepted／post-review**；尚未表示实现 | rev 20 | 2026-09-26 | D-045（G6），契约由 D-041 接受并冻结，节点由 D-042 接受；逐文件 hash 在 [provenance](v2/provenance.json) |
| [v1](v1/projection.md) | 历史、已由 v2 取代；保留当时未接受／未冻结的来源状态 | 原快照修订 | 2026-09-25 | 历史正文与 provenance 不原地改写，不作为当前实施入口 |

当前版本为 **v2**。只在节点声明的可实施范围内使用；显式缺口不填默认值。规格以 registry 的冻结 hash 核对，产品／节点 hash 仅表示本版快照；实施之前逐项检查，来源变化出新版投影。
