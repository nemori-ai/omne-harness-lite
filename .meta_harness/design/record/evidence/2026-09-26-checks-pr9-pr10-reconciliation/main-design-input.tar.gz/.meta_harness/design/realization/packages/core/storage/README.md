# storage

- kind：`provider`
- 对象与设计修订：状态 `implemented`（源码修订 HUB `c9b5850`），2026-09-22 首稿。**不兑现任何契约条款**；它的规格是两个 tenancy 节点写下的对存储提供者的要求清单——[account-identity R-1～R-7](../../tenancy/account-identity/design.md#对存储提供者的要求清单)与[organization-governance R-1～R-6](../../tenancy/organization-governance/design.md#对存储提供者的要求清单)（两份设计由 [D-023](../../../../record/decisions/tenant-domain-design-acceptance/README.md) 接受为实现路径）——加 [D-026](../../../../record/decisions/infrastructure-persistence-choices/README.md) 的四条基础设施选择
- 源码位置：`packages/core/storage`——**已实现（HUB `c9b5850`）**：`src/protocol.ts`、`src/errors.ts`、`src/map.ts`、`src/migration.ts`（`MigrationFragment`、`composeMigrations`、`composedMigrationName`：owner 导出片段、装配合成，[tenancy-host「迁移由 owner 导出片段」](../../../apps/tenancy-host/design.md#存储装配迁移由-owner-导出片段本节点合成)）、`src/preflight.ts`（`PreflightInput`／`PreflightResult`／`PreflightCheck`：[storage-sql「迁移前只读核对」](../../infra/storage-sql/design.md#迁移前只读核对)的核对函数形状，clock 与入口层据此对接、不 import storage-sql）、`src/conformance/index.ts`（子路径 `./conformance`）。归 `core`：它是一个**协议级构造**（存储协议的接口、错误类型、锁语义）加一套任何提供者都必须通过的一致性测试，没有领域事实，被 `tenancy` 两个持事实节点、`infra/clock` 与 `infra/storage-sql` 消费（[两层布局](../../../README.md#packages-的两层布局)）
- 契约采用与边界依据：本节点是**纯模块，不是 Cordis 插件**——协议没有生命周期、不拥有连接、不 provide 任何服务；服务名 `storage` 的**实例**由 `infra/storage-sql`（组名由 [D-027](../../../../record/decisions/infrastructure-names-and-sqlite-durability/README.md) 拍板）的插件 `storageSqlPlugin` provide。本节点拥有四样：`Storage`／`ReadTx`／`WriteTx`／`StorageInstance` 接口与**四型失败**（`StorageUnavailable` 只收瞬时、`UniqueViolation`、`ReferenceViolation`、`StorageDefect` 收缺陷）的形状与语义、两种方言下锁语义的**协议解释**、`mapStorageError`（只折 `StorageUnavailable`，错误类型的 owner 拥有映射）、`describeStorageConformance` 一致性套件。**表结构不在协议里**：各节点的表由装配层的迁移建立，两个 tenancy 节点的表须落在同一存储、同一约束域（[design.md](design.md#表结构不在协议里由装配层迁移建立两节点同一约束域)）

## 分层状态

- 语义接受范围：**无契约条款。**本节点不是任何 `data.*`／`capability.*`／`composition.*` 契约的提供者；它兑现的是两份已接受节点设计里的要求清单（AI R-1～R-7、OG R-1～R-6）与 D-026 的选择。要求清单的语义归那两个节点，本节点不改写它们的任何一条
- 可实施范围：**已实现（HUB `c9b5850`）。**协议接口、四型失败与 `mapStorageError`（[design.md「协议」](design.md#协议)）、每条 R 在协议上的兑现点与提供者义务 P-1～P-12（[要求→协议→测试表](design.md#要求到协议再到会红的测试)）、一致性套件 19 个用例（C-1a/b～C-15，含 C-2b 主键支与 C-15 嵌套调用）、迁移片段与迁移前核对的共用形状（[design.md](design.md#迁移片段与迁移前核对的共用形状)）。**不给出**：任何提供者实现（归 [`infra/storage-sql`](../../infra/storage-sql/README.md)）、任何表结构与迁移（各 owner 导出片段、装配合成）、跨进程形态下的存储协调协议
- 绑定与证据：[`bindings.yaml`](bindings.yaml) 为**空表**——没有契约条款可绑；本包的测试与套件都不是对某条契约的证据。一致性套件的通过是**提供者节点**的证据（它跑套件），不是本节点的绑定；每条用例的义务登记在 [verification.md](verification.md)
- 实际验证：运行 `2026-09-23-tests-tenancy-leg-2`（证据登记在 [`record/evidence/2026-09-23-tests-tenancy-leg-2/`](../../../../record/evidence/2026-09-23-tests-tenancy-leg-2/README.md)，HUB）：本包的单元与类型测试随十三个 TS 成员在 sqlite 下全过；一致性套件由 [`infra/storage-sql`](../../infra/storage-sql/README.md) 在它的包测试里接线运行，sqlite 下全过，pg 16 容器上 19／19 通过。本节点 [verification.md](verification.md#实际执行) 的「实际执行」待回填

## 按当前问题展开

| 当前问题                                                                                                | 阅读入口                            |
| ------------------------------------------------------------------------------------------------------- | ----------------------------------- |
| 协议长什么样、每条 R 靠协议里的哪个方法或错误类型兑现、两种方言下锁语义怎么解释、一致性套件哪条测试会红 | [实现设计](design.md)               |
| 哪条承诺由哪份证据支持、前提是什么                                                                      | [绑定表](bindings.yaml)（当前为空） |
| 一致性套件要证什么、实际跑过什么、还缺什么                                                              | [验证与证据](verification.md)       |

状态变化由实际事件驱动。文件存在、接口齐全或评审无意见都不提升状态；
契约语义变化回 [spec](../../../../spec/README.md)，采用选择回 [record/decisions](../../../../record/decisions/README.md)。
