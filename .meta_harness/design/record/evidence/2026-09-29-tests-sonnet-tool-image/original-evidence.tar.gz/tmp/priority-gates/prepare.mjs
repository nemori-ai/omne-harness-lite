import assert from 'node:assert/strict'
import { mkdir, writeFile, readFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import {
  applicable,
  createTransport,
  definition,
  hash,
  planFor,
  profile,
  sourceCommit,
  sourceDigests,
} from './core.mjs'

if (
  process.argv.length !== 10 ||
  process.argv[2] !== '--model' ||
  process.argv[4] !== '--gate' ||
  process.argv[6] !== '--max-output-tokens' ||
  process.argv[8] !== '--output'
)
  throw new Error(
    'usage: prepare.mjs --model EXACT --gate GATE --max-output-tokens N --output PATH',
  )
const modelId = process.argv[3]
const gate = process.argv[5]
assert.ok(applicable(modelId, gate), 'not applicable; do not force missing meter')
const maxOutputTokens = Number(process.argv[7])
const { provider, value } = definition(modelId)
assert.ok(
  Number.isSafeInteger(maxOutputTokens) &&
    maxOutputTokens > 0 &&
    maxOutputTokens <= value.capabilities.maxOutputTokens,
)
const scenario = {
  format: 1,
  caseKind: 'public_gate',
  reviewStatus: 'pending',
  modelId,
  provider,
  gate,
  definitionRevision: value.revision,
  implementation: value.implementation,
  expectedEndpointTag: provider,
  maxOutputTokens,
  sourceCommit: sourceCommit(),
  sourceSha256: await sourceDigests(),
  profileSha256: hash(JSON.stringify(profile(modelId))),
  imageSha256:
    gate === 'inline_image' ? hash(await readFile('tmp/priority-gates/fixtures/red-64.png')) : null,
}
const transport = createTransport(scenario)
try {
  const { planned } = await planFor(scenario, transport)
  scenario.publicWireSha256 = hash(planned.serialized)
  scenario.measurement = {
    mode: planned.measurement.mode,
    precision: planned.measurement.precision,
  }
} finally {
  await transport.close()
}
await mkdir(dirname(process.argv[9]), { recursive: true, mode: 0o700 })
await writeFile(process.argv[9], JSON.stringify(scenario, null, 2) + '\n', {
  flag: 'wx',
  mode: 0o600,
})
process.stdout.write(
  `${scenario.modelId} ${scenario.gate} pending ${hash(await readFile(process.argv[9]))}\n`,
)
