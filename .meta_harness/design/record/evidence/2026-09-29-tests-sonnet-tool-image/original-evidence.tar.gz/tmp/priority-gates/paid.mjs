import assert from 'node:assert/strict'
import { lstat, readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { readPrivateFile } from '../../examples/model-invocation-minimal-demo/dist/demo.js'
import {
  openProductionLedger,
  privateOutputDirectory,
  writePrivateEvidence,
} from '../../tools/model-probe/src/production-gate.mjs'
import {
  approvedLedger,
  budget,
  createTransport,
  hash,
  planFor,
  pricing,
  publicCase,
  readFrozen,
  reservation,
  validateScenario,
  verifyCatalog,
  verifySources,
} from './core.mjs'

function argumentsFor(argv) {
  const map = new Map()
  for (let index = 0; index < argv.length; index += 2) {
    const key = argv[index],
      value = argv[index + 1]
    if (!key?.startsWith('--') || value === undefined || map.has(key))
      throw new Error('distinct option/value required')
    map.set(key, value)
  }
  const required = [
    '--mode',
    '--model',
    '--scenario',
    '--scenario-sha256',
    '--catalog',
    '--catalog-sha256',
    '--catalog-max-age-ms',
    '--ledger',
    '--credential-file',
    '--output-dir',
  ]
  assert.deepEqual([...map.keys()].sort(), required.sort(), 'exact production option set required')
  assert.equal(map.get('--mode'), 'production', 'production mode must be explicit')
  return Object.fromEntries([...map].map(([k, v]) => [k.slice(2), v]))
}
const args = argumentsFor(process.argv.slice(2))
assert.equal(resolve(args.ledger), approvedLedger, 'the one approved HUB ledger is required')
const scenario = validateScenario(await readFrozen(args.scenario, args['scenario-sha256']))
assert.equal(args.model, scenario.modelId)
assert.equal(scenario.reviewStatus, 'approved', 'separate human scenario approval required')
await verifySources(scenario)
const transport = createTransport(scenario)
try {
  const { planned } = await planFor(scenario, transport)
  assert.equal(hash(planned.serialized), scenario.publicWireSha256)
} finally {
  await transport.close()
}
const catalog = await readFrozen(args.catalog, args['catalog-sha256'])
await verifyCatalog(catalog, resolve(args.catalog), scenario)
const prices = pricing(catalog, scenario, Number(args['catalog-max-age-ms']))
const estimateUsd = reservation(prices, scenario)
const ledgerStat = await lstat(approvedLedger)
assert.ok(
  ledgerStat.isFile() && ledgerStat.uid === process.getuid() && (ledgerStat.mode & 0o777) === 0o600,
)
const outputDir = await privateOutputDirectory(args['output-dir'])
const ledger = await openProductionLedger(args.ledger, approvedLedger, budget)
let credentialBytes
try {
  const raw = await readPrivateFile(args['credential-file'])
  try {
    credentialBytes = Buffer.from(raw.subarray(0, raw.at(-1) === 10 ? raw.length - 1 : raw.length))
  } finally {
    raw.fill(0)
  }
  assert.ok(
    credentialBytes.length > 0 && credentialBytes.every(byte => byte >= 0x20 && byte <= 0x7e),
  )
  await writePrivateEvidence(
    `${outputDir}/manifest.json`,
    JSON.stringify(
      {
        modelId: scenario.modelId,
        gate: scenario.gate,
        scenarioSha256: args['scenario-sha256'],
        catalogSha256: args['catalog-sha256'],
        estimateUsd,
        maximumPlannedRequests: 1,
        publicWireSha256: scenario.publicWireSha256,
        sourceCommit: scenario.sourceCommit,
        sourceSha256: scenario.sourceSha256,
        budget,
      },
      null,
      2,
    ) + '\n',
  )
  const result = await publicCase({
    scenario,
    prices,
    ledger,
    outputDir,
    credential: credentialBytes.toString('ascii'),
  })
  await writePrivateEvidence(
    `${outputDir}/summary.json`,
    JSON.stringify(
      { ...result, transportClosed: true, ledgerCloseFollowsSummaryWrite: true },
      null,
      2,
    ) + '\n',
  )
} finally {
  credentialBytes?.fill(0)
  await ledger.close()
}
