import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { execFileSync } from 'node:child_process'
import { judgeMessage } from '../../packages/core/messages/dist/index.js'
import { parseOpaqueIdentifier, unwrap } from '../../packages/core/identity-values/dist/index.js'
import {
  jsonNumberSource,
  writeJsonLossless,
} from '../../packages/core/content-blocks/dist/index.js'
import {
  invokeModel,
  openRouterCredentialRedactionConfig,
} from '../../packages/model/model-request-runtime/dist/index.js'
import {
  anthropicDefinitions,
  openaiDefinitions,
  createAnthropicInputMeter,
  createOpenAiInputMeter,
  createOfficialProfileContent,
  createPiAiTransport,
} from '../../packages/model/pi-ai-transport/dist/index.js'
import { estimateReservation } from '../../tools/model-probe/src/budget.mjs'
import {
  paidInvocation,
  writePrivateEvidence,
} from '../../tools/model-probe/src/production-gate.mjs'
import { safeCausality, typedRejection } from './evidence.mjs'

export const hash = bytes => createHash('sha256').update(bytes).digest('hex')
export const modelIds = Object.freeze([
  ...anthropicDefinitions.map(d => d.modelId),
  'openai/gpt-6-astra',
  'openai/gpt-6-astra-pro',
  'openai/gpt-6-sol',
  'openai/gpt-6-sol-pro',
  'openai/gpt-6-luna',
  'openai/gpt-6-luna-pro',
  'openai/gpt-5.6-sol',
  'openai/gpt-5.6-sol-pro',
  'openai/gpt-5.6-terra',
  'openai/gpt-5.6-terra-pro',
  'openai/gpt-5.6-luna',
  'openai/gpt-5.6-luna-pro',
])
export const gates = Object.freeze(['tool_schema', 'inline_image', 'effort_high', 'stop_sequence'])
export const approvedLedger =
  '/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime/tmp/model-request-runtime/ledger.json'
export const budget = Object.freeze({ limitUsd: '100', researchLimitUsd: '50' })
export const sourcePaths = Object.freeze([
  'tools/model-probe/src/budget.mjs',
  'tools/model-probe/src/production-gate.mjs',
  'tmp/priority-gates/core.mjs',
  'tmp/priority-gates/evidence.mjs',
  'tmp/priority-gates/prepare.mjs',
  'tmp/priority-gates/review.mjs',
  'tmp/priority-gates/paid.mjs',
  'tmp/priority-gates/local.mjs',
  'packages/core/messages/dist/index.js',
  'packages/core/content-blocks/dist/index.js',
  'packages/model/model-request-runtime/dist/index.js',
  'packages/model/pi-ai-transport/dist/index.js',
  'packages/model/pi-ai-transport/src/official-models/anthropic.ts',
  'packages/model/pi-ai-transport/src/official-models/openai.ts',
  'packages/model/pi-ai-transport/src/input-meters/anthropic.ts',
  'packages/model/pi-ai-transport/src/input-meters/openai.ts',
  'packages/model/pi-ai-transport/src/calibration.ts',
  'packages/model/pi-ai-transport/src/transport.ts',
  'packages/model/model-request-runtime/src/invoke.ts',
  'examples/model-invocation-minimal-demo/src/demo.ts',
])
export const sourceCommit = () =>
  execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim()
export async function sourceDigests() {
  return Object.fromEntries(
    await Promise.all(sourcePaths.map(async path => [path, hash(await readFile(path))])),
  )
}
export function definition(modelId) {
  assert.ok(modelIds.includes(modelId), 'model outside exact sixteen allowlist')
  const provider = modelId.startsWith('openai/') ? 'openai' : 'anthropic'
  const value = (provider === 'openai' ? openaiDefinitions : anthropicDefinitions).find(
    d => d.modelId === modelId,
  )
  assert.ok(value, 'exact official model definition unavailable')
  return { provider, value }
}
export function applicable(modelId, gate) {
  assert.ok(gates.includes(gate), 'unknown gate')
  const { provider } = definition(modelId)
  if (gate === 'stop_sequence') return provider === 'anthropic'
  if (gate === 'inline_image')
    return provider === 'anthropic' || /^openai\/gpt-5\.6-(sol|terra|luna)$/.test(modelId)
  if (gate === 'effort_high') return modelId !== 'openai/gpt-6-luna'
  return true
}
export function profile(modelId) {
  const { provider, value } = definition(modelId)
  const cache =
    provider === 'openai'
      ? { mode: 'automatic' }
      : { mode: 'explicit', ttl: '1h', breakpoints: ['last_message'] }
  const result = createOfficialProfileContent(value, {
    providers: [provider],
    allowFallback: false,
    configuration: { revision: 'priority-gates-1', values: { cache } },
  })
  if (!('ok' in result)) throw new Error(`official profile rejected: ${result.rejected}`)
  return result.ok
}
export function meter(modelId) {
  const { provider, value } = definition(modelId)
  return provider === 'openai' ? createOpenAiInputMeter(value) : createAnthropicInputMeter(value)
}
const at = '2026-09-29T00:00:00Z'
export function textMessage(type, text, id) {
  const result = judgeMessage({
    type,
    id,
    createdAt: at,
    blocks: [
      { id: `${id}-text`, kind: 'text', text, visibility: { toHuman: true, toModel: true } },
    ],
    ...(type === 'system_reminder'
      ? { nature: 'event', source: { kind: 'attempt_started', attempt: 1, reason: 'first', at } }
      : {}),
  })
  if (!('ok' in result)) throw new Error(`message rejected: ${result.rejected}`)
  return result.ok
}
function imageMessage(png) {
  const result = judgeMessage({
    type: 'user',
    id: 'gate-image',
    createdAt: at,
    blocks: [
      {
        id: 'gate-image-block',
        kind: 'image',
        mediaType: 'image/png',
        data: { inline: png.toString('base64') },
        visibility: { toHuman: true, toModel: true },
      },
    ],
  })
  if (!('ok' in result)) throw new Error(`image rejected: ${result.rejected}`)
  return result.ok
}
export const tool = Object.freeze({
  name: 'lookup__exact',
  description: 'Look up a fixed exact codeword',
  parameters: {
    type: 'object',
    properties: { query: { type: 'string' } },
    required: ['query'],
    additionalProperties: false,
  },
})
export async function requestFor(scenario, builtProfile = profile(scenario.modelId)) {
  const { provider, value } = definition(scenario.modelId)
  const messages = [
    textMessage(
      'system',
      scenario.gate === 'tool_schema'
        ? 'Call lookup__exact with query CEDAR. Do not answer in text.'
        : scenario.gate === 'inline_image'
          ? 'Answer only the dominant color in the image.'
          : scenario.gate === 'stop_sequence'
            ? 'Output exactly A STOP B.'
            : 'Answer briefly.',
      'gate-system',
    ),
    textMessage('system_reminder', 'Follow the system instruction.', 'gate-reminder'),
    textMessage(
      'user',
      scenario.gate === 'tool_schema' ? 'Look up CEDAR.' : 'Continue.',
      'gate-user',
    ),
  ]
  if (scenario.gate === 'inline_image')
    messages.push(imageMessage(await readFile('tmp/priority-gates/fixtures/red-64.png')))
  return {
    calibration: { kind: 'none', reason: 'no_observation' },
    tokenMargin: { multiplier: 1.1, reserveTokens: 256 },
    target: {
      kind: 'model_call',
      callId: unwrap(parseOpaqueIdentifier('priority-gate-public', 'ModelCallId')),
      dispatch: 1,
    },
    routeName: scenario.modelId,
    provider,
    parameters: {
      reasoningEffort: scenario.gate === 'effort_high' ? 'high' : 'low',
      maxOutputTokens: scenario.maxOutputTokens,
      ...(scenario.gate === 'stop_sequence' ? { stopSequences: ['STOP'] } : {}),
    },
    tools: scenario.gate === 'tool_schema' ? [tool] : [],
    messages,
    snapshot: {
      adaptation: builtProfile.adaptation,
      providers: builtProfile.providers,
      allowFallback: builtProfile.allowFallback,
      ...value.capabilities,
      updatedAt: at,
    },
  }
}
export const transportPolicy = () => ({
  maxConnections: 1,
  idleConnectionTimeoutMs: 5000,
  connectTimeoutMs: 5000,
  maxErrorBodyBytes: 8192,
  maxSseEventBytes: 65536,
  credentialRedaction: openRouterCredentialRedactionConfig,
})
export const invocationPolicy = () => ({
  now: () => new Date().toISOString(),
  schedule(ms, fn) {
    const timer = setTimeout(fn, ms)
    return () => clearTimeout(timer)
  },
  firstContentTimeoutMs: 15000,
  idleContentTimeoutMs: 120000,
  statusCauseTable: {
    401: 'credential_unavailable',
    429: 'upstream_unavailable',
    503: 'upstream_unavailable',
  },
  credentialRedaction: openRouterCredentialRedactionConfig,
  diagnostic: () => {},
})
export function createTransport(scenario, options = {}) {
  const { value } = definition(scenario.modelId)
  return createPiAiTransport({
    definitions: [value],
    inputMeters: [meter(scenario.modelId)],
    policy: transportPolicy(),
    ...options,
  })
}
export async function planFor(scenario, transport) {
  const request = await requestFor(scenario)
  const result = transport.plan(request)
  if (!('planned' in result))
    throw new Error(`production planner rejected gate: ${JSON.stringify(result)}`)
  const planned = result.planned
  assert.equal(planned.body.provider.order[0], definition(scenario.modelId).provider)
  if (scenario.gate === 'tool_schema')
    assert.equal(planned.body.tools?.[0]?.function?.name, tool.name)
  if (scenario.gate === 'effort_high') assert.deepEqual(planned.body.reasoning, { effort: 'high' })
  if (scenario.gate === 'stop_sequence') assert.deepEqual(planned.body.stop, ['STOP'])
  if (scenario.gate === 'inline_image')
    assert.ok(
      planned.body.messages.some(
        m => Array.isArray(m.content) && m.content.some(b => b.type === 'image_url'),
      ),
    )
  return { request, planned }
}
export function validateScenario(s) {
  assert.equal(s.format, 1)
  assert.equal(s.caseKind, 'public_gate')
  assert.ok(applicable(s.modelId, s.gate), 'gate not applicable on current production meter/route')
  assert.ok(['pending', 'approved'].includes(s.reviewStatus))
  const { provider, value } = definition(s.modelId)
  assert.equal(s.provider, provider)
  assert.equal(s.definitionRevision, value.revision)
  assert.deepEqual(s.implementation, value.implementation)
  assert.equal(s.expectedEndpointTag, provider)
  assert.ok(
    Number.isSafeInteger(s.maxOutputTokens) &&
      s.maxOutputTokens > 0 &&
      s.maxOutputTokens <= value.capabilities.maxOutputTokens,
  )
  assert.equal(s.sourceCommit, sourceCommit())
  for (const key of ['profileSha256', 'publicWireSha256', 'imageSha256'])
    if (s[key] !== null) assert.match(s[key], /^[0-9a-f]{64}$/)
  assert.deepEqual(Object.keys(s.sourceSha256).sort(), [...sourcePaths].sort())
  return s
}
export async function verifySources(s) {
  assert.deepEqual(s.sourceSha256, await sourceDigests())
  assert.equal(s.profileSha256, hash(JSON.stringify(profile(s.modelId))))
  if (s.gate === 'inline_image')
    assert.equal(s.imageSha256, hash(await readFile('tmp/priority-gates/fixtures/red-64.png')))
  else assert.equal(s.imageSha256, null)
}
export async function readFrozen(path, digest) {
  assert.match(digest, /^[a-f0-9]{64}$/)
  const bytes = await readFile(path)
  assert.equal(hash(bytes), digest, 'frozen SHA mismatch')
  return JSON.parse(bytes.toString('utf8'))
}
export async function verifyCatalog(catalog, catalogPath, scenario) {
  const { dirname, join } = await import('node:path')
  assert.equal(
    catalog.captureSource,
    'openrouter-public-api',
    'fixture catalog forbidden in paid mode',
  )
  const directory = await readFile(join(dirname(catalogPath), 'directory.raw.json'))
  const endpoint = await readFile(join(dirname(catalogPath), 'endpoint.raw.json'))
  assert.equal(hash(directory), catalog.directoryRawSha256)
  assert.equal(hash(endpoint), catalog.endpointRawSha256)
  const listed = JSON.parse(directory.toString('utf8')).data?.find(x => x.id === scenario.modelId)
  const raw = JSON.parse(endpoint.toString('utf8')).data?.endpoints?.find(
    x => x.tag === scenario.expectedEndpointTag,
  )
  assert.ok(listed && raw && raw.status === 0)
  assert.equal(raw.provider_name, scenario.provider === 'openai' ? 'OpenAI' : 'Anthropic')
  const card = catalog.cards?.find(x => x.id === scenario.modelId)
  assert.deepEqual(
    card?.endpoints?.find(x => x.tag === scenario.expectedEndpointTag)?.pricing,
    raw.pricing,
  )
}
export function pricing(catalog, scenario, maxAgeMs) {
  assert.equal(catalog.format, 1)
  const age = Date.now() - Date.parse(catalog.observedAt)
  assert.ok(
    Number.isSafeInteger(maxAgeMs) &&
      maxAgeMs > 0 &&
      Number.isFinite(age) &&
      age >= 0 &&
      age <= maxAgeMs,
    'stale or future catalog',
  )
  const card = catalog.cards?.find(c => c.id === scenario.modelId)
  assert.equal(card?.state, 'directory_present')
  const endpoint = card.endpoints?.find(e => e.tag === scenario.expectedEndpointTag)
  assert.equal(endpoint?.provider, scenario.provider === 'openai' ? 'OpenAI' : 'Anthropic')
  assert.equal(endpoint?.status, 0)
  assert.ok(endpoint.pricing)
  return endpoint.pricing
}
export function reservation(prices, scenario) {
  return estimateReservation(
    prices,
    definition(scenario.modelId).value.capabilities.maxInputTokens,
    scenario.maxOutputTokens,
  )
}
export function assertGateOutcome(scenario, outcome) {
  assert.ok('outcome' in outcome, `pre-send branch: ${JSON.stringify(outcome)}`)
  assert.equal(outcome.outcome, 'complete', 'upstream gate did not complete')
  if (scenario.gate === 'tool_schema') {
    const calls = outcome.blocks.filter(
      b => b.kind === 'tool_call' && b.tool === tool.name && b.complete && !b.unparseable,
    )
    assert.equal(calls.length, 1, 'one complete parsed tool call required')
    assert.deepEqual(calls[0].arguments, { query: 'CEDAR' })
  }
  if (scenario.gate === 'inline_image') {
    const text = outcome.blocks
      .filter(b => b.kind === 'text')
      .map(b => b.text)
      .join('')
      .trim()
    assert.match(text, /^red[.!]?$/i, 'image answer is not the expected dominant color')
  }
  if (scenario.gate === 'stop_sequence') {
    const text = outcome.blocks
      .filter(b => b.kind === 'text')
      .map(b => b.text)
      .join('')
    assert.ok(
      !text.includes('STOP') && text.trim() === 'A',
      'stop effect not observed in normalized text',
    )
  }
}
export async function publicCase({
  scenario,
  prices,
  ledger,
  outputDir,
  credential,
  transportOptions = {},
}) {
  const transport = createTransport(scenario, transportOptions)
  try {
    const { request, planned } = await planFor(scenario, transport)
    const wireSha256 = hash(planned.serialized)
    assert.equal(wireSha256, scenario.publicWireSha256, 'public wire changed after approval')
    const estimateUsd = reservation(prices, scenario)
    const paid = await paidInvocation(
      ledger,
      { model: scenario.modelId, provider: scenario.provider, stage: 'acceptance', estimateUsd },
      async entryId => {
        let outcome
        try {
          outcome = await invokeModel({
            ...request,
            transport,
            credential,
            signal: new AbortController().signal,
            policy: invocationPolicy(),
            onAccepted: () => {},
          }).outcome
        } catch {
          await writePrivateEvidence(
            `${outputDir}/public-${entryId}.json`,
            JSON.stringify(
              {
                entryId,
                wireSha256,
                stage: 'invoke_exception',
                cost: null,
                ...safeCausality(null, credential),
              },
              null,
              2,
            ) + '\n',
          )
          throw new Error('invocation threw; cost unknown')
        }
        const safe = {
          entryId,
          modelId: scenario.modelId,
          gate: scenario.gate,
          wireSha256,
          estimateUsd,
          outcome: 'outcome' in outcome ? outcome.outcome : outcome.rejected,
          rejectionReason: 'reason' in outcome ? outcome.reason : null,
          typedRejection: typedRejection(outcome),
          ...safeCausality(outcome, credential),
          usage: 'usage' in outcome ? JSON.parse(writeJsonLossless(outcome.usage)) : null,
          cost: 'cost' in outcome ? JSON.parse(writeJsonLossless(outcome.cost)) : null,
          blocks:
            'blocks' in outcome
              ? outcome.blocks.map(b =>
                  b.kind === 'tool_call'
                    ? {
                        kind: b.kind,
                        tool:
                          b.tool === tool.name
                            ? tool.name
                            : { omitted: true, sha256: hash(b.tool ?? '') },
                        complete: b.complete,
                        arguments:
                          b.complete && !b.unparseable
                            ? {
                                bytes: Buffer.byteLength(writeJsonLossless(b.arguments)),
                                sha256: hash(writeJsonLossless(b.arguments)),
                              }
                            : null,
                      }
                    : {
                        kind: b.kind,
                        ...(b.kind === 'text'
                          ? { text: { bytes: Buffer.byteLength(b.text), sha256: hash(b.text) } }
                          : {}),
                      },
                )
              : [],
        }
        await writePrivateEvidence(
          `${outputDir}/public-${entryId}.json`,
          JSON.stringify(safe, null, 2) + '\n',
        )
        return {
          actualUsd:
            'cost' in outcome && outcome.cost?.cost_usd !== 'unknown'
              ? jsonNumberSource(outcome.cost.cost_usd)
              : undefined,
          safe,
          outcome,
        }
      },
    )
    assertGateOutcome(scenario, paid.receipt.outcome)
    return { entryId: paid.id, ...paid.receipt.safe }
  } finally {
    await transport.close()
  }
}
