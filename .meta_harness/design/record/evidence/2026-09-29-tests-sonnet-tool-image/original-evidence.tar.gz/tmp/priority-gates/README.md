# T16 online applicability gates: preparation package

This directory is a private verification tool, not a product app or an online verdict. It prepares one bounded **public** `invokeModel` request per exact model and gate. It uses the built production planner, official definition and meter, Pi-AI transport, original `budget.mjs` whole-context reservation and `production-gate.mjs` durable ledger gate. Its own loopback TLS fixture must not be substituted for the upstream route. Authenticated three-turn service applicability is **not** certified by this package; the earlier runner-v2 baseline covers service independently.

Source basis: execution commit `68b49260a8da01cf79aa096c4cea7df3a81e1c65`; D107 adopted MR9/RT10, transport v12 rev2 SHA `8e2c62b2379ef7741ad44112421b1e6440849ec43d4b54edd7d94c2ff8e41476`, runtime v16 SHA `17e4552faac16a3ab03aa974b210e150ac1fc96a5982f4812b8e549e203c978d`. The previous 42-case local matrix at HEAD `7595c196` is read-only input in HUB `tmp/priority-certification/runner-v2/successor/gates-v1/`; this package rechecks applicability on its own actual source. Its `sourceSha256` freezes both exact product source and produced entry-point bytes; a different integrated HUB source must regenerate scenarios.

| Gate | Eligible exact bindings | Bounded public oracle | Remaining online proof |
| --- | --- | --- | --- |
| `tool_schema` | All 16 | Wire tool schema, one complete normalized `lookup__exact` call, parsed `{"query":"CEDAR"}` | Upstream actually selects and emits that call; service tool execution is separate |
| `inline_image` | Anthropic 4 and GPT-5.6 base 3 | Original 64×64 red PNG SHA, inline wire image, normalized `RED` answer | Remote image acceptance and understanding; seven local answers are synthetic |
| `effort_high` | All except GPT-6 Luna base | Exact `reasoning.effort=high` wire and complete response | Upstream effort support and actual usage/cost |
| `stop_sequence` | Anthropic 4 | Exact wire `stop:["STOP"]`, normalized `A` without delimiter | Upstream stop effect; OpenAI routes deliberately drop stop |

The other nine OpenAI image meters return `input_size_unavailable`, GPT-6 Luna base high effort returns `input_size_unavailable`, and six OpenAI Pro definitions retain `scope_unknown`. No test supplies a synthetic image meter, coerces Pro calibration to marginal, or lowers the definition's input/output profile cap. The scenario's request `maxOutputTokens` is independently reviewable; the example uses 256 and reserves against the exact definition maximum input bound. The budget helper includes highest applicable prompt/cache-write tier, output tier and request fee. If a catalog lacks a price or a whole-context reservation does not fit the sole approved ledger, that case does not send. Unknown cost remains unknown and stops; there is no automatic retry.

## Reproduce without a credential or the formal ledger

Build the model-invocation demo dependency closure in this worktree first. These commands generate **pending** scenarios and local results under a new private directory. The matrix runs one child at a time. `first` is four Anthropic plus three GPT-5.6 non-Pro bindings (25 applicable gates); `all` is the current full 42-case matrix. `TMPDIR` points to this worktree.

```sh
mkdir -p tmp/priority-gates/tmpdir
TMPDIR=$PWD/tmp/priority-gates/tmpdir pnpm -r --filter '@omne-harness-lite/model-invocation-minimal-demo...' --workspace-concurrency=1 run build
TMPDIR=$PWD/tmp/priority-gates/tmpdir node tmp/priority-gates/run-matrix.mjs --set first --output-dir tmp/priority-gates/matrix-first-NEW
TMPDIR=$PWD/tmp/priority-gates/tmpdir node tmp/priority-gates/run-matrix.mjs --set all --output-dir tmp/priority-gates/matrix-all-NEW
```

For a single bounded stage, use `prepare.mjs --model anthropic/claude-sonnet-5 --gate tool_schema --max-output-tokens 256 --output /ABS/NEW/scenario.json`; hash the generated file with `sha256sum`; then invoke `node --experimental-transform-types tmp/priority-gates/local.mjs --scenario /ABS/NEW/scenario.json --scenario-sha256 SHA --output-dir /ABS/NEW/local`. `negative.mjs` with `--case unknown_cost` or `--case wrong_tool_arguments` reuses a tool scenario. `preflight-negative.mjs` verifies five paid-entry refusals before the formal ledger/key/HTTP boundary. `typed-rejection-negative.mjs` checks content-free typed public and service-shaped refusal projection. These are local fixture observations only. `run-matrix.mjs` writes one ledger per case; its whole-context reservation is checked durable and `reserved` inside the TLS handler before that handler replies. Each request body must byte-equal the frozen production plan.

The typed refusal helper retains only whitelisted category, reason, metric/basis and bounded limit numbers. It drops messages, request bodies, opaque reasoning and arbitrary upstream text. It can be consumed by a future service-stage runner; this package's online stage is public only and does not repair the prior service runner's lost second-turn Luna refusal.

## Root-only online sequence, one approved stage at a time

The root executor copies this package into the integrated HUB at `tmp/priority-gates/`, rebuilds the same closure, regenerates the selected scenario, checks its profile/definition/implementation/wire/source SHA and changes its `reviewStatus` from `pending` to `approved` only after separate review. This changes the scenario SHA. No local result supplies approval. Use the existing frozen `tmp/priority-certification/runner-v2/catalog.mjs --model EXACT --output-dir /ABS/NEW_PRIVATE_CATALOG` to capture a fresh public directory and exact endpoint; that entry stores the raw directory and endpoint bytes with SHA. The following are template commands, not commands executed in this preparation:

```sh
node tmp/priority-gates/review.mjs /ABS/APPROVED_SCENARIO SCENARIO_SHA /ABS/FRESH_CATALOG/catalog.json CATALOG_SHA 900000
node tmp/priority-gates/paid.mjs --mode production --model EXACT --scenario /ABS/APPROVED_SCENARIO --scenario-sha256 SCENARIO_SHA --catalog /ABS/FRESH_CATALOG/catalog.json --catalog-sha256 CATALOG_SHA --catalog-max-age-ms 900000 --ledger /data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime/tmp/model-request-runtime/ledger.json --credential-file /ABS/OWNER_ONLY_RAW_KEY --output-dir /ABS/NEW_PRIVATE_EVIDENCE
```

`900000` ms is an operator freshness example, not a product TTL. Root reviews the actual available exposure including unknown holds before **each** request; do not batch-reserve all gates or create another ledger. The paid entry rejects unapproved/mismatched scenario, changed source/wire/profile, fixture or stale catalog, changed raw endpoint/price, alternate ledger, and wrong mode before credentials or the formal ledger. It reads an owner-only key file without putting secrets in argv or evidence. `paidInvocation` reserves durably before HTTP; private evidence stores original usage/cost plus bounded/sanitized failure cause, upstream request ID and HTTP status before settlement. Tool arguments and text are hashed in evidence; the in-memory oracle checks the exact parsed tool arguments after settlement. Transport close is awaited; the ledger closes in `finally`. Any missing cost leaves the original unknown hold and stops. A false applicability oracle is reported as failure, not rewritten to pass.

The 64×64 image and its expected `RED` local response are a deterministic **synthetic** fixture. Only a root-executed remote result on the frozen exact endpoint can support image understanding, tool selection, effort or stop claims. Public gates do not certify authenticated service, durable SL3, live wire SHA inside the service, multi-turn cache, or the entire 16-model acceptance matrix. Previous service/cache online evidence remains separate.
