from pathlib import Path, PurePosixPath
import json, hashlib, tarfile, subprocess, os
hub=Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime')
spoke=hub.parent/'model-request-runtime-p2-rfc3339-order-verification'
base=spoke/'tmp/model-request-runtime/p2-rfc3339-order-verification'
out=hub/'tmp/model-request-runtime/p2-rfc3339-order-signoff'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
a=json.loads((base/'archive.json').read_text());s=json.loads((base/'summary.json').read_text());m=json.loads((base/'archive-manifest.json').read_text())
assert a['sha256']=='8cd8e512c714f10383ac6a4ab94636c92d6b90146efb825ae8563a0f8e0ed53a'
assert a['manifestSha256']=='4e37be7881a195e6eab66a0b51a6015479e1eae2c2941151903fd17e6a034ab3'
assert sha(base/'closed-evidence.tar.gz')==a['sha256']
assert sha(base/'archive-manifest.json')==a['manifestSha256']
assert sha(base/'REPORT.md')==a['reportSha256'] and sha(base/'summary.json')==a['summarySha256']
assert s['sourceHead']=='56d69e3647636cc13acb58d5ec0bd667fab3d191' and s['verdict']=='Pass with issues' and s['productSliceVerdict']=='Pass'
assert len(s['issues'])==1 and s['issues'][0]['id']=='ISSUE-1'
assert s['tests']['numPassedTests']==150 and s['tests']['numFailedTests']==0
assert s['freeze']['drift']==[] and s['freeze']['inputs']==198
seen=set();counts={'files':0,'directories':0,'manifest':0};readback={}
with tarfile.open(base/'closed-evidence.tar.gz','r:gz') as t:
 for entry in t:
  path=PurePosixPath(entry.name)
  assert not path.is_absolute() and '..' not in path.parts and entry.name not in seen,entry.name
  seen.add(entry.name)
  if entry.isdir():
   assert entry.name in m['directories'];counts['directories']+=1;continue
  assert entry.isfile(),entry.name
  data=t.extractfile(entry).read();digest=hashlib.sha256(data).hexdigest()
  if entry.name=='MANIFEST.json':
   assert digest==a['manifestSha256'];counts['manifest']+=1;continue
  row=m['members'][entry.name]
  assert len(data)==row['bytes'] and digest==row['sha256'],entry.name
  source=Path(row['source']);assert source.is_file() and sha(source)==digest,entry.name
  counts['files']+=1;readback[entry.name]={'sha256':digest,'bytes':len(data)}
assert set(m['members'])|set(m['directories'])|{'MANIFEST.json'}==seen
assert counts=={'files':3993,'directories':548,'manifest':1} and len(seen)==4542
inputs=json.loads((base/'frozen-inputs.json').read_text())
for path,digest in inputs.items():
 assert sha(spoke/path)==digest,path
 assert sha(hub/path)==digest,path
assert len(inputs)==198
commands=[]
for runkey in ['finalConsumersRun','finalControlsRun']:
 for path in sorted(Path(s[runkey]).glob('*/command.json')):
  obj=json.loads(path.read_text())
  assert isinstance(obj['pid'],int) and obj['actualWaitCompleted'] is True and obj.get('timedOut',False) is False
  assert sha(path.parent/'stdout')==obj['stdoutSha256'] and sha(path.parent/'stderr')==obj['stderrSha256']
  expect=1 if obj['pid'] in {item['pid'] for item in s['negativeControls']} else 0
  assert obj['exit']==expect,(obj['label'],expect,obj['exit'])
  commands.append({'path':str(path.relative_to(base)),'label':obj['label'],'pid':obj['pid'],'exit':obj['exit'],'actualWaitCompleted':True})
for name in ['B','C']:
 resources=s['resources'][name]
 assert resources['oraclesPassed']==9475 and resources['businessEffects']==[] and resources['businessAsyncResources']==[]
 assert resources['initial']['fds']==resources['final']['fds']==21
 assert resources['initial']['resources']==resources['final']['resources']==[]
 directory=Path(s['publicationAudit'][name]['directory'])
 files=json.loads((base/('consumer-'+name+'-manifest.json')).read_text())
 assert len(files)==878 and not any(p.is_symlink() for p in directory.rglob('*'))
 for path,row in files.items():assert (directory/path).stat().st_size==row['bytes'] and sha(directory/path)==row['sha256'],path
for neg in s['negativeControls']:
 assert neg['compileExit']==neg['syntaxExit']==0 and neg['behaviorExit']==1
 assert neg['onlyProductDelta']==['offer-expiry/dist/rfc3339-order.js']
 assert 'AssertionError' in neg['failure']['error'] and neg['failure']['name']==neg['oracle']
assert a['command']['actualWaitCompleted'] is True and a['command']['exit']==0
assert a['postArchiveReadOnlyAudit']['allProductReadersStopped'] is True
assert subprocess.check_output(['git','status','--porcelain'],cwd=hub,text=True)==''
result={'archiveSha256':a['sha256'],'manifestSha256':a['manifestSha256'],'memberCounts':counts,'allMembers':len(seen),'allSourceBytesReadback':True,'currentHubInputs':len(inputs),'commands':commands,'consumerFilesEach':878,'oraclesEach':9475,'literalExecutions':12,'compiledNegatives':2,'issuePreserved':s['issues'][0],'technicalScope':'D089 B/R1 core conditional ordering only; no production provenance or full vertical acceptance','readback':readback}
(out/'root-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['readback','commands']},ensure_ascii=False))
