#!/usr/bin/env python3
"""Static R5 IO acceptance candidate. Docker runs require a separate root review gate."""

import argparse
import hashlib
import io
import json
import pathlib
import re
import shutil
import subprocess
import sys
import tarfile
import time

import base_driver as base

HERE = pathlib.Path(__file__).resolve().parent
I3_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
BUILD_ID = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
IMAGE_ID = "sha256:27c0665146265afefe39012aaea26bdae7499784eaaeb74aea712a6fcdfc03f2"
IMAGE_TAR_SHA = "503fc0c6006d5d654e1e288bbff1af806ec041163d56223bac7e322391653de2"
HELPER_SHA = "71ba9f3c31b34c171dd2a4048d9e249af31f7948abcf66ee603da5ffb7d1b365"
DOCKER_SPEC_SHA = "3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223"
FD_PATH = re.compile(r"/state/backups/\.quarantine/export-[0-9a-f]{32}\Z")
MARKER = base.STATE + "/backups/.quarantine/.omne-isolated"


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def canonical_hash(value):
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


def checked_inputs(args):
    base.V0 = args.v0_dir
    paths = {
        "driver": HERE / "driver.py", "base_driver": HERE / "base_driver.py",
        "oracle": HERE / "oracle.py", "gate": HERE / "gate.mjs",
        "gate_availability": HERE / "gate_availability.mjs",
        "inventory": HERE / "inventory.mjs", "i3_manifest": args.i3_manifest,
        "image_tar": args.image_tar,
        "host_build_info": args.helper_dir.parents[1] / "build-info.json",
        "host_build_id": args.helper_dir.parents[1] / "BUILD_ID",
        "helper": args.helper_dir / "omne-center",
        "compose": args.helper_dir / "compose.yaml",
        "maintenance_compose": args.helper_dir / "compose.maintenance.yaml",
        "health": args.helper_dir / "health.mjs",
        "service": args.helper_dir / "omne-center-backup@.service",
        "timer": args.helper_dir / "omne-center-backup@.timer",
        "compose_binary": args.v0_dir / "docker-compose-linux-aarch64",
        "docker_cli": args.v0_dir / "extracted-bin/docker",
        "docker_spec": args.design_root / "realization/apps/tenancy-host/docker.md",
    }
    actual = {name: base.sha(path) for name, path in paths.items()}
    manifest = json.loads(args.i3_manifest.read_text())
    arm = manifest["images"]["arm64"]
    host = manifest["archives"]["host"]
    require(actual["i3_manifest"] == I3_SHA and actual["docker_spec"] == DOCKER_SPEC_SHA,
            "adopted inputs changed")
    require(manifest["source"]["commit"] == "f8f286c95cb9458fe3173190edbeab6076339b08",
            "I3 source commit changed")
    require(arm["imageId"] == IMAGE_ID and arm["archiveSha256"] == IMAGE_TAR_SHA
            and arm["buildId"] == BUILD_ID and host["buildId"] == BUILD_ID,
            "I3 artifact identity changed")
    require(actual["image_tar"] == IMAGE_TAR_SHA, "final I3 image tar differs")
    require(actual["host_build_info"] == host["fullFileManifestSha256"] and
            paths["host_build_id"].read_text().strip() == BUILD_ID and
            json.loads(paths["host_build_info"].read_text())["buildId"] == BUILD_ID,
            "final I3 packaged host inventory differs")
    require(actual["helper"] == HELPER_SHA and
            all(actual[name] == manifest["deployFiles"][filename]["packagedSha256"]
                for name, filename in (("compose", "compose.yaml"),
                                       ("maintenance_compose", "compose.maintenance.yaml"),
                                       ("health", "health.mjs"),
                                       ("service", "omne-center-backup@.service"),
                                       ("timer", "omne-center-backup@.timer"))),
            "final I3 helper files changed")
    require(actual["compose_binary"] == base.COMPOSE_SHA and actual["docker_cli"] == base.CLI_SHA,
            "fixed V0 tool bytes changed")
    require(args.uid == 10001 and args.gid == 10001 and args.hold_seconds >= 31.25,
            "reviewed UID or hold lower bound changed")
    require(args.scenario in ("write-hold", "close-fail"), "one explicit scenario required")
    require(args.observe_seconds >= 90 and args.term_observe_seconds > 0,
            "observation budget invalid")
    # Relocation of the exact immutable artifact is allowed; the packaged app
    # build-info and every deployment file are checked by bytes, not source path.
    return {"paths": {key: str(value.resolve()) for key, value in paths.items()},
            "sha256": actual, "image_id": IMAGE_ID, "build_id": BUILD_ID,
            "host_manifest_sha256": host["fullFileManifestSha256"],
            "uid": args.uid, "gid": args.gid, "scenario": args.scenario,
            "hold_seconds": args.hold_seconds, "observe_seconds": args.observe_seconds,
            "term_observe_seconds": args.term_observe_seconds}


def reviewed_inputs(args, inputs):
    require(args.reviewed_gate is not None, "root-reviewed gate required")
    gate = json.loads(args.reviewed_gate.read_text())
    require(gate.get("approved") is True and gate.get("reviewer") == "root"
            and gate.get("inputs_sha256") == canonical_hash(inputs)
            and gate.get("driver_sha256") == inputs["sha256"]["driver"]
            and gate.get("oracle_sha256") == inputs["sha256"]["oracle"],
            "missing or stale root-reviewed gate")


class IoRun(base.Run):
    def __init__(self, args, inputs):
        super().__init__(args, inputs)
        for name in ("driver.py", "base_driver.py", "gate.mjs", "gate_availability.mjs",
                     "inventory.mjs"):
            source = HERE / name
            target = self.frozen / name
            shutil.copyfile(source, target)
            require(base.sha(target) == inputs["sha256"][name.removesuffix(".py").removesuffix(".mjs")],
                    "script changed during freeze")
        shutil.copyfile(args.i3_manifest, self.frozen / "i3-manifest.json")
        self.evidence["scenario"] = args.scenario
        self.evidence["hold_seconds"] = args.hold_seconds
        self.evidence["artifact_manifest_sha256"] = inputs["sha256"]["i3_manifest"]
        self.save()
        self.async_clients = {}

    def asynchronous(self, label, argv):
        require(label not in self.async_clients, "duplicate async client")
        out = pathlib.Path("raw") / f"{label}.stdout"
        err = pathlib.Path("raw") / f"{label}.stderr"
        item = {"label": label, "argv": argv, "stdout": str(out), "stderr": str(err),
                "started_utc": base.utc(), "started_monotonic_ns": time.monotonic_ns(),
                "returncode": None, "observation_expired": False}
        self.evidence["commands"].append(item)
        self.save()
        stdout = (self.run / out).open("xb")
        stderr = (self.run / err).open("xb")
        try:
            process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=stdout,
                                       stderr=stderr, close_fds=True)
        finally:
            stdout.close()
            stderr.close()
        self.async_clients[label] = (item, process)
        self.pending_clients.append((label, process))
        return process

    def finish_async(self, label, timeout):
        item, process = self.async_clients[label]
        try:
            item["returncode"] = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            item["observation_expired"] = True
        item["finished_utc"] = base.utc()
        item["finished_monotonic_ns"] = time.monotonic_ns()
        self.save()
        require(not item["observation_expired"], label + ": result unknown after observation budget")

    def await_file(self, label, path, seconds=30):
        deadline = time.monotonic() + seconds
        for attempt in range(1, int(seconds * 5) + 2):
            observed = self.control_exec(f"{label}-poll-{attempt}", "test", "-f", path,
                                         expected=None, timeout=8)
            if self.evidence["commands"][-1]["returncode"] == 0:
                return json.loads(self.control_exec(label, "cat", path))
            if time.monotonic() >= deadline:
                break
            time.sleep(0.2)
        raise RuntimeError(label + ": file absent, outcome unknown")

    def observe_term(self, cid, event_start):
        # This is a read-only Engine query. The returned poll completes after the
        # actual kill event, so its local monotonic time is a conservative anchor.
        deadline = time.monotonic() + self.args.term_observe_seconds
        attempt = 0
        while time.monotonic() < deadline:
            attempt += 1
            label = f"term-poll-{attempt}"
            output = self.inner(label, "events", "--since", event_start,
                                "--until", base.utc(), "--filter", f"container={cid}",
                                "--filter", "event=kill", "--format", "{{json .}}",
                                timeout=8)
            events = [json.loads(line) for line in output.splitlines()]
            kills = [event for event in events if event.get("Action") == "kill"]
            require(all(event.get("Actor", {}).get("ID") == cid and
                        event.get("Actor", {}).get("Attributes", {}).get("signal")
                        in ("15", "SIGTERM") for event in kills),
                    "wrong-ID or wrong-signal Engine kill event")
            require(len(kills) <= 1, "duplicate Engine kill events before hold")
            if kills:
                stop = self.async_clients["stop-helper"][1]
                require(stop.poll() is None, "helper finished before TERM observation")
                self.evidence["term_observation"] = {
                    "poll_label": label, "monotonic_ns": time.monotonic_ns(),
                    "helper_pending": True,
                }
                self.save()
                return
            time.sleep(0.25)
        raise RuntimeError("TERM event not observed within read-only budget; outcome unknown")

    def prepare_qa(self):
        uid = str(self.args.uid)
        gid = str(self.args.gid)
        self.control_exec("qa-dir", "install", "-d", "-m", "0700", "-o", uid, "-g", gid,
                          base.STATE + "/qa")
        self.outer("qa-mode", "exec", "-i", self.control, "tee", base.STATE + "/qa/mode",
                   stdin=(self.args.scenario + "\n").encode())
        self.control_exec("qa-mode-owner", "chown", f"{uid}:{gid}", base.STATE + "/qa/mode")
        self.control_exec("qa-mode-permission", "chmod", "0600", base.STATE + "/qa/mode")
        dockerfile = (f"FROM {self.image_id}\nUSER 0:0\n"
                      "RUN install -d -m 0755 -o 0 -g 0 /probe\n"
                      "COPY --chown=10001:10001 gate.mjs /probe/gate.mjs\n"
                      "RUN chmod 0444 /probe/gate.mjs\n"
                      "USER 10001:10001\nENV NODE_OPTIONS=--import=/probe/gate.mjs\n"
                      "LABEL ai.nemori.omne.qa-fixture=maintenance-gate/r5\n")
        context = self.run / "qa-context.tar"
        with tarfile.open(context, "w") as tar:
            for name, contents in (("Dockerfile", dockerfile.encode()),
                                   ("gate.mjs", (self.frozen / "gate.mjs").read_bytes())):
                entry = tarfile.TarInfo(name)
                entry.size = len(contents)
                entry.mode = 0o644
                entry.mtime = 0
                tar.addfile(entry, io.BytesIO(contents))
        self.evidence["qa_context_sha256"] = base.sha(context)
        self.qa_tag = "omne-r5-io-qa:" + self.run_id.lower().replace("t", "-").replace("z", "")
        self.outer("qa-build", "exec", "-i", self.control, "docker", "--host", base.SOCKET,
                   "build", "--network=none", "--pull=false", "--no-cache", "-t", self.qa_tag,
                   "-", stdin=context, timeout=600)
        qa = json.loads(self.inner("qa-image-inspect", "image", "inspect", self.qa_tag))[0]
        require(qa["Id"] != self.image_id and qa["Config"]["User"] == "10001:10001"
                and qa["Config"]["Labels"].get("ai.nemori.omne.qa-fixture") == "maintenance-gate/r5",
                "QA image boundary invalid")
        self.qa_id = qa["Id"]
        self.evidence["qa_image_id"] = self.qa_id
        for label, image in (("original-inventory", self.image_id),
                             ("qa-inventory", self.qa_id)):
            self.outer(label, "exec", "-i", self.control, "docker", "--host", base.SOCKET,
                       "run", "--rm", "-i", "--pull", "never", "--network", "none",
                       "--label", self.label, "--entrypoint", "node", "-e", "NODE_OPTIONS=",
                       "-e", f"EXPECTED_BUILD_ID={BUILD_ID}",
                       "-e", f"EXPECTED_MANIFEST_SHA256={self.evidence['inputs']['host_manifest_sha256']}",
                       image, "--input-type=module", "-", stdin=self.frozen / "inventory.mjs",
                       timeout=180)
        original = json.loads((self.run / "raw/original-inventory.stdout").read_text())
        checked = json.loads((self.run / "raw/qa-inventory.stdout").read_text())
        require(original == checked and original.get("status") == "verified",
                "QA app inventory differs from production")
        gate_sha = self.evidence["inputs"]["sha256"]["gate"]
        self.outer("gate-availability", "exec", "-i", self.control, "docker", "--host", base.SOCKET,
                   "run", "--rm", "-i", "--pull", "never", "--network", "none",
                   "--label", self.label, "--user", f"{uid}:{gid}", "--entrypoint", "node",
                   "-e", "NODE_OPTIONS=", "-e", f"EXPECTED_GATE_SHA256={gate_sha}",
                   "-e", f"EXPECTED_UID={uid}", "-e", f"EXPECTED_GID={gid}",
                   self.qa_id, "--input-type=module", "-",
                   stdin=self.frozen / "gate_availability.mjs")
        avail = json.loads((self.run / "raw/gate-availability.stdout").read_text())
        require(avail.get("status") == "pass" and avail["directory"]["mode"] == "755",
                "QA preload unavailable to application UID")
        self.save()

    def contender_env(self):
        values = {
            "OMNE_TENANCY_STORAGE_DIALECT": "sqlite",
            "OMNE_TENANCY_STORAGE_FILE": "/state/data/center.sqlite",
            "OMNE_TENANCY_BACKUP_DIR": "/state/backups",
            "OMNE_TENANCY_OPS_SOCKET_DIR": "/run/omne-tenancy",
            "OMNE_TENANCY_ENTRY_LISTEN": "0.0.0.0:8443",
            "OMNE_TENANCY_ACTIVATION_SIGNING_KEY_PEM_FILE": "/secrets/activation-signing-key.pem",
            "OMNE_TENANCY_ACTIVATION_VERIFICATION_KEY_PEM_FILE": "/secrets/activation-verification-key.pem",
            "OMNE_TENANCY_PURGE_SIGNING_KEY_PEM_FILE": "/secrets/purge-signing-key.pem",
            "OMNE_TENANCY_PURGE_VERIFICATION_KEY_PEM_FILE": "/secrets/purge-verification-key.pem",
            "OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE": "/secrets/tls-chain.pem",
            "OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE": "/secrets/tls-private.pem",
        }
        return [part for key, value in values.items() for part in ("-e", f"{key}={value}")]

    def scenario(self):
        common = ["--project", self.project]
        deployment = [*common, "--image", self.qa_id, "--state-dir", base.STATE,
                      "--secrets-dir", base.SECRETS, "--settings-file", base.SETTINGS,
                      "--publish-address", "127.0.0.1", "--publish-port", "18443",
                      "--uid", str(self.args.uid), "--gid", str(self.args.gid)]
        self.helper("validate", "validate", *deployment)
        start = base.parse_json_line(self.helper("start", "start", *deployment,
                                                 timeout=self.args.observe_seconds), "start")
        cid = start.get("containerId")
        require(isinstance(cid, str) and base.HEX64.fullmatch(cid), "helper start lacked exact ID")
        self.center_id = cid
        self.evidence["center_id"] = cid
        self.await_file("gate-ready", base.STATE + "/qa/ready")
        self.inner("center-before-stop", "inspect", cid)
        self.control_exec("held-before-arm", "test", "!", "-e", base.STATE + "/qa/held")
        self.control_exec("arm-gate", "touch", base.STATE + "/qa/arm")
        self.evidence["armed_monotonic_ns"] = time.monotonic_ns()
        self.save()
        backup_argv = ["docker", "exec", "-e", f"DOCKER_HOST={base.SOCKET}", self.control,
                       base.HELPER, "backup", *common]
        self.asynchronous("backup-client", backup_argv)
        held = self.await_file("gate-held", base.STATE + "/qa/held")
        require(held.get("stage") == ("write" if self.args.scenario == "write-hold" else "close")
                and held.get("pid") == 1 and type(held.get("fd")) is int and held["fd"] >= 0
                and isinstance(held.get("path"), str) and FD_PATH.fullmatch(held["path"]),
                "gate did not hold real expected FileHandle")
        fd = f"/proc/1/fd/{held['fd']}"
        self.inner("fd-readlink", "exec", cid, "readlink", fd)
        self.inner("fd-stat", "exec", cid, "stat", "-Lc", "%d:%i:%u:%g:%a", fd)
        event_start = base.utc()
        self.evidence["event_start_utc"] = event_start
        self.save()
        stop_argv = ["docker", "exec", "-e", f"DOCKER_HOST={base.SOCKET}", self.control,
                     base.HELPER, "stop", *common]
        stop = self.asynchronous("stop-helper", stop_argv)
        self.observe_term(cid, event_start)
        time.sleep(self.args.hold_seconds)
        backup_returncode = self.async_clients["backup-client"][1].poll()
        self.evidence["midpoint"] = {
            "monotonic_ns": time.monotonic_ns(), "helper_pending": stop.poll() is None,
            "backup_pending": backup_returncode is None,
            "backup_returncode": backup_returncode,
        }
        self.save()
        self.inner("center-after-31s", "inspect", cid)
        self.inner("fd-readlink-after-31s", "exec", cid, "readlink", fd)
        self.inner("fd-stat-after-31s", "exec", cid, "stat", "-Lc", "%d:%i:%u:%g:%a", fd)
        if self.args.scenario == "close-fail":
            self.control_exec("marker-stat-held", "stat", "-c", "%F:%d:%i:%u:%g:%a:%s", MARKER)
            self.control_exec("marker-content-held", "cat", MARKER)
        self.inner("center-logs-held", "logs", cid)
        contender = self.project + "-contender"
        self.evidence["contender_name"] = contender
        contender_argv = ["run", "--pull", "never", "--name", contender, "--label", self.label,
                          "--network", "none", "--user", "10001:10001", "--restart", "no",
                          "--env-file", base.SETTINGS,
                          "-v", f"{base.STATE}:/state", "-v", f"{base.SECRETS}:/secrets:ro",
                          "--tmpfs", "/run/omne-tenancy:rw,nosuid,nodev,noexec,uid=10001,gid=10001,mode=0700",
                          *self.contender_env(), self.image_id, "serve"]
        self.inner("contender-run", *contender_argv, expected=None, timeout=25)
        self.inner("contender-final", "inspect", contender)
        self.control_exec("release-gate", "touch", base.STATE + "/qa/release")
        self.evidence["release_monotonic_ns"] = time.monotonic_ns()
        self.save()
        self.control_exec("gate-release-present", "test", "-f", base.STATE + "/qa/release")
        self.finish_async("stop-helper", self.args.observe_seconds)
        self.finish_async("backup-client", 30)
        self.inner("center-final", "inspect", cid)
        self.inner("center-logs-final", "logs", cid)
        self.inner("center-events", "events", "--since", event_start, "--until", base.utc(),
                   "--filter", f"container={cid}", "--format", "{{json .}}", timeout=20)
        if self.args.scenario == "close-fail":
            residual = base.STATE + held["path"][len("/state"):]
            self.control_exec("residual-stat", "stat", "-c", "%d:%i:%u:%g:%a", residual,
                              expected=None)
            self.control_exec("marker-stat-final", "stat", "-c", "%F:%d:%i:%u:%g:%a:%s", MARKER)
            self.control_exec("marker-content-final", "cat", MARKER)
        self.evidence["business_complete"] = True
        self.evidence["status"] = "observed-awaiting-oracle"
        self.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=("write-hold", "close-fail"), required=True)
    parser.add_argument("--i3-manifest", type=pathlib.Path, required=True)
    parser.add_argument("--image-tar", type=pathlib.Path, required=True)
    parser.add_argument("--helper-dir", type=pathlib.Path, required=True)
    parser.add_argument("--v0-dir", type=pathlib.Path, required=True)
    parser.add_argument("--design-root", type=pathlib.Path, required=True)
    parser.add_argument("--uid", type=int, default=10001)
    parser.add_argument("--gid", type=int, default=10001)
    parser.add_argument("--hold-seconds", type=float, default=31.5)
    parser.add_argument("--term-observe-seconds", type=float, default=15.0)
    parser.add_argument("--observe-seconds", type=int, default=180)
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    inputs = checked_inputs(args)
    if args.print_inputs:
        print(json.dumps({"inputs": inputs, "inputs_sha256": canonical_hash(inputs)}, sort_keys=True))
        return 0
    require(args.execute, "Docker execution requires --execute")
    reviewed_inputs(args, inputs)
    # base.Run expects exact input identities when it freezes final packaged files.
    args.image_id = IMAGE_ID
    args.build_id = BUILD_ID
    run = IoRun(args, inputs)
    try:
        run.setup()
        run.import_image()
        run.prepare_paths()
        run.prepare_qa()
        run.scenario()
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
        run.save()
    finally:
        run.cleanup()
    with (run.run / "oracle.stdout").open("xb") as stdout, (run.run / "oracle.stderr").open("xb") as stderr:
        checked = subprocess.run([sys.executable, "-B", str(run.frozen / "oracle.py"), str(run.run)],
                                 stdout=stdout, stderr=stderr, check=False)
    run.evidence["oracle_exit"] = checked.returncode
    run.save()
    print(json.dumps({"run": str(run.run), "scenario": args.scenario,
                      "oracle_exit": checked.returncode,
                      "cleanup_complete": run.evidence["cleanup_complete"]}, sort_keys=True))
    return 0 if checked.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
