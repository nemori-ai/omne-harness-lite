#!/usr/bin/env python3
"""Offline mutations proving the R5 IO oracle rejects representative false success."""

import copy
import hashlib
import json
import pathlib
import tempfile

import oracle

HERE = pathlib.Path(__file__).resolve().parent
CID = "a" * 64
CONTENDER = "b" * 64
QA_ID = "sha256:" + "c" * 64
SOURCE = "/state/backups/.quarantine/export-" + "d" * 32
CONTROL = "omne-r5-selftest-control"
SOCKET = "unix:///opt/omne-private-docker/docker.sock"
STATE = "/var/lib/omne-tenancy/state"
EVENT_START = "2026-09-27T00:00:00+00:00"


def encoded(value):
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        return value.encode()
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def fixture(run, scenario):
    (run / "raw").mkdir()
    (run / "inputs").mkdir()
    sha = {}
    for name in ("driver.py", "base_driver.py", "oracle.py", "gate.mjs",
                 "inventory.mjs", "gate_availability.mjs"):
        content = (HERE / name).read_bytes()
        (run / "inputs" / name).write_bytes(content)
        sha[name.removesuffix(".py").removesuffix(".mjs")] = hashlib.sha256(content).hexdigest()
    # Read-only copy of the actual final I3 manifest exercises its frozen identity.
    real = pathlib.Path("/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery/tmp/docker-delivery/i3-f8f286c9/manifest-delivery.json")
    if not real.is_file():
        raise RuntimeError("frozen I3 manifest required for offline self-test")
    (run / "inputs/i3-manifest.json").write_bytes(real.read_bytes())
    sha.update({"gate": hashlib.sha256((HERE / "gate.mjs").read_bytes()).hexdigest()})
    commands = []

    def add(label, argv=None, stdout=b"", stderr=b"", rc=0, **extra):
        out_path = "raw/" + label + ".stdout"
        err_path = "raw/" + label + ".stderr"
        (run / out_path).write_bytes(encoded(stdout))
        (run / err_path).write_bytes(encoded(stderr))
        commands.append({"label": label, "argv": argv or [], "stdout": out_path,
                         "stderr": err_path, "returncode": rc,
                         "observation_expired": False, **extra})

    inventory = {"status": "verified", "buildId": oracle.BUILD_ID, "files": 2851,
                 "links": 115, "manifestSha256": "e" * 64, "node": "v24.21.0"}
    original_image = {"Id": oracle.ORIGINAL_ID, "RootFS": {"Layers": ["sha256:" + "1" * 64]},
                      "Config": {"Labels": {"ai.nemori.omne.host-build-id": oracle.BUILD_ID},
                                 "Env": [], "Entrypoint": ["node", "/opt/omne/app/dist/cli.js"],
                                 "Cmd": ["serve"]}}
    add("inner-image-inspect", stdout=[original_image])
    add("outer-product-image", stdout=[original_image])
    add("original-inventory", stdout=inventory)
    add("qa-inventory", stdout=inventory)
    qa = {"Id": QA_ID, "Config": {"Labels": {"ai.nemori.omne.qa-fixture": "maintenance-gate/r5"},
                                     "Env": ["NODE_OPTIONS=--import=/probe/gate.mjs"],
                                     "Entrypoint": original_image["Config"]["Entrypoint"],
                                     "Cmd": original_image["Config"]["Cmd"]},
          "RootFS": {"Layers": [*original_image["RootFS"]["Layers"], "sha256:" + "2" * 64]}}
    add("qa-image-inspect", stdout=[qa])
    add("gate-availability", stdout={"status": "pass", "uid": 10001, "gid": 10001,
                                     "directory": {"mode": "755"}, "file": {"isFile": True},
                                     "actualSha256": sha["gate"]})
    prefix = ["docker", "exec", "-e", "DOCKER_HOST=" + SOCKET, CONTROL,
              "/usr/local/libexec/omne-center"]
    add("validate", [*prefix, "validate"], {"state": "deployment-structure-valid"})
    add("start", [*prefix, "start"], {"state": "running", "containerId": CID,
                                      "imageId": QA_ID, "buildId": oracle.BUILD_ID,
                                      "health": "healthy"})
    running = {"Id": CID, "Image": QA_ID, "Config": {"StopSignal": "SIGTERM",
               "StopTimeout": -1, "User": "10001:10001"},
               "HostConfig": {"RestartPolicy": {"Name": "unless-stopped"}},
               "State": {"Status": "running", "Pid": 1, "StartedAt": "time-1"},
               "Mounts": [{"Destination": "/state", "Source": STATE}]}
    add("gate-ready", stdout={"stage": "ready", "mode": scenario, "pid": 1, "armed": False})
    add("center-before-stop", stdout=[running])
    add("held-before-arm", ["test", "!", "-e", STATE + "/qa/held"])
    add("arm-gate", ["touch", STATE + "/qa/arm"])
    add("backup-client", [*prefix, "backup"], stderr="ops result unconfirmed\n", rc=1)
    held = {"stage": "write" if scenario == "write-hold" else "close",
            "pid": 1, "fd": 17, "path": SOURCE, "dev": 2048, "ino": 901}
    add("gate-held", stdout=held)
    descriptor = "/proc/1/fd/17"
    add("fd-readlink", ["docker", "exec", CID, "readlink", descriptor], SOURCE + "\n")
    add("fd-stat", ["docker", "exec", CID, "stat", descriptor], "2048:901:10001:10001:600\n")
    expected_exit = 0 if scenario == "write-hold" else 1
    add("stop-helper", [*prefix, "stop"],
        {"state": "stopped" if expected_exit == 0 else "stopped-with-error",
         "containerId": CID, "exitCode": expected_exit, "clean": expected_exit == 0},
        stderr="term-request container=" + CID + "\n", rc=expected_exit,
        started_monotonic_ns=100_000_000_000)
    term_event = ('{"Action":"kill","Actor":{"ID":"' + CID +
                  '","Attributes":{"signal":"15"}}}\n')
    add("term-poll-1", ["docker", "exec", CONTROL, "docker", "--host", SOCKET,
                        "events", "--since", EVENT_START, "--until", "2026-09-27T00:00:01+00:00",
                        "--filter", "container=" + CID, "--filter", "event=kill"],
        term_event)
    add("center-after-31s", stdout=[running])
    add("fd-readlink-after-31s", ["docker", "exec", CID, "readlink", descriptor], SOURCE + "\n")
    add("fd-stat-after-31s", ["docker", "exec", CID, "stat", descriptor],
        "2048:901:10001:10001:600\n")
    if scenario == "close-fail":
        add("marker-stat-held", ["stat", oracle.MARKER], "regular file:2048:777:10001:10001:600:16\n")
        add("marker-content-held", ["cat", oracle.MARKER], oracle.MARKER_CONTENT)
    add("center-logs-held", stderr='{"event":"still-stopping"}\n')
    add("contender-run", ["docker", "run", oracle.ORIGINAL_ID, "serve"],
        stderr='{"stage":"occupied"}\n', rc=1)
    add("contender-final", ["docker", "inspect", "selftest-contender"],
        [{"Id": CONTENDER, "Name": "/selftest-contender", "Image": oracle.ORIGINAL_ID,
          "Mounts": [{"Destination": "/state", "Source": STATE}],
          "State": {"Status": "exited", "ExitCode": 1}}])
    add("release-gate", ["touch", STATE + "/qa/release"])
    add("gate-release-present", ["test", "-f", STATE + "/qa/release"])
    final = copy.deepcopy(running)
    final["State"] = {"Status": "exited", "Running": False,
                       "ExitCode": expected_exit, "StartedAt": "time-1"}
    add("center-final", stdout=[final])
    logs = ('{"event":"maintenance-residual","path":"' + SOURCE + '"}\n'
            '{"event":"dispose-incomplete","controller":"error"}\n'
            '{"event":"disposed","complete":false}\n') if scenario == "close-fail" else \
           '{"event":"disposed","complete":true}\n'
    add("center-logs-final", stderr=logs)
    add("center-events", ["docker", "events", "--since", EVENT_START,
                          "--filter", "container=" + CID],
        term_event)
    if scenario == "close-fail":
        add("residual-stat", ["stat", STATE + SOURCE[len("/state"):]],
            "2048:901:10001:10001:600\n")
        add("marker-stat-final", ["stat", oracle.MARKER], "regular file:2048:777:10001:10001:600:16\n")
        add("marker-content-final", ["cat", oracle.MARKER], oracle.MARKER_CONTENT)
    cleanup = []
    for label in ("cleanup-final-list-container", "cleanup-final-list-volume",
                  "cleanup-final-list-network", "cleanup-inner-project-final-list",
                  "cleanup-inner-fixture-final-list", "cleanup-inner-all-final-list"):
        path = "raw/" + label + ".stdout"
        (run / path).write_bytes(b"")
        cleanup.append({"label": label, "stdout": path, "returncode": 0})
    evidence = {"commands": commands, "cleanup_commands": cleanup,
                "scenario": scenario, "center_id": CID, "qa_image_id": QA_ID,
                "contender_name": "selftest-contender", "artifact_manifest_sha256": oracle.I3_SHA,
                "inputs": {"image_id": oracle.ORIGINAL_ID, "build_id": oracle.BUILD_ID,
                           "host_manifest_sha256": "e" * 64, "sha256": sha},
                "expected": {"control": CONTROL, "state": STATE,
                             "image_id": oracle.ORIGINAL_ID, "inner_image_id": oracle.ORIGINAL_ID},
                "midpoint": {"monotonic_ns": 132_000_000_000, "helper_pending": True,
                             "backup_pending": True}, "release_monotonic_ns": 133_000_000_000,
                "term_observation": {"poll_label": "term-poll-1",
                                     "monotonic_ns": 100_500_000_000, "helper_pending": True},
                "event_start_utc": EVENT_START,
                "armed_monotonic_ns": 99_000_000_000, "business_complete": True,
                "cleanup_complete": True, "cleanup_errors": []}
    (run / "evidence.json").write_text(json.dumps(evidence))
    return evidence


def check_mutation(scenario, name, change):
    with tempfile.TemporaryDirectory(dir=HERE, prefix=".selftest-") as directory:
        run = pathlib.Path(directory)
        evidence = fixture(run, scenario)
        if name == "positive":
            oracle.evaluate(run)
            return
        change(run, evidence)
        (run / "evidence.json").write_text(json.dumps(evidence))
        try:
            oracle.evaluate(run)
        except (KeyError, IndexError, ValueError, TypeError):
            return
        raise AssertionError(name + ": false success was accepted")


def mutate_raw(label, edit):
    def change(run, evidence):
        path = run / "raw" / (label + ".stdout")
        path.write_bytes(encoded(edit(json.loads(path.read_text()))))
    return change


def stale_term_window(_run, evidence):
    item = next(row for row in evidence["commands"] if row["label"] == "term-poll-1")
    item["argv"][item["argv"].index("--since") + 1] = "2020-01-01T00:00:00+00:00"


def main():
    cases = [
        ("wrong-center-id", mutate_raw("center-final", lambda a: [{**a[0], "Id": "f" * 64}])),
        ("short-hold", lambda _r, e: e["midpoint"].update(monotonic_ns=130_000_000_000)),
        ("late-term-after-helper-31s", lambda _r, e: e["term_observation"].update(
            monotonic_ns=131_000_000_000)),
        ("stale-term-window", stale_term_window),
        ("helper-finished-early", lambda _r, e: e["midpoint"].update(helper_pending=False)),
        ("released-before-check", lambda _r, e: e.update(release_monotonic_ns=131_000_000_000)),
        ("fd-released", lambda r, _e: (r / "raw/fd-readlink-after-31s.stdout").write_text("gone\n")),
        ("fd-inode-changed", lambda r, _e: (r / "raw/fd-stat-after-31s.stdout").write_text(
            "2048:999:10001:10001:600\n")),
        ("owner-released", mutate_raw("contender-final", lambda a: [{**a[0],
            "State": {"Status": "exited", "ExitCode": 0}}])),
        ("app-exit-wrong", mutate_raw("center-final", lambda a: [{**a[0],
            "State": {**a[0]["State"], "ExitCode": 42}}])),
        ("no-term", lambda r, _e: (r / "raw/center-events.stdout").write_text(
            '{"Action":"die","Actor":{"ID":"' + CID + '"}}\n')),
        ("cleanup-failed", lambda _r, e: e.update(cleanup_complete=False)),
        ("empty-helper-result", lambda r, _e: (r / "raw/stop-helper.stdout").write_bytes(b"")),
    ]
    checked = []
    for scenario in ("write-hold", "close-fail"):
        check_mutation(scenario, "positive", None)
        checked.append(scenario + ":positive")
        for name, change in cases:
            check_mutation(scenario, name, change)
            checked.append(scenario + ":" + name)
        wrong_clean = scenario == "write-hold"
        check_mutation(scenario, "wrong-helper-clean", mutate_raw("stop-helper", lambda a:
                       {**a, "clean": not wrong_clean, "exitCode": 1 if wrong_clean else 0}))
        checked.append(scenario + ":wrong-helper-clean")
        check_mutation(scenario, "wrong-helper-cli-code", lambda _r, e:
                       next(row for row in e["commands"] if row["label"] == "stop-helper").update(
                           returncode=1 if scenario == "write-hold" else 0))
        checked.append(scenario + ":wrong-helper-cli-code")
    check_mutation("close-fail", "wrong-residual-inode", lambda r, _e:
                   (r / "raw/residual-stat.stdout").write_text("2048:999:10001:10001:600\n"))
    checked.append("close-fail:wrong-residual-inode")
    for name, file, contents in (
        ("marker-held-missing", "marker-content-held.stdout", b""),
        ("marker-final-content", "marker-content-final.stdout", b"tampered\n"),
        ("marker-mode", "marker-stat-final.stdout", b"regular file:2048:777:10001:10001:644:16\n"),
    ):
        check_mutation("close-fail", name, lambda r, _e, f=file, c=contents:
                       (r / "raw" / f).write_bytes(c))
        checked.append("close-fail:" + name)
    print(json.dumps({"status": "pass", "docker_executed": False,
                      "positive_scenarios": 2, "rejected_mutations": len(checked) - 2,
                      "cases": checked}, sort_keys=True))


if __name__ == "__main__":
    main()
