# Docker R5 长 IO / close 残余：静态验收夹具

本目录是 `pandazki/agent-work-loop-docker-r5-io`、HEAD `f8f286c95cb9458fe3173190edbeab6076339b08` 上的 ignored 临时交接。**本轮未调用 Docker、未 build、未调用模型或读取真实凭据，也没有产品验收结果。**两个单格必须由 root 复审输入与脚本后分别放行一次；无 `--execute` 和场景专属 `reviewed-gate.json` 时，驱动在首次 Docker 命令前拒绝。

## 输入和判据

- 已接受 D-071 `governance-docker-stop-adoption/decision.md` 与 provider snapshot；`realization/apps/tenancy-host/docker.md` SHA256 `3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223`，同节点 `maintenance-binding.md` 和 `verification.md`；EC3 v3 `S-55`～`S-59`/Schema、HT3 v3 `S-20`～`S-21`。实施安排是 HUB `tmp/next-iteration/tasks/docker-delivery.md` 的 DK-I6/I7、V0/I3 和 `docker-stop-r5-implementation.md`。旧 I1 IO 记录仅为夹具先导。
- 最终 I3 manifest `manifest-delivery.json` SHA256 `c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e`，host BUILD_ID `7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616`，arm64 image ID `sha256:27c0665146265afefe39012aaea26bdae7499784eaaeb74aea712a6fcdfc03f2`，tar SHA256 `503fc0c6006d5d654e1e288bbff1af806ec041163d56223bac7e322391653de2`，packaged helper SHA256 `71ba9f3c31b34c171dd2a4048d9e249af31f7948abcf66ee603da5ffb7d1b365`。`--print-inputs` 对实际文件重算，固定源提交、包内文件、V0 CLI/Compose 与采用 Docker 映射同时校验。arm64 是本夹具唯一目标架构。
- 两个显式场景各自使用新 run、新 project 和私有 Engine。原 I3 镜像经 tar 导入；QA 镜像仅增加 `/probe/gate.mjs`、`NODE_OPTIONS` 与 QA label，原 `/opt/omne/app` 每件文件/软链由最终 `build-info.json` 重新核对；目标 UID 10001 读到 `/probe:0755` 和精确 gate SHA 后才启动。**gate 只在正式 helper start 健康返回后写 `arm`；它只拦 `/state/backups/.quarantine/export-<32hex>` 的 `wx/0600` FileHandle。**这消除了旧启动期误拦反例。未出现 `held` 前不得发 stop。
- `write-hold`：真实 helper backup 获取源 FD；在 PID1 `/proc/1/fd` 上核 dev/inode/UID/GID/0600，调用 root 控制容器中的正式 helper stop 一次。先只读轮询私有 Engine 中 exact-ID 的 SIGTERM `kill` event；**从该查询返回后的本机 monotonic 锚点再等超过 31 秒**，helper 与备份仍 pending、同 PID/FD/inode 仍在。未插桩原镜像以同一 `/state` 起第二 owner，实际 exit1/`occupied`。释放后 helper stdout 恰 `containerId` 原 ID、`exitCode:0`、`clean:true`，实际同 ID exited/0。
- `close-fail`：同样先持有真实 close 边界并满足 TERM 后 >31 秒/第二 owner 拒绝；release 后 gate 对真实 FileHandle.close 抛 EIO。helper 必须 exit1、`stopped-with-error`/`clean:false`，应用实际同 ID exited/1；隔离残余路径须与 held FD 同 dev/inode、UID/GID10001、0600。`/state/backups/.quarantine/.omne-isolated` 在 held 时及退出后均须为同 inode 普通文件、10001/10001、0600、精确字节 `omne-isolated/1\n`（实施映射为 `packages/infra/storage-sql/src/sqlite/protection.ts`）；日志含 `maintenance-residual`、controller error、`disposed complete:false`，不能有 clean true。备份客户端不能报 completed。每格还核 Engine 只有一次 exact-ID SIGTERM `kill` event、没有窗口内重启。只读 TERM 轮询有限到期即 unknown；不会补发 stop。

测量器使用复制的已运行私有 Linux control/systemd + DinD 基础 `base_driver.py`，固定 control/DinD image ID 与 Engine29.1.3、Compose2.40.3、私有 Unix `DOCKER_HOST`。外层用户 Docker 只建/删本轮唯一 label `omne.r5.helper-prep=<run-id>` 的 control、DinD、三个 named volume 和网络；control **不挂用户 Docker socket**。control、DinD、原/QA 应用对 `/var/lib/omne-tenancy/state` 的 inode/UID/marker 先在基础驱动核对，场景再读真实 FD。所有产品 helper stdout/stderr 在命令开始时直接写 `runs/<id>/raw/`；有限本地观察预算届满记 unknown，不自动重试或用清理转换为成功。`finally` 的 `rm -f` 只针对本轮私有 label/project 资源，独立于业务停止；失败同样保存 raw 和 cleanup 状态。

## 当前离线结果与文件

`PYTHONDONTWRITEBYTECODE=1 python3 -B self_test.py > offline-self-test.json`：两种合成正例通过，34 个反例被 oracle 拒绝，含错 ID、TERM 很晚才到但 helper 已启动 31 秒、使用过期事件窗口、helper 提前收场、FD/残余换 inode、owner 获准、应用或 CLI 结果错、无 TERM、提前 release、marker 缺失/模式或内容错误、空 stop 输出及 cleanup 假成功。`python3` AST parse 与 `node --check` 对本目录脚本均通过。`--print-inputs` 对最终 I3 与 V0 精确文件两场景均返回 0；冻结输出是 `static-inputs-write.json`（input SHA `e1ab938d184faa6740afc03239dbf7c29f8ad23f579d7f3a1c953630af5611dc`）和 `static-inputs-close.json`（input SHA `c48b7a9278b59729bb0dea23000112eff2dd410b4e35a9034928c14c0ddf9c5f`）。制品可搬运到别处，预检仍须重算 tar、包内 build-info/BUILD_ID 和部署文件 hash；这只是输入静态预检，合成数据不证明真实 app 行为。

关键脚本 SHA256：`driver.py` `7c9f7b398828e53dea7967d28f2afe9d36dbbd7b0a9001bad4cc41a97e0055e7`；`base_driver.py` `a450179ed522b8ab2033f0aa368c5d4ad3fe43139353b9d14d24afb01915da26`；`oracle.py` `203b74daecab24be92efbd3acc484d02b8fb9840545f543c835e05e9b3605da3`；`gate.mjs` `6c3c99cf9feb308f9bdf6adcdbb96e52eced7ffd7acc56c5b371d44d3425e34d`；`inventory.mjs` `e34066264f428780fd3aa79def7c98461a315ff1b5243ca11038c2d6736b3517`；`gate_availability.mjs` `62a60c445e8f244d59c6a84f14f7d197dd4e0e72aa5d64e2f6d96df68cf9cb24`。`base_driver.py` 是旧 R5 helper smoke 环境代码原字节；其 `smoke()` 不由此驱动调用。

## root 复审后的最小单次运行

在本目录执行。`IO_I3`、`IO_V0`、`IO_DESIGN` 是本任务输入路径，不从当前 Git 根猜测：

```sh
IO_I3=/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery/tmp/docker-delivery/i3-f8f286c9
IO_V0=/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-fixtures/tmp/docker-product-fixtures/v0c
IO_DESIGN=/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-r5-io/.meta_harness/design
python3 -B driver.py --scenario write-hold --i3-manifest "$IO_I3/manifest-delivery.json" --image-tar "$IO_I3/center-arm64.tar" --helper-dir "$IO_I3/host-unpacked/app/deploy/docker" --v0-dir "$IO_V0" --design-root "$IO_DESIGN" --print-inputs
```

`close-fail` 换场景名再打印。root 核实际文件和上述 script/input SHA 后，为**每个场景**单独写 `reviewed-gate-<scenario>.json`：`{"approved":true,"reviewer":"root","inputs_sha256":"<该场景打印值>","driver_sha256":"<driver SHA>","oracle_sha256":"<oracle SHA>"}`。实际单次调用用完全相同参数，将 `--print-inputs` 换为 `--reviewed-gate <对应绝对路径> --execute`。返回的 `run` 目录与 `oracle.stdout/stderr`、全部 raw、cleanup 需要 root 保全；可用 `python3 -B oracle.py <run目录>` 离线复算。若 root 再改任何脚本、I3 文件或参数，须重新打印并复审；不得复用旧 gate。两个场景按顺序各跑一次，不自动重试失败。

计划内若另加计划私有 daemon 重启观察，必须在**同一已退出且 oracle 通过的精确 ID**、健康 metadata、无并发 daemon shutdown/外部管理命令前提下，保存前后 `Status/StartedAt/RestartCount` 与 Engine event，核重启 daemon 后该 ID 仍 exited、没有 start event。该草稿没有纳入当前 driver/oracle，也不能由 `clean:true` 自动推出。当前未覆盖两架构完整治理/TLS、timer、强杀与 guard、真实断电、并发 shutdown、失联/空 wait 注入、离线取消竞态或无条件 Engine 标记耐久；分别留给 DK-I7/I8/I10 和其它验收。此次 close EIO 是 QA FileHandle 注入，不等于物理介质故障。
