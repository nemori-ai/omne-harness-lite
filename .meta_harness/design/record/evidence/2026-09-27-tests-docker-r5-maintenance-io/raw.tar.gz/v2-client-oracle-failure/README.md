# R5 IO 静态候选 v2 · legacy builder 兼容修正

本目录只对 root 已审的第一版夹具做一个 QA Dockerfile 修正。第一次获授权 write-hold 实跑的原件完整留在相邻 `tmp/docker-r5-io/`：run `runs/20260926T200718Z-3aa15e0d` 在 QA build Step 4 被 private control 中的 legacy builder 拒绝 `COPY --chmod`，应用、backup、stop 均未启动；它是**测量器准备失败，不能判产品通过或失败**。该 run 的原始 stdout/stderr、oracle、cleanup、独立宿主三类 exact-label 空查询与 195 件全文件 SHA 清单 `actual-run-files.sha256.json`（SHA256 `617018b4d12d3ebd8e57dfc5b5dea45c0b283d15dba054ba9caadd4cebacd549`）均在旧目录；v2 没有覆盖旧脚本、gate 或 raw。

`driver.diff` 是 v1→v2 唯一代码差异：QA build 先 `COPY --chown=10001:10001 gate.mjs /probe/gate.mjs`，再由镜像构建期 root 执行 `RUN chmod 0444 /probe/gate.mjs`。`FROM` 仍为本次 private Engine 导入的最终 I3 image，`/probe` 仍显式建 0755，最后仍 `USER 10001:10001` 并仅在 QA image 增 `NODE_OPTIONS`。不安装 buildx、不 pull 新组件、不改产品镜像；完整 app inventory、目标 UID 的 gate 可读/hash 检查和原两场景 oracle 均保持。

静态输入仍钉 D-071、EC3 v3 S-55～S-59/Schema、HT3 v3 S-20～S-21、tenancy-host Docker 映射 SHA256 `3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223`、I3 manifest SHA256 `c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e` 与 arm64 tar SHA256 `503fc0c6006d5d654e1e288bbff1af806ec041163d56223bac7e322391653de2`。`--print-inputs` 本轮 write-hold SHA256 `9b03846c7d7642a8971db5cdda44d7ed646c66b7e92728ef8b747605b9f216ad`；close-fail 静态输入 SHA256 `4f2b0aa7cc6b5a4ce0e1543c1a6692af9dff3e07723a7d9acd3e20a4afa66152`，但该场景**未获实跑授权**。

本轮离线执行 `PYTHONDONTWRITEBYTECODE=1 python3 -B self_test.py > offline-self-test.json`，两合成正例/34 个反例通过；Python AST 与 Node24.21.0 `--check` 通过，`--print-inputs` 两场景返回0。`driver.py` SHA256 `c5892686ba2e951edd19cf9e7a13e57151fe28a80095237753eb30b257ed86ab`，`oracle.py` SHA256 `203b74daecab24be92efbd3acc484d02b8fb9840545f543c835e05e9b3605da3`，`gate.mjs` SHA256 `6c3c99cf9feb308f9bdf6adcdbb96e52eced7ffd7acc56c5b371d44d3425e34d`。全部文件与哈希见 `manifest-static.json`。

本目录还没有 `reviewed-gate`，没有 Docker/build/产品运行。root 审 `driver.diff`、新 input hash 与 manifest 后，才可为 **v2 write-hold** 单独给 gate 和 exact argv。v1 gate 的 driver/input hash 与本目录不匹配，不得复用；失败也不自动重试。真实执行的私有 label、原始 stdout/stderr、root helper TERM 后31秒锚点、同一FD/第二owner、业务结果与夹具 cleanup 判据仍按未改的 driver/oracle；实际运行后须独立宿主 exact-label 查询并保全所有文件哈希。daemon 重启、timer、close-fail 等未在本次修正中获得实际证据。
