# R5 IO measurement candidate review

Root read driver.py (363 lines), base Run constructor and reused environment provenance, gate.mjs, inventory.mjs, gate_availability.mjs and oracle.py (283 lines). Product inputs remain f8f286c9 / final I3 manifest c97c8584… / D071 node 3720aebc… . No actual IO run is released yet.

Two gaps sent to the independent measurement author:

1. The >31 second hold interval begins at the outer helper client spawn, not at observation that Engine accepted the exact TERM. A delayed Docker request could therefore satisfy the old elapsed check without >31 seconds of post-TERM resource retention. Require a read-only exact-ID SIGTERM Engine event observation, anchor local monotonic after that observation, then hold; negative test delays TERM despite an old helper launch.
2. Close-error residual identity and 0600 mode alone do not establish its permanent ancestor marker remained. Read the actual online quarantine workRoot/.omne-isolated type, owner/mode and exact content while held and after exit; preserve marker as part of the oracle. No target-root marker is invented.

Retain the existing raw gate FileHandle/FD/inode observations, noninstrumented second-owner rejection, actual app exit vs helper exit distinction, exact source/code inventories, and fixture cleanup separation. These changes clarify measurement of accepted properties; no new product policy, real daemon-restart claim or physical EIO guarantee is introduced. Original static revision must remain recoverable.

Final revised anchor and marker segments reviewed; 11 current static files independently hashed/copied. Earlier candidate bytes were not preserved by author; no prior hash or earlier offline result is used as evidence. Only the current exact scripts and 2-positive/34-negative offline result enter this release. One write-hold actual run authorized; close-fail still unrun and ungated.
