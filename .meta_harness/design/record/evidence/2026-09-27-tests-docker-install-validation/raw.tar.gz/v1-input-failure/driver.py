#!/usr/bin/env python3
"""Root-gated DK-I3 Linux installation negatives; no Docker without --execute."""
import argparse
import hashlib
import importlib.util
import json
import pathlib
import re
import shutil
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
TREE = HERE.parents[1]
I3 = pathlib.Path(
    "/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery/tmp/docker-delivery/i3-f8f286c9"
)
MANIFEST = I3 / "manifest-delivery.json"
MANIFEST_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
BASE = pathlib.Path(
    "/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-fixtures/tmp/docker-product-fixtures/r5-helper-prep/driver.py"
)
BASE_SHA = "a450179ed522b8ab2033f0aa368c5d4ad3fe43139353b9d14d24afb01915da26"
CROSS = TREE / "tmp/docker-business-backup/driver.py"
CROSS_SHA = "1cf7fa954ddbdada5a04f6a3ee46ebc621c20c76f7df1ce9b5d5b1beabc8b098"
HELPER_DIR = TREE / "apps/tenancy-host/deploy/docker"
SOURCE_COMMIT = "f8f286c95cb9458fe3173190edbeab6076339b08"
HOST_BUILD = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
HELPER_SHA = "71ba9f3c31b34c171dd2a4048d9e249af31f7948abcf66ee603da5ffb7d1b365"
NODE_SHA = "3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223"
UID = 12017
GID = 12019
STAT = "%n|%F|%u|%g|%a|%d|%i|%s"
CASES = (
    ("uid0", "invalid-uid"),
    ("data_mode", "private-directory-permission"),
    ("data_owner", "private-directory-permission"),
    ("secret_mode", "private-file-permission"),
    ("state_link", "invalid-state-path"),
    ("ancestor_link", "invalid-state-path"),
    ("ancestor_marker", "isolated-state-ancestor"),
    ("settings_missing", "settings-missing-OMNE_TENANCY_UNACTIVATED_RETENTION"),
    ("settings_unknown_storage", "settings-unknown-key"),
    ("compose_file_override", "compose-override-prohibited"),
)


def need(test, message):
    if not test:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with pathlib.Path(path).open("rb") as file:
        for block in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def load_checked(name, path, expected):
    need(sha(path) == expected, name + " dependency changed")
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None, name + " import unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def input_set():
    need(sha(MANIFEST) == MANIFEST_SHA, "I3 manifest changed")
    need(sha(BASE) == BASE_SHA and sha(CROSS) == CROSS_SHA, "accepted runners changed")
    manifest = json.loads(MANIFEST.read_text())
    image = manifest["images"]["arm64"]
    need(
        manifest["source"]["commit"] == SOURCE_COMMIT
        and manifest["archives"]["host"]["buildId"] == HOST_BUILD
        and image["buildId"] == HOST_BUILD
        and image["platform"] == "linux/arm64",
        "final I3 identity changed",
    )
    v0 = BASE.parent.parent / "v0c"
    paths = {
        "helper": HELPER_DIR / "omne-center",
        "compose": HELPER_DIR / "compose.yaml",
        "maintenance_compose": HELPER_DIR / "compose.maintenance.yaml",
        "health": HELPER_DIR / "health.mjs",
        "service": HELPER_DIR / "omne-center-backup@.service",
        "timer": HELPER_DIR / "omne-center-backup@.timer",
        "image_tar": pathlib.Path(image["archive"]),
        "compose_binary": v0 / "docker-compose-linux-aarch64",
        "docker_cli": v0 / "extracted-bin/docker",
        "manifest": MANIFEST,
        "v0_driver": BASE,
        "cross_driver": CROSS,
        "driver": HERE / "driver.py",
        "oracle": HERE / "oracle.py",
        "component_probe": HERE / "component_probe.sh",
        "component_create": HERE / "component_create.sh",
        "extra_mount": HERE / "qa-extra-mount.yaml",
    }
    hashes = {name: sha(path) for name, path in paths.items()}
    for key, deploy in (
        ("helper", "omne-center"),
        ("compose", "compose.yaml"),
        ("maintenance_compose", "compose.maintenance.yaml"),
        ("health", "health.mjs"),
        ("service", "omne-center-backup@.service"),
        ("timer", "omne-center-backup@.timer"),
    ):
        need(
            hashes[key] == manifest["deployFiles"][deploy]["sourceSha256"],
            key + " deploy SHA",
        )
    need(
        hashes["helper"] == HELPER_SHA
        and hashes["image_tar"] == image["archiveSha256"]
        and hashes["manifest"] == MANIFEST_SHA
        and hashes["v0_driver"] == BASE_SHA
        and hashes["cross_driver"] == CROSS_SHA,
        "final input SHA",
    )
    need(
        hashes["compose_binary"]
        == "d26373b19e89160546d15407516cc59f453030d9bc5b43ba7faf16f7b4980137"
        and hashes["docker_cli"]
        == "544cf329807e30c9601652562a159b17179345146be0f8211bfe2ebd872eb880",
        "fixed private control tool SHA",
    )
    need(
        sha(TREE / ".meta_harness/design/realization/apps/tenancy-host/docker.md")
        == NODE_SHA,
        "accepted Docker realization SHA",
    )
    current = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=TREE,
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    need(current == SOURCE_COMMIT, "execution checkout changed")
    return {
        "paths": {name: str(path.resolve()) for name, path in paths.items()},
        "sha256": hashes,
        "source_commit": SOURCE_COMMIT,
        "image_id": image["imageId"],
        "build_id": HOST_BUILD,
        "platform": "arm64",
        "uid": UID,
        "gid": GID,
        "observe_seconds": 600,
        "timer_observe_seconds": 30,
        "node_sha256": NODE_SHA,
        "case_reasons": dict(CASES),
    }


def args_for_run(inputs, gate):
    return argparse.Namespace(
        helper_dir=HELPER_DIR,
        image_tar=pathlib.Path(inputs["paths"]["image_tar"]),
        image_id=inputs["image_id"],
        build_id=inputs["build_id"],
        uid=UID,
        gid=GID,
        observe_seconds=600,
        timer_observe_seconds=30,
        reviewed_gate=gate,
    )


def deployment(run, base, project, *, state=None, settings=None, uid=None):
    return [
        "--project",
        project,
        "--image",
        run.image_id,
        "--state-dir",
        state or base.STATE,
        "--secrets-dir",
        base.SECRETS,
        "--settings-file",
        settings or base.SETTINGS,
        "--publish-address",
        "127.0.0.1",
        "--publish-port",
        "18443",
        "--uid",
        str(UID if uid is None else uid),
        "--gid",
        str(GID),
    ]


def snapshot(run, base, label):
    return run.control_exec(
        label,
        "stat",
        "-c",
        STAT,
        base.ROOT,
        base.STATE,
        base.STATE + "/data",
        base.SECRETS,
        base.SECRETS + "/activation-signing-key.pem",
        base.SETTINGS,
    )


def empty_project(run, label, project):
    found = run.inner(
        label,
        "ps",
        "-aq",
        "--no-trunc",
        "--filter",
        "label=ai.nemori.omne.project=" + project,
    )
    run.inner(
        label + "-name",
        "container",
        "inspect",
        "omne-" + project + "-center",
        expected=None,
    )
    return found


def assert_no_service(run, label, project):
    found = empty_project(run, label, project)
    name_check = run.evidence["commands"][-1]
    need(
        found == b"" and name_check["returncode"] != 0,
        label + " product center unexpectedly exists",
    )


def helper_action(run, base, label, action, args, *, override=False):
    if override:
        return run.outer(
            label,
            "exec",
            "-e",
            "DOCKER_HOST=" + base.SOCKET,
            "-e",
            "COMPOSE_FILE=qa-disallowed",
            run.control,
            base.HELPER,
            action,
            *args,
            expected=None,
            timeout=300,
        )
    return run.helper(label, action, *args, expected=None, timeout=300)


def case_paths(base, project):
    return {
        "data": base.STATE + "/data",
        "secret": base.SECRETS + "/activation-signing-key.pem",
        "state_link": base.ROOT + "/qa-state-link-" + project,
        "ancestor_link": base.ROOT + "/qa-ancestor-link-" + project,
        "marker": base.ROOT + "/.omne-isolated",
        "settings_missing": base.ROOT + "/qa-settings-missing-" + project + ".env",
        "settings_unknown_storage": base.ROOT
        + "/qa-settings-unknown-"
        + project
        + ".env",
    }


def require_absent(run, label, path):
    run.control_exec(label, "sh", "-c", '[ ! -e "$1" ] && [ ! -L "$1" ]', "sh", path)


def mutate(run, base, case, project, paths):
    state = base.STATE
    settings = base.SETTINGS
    uid = UID
    override = False
    if case == "uid0":
        uid = 0
    elif case == "data_mode":
        run.control_exec(case + "-mutate", "chmod", "0755", paths["data"])
    elif case == "data_owner":
        run.control_exec(case + "-mutate", "chown", "0:0", paths["data"])
    elif case == "secret_mode":
        run.control_exec(case + "-mutate", "chmod", "0644", paths["secret"])
    elif case == "state_link":
        require_absent(run, case + "-pre-absent", paths["state_link"])
        run.control_exec(case + "-mutate", "ln", "-s", base.STATE, paths["state_link"])
        state = paths["state_link"]
    elif case == "ancestor_link":
        require_absent(run, case + "-pre-absent", paths["ancestor_link"])
        run.control_exec(
            case + "-mutate", "ln", "-s", base.ROOT, paths["ancestor_link"]
        )
        state = paths["ancestor_link"] + "/state"
    elif case == "ancestor_marker":
        require_absent(run, case + "-pre-absent", paths["marker"])
        run.control_exec(case + "-mutate", "mkdir", "-m", "0700", paths["marker"])
    elif case == "settings_missing":
        settings = paths[case]
        require_absent(run, case + "-pre-absent", settings)
        run.control_exec(
            case + "-mutate",
            "sh",
            "-c",
            'umask 077; sed "/^OMNE_TENANCY_UNACTIVATED_RETENTION=/d" "$1" > "$2"; chmod 600 "$2"',
            "sh",
            base.SETTINGS,
            settings,
        )
    elif case == "settings_unknown_storage":
        settings = paths[case]
        require_absent(run, case + "-pre-absent", settings)
        run.control_exec(
            case + "-mutate",
            "sh",
            "-c",
            'umask 077; cat "$1" > "$2"; printf "%s\\n" "OMNE_TENANCY_STORAGE_FILE=/state/qa-unknown.sqlite" >> "$2"; chmod 600 "$2"',
            "sh",
            base.SETTINGS,
            settings,
        )
    elif case == "compose_file_override":
        override = True
    else:
        raise RuntimeError("unknown case")
    return (
        deployment(run, base, project, state=state, settings=settings, uid=uid),
        override,
    )


def mutation_observation(run, base, case, paths):
    if case in ("state_link", "ancestor_link"):
        path = paths[case]
        run.control_exec(case + "-bad-stat", "stat", "-c", STAT, path)
        run.control_exec(case + "-bad-readlink", "readlink", path)
    elif case == "ancestor_marker":
        run.control_exec(case + "-bad-stat", "stat", "-c", STAT, paths["marker"])
    elif case.startswith("settings_"):
        path = paths[case]
        run.control_exec(case + "-bad-stat", "stat", "-c", STAT, path)
        run.control_exec(case + "-bad-names", "sed", "-n", "s/=.*//p", path)
    else:
        path = paths["data"] if case in ("data_mode", "data_owner") else paths["secret"]
        run.control_exec(case + "-bad-stat", "stat", "-c", STAT, path)


def restore(run, base, case, paths):
    if case == "data_mode":
        run.control_exec(case + "-restore", "chmod", "0700", paths["data"])
    elif case == "data_owner":
        run.control_exec(case + "-restore", "chown", f"{UID}:{GID}", paths["data"])
    elif case == "secret_mode":
        run.control_exec(case + "-restore", "chmod", "0600", paths["secret"])
    elif case in ("state_link", "ancestor_link"):
        run.control_exec(case + "-restore", "rm", paths[case])
        require_absent(run, case + "-after-absent", paths[case])
    elif case == "ancestor_marker":
        run.control_exec(case + "-restore", "rmdir", paths["marker"])
        require_absent(run, case + "-after-absent", paths["marker"])
    elif case.startswith("settings_"):
        run.control_exec(case + "-restore", "rm", paths[case])
        require_absent(run, case + "-after-absent", paths[case])


def case_run(run, base, case, reason):
    project = run.project + "n" + str([name for name, _ in CASES].index(case))
    paths = case_paths(base, run.project)
    run.evidence.setdefault("case_projects", []).append(project)
    run.evidence.setdefault("cases", []).append(
        {"case": case, "reason": reason, "project": project}
    )
    run.save()
    snapshot(run, base, case + "-before-stat")
    assert_no_service(run, case + "-before-project", project)
    args = None
    override = False
    try:
        args, override = mutate(run, base, case, project, paths)
        snapshot(run, base, case + "-bad-baseline-stat")
        mutation_observation(run, base, case, paths)
        helper_action(
            run, base, case + "-validate", "validate", args, override=override
        )
        helper_action(run, base, case + "-start", "start", args, override=override)
        assert_no_service(run, case + "-after-project", project)
    finally:
        can_restore = False
        try:
            assert_no_service(run, case + "-before-restore-project", project)
            can_restore = True
        except Exception as error:
            run.evidence.setdefault("uncertain_case_cleanup", {})[case] = str(error)
            run.save()
        if can_restore:
            restore(run, base, case, paths)
            snapshot(run, base, case + "-restored-stat")
            baseline = deployment(run, base, run.project)
            run.helper(case + "-baseline-validate", "validate", *baseline)
            assert_no_service(run, case + "-restored-project", project)
    for action in ("validate", "start"):
        item = next(
            x for x in run.evidence["commands"] if x["label"] == case + "-" + action
        )
        need(
            item["returncode"] == 1 and not item["observation_expired"],
            case + " " + action + " did not reject",
        )
        err = (run.run / item["stderr"]).read_bytes()
        out = (run.run / item["stdout"]).read_bytes()
        need(
            out == b"" and err == ("omne-center: " + reason + "\n").encode(),
            case + " " + action + " wrong reason",
        )
    need(
        (run.run / "raw" / (case + "-after-project.stdout")).read_bytes() == b"",
        case + " created a service",
    )


def component_args(run, base, mode, project):
    return [
        base.HELPER,
        mode,
        project,
        run.image_id,
        base.STATE,
        base.SECRETS,
        base.SETTINGS,
        "127.0.0.1",
        "18443",
        str(UID),
        str(GID),
        "/usr/local/libexec/qa-extra-mount.yaml",
        base.ROOT + "/qa-extra-" + run.project,
    ]


def probe_actual(run, base, label, inspect_label):
    source = run.run / "raw" / (inspect_label + ".stdout")
    source_sha256 = sha(source)
    run.outer(
        label,
        "exec",
        "-i",
        "-e",
        "DOCKER_HOST=" + base.SOCKET,
        run.control,
        "bash",
        "/usr/local/libexec/qa-component-probe.sh",
        base.HELPER,
        run.image_id,
        base.STATE,
        base.SECRETS,
        "127.0.0.1",
        "18443",
        str(UID),
        str(GID),
        stdin=source,
        expected=0 if inspect_label == "component-normal-inspect" else None,
    )
    need(sha(source) == source_sha256, label + " inspect input changed while probing")
    command = run.evidence["commands"][-1]
    need(command["label"] == label, label + " probe record identity")
    command["stdin_source"] = "raw/" + inspect_label + ".stdout"
    command["stdin_sha256"] = source_sha256
    run.save()


def component(run, base):
    project = run.project + "component"
    run.evidence["component_project"] = project
    run.save()
    extra = base.ROOT + "/qa-extra-" + run.project
    run.control_exec("component-extra-dir", "install", "-d", "-m", "0700", extra)
    run.control_exec("component-extra-stat", "stat", "-c", STAT, extra)
    run.control_exec(
        "component-normal-create",
        "bash",
        "/usr/local/libexec/qa-component-create.sh",
        *component_args(run, base, "normal", project),
        timeout=180,
    )
    normal_ids = (
        empty_project(run, "component-normal-ids", project).decode().splitlines()
    )
    need(
        len(normal_ids) == 1 and re.fullmatch(r"[0-9a-f]{64}", normal_ids[0]),
        "normal created CID not unique",
    )
    normal = normal_ids[0]
    run.inner("component-normal-inspect", "inspect", normal)
    probe_actual(run, base, "component-normal-probe", "component-normal-inspect")
    run.inner("component-normal-remove", "rm", normal)
    empty_project(run, "component-between-ids", project)
    run.control_exec(
        "component-extra-create",
        "bash",
        "/usr/local/libexec/qa-component-create.sh",
        *component_args(run, base, "extra", project),
        timeout=180,
    )
    bad_ids = empty_project(run, "component-extra-ids", project).decode().splitlines()
    need(
        len(bad_ids) == 1
        and re.fullmatch(r"[0-9a-f]{64}", bad_ids[0])
        and bad_ids[0] != normal,
        "extra created CID not unique",
    )
    bad = bad_ids[0]
    run.inner("component-extra-inspect", "inspect", bad)
    probe_actual(run, base, "component-extra-probe", "component-extra-inspect")
    run.evidence["component_cids"] = {"normal": normal, "extra": bad}
    run.save()


def cleanup_project(run, project, index):
    errors = []
    try:
        if ("container", run.control) not in run.created or (
            "container",
            run.dind,
        ) not in run.created:
            return errors
        for kind, command in (
            ("container", ("ps", "-aq", "--no-trunc")),
            ("network", ("network", "ls", "-q")),
        ):
            filter_key = (
                "ai.nemori.omne.project"
                if kind == "container"
                else "com.docker.compose.project"
            )
            found = (
                run.inner(
                    f"cleanup-project-{index}-{kind}-list",
                    *command,
                    "--filter",
                    "label=" + filter_key + "=" + project,
                    cleanup=True,
                )
                .decode()
                .splitlines()
            )
            for n, resource in enumerate(found):
                inspect_args = (
                    ("inspect", resource)
                    if kind == "container"
                    else ("network", "inspect", resource)
                )
                inspected = json.loads(
                    run.inner(
                        f"cleanup-project-{index}-{kind}-inspect-{n}",
                        *inspect_args,
                        cleanup=True,
                    )
                )[0]
                labels = (
                    inspected["Config"]["Labels"]
                    if kind == "container"
                    else inspected["Labels"]
                )
                need(labels.get(filter_key) == project, "cleanup project identity")
                args = (
                    ("rm", "-f", resource)
                    if kind == "container"
                    else ("network", "rm", resource)
                )
                run.inner(
                    f"cleanup-project-{index}-{kind}-remove-{n}", *args, cleanup=True
                )
            remaining = run.inner(
                f"cleanup-project-{index}-{kind}-final",
                *command,
                "--filter",
                "label=" + filter_key + "=" + project,
                cleanup=True,
            )
            need(remaining == b"", "project resource remains")
    except Exception as error:
        errors.append(str(error))
    return errors


def execute(gate):
    inputs = input_set()
    approved = json.loads(gate.read_text())
    need(
        approved
        == {
            "approved": True,
            "reviewer": "root",
            "inputs_sha256": hashlib.sha256(canonical(inputs)).hexdigest(),
            "driver_sha256": inputs["sha256"]["driver"],
            "oracle_sha256": inputs["sha256"]["oracle"],
        },
        "root gate missing or stale",
    )
    base = load_checked("install_base", BASE, BASE_SHA)
    cross = load_checked("install_cross", CROSS, CROSS_SHA)
    base.HERE = HERE
    run = base.Run(args_for_run(inputs, gate), inputs)
    for name, key in (
        ("driver.py", "driver"),
        ("manifest-delivery.json", "manifest"),
        ("v0-driver.py", "v0_driver"),
        ("cross-driver.py", "cross_driver"),
        ("qa-component-create.sh", "component_create"),
        ("qa-component-probe.sh", "component_probe"),
        ("qa-extra-mount.yaml", "extra_mount"),
    ):
        source = pathlib.Path(inputs["paths"][key])
        target = run.frozen / name
        shutil.copyfile(source, target)
        need(sha(target) == inputs["sha256"][key], "frozen input changed " + name)
    run.evidence["fixture"] = "install-validation/1"
    run.save()
    try:
        cross.setup(run, base)
        cross.import_image(run, base, "arm64")
        run.prepare_paths()
        run.evidence["expected"]["uid"] = UID
        run.evidence["expected"]["gid"] = GID
        run.save()
        for file, target in (
            ("qa-component-create.sh", "/usr/local/libexec/qa-component-create.sh"),
            ("qa-component-probe.sh", "/usr/local/libexec/qa-component-probe.sh"),
            ("qa-extra-mount.yaml", "/usr/local/libexec/qa-extra-mount.yaml"),
        ):
            run.copy("copy-" + file, run.frozen / file, target)
        baseline = deployment(run, base, run.project)
        run.helper("initial-baseline-validate", "validate", *baseline)
        snapshot(run, base, "initial-baseline-stat")
        run.control_exec(
            "initial-settings-names", "sed", "-n", "s/=.*//p", base.SETTINGS
        )
        for case, reason in CASES:
            case_run(run, base, case, reason)
        component(run, base)
        run.evidence["install_complete"] = True
        run.evidence["status"] = "observed-awaiting-oracle"
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
    finally:
        projects = run.evidence.get("case_projects", []) + [
            run.evidence.get("component_project", "")
        ]
        cleanup_errors = []
        for index, project in enumerate(projects):
            if project:
                cleanup_errors.extend(cleanup_project(run, project, index))
        run.evidence["project_cleanup_errors"] = cleanup_errors
        run.evidence["project_cleanup_complete"] = not cleanup_errors
        run.cleanup()
        run.save()
    with (
        (run.run / "oracle.stdout").open("xb") as out,
        (run.run / "oracle.stderr").open("xb") as err,
    ):
        result = subprocess.run(
            [sys.executable, "-B", str(run.frozen / "oracle.py"), str(run.run)],
            stdout=out,
            stderr=err,
            check=False,
        )
    run.evidence["oracle_exit"] = result.returncode
    run.save()
    print(
        json.dumps(
            {
                "run": str(run.run),
                "oracle_exit": result.returncode,
                "cleanup_complete": run.evidence["cleanup_complete"],
            },
            sort_keys=True,
        )
    )
    return result.returncode


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    inputs = input_set()
    if args.print_inputs:
        print(
            json.dumps(
                {
                    "inputs": inputs,
                    "inputs_sha256": hashlib.sha256(canonical(inputs)).hexdigest(),
                },
                sort_keys=True,
            )
        )
        return 0
    need(
        args.execute and args.reviewed_gate is not None,
        "Docker requires --execute and an exact root-reviewed gate",
    )
    return execute(args.reviewed_gate)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"preflight refused: {error}", file=sys.stderr)
        raise SystemExit(2)
