#!/usr/bin/env bash
# Create only, never start. The extra branch constructs a deliberate topology fault.
set -euo pipefail
helper="$1"; mode="$2"; requested_project="$3"; requested_image="$4"
requested_state="$5"; requested_secrets="$6"; requested_settings="$7"
requested_address="$8"; requested_port="$9"; requested_uid="${10}"
requested_gid="${11}"; override="${12}"; extra_source="${13}"
source "$helper"
project="$requested_project"
image="$requested_image"
state_dir="$requested_state"
secrets_dir="$requested_secrets"
settings_file="$requested_settings"
publish_address="$requested_address"
publish_port="$requested_port"
app_uid="$requested_uid"
app_gid="$requested_gid"
validate_image
if [[ "$mode" == normal ]]; then
  validate_center_config
  compose_center create --no-build --pull never -y center
  exit
fi
[[ "$mode" == extra || "$mode" == extra-down ]] || fail qa-mode-invalid
common=(PATH="$PATH" HOME="${HOME:-/root}" DOCKER_HOST="$docker_host"
  OMNE_CENTER_IMAGE="$image" OMNE_CENTER_CONTAINER_NAME="omne-${project}-center"
  OMNE_CENTER_PROJECT="$project" OMNE_CENTER_UID="$app_uid" OMNE_CENTER_GID="$app_gid"
  OMNE_CENTER_STATE_DIR="$state_dir" OMNE_CENTER_SECRETS_DIR="$secrets_dir"
  OMNE_CENTER_SETTINGS_FILE="$settings_file" OMNE_CENTER_PUBLISH_ADDRESS="$publish_address"
  OMNE_CENTER_PUBLISH_PORT="$publish_port" OMNE_CENTER_VERSION="$image_version"
  OMNE_CENTER_BUILD_ID="$image_build_id" OMNE_CENTER_HEALTH_INTERVAL="$health_interval"
  OMNE_CENTER_HEALTH_TIMEOUT="$health_timeout"
  OMNE_CENTER_HEALTH_START_PERIOD="$health_start_period"
  OMNE_CENTER_HEALTH_RETRIES="$health_retries"
  OMNE_CENTER_LOG_MAX_SIZE="$log_max_size" OMNE_CENTER_LOG_MAX_FILE="$log_max_file"
  OMNE_CENTER_EXTRA_BIND_SOURCE="$extra_source")
if [[ "$mode" == extra ]]; then
  env -i "${common[@]}" docker compose --ansi never -f "$center_file" -f "$override" \
    -p "$project" config --format json >/dev/null
  env -i "${common[@]}" docker compose --ansi never -f "$center_file" -f "$override" \
    -p "$project" create --no-build --pull never -y center
else
  env -i "${common[@]}" docker compose --ansi never -f "$center_file" -f "$override" \
    -p "$project" down
fi
