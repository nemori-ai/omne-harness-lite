#!/usr/bin/env python3
"""Independent raw-output oracle for DK-I3 real helper installation negatives."""
import hashlib
import json
import pathlib
import re
import sys

CASES = (
    ("uid0", "invalid-uid"),
    ("data_mode", "private-directory-permission"),
    ("data_owner", "private-directory-permission"),
    ("secret_mode", "private-file-permission"),
    ("state_link", "invalid-state-path"),
    ("ancestor_link", "invalid-state-path"),
    ("ancestor_marker", "isolated-state-ancestor"),
    ("settings_missing", "settings-missing-OMNE_TENANCY_UNACTIVATED_RETENTION"),
    ("settings_unknown_storage", "settings-unknown-key"),
    ("compose_file_override", "compose-override-prohibited"),
)
BUILD = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
MANIFEST_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
HELPER_SHA = "71ba9f3c31b34c171dd2a4048d9e249af31f7948abcf66ee603da5ffb7d1b365"
STAT_PATHS = (
    "/var/lib/omne-tenancy",
    "/var/lib/omne-tenancy/state",
    "/var/lib/omne-tenancy/state/data",
    "/var/lib/omne-tenancy/secrets",
    "/var/lib/omne-tenancy/secrets/activation-signing-key.pem",
    "/var/lib/omne-tenancy/settings.env",
)


def need(test, reason):
    if not test:
        raise AssertionError(reason)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def commands_of(evidence):
    commands = evidence["commands"]
    labels = [c["label"] for c in commands]
    need(len(labels) == len(set(labels)), "duplicate command label")
    return {c["label"]: c for c in commands}


def raw(run, commands, label, stream="stdout", expected_rc=0):
    need(label in commands, "missing command " + label)
    command = commands[label]
    need(
        command["returncode"] is not None and command["observation_expired"] is False,
        label + " unobserved command",
    )
    if expected_rc is not None:
        need(command["returncode"] == expected_rc, label + " wrong exit")
    relative = "raw/" + label + "." + stream
    need(command[stream] == relative, label + " wrong raw path")
    path = run / relative
    need(path.is_file(), label + " raw stream absent")
    return path.read_bytes()


def one_json(data, label):
    need(data.endswith(b"\n") and data.count(b"\n") == 1, label + " not one JSON+LF")
    return json.loads(data[:-1].decode("utf-8", "strict"))


def parse_stat(data, paths):
    lines = data.decode("utf-8", "strict").splitlines()
    need(len(lines) == len(paths), "stat path count")
    result = {}
    for line, expected in zip(lines, paths):
        parts = line.split("|")
        need(len(parts) == 8 and parts[0] == expected, "stat path identity")
        kind, uid, gid, mode, device, inode, size = parts[1:]
        need(
            all(part.isdigit() for part in (uid, gid, mode, device, inode, size))
            and int(device) > 0
            and int(inode) > 0,
            "stat metadata shape",
        )
        result[expected] = {
            "kind": kind,
            "uid": uid,
            "gid": gid,
            "mode": mode,
            "device": device,
            "inode": inode,
            "size": size,
        }
    return result


def stable(before, after):
    need(before.keys() == after.keys(), "stat set changed")
    for path in before:
        for field in ("kind", "uid", "gid", "mode", "device", "inode"):
            need(
                before[path][field] == after[path][field],
                path + " baseline not restored: " + field,
            )
        if before[path]["kind"] == "regular file":
            need(
                before[path]["size"] == after[path]["size"], path + " file size changed"
            )


def correct_baseline(stat):
    state = stat[STAT_PATHS[1]]
    data = stat[STAT_PATHS[2]]
    secrets = stat[STAT_PATHS[3]]
    key = stat[STAT_PATHS[4]]
    settings = stat[STAT_PATHS[5]]
    for item in (state, data, secrets):
        need(
            item["kind"] == "directory"
            and (item["uid"], item["gid"], item["mode"]) == ("12017", "12019", "700"),
            "private baseline directory",
        )
    need(
        key["kind"] == "regular file"
        and (key["uid"], key["gid"], key["mode"]) == ("12017", "12019", "600"),
        "private baseline key stat",
    )
    need(
        settings["kind"] == "regular file"
        and settings["uid"] == "0"
        and settings["mode"] == "600",
        "settings baseline stat",
    )


def project_absent(run, commands, label):
    need(raw(run, commands, label) == b"", label + " service exists by project")
    name = commands[label + "-name"]
    need(
        name["returncode"] != 0 and name["observation_expired"] is False,
        label + " exact service name exists",
    )
    raw(run, commands, label + "-name", "stdout", expected_rc=None)
    raw(run, commands, label + "-name", "stderr", expected_rc=None)


def helper_args(command, action, project, case, base_project, image_id):
    argv = command["argv"]
    positions = [
        i for i, value in enumerate(argv) if value == "/usr/local/libexec/omne-center"
    ]
    need(
        len(positions) == 1
        and argv[positions[0] + 1] == action
        and "--project" in argv
        and argv[argv.index("--project") + 1] == project,
        case + " installed helper command identity",
    )
    if case == "compose_file_override":
        need("COMPOSE_FILE=qa-disallowed" in argv, "override environment missing")
    else:
        need(
            "COMPOSE_FILE=qa-disallowed" not in argv, "unexpected override environment"
        )
    expected_uid = "0" if case == "uid0" else "12017"
    need(
        argv[argv.index("--uid") + 1] == expected_uid
        and argv[argv.index("--gid") + 1] == "12019",
        case + " UID/GID argv",
    )
    state = "/var/lib/omne-tenancy/state"
    settings = "/var/lib/omne-tenancy/settings.env"
    if case == "state_link":
        state = "/var/lib/omne-tenancy/qa-state-link-" + base_project
    elif case == "ancestor_link":
        state = "/var/lib/omne-tenancy/qa-ancestor-link-" + base_project + "/state"
    elif case == "settings_missing":
        settings = "/var/lib/omne-tenancy/qa-settings-missing-" + base_project + ".env"
    elif case == "settings_unknown_storage":
        settings = "/var/lib/omne-tenancy/qa-settings-unknown-" + base_project + ".env"
    need(
        argv[argv.index("--state-dir") + 1] == state
        and argv[argv.index("--settings-file") + 1] == settings
        and argv[argv.index("--image") + 1] == image_id
        and argv[argv.index("--secrets-dir") + 1] == "/var/lib/omne-tenancy/secrets"
        and argv[argv.index("--publish-address") + 1] == "127.0.0.1"
        and argv[argv.index("--publish-port") + 1] == "18443",
        case + " fixture path argv",
    )


def check_mutation(run, commands, case, baseline, bad, project):
    root, state, data, secrets, key, settings = STAT_PATHS
    if case == "data_mode":
        need(
            bad[data]["mode"] == "755"
            and bad[data]["uid"] == "12017"
            and bad[data]["inode"] == baseline[data]["inode"],
            "data mode mutation",
        )
    elif case == "data_owner":
        need(
            (bad[data]["uid"], bad[data]["gid"], bad[data]["mode"]) == ("0", "0", "700")
            and bad[data]["inode"] == baseline[data]["inode"],
            "data owner mutation",
        )
    elif case == "secret_mode":
        need(
            bad[key]["mode"] == "644"
            and bad[key]["uid"] == "12017"
            and bad[key]["inode"] == baseline[key]["inode"],
            "secret mode mutation",
        )
    else:
        stable(baseline, bad)
    if case in (
        "uid0",
        "data_mode",
        "data_owner",
        "secret_mode",
        "compose_file_override",
    ):
        observed_path = data if case in ("data_mode", "data_owner") else key
        single = parse_stat(raw(run, commands, case + "-bad-stat"), (observed_path,))[
            observed_path
        ]
        need(single == bad[observed_path], case + " independent bad stat differs")
    path = {
        "state_link": root + "/qa-state-link-" + project,
        "ancestor_link": root + "/qa-ancestor-link-" + project,
        "ancestor_marker": root + "/.omne-isolated",
        "settings_missing": root + "/qa-settings-missing-" + project + ".env",
        "settings_unknown_storage": root + "/qa-settings-unknown-" + project + ".env",
    }.get(case)
    if path:
        raw(run, commands, case + "-pre-absent")
        observed = parse_stat(raw(run, commands, case + "-bad-stat"), (path,))[path]
        if case.endswith("_link"):
            need(observed["kind"] == "symbolic link", case + " actual link type")
            target = state if case == "state_link" else root
            need(
                raw(run, commands, case + "-bad-readlink") == (target + "\n").encode(),
                case + " actual link target",
            )
        elif case == "ancestor_marker":
            need(
                observed["kind"] == "directory" and observed["mode"] == "700",
                "arbitrary-type ancestor marker missing",
            )
        else:
            need(
                observed["kind"] == "regular file"
                and observed["uid"] == "0"
                and observed["mode"] == "600",
                case + " settings file",
            )
            names = raw(run, commands, case + "-bad-names").decode().splitlines()
            normal = raw(run, commands, "initial-settings-names").decode().splitlines()
            expected = (
                [n for n in normal if n != "OMNE_TENANCY_UNACTIVATED_RETENTION"]
                if case == "settings_missing"
                else normal + ["OMNE_TENANCY_STORAGE_FILE"]
            )
            need(
                names == expected and len(names) == len(set(names)),
                case + " non-secret setting names",
            )
        raw(run, commands, case + "-after-absent")


def check_cases(run, commands, evidence):
    need(
        evidence["cases"]
        == [
            {
                "case": case,
                "reason": reason,
                "project": evidence["expected"]["project"] + "n" + str(i),
            }
            for i, (case, reason) in enumerate(CASES)
        ],
        "closed case ledger",
    )
    initial = parse_stat(raw(run, commands, "initial-baseline-stat"), STAT_PATHS)
    correct_baseline(initial)
    need(
        one_json(raw(run, commands, "initial-baseline-validate"), "initial validate")
        == {"state": "deployment-structure-valid"},
        "initial real validate failed",
    )
    normal_names = raw(run, commands, "initial-settings-names").decode().splitlines()
    need(
        set(normal_names)
        == {
            "OMNE_TENANCY_UNACTIVATED_RETENTION",
            "OMNE_TENANCY_INVITATION_TTL_DEFAULT",
            "OMNE_TENANCY_AFFILIATION_REQUEST_TTL_DEFAULT",
            "OMNE_TENANCY_COPY_NOTICE_TTL_DEFAULT",
            "OMNE_TENANCY_SHARING_INVITATION_TTL_DEFAULT",
            "OMNE_TENANCY_TEAM_CREATION_KEY_RETENTION",
            "OMNE_TENANCY_CLOCK_READY_TIMEOUT",
        },
        "baseline setting name set",
    )
    for i, (case, reason) in enumerate(CASES):
        project = evidence["expected"]["project"] + "n" + str(i)
        before = parse_stat(raw(run, commands, case + "-before-stat"), STAT_PATHS)
        bad = parse_stat(raw(run, commands, case + "-bad-baseline-stat"), STAT_PATHS)
        restored = parse_stat(raw(run, commands, case + "-restored-stat"), STAT_PATHS)
        stable(initial, before)
        stable(before, restored)
        correct_baseline(restored)
        check_mutation(
            run, commands, case, before, bad, evidence["expected"]["project"]
        )
        for phase in ("before", "after", "before-restore", "restored"):
            project_absent(run, commands, case + "-" + phase + "-project")
        for action in ("validate", "start"):
            label = case + "-" + action
            helper_args(
                commands[label],
                action,
                project,
                case,
                evidence["expected"]["project"],
                evidence["expected"]["inner_image_id"],
            )
            need(
                raw(run, commands, label, expected_rc=1) == b""
                and raw(run, commands, label, "stderr", expected_rc=1)
                == ("omne-center: " + reason + "\n").encode(),
                case + " " + action + " exact refusal",
            )
        need(
            one_json(
                raw(run, commands, case + "-baseline-validate"),
                case + " restored validate",
            )
            == {"state": "deployment-structure-valid"},
            case + " correct baseline not recovered",
        )


def check_image(run, commands, evidence):
    expected = evidence["expected"]
    need(
        expected["build_id"] == BUILD
        and evidence["inputs"]["sha256"]["manifest"] == MANIFEST_SHA
        and evidence["inputs"]["sha256"]["helper"] == HELPER_SHA
        and expected["uid"] == 12017
        and expected["gid"] == 12019,
        "artifact/build/custom UID identity",
    )
    inner = json.loads(raw(run, commands, "inner-image-inspect"))[0]
    outer = json.loads(raw(run, commands, "outer-product-image"))[0]
    need(
        inner["Id"] == expected["inner_image_id"]
        and outer["Id"] == expected["image_id"]
        and inner["RootFS"]["Layers"] == outer["RootFS"]["Layers"]
        and inner["Os"] == outer["Os"] == "linux"
        and inner["Architecture"] == outer["Architecture"] == "arm64",
        "final actual image",
    )
    frozen = run / "inputs/omne-center"
    need(digest(frozen) == HELPER_SHA, "installed source helper not final")
    for path, key in (
        ("qa-component-create.sh", "component_create"),
        ("qa-component-probe.sh", "component_probe"),
        ("qa-extra-mount.yaml", "extra_mount"),
    ):
        need(
            digest(run / "inputs" / path) == evidence["inputs"]["sha256"][key],
            "component fixture changed",
        )


def check_component(run, commands, evidence):
    project = evidence["expected"]["project"] + "component"
    need(evidence["component_project"] == project, "component project")
    normal_ids = raw(run, commands, "component-normal-ids").decode().splitlines()
    bad_ids = raw(run, commands, "component-extra-ids").decode().splitlines()
    need(
        len(normal_ids) == len(bad_ids) == 1
        and re.fullmatch(r"[0-9a-f]{64}", normal_ids[0])
        and re.fullmatch(r"[0-9a-f]{64}", bad_ids[0])
        and normal_ids[0] != bad_ids[0],
        "two actual created containers",
    )
    normal = json.loads(raw(run, commands, "component-normal-inspect"))[0]
    bad = json.loads(raw(run, commands, "component-extra-inspect"))[0]
    expected = evidence["expected"]
    state = expected["state"]
    secrets = str(pathlib.PurePosixPath(state).parent / "secrets")
    extra = str(
        pathlib.PurePosixPath(state).parent / ("qa-extra-" + expected["project"])
    )
    for cid, item in ((normal_ids[0], normal), (bad_ids[0], bad)):
        need(
            item["Id"] == cid
            and item["Image"] == expected["inner_image_id"]
            and item["Config"]["User"] == "12017:12019"
            and item["Config"]["Labels"]["ai.nemori.omne.project"] == project
            and item["State"]["Status"] == "created"
            and item["State"]["Running"] is False
            and item["HostConfig"]["RestartPolicy"]["Name"] == "unless-stopped"
            and item["Config"]["StopTimeout"] == -1
            and item["Config"]["StopSignal"] == "SIGTERM"
            and item["Config"]["Healthcheck"]["Test"]
            == ["CMD", "node", "/opt/omne/app/deploy/docker/health.mjs"]
            and item["HostConfig"]["PortBindings"]["8443/tcp"][0]
            == {"HostIp": "127.0.0.1", "HostPort": "18443"},
            "actual create config/never start",
        )
    normal_mounts = {m["Destination"]: m for m in normal["Mounts"]}
    bad_mounts = {m["Destination"]: m for m in bad["Mounts"]}
    need(
        len(normal_mounts) == len(normal["Mounts"]) == 2
        and set(normal_mounts) == {"/state", "/secrets"}
        and len(bad_mounts) == len(bad["Mounts"]) == 3
        and set(bad_mounts) == {"/state", "/secrets", "/qa-extra"},
        "actual mount count/topology",
    )
    for mounts in (normal_mounts, bad_mounts):
        need(
            mounts["/state"]["Type"] == "bind"
            and mounts["/state"]["Source"] == state
            and mounts["/state"]["RW"] is True
            and mounts["/secrets"]["Type"] == "bind"
            and mounts["/secrets"]["Source"] == secrets
            and mounts["/secrets"]["RW"] is False,
            "full state/private secrets mapping",
        )
    need(
        normal_mounts["/state"] == bad_mounts["/state"]
        and normal_mounts["/secrets"] == bad_mounts["/secrets"],
        "original complete bind records changed",
    )
    need(
        bad_mounts["/qa-extra"]["Type"] == "bind"
        and bad_mounts["/qa-extra"]["Source"] == extra
        and bad_mounts["/qa-extra"]["RW"] is True,
        "only extra bind fault not observed",
    )
    for key in ("Image", "Path", "Args"):
        need(normal[key] == bad[key], "component config differs beyond bind: " + key)
    for key in (
        "User",
        "Entrypoint",
        "Cmd",
        "Env",
        "StopTimeout",
        "StopSignal",
        "Healthcheck",
    ):
        need(
            normal["Config"][key] == bad["Config"][key],
            "component config differs beyond bind: " + key,
        )
    for key in (
        "RestartPolicy",
        "Tmpfs",
        "PortBindings",
        "Privileged",
        "PidMode",
        "CapAdd",
        "Devices",
        "DeviceRequests",
    ):
        need(
            normal["HostConfig"].get(key) == bad["HostConfig"].get(key),
            "component host config differs beyond bind: " + key,
        )
    control = expected["control"]
    socket = "unix:///opt/omne-private-docker/docker.sock"
    for kind, cid in (("normal", normal_ids[0]), ("extra", bad_ids[0])):
        inspect_label = "component-" + kind + "-inspect"
        probe_label = "component-" + kind + "-probe"
        need(
            commands[inspect_label]["argv"]
            == ["docker", "exec", control, "docker", "--host", socket, "inspect", cid],
            kind + " actual inspect argv",
        )
        need(
            commands[probe_label]["argv"]
            == [
                "docker",
                "exec",
                "-i",
                "-e",
                "DOCKER_HOST=" + socket,
                control,
                "bash",
                "/usr/local/libexec/qa-component-probe.sh",
                "/usr/local/libexec/omne-center",
                expected["inner_image_id"],
                state,
                secrets,
                "127.0.0.1",
                "18443",
                "12017",
                "12019",
            ]
            and commands[probe_label]["stdin_source"]
            == "raw/" + inspect_label + ".stdout"
            and commands[probe_label]["stdin_sha256"]
            == digest(run / commands[probe_label]["stdin_source"]),
            kind + " original wrapper/inspect stdin identity",
        )
    need(
        raw(run, commands, "component-normal-probe") == b"actual-container-valid\n"
        and raw(run, commands, "component-normal-probe", "stderr") == b""
        and raw(run, commands, "component-extra-probe", expected_rc=1) == b""
        and raw(run, commands, "component-extra-probe", "stderr", expected_rc=1)
        == b"omne-center: actual-container-unsafe\n",
        "original validate_actual_center did not discriminate actual inspect",
    )
    need(
        raw(run, commands, "component-between-ids") == b""
        and commands["component-between-ids-name"]["returncode"] != 0,
        "normal created container not removed before extra",
    )
    raw(run, commands, "component-normal-remove")
    raw(run, commands, "component-extra-stat")


def check_cleanup(run, commands, evidence):
    need(
        evidence["cleanup_complete"] is True
        and evidence["cleanup_errors"] == []
        and evidence["project_cleanup_complete"] is True
        and evidence["project_cleanup_errors"] == [],
        "cleanup incomplete",
    )
    cleanup = {item["label"]: item for item in evidence["cleanup_commands"]}
    for i in range(len(CASES) + 1):
        for kind in ("container", "network"):
            label = f"cleanup-project-{i}-{kind}-final"
            need(
                label in cleanup
                and cleanup[label]["returncode"] == 0
                and (run / cleanup[label]["stdout"]).read_bytes() == b"",
                label + " project resource remains",
            )
    for kind in ("container", "network", "volume"):
        label = "cleanup-final-list-" + kind
        need(
            label in cleanup
            and cleanup[label]["returncode"] == 0
            and (run / cleanup[label]["stdout"]).read_bytes() == b"",
            label + " outer resource remains",
        )
    for label in (
        "cleanup-inner-project-final-list",
        "cleanup-inner-fixture-final-list",
        "cleanup-inner-all-final-list",
    ):
        need(
            label in cleanup
            and cleanup[label]["returncode"] == 0
            and (run / cleanup[label]["stdout"]).read_bytes() == b"",
            label + " private engine residual",
        )


def check(run):
    evidence = json.loads((run / "evidence.json").read_text())
    need(
        evidence["status"] == "observed-awaiting-oracle"
        and evidence["install_complete"] is True
        and evidence["inputs"]["platform"] == "arm64"
        and evidence["fixture"] == "install-validation/1"
        and not evidence.get("uncertain_case_cleanup"),
        "driver did not finish",
    )
    commands = commands_of(evidence)
    check_image(run, commands, evidence)
    check_cases(run, commands, evidence)
    check_component(run, commands, evidence)
    check_cleanup(run, commands, evidence)
    for path in (run / "evidence.json", *(run / "raw").iterdir()):
        if path.is_file():
            data = path.read_bytes()
            need(
                b"-----BEGIN PRIVATE KEY-----" not in data
                and b"-----BEGIN RSA PRIVATE KEY-----" not in data,
                "private key material leaked in raw evidence",
            )
    return {
        "status": "PASS",
        "caseCount": len(CASES),
        "component": "actual created inspect, original helper function only",
        "buildId": BUILD,
        "uid": 12017,
        "gid": 12019,
        "commandCount": len(commands),
    }


def main():
    need(len(sys.argv) == 2, "usage: oracle.py RUN_DIRECTORY")
    print(json.dumps(check(pathlib.Path(sys.argv[1]).resolve()), sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"ORACLE FAIL: {type(error).__name__}: {error}", file=sys.stderr)
        raise SystemExit(1)
