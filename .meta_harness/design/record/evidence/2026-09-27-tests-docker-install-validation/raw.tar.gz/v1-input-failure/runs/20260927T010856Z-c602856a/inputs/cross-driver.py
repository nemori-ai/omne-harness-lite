#!/usr/bin/env python3
"""DK-I5 arm64 business/backup overlap. Execution requires an exact root review gate."""

import argparse
import hashlib
import importlib.util
import io
import json
import pathlib
import platform as host_platform
import re
import secrets
import shutil
import subprocess
import sys
import tarfile
import time
from datetime import datetime, timezone

HERE = pathlib.Path(__file__).resolve().parent
TREE = pathlib.Path(__file__).resolve().parents[2]
V4 = TREE / "tmp/docker-cross-os-v4/driver.py"
V4_SHA = "fd4e4c46803ca1afde9c56d3628726d57a140c31037b3f9c46240161cdb091d5"
I3 = pathlib.Path(
    "/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery/tmp/docker-delivery/i3-f8f286c9"
)
MANIFEST = I3 / "manifest-delivery.json"
MANIFEST_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
BASE_PATH = pathlib.Path(
    "/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-fixtures/tmp/docker-product-fixtures/r5-helper-prep/driver.py"
)
BASE_SHA = "a450179ed522b8ab2033f0aa368c5d4ad3fe43139353b9d14d24afb01915da26"
V0 = BASE_PATH.parent.parent / "v0c"
HELPER_DIR = TREE / "apps/tenancy-host/deploy/docker"
PORT = "18443"
QA_GATE_SHA = "3a41976d06cfcd1b14e68cef3d2dedf96fc248d9efba3d619550392218927fc8"
LINUX_QA_DIR = "/opt/omne-cross-os/private"
LINUX_CLI = LINUX_QA_DIR + "/app/dist/main.js"
QA_CREDENTIAL_POLICY = 'OMNE_TENANCY_CREDENTIAL_POLICY={"minLength":12}'
HEX32 = re.compile(r"[0-9a-f]{32}\Z")
IMAGE = re.compile(r"sha256:[0-9a-f]{64}\Z")


def need(test, message):
    if not test:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def load_base():
    need(sha(BASE_PATH) == BASE_SHA, "frozen V0 driver changed")
    spec = importlib.util.spec_from_file_location("frozen_v0_driver", BASE_PATH)
    need(spec is not None and spec.loader is not None, "V0 import unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.HERE = HERE  # Run evidence and frozen oracle belong to this spoke.
    return module


def input_set(platform):
    need(platform == "arm64", "DK-I5 gate is arm64 only")
    need(sha(V4) == V4_SHA, "accepted cross-OS driver changed")
    need(sha(HERE / "gate.mjs") == QA_GATE_SHA, "verified write gate changed")
    need(sha(MANIFEST) == MANIFEST_SHA, "I3 manifest changed")
    manifest = json.loads(MANIFEST.read_text())
    need(
        manifest["source"]["commit"] == "f8f286c95cb9458fe3173190edbeab6076339b08",
        "I3 source",
    )
    need(
        manifest["archives"]["host"]["buildId"]
        == "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616",
        "host BUILD_ID",
    )
    need(
        manifest["archives"]["cli"]["buildId"]
        == "f38e46f1f169aea8993640c8ccf0ffc42545f2d64adf21f96b6658b2c83bb9f1",
        "CLI BUILD_ID",
    )
    image = manifest["images"][platform]
    need(
        image["platform"] == "linux/" + platform and IMAGE.fullmatch(image["imageId"]),
        "image identity",
    )
    paths = {
        "helper": HELPER_DIR / "omne-center",
        "compose": HELPER_DIR / "compose.yaml",
        "maintenance_compose": HELPER_DIR / "compose.maintenance.yaml",
        "health": HELPER_DIR / "health.mjs",
        "service": HELPER_DIR / "omne-center-backup@.service",
        "timer": HELPER_DIR / "omne-center-backup@.timer",
        "image_tar": pathlib.Path(image["archive"]),
        "cli_tar": pathlib.Path(manifest["archives"]["cli"]["path"]),
        "compose_binary": V0 / "docker-compose-linux-aarch64",
        "docker_cli": V0 / "extracted-bin/docker",
        "manifest": MANIFEST,
        "v0_driver": BASE_PATH,
        "driver": HERE / "driver.py",
        "oracle": HERE / "oracle.py",
        "dockerfile": HERE / "Dockerfile",
        "gate": HERE / "gate.mjs",
        "inventory": HERE / "inventory.mjs",
        "v4_driver": V4,
        "host_file_manifest": pathlib.Path(
            manifest["archives"]["host"]["fullFileManifest"]
        ),
    }
    hashes = {key: sha(path) for key, path in paths.items()}
    for name, manifest_key in (
        ("helper", "omne-center"),
        ("compose", "compose.yaml"),
        ("maintenance_compose", "compose.maintenance.yaml"),
        ("health", "health.mjs"),
        ("service", "omne-center-backup@.service"),
        ("timer", "omne-center-backup@.timer"),
    ):
        need(
            hashes[name] == manifest["deployFiles"][manifest_key]["sourceSha256"],
            name + " SHA",
        )
    need(
        hashes["helper"]
        == "71ba9f3c31b34c171dd2a4048d9e249af31f7948abcf66ee603da5ffb7d1b365",
        "helper adopted SHA",
    )
    need(hashes["image_tar"] == image["archiveSha256"], "image tar SHA")
    need(hashes["v4_driver"] == V4_SHA, "accepted cross-OS source SHA")
    need(hashes["gate"] == QA_GATE_SHA, "verified gate SHA")
    need(
        hashes["host_file_manifest"]
        == manifest["archives"]["host"]["fullFileManifestSha256"],
        "full host file manifest SHA",
    )
    need(hashes["cli_tar"] == manifest["archives"]["cli"]["sha256"], "CLI tar SHA")
    need(
        hashes["compose_binary"]
        == "d26373b19e89160546d15407516cc59f453030d9bc5b43ba7faf16f7b4980137"
        and hashes["docker_cli"]
        == "544cf329807e30c9601652562a159b17179345146be0f8211bfe2ebd872eb880",
        "V0 control tools SHA",
    )
    need(
        hashes["v0_driver"] == BASE_SHA and hashes["manifest"] == MANIFEST_SHA,
        "fixture SHA",
    )
    need(
        sha(TREE / ".meta_harness/design/realization/apps/tenancy-host/docker.md")
        == "3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223",
        "R5 node SHA",
    )
    need(
        subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=TREE,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        == manifest["source"]["commit"],
        "worktree HEAD",
    )
    return {
        "paths": {key: str(path.resolve()) for key, path in paths.items()},
        "sha256": hashes,
        "platform": platform,
        "image_id": image["imageId"],
        "build_id": image["buildId"],
        "cli_build_id": manifest["archives"]["cli"]["buildId"],
        "source_commit": manifest["source"]["commit"],
        "uid": 10001,
        "gid": 10001,
        "qa_fixture": "business-backup-write-hold/1",
        "observe_seconds": 600,
        "timer_observe_seconds": 30,
    }


def args_for_base(inputs, gate):
    names = {
        "helper_dir": HELPER_DIR,
        "image_tar": pathlib.Path(inputs["paths"]["image_tar"]),
        "image_id": inputs["image_id"],
        "build_id": inputs["build_id"],
        "uid": 10001,
        "gid": 10001,
        "observe_seconds": 600,
        "timer_observe_seconds": 30,
        "reviewed_gate": gate,
    }
    return argparse.Namespace(**names)


class Journey:
    def __init__(self, run, base, inputs):
        self.run = run
        self.base = base
        self.inputs = inputs
        self.history = []
        self.private = run.run / "private"
        self.private.mkdir(mode=0o700)

    def parse(self, label, data):
        return self.base.parse_json_line(data, label)

    def cli(
        self,
        label,
        os_name,
        client,
        action,
        payload=None,
        credential=None,
        endpoint=None,
        ca=None,
        refresh=False,
        expected=None,
    ):
        if label == "mac-invite-bob":
            self.start_held_backup()
        result = self._cli_original(
            label,
            os_name,
            client,
            action,
            payload,
            credential,
            endpoint,
            ca,
            refresh,
            expected,
        )
        if label == "linux-inbox-bob":
            self.finish_held_backup()
        return result

    def start_held_backup(self):
        r = self.run
        cid = r.evidence["expected"]["first_center_container"]
        argv = [
            "docker",
            "exec",
            r.control,
            "docker",
            "--host",
            self.base.SOCKET,
            "exec",
            cid,
            "node",
            "/opt/omne/app/dist/cli.js",
            "ops",
            "--socket-dir",
            "/run/omne-tenancy",
            "backup",
        ]
        out = r.run / "raw/concurrent-backup.stdout"
        err = r.run / "raw/concurrent-backup.stderr"
        with out.open("xb") as stdout, err.open("xb") as stderr:
            process = subprocess.Popen(
                argv,
                stdout=stdout,
                stderr=stderr,
                stdin=subprocess.DEVNULL,
                close_fds=True,
            )
        r.backup_process = process
        r.evidence["async_backup"] = {
            "argv": argv,
            "pid": process.pid,
            "started_utc": datetime.now(timezone.utc).isoformat(),
            "stdout": "raw/concurrent-backup.stdout",
            "stderr": "raw/concurrent-backup.stderr",
            "returncode": None,
        }
        r.save()
        for attempt in range(1, 151):
            exists = r.control_exec(
                f"gate-held-poll-{attempt}",
                "test",
                "-f",
                self.base.STATE + "/qa/held",
                expected=None,
            )
            need(process.poll() is None, "backup exited before gate was held")
            if r.evidence["commands"][-1]["returncode"] == 0:
                break
            time.sleep(0.2)
        else:
            raise RuntimeError("write gate never held the online backup")
        held = self.parse(
            "gate-held",
            r.control_exec("gate-held", "cat", self.base.STATE + "/qa/held"),
        )
        need(
            held.get("stage") == "write"
            and held.get("pid") == 1
            and type(held.get("fd")) is int
            and held["fd"] >= 0
            and re.fullmatch(
                r"/state/backups/\.quarantine/export-[0-9a-f]{32}", held.get("path", "")
            ),
            "wrong write gate",
        )
        r.inner("gate-fd-link", "exec", cid, "readlink", f"/proc/1/fd/{held['fd']}")
        r.inner(
            "gate-fd-stat",
            "exec",
            cid,
            "stat",
            "-Lc",
            "%d:%i:%u:%g:%a",
            f"/proc/1/fd/{held['fd']}",
        )
        r.evidence["async_backup"]["held_observed_utc"] = datetime.now(
            timezone.utc
        ).isoformat()
        r.evidence["async_backup"]["held"] = held
        r.save()

    def finish_held_backup(self):
        r = self.run
        process = r.backup_process
        need(process.poll() is None, "backup ended before business read")
        r.evidence["async_backup"]["business_read_completed_utc"] = datetime.now(
            timezone.utc
        ).isoformat()
        r.save()
        release = self.base.STATE + "/qa/release"
        r.control_exec("gate-release", "sh", "-c", 'umask 077; : > "$1"', "sh", release)
        r.evidence["async_backup"]["released_utc"] = datetime.now(
            timezone.utc
        ).isoformat()
        r.save()
        try:
            code = process.wait(timeout=600)
        except subprocess.TimeoutExpired:
            raise RuntimeError("backup observation expired; result unknown")
        r.evidence["async_backup"]["returncode"] = code
        r.evidence["async_backup"]["finished_utc"] = datetime.now(
            timezone.utc
        ).isoformat()
        r.save()
        need(code == 0, "online backup did not complete")
        completed = self.parse(
            "concurrent-backup", (r.run / "raw/concurrent-backup.stdout").read_bytes()
        )
        need(completed.get("status") == "completed", "online backup was not completed")
        r.evidence["backup"] = completed
        r.save()
        status = self.parse(
            "concurrent-backup-status",
            r.helper(
                "concurrent-backup-status", "backup-status", "--project", r.project
            ),
        )
        need(status.get("status") == "observed", "backup-status did not observe")
        r.evidence["backup_status"] = status
        r.save()

    def deployment(self, project=None, port=PORT):
        return [
            "--project",
            project or self.run.project,
            "--image",
            self.run.image_id,
            "--state-dir",
            self.base.STATE,
            "--secrets-dir",
            self.base.SECRETS,
            "--settings-file",
            self.base.SETTINGS,
            "--publish-address",
            self.run.dind_ip,
            "--publish-port",
            str(port),
            "--uid",
            "10001",
            "--gid",
            "10001",
        ]

    def put_control(self, label, path, content):
        self.run.outer(
            label,
            "exec",
            "-i",
            self.run.control,
            "sh",
            "-c",
            'umask 077; cat > "$1"',
            "sh",
            path,
            stdin=content,
        )

    def input_file(self, os_name, label, content, secret=False):
        need(re.fullmatch(r"[a-z0-9-]+", label) is not None, "input label")
        if os_name == "mac":
            path = self.private / (label + (".secret" if secret else ".json"))
            path.write_bytes(content)
            path.chmod(0o600)
            return str(path)
        path = LINUX_QA_DIR + "/" + label + (".secret" if secret else ".json")
        self.put_control(
            "input-" + label + ("-secret" if secret else "-json"), path, content
        )
        return path

    def _cli_original(
        self,
        label,
        os_name,
        client,
        action,
        payload=None,
        credential=None,
        endpoint=None,
        ca=None,
        refresh=False,
        expected=None,
    ):
        command = {
            "configure": ["center", "configure"],
            "health": ["center", "health"],
            "register": ["register"],
            "login": ["login"],
            "logout": ["logout"],
            "current": ["tenant", "current"],
            "tenant-list": ["tenant", "list"],
            "create": ["organization", "create"],
            "invite": ["invitation", "invite-by-login"],
            "inbox": ["invitation", "inbox"],
            "accept": ["invitation", "accept"],
            "switch": ["tenant", "switch"],
            "membership": ["membership", "inspect"],
            "members": ["membership", "list"],
            "role": ["membership", "set-role"],
            "remove": ["membership", "remove"],
            "admin-inbox": ["affiliation", "inbox"],
        }[action]
        state = (
            str(self.private / ("state-" + client))
            if os_name == "mac"
            else LINUX_QA_DIR + "/state-" + client
        )
        argv = ["machine", *command, "--state-dir", state]
        if action == "configure":
            argv += ["--endpoint", endpoint, "--ca-file", ca]
        else:
            if action in ("register", "login"):
                identifier = payload.pop("loginIdentifier")
                argv += ["--login-identifier", identifier]
            if payload is not None:
                argv += [
                    "--payload-file",
                    self.input_file(os_name, label, canonical(payload)),
                ]
            if credential is not None:
                argv += [
                    "--credential-file",
                    self.input_file(os_name, label, credential, True),
                ]
            if refresh:
                argv += ["--refresh"]
        if os_name == "mac":
            actual = self.run.call(
                label,
                [self.run.mac_node, str(self.run.mac_cli), *argv],
                timeout=90,
                expected=expected,
            )
        else:
            actual = self.run.outer(
                label,
                "exec",
                "-e",
                "HOME=" + LINUX_QA_DIR,
                self.run.control,
                "node",
                LINUX_CLI,
                *argv,
                timeout=90,
                expected=expected,
            )
        report = self.parse(label, actual)
        need(
            report.get("format") == "governance-client/1",
            label + " malformed CLI report",
        )
        self.history.append(
            {"label": label, "os": os_name, "client": client, "action": action}
        )
        self.run.evidence["journey"] = self.history
        self.run.save()
        return report

    @staticmethod
    def result(report, label):
        need(
            report.get("remote", {}).get("status") == "success"
            and report.get("remote", {}).get("reply", {}).get("reply", {}).get("result")
            is not None,
            label + " did not return a remote result",
        )
        return report["remote"]["reply"]["reply"]["result"]

    def go(self):
        r = self.run
        deployment = self.deployment()
        r.helper("validate", "validate", *deployment)
        started = self.parse(
            "start", r.helper("start", "start", *deployment, timeout=600)
        )
        cid = started["containerId"]
        need(re.fullmatch(r"[0-9a-f]{64}", cid), "start container ID")
        r.evidence["expected"]["first_center_container"] = cid
        r.save()
        r.inner("center-inspect-before", "inspect", cid)
        r.inner("center-exe-before", "exec", cid, "readlink", "/proc/1/exe")
        r.inner("center-cmdline-before", "exec", cid, "cat", "/proc/1/cmdline")
        for attempt in range(1, 151):
            r.control_exec(
                f"gate-ready-poll-{attempt}",
                "test",
                "-f",
                self.base.STATE + "/qa/ready",
                expected=None,
            )
            if r.evidence["commands"][-1]["returncode"] == 0:
                break
            time.sleep(0.2)
        else:
            raise RuntimeError("QA gate was not installed in serve PID1")
        r.control_exec("gate-ready", "cat", self.base.STATE + "/qa/ready")
        mac_url = f"https://127.0.0.1:{r.mac_port}/"
        linux_url = f"https://{r.dind_ip}:{PORT}/"
        self.cli(
            "mac-configure-alice",
            "mac",
            "alice",
            "configure",
            endpoint=mac_url,
            ca=str(self.private / "ca.pem"),
        )
        self.cli(
            "linux-configure-bob",
            "linux",
            "bob",
            "configure",
            endpoint=linux_url,
            ca=LINUX_QA_DIR + "/ca.pem",
        )
        mac_health = self.cli("mac-health-before", "mac", "alice", "health")
        linux_health = self.cli("linux-health-before", "linux", "bob", "health")
        center_id = mac_health["remote"]["health"]["centerId"]
        need(
            HEX32.fullmatch(center_id)
            and linux_health["remote"]["health"]["centerId"] == center_id,
            "two clients must see one center",
        )
        name_a, name_b = "qa" + r.project + "a", "qa" + r.project + "b"
        password_a, password_b = (
            secrets.token_hex(18).encode(),
            secrets.token_hex(18).encode(),
        )
        bob_secret = self.private / "bob-credential.secret"
        bob_secret.write_bytes(password_b)
        bob_secret.chmod(0o600)
        self.cli(
            "mac-register-alice",
            "mac",
            "alice",
            "register",
            {"loginIdentifier": name_a},
            password_a,
        )
        self.cli(
            "linux-register-bob",
            "linux",
            "bob",
            "register",
            {"loginIdentifier": name_b},
            password_b,
        )
        self.cli(
            "mac-login-alice",
            "mac",
            "alice",
            "login",
            {"loginIdentifier": name_a},
            password_a,
        )
        self.cli(
            "linux-login-bob",
            "linux",
            "bob",
            "login",
            {"loginIdentifier": name_b},
            password_b,
        )
        personal_a = self.result(
            self.cli(
                "mac-current-personal", "mac", "alice", "current", {}, refresh=True
            ),
            "Alice current",
        )
        personal_b = self.result(
            self.cli(
                "linux-current-personal", "linux", "bob", "current", {}, refresh=True
            ),
            "Bob current",
        )
        team_a = self.result(
            self.cli(
                "mac-create-team-a",
                "mac",
                "alice",
                "create",
                {"creationKey": "backup-a-" + r.project},
            ),
            "team A",
        )
        team_b = self.result(
            self.cli(
                "linux-create-team-b",
                "linux",
                "bob",
                "create",
                {"creationKey": "backup-b-" + r.project},
            ),
            "team B",
        )
        tenant_a = {"organization": team_a, "account": personal_a["account"]}
        r.evidence["anchors"] = {
            "center_id": center_id,
            "alice": personal_a["account"],
            "bob": personal_b["account"],
            "team_a": team_a,
            "team_b": team_b,
        }
        r.save()
        self.cli(
            "mac-list-before-backup", "mac", "alice", "tenant-list", {}, refresh=True
        )
        self.cli(
            "linux-list-before-backup", "linux", "bob", "tenant-list", {}, refresh=True
        )
        self.cli(
            "mac-switch-team-a",
            "mac",
            "alice",
            "switch",
            {"expectedTenant": personal_a, "targetTenant": tenant_a},
        )
        self.cli("mac-current-team-a", "mac", "alice", "current", {}, refresh=True)
        invitation = self.result(
            self.cli(
                "mac-invite-bob",
                "mac",
                "alice",
                "invite",
                {"expectedTenant": tenant_a, "loginIdentifier": name_b},
            ),
            "invitation",
        )
        self.cli("linux-inbox-bob", "linux", "bob", "inbox", {}, refresh=True)
        r.evidence["invitation"] = invitation
        r.save()
        r.helper("full-health-after-backup", "full-health", "--project", r.project)
        stopped = self.parse(
            "stop", r.helper("stop", "stop", "--project", r.project, timeout=600)
        )
        need(
            stopped
            == {"state": "stopped", "containerId": cid, "exitCode": 0, "clean": True},
            "confirmed clean stop",
        )
        r.inner("stopped-center-inspect", "inspect", cid)
        r.inner("stopped-center-logs", "logs", cid)


def qa_context():
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w") as archive:
        for name in ("Dockerfile", "gate.mjs"):
            content = (HERE / name).read_bytes()
            member = tarfile.TarInfo(name)
            member.size = len(content)
            member.mode = 0o644
            archive.addfile(member, io.BytesIO(content))
    return buffer.getvalue()


def build_qa(run, base, inputs):
    original = run.image_id
    tag = "omne-business-backup-base:" + run.run_id.lower().replace("t", "-").replace(
        "z", ""
    )
    qa_tag = "omne-business-backup-qa:" + run.run_id.lower().replace("t", "-").replace(
        "z", ""
    )
    run.inner("qa-tag-base", "tag", original, tag)
    run.outer(
        "qa-build",
        "exec",
        "-i",
        run.dind,
        "docker",
        "--host",
        base.SOCKET,
        "build",
        "--pull=false",
        "--network=none",
        "--no-cache",
        "--build-arg",
        "BASE_IMAGE=" + tag,
        "-t",
        qa_tag,
        "-",
        stdin=qa_context(),
        timeout=600,
    )
    original_inspect = json.loads(
        run.inner("qa-original-inspect", "image", "inspect", original)
    )[0]
    qa_inspect = json.loads(run.inner("qa-image-inspect", "image", "inspect", qa_tag))[
        0
    ]
    need(
        qa_inspect["Os"] == original_inspect["Os"] == "linux"
        and qa_inspect["Architecture"] == original_inspect["Architecture"] == "arm64"
        and qa_inspect["Config"]["User"]
        == original_inspect["Config"]["User"]
        == "10001:10001"
        and qa_inspect["Config"]["Entrypoint"]
        == original_inspect["Config"]["Entrypoint"]
        and qa_inspect["Config"]["Cmd"] == original_inspect["Config"]["Cmd"]
        and qa_inspect["RootFS"]["Layers"][: len(original_inspect["RootFS"]["Layers"])]
        == original_inspect["RootFS"]["Layers"]
        and qa_inspect["Config"]["Labels"].get("ai.nemori.omne.qa-fixture")
        == inputs["qa_fixture"],
        "QA derivation changed original image identity",
    )
    for tag_name, image in (("original", original), ("qa", qa_inspect["Id"])):
        raw = run.outer(
            "exec-inventory-" + tag_name,
            "exec",
            "-i",
            run.dind,
            "docker",
            "--host",
            base.SOCKET,
            "run",
            "--rm",
            "--pull",
            "never",
            "--network",
            "none",
            "-i",
            "--entrypoint",
            "node",
            "-e",
            "NODE_OPTIONS=",
            image,
            "--input-type=module",
            "-",
            stdin=HERE / "inventory.mjs",
            timeout=180,
        )
        report = base.parse_json_line(raw, tag_name + " inventory")
        need(
            report.get("status") == "verified"
            and report.get("buildId") == inputs["build_id"]
            and report.get("manifestSha256") == inputs["sha256"]["host_file_manifest"]
            and report.get("node") == "v24.21.0",
            "full app inventory mismatch",
        )
    run.evidence["expected"]["original_inner_image_id"] = original
    run.evidence["expected"]["qa_inner_image_id"] = qa_inspect["Id"]
    run.image_id = qa_inspect["Id"]
    run.save()


def inspect_maintenance(run, action):
    name = "maintenance-" + action.replace("-", "-")
    ids = (
        run.inner(
            name + "-list",
            "ps",
            "-aq",
            "--no-trunc",
            "--filter",
            "label=ai.nemori.omne.project=" + run.project,
            "--filter",
            "label=ai.nemori.omne.service=maintenance",
            "--filter",
            "label=ai.nemori.omne.action=" + action,
        )
        .decode()
        .splitlines()
    )
    need(
        len(ids) == 1 and re.fullmatch(r"[0-9a-f]{64}", ids[0]),
        action + " exact maintenance container",
    )
    run.inner(name + "-inspect", "inspect", ids[0])
    run.evidence.setdefault("maintenance_ids", {})[action] = ids[0]
    run.save()


def direct_serve_probe(run, base, label, storage_file):
    name = "omne-" + run.project + "-" + label
    flags = [
        "run",
        "--name",
        name,
        "--pull",
        "never",
        "--network",
        "none",
        "--restart",
        "no",
        "--label",
        run.label,
        "--label",
        "ai.nemori.omne.project=" + run.project,
        "--user",
        "10001:10001",
        "--mount",
        f"type=bind,source={base.STATE},target=/state",
        "--mount",
        f"type=bind,source={base.SECRETS},target=/secrets,readonly",
        "--tmpfs",
        "/run/omne-tenancy:mode=0700,uid=10001,gid=10001,nosuid,nodev,noexec",
        "--env-file",
        base.SETTINGS,
        "-e",
        "OMNE_TENANCY_STORAGE_DIALECT=sqlite",
        "-e",
        "OMNE_TENANCY_STORAGE_FILE=" + storage_file,
        "-e",
        "OMNE_TENANCY_BACKUP_DIR=/state/backups",
        "-e",
        "OMNE_TENANCY_OPS_SOCKET_DIR=/run/omne-tenancy",
        "-e",
        "OMNE_TENANCY_ENTRY_LISTEN=0.0.0.0:8443",
    ]
    for key, file in (
        ("ACTIVATION_SIGNING_KEY", "activation-signing-key"),
        ("ACTIVATION_VERIFICATION_KEY", "activation-verification-key"),
        ("PURGE_SIGNING_KEY", "purge-signing-key"),
        ("PURGE_VERIFICATION_KEY", "purge-verification-key"),
    ):
        flags += ["-e", f"OMNE_TENANCY_{key}_PEM_FILE=/secrets/{file}.pem"]
    flags += [
        "-e",
        "OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE=/secrets/tls-chain.pem",
        "-e",
        "OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE=/secrets/tls-private.pem",
        run.evidence["expected"]["original_inner_image_id"],
    ]
    run.inner(label + "-serve", *flags, expected=None, timeout=90)
    run.inner(label + "-inspect", "inspect", name)
    run.inner(label + "-logs", "logs", name)
    run.evidence.setdefault("serve_probes", {})[label] = {
        "container_name": name,
        "storage_file": storage_file,
    }
    run.save()


def offline_and_rejection_probes(run, base):
    descriptor = run.evidence["backup"]["backup"]
    file_name = descriptor["fileName"]
    need(re.fullmatch(r"[0-9a-f]{32}\.omne-backup", file_name), "backup filename")
    source = base.STATE + "/backups/" + file_name
    work = base.STATE + "/offline-work/" + run.project
    target = base.STATE + "/restores/" + run.project
    original = run.evidence["expected"]["original_inner_image_id"]
    run.evidence["offline"] = {"source": source, "work": work, "target": target}
    run.save()
    run.control_exec("source-envelope-stat", "stat", "-c", "%F:%u:%g:%a:%s", source)
    run.control_exec("source-envelope-sha", "sha256sum", source)
    common = [
        "--project",
        run.project,
        "--image",
        original,
        "--state-dir",
        base.STATE,
        "--uid",
        "10001",
        "--gid",
        "10001",
    ]
    run.helper(
        "offline-verify",
        "verify",
        *common,
        "--source",
        source,
        "--work-dir",
        work,
        timeout=600,
    )
    inspect_maintenance(run, "verify")
    run.helper(
        "offline-restore",
        "restore-isolated",
        *common,
        "--source",
        source,
        "--work-dir",
        work,
        "--target",
        target,
        timeout=600,
    )
    inspect_maintenance(run, "restore-isolated")
    run.control_exec(
        "work-marker-stat", "stat", "-c", "%d:%i:%u:%g:%a:%s", work + "/.omne-isolated"
    )
    run.control_exec("work-marker-bytes", "cat", work + "/.omne-isolated")
    run.control_exec("restore-target-stat", "stat", "-c", "%F:%u:%g:%a", target)
    run.control_exec(
        "restore-envelope-stat",
        "stat",
        "-c",
        "%F:%u:%g:%a:%s",
        target + "/data.omne-backup",
    )
    run.control_exec("restore-envelope-sha", "sha256sum", target + "/data.omne-backup")
    target_project = run.project + "target"
    run.helper(
        "restore-target-helper-start",
        "start",
        "--project",
        target_project,
        "--image",
        original,
        "--state-dir",
        target,
        "--secrets-dir",
        base.SECRETS,
        "--settings-file",
        base.SETTINGS,
        "--publish-address",
        run.dind_ip,
        "--publish-port",
        "18445",
        "--uid",
        "10001",
        "--gid",
        "10001",
        expected=None,
    )
    run.inner(
        "restore-target-project-list",
        "ps",
        "-aq",
        "--no-trunc",
        "--filter",
        "label=ai.nemori.omne.project=" + target_project,
    )
    direct_serve_probe(
        run, base, "envelope", "/state/restores/" + run.project + "/data.omne-backup"
    )
    direct_serve_probe(
        run, base, "marker", "/state/offline-work/" + run.project + "/probe.sqlite"
    )
    run.control_exec("source-envelope-sha-after-probes", "sha256sum", source)
    run.control_exec(
        "restore-envelope-sha-after-probes", "sha256sum", target + "/data.omne-backup"
    )
    run.control_exec(
        "work-marker-stat-after-probes",
        "stat",
        "-c",
        "%d:%i:%u:%g:%a:%s",
        work + "/.omne-isolated",
    )
    run.control_exec("work-marker-bytes-after-probes", "cat", work + "/.omne-isolated")
    run.evidence["business_complete"] = True
    run.save()


def run_platform(platform, gate):
    need(host_platform.system() == "Darwin", "Mac CLI leg requires a Darwin host")
    inputs = input_set(platform)
    gate_data = json.loads(gate.read_text())
    need(
        gate_data
        == {
            "approved": True,
            "reviewer": "root",
            "inputs_sha256": hashlib.sha256(canonical(inputs)).hexdigest(),
            "driver_sha256": inputs["sha256"]["driver"],
            "oracle_sha256": inputs["sha256"]["oracle"],
        },
        "review gate missing or stale",
    )
    base = load_base()
    base.HERE = HERE
    args = args_for_base(inputs, gate)
    run = base.Run(args, inputs)
    for name, source, key in (
        ("driver.py", HERE / "driver.py", "driver"),
        ("v0-driver.py", BASE_PATH, "v0_driver"),
        ("manifest-delivery.json", MANIFEST, "manifest"),
        ("Dockerfile", HERE / "Dockerfile", "dockerfile"),
        ("gate.mjs", HERE / "gate.mjs", "gate"),
        ("inventory.mjs", HERE / "inventory.mjs", "inventory"),
        ("accepted-v4-driver.py", V4, "v4_driver"),
    ):
        frozen = run.frozen / name
        shutil.copyfile(source, frozen)
        need(sha(frozen) == inputs["sha256"][key], "frozen input changed: " + name)
    run.evidence["host"] = {
        "system": host_platform.system(),
        "machine": host_platform.machine(),
    }
    run.save()
    journey = Journey(run, base, inputs)
    try:
        setup(run, base)
        import_image(run, base, platform)
        build_qa(run, base, inputs)
        run.prepare_paths()
        run.control_exec(
            "qa-directory",
            "install",
            "-d",
            "-m",
            "0700",
            "-o",
            "10001",
            "-g",
            "10001",
            base.STATE + "/qa",
        )
        run.control_exec(
            "qa-mode",
            "sh",
            "-c",
            'umask 077; printf "write-hold\\n" > "$1"; chown 10001:10001 "$1"',
            "sh",
            base.STATE + "/qa/mode",
        )
        run.control_exec(
            "append-qa-credential-policy",
            "sh",
            "-c",
            'printf "%s\\n" "$1" >> "$2"',
            "sh",
            QA_CREDENTIAL_POLICY,
            base.SETTINGS,
        )
        observed_policy = run.control_exec(
            "read-qa-credential-policy",
            "grep",
            "-Fx",
            QA_CREDENTIAL_POLICY,
            base.SETTINGS,
        )
        need(
            observed_policy == (QA_CREDENTIAL_POLICY + "\n").encode(),
            "QA credential policy settings not observed",
        )
        prepare_clients(run, journey)
        journey.go()
        offline_and_rejection_probes(run, base)
        run.evidence["status"] = "observed-awaiting-oracle"
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
    finally:
        if (
            getattr(run, "backup_process", None) is not None
            and run.backup_process.poll() is None
        ):
            try:
                run.control_exec(
                    "gate-emergency-release",
                    "sh",
                    "-c",
                    'umask 077; : > "$1"',
                    "sh",
                    base.STATE + "/qa/release",
                    expected=None,
                    cleanup=True,
                )
                run.backup_process.wait(timeout=600)
                run.evidence["async_backup"][
                    "returncode"
                ] = run.backup_process.returncode
                run.evidence["async_backup"]["finished_utc"] = datetime.now(
                    timezone.utc
                ).isoformat()
                run.save()
            except Exception as error:
                run.evidence["async_cleanup_error"] = str(error)
                run.save()
        other_errors = cleanup_other_project(run)
        target_errors = cleanup_named_project(run, run.project + "target")
        run.cleanup()
        run.evidence["other_project_cleanup_complete"] = not other_errors
        run.evidence["other_project_cleanup_errors"] = other_errors
        run.evidence["target_project_cleanup_complete"] = not target_errors
        run.evidence["target_project_cleanup_errors"] = target_errors
        run.save()
    with (
        (run.run / "oracle.stdout").open("xb") as out,
        (run.run / "oracle.stderr").open("xb") as err,
    ):
        result = subprocess.run(
            [sys.executable, "-B", str(run.frozen / "oracle.py"), str(run.run)],
            stdout=out,
            stderr=err,
            check=False,
        )
    run.evidence["oracle_exit"] = result.returncode
    run.save()
    print(
        json.dumps(
            {
                "run": str(run.run),
                "oracle_exit": result.returncode,
                "cleanup_complete": run.evidence["cleanup_complete"],
            },
            sort_keys=True,
        )
    )
    return result.returncode


def setup(run, base):
    for kind, name in [
        ("network", run.network),
        *(("volume", v) for v in run.volumes),
        ("container", run.control),
        ("container", run.dind),
    ]:
        run.preflight_resource(kind, name)
    for image, expected in ((base.CONTROL, base.CONTROL_ID), (base.DIND, base.DIND_ID)):
        actual = json.loads(
            run.outer("outer-image-" + image.split(":")[0], "image", "inspect", image)
        )[0]["Id"]
        need(actual == expected, "fixed image changed " + image)
    run.create(
        "network", run.network, "network", "create", "--label", run.label, run.network
    )
    for volume in run.volumes:
        run.create("volume", volume, "volume", "create", "--label", run.label, volume)
    run.create(
        "container",
        run.control,
        "run",
        "-d",
        "--pull",
        "never",
        "--name",
        run.control,
        "--label",
        run.label,
        "--network",
        run.network,
        "--privileged",
        "-e",
        f"DOCKER_HOST={base.SOCKET}",
        "--cgroupns=private",
        "--tmpfs",
        "/run",
        "--tmpfs",
        "/run/lock",
        "--tmpfs",
        "/tmp",
        "-v",
        f"{run.volumes[0]}:{base.ROOT}",
        "-v",
        f"{run.volumes[1]}:/opt/omne-private-docker",
        base.CONTROL,
    )
    run.create(
        "container",
        run.dind,
        "run",
        "-d",
        "--pull",
        "never",
        "--name",
        run.dind,
        "--label",
        run.label,
        "--network",
        run.network,
        "--privileged",
        "-p",
        f"127.0.0.1::{PORT}",
        "-e",
        f"DOCKER_HOST={base.SOCKET}",
        "-e",
        "DOCKER_TLS_CERTDIR=",
        "-v",
        f"{run.volumes[0]}:{base.ROOT}",
        "-v",
        f"{run.volumes[1]}:/opt/omne-private-docker",
        "-v",
        f"{run.volumes[2]}:/var/lib/docker",
        base.DIND,
        "--host",
        base.SOCKET,
        "--tls=false",
    )
    for outer in (run.control, run.dind):
        inspected = json.loads(run.outer("outer-inspect-" + outer, "inspect", outer))[0]
        need(
            all(m["Type"] == "volume" for m in inspected["Mounts"]),
            "host bind forbidden",
        )
        ports = inspected["NetworkSettings"]["Ports"]
        if outer == run.control:
            need(not inspected["HostConfig"]["PortBindings"], "control port forbidden")
        else:
            published = ports[f"{PORT}/tcp"]
            need(
                len(published) == 1 and published[0]["HostIp"] == "127.0.0.1",
                "Mac forwarding must be loopback only",
            )
            run.mac_port = int(published[0]["HostPort"])
            run.dind_ip = inspected["NetworkSettings"]["Networks"][run.network][
                "IPAddress"
            ]
            need(
                re.fullmatch(r"(?:10|172|192)\.[0-9.]+", run.dind_ip)
                and 1 <= run.mac_port <= 65535,
                "private DinD IP/port",
            )
    need(run.control_exec("control-uid", "id", "-u").strip() == b"0", "control root")
    need(
        run.control_exec("control-pid1", "cat", "/proc/1/comm").strip() == b"systemd",
        "control systemd",
    )
    run.control_exec("control-systemd-version", "systemctl", "--version")
    need(
        run.control_exec("linux-uname", "uname", "-s").strip() == b"Linux",
        "Linux client control",
    )
    run.control_exec(
        "mkdir-plugin",
        "install",
        "-d",
        "-m",
        "0755",
        "/usr/local/lib/docker/cli-plugins",
        "/usr/local/libexec",
    )
    run.copy(
        "copy-docker-cli", base.V0 / "extracted-bin/docker", "/usr/local/bin/docker"
    )
    run.copy(
        "copy-compose",
        base.V0 / "docker-compose-linux-aarch64",
        "/usr/local/lib/docker/cli-plugins/docker-compose",
    )
    run.control_exec(
        "chmod-cli",
        "chmod",
        "0755",
        "/usr/local/bin/docker",
        "/usr/local/lib/docker/cli-plugins/docker-compose",
    )
    for attempt in range(1, 41):
        output = run.inner(
            f"engine-ready-{attempt}",
            "version",
            "--format",
            "{{.Client.Version}} {{.Server.Version}}",
            expected=None,
        )
        if (
            run.evidence["commands"][-1]["returncode"] == 0
            and output.strip() == b"29.1.3 29.1.3"
        ):
            break
        import time

        time.sleep(1)
    else:
        raise RuntimeError("private Engine unavailable")
    need(
        run.control_exec(
            "compose-version", "docker", "compose", "version", "--short"
        ).strip()
        == b"2.40.3",
        "Compose version",
    )
    for name in (
        "omne-center",
        "compose.yaml",
        "compose.maintenance.yaml",
        "health.mjs",
    ):
        run.copy("copy-" + name, run.frozen / name, "/usr/local/libexec/" + name)
    run.control_exec("chmod-helper", "chmod", "0755", base.HELPER)
    run.evidence["network"] = {
        "dind_ip": run.dind_ip,
        "mac_loopback_port": run.mac_port,
    }
    run.save()


def cleanup_other_project(run):
    """The helper's second project is owned by this run but not by V0's project filter."""
    errors = []
    second = run.project + "other"
    try:
        if ("container", run.control) not in run.created or (
            "container",
            run.dind,
        ) not in run.created:
            return errors
        found = (
            run.inner(
                "cleanup-other-list",
                "ps",
                "-aq",
                "--no-trunc",
                "--filter",
                f"label=ai.nemori.omne.project={second}",
                cleanup=True,
            )
            .decode()
            .splitlines()
        )
        for index, cid in enumerate(found):
            inspected = json.loads(
                run.inner(
                    f"cleanup-other-inspect-{index}", "inspect", cid, cleanup=True
                )
            )[0]
            need(
                inspected["Id"] == cid
                and inspected["Config"]["Labels"].get("ai.nemori.omne.project")
                == second,
                "second project cleanup identity mismatch",
            )
            run.inner(f"cleanup-other-remove-{index}", "rm", "-f", cid, cleanup=True)
        remaining = run.inner(
            "cleanup-other-final-list",
            "ps",
            "-aq",
            "--no-trunc",
            "--filter",
            f"label=ai.nemori.omne.project={second}",
            cleanup=True,
        )
        need(remaining == b"", "second project residual")
    except Exception as error:
        errors.append(str(error))
    return errors


def cleanup_named_project(run, project):
    errors = []
    try:
        if ("container", run.control) not in run.created or (
            "container",
            run.dind,
        ) not in run.created:
            return errors
        found = (
            run.inner(
                "cleanup-target-project-list",
                "ps",
                "-aq",
                "--no-trunc",
                "--filter",
                f"label=ai.nemori.omne.project={project}",
                cleanup=True,
            )
            .decode()
            .splitlines()
        )
        for index, cid in enumerate(found):
            inspected = json.loads(
                run.inner(
                    f"cleanup-target-project-inspect-{index}",
                    "inspect",
                    cid,
                    cleanup=True,
                )
            )[0]
            need(
                inspected["Id"] == cid
                and inspected["Config"]["Labels"].get("ai.nemori.omne.project")
                == project,
                "target-project cleanup identity",
            )
            run.inner(
                f"cleanup-target-project-remove-{index}", "rm", "-f", cid, cleanup=True
            )
        remaining = run.inner(
            "cleanup-target-project-final-list",
            "ps",
            "-aq",
            "--no-trunc",
            "--filter",
            f"label=ai.nemori.omne.project={project}",
            cleanup=True,
        )
        need(remaining == b"", "target project residual")
    except Exception as error:
        errors.append(str(error))
    return errors


def import_image(run, base, platform):
    need(
        sha(run.args.image_tar) == run.evidence["inputs"]["sha256"]["image_tar"],
        "image changed",
    )
    run.outer(
        "load-image",
        "exec",
        "-i",
        run.dind,
        "docker",
        "--host",
        base.SOCKET,
        "load",
        stdin=run.args.image_tar,
        timeout=180,
    )
    ids = run.inner(
        "inner-image-list",
        "image",
        "ls",
        "-q",
        "--no-trunc",
        "--filter",
        f"label=ai.nemori.omne.host-build-id={run.args.build_id}",
    )
    lines = sorted(set(ids.decode().splitlines()))
    need(len(lines) == 1 and IMAGE.fullmatch(lines[0]), "inner image ambiguous")
    inner = json.loads(run.inner("inner-image-inspect", "image", "inspect", lines[0]))[
        0
    ]
    outer = json.loads(
        run.outer("outer-product-image", "image", "inspect", run.args.image_id)
    )[0]
    need(
        outer["Id"] == run.args.image_id
        and inner["RootFS"]["Layers"] == outer["RootFS"]["Layers"],
        "image bytes mismatch",
    )
    for image in (inner, outer):
        need(
            image["Os"] == "linux" and image["Architecture"] == platform,
            "image platform",
        )
        need(
            image["Config"]["Labels"]["ai.nemori.omne.host-build-id"]
            == run.args.build_id,
            "image BUILD_ID",
        )
        need(
            image["Config"]["Labels"]["ai.nemori.omne.distribution"]
            == "tenancy-host-docker/1",
            "image distribution",
        )
    run.image_id = lines[0]
    run.evidence["expected"] = {
        "image_id": run.args.image_id,
        "inner_image_id": run.image_id,
        "build_id": run.args.build_id,
        "cli_build_id": run.evidence["inputs"]["cli_build_id"],
        "project": run.project,
        "control": run.control,
        "dind": run.dind,
        "uid": 10001,
        "gid": 10001,
        "state": base.STATE,
        "platform": platform,
    }
    run.save()


def prepare_clients(run, journey):
    base = journey.base
    run.control_exec("linux-node-version", "node", "--version")
    need(
        (run.run / "raw/linux-node-version.stdout").read_bytes() == b"v24.21.0\n",
        "Linux Node",
    )
    run.control_exec("linux-openssl-version", "openssl", "version")
    need(
        b"OpenSSL 3." in (run.run / "raw/linux-openssl-version.stdout").read_bytes(),
        "Linux OpenSSL3",
    )
    run.mac_node = shutil.which("node")
    need(run.mac_node is not None, "Mac Node absent")
    need(
        run.call("mac-node-version", [run.mac_node, "--version"]).strip()
        == b"v24.21.0",
        "Mac Node24.21",
    )
    run.control_exec(
        "mkdir-qa",
        "install",
        "-d",
        "-m",
        "0700",
        "/opt/omne-cross-os",
        LINUX_QA_DIR,
    )
    cli_tar = pathlib.Path(journey.inputs["paths"]["cli_tar"])
    need(sha(cli_tar) == journey.inputs["sha256"]["cli_tar"], "CLI changed")
    frozen_cli = run.frozen / "cli.tar.gz"
    shutil.copyfile(cli_tar, frozen_cli)
    need(sha(frozen_cli) == journey.inputs["sha256"]["cli_tar"], "frozen CLI")
    mac_cli_root = journey.private / "mac-cli"
    mac_cli_root.mkdir(mode=0o700)
    run.call(
        "mac-cli-extract", ["tar", "-xzf", str(frozen_cli), "-C", str(mac_cli_root)]
    )
    run.mac_cli = mac_cli_root / "app/dist/main.js"
    run.outer(
        "copy-linux-cli-tar",
        "cp",
        str(frozen_cli),
        f"{run.control}:{LINUX_QA_DIR}/cli.tar.gz",
    )
    run.control_exec(
        "linux-cli-extract",
        "tar",
        "-xzf",
        LINUX_QA_DIR + "/cli.tar.gz",
        "-C",
        LINUX_QA_DIR,
    )
    need(
        journey.inputs["cli_build_id"].encode()
        in run.call("mac-cli-version", [run.mac_node, str(run.mac_cli), "--version"]),
        "Mac CLI build",
    )
    need(
        journey.inputs["cli_build_id"].encode()
        in run.control_exec(
            "linux-cli-version",
            "node",
            LINUX_CLI,
            "--version",
        ),
        "Linux CLI build",
    )
    # Parent prepares full shared Linux state and fixture-only keys. Reissue a SAN
    # certificate for both actual transport endpoints after the DinD address is known.
    run.control_exec(
        "cross-tls",
        "openssl",
        "req",
        "-x509",
        "-newkey",
        "rsa:2048",
        "-sha256",
        "-nodes",
        "-days",
        "1",
        "-subj",
        "/CN=localhost",
        "-addext",
        f"subjectAltName=DNS:localhost,IP:127.0.0.1,IP:{run.dind_ip}",
        "-keyout",
        base.SECRETS + "/tls-private.pem",
        "-out",
        base.SECRETS + "/tls-chain.pem",
    )
    run.control_exec(
        "cross-tls-owner",
        "chown",
        "10001:10001",
        base.SECRETS + "/tls-private.pem",
        base.SECRETS + "/tls-chain.pem",
    )
    run.control_exec(
        "cross-tls-mode",
        "chmod",
        "0600",
        base.SECRETS + "/tls-private.pem",
        base.SECRETS + "/tls-chain.pem",
    )
    run.control_exec(
        "cross-tls-inspect",
        "openssl",
        "x509",
        "-in",
        base.SECRETS + "/tls-chain.pem",
        "-noout",
        "-ext",
        "subjectAltName",
    )
    run.outer(
        "copy-mac-ca",
        "cp",
        f"{run.control}:{base.SECRETS}/tls-chain.pem",
        str(journey.private / "ca.pem"),
    )
    run.control_exec(
        "decoy-ca",
        "openssl",
        "req",
        "-x509",
        "-newkey",
        "rsa:2048",
        "-sha256",
        "-nodes",
        "-days",
        "1",
        "-subj",
        "/CN=wrong-test-ca",
        "-keyout",
        LINUX_QA_DIR + "/bad-ca.key",
        "-out",
        LINUX_QA_DIR + "/bad-ca.pem",
    )
    run.outer(
        "copy-mac-bad-ca",
        "cp",
        f"{run.control}:{LINUX_QA_DIR}/bad-ca.pem",
        str(journey.private / "bad-ca.pem"),
    )
    run.control_exec(
        "copy-linux-ca",
        "cp",
        base.SECRETS + "/tls-chain.pem",
        LINUX_QA_DIR + "/ca.pem",
    )
    run.evidence["client_paths"] = {
        "mac": str(run.mac_cli),
        "linux": LINUX_CLI,
    }
    run.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--platform", choices=("arm64",), required=True)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    inputs = input_set(args.platform)
    if args.print_inputs:
        print(
            json.dumps(
                {
                    "inputs": inputs,
                    "inputs_sha256": hashlib.sha256(canonical(inputs)).hexdigest(),
                },
                sort_keys=True,
            )
        )
        return 0
    need(
        args.execute and args.reviewed_gate is not None,
        "Docker requires --execute and root-reviewed gate",
    )
    return run_platform(args.platform, args.reviewed_gate)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"preflight refused: {error}", file=sys.stderr)
        raise SystemExit(2)
