#!/usr/bin/env bash
# Source the frozen installed helper; its BASH_SOURCE guard leaves main uncalled.
set -euo pipefail
helper="$1"; expected_image="$2"; expected_state="$3"; expected_secrets="$4"
expected_address="$5"; expected_port="$6"; expected_uid="$7"; expected_gid="$8"
source "$helper"
state_dir="$expected_state"
secrets_dir="$expected_secrets"
publish_address="$expected_address"
publish_port="$expected_port"
app_uid="$expected_uid"
app_gid="$expected_gid"
desired_image_id="$expected_image"
inspected="$(cat)"
[[ -n "$inspected" ]] || fail missing-inspect-input
# This is the unmodified installed function, including its real image inspect and jq.
validate_actual_center "$inspected"
printf 'actual-container-valid\n'
