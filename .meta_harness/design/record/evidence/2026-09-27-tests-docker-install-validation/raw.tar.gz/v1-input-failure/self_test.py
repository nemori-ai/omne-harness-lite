#!/usr/bin/env python3
"""Offline representative counterexamples; never invokes Docker or the helper."""
import copy
import hashlib
import json
import pathlib
import tempfile

import oracle


def rejected(call):
    try:
        call()
    except (AssertionError, KeyError, TypeError, ValueError):
        return True
    return False


def write(run, label, data=b"", err=b"", rc=0):
    (run / "raw" / (label + ".stdout")).write_bytes(data)
    (run / "raw" / (label + ".stderr")).write_bytes(err)
    return {
        "label": label,
        "stdout": "raw/" + label + ".stdout",
        "stderr": "raw/" + label + ".stderr",
        "returncode": rc,
        "observation_expired": False,
        "argv": [],
    }


def baseline_lines():
    fields = (
        ("directory", "0", "0", "755"),
        ("directory", "12017", "12019", "700"),
        ("directory", "12017", "12019", "700"),
        ("directory", "12017", "12019", "700"),
        ("regular file", "12017", "12019", "600"),
        ("regular file", "0", "0", "600"),
    )
    return "".join(
        f"{path}|{kind}|{uid}|{gid}|{mode}|12|{i + 1}|16\n"
        for i, (path, (kind, uid, gid, mode)) in enumerate(
            zip(oracle.STAT_PATHS, fields)
        )
    ).encode()


def component_example(run):
    project = "r5samplecomponent"
    state = "/var/lib/omne-tenancy/state"
    original = "sha256:" + "a" * 64
    normal_id = "b" * 64
    bad_id = "c" * 64
    common = {
        "Image": original,
        "Path": "node",
        "Args": ["/opt/omne/app/dist/cli.js", "serve"],
        "Config": {
            "User": "12017:12019",
            "Entrypoint": ["node", "/opt/omne/app/dist/cli.js"],
            "Cmd": ["serve"],
            "Env": ["PATH=/usr/local/bin"],
            "StopTimeout": -1,
            "StopSignal": "SIGTERM",
            "Healthcheck": {
                "Test": ["CMD", "node", "/opt/omne/app/deploy/docker/health.mjs"]
            },
            "Labels": {"ai.nemori.omne.project": project},
        },
        "State": {"Status": "created", "Running": False},
        "HostConfig": {
            "RestartPolicy": {"Name": "unless-stopped"},
            "PortBindings": {
                "8443/tcp": [{"HostIp": "127.0.0.1", "HostPort": "18443"}]
            },
            "Tmpfs": {"/run/omne-tenancy": "mode=0700"},
            "Privileged": False,
            "PidMode": "",
            "CapAdd": None,
            "Devices": None,
            "DeviceRequests": None,
        },
    }
    normal = copy.deepcopy(common)
    normal["Id"] = normal_id
    normal["Mounts"] = [
        {"Destination": "/state", "Type": "bind", "Source": state, "RW": True},
        {
            "Destination": "/secrets",
            "Type": "bind",
            "Source": "/var/lib/omne-tenancy/secrets",
            "RW": False,
        },
    ]
    bad = copy.deepcopy(normal)
    bad["Id"] = bad_id
    bad["Mounts"].append(
        {
            "Destination": "/qa-extra",
            "Type": "bind",
            "Source": "/var/lib/omne-tenancy/qa-extra-r5sample",
            "RW": True,
        }
    )
    commands = {
        "component-normal-ids": write(
            run, "component-normal-ids", (normal_id + "\n").encode()
        ),
        "component-extra-ids": write(
            run, "component-extra-ids", (bad_id + "\n").encode()
        ),
        "component-normal-inspect": write(
            run, "component-normal-inspect", json.dumps([normal]).encode() + b"\n"
        ),
        "component-extra-inspect": write(
            run, "component-extra-inspect", json.dumps([bad]).encode() + b"\n"
        ),
        "component-normal-probe": write(
            run, "component-normal-probe", b"actual-container-valid\n"
        ),
        "component-extra-probe": write(
            run,
            "component-extra-probe",
            err=b"omne-center: actual-container-unsafe\n",
            rc=1,
        ),
        "component-between-ids": write(run, "component-between-ids"),
        "component-between-ids-name": write(run, "component-between-ids-name", rc=1),
        "component-normal-remove": write(
            run, "component-normal-remove", normal_id.encode() + b"\n"
        ),
        "component-extra-stat": write(
            run,
            "component-extra-stat",
            b"/var/lib/omne-tenancy/qa-extra-r5sample|directory|0|0|700|12|8|16\n",
        ),
    }
    control = "r5sample-control"
    socket = "unix:///opt/omne-private-docker/docker.sock"
    for kind, cid in (("normal", normal_id), ("extra", bad_id)):
        inspect_label = "component-" + kind + "-inspect"
        probe_label = "component-" + kind + "-probe"
        commands[inspect_label]["argv"] = [
            "docker",
            "exec",
            control,
            "docker",
            "--host",
            socket,
            "inspect",
            cid,
        ]
        commands[probe_label]["argv"] = [
            "docker",
            "exec",
            "-i",
            "-e",
            "DOCKER_HOST=" + socket,
            control,
            "bash",
            "/usr/local/libexec/qa-component-probe.sh",
            "/usr/local/libexec/omne-center",
            original,
            state,
            "/var/lib/omne-tenancy/secrets",
            "127.0.0.1",
            "18443",
            "12017",
            "12019",
        ]
        commands[probe_label]["stdin_source"] = "raw/" + inspect_label + ".stdout"
        commands[probe_label]["stdin_sha256"] = hashlib.sha256(
            (run / commands[probe_label]["stdin_source"]).read_bytes()
        ).hexdigest()
    evidence = {
        "expected": {
            "project": "r5sample",
            "state": state,
            "inner_image_id": original,
            "control": control,
        },
        "component_project": project,
    }
    return commands, evidence


def main():
    checks = {}
    baseline = oracle.parse_stat(baseline_lines(), oracle.STAT_PATHS)
    oracle.correct_baseline(baseline)
    checks["valid_baseline_stat"] = True
    wrong = copy.deepcopy(baseline)
    wrong[oracle.STAT_PATHS[2]]["mode"] = "755"
    checks["world_readable_data_rejected"] = rejected(
        lambda: oracle.correct_baseline(wrong)
    )
    wrong = copy.deepcopy(baseline)
    wrong[oracle.STAT_PATHS[4]]["mode"] = "644"
    checks["world_readable_secret_rejected"] = rejected(
        lambda: oracle.correct_baseline(wrong)
    )
    wrong = copy.deepcopy(baseline)
    wrong[oracle.STAT_PATHS[2]]["inode"] = "99"
    checks["replaced_data_rejected"] = rejected(lambda: oracle.stable(baseline, wrong))
    checks["missing_json_lf_rejected"] = rejected(
        lambda: oracle.one_json(b'{"state":"deployment-structure-valid"}', "x")
    )
    with tempfile.TemporaryDirectory() as temporary:
        run = pathlib.Path(temporary)
        (run / "raw").mkdir()
        commands = {
            "absent": write(run, "absent"),
            "absent-name": write(run, "absent-name", rc=1),
        }
        oracle.project_absent(run, commands, "absent")
        checks["valid_absence"] = True
        (run / "raw/absent.stdout").write_bytes(b"bad-id\n")
        checks["created_service_rejected"] = rejected(
            lambda: oracle.project_absent(run, commands, "absent")
        )
        (run / "raw/absent.stdout").write_bytes(b"")
        commands["absent-name"]["returncode"] = 0
        checks["name_collision_rejected"] = rejected(
            lambda: oracle.project_absent(run, commands, "absent")
        )
        component, evidence = component_example(run)
        oracle.check_component(run, component, evidence)
        checks["valid_component_pair"] = True
        path = run / "raw/component-extra-inspect.stdout"
        original = path.read_bytes()
        for name, change in (
            (
                "extra_bind_missing_rejected",
                lambda x: x[0].update(Mounts=x[0]["Mounts"][:2]),
            ),
            (
                "narrow_state_source_rejected",
                lambda x: x[0]["Mounts"][0].update(Source="/state/data"),
            ),
            (
                "changed_bind_propagation_rejected",
                lambda x: x[0]["Mounts"][0].update(Propagation="rprivate"),
            ),
            (
                "changed_bind_mode_rejected",
                lambda x: x[0]["Mounts"][1].update(Mode="ro"),
            ),
            (
                "unsafe_container_started_rejected",
                lambda x: x[0]["State"].update(Status="running", Running=True),
            ),
        ):
            altered = json.loads(original)
            change(altered)
            path.write_bytes(json.dumps(altered).encode() + b"\n")
            component["component-extra-probe"]["stdin_sha256"] = hashlib.sha256(
                path.read_bytes()
            ).hexdigest()
            checks[name] = rejected(
                lambda: oracle.check_component(run, component, evidence)
            )
        path.write_bytes(original)
        component["component-extra-probe"]["stdin_sha256"] = hashlib.sha256(
            original
        ).hexdigest()
        probe = component["component-extra-probe"]
        probe["stdin_source"] = "raw/component-normal-inspect.stdout"
        checks["wrong_probe_source_rejected"] = rejected(
            lambda: oracle.check_component(run, component, evidence)
        )
        probe["stdin_source"] = "raw/component-extra-inspect.stdout"
        probe["stdin_sha256"] = "0" * 64
        checks["wrong_probe_sha_rejected"] = rejected(
            lambda: oracle.check_component(run, component, evidence)
        )
        probe["stdin_sha256"] = hashlib.sha256(original).hexdigest()
        probe["argv"][-1] = "0"
        checks["wrong_probe_argv_rejected"] = rejected(
            lambda: oracle.check_component(run, component, evidence)
        )
        probe["argv"][-1] = "12019"
        (run / "raw/component-extra-probe.stderr").write_bytes(
            b"omne-center: unrelated-config\n"
        )
        checks["wrong_reason_rejected"] = rejected(
            lambda: oracle.check_component(run, component, evidence)
        )
        (run / "raw/component-extra-probe.stderr").write_bytes(
            b"omne-center: actual-container-unsafe\n"
        )
        component["component-normal-inspect"]["returncode"] = 1
        checks["inspect_error_rejected"] = rejected(
            lambda: oracle.check_component(run, component, evidence)
        )
    if not all(checks.values()):
        raise AssertionError(
            "offline negative failed: " + json.dumps(checks, sort_keys=True)
        )
    print(json.dumps({"status": "PASS", "checks": checks}, sort_keys=True))


if __name__ == "__main__":
    main()
