#!/usr/bin/env python3
"""Offline close-fail exit1/private-daemon positive and false-success mutations."""

import copy
import hashlib
import json
import pathlib
import tempfile

import oracle

HERE = pathlib.Path(__file__).resolve().parent
CID = "a" * 64
CONTENDER = "b" * 64
QA_ID = "sha256:" + "c" * 64
DIND_ID = "9" * 64
DIND_NAME = "selftest-private-dind"
RUN_ID = "selftest-exit1-daemon"
SOURCE = "/state/backups/.quarantine/export-" + "d" * 32
CONTROL = "omne-r5-selftest-control"
SOCKET = "unix:///opt/omne-private-docker/docker.sock"
STATE = "/var/lib/omne-tenancy/state"
EVENT_START = "2026-09-27T00:00:00+00:00"


def encoded(value):
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        return value.encode()
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def fixture(run, scenario):
    (run / "raw").mkdir()
    (run / "inputs").mkdir()
    sha = {}
    for name in ("driver.py", "base_driver.py", "oracle.py", "gate.mjs",
                 "inventory.mjs", "gate_availability.mjs"):
        content = (HERE / name).read_bytes()
        (run / "inputs" / name).write_bytes(content)
        sha[name.removesuffix(".py").removesuffix(".mjs")] = hashlib.sha256(content).hexdigest()
    # Read-only copy of the actual final I3 manifest exercises its frozen identity.
    real = pathlib.Path("/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery/tmp/docker-delivery/i3-f8f286c9/manifest-delivery.json")
    if not real.is_file():
        raise RuntimeError("frozen I3 manifest required for offline self-test")
    (run / "inputs/i3-manifest.json").write_bytes(real.read_bytes())
    sha.update({"gate": hashlib.sha256((HERE / "gate.mjs").read_bytes()).hexdigest()})
    commands = []

    def add(label, argv=None, stdout=b"", stderr=b"", rc=0, **extra):
        out_path = "raw/" + label + ".stdout"
        err_path = "raw/" + label + ".stderr"
        (run / out_path).write_bytes(encoded(stdout))
        (run / err_path).write_bytes(encoded(stderr))
        commands.append({"label": label, "argv": argv or [], "stdout": out_path,
                         "stderr": err_path, "returncode": rc,
                         "observation_expired": False, **extra})

    inventory = {"status": "verified", "buildId": oracle.BUILD_ID, "files": 2851,
                 "links": 115, "manifestSha256": "e" * 64, "node": "v24.21.0"}
    original_image = {"Id": oracle.ORIGINAL_ID, "RootFS": {"Layers": ["sha256:" + "1" * 64]},
                      "Config": {"Labels": {"ai.nemori.omne.host-build-id": oracle.BUILD_ID},
                                 "Env": [], "Entrypoint": ["node", "/opt/omne/app/dist/cli.js"],
                                 "Cmd": ["serve"]}}
    add("inner-image-inspect", stdout=[original_image])
    add("outer-product-image", stdout=[original_image])
    add("original-inventory", stdout=inventory)
    add("qa-inventory", stdout=inventory)
    qa = {"Id": QA_ID, "Config": {"Labels": {"ai.nemori.omne.qa-fixture": "maintenance-gate/r5"},
                                     "Env": ["NODE_OPTIONS=--import=/probe/gate.mjs"],
                                     "Entrypoint": original_image["Config"]["Entrypoint"],
                                     "Cmd": original_image["Config"]["Cmd"]},
          "RootFS": {"Layers": [*original_image["RootFS"]["Layers"], "sha256:" + "2" * 64]}}
    add("qa-image-inspect", stdout=[qa])
    add("gate-availability", stdout={"status": "pass", "uid": 10001, "gid": 10001,
                                     "directory": {"mode": "755"}, "file": {"isFile": True},
                                     "actualSha256": sha["gate"]})
    prefix = ["docker", "exec", "-e", "DOCKER_HOST=" + SOCKET, CONTROL,
              "/usr/local/libexec/omne-center"]
    add("validate", [*prefix, "validate"], {"state": "deployment-structure-valid"})
    add("start", [*prefix, "start"], {"state": "running", "containerId": CID,
                                      "imageId": QA_ID, "buildId": oracle.BUILD_ID,
                                      "health": "healthy"})
    running = {"Id": CID, "Image": QA_ID, "Config": {"StopSignal": "SIGTERM",
               "StopTimeout": -1, "User": "10001:10001"},
               "HostConfig": {"RestartPolicy": {"Name": "unless-stopped"}},
               "State": {"Status": "running", "Pid": 1, "StartedAt": "time-1"},
               "RestartCount": 0,
               "Mounts": [{"Destination": "/state", "Source": STATE}]}
    add("gate-ready", stdout={"stage": "ready", "mode": scenario, "pid": 1, "armed": False})
    add("center-before-stop", stdout=[running])
    add("held-before-arm", ["test", "!", "-e", STATE + "/qa/held"])
    add("arm-gate", ["touch", STATE + "/qa/arm"])
    add("backup-client", [*prefix, "backup"], stderr="ops result unconfirmed\n", rc=1)
    held = {"stage": "write" if scenario == "write-hold" else "close",
            "pid": 1, "fd": 17, "path": SOURCE, "dev": 2048, "ino": 901}
    add("gate-held", stdout=held)
    descriptor = "/proc/1/fd/17"
    add("fd-readlink", ["docker", "exec", CID, "readlink", descriptor], SOURCE + "\n")
    add("fd-stat", ["docker", "exec", CID, "stat", descriptor], "2048:901:10001:10001:600\n")
    expected_exit = 0 if scenario == "write-hold" else 1
    add("stop-helper", [*prefix, "stop"],
        {"state": "stopped" if expected_exit == 0 else "stopped-with-error",
         "containerId": CID, "exitCode": expected_exit, "clean": expected_exit == 0},
        stderr="term-request container=" + CID + "\n", rc=expected_exit,
        started_monotonic_ns=100_000_000_000)
    term_event = ('{"Action":"kill","Actor":{"ID":"' + CID +
                  '","Attributes":{"signal":"15"}}}\n')
    add("term-poll-1", ["docker", "exec", CONTROL, "docker", "--host", SOCKET,
                        "events", "--since", EVENT_START, "--until", "2026-09-27T00:00:01+00:00",
                        "--filter", "container=" + CID, "--filter", "event=kill"],
        term_event)
    add("center-after-31s", stdout=[running])
    add("fd-readlink-after-31s", ["docker", "exec", CID, "readlink", descriptor], SOURCE + "\n")
    add("fd-stat-after-31s", ["docker", "exec", CID, "stat", descriptor],
        "2048:901:10001:10001:600\n")
    if scenario == "close-fail":
        add("marker-stat-held", ["stat", oracle.MARKER], "regular file:2048:777:10001:10001:600:16\n")
        add("marker-content-held", ["cat", oracle.MARKER], oracle.MARKER_CONTENT)
    add("center-logs-held", stderr='{"event":"still-stopping"}\n')
    add("contender-run", ["docker", "run", oracle.ORIGINAL_ID, "serve"],
        stderr='{"stage":"occupied"}\n', rc=1)
    add("contender-final", ["docker", "inspect", "selftest-contender"],
        [{"Id": CONTENDER, "Name": "/selftest-contender", "Image": oracle.ORIGINAL_ID,
          "Mounts": [{"Destination": "/state", "Source": STATE}],
          "State": {"Status": "exited", "ExitCode": 1}}])
    add("release-gate", ["touch", STATE + "/qa/release"])
    add("gate-release-present", ["test", "-f", STATE + "/qa/release"])
    final = copy.deepcopy(running)
    final["State"] = {"Status": "exited", "Running": False,
                       "ExitCode": expected_exit, "StartedAt": "time-1"}
    add("center-final", stdout=[final])
    logs = ('{"event":"maintenance-residual","path":"' + SOURCE + '"}\n'
            '{"event":"dispose-incomplete","controller":"error"}\n'
            '{"event":"disposed","complete":false}\n') if scenario == "close-fail" else \
           '{"event":"disposed","complete":true}\n'
    add("center-logs-final", stderr=logs)
    add("center-events", ["docker", "events", "--since", EVENT_START,
                          "--filter", "container=" + CID],
        term_event)
    if scenario == "close-fail":
        add("residual-stat", ["stat", STATE + SOURCE[len("/state"):]],
            "2048:901:10001:10001:600\n")
        add("marker-stat-final", ["stat", oracle.MARKER], "regular file:2048:777:10001:10001:600:16\n")
        add("marker-content-final", ["cat", oracle.MARKER], oracle.MARKER_CONTENT)
        root_stat = "directory:2048:800:10001:10001:700\n"
        quarantine_stat = "directory:2048:801:10001:10001:700\n"
        residual_stat = "2048:901:10001:10001:600\n"
        marker_stat = "regular file:2048:777:10001:10001:600:16\n"
        volume_names = ("selftest-private-data", "selftest-private-socket",
                        "selftest-private-daemon")
        volumes = [{"Name": name, "CreatedAt": "2026-09-27T00:00:00Z",
                    "Mountpoint": "/var/lib/docker/volumes/" + name,
                    "Driver": "local", "Scope": "local",
                    "Labels": {"omne.r5.helper-prep": RUN_ID}} for name in volume_names]
        mounts = [{"Type": "volume", "Name": name} for name in volume_names]
        dind_running = {"Id": DIND_ID, "Mounts": mounts,
                        "Config": {"Labels": {"omne.r5.helper-prep": RUN_ID}},
                        "State": {"Status": "running", "StartedAt": "daemon-start-1"}}
        dind_stopped = copy.deepcopy(dind_running)
        dind_stopped["State"]["Status"] = "exited"
        dind_after = copy.deepcopy(dind_running)
        dind_after["State"]["StartedAt"] = "daemon-start-2"
        add("exit1-state-root-before", stdout=root_stat)
        add("exit1-quarantine-before", stdout=quarantine_stat)
        add("exit1-volumes-before", stdout=volumes)
        add("exit1-dind-before", stdout=[dind_running])
        add("exit1-stop-private-dind", ["docker", "stop", DIND_NAME])
        add("exit1-dind-stopped", stdout=[dind_stopped])
        add("exit1-explicit-start-private-dind", ["docker", "start", DIND_NAME])
        add("exit1-dind-after", stdout=[dind_after])
        add("exit1-volumes-after", stdout=volumes)
        add("exit1-state-root-after", stdout=root_stat)
        add("exit1-quarantine-after", stdout=quarantine_stat)
        add("exit1-residual-after", ["stat", STATE + SOURCE[len("/state"):]], residual_stat)
        add("exit1-marker-stat-after", stdout=marker_stat)
        add("exit1-marker-content-after", stdout=oracle.MARKER_CONTENT)
        add("exit1-center-after", stdout=[final])
        add("exit1-status-after", stdout={"state": "exited", "containerId": CID,
                                          "imageId": QA_ID, "buildId": oracle.BUILD_ID,
                                          "exitCode": 1})
        for n, when in ((1, "2026-09-27T00:00:00+00:00"),
                        (2, "2026-09-27T00:00:05+00:00"),
                        (3, "2026-09-27T00:00:11+00:00")):
            add(f"exit1-observe-{n}", stdout=[final], started_utc=when)
        add("exit1-state-root-end", stdout=root_stat)
        add("exit1-quarantine-end", stdout=quarantine_stat)
        add("exit1-residual-end", ["stat", STATE + SOURCE[len("/state"):]], residual_stat)
        add("exit1-marker-stat-end", stdout=marker_stat)
        add("exit1-marker-content-end", stdout=oracle.MARKER_CONTENT)
        add("exit1-center-events-after", stdout="")
        add("exit1-outer-dind-events", stdout=(
            '{"Action":"die","Actor":{"ID":"' + DIND_ID + '"}}\n'
            '{"Action":"start","Actor":{"ID":"' + DIND_ID + '"}}\n'))
    cleanup = []
    for label in ("cleanup-final-list-container", "cleanup-final-list-volume",
                  "cleanup-final-list-network", "cleanup-inner-project-final-list",
                  "cleanup-inner-fixture-final-list", "cleanup-inner-all-final-list"):
        path = "raw/" + label + ".stdout"
        (run / path).write_bytes(b"")
        cleanup.append({"label": label, "stdout": path, "returncode": 0})
    evidence = {"commands": commands, "cleanup_commands": cleanup,
                "scenario": scenario, "center_id": CID, "qa_image_id": QA_ID,
                "contender_name": "selftest-contender", "artifact_manifest_sha256": oracle.I3_SHA,
                "inputs": {"image_id": oracle.ORIGINAL_ID, "build_id": oracle.BUILD_ID,
                           "host_manifest_sha256": "e" * 64, "sha256": sha,
                           "daemon_observe_seconds": 10},
                "expected": {"control": CONTROL, "state": STATE,
                             "image_id": oracle.ORIGINAL_ID, "inner_image_id": oracle.ORIGINAL_ID,
                             "dind": DIND_NAME},
                "midpoint": {"monotonic_ns": 132_000_000_000, "helper_pending": True,
                             "backup_pending": True, "backup_returncode": None},
                "release_monotonic_ns": 133_000_000_000,
                "term_observation": {"poll_label": "term-poll-1",
                                     "monotonic_ns": 100_500_000_000, "helper_pending": True},
                "event_start_utc": EVENT_START,
                "exit1_dind_id": DIND_ID,
                "exit1_residual_path": STATE + SOURCE[len("/state"):],
                "exit1_daemon_event_since": "2026-09-27T00:00:00+00:00",
                "exit1_observation_first_label": "exit1-observe-1",
                "exit1_observation_last_label": "exit1-observe-3",
                "exit1_observation_started_monotonic_ns": 200_000_000_000,
                "exit1_observation_finished_monotonic_ns": 211_000_000_000,
                "created": [["volume", name] for name in
                            ("selftest-private-data", "selftest-private-socket",
                             "selftest-private-daemon")],
                "run_id": RUN_ID,
                "armed_monotonic_ns": 99_000_000_000, "business_complete": True,
                "cleanup_complete": True, "cleanup_errors": []}
    (run / "evidence.json").write_text(json.dumps(evidence))
    return evidence


def check_mutation(scenario, name, change):
    with tempfile.TemporaryDirectory(dir=HERE, prefix=".selftest-") as directory:
        run = pathlib.Path(directory)
        evidence = fixture(run, scenario)
        if name == "positive":
            oracle.evaluate(run)
            return
        change(run, evidence)
        (run / "evidence.json").write_text(json.dumps(evidence))
        try:
            oracle.evaluate(run)
        except (KeyError, IndexError, ValueError, TypeError):
            return
        raise AssertionError(name + ": false success was accepted")


def mutate_raw(label, edit):
    def change(run, evidence):
        path = run / "raw" / (label + ".stdout")
        path.write_bytes(encoded(edit(json.loads(path.read_text()))))
    return change


def stale_term_window(_run, evidence):
    item = next(row for row in evidence["commands"] if row["label"] == "term-poll-1")
    item["argv"][item["argv"].index("--since") + 1] = "2020-01-01T00:00:00+00:00"


def early_unknown(_run, evidence):
    evidence["midpoint"].update(backup_pending=False, backup_returncode=1)


def early_completed(run, evidence):
    early_unknown(run, evidence)
    (run / "raw/backup-client.stdout").write_bytes(b'{"status":"completed"}\n')


def early_without_unknown(run, evidence):
    early_unknown(run, evidence)
    (run / "raw/backup-client.stderr").write_bytes(b"")


def early_success_code(run, evidence):
    early_unknown(run, evidence)
    evidence["midpoint"]["backup_returncode"] = 0
    next(row for row in evidence["commands"] if row["label"] == "backup-client")["returncode"] = 0


def main():
    cases = [
        ("wrong-center-id", mutate_raw("center-final", lambda a: [{**a[0], "Id": "f" * 64}])),
        ("short-hold", lambda _r, e: e["midpoint"].update(monotonic_ns=130_000_000_000)),
        ("late-term-after-helper-31s", lambda _r, e: e["term_observation"].update(
            monotonic_ns=131_000_000_000)),
        ("stale-term-window", stale_term_window),
        ("helper-finished-early", lambda _r, e: e["midpoint"].update(helper_pending=False)),
        ("early-client-completed", early_completed),
        ("early-client-without-unknown", early_without_unknown),
        ("early-client-success-code", early_success_code),
        ("released-before-check", lambda _r, e: e.update(release_monotonic_ns=131_000_000_000)),
        ("fd-released", lambda r, _e: (r / "raw/fd-readlink-after-31s.stdout").write_text("gone\n")),
        ("fd-inode-changed", lambda r, _e: (r / "raw/fd-stat-after-31s.stdout").write_text(
            "2048:999:10001:10001:600\n")),
        ("owner-released", mutate_raw("contender-final", lambda a: [{**a[0],
            "State": {"Status": "exited", "ExitCode": 0}}])),
        ("app-exit-wrong", mutate_raw("center-final", lambda a: [{**a[0],
            "State": {**a[0]["State"], "ExitCode": 42}}])),
        ("no-term", lambda r, _e: (r / "raw/center-events.stdout").write_text(
            '{"Action":"die","Actor":{"ID":"' + CID + '"}}\n')),
        ("cleanup-failed", lambda _r, e: e.update(cleanup_complete=False)),
        ("empty-helper-result", lambda r, _e: (r / "raw/stop-helper.stdout").write_bytes(b"")),
    ]
    checked = []
    for scenario in ("close-fail",):
        check_mutation(scenario, "positive", None)
        checked.append(scenario + ":positive")
        for name, change in cases:
            check_mutation(scenario, name, change)
            checked.append(scenario + ":" + name)
        check_mutation(scenario, "wrong-helper-clean", mutate_raw("stop-helper", lambda a:
                       {**a, "clean": True, "exitCode": 0}))
        checked.append(scenario + ":wrong-helper-clean")
        check_mutation(scenario, "wrong-helper-cli-code", lambda _r, e:
                       next(row for row in e["commands"] if row["label"] == "stop-helper").update(
                           returncode=0))
        checked.append(scenario + ":wrong-helper-cli-code")
    check_mutation("close-fail", "wrong-residual-inode", lambda r, _e:
                   (r / "raw/residual-stat.stdout").write_text("2048:999:10001:10001:600\n"))
    checked.append("close-fail:wrong-residual-inode")
    for name, file, contents in (
        ("marker-held-missing", "marker-content-held.stdout", b""),
        ("marker-final-content", "marker-content-final.stdout", b"tampered\n"),
        ("marker-mode", "marker-stat-final.stdout", b"regular file:2048:777:10001:10001:644:16\n"),
    ):
        check_mutation("close-fail", name, lambda r, _e, f=file, c=contents:
                       (r / "raw" / f).write_bytes(c))
        checked.append("close-fail:" + name)
    for name, change in (
        ("center-app0-after-daemon", mutate_raw("exit1-center-after", lambda a:
            [{**a[0], "State": {**a[0]["State"], "ExitCode": 0}}])),
        ("center-restarted-after-daemon", mutate_raw("exit1-center-after", lambda a:
            [{**a[0], "State": {**a[0]["State"], "StartedAt": "new-start"},
              "RestartCount": 1}])),
        ("dind-replaced", mutate_raw("exit1-dind-after", lambda a:
            [{**a[0], "Id": "8" * 64}])),
        ("volume-replaced", mutate_raw("exit1-volumes-after", lambda a:
            [{**a[0], "CreatedAt": "later"}, *a[1:]])),
        ("root-inode-changed", lambda r, _e: (r / "raw/exit1-state-root-after.stdout").write_text(
            "directory:2048:999:10001:10001:700\n")),
        ("root-stat-failed-with-stale-output", lambda _r, e: next(x for x in e["commands"]
            if x["label"] == "exit1-state-root-after").update(returncode=1)),
        ("residual-lost", lambda r, _e: (r / "raw/exit1-residual-end.stdout").write_bytes(b"")),
        ("marker-owner-changed", lambda r, _e: (r / "raw/exit1-marker-stat-end.stdout").write_text(
            "regular file:2048:777:0:0:600:16\n")),
        ("marker-content-changed", lambda r, _e: (r / "raw/exit1-marker-content-end.stdout").write_bytes(
            b"tampered\n")),
        ("marker-read-failed-with-stale-output", lambda _r, e: next(x for x in e["commands"]
            if x["label"] == "exit1-marker-content-after").update(returncode=1)),
        ("short-daemon-window", lambda _r, e: e.update(
            exit1_observation_finished_monotonic_ns=209_000_000_000)),
        ("late-sample-too-early", lambda _r, e: next(x for x in e["commands"]
            if x["label"] == "exit1-observe-3").update(
                started_utc="2026-09-27T00:00:09+00:00")),
        ("post-daemon-center-start", lambda r, _e: (r / "raw/exit1-center-events-after.stdout").write_text(
            '{"Action":"start","Actor":{"ID":"' + CID + '"}}\n')),
        ("extra-helper-start", lambda _r, e: e["commands"].append({
            "label": "unsanctioned-start", "argv": ["docker", "exec", "-e",
            "DOCKER_HOST=" + SOCKET, CONTROL, "/usr/local/libexec/omne-center", "start"],
            "returncode": 0})),
    ):
        check_mutation("close-fail", name, change)
        checked.append("close-fail:" + name)
    print(json.dumps({"status": "pass", "docker_executed": False,
                      "positive_scenarios": 1, "rejected_mutations": len(checked) - 1,
                      "cases": checked}, sort_keys=True))


if __name__ == "__main__":
    main()
