#!/usr/bin/env python3
"""Independent close-fail exit1 and private daemon restart raw oracle."""

import json
import pathlib
import re
import sys
from datetime import datetime

BUILD_ID = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
ORIGINAL_ID = "sha256:27c0665146265afefe39012aaea26bdae7499784eaaeb74aea712a6fcdfc03f2"
I3_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
SOURCE = re.compile(r"/state/backups/\.quarantine/export-[0-9a-f]{32}\Z")
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
SOCKET = "unix:///opt/omne-private-docker/docker.sock"
MARKER = "/var/lib/omne-tenancy/state/backups/.quarantine/.omne-isolated"
MARKER_CONTENT = b"omne-isolated/1\n"
MOUNT_FIELDS = frozenset(("Type", "Name", "Source", "Destination", "Driver",
                          "Mode", "RW", "Propagation"))


def demand(value, message):
    if not value:
        raise ValueError(message)


def private_mounts(mounts, names, label):
    demand(isinstance(mounts, list) and len(mounts) == len(names),
           label + ": private DinD mount count/shape")
    by_destination = {}
    for mount in mounts:
        demand(isinstance(mount, dict) and set(mount) == MOUNT_FIELDS,
               label + ": private DinD mount record shape")
        destination = mount["Destination"]
        demand(isinstance(destination, str) and destination in names
               and destination not in by_destination
               and mount["Type"] == "volume"
               and mount["Name"] == names[destination]
               and isinstance(mount["Source"], str) and mount["Source"].startswith("/")
               and isinstance(mount["Driver"], str) and bool(mount["Driver"])
               and isinstance(mount["Mode"], str)
               and mount["RW"] is True
               and isinstance(mount["Propagation"], str),
               label + ": private DinD mount destination/name/value")
        by_destination[destination] = mount
    demand(set(by_destination) == set(names), label + ": private DinD mount destination set")
    return by_destination


def single_object(raw, label):
    demand(raw.endswith(b"\n") and raw.count(b"\n") == 1, label + ": one JSON+LF required")
    result = json.loads(raw.decode("utf8"))
    demand(isinstance(result, dict), label + ": object required")
    return result


def json_lines(raw):
    values = []
    for line in raw.decode("utf8", "replace").splitlines():
        try:
            value = json.loads(line)
        except ValueError:
            continue
        if isinstance(value, dict):
            values.append(value)
    return values


def parse_stat(raw, label):
    parts = raw.decode("ascii", "strict").strip().split(":")
    demand(len(parts) == 5 and all(part.isdigit() for part in parts), label + ": bad stat")
    return tuple(map(int, parts))


def parse_marker_stat(raw, label):
    parts = raw.decode("ascii", "strict").strip().split(":")
    demand(len(parts) == 7 and parts[0] == "regular file" and
           all(part.isdigit() for part in parts[1:]), label + ": bad marker stat")
    return tuple(map(int, parts[1:]))


def evaluate(run):
    evidence = json.loads((run / "evidence.json").read_text())
    rows = evidence["commands"]
    commands = {row["label"]: row for row in rows}
    demand(len(commands) == len(rows), "duplicate command label")
    scenario = evidence["scenario"]
    demand(scenario == "close-fail" and
           evidence["inputs"]["daemon_observe_seconds"] >= 10,
           "only reviewed close-fail exit1 daemon scenario")
    demand(evidence["artifact_manifest_sha256"] == I3_SHA and
           evidence["inputs"]["build_id"] == BUILD_ID and
           evidence["inputs"]["image_id"] == ORIGINAL_ID,
           "not the reviewed I3 input")
    demand(evidence["business_complete"] is True, "business observation incomplete")
    demand(evidence["inputs"]["sha256"]["driver"] and
           evidence["inputs"]["sha256"]["oracle"], "missing tool freeze")
    import hashlib
    for name in ("driver.py", "base_driver.py", "oracle.py", "gate.mjs",
                 "inventory.mjs", "gate_availability.mjs", "i3-manifest.json"):
        expected = (I3_SHA if name == "i3-manifest.json" else
                    evidence["inputs"]["sha256"][name.removesuffix(".py").removesuffix(".mjs")])
        actual = hashlib.sha256((run / "inputs" / name).read_bytes()).hexdigest()
        demand(actual == expected, "frozen input changed: " + name)

    def row(label, code=0):
        item = commands[label]
        demand(item["returncode"] == code and item.get("observation_expired") is False,
               label + ": wrong CLI exit or incomplete observation")
        return item

    def raw(label, stream="stdout"):
        item = commands[label]
        path = run / item[stream]
        demand(path.is_file() and path.parent == run / "raw", label + ": missing raw " + stream)
        return path.read_bytes()

    def obj(label, code=0):
        row(label, code)
        return single_object(raw(label), label)

    def inspect(label, cid):
        row(label)
        data = json.loads(raw(label))
        demand(isinstance(data, list) and len(data) == 1 and data[0].get("Id") == cid,
               label + ": wrong exact Docker identity")
        return data[0]

    order = [item["label"] for item in rows]
    stages = ("original-inventory", "qa-inventory", "gate-availability", "validate", "start",
              "gate-ready", "center-before-stop", "held-before-arm", "arm-gate",
              "backup-client", "gate-held", "fd-readlink", "fd-stat", "stop-helper",
              "center-after-31s", "fd-readlink-after-31s", "fd-stat-after-31s",
              "contender-run", "contender-final", "release-gate", "center-final")
    demand(all(label in commands for label in stages) and
           [order.index(label) for label in stages] == sorted(order.index(label) for label in stages),
           "scenario order absent or changed")
    input_manifest = json.loads((run / "inputs/i3-manifest.json").read_text())
    demand(input_manifest["images"]["arm64"]["imageId"] == ORIGINAL_ID and
           input_manifest["archives"]["host"]["buildId"] == BUILD_ID,
           "frozen I3 manifest mismatch")
    original = obj("original-inventory")
    qa = obj("qa-inventory")
    demand(original == qa == {"status": "verified", "buildId": BUILD_ID,
                             "files": 2851, "links": 115,
                             "manifestSha256": evidence["inputs"]["host_manifest_sha256"],
                             "node": "v24.21.0"}, "full app inventory differs")
    qa_image = inspect("qa-image-inspect", evidence["qa_image_id"])
    demand(qa_image["Id"] != ORIGINAL_ID and
           qa_image["Config"]["Labels"].get("ai.nemori.omne.qa-fixture") == "maintenance-gate/r5" and
           "NODE_OPTIONS=--import=/probe/gate.mjs" in qa_image["Config"]["Env"],
           "QA-only preload boundary changed")
    gate = obj("gate-availability")
    demand(gate.get("status") == "pass" and gate.get("uid") == 10001 and
           gate.get("gid") == 10001 and gate.get("directory", {}).get("mode") == "755" and
           gate.get("file", {}).get("isFile") is True and
           gate.get("actualSha256") == evidence["inputs"]["sha256"]["gate"],
           "QA gate unreadable or wrong bytes")
    cid = evidence["center_id"]
    demand(isinstance(cid, str) and HEX64.fullmatch(cid), "center ID malformed")
    inner_original = evidence["expected"]["inner_image_id"]
    demand(evidence["expected"]["image_id"] == ORIGINAL_ID and
           isinstance(inner_original, str) and inner_original.startswith("sha256:") and
           HEX64.fullmatch(inner_original.removeprefix("sha256:")),
           "original image provenance missing")
    imported = inspect("inner-image-inspect", inner_original)
    outer = inspect("outer-product-image", ORIGINAL_ID)
    demand(imported["RootFS"]["Layers"] == outer["RootFS"]["Layers"] and
           imported["Config"]["Labels"].get("ai.nemori.omne.host-build-id") == BUILD_ID and
           "NODE_OPTIONS=--import=/probe/gate.mjs" not in imported["Config"]["Env"] and
           qa_image["RootFS"]["Layers"][:len(imported["RootFS"]["Layers"])] ==
           imported["RootFS"]["Layers"] and
           qa_image["Config"]["Entrypoint"] == imported["Config"]["Entrypoint"] and
           qa_image["Config"]["Cmd"] == imported["Config"]["Cmd"],
           "imported final I3 image differs from original")
    control = evidence["expected"]["control"]
    private = f"DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock"
    prefix = ["docker", "exec", "-e", private, control, "/usr/local/libexec/omne-center"]
    for label, action in (("validate", "validate"), ("start", "start"),
                          ("stop-helper", "stop"), ("backup-client", "backup")):
        demand(commands[label]["argv"][:len(prefix) + 1] == [*prefix, action],
               label + ": not official helper in private Linux control")
    demand(sum(1 for item in rows if item["argv"][:len(prefix) + 1] == [*prefix, "stop"]) == 1,
           "stop helper must be invoked once")
    started = obj("start")
    demand(started.get("containerId") == cid and started.get("state") == "running" and
           started.get("health") == "healthy" and started.get("buildId") == BUILD_ID and
           started.get("imageId") == evidence["qa_image_id"], "helper start did not identify QA center")
    before = inspect("center-before-stop", cid)
    middle = inspect("center-after-31s", cid)
    after = inspect("center-final", cid)
    demand(before["Image"] == middle["Image"] == after["Image"] == evidence["qa_image_id"],
           "center image changed during stop")
    demand(before["Config"]["StopSignal"] == "SIGTERM" and
           before["Config"]["StopTimeout"] == -1 and
           before["HostConfig"]["RestartPolicy"]["Name"] == "unless-stopped",
           "actual R5 stop/restart config absent")
    demand(before["State"]["Status"] == middle["State"]["Status"] == "running" and
           before["State"]["Pid"] == middle["State"]["Pid"] > 0 and
           before["State"]["StartedAt"] == middle["State"]["StartedAt"],
           "source process changed or exited during hold")
    demand(before["Config"]["User"] == "10001:10001", "actual app user")
    mount_before = next((m.get("Source") for m in before["Mounts"] if m.get("Destination") == "/state"), None)
    demand(mount_before == evidence["expected"]["state"], "actual state mount differs")
    ready = obj("gate-ready")
    held = obj("gate-held")
    demand(ready == {"stage": "ready", "mode": scenario, "pid": 1, "armed": False} and
           held.get("stage") == ("write" if scenario == "write-hold" else "close") and
           held.get("pid") == 1 and type(held.get("fd")) is int and held["fd"] >= 0 and
           isinstance(held.get("path"), str) and SOURCE.fullmatch(held["path"]),
           "gate did not reach intended real FileHandle")
    row("held-before-arm")
    descriptor = f"/proc/1/fd/{held['fd']}"
    for suffix in ("", "-after-31s"):
        target_label = "fd-readlink" + suffix
        stat_label = "fd-stat" + suffix
        demand(row(target_label)["argv"][-1] == descriptor and
               raw(target_label).decode().strip() == held["path"], target_label + ": FD target changed")
        observed = parse_stat(raw(stat_label), stat_label)
        demand(row(stat_label)["argv"][-1] == descriptor and
               observed == (held["dev"], held["ino"], 10001, 10001, 600),
               stat_label + ": FD inode/owner/mode changed")
    stop = row("stop-helper", 0 if scenario == "write-hold" else 1)
    midpoint = evidence["midpoint"]
    term = evidence["term_observation"]
    term_label = term["poll_label"]
    term_row = row(term_label)
    demand(order.index("stop-helper") < order.index(term_label) < order.index("center-after-31s") and
           term_row["argv"][:7] == ["docker", "exec", control, "docker", "--host",
                                     SOCKET, "events"] and
           f"container={cid}" in term_row["argv"] and "event=kill" in term_row["argv"] and
           "--since" in term_row["argv"] and
           term_row["argv"][term_row["argv"].index("--since") + 1] == evidence["event_start_utc"] and
           "--until" in term_row["argv"],
           "TERM poll was not an exact private Engine query")
    term_events = [json.loads(line) for line in raw(term_label).splitlines()]
    demand(len(term_events) == 1 and term_events[0].get("Action") == "kill" and
           term_events[0].get("Actor", {}).get("ID") == cid and
           term_events[0].get("Actor", {}).get("Attributes", {}).get("signal")
           in ("15", "SIGTERM"), "TERM not observed before hold anchor")
    demand(term["monotonic_ns"] >= stop["started_monotonic_ns"] and
           term["helper_pending"] is True and
           midpoint["monotonic_ns"] - term["monotonic_ns"] > 31_000_000_000 and
           midpoint["helper_pending"] is True and
           evidence["release_monotonic_ns"] > midpoint["monotonic_ns"],
           "helper/source hold did not remain pending >31 s after observed TERM")
    client_at_midpoint = midpoint["backup_returncode"]
    demand((client_at_midpoint is None and midpoint["backup_pending"] is True) or
           (type(client_at_midpoint) is int and midpoint["backup_pending"] is False and
            client_at_midpoint == commands["backup-client"]["returncode"]),
           "backup client midpoint state contradicts its observed exit")
    if client_at_midpoint is not None:
        client_stdout = raw("backup-client")
        client_stderr = raw("backup-client", "stderr")
        explicit_unknown = (client_stdout == b"" and b"ops result unconfirmed" in client_stderr)
        if not explicit_unknown:
            try:
                result = single_object(client_stdout, "backup-client")
            except (ValueError, UnicodeError, json.JSONDecodeError):
                result = {}
            explicit_unknown = result.get("status") == "outcome-unknown"
        demand(client_at_midpoint == 1 and explicit_unknown and
               not any(value.get("status") == "completed" for value in json_lines(client_stdout)),
               "early backup client exit falsely claims a completed result")
    demand(row("release-gate")["argv"][-1] == "/var/lib/omne-tenancy/state/qa/release" and
           row("gate-release-present"), "gate release not observed")
    row("contender-final")
    contender_array = json.loads(raw("contender-final"))
    demand(isinstance(contender_array, list) and len(contender_array) == 1,
           "contender inspect shape")
    contender = contender_array[0]
    demand(contender.get("Id") != cid and
           contender.get("Name") == "/" + evidence["contender_name"] and
           commands["contender-final"]["argv"][-1] == evidence["contender_name"],
           "contender inspect wrong identity")
    contender_run = row("contender-run", 1)
    contender_mount = next((m.get("Source") for m in contender["Mounts"]
                            if m.get("Destination") == "/state"), None)
    demand(contender["Image"] == inner_original and contender_mount == mount_before and
           contender["State"]["Status"] == "exited" and
           contender["State"]["ExitCode"] == 1 and
           any(item.get("stage") == "occupied" for item in json_lines(raw("contender-run", "stderr"))),
           "real second source owner was not rejected")
    demand(contender_run["argv"][-2:] == [inner_original, "serve"],
           "contender did not use original image")
    expected_exit = 0 if scenario == "write-hold" else 1
    result = single_object(raw("stop-helper"), "stop-helper")
    demand(result == {"state": "stopped" if expected_exit == 0 else "stopped-with-error",
                      "containerId": cid, "exitCode": expected_exit,
                      "clean": expected_exit == 0},
           "helper confused Docker CLI exit with application result")
    demand(after["State"]["Status"] == "exited" and after["State"]["Running"] is False and
           after["State"]["ExitCode"] == expected_exit and
           after["State"]["StartedAt"] == before["State"]["StartedAt"],
           "same center actual exit differs or restarted")
    backup = commands["backup-client"]
    demand(backup["returncode"] == 1 and backup["observation_expired"] is False and
           not any(value.get("status") == "completed" for value in json_lines(raw("backup-client"))),
           "backup client falsely reported success")
    held_logs = raw("center-logs-held") + raw("center-logs-held", "stderr")
    demand(any(value.get("event") == "still-stopping" for value in json_lines(held_logs)),
           "real host did not report continued stopping")
    final_logs = raw("center-logs-final") + raw("center-logs-final", "stderr")
    if scenario == "close-fail":
        residual = row("residual-stat")
        expected_path = evidence["expected"]["state"] + held["path"][len("/state"):]
        demand(residual["argv"][-1] == expected_path and
               parse_stat(raw("residual-stat"), "residual-stat") ==
               (held["dev"], held["ino"], 10001, 10001, 600),
               "close EIO residual not the same protected inode")
        demand(order.index("center-after-31s") < order.index("marker-stat-held") <
               order.index("marker-content-held") < order.index("release-gate") <
               order.index("center-final") < order.index("marker-stat-final") <
               order.index("marker-content-final"),
               "protection marker was not checked while held and after exit")
        markers = []
        for suffix in ("held", "final"):
            stat_label = "marker-stat-" + suffix
            content_label = "marker-content-" + suffix
            demand(row(stat_label)["argv"][-1] == MARKER and
                   row(content_label)["argv"][-1] == MARKER and
                   raw(content_label) == MARKER_CONTENT,
                   suffix + ": real workRoot marker path/content mismatch")
            observed = parse_marker_stat(raw(stat_label), stat_label)
            demand(observed[2:] == (10001, 10001, 600, len(MARKER_CONTENT)),
                   suffix + ": marker owner/mode/length mismatch")
            markers.append(observed)
        demand(markers[0] == markers[1], "permanent marker replaced before process exit")
        demand(b"maintenance-residual" in final_logs and held["path"].encode() in final_logs and
               any(item.get("event") == "dispose-incomplete" and item.get("controller") == "error"
                   for item in json_lines(final_logs)) and
               any(item.get("event") == "disposed" and item.get("complete") is False
                   for item in json_lines(final_logs)) and
               not any(item.get("event") == "disposed" and item.get("complete") is True
                       for item in json_lines(final_logs)), "close error reported clean or residual hidden")
    events_row = row("center-events")
    demand(f"container={cid}" in events_row["argv"] and
           "--since" in events_row["argv"] and
           events_row["argv"][events_row["argv"].index("--since") + 1] ==
           evidence["event_start_utc"], "events did not target stop window/exact center")
    events = [json.loads(line) for line in raw("center-events").splitlines()]
    demand(events and all(event.get("Actor", {}).get("ID") == cid for event in events),
           "Engine event wrong center ID")
    kills = [event for event in events if event.get("Action") == "kill"]
    demand(len(kills) == 1 and kills[0].get("Actor", {}).get("Attributes", {}).get("signal")
           in ("15", "SIGTERM") and
           not any(event.get("Action") == "start" for event in events),
           "missing, duplicated or wrong TERM / restarted center")
    # All following observations occur only after the formal helper's
    # stopped-with-error/app1 and the original marker/residual checks above.
    extra = ("exit1-state-root-before", "exit1-quarantine-before",
             "exit1-volumes-before", "exit1-dind-before", "exit1-stop-private-dind",
             "exit1-dind-stopped", "exit1-explicit-start-private-dind",
             "exit1-dind-after", "exit1-volumes-after", "exit1-state-root-after",
             "exit1-quarantine-after", "exit1-residual-after",
             "exit1-marker-stat-after", "exit1-marker-content-after",
             "exit1-center-after", "exit1-status-after",
             "exit1-state-root-end", "exit1-quarantine-end", "exit1-residual-end",
             "exit1-marker-stat-end", "exit1-marker-content-end",
             "exit1-center-events-after", "exit1-outer-dind-events")
    demand(all(label in commands for label in extra) and
           [order.index(label) for label in extra] ==
           sorted(order.index(label) for label in extra) and
           order.index("marker-content-final") < order.index("exit1-dind-before"),
           "exit1 daemon/residual observation order")
    for label in extra:
        row(label)
    demand(sum(1 for item in rows if item["argv"][:len(prefix) + 1] ==
               [*prefix, "start"]) == 1,
           "fixture reopened center after exit1")
    dind_id = evidence["exit1_dind_id"]
    demand(isinstance(dind_id, str) and HEX64.fullmatch(dind_id),
           "private DinD ID malformed")
    dind_before = inspect("exit1-dind-before", dind_id)
    dind_stopped = inspect("exit1-dind-stopped", dind_id)
    dind_after = inspect("exit1-dind-after", dind_id)
    volume_names = [entry[1] for entry in evidence["created"] if entry[0] == "volume"]
    demand(len(volume_names) == 3 and len(set(volume_names)) == 3,
           "private metadata/state/socket volume set")
    mount_names = dict(zip(("/var/lib/omne-tenancy", "/opt/omne-private-docker",
                            "/var/lib/docker"), volume_names))
    before_mounts = private_mounts(dind_before["Mounts"], mount_names, "exit1-dind-before")
    stopped_mounts = private_mounts(dind_stopped["Mounts"], mount_names,
                                    "exit1-dind-stopped")
    after_mounts = private_mounts(dind_after["Mounts"], mount_names, "exit1-dind-after")
    demand(dind_before["State"]["Status"] == "running"
           and dind_stopped["State"]["Status"] == "exited"
           and dind_after["State"]["Status"] == "running"
           and dind_stopped["State"]["StartedAt"] ==
               dind_before["State"]["StartedAt"]
           and dind_after["State"]["StartedAt"] !=
               dind_before["State"]["StartedAt"]
           and before_mounts == stopped_mounts == after_mounts
           and dind_before["Config"]["Labels"].get("omne.r5.helper-prep") ==
               evidence["run_id"],
           "private DinD ID/config/volumes did not survive explicit restart")
    demand(row("exit1-stop-private-dind")["argv"] ==
           ["docker", "stop", evidence["expected"]["dind"]]
           and row("exit1-explicit-start-private-dind")["argv"] ==
               ["docker", "start", evidence["expected"]["dind"]],
           "only this exact private DinD may be stopped/restarted")
    expected_volumes = set(volume_names)
    demand(len(expected_volumes) == 3, "private metadata/state/socket volume set")
    volume_views = []
    for label in ("exit1-volumes-before", "exit1-volumes-after"):
        row(label)
        data = json.loads(raw(label))
        demand(isinstance(data, list) and len(data) == 3 and
               {v["Name"] for v in data} == expected_volumes,
               label + ": private volume identity")
        volume_views.append({v["Name"]: {k: v.get(k) for k in
                             ("CreatedAt", "Mountpoint", "Driver", "Scope", "Labels")}
                             for v in data})
    demand(volume_views[0] == volume_views[1] and all(
           value["CreatedAt"] and value["Mountpoint"] and
           value["Labels"].get("omne.r5.helper-prep") == evidence["run_id"]
           for value in volume_views[0].values()),
           "private metadata/state/socket volume recreated or relabelled")
    for stem, expected_owner in (("exit1-state-root", "10001:10001:700"),
                                 ("exit1-quarantine", "10001:10001:700")):
        views = [raw(stem + "-" + suffix) for suffix in ("before", "after", "end")]
        demand(views[0] == views[1] == views[2] and
               re.fullmatch(rb"directory:[1-9][0-9]*:[1-9][0-9]*:" +
                            expected_owner.encode() + rb"\n", views[0]),
               stem + ": root directory owner/mode/dev/inode changed")
    residual_path = evidence["exit1_residual_path"]
    demand(residual_path == evidence["expected"]["state"] +
           held["path"][len("/state"):] and
           all(row(label)["argv"][-1] == residual_path for label in
               ("exit1-residual-after", "exit1-residual-end")),
           "residual path changed")
    original_residual = parse_stat(raw("residual-stat"), "residual-stat")
    demand(original_residual == (held["dev"], held["ino"], 10001, 10001, 600)
           and all(parse_stat(raw(label), label) == original_residual for label in
                   ("exit1-residual-after", "exit1-residual-end")),
           "actual close-fail residual lost or changed after daemon restart")
    original_marker = parse_marker_stat(raw("marker-stat-final"), "marker-stat-final")
    demand(all(parse_marker_stat(raw(label), label) == original_marker for label in
               ("exit1-marker-stat-after", "exit1-marker-stat-end")) and
           all(raw(label) == MARKER_CONTENT for label in
               ("exit1-marker-content-after", "exit1-marker-content-end")),
           "permanent isolation marker lost/replaced across private daemon")
    center_after = inspect("exit1-center-after", cid)
    demand(center_after["State"]["Status"] == "exited"
           and center_after["State"]["Running"] is False
           and center_after["State"]["ExitCode"] == 1
           and center_after["State"]["StartedAt"] == after["State"]["StartedAt"]
           and center_after["RestartCount"] == after["RestartCount"]
           and center_after["Image"] == after["Image"],
           "original center revived/replaced after private daemon recovery")
    status_after = obj("exit1-status-after")
    demand(status_after["state"] == "exited" and status_after["exitCode"] == 1
           and status_after["containerId"] == cid
           and status_after["imageId"] == evidence["qa_image_id"]
           and status_after["buildId"] == BUILD_ID,
           "helper status masked exact exited1 center")
    observe_labels = [label for label in order if re.fullmatch(r"exit1-observe-[1-9][0-9]*", label)]
    first_label = evidence["exit1_observation_first_label"]
    last_label = evidence["exit1_observation_last_label"]
    budget = evidence["inputs"]["daemon_observe_seconds"]
    demand(len(observe_labels) >= 3 and observe_labels[0] == first_label
           and observe_labels[-1] == last_label and
           [int(label.rsplit("-", 1)[-1]) for label in observe_labels] ==
           list(range(1, len(observe_labels) + 1)),
           "finite exited1 observations missing")
    for label in observe_labels:
        sample = inspect(label, cid)
        demand(sample["State"]["Status"] == "exited"
               and sample["State"]["Running"] is False
               and sample["State"]["ExitCode"] == 1
               and sample["State"]["StartedAt"] == after["State"]["StartedAt"]
               and sample["RestartCount"] == after["RestartCount"]
               and sample["Image"] == after["Image"],
               label + ": center restarted in finite post-daemon window")
    first_utc = datetime.fromisoformat(commands[first_label]["started_utc"])
    last_utc = datetime.fromisoformat(commands[last_label]["started_utc"])
    demand((last_utc - first_utc).total_seconds() >= budget and
           evidence["exit1_observation_finished_monotonic_ns"] -
           evidence["exit1_observation_started_monotonic_ns"] >=
           budget * 1_000_000_000,
           "actual same-ID observation span under requested 10 seconds")
    row("exit1-center-events-after")
    later_events = [json.loads(line) for line in raw("exit1-center-events-after").splitlines()]
    demand(all(event.get("Actor", {}).get("ID") == cid for event in later_events) and
           not any(event.get("Action") in ("start", "restart") for event in later_events),
           "private Engine recorded center start after explicit daemon restart")
    row("exit1-outer-dind-events")
    dind_events = [json.loads(line) for line in raw("exit1-outer-dind-events").splitlines()]
    demand(dind_events and all(event.get("Actor", {}).get("ID") == dind_id
                               for event in dind_events) and
           sum(event.get("Action") == "start" for event in dind_events) == 1,
           "private DinD was not explicitly restarted exactly once")
    demand(evidence["cleanup_complete"] is True and evidence["cleanup_errors"] == [],
           "fixture resources not fully cleaned")
    cleanup = {item["label"]: item for item in evidence["cleanup_commands"]}
    demand(len(cleanup) == len(evidence["cleanup_commands"]), "duplicate cleanup label")
    for kind in ("container", "volume", "network"):
        label = "cleanup-final-list-" + kind
        demand(cleanup[label]["returncode"] == 0 and (run / cleanup[label]["stdout"]).read_bytes() == b"",
               label + ": exact-label resources remain")
    for group in ("project", "fixture", "all"):
        label = "cleanup-inner-" + group + "-final-list"
        demand(cleanup[label]["returncode"] == 0 and (run / cleanup[label]["stdout"]).read_bytes() == b"",
               label + ": private Engine resources remain")
    return {"status": "limited_pass", "scenario": "close-fail-exit1-daemon",
            "containerId": cid, "appExit": 1,
            "daemonObserveSeconds": budget, "checks": 26}


def main():
    if len(sys.argv) != 2:
        print("usage: oracle.py <run-directory>", file=sys.stderr)
        return 64
    try:
        result = evaluate(pathlib.Path(sys.argv[1]))
    except (OSError, KeyError, IndexError, ValueError, TypeError, UnicodeError, json.JSONDecodeError) as error:
        result = {"status": "unverified", "error": f"{type(error).__name__}: {error}"}
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] == "limited_pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
