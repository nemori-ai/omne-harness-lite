from pathlib import Path
import json, importlib.util, tarfile, hashlib, subprocess, sys

root = Path.cwd()
base = Path(__file__).resolve().parent
p = root / '.meta_harness/tooling/src/realization_nodes.py'
sys.path.insert(0, str(p.parent))
s = importlib.util.spec_from_file_location('realization_nodes', p)
m = importlib.util.module_from_spec(s)
sys.modules[s.name] = m
s.loader.exec_module(m)
c = m.Checker(root / '.meta_harness/design')
c.load()
selected = [n for n in c.nodes if n.name in ('model-request-runtime', 'pi-ai-transport')]
for n in selected:
    c.check_entry(n)
    c.check_architecture(n)
    c.check_bindings(n)
    c.check_links(n)
result = {'nodes': [n.name for n in selected], 'checks': ['entry', 'architecture', 'bindings', 'links'], 'errors': c.errors, 'notes': c.notes}
(base / 'scoped-check.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
assert len(selected) == 2 and not c.errors
files = [root / '.meta_harness/design/record/evidence/2026-09-27-tests-model-request-runtime-boundaries/README.md', root / '.meta_harness/design/record/evidence/README.md']
for n in selected:
    files.extend(f for f in n.path.iterdir() if f.is_file())
hashes = {str(f.relative_to(root)): hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
(base / 'input-hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
cmd = ['.venv/bin/python', '.meta_harness/tooling/src/check_design.py', '--root', '.meta_harness/design', '--formal', 'skip', '--gate', 'internal']
with (base / 'design-check.stdout').open('w') as out, (base / 'design-check.stderr').open('w') as err:
    r = subprocess.run(cmd, cwd=root, stdout=out, stderr=err, timeout=60)
(base / 'command-result.json').write_text(json.dumps({'argv': cmd, 'cwd': str(root), 'exitCode': r.returncode, 'formalTasksExecuted': 0}, indent=2) + '\n')
assert r.returncode == 0
run = root / '.meta_harness/design/record/evidence/2026-09-27-tests-model-request-runtime-boundaries'
a = run / 'final-mapping-check.tar.gz'
with tarfile.open(a, 'x:gz') as tar:
    tar.add(base, arcname='mapping-check')
with tarfile.open(a, 'r:gz') as tar:
    for f in base.iterdir():
        assert tar.extractfile('mapping-check/' + f.name).read() == f.read_bytes()
print(json.dumps({'archive': str(a.relative_to(root)), 'sha256': hashlib.sha256(a.read_bytes()).hexdigest(), 'bytes': a.stat().st_size, 'readback': True}))
