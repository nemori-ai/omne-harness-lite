## 2026-09-26 当前3形式运行已归档

`record/evidence/2026-09-26-formal-core-v3` 完整归档实际模型/变异、631文件、630源SHA与1.3MB可读回原始封包；32接受资源、40输入、三工具SHA、263主Alloy+28 XML由主调度独立核读，spec-reviewer对应性无阻断。SA两条当前3正式模型binding已登记，仅限有限P1/P7，不把旧raw1/alias2重标3或签收实现。三份形式模型运行不是W6两真实链，后者仍待完整source。

## 2026-09-26 当前依赖试点已释放

HUB `eabfff0f` 已独立完成默认3/完整旧2公开Schema固定图（AM3全25定义、六保留2消费者全定义）、坏名CB3接纳/TD3拒绝分支和实际27源码规则；检查器299用例通过。SA／AE／AR／W6已按此精确源获准同步自身spoke继续。原消费者寻址、旧AR dist和本机命令／精确规则阻断日志保留，见 `D068-dependency-pilot-HUB-release.json`。这只是依赖试点，不是六数据全部义务签收，也不是W6/最终接受；当前矩阵0cdc74ec、原327/本阶段221范围不变。

# Core 完整交付与自主验收方案

## 当前：D-068规格已接受，八提供者采用实施中

独立R2/R3复审无阻断，主调度在3fab9200接受并冻结八份3的32资源；旧319摘要不改。八个realization设计显式采用3，当前实现仍须耦合升级、Schema/v2原字节公开、保留2消费者固定闭包、实际AR等同性和W6回归。矩阵原327/221scope不变；八节点旧2签收保留原epoch，当前3统一待复验，不自动翻PASS。备份acceptance-matrix.before-D068-adoption.json完整保留旧字节。

## 2026-09-26 D-068：规格一致性前置修订（范围沿革）

冻结 SA2 的两项示例 oracle 与表示优先矛盾，CB2 的工具名 Schema 与既有 D060 N32 的未解析封口表示矛盾。具体反例和技术采用范围归 `.meta_harness/design/record/decisions/core-implementation-spec-reconciliation/`；不改旧冻结2，不删旧测试预期，不将错误输出视作符合。

新增收口节奏：八份 v3 候选（CB、Messages、MR、Loop、TD、AM；SA、AE）→独立 spec-reviewer 复核完整批次→主调度技术接受与冻结→显式升级这八个 core 提供者及实际依赖资源→HUB 受影响回归→W6 真实组合与逐ID签收。候选未接受前只暂停两个示例和非法名字封口依赖分支，其他实施继续。AR／CA／MP／Skill／MCP／Slash 保持2，旧完整 Schema 经精确 `schema/v2` 提供；不能以新版资源冒充旧$id。运行时仍pin2的消费者登记 affected／未迁移，不算本阶段交付。

该修订不改变 215 active core＋6 mixed 当前部分（共221项，U1另计），也不扩大 Connector 延期。AE2 的完整 NonConnector 实施已合，当前17／18 core已有源码，Stream 尚待完整 release。AE2／AR2／MR2等旧证据的固定矩阵、计划和版本不变；当前执行矩阵因 SA 资源审计模板纠错更新，修前字节完整保存在 `acceptance-matrix.before-SA-resource-audit-correction.json`。SA 不发布自己的 Schema，该项核对八份规范资源与真实依赖闭包，不能空集通过。

本地 main127d63da 完整包含 origin/main2cb236db；HUB已包含main，最近fetch未见新增。HUB后续提交以前置检查和实际基线为准。本段接续下文历史记录，不把历史测试重标为v3或将人的总体门提前签收。

## 2026-09-26 MR 执行审计纠错（当前）

独立 spec-reviewer 核实后，主调度将 `model-response.predispatch-exclusion` 的整条执行责任改归 external：S-16 允许其形状，V-5/S-26 的不写入由实际运行时与日志负责，不能通过公开 Schema 或 judge 增加拒绝。`model-response.route-copy` 保留本地 Route/ParameterAdjustment 形状及完整六处 Schema 复制对齐；与实际请求/发出的事实对应归现有 `model-response.request-runtime`（V-6/V-9）。这是原审计错误的纠正，不是新延期或新产品政策。

当前计数为 **305 active＝185 local＋30 composition＋90 external；6 mixed 当前部分＝4 local＋2 composition；16 Connector deferred 不变**。本阶段为 **215 条 active core 义务＋6 条 mixed 的当前部分**，另有 U1。原327审计、原字段与证据全部保留，当前规范来源已逐行采用 D-066 对应资源；本次更正不新增 PASS。报告 `MR-executing-audit-correction.json`、修前快照 `acceptance-matrix.before-MR-audit-correction.json`。

## 当前施工基线（2026-09-26 上游同步后）

本地 main `127d63da` 已含远程 main `2cb236db` 与本轮 W0 两个独立提交；HUB `b4bb63e3` 已合该 main，并通过合并后的构建、类型、16 个已实现 core 包、2 util、验证工具、26 条实际源码规则及格式门。主调度合并使用 merge 保全提交与证据，未改写历史。旧基线与原327项审计继续作为历史输入保留。

当前采用按 D-066：十二个 PR9 数据 core 包及两个能力 core 节点采用 v2；Connector 数据 v2仅行政登记，实施仍延期。identity-values 仍 v1。OE 主包为上游已接受的 v2（declined、timingFrom可区分不可用），原精确 OE1 Schema 经 ./schema/v1 公开供既有 v2 资源图引用，不用 OE2 冒充 OE1。Storage 的共同事务、维护、显式测试运行器来自上游已接受技术设计，也纳入当前公开面验证。

当前 D-061/D-062/D-065 是原PR9 D-041/D-042/D-045的坐标；本轮 formatter 决定登记D-067，上游治理D-046不动。baseline-frozen.json、327审计、旧日志与旧签收不可覆盖成新版本运行；原矩阵备份 acceptance-matrix.before-D066.json，新矩阵 input_coordinate 采用现行坐标，original_input_coordinate/technical_acceptance保留原事实。详细证据 upstream-sync-verification.json。50项历史W1技术签收不自动证明新版实现，当前 per-ID 重核及 W6 两条真实组合仍要完成。

总体门中的“冻结 hash 不变”指相对本次明确采用的现行冻结清单无未经授权改写，D-066登记的源到目标摘要分别核对；不是要求行政迁移后字节等于旧v1。非core源码限制相对同步后的main评估，上游已交付其他领域不计成本轮新增。下一 spoke 从已绿、已同步HUB切出。

下文的原基线日期、W0和施工过程保留为历史记录，采用状态以本段与执行矩阵为准。

状态：执行中；本稿由用户于 2026-09-26 授权实施。初始基线 main `bb3d8bc4`。

## 阅读与权威

执行仓库 `/data/qiwei/repos/omne-harness-lite`。HUB 为 `.worktrees/core-delivery`，分支 `panqiwei/core-delivery`；主检出保持 main。
本文是一次交付的计划和进度，不定义第二份产品或规格权威。设计输入均从 HUB 的 `.meta_harness/design/` 读取。
原始计划覆盖 `realization/packages/core/` 全部 19 个节点；按用户 2026-09-26 的最新要求，Connector 整块从本阶段移出，当前为除 Connector 之外 18 个 core 节点的交付；AM／AE 只延期 Connector 那一类正文／相关组合，其他资产类型完整交付。采用版本按 `registry/catalog.json`，冻结原件按 `registry/frozen.json`。
每个包的设计、接口和证据义务分别从相应节点 `README.md`、`design.md`、`verification.md` 读取。

## 范围

- 原计划产品源码范围为 `packages/core/`，交付已有四包的覆盖补齐和十五个新包。最新范围排除 `packages/core/connector` 及 Connector 相关实现／接入／组合验证：该整块去留与新产品设计尚在商榷，不先花实施成本，不开占位包。用户执行中追加 `packages/util/unix-format` 与 `packages/util/xml-format`（来源树实际名字，用户消息写作 xml-mformat），作为并行 U1 增量。timeout/brand 按实际需要由主调度决定是否复用，不自动引入。
- 允许为 core 配套修改开发工具、workspace 配置、开发说明、实现映射和证据。
- W0 developer roles 检查和必要强化直接提交 main，作为独立前置交付，HUB 立即同步。
- 不实现 infra/领域插件、会话日志、模型或工具运行时、应用装配；不做真实 OpenRouter 调用。
- 冻结规格不修改；显式缺口按既定结果实现，不补造规则。阶段外义务记录 owner、前提和后续验收条件。
- 产品源码只进入上述 core 及明确追加的 util 包；其他领域/infra源码不改。跨包验证开发成员为 `tools/core-verification`，不会让 core 产品反向依赖 infra。

## Connector 延期的依赖边界（用户最新要求，2026-09-26）

- 已停止刚启动的 Connector spoke；未产生产品源码。环境日志先保全，再退休，不合入空包或伪实现。
- 不修改其冻结契约，也不宣布旧设计已被新产品设计取代；现行输入仍留档可读，实施授权本轮明确排除该整块。
- AM 已有类别／声明联合与通用端口护栏保留；不开发 Connector 正文实现，不用 mock 关闭六真实正文的组合义务。
- 用户进一步明确仅 Connector 一种资产纵线延期，其他资产类型完整实施与交付。此前将 AE 全操作延期的口径过宽，现纠正：`evaluate`、`readWorkspaceCarrier`、S-23 三构件、整输入指纹均继续，针对已提供的其他资产类型完整兑现冻结语义；默认装配只绑定五个真实正文，不造 Connector 替身、不宣称六齐全。未提供的 Connector 用明确技术可用性边界承载，类型／运行边界及消费者范围经独立架构复审细化，不重写其他类型产品政策。
- 原完整 `BodyContracts` 的六真实键承诺保留；本阶段装配公开准确的五提供者可用性，不靠空规则／伪 Schema 补 Connector。涉及未提供正文的调用明确不是已交付路径；其他资产类型的相同输入仍按已接受规则给相同结果。冻结类型里的 Connector 名称不代表该领域已实现。
- 验收原始 327 项审计不改；执行矩阵新增范围处置及延期原因，留原条款、原 stage 与未闭合事实。独立 plan-review 已核原依赖；用户进一步明确仅Connector纵线延期后，恢复所有非Connector真实组合与工作区完整域。六项含Connector正文／六真实端口的义务单列当前与延期部分，其余具名资产走查完整继续；最新矩阵再次只读复审，AE不虚构Schema。拆分项本阶段证据与签收单列，不签原整条。总体接受只针对修订后实际交付范围，不能签掉延期项。

## W0-A：developer roles

对象：kernel-developer、capability-developer、infrastructure-developer、application-developer、verification-developer。
首先核对已有共享约束，不重复五份正文。必要修改归 canonical `agents/roles/developer-contract.md`、`developer-task.md` 及所属验证；生成两端配置，不直接编辑宿主产物，不换模型或权限。

必须覆盖：

1. 任务输入明确 design workspace、可读的精确技术规格与接受依据、相关 realization 文档/版本/公开面/责任范围；不能只交产品描述或包名。
2. 实际读取 spec、Schema、realization 与 verification，核对版本/边界/前提；不假定继承主会话知识。
3. 实现、错误、状态与测试预期受已接受规格约束；源码、第三方行为或便利不能倒改契约，fixture 不补造政策。
4. 缺项或冲突报告具体条款和受阻动作，暂停依赖部分；规格内普通缺陷自主修复。
5. 已选采用决定继续约束；未定技术栈/依赖允许自主调研或采用派发者提供方案，核对版本、许可和适配证据，新增依赖由明确 owner 更新锁。
6. 交付逐项对应验收并给出条款与证据；kernel/storage 等无独立契约时引用其已接受协议设计，不造坐标。

验收：生成一致、docs 和受影响工具测试通过；用生成后完整角色提示独立试用，观察缺 spec、缺 realization、规格与源码冲突、技术栈未定、恢复后版本变化五类实际动作。主调度审核并提交 main。静态检查与行为试用分别记录，提示不能被说成机器权限隔离。

## W0-B：环境与任务输入

- HUB/每个 spoke 使用自己的 uv/pnpm 环境，按锁安装；记录 make check 基线。
- 新 spoke 从已同步且关卡通过的 HUB 分支切出，在主检出 `.worktrees/` 同级放置，命名 `core-delivery-<任务>`。
- 派发首步为 cd 到绝对路径并核对 branch/status；主调度独立核对提交落点。
- 原19包（当前交付18包，Connector延期）验收矩阵由 `acceptance-matrix.json` 保存来源和状态。每项条款→入口→证据→owner→闭合时点，最终逐项签收。
- 核对已有 evidence 输入 hash/适用范围，尤其 asset-evaluation 的 Alloy 原始输出已存在，不机械补跑。
- YAML、regexpp、Ajv 与严格 base64 的核验是实施前置，核不过仅暂停相关消费者，不新增人工审批。

## 波次与依赖

| 波 | 包 | 内部释放/阶段后置项 |
|---|---|---|
| W1 | identity-values、offer-expiry、kernel-basis、storage；随后 content-blocks | 四包缺口与所需公共面先释放；content-blocks 为严格 JSON/Schema/公开入口试点，合回并验证后才复制模式 |
| W2 | asset-model、model-profile；随后 call-accounts | call-accounts 依赖 asset-model，不能全并行；asset-model 基础端口先释放；六正文装配因 Connector 明确延期，本地端口护栏仍验 |
| W3 | tool-definition、messages | 工具 Schema、消息前缀判定、拒绝顺序与类型接口 |
| W4 | loop-extension、skill-package、mcp-endpoint | 三包正文端口、推出规则、解析、具名拒绝；Connector 整块延期，不以替身补齐 |
| W5 | arrival-events、model-response、slash-command | 严格 base64、响应副本和精度、命令语法展开 |
| W6 | stream-assembly、asset-evaluation（除 Connector 纵线） | 五个真实正文→AM→AE 完整求值／工作区读入；消息流实际组合；仅 Connector 相关路径与六真实正文齐全的断言延期 |

三种状态分别登记：接口释放（可消费）、包级完成（本阶段全部义务闭合）、波次通过（允许继续）。不能将暂用契约替身的接口释放写成完整验收。

执行中允许主调度按已核对的真实依赖释放下一波的独立包实施，不等同放行整波：tool-definition仅消费已经HUB验证的content-blocks与asset-model公开端口，可在call-accounts收尾期间实施；messages仍等待call-accounts实际接口。派发前核对采用条款与已释放API，发现尚缺前置即停相关动作；最终包/波和W6真实组合的完整门不降低。

## 责任与验收节奏

主调度规划者拥有计划、共享边界、HUB 集成、证据审核及包/波技术验收权；用户只做最后总体验收。
kernel-developer 负责 kernel-basis；其余产品模块按契约交 capability-developer；verification-developer 负责检查、故障注入、独立用例和运行证据，不自行接受。
公共 root 配置/catalog/锁/tools 由单一 owner 维护，包任务仅改自己的包及明确分配的对应节点，跨包需求交 owner。

每包先自查；每次 merge-back 后立即做受影响真实集成检查，每波审核后释放下游。
新波和 reviewer 前先核对 main 漂移，必要时 back-merge 并重验；组成/输入变化使旧证据失效则重跑受影响检查。
独立验收观察源码提交、配置、环境、原始结果、跳过和前提；验收者不能改产品、降标准或将作者自报当证据。

## 验收标准

所有包具备 build/typecheck/test、公开 exports、构建产物消费和有效负向类型测试；不得穿透兄弟 src。
十五个新纯模块不依赖 Cordis/kernel/storage/non-core 插件；既有 kernel/storage 按自己的职责例外。

| 组 | 关键判据 |
|---|---|
| Schema/表示 | 副本与冻结原件逐字节同；正反实例拒绝值及次序逐字相符，不从 Ajv 错误猜拒绝、不修补输入 |
| JSON | 超 2^53、长小数、opaque 往返无损，缺席/null 分开；任意层重复键及转义同名拒绝；Node >=24.18.0 前提明确 |
| 计量 | ExactDecimal 0.1+0.2=0.3 与超17位；补账重复/孤立/平局；knownSum/unknownCount 与手算一致 |
| 资产 | 非Connector资产完整禁用/替换/权限界/设置/工作区/指纹与五真实正文组合；仅Connector正文及其纵线相关求值/接入验收延期，不计作通过 |
| 消息/流 | 前缀可读、名单/配对、缺输入判不了；拒绝不改 state；snapshot/settlement/abandon；切分合并等价；语音按字节归约 |
| 参数 | 收齐重复键参数的封口接受、落 unparseable；区别 JSON 接收边界 malformed；U1~U7/format/缓存归属按设计，U8 runtime timeout 阶段外 |
| 正文/响应 | YAML1.2重复键/原文、路径形状与slash语法；MCP存取不筛去病态schema；响应/profile副本与精度 |
| 既有4包 | 空白集合唯一导出；identity所承担规则输入/负向检查；kernel三处缺失probe；offer墙钟负例；storage套件有效性负向自测 |

预期由契约或独立推导，不能由被测实现生成；性质测试固定种子且保留失败seed；检查工具各有故意违反必红的自测。
storage 验证用现有真实 provider + 临时文件库，驱动在工具侧；选择确定可复现的变异，不能假设 sqlite lockRow no-op 必红。

当前实际 core 组合与延期项：

1. 五个已交付真实正文 → 明确可用性的正文装配 → asset-model → asset-evaluation：完整验其他资产类型。Connector正文／纵线验收、六真实正文齐全的断言延期；替身只用于边界负例，不能代表Connector已交付。
2. 内容/账 → arrival-events → stream-assembly → 消息、响应及结算校验。

共享走查完成 core 接口侧；日志、运行时、存储和宿主前提保留外部 owner，不整行冒称完成。

## 总体交付门

- 当前范围的矩阵义务零未闭合、零跳过；消息／流真实组合及最终 make check 通过。Connector 及由它阻断的Connector相关资产求值组合以 `deferred-by-user` 单列，不能计作通过，也不能藏为 external。拆分项分别列本阶段已验部分与明确延期部分；不再声称原 19 包全部完成。
- 冻结 hash 不变，除明确追加的 util 外，非 core 产品源码 diff 为零；roles main 前置提交和 HUB 采用可核对。
- 全仓阶段外 skip 单列。evidence 记录源码、工具版本、命令、配置、实际结果和覆盖限制，模型与实现证据分开。
- realization 按实际结果回填，历史证据不覆盖；主调度提交对账/验收报告/未覆盖边界/差异给用户总体签收。
- 汇总一个 HUB 可审阅交付，不自行登记用户最终接受；本轮 remote 发布/合入 main 不从旧批次权限推断。

## 保存与恢复

用户入口为主检出 `tmp/core-delivery-plan.md`（软链接到本文）。实时状态在 `status.md`。
spoke 退休前核对唯一 ignored 证据和活跃消费者，保存并 hash 校验后移除；HUB 退休先搬计划到主检出 tmp/core-delivery，更新链接，避免悬空。
长期实际 evidence 归 design/record/evidence；调度计划不变成设计权威，不复制到 docs 或另建 design topic。

## 执行进度

- 2026-09-26：HUB 已从 main bb3d8bc4 创建。计划落盘，W0-A 开始。

## U1：执行中追加的格式化工具包

用户2026-09-26明确选择 unix-format 与 xml-format，用于统一格式化策略。来源为 minimal-runtime 树提交 d79484d9f4b8c726b6d7e37a36ae5698f4c8ecac 的两个项目自有移植包；不整体合入该分支。先核对真实来源/公开行为/上游与现有输入边界，补 .meta_harness 的窄实现地图并独立评审，主调度在授权的技术范围内接受，再从已通过HUB切spoke导入适配。源树只读且不清理。

U1与W2～W6无前置依赖，可并行。只引入格式化函数/声明选项/构建入口及必要测试和来源；不接管消息上下文、业务策略或XML解析器。timeout/brand调查结论单列，已有core身份品牌不得因搬util重定义，纯包不得因timeout引入墙钟/计时器。

验收：两包源commit/逐文件hash与改动清单可追溯，版本适配现catalog与Node24.18，零运行依赖；build/typecheck/test、公开构建入口与必要负类型、Python既有golden逐字节核对、Unicode宽度/转义/嵌套信任边界/选项非法输入检查通过。golden是有限差分基线，不推广为所有输入等价；toXml/formatDate调用方钩子不变成权限或任意XML安全保证。新增源码仅packages/util两个明确叶子，根锁/config由root，最终总体门加此U1增量。
