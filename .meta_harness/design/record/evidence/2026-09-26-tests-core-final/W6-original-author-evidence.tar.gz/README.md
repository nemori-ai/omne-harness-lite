# W6 measurement epoch 4 handoff

Source release `e77c7f126ff7144c546d9216273663beee039504`, human author panqiwei.
Spoke `panqiwei/core-delivery-w6-verification`; product inputs released at exact HUB
`0ec3eed2d5a5d3323caea5e8775de095fa13f3f0`. Adopted contract epoch is 3, distinct
from this measurement epoch 4. Earlier epoch 2/3 evidence is unchanged.

The reports record their real pre-commit HEAD `64e58ad1669569e96de6bcebd0ccfcda4dc746a9`.
`source-release-link.json` verifies that the tested source bytes are in e77 and
the three compiled consumer program hashes still match the last actual tarball run.
No report was rewritten to claim a later source revision.

Actual completed gates:

- `dependencies-after-MCP-executions.json`: 21 real dependencies build/typecheck/test
  returned 0, 6,340 tests passed; infra/storage-sql 4 PostgreSQL tests skipped because
  no PG instance was supplied. Core AE168, SA479 and MCP157 are all green.
- `member-enhanced-executions.json`: own build/typecheck/test returned 0,
  12 test files/35 tests, no type errors. Real SQLite runs all19 cases; foreign-key
  mutation fails exactly C11/C12 and leaves other17 green. Original raw output retained.
- `pack-enhanced-execution.json`, `run/packed-consumers/run-hDzgUt/report.json`:
  actual 18core+2util tarballs installed in an independent offline Node consumer.
  All500 named public types plus21 JSON public subpaths pass strict tsc with
  skipLibCheck:false. Every139 forbidden path has TS2307 and Node
  ERR_PACKAGE_PATH_NOT_EXPORTED. Actual22 fixed resources/421 definitions compile;
  six default3 and all public retained2 bytes and exact coordinates are checked.
- The same compiled programs exercise12 actual asset scenes and13 actual stream
  scenes in workspace and independent tarball consumers. Five genuine bodyContract
  providers feed AM→AE; CB/CA→AR→SA→Messages/MR uses all six real public ports.
  No fixture implements product behavior. The exact frame hand calculation9→wrong10
  and exact schema CB3→wrong2 controls each fail only the named target AssertionError.
  All raw wrong-control error messages and other passing scenes are retained.
- `coverage-report.json` checks all32 core-composition ID mappings against the actual
  a356 input matrix (30 active plus2 split-Connector core steps). Each measured core
  step points to an actual green report, including the two SQLite suite properties.
- `format-final.log` and `diff-final.log`: maintained changed source formatting and
  git diff whitespace checks passed. README and coverage JSON are outside the
  repository formatter's maintained scope; attempting them was rejected by that
  scope guard, not a formatting failure in maintained code.

`measurement-corrections.json` records the preserved red probes, original consumer
source/built hashes in probe-1..4, and frozen-clause reasons for consumer fixture
corrections. The original dependency MCP fixture mismatch red remains in
`dependencies-tests-final.log`; parent changed its Loop resource coordinate only,
then this spoke reran the complete dependency gates at the explicit new release.

The construction input matrix a356 is unchanged. `root-acceptance-delta.json` keeps
the separate later eb454167 matrix and its29 root metadata/signature differences.
Acceptance is root's decision. The coverage source has two historical suffixes
“SA release pending”; `coverage-report.json` explicitly records them as obsolete
after the real SA source release. External owner premises stay unverified.

Pending scope: two Connector IDs, genuine filesystem/MCP upstream authenticity,
transport/runtime side effects, durable same-commit session records/reference
existence, external owners' whole CS obligations, and user Skill SP3/S20 unknown-tag
semantic policy. Shape fixtures and core measurements do not prove these facts.
No formal/model result is inferred from this runtime run; parent owns formal gates.
Root technical acceptance and final user campaign acceptance remain outstanding.

`source-and-built.tar.gz` is a selected reproducible repository snapshot, not a new
design authority. It contains exact specs/realizations/config/source plus built
files needed by these consumers. Old unrelated evidence caches and installed
node_modules are excluded. All20 actual tarballs, input config, consumers, lock,
commands, stdout/stderr and negative-control reports are included in the compact
seal. Paths in raw reports are the original execution paths. Rebuild the independent
consumer in a fresh explicit evidence root; do not overwrite these original runs.

`seal/manifest.json` inventories every archived evidence file by bytes/hash;
`seal/seal-result.json` records archive hash and verified member count. Retirement
requires matching outside-spoke preservation and all consumers releasing this tree.
