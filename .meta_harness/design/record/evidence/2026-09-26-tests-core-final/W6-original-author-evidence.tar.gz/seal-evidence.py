from pathlib import Path
import hashlib
import json
import subprocess
import tarfile


root = Path.cwd()
base = root / 'tmp/w6-core-verification/epoch-4'
seal = base / 'seal'
seal.mkdir(exist_ok=True)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == 'e77c7f126ff7144c546d9216273663beee039504'
assert subprocess.check_output(['git', 'status', '--porcelain'], text=True) == ''
tracked = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
prefixes = (
    'packages/core/', 'packages/util/', 'packages/infra/storage-sql/',
    'tools/core-verification/', '.meta_harness/design/spec/',
    '.meta_harness/design/realization/packages/core/',
    '.meta_harness/design/realization/packages/util/', '.meta_harness/design/registry/',
    '.meta_harness/design/record/decisions/core-implementation-spec-reconciliation/',
    '.meta_harness/design/record/decisions/pr9-pr10-coordinate-reconciliation/',
)
configuration = {
    'package.json', 'pnpm-workspace.yaml', 'pnpm-lock.yaml', 'tsconfig.base.json',
    '.prettierrc.json', '.prettierignore', 'AGENTS.md', 'tools/AGENTS.md',
    'packages/AGENTS.md', 'docs/development.md', 'docs/workspace.md',
    'docs/verification.md', 'docs/defensive-patterns.md', 'scripts/format.sh',
    '.meta_harness/AGENTS.md', '.meta_harness/design/AGENTS.md',
    '.meta_harness/agents/roles/developer-contract.md',
}
source_files = [root / p for p in tracked if p and (p.startswith(prefixes) or p in configuration)]
built_files = []
for group in ['core', 'util']:
    for member in (root / 'packages' / group).iterdir():
        if (member / 'dist').is_dir():
            built_files.extend(p for p in (member / 'dist').rglob('*') if p.is_file())
for member in [root / 'packages/infra/storage-sql', root / 'tools/core-verification']:
    built_files.extend(p for p in (member / 'dist').rglob('*') if p.is_file())

files = sorted(set(source_files + built_files))
inventory = []
archive = base / 'source-and-built.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in files:
        assert path.is_file() and not path.is_symlink()
        relative = str(path.relative_to(root))
        assert 'node_modules' not in path.parts and not path.name.startswith('.env')
        data = path.read_bytes()
        inventory.append({'path': relative, 'kind': 'tracked-source' if path in source_files else 'built',
                          'bytes': len(data), 'sha256': digest(data)})
        tar.add(path, arcname=relative, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(inventory)
    for item in inventory:
        assert digest(tar.extractfile(item['path']).read()) == item['sha256']
write_json(base / 'source-and-built-inventory.json', {
    'source_release': head, 'files': inventory, 'archive_sha256': digest(archive.read_bytes()),
    'bytes': archive.stat().st_size, 'verified_archive_members': len(inventory),
    'note': 'Selected source/spec/realization/configuration and actual built bytes only. No unrelated historical evidence caches or installed node_modules.'})

old_archives = [
    (root / 'tmp/w6-core-verification/epoch-2-evidence.tar.gz',
     '88b030cfc7c8f86496979c6e5530cb21f0f9c8c09667c19378b3d84127376c81'),
    (root / 'tmp/w6-core-verification/epoch-3/seal/epoch-3-evidence.tar.gz',
     '24386bd9690220413f3d43ef300ca2e74c24a63beea119fb7370edee4b09adc9'),
]
prior = []
for path, expected in old_archives:
    actual = digest(path.read_bytes())
    assert actual == expected
    prior.append({'path': str(path.relative_to(root)), 'sha256': actual, 'unchanged': True})
write_json(base / 'previous-epochs-unchanged.json', prior)

pack = json.loads((base / 'run/packed-consumers/run-hDzgUt/report.json').read_text())
assert len(pack['members']) == 20 and pack['types'] == 500
assert len(pack['jsonInventory']) == 21 and pack['negativeTypeDiagnostics'] == 139
for member in pack['members']:
    assert digest(Path(member['tarball']).read_bytes()) == member['hash']
    assert member['specifier'].startswith('@omne-harness-lite/')
write_json(base / 'tarball-manifest.json', {
    'report': 'run/packed-consumers/run-hDzgUt/report.json',
    'packages': [{'name': m['specifier'], 'version': '0.0.0', 'tarball': m['tarball'],
                  'sha256': m['hash'], 'subpaths': m['subpaths']} for m in pack['members']],
})

evidence_files = sorted(p for p in base.rglob('*') if p.is_file()
                        and seal not in p.parents and 'node_modules' not in p.parts)
entries = [{'path': str(p.relative_to(base)), 'bytes': p.stat().st_size,
            'sha256': digest(p.read_bytes())} for p in evidence_files]
manifest = {
    'measurement_epoch': 4, 'adopted_spec_epoch': 3, 'source_release': head,
    'product_source_release': '0ec3eed2d5a5d3323caea5e8775de095fa13f3f0',
    'tested_report_HEAD': '64e58ad1669569e96de6bcebd0ccfcda4dc746a9',
    'source_release_link': 'source-release-link.json',
    'author': 'panqiwei <594557445@qq.com>', 'acceptance_authority': 'root technical; user final',
    'scope': {'core_packages': 18, 'util_packages': 2, 'dependency_gate_members': 21,
              'dependency_tests_passed': 6340, 'infra_PG_skipped': 4,
              'tool_test_files': 12, 'tool_tests_passed': 35,
              'actual_asset_cases': 12, 'actual_stream_cases': 13,
              'named_public_types': 500, 'public_JSON_subpaths': 21,
              'private_paths_TS2307': 139, 'private_paths_Node_error': 139,
              'schema_resources': 22, 'schema_definitions_compiled': 421,
              'core_composition_steps': 32},
    'pending': ['Connector two excluded IDs', 'external owner premises',
                'Skill SP3/S20 unknown-tag semantic decision', 'root technical acceptance',
                'user final campaign acceptance'],
    'negative_controls': ['SQLite foreign_keys off: C-11/C-12 only actual assertion failures',
                          'W1 Outcome 42 vs 0: target AssertionError only',
                          'AE workspace self vs member: target AssertionError only',
                          'schema CB3 expected2: exact-coordinate AssertionError only',
                          'SA emitted9 expected10: exact S-13 frame AssertionError only'],
    'reproduce': ['Restore selected source-and-built.tar.gz into a fresh repository checkout at release e77',
                  'pnpm install --frozen-lockfile --ignore-scripts',
                  'pnpm --filter @omne-harness-lite/core-verification... run build',
                  'pnpm --filter @omne-harness-lite/core-verification run typecheck',
                  'OMNE_CORE_VERIFICATION_EVIDENCE_ROOT=tmp/w6-core-verification/replay/run pnpm --filter @omne-harness-lite/core-verification run test',
                  'OMNE_CORE_VERIFICATION_EVIDENCE_ROOT=tmp/w6-core-verification/replay/run node tools/core-verification/dist/w6-packed-consumer.js'],
    'retention': 'Required raw stdout/stderr, exact probes, tarballs, scripts, inputs and reports included. Rebuildable node_modules only excluded. No retirement before verified outside-spoke preservation and consumer release.',
    'entries': entries,
}
write_json(seal / 'manifest.json', manifest)
evidence_archive = seal / 'epoch-4-evidence.tar.gz'
with tarfile.open(evidence_archive, 'w:gz') as tar:
    for path in evidence_files:
        tar.add(path, arcname=str(path.relative_to(base)), recursive=False)
    tar.add(seal / 'manifest.json', arcname='seal/manifest.json', recursive=False)
with tarfile.open(evidence_archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(entries) + 1
    for item in entries:
        assert digest(tar.extractfile(item['path']).read()) == item['sha256']
    assert digest(tar.extractfile('seal/manifest.json').read()) == digest((seal / 'manifest.json').read_bytes())
result = {'archive': str(evidence_archive.relative_to(root)), 'sha256': digest(evidence_archive.read_bytes()),
          'bytes': evidence_archive.stat().st_size, 'verified_members': len(entries) + 1,
          'manifest_sha256': digest((seal / 'manifest.json').read_bytes()),
          'source_archive_sha256': digest(archive.read_bytes()),
          'source_archive_members': len(inventory), 'previous_epochs_unchanged': True,
          'tracked_clean': subprocess.check_output(['git', 'status', '--porcelain'], text=True) == ''}
write_json(seal / 'seal-result.json', result)
print(json.dumps(result, indent=2))
