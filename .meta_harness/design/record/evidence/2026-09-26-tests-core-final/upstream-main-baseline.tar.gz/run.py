import datetime
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery-upstream-baseline')
OUT = ROOT / 'tmp/upstream-sqlite-baseline'
EXPECTED = '127d63dadf00358576b52fbfaed66e6e0c3f20dc'

def raw(argv):
    return subprocess.check_output(argv, cwd=str(ROOT))

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(value):
    return hashlib.sha256(value).hexdigest()

def record_run(label, argv):
    report = {'argv': argv, 'cwd': str(ROOT), 'started_at': stamp(), 'head': raw(['git', 'rev-parse', 'HEAD']).decode().strip()}
    with (OUT / (label + '.stdout.log')).open('wb') as stdout, (OUT / (label + '.stderr.log')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=str(ROOT), stdout=stdout, stderr=stderr)
    report.update({'finished_at': stamp(), 'exit_code': result.returncode})
    for stream in ['stdout', 'stderr']:
        file = OUT / (label + '.' + stream + '.log')
        report[stream + '_sha256'] = digest(file.read_bytes())
    (OUT / (label + '.receipt.json')).write_text(json.dumps(report, indent=2) + '\n')
    return result.returncode

assert raw(['git', 'rev-parse', 'HEAD']).decode().strip() == EXPECTED
assert raw(['git', 'branch', '--show-current']).decode().strip() == 'panqiwei/core-delivery-upstream-baseline'
assert raw(['git', 'status', '--porcelain']) == b''

versions = {'node': raw(['node', '--version']).decode().strip(), 'pnpm': raw(['pnpm', '--version']).decode().strip(), 'python': sys.version, 'uname': raw(['uname', '-a']).decode().strip()}
(OUT / 'environment.json').write_text(json.dumps(versions, indent=2) + '\n')

if sys.argv[1:] == ['build']:
    raise SystemExit(record_run('build-required-closure', ['pnpm', '--filter', '@omne-harness-lite/account-identity...', 'run', 'build']))
if sys.argv[1:] == ['test']:
    raise SystemExit(record_run('bounded-logins', ['pnpm', '--filter', '@omne-harness-lite/account-identity', 'exec', 'vitest', 'run', 'tests/bounded-logins.spec.ts', '--maxWorkers', '1', '--reporter', 'default', '--reporter', 'json', '--outputFile', str(OUT / 'bounded-logins.vitest.json')]))
if sys.argv[1:] == ['provenance']:
    refs = {'origin_main': '2cb236db7da15e78bb1e96dd8220ee68b6eceb75', 'main': EXPECTED, 'hub': 'a53644ad585d433627073c066f46d500f1aee6c6'}
    paths = ['packages/tenancy/account-identity', 'packages/infra/storage-sql']
    evidence = {'references': refs, 'packages': {}, 'lock_sha256': digest((ROOT / 'pnpm-lock.yaml').read_bytes()), 'source_snapshots': []}
    for path in paths:
        per_ref = {}
        for name, ref in refs.items():
            files = raw(['git', 'ls-tree', '-rz', '--name-only', ref, '--', path]).decode().split('\0')
            hashes = {file: digest(raw(['git', 'show', ref + ':' + file])) for file in files if file}
            per_ref[name] = {'files': hashes, 'count': len(hashes), 'aggregate_sha256': digest((''.join(file + ' ' + hashes[file] + '\n' for file in sorted(hashes))).encode())}
        evidence['packages'][path] = per_ref
    evidence['differences'] = {}
    for left, right in [('origin_main', 'main'), ('main', 'hub'), ('origin_main', 'hub')]:
        evidence['differences'][left + '_to_' + right] = raw(['git', 'diff', '--name-status', refs[left], refs[right], '--'] + paths).decode()
    source_paths = raw(['git', 'ls-files', '--'] + paths + ['packages/core/storage', 'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'tsconfig.base.json']).decode().splitlines()
    evidence['source_snapshots'] = {path: digest((ROOT / path).read_bytes()) for path in source_paths}
    with (OUT / 'tracked-inputs.tar').open('wb') as stream:
        subprocess.run(['git', 'archive', '--format=tar', EXPECTED] + paths + ['packages/core/storage', 'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'tsconfig.base.json'], cwd=str(ROOT), stdout=stream, check=True)
    evidence['tracked_inputs_tar_sha256'] = digest((OUT / 'tracked-inputs.tar').read_bytes())
    (OUT / 'provenance.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps({'diffs': evidence['differences'], 'packages': {path: {name: {'files': data['count'], 'aggregate_sha256': data['aggregate_sha256']} for name, data in per_ref.items()} for path, per_ref in evidence['packages'].items()}}, indent=2))
