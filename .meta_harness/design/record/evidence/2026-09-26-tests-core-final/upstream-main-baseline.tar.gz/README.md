# Main SQLite baseline reproduction

Baseline: `panqiwei/core-delivery-upstream-baseline` at
`127d63dadf00358576b52fbfaed66e6e0c3f20dc`.

Actual Node `v24.18.0`, pnpm `10.28.1`, Vitest `4.1.11`.
The unmodified `bounded-logins.spec.ts` ran with `maxWorkers 1`:
**14 passed, 3 failed, 0 skipped**. The failing names and messages match the
three reported HUB failures. See `REPORT.json`, raw Vitest JSON, and separate
stdout/stderr logs. This is a baseline result, not delivery acceptance.

`provenance.json` compares every tracked file of `account-identity` and
`storage-sql` at remote-main `2cb236db`, local-main `127d63da`, and HUB `a53644ad`.
All three pairwise package diffs are empty, with per-file SHA-256 retained.
The own main lock is retained separately from the HUB lock.

The independent `native-ddl-probe.mjs` imports only Node built-ins. With two
`DatabaseSync` connections to one temporary disk file, the reader first sees
the old schema and the writer then commits ALTER. ADD produces a first `SELECT *`
result missing the added columns; DROP produces `ERR_INVALID_STATE` with
`Cannot get name of column 5`, while `reader.isOpen` remains true. Before/after
`StatementSync.columns()` observations change 4→6 and 6→5 respectively.
Repeating the same statement then reads the complete result. Reading table
metadata first and requesting explicit columns provide positive controls.
This demonstrates an original Node API symptom; the C++ implementation was
not investigated and no internal cause or repair is claimed. The existing
provider's `ERR_INVALID_STATE`→`sqlite handle is closed` mapping does not describe
the observed still-open native handle in this case.

Replay from the specified clean baseline with its own dependencies:

```sh
pnpm install --frozen-lockfile --ignore-scripts
python3 tmp/upstream-sqlite-baseline/run.py provenance
python3 tmp/upstream-sqlite-baseline/run.py build
python3 tmp/upstream-sqlite-baseline/run.py test
node tmp/upstream-sqlite-baseline/native-ddl-probe.mjs
```

The `test` command is expected to exit 1 with the documented three failures.
Fresh replays should use a new evidence directory to preserve this original run.
`run.py` contains exact test argv; `build-closure-inputs.json` and its archive
record all eight built members and generated-dist hashes. Raw logs, source
archives, technical-input hashes, and generated probe database files are sealed
in `SHA256SUMS.json`. Both source archives were independently read back against
the unchanged baseline files. No tracked files were edited.

Scope excludes a full repository or tenancy suite, product/provider repair,
changes to fixtures/assertions/specification, and any acceptance decision.
