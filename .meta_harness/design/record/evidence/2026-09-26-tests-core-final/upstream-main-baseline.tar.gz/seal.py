import datetime
import hashlib
import json
import pathlib
import subprocess
import tarfile

ROOT = pathlib.Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery-upstream-baseline')
OUT = ROOT / 'tmp/upstream-sqlite-baseline'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(argv):
    return subprocess.check_output(['git'] + argv, cwd=str(ROOT))

assert git(['status', '--porcelain']) == b''
assert git(['rev-parse', 'HEAD']).decode().strip() == '127d63dadf00358576b52fbfaed66e6e0c3f20dc'

members = ['packages/core/identity-values', 'packages/core/kernel-basis', 'packages/core/storage', 'packages/core/offer-expiry', 'packages/infra/storage-sql', 'packages/infra/clock', 'packages/tenancy/credential-verification', 'packages/tenancy/account-identity']
configs = ['package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'tsconfig.base.json']
source_paths = git(['ls-files', '--'] + members + configs).decode().splitlines()
source_hashes = {path: sha((ROOT / path).read_bytes()) for path in source_paths}
with (OUT / 'build-closure-source.tar').open('wb') as stream:
    subprocess.run(['git', 'archive', '--format=tar', 'HEAD'] + members + configs, cwd=str(ROOT), stdout=stream, check=True)
build_hashes = {str(path.relative_to(ROOT)): sha(path.read_bytes()) for member in members for path in sorted((ROOT / member / 'dist').rglob('*')) if path.is_file()}
(OUT / 'build-closure-inputs.json').write_text(json.dumps({'members': members, 'tracked_inputs': source_hashes, 'generated_dist': build_hashes, 'source_tar_sha256': sha((OUT / 'build-closure-source.tar').read_bytes())}, indent=2) + '\n')

versions_argv = ['pnpm', '--filter', '@omne-harness-lite/account-identity...', 'list', '--depth', '0', '--json']
versions = subprocess.run(versions_argv, cwd=str(ROOT), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(OUT / 'selected-dependencies.stdout.json').write_bytes(versions.stdout)
(OUT / 'selected-dependencies.stderr.log').write_bytes(versions.stderr)
(OUT / 'selected-dependencies.receipt.json').write_text(json.dumps({'argv': versions_argv, 'cwd': str(ROOT), 'exit_code': versions.returncode}, indent=2) + '\n')
assert versions.returncode == 0

raw_results = json.loads((OUT / 'bounded-logins.vitest.json').read_text())
assertions = [test for suite in raw_results['testResults'] for test in suite['assertionResults']]
failed = [test for test in assertions if test['status'] == 'failed']
assert len(assertions) == 17 and len(failed) == 3
expected_titles = [
    'owns DDL and legacy revocation atomically when the SQLite Migrator has no outer transaction',
    'rejects a partially present bounded schema instead of applying an ambiguous migration',
    'first bounded migration revokes legacy logins and preserves old issuance/account material',
]
assert [test['title'] for test in failed] == expected_titles
provenance = json.loads((OUT / 'provenance.json').read_text())
assert all(diff == '' for diff in provenance['differences'].values())
probe = json.loads((OUT / 'native-ddl-probe.stdout.json').read_text())
assert len(probe['cases']) == 6
summary = {
    'sealed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'task': 'Read-only main baseline reproduction of the three HUB SQLite failures',
    'baseline_head': git(['rev-parse', 'HEAD']).decode().strip(),
    'branch': git(['branch', '--show-current']).decode().strip(),
    'result': 'reproduced',
    'runtime_tests': {'total': len(assertions), 'passed': len(assertions) - len(failed), 'failed': len(failed), 'skipped': sum(test['status'] in ['pending', 'todo', 'skipped'] for test in assertions)},
    'failures': [{'title': test['title'], 'status': test['status'], 'failureMessages': test['failureMessages']} for test in failed],
    'source_provenance': {'references': provenance['references'], 'pairwise_tracked_diffs': provenance['differences'], 'packages': {path: {name: {'files': data['count'], 'aggregate_sha256': data['aggregate_sha256']} for name, data in per_ref.items()} for path, per_ref in provenance['packages'].items()}},
    'native_probe': {'argv': ['node', 'tmp/upstream-sqlite-baseline/native-ddl-probe.mjs'], 'cwd': str(ROOT), 'node': probe['node'], 'cases': len(probe['cases']), 'status': 'cross-connection ADD/DROP symptoms reproduced; metadata/explicit-column controls observed', 'internal_cause': 'not investigated; no assertion about Node C++ internals'},
    'tracked_status_at_seal': git(['status', '--porcelain']).decode(),
    'limits': ['Single bounded-logins file, not complete tenancy or repository suite', 'Linux single-process Node 24.18.0 only', 'No product, fixture, specification, realization, or tracked lock edits', 'No provider repair or technical acceptance', 'No original install timestamp was captured; original stdout/stderr and exact declared command are retained'],
    'install_argv': ['pnpm', 'install', '--frozen-lockfile', '--ignore-scripts'],
}
(OUT / 'REPORT.json').write_text(json.dumps(summary, indent=2) + '\n')

inputs = ['AGENTS.md', 'packages/AGENTS.md', 'docs/AGENTS.md', 'docs/development.md', 'docs/verification.md', '.meta_harness/design/registry/catalog.json', '.meta_harness/design/spec/capabilities/account-identity/v3/contract.md', '.meta_harness/design/record/decisions/governance-identity-offer-contracts/acceptance.json']
for node in ['core/storage', 'infra/storage-sql', 'tenancy/account-identity']:
    inputs.extend('.meta_harness/design/realization/packages/' + node + '/' + name + '.md' for name in ['README', 'design', 'verification'])
(OUT / 'technical-inputs.json').write_text(json.dumps({path: sha((ROOT / path).read_bytes()) for path in inputs}, indent=2) + '\n')
plan = pathlib.Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery/tmp/core-delivery/implementation-delivery-plan.md')
(OUT / 'plan-input.json').write_text(json.dumps({'path': str(plan), 'sha256': sha(plan.read_bytes()), 'scope': 'core only, Connector vertical deferred; this diagnostic does not extend delivery scope'}, indent=2) + '\n')

manifest = {str(path.relative_to(OUT)): sha(path.read_bytes()) for path in sorted(OUT.rglob('*')) if path.is_file() and path.name != 'SHA256SUMS.json'}
(OUT / 'SHA256SUMS.json').write_text(json.dumps(manifest, indent=2) + '\n')
for path, digest in manifest.items():
    assert sha((OUT / path).read_bytes()) == digest
for archive in ['tracked-inputs.tar', 'build-closure-source.tar']:
    with tarfile.open(str(OUT / archive)) as tar:
        for member in tar.getmembers():
            if member.isfile():
                assert sha(tar.extractfile(member).read()) == sha((ROOT / member.name).read_bytes())
print(json.dumps({'result': summary['result'], 'runtime_tests': summary['runtime_tests'], 'package_hashes': summary['source_provenance']['packages'], 'payload_files': len(manifest), 'manifest_sha256': sha((OUT / 'SHA256SUMS.json').read_bytes()), 'tracked_clean': summary['tracked_status_at_seal'] == ''}, indent=2))
