import { DatabaseSync } from 'node:sqlite'
import { mkdtempSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

// Independent observations only. No product imports, patching, or test replacements.
const evidenceRoot = fileURLToPath(new URL('.', import.meta.url))
const temp = mkdtempSync(join(evidenceRoot, 'native-ddl-'))
const report = { node: process.version, startedAt: new Date().toISOString(), cases: [] }

function observe(callback) {
  try {
    return { ok: callback() }
  } catch (error) {
    return { error: { name: error.name, message: error.message, code: error.code, errcode: error.errcode, stack: error.stack } }
  }
}

for (const change of ['add', 'drop']) {
  for (const control of ['none', 'read-table-info-before-select', 'explicit-columns']) {
    const file = join(temp, `${change}-${control}.sqlite`)
    const writer = new DatabaseSync(file)
    writer.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA foreign_keys=ON')
    writer.exec('CREATE TABLE login_state (login_state_id TEXT PRIMARY KEY, account_id TEXT, issued_at INTEGER, revoked INTEGER)')
    if (change === 'drop') writer.exec('ALTER TABLE login_state ADD COLUMN credential_revision INTEGER NOT NULL DEFAULT 0; ALTER TABLE login_state ADD COLUMN last_activity_at INTEGER NOT NULL DEFAULT 0')
    writer.exec("INSERT INTO login_state (login_state_id, account_id, issued_at, revoked) VALUES ('legacy-id','legacy-account',1790164800000,0)")
    const reader = new DatabaseSync(file)
    reader.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA foreign_keys=ON; PRAGMA query_only=ON')
    const before = reader.prepare('SELECT * FROM login_state').all()
    writer.exec('BEGIN IMMEDIATE')
    if (change === 'add') writer.exec('ALTER TABLE login_state ADD COLUMN credential_revision INTEGER NOT NULL DEFAULT 0; ALTER TABLE login_state ADD COLUMN last_activity_at INTEGER NOT NULL DEFAULT 0; UPDATE login_state SET revoked=1, last_activity_at=issued_at')
    else writer.exec('ALTER TABLE login_state DROP COLUMN last_activity_at')
    writer.exec('COMMIT')
    const item = { change, control, before, writerAfter: writer.prepare('SELECT * FROM login_state').all() }
    if (control === 'read-table-info-before-select') item.readerTableInfo = observe(() => reader.prepare('PRAGMA table_info(login_state)').all())
    const sql = control === 'explicit-columns'
      ? `SELECT login_state_id, account_id, issued_at, revoked, credential_revision${change === 'add' ? ', last_activity_at' : ''} FROM login_state`
      : 'SELECT * FROM login_state'
    reader.exec('BEGIN')
    const statement = reader.prepare(sql)
    item.sql = sql
    item.columnsBeforeStep = observe(() => statement.columns())
    item.firstAll = observe(() => statement.all())
    item.readerStillOpen = reader.isOpen
    item.columnsAfterStep = observe(() => statement.columns())
    item.secondAllSameStatement = observe(() => statement.all())
    item.freshAll = observe(() => reader.prepare(sql).all())
    reader.exec('COMMIT')
    reader.close()
    writer.close()
    report.cases.push(item)
  }
}
report.finishedAt = new Date().toISOString()
console.log(JSON.stringify(report, null, 2))
