export const calls = []

export function encode(value) {
  if (value === undefined) return { $reference: 'undefined' }
  if (typeof value === 'bigint') return { $reference: 'bigint', value: value.toString() }
  if (value instanceof Date) return { $reference: 'date', value: value.toISOString() }
  if (value instanceof Map) return { $reference: 'map', entries: [...value].map(([k, v]) => [encode(k), encode(v)]) }
  if (value?.constructor?.name === 'Child' && typeof value.toXml === 'function') {
    return { $reference: 'child', label: value.label }
  }
  if (Array.isArray(value)) return value.map(encode)
  if (value !== null && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, encode(v)]))
  }
  return value
}

export function instrument(name, original) {
  return (...args) => {
    calls.push({ function: name, args: encode(args) })
    return original(...args)
  }
}
