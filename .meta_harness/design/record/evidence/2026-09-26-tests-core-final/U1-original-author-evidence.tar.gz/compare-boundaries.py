"""Check exact boundary observations; differences are adoption deltas, not parity."""
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parent
inputs = json.loads((ROOT / 'boundary-inputs.json').read_text())['cases']
ts = {r['id']: r for r in json.loads((ROOT / 'boundary-typescript-results.json').read_text())['cases']}
py = {r['id']: r for r in json.loads((ROOT / 'boundary-python-results.json').read_text())['cases']}
assert len(inputs) == len(ts) == len(py) == 11
rows = []
for case in inputs:
    ident = case['id']
    actual = ts[ident]
    reference = py[ident]
    expected = case['expected']
    assert actual['status'] == expected['status'], ident
    if expected['status'] == 'error':
        assert actual['error_type'] == expected['error_type'], ident
        assert re.search(expected['message_pattern'], actual['error'], re.I), ident
        if case['name'] == 'xml-invalid-indent':
            assert reference['status'] == 'error'
            assert reference['error_type'] == 'ValidationError'
            assert 'less_than_equal' in reference['error'] and 'indent_size' in reference['error']
            classification = 'both-reject-native-option-error-types'
        else:
            assert reference['status'] == 'output', ident
            classification = 'accepted-current-input-rejection-not-Python-parity'
    else:
        assert actual['output'] == expected['output'], ident
        assert reference['status'] == 'output'
        assert actual['output'].encode('utf-8') == reference['output'].encode('utf-8'), ident
        classification = 'byte-equal-caller-premises-preserved'
    rows.append({'id': ident, 'rule': case['rule'], 'input': case, 'typescript': actual,
                 'python': reference, 'classification': classification})
result = {'executed': 11, 'current_expected_rejections': 8, 'current_expected_outputs': 3,
          'cases': rows, 'unexpected_observations': 0,
          'reference_process_exit': int((ROOT / 'boundary-python-exit.txt').read_text()),
          'reference_exit_explanation': 'Exit 1 records the actual Python ValidationError for indent_size=9; exact per-case observation checked here.'}
assert result['reference_process_exit'] == 1
(ROOT / 'boundary-comparison.json').write_text(json.dumps(result, indent=2, ensure_ascii=True) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'cases'}))
