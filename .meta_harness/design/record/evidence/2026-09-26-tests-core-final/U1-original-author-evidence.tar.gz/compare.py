"""Compare actual UTF-8 output bytes, keeping each input and expected delta visible."""
import argparse
import hashlib
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--typescript', type=pathlib.Path, default=ROOT / 'typescript-results.json')
parser.add_argument('--output', type=pathlib.Path, default=ROOT / 'comparison.json')
options = parser.parse_args()
ts = json.loads(options.typescript.read_text())
py = json.loads((ROOT / 'python-results.json').read_text())
inputs = json.loads((ROOT / 'inputs.json').read_text())
ts_by_id = {r['id']: r for r in ts['cases']}
py_by_id = {r['id']: r for r in py['cases']}
assert len(inputs['cases']) == len(ts_by_id) == len(py_by_id) == 99
rows = []
for case in inputs['cases']:
    ident = case['id']
    actual_py = py_by_id[ident]
    actual_ts = ts_by_id[ident]
    assert actual_py['status'] == actual_ts['status'] == 'output', ident
    py_bytes = actual_py['output'].encode('utf-8')
    ts_bytes = actual_ts['output'].encode('utf-8')
    same = py_bytes == ts_bytes
    expected_date_delta = ident == 'xml-format/date_default'
    assert same != expected_date_delta, ident
    if expected_date_delta:
        assert actual_py['output'] == '<event occurred_at="2024-01-15T10:30:00+00:00"/>'
        assert actual_ts['output'] == '<event occurred_at="2024-01-15T10:30:00.000Z"/>'
    rows.append({'id': ident, 'input': case, 'python': actual_py, 'typescript': actual_ts,
                 'utf8_equal': same, 'classification': 'accepted-JS-ISO-date-spelling' if expected_date_delta else 'byte-equal'})

# A deliberately corrupted output must be detected for its exact case. This
# exercises the measurement criterion without editing formatter code or inputs.
target = 'unix-format/error_plain'
corrupt = ts_by_id[target]['output'] + '\n'
try:
    assert corrupt.encode('utf-8') == py_by_id[target]['output'].encode('utf-8'), target
except AssertionError as exc:
    assert str(exc) == target
    controls = [{'id': 'extra-newline-is-not-equal', 'target': target, 'detected': True,
                 'python_sha256': py_by_id[target]['sha256'], 'corrupt_ts_sha256': hashlib.sha256(corrupt.encode()).hexdigest()}]
else:
    raise AssertionError('corrupt comparator control was not detected')

golden_results = []
for pkg in ('unix-format', 'xml-format'):
    fixture = ROOT / 'case-source' / f'{pkg}.golden.json'
    fixture_data = json.loads(fixture.read_text())
    expected = {**fixture_data['same'], **fixture_data.get('diff', {})}
    selected = [r for r in rows if r['input']['package'] == pkg]
    assert len(selected) == len(expected)
    mismatches = [r['id'] for r in selected if r['python']['output'] != expected[r['input']['name']]]
    assert not mismatches, mismatches
    golden_results.append({'package': pkg, 'actual_python_cases': len(selected),
                           'fixed_fixture_sha256': hashlib.sha256(fixture.read_bytes()).hexdigest(),
                           'all_actual_python_bytes_match_fixed_fixture': True})

result = {'total': 99, 'unix_byte_equal': 51, 'xml_byte_equal': 47, 'xml_accepted_differences': 1,
          'unexecuted': 0, 'unexpected_differences': 0, 'cases': rows,
          'fixed_fixture_cross_check': golden_results, 'measurement_negative_controls': controls}
options.output.write_text(json.dumps(result, indent=2, ensure_ascii=True) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('cases',)}))
