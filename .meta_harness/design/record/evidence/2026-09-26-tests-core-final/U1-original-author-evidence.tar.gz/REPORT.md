# U1 固定 Python formatter 的实际有限差分

本补交只开发验证适配和保存结果；不改产品实现、规格或采用决定，不作技术接受，也不代签人类总体门。写入只在本任务 `tmp/core-delivery/u1-python-reference/`。执行仓库是 HUB `panqiwei/core-delivery`，首检出为 `7e637451fcc2f05bfa5a51679132df6d401cd637`；最终源码、工具和运行修订见 `environment.json`、`execution-state.json`。

## 结果

真正执行 omne-next 固定 Git `6263fed545e48ad9efb5714f3fe76a7c1a0af1b5` 的 Python 实现，独立读取 99 个输入，逐项与当前 HUB 包名公开入口产生的 UTF-8 字节比较。

| 范围 | 实际执行 | 字节相同 | 已接受差异 | 未执行 / 未解释差异 |
| --- | ---: | ---: | ---: | ---: |
| unix-format | 51 | 51 | 0 | 0 |
| xml-format | 48 | 47 | 1 | 0 |

唯一差异 `xml-format/date_default`：Python 为 `<event occurred_at="2024-01-15T10:30:00+00:00"/>`，TS 为 `<event occurred_at="2024-01-15T10:30:00.000Z"/>`。这是 XF-5 接受的 JS ISO 日期拼写。Python 的 99 个实际输出还逐字节复现了固定旧 fixture；fixture 只在执行完成后作为交叉核对，没有用作 Python formatter 的替身。

`comparison.json` 保存 99 行完整输入、Python/TS 实际输出、UTF-8 长度、SHA256 和分类；`CASE-RESULTS.md` 给出全部具名结果。运行零未执行、零未知差异，但只覆盖这组有限输入，不能推广为所有输入的跨语言等价。

## 真实源与输入适配

- 16 个源/元数据文件由只读 `git show` 恢复，包括两 formatter 共 11 个原文件、原父级 facade、固定 `uv.lock` 和 pyproject；`source-manifest.json` 给逐文件 hash，`fixed-source-git-reverification.json` 记录再次实际读取固定 blob 的命令与一致结果。没有 checkout 或运行 omne-next 仓库环境。
- 实际导入的是原 Unix 公开函数和原 `XMLFormatMixin`、`FieldSpec`、`FormattingOptions`。`python-results.json.actual_modules` 给本次真正执行的原模块路径/hash。Python 函数没有重写；没有仿造同名 formatter。
- 只为导入叶子模块注册父级 namespace，绕过原 aggregate `__init__` 引入的分发版本、ContextBlock、registry、time 子系统。绕过的 facade 也完整保存，未把它们的行为列入本次验证；不存在替代 formatter 或 Pydantic 的 stub。
- Python 环境为任务专属 `.venv`、Python 3.12.13。Pydantic 2.12.5 / pydantic-core 2.41.5 / annotated-types 0.7.0 / typing-extensions 4.15.0 / typing-inspection 0.4.2，从固定锁取精确 wheel URL/hash，并以 `uv pip --require-hashes` 安装。要求、hash 和实际安装日志见 `reference-requirements.txt`、`python-dependencies.json`、`setup-dependencies.log`。
- 输入来自两包受维护 `differential.spec.ts` 的 51 + 47 个原案例函数，以及原日期案例，源副本/hash保存在 `case-source/`、`inputs.json.inputSources`。AST 只移除 Vitest/fixture 读取和测试注册；原输入与 schema 构造保留。观察 wrapper 在调用真实包名入口之前记录参数，输出仍由真实 dist 产生，没有重实现 TS formatter。`typescript-results.json` 保存实际公开解析路径、Node 和 TS 版本。
- BigInt 以十进制串桥接为 Python int，Date ISO 桥接为时区 datetime，Map 桥接为保序 dict。`not_nullish` 映射为原 `not_none`，schema/选项 camelCase 映射为原 snake_case。没有改变值、字段次序或输出。
- XML 根对象使用真正 Pydantic `BaseModel + XMLFormatMixin`，并按输入 schema 配置原 `__xml_tag__`、`__required_fields__` 和 `__optional_fields__`。复杂列表对象和其嵌套记录使用真正 BaseModel，供原 formatter 识别；普通 dict 字段保留 dict。Child 是原 mixin 的真正模型，不返回 fixture 字符串。适配只选择原有输入模型，没有格式化逻辑。
- Unix options 使用原 dataclass，numbered 的 `start` / `separator` / `per_line_char_limit` 按原签名传入；未给 options 时保持原 numbered 的不封顶默认。
- HUB 两叶全部 40 个受维护文件与实施提交 `bf47e1e73f1ea6d3b1f3b9638aa99ced1eb1d35f` 逐字节一致；真实 dist、源、fixture、采用文档快照均存入 source tar。运行前后 88 个产品/真实 dist 文件 hash 不变。完整文件计数以 `hub-source-manifest.json` 和 `execution-state.json` 为准。

## 边界与测量自检

另实际执行 11 项补充边界，不算入 99 项 golden：

- XML 非法 NUL / U+FFFE、重复根属性：当前 TypeError，原 Python 产生带非法字符或重复属性的字符串，按 XF-2 / XF-3 登记为已接受输入拒绝差异。
- 继承名字 `toString` 作为未知 optional 选择、未知 override、非法根名字：当前分别在具体 schema/名字边界拒绝，原 Python 会忽略或输出；按 XF-1 / XF-3 / XF-4 记录，不声称旧输入全等价。
- indentSize=9：当前 RangeError；原 Pydantic 是确切 `indent_size`、`less_than_equal` ValidationError。原 Python 进程保留退出 1，不改成成功；结果比较器验证了具体错误位置/类型。
- Unix maxWidth=-1：当前 RangeError，原 Python 接受；按 UF-4 记录已接受校验差异。
- U+1FFFE、signed start=-3、trusted toXml 的 `<broken>` 原样片段三项两边字节相同。最后一项显式显示主动钩子未被验证成合法完整 XML，不能据此给 XML 安全保证。

`boundary-comparison.json` 保存 11 项完整输入、原输出/错误和归类。当前 8 项预期拒绝、3 项输出均通过。

比较器有两个真实进程必红控制：只给 `error_plain` 的被比较 TS 输出附加 LF；只把日期差异隐藏成 Python 拼写。两次均退出 1，stderr 分别精确 `AssertionError: unix-format/error_plain` 和 `AssertionError: xml-format/date_default`，且没有生成成功报告。真实 formatter / 输入没有改。完整控制输入、stdout/stderr、argv/退出值见 `control-*.json`、`final-control-*.log`、`invocations.json`。

首轮补充 harness 错把 numbered separator 周围空格漏掉，独立 Python 与真实 TS 都是 `    -3 | a`；只纠正本任务 oracle。R1 的错误预期、脚本、原始失败和真实输出保存在 `boundary-harness-r1.mjs`、`boundary-inputs-r1.json`、`boundary-typescript-run.log`、`boundary-typescript-results-r1.json`。这不是产品失败，没有改接受规则、实现或阈值。

## 复跑与保存

实际最终八条命令、cwd、UTC 起止、原始 stdout/stderr、退出值在 `invocations.json`；将完整 evidence tar 解到同一 HUB `tmp/core-delivery/` 下一个新叶目录后，`replay.py` 可独立再执行，CPU 范围只有这 99 + 11 小输入和比较器。原封存目录保持只读，复跑不覆盖原始报告与日志。

1. 在新的复跑任务目录恢复源码/输入；需要 Node 24.18.0、HUB TypeScript 开发依赖和这两个真实公开 dist。本交付不会自行 build，也不会修改 shared `.venv` 或根锁。
2. 如环境需重建：`uv venv --python 3.12.13 <任务目录>/.venv`；`uv pip install --python <任务目录>/.venv/bin/python --require-hashes -r <任务目录>/reference-requirements.txt`。仅原五依赖装入该环境。
3. 本任务 `node_modules/@omne-harness-lite/{unix-format,xml-format}` 链接到该 HUB 两包，`node_modules/typescript` 链接该 HUB `tools/ts-checks/node_modules/typescript`。这些链接/环境属于可重建部分，不进入 seal。
4. `<任务目录>/.venv/bin/python <任务目录>/replay.py`。原 Python 执行器也可单独用 `--input inputs.json --output <新输出>`，不会读取 TS 输出或 golden。

`source-input.tar.gz` 保存原 Python 与本次真实产品/采用输入快照；`source-tar-manifest.json`、`manifest.json`、`SHA256SUMS` 逐文件可读可核；完整 `evidence.tar.gz` 另含运行工具、99/11 原始结果、负控制、报告与 source tar。`bundle-verification.json` 是实际 tar 读取/hash 检查，不把路径存在当作保全完成。环境、node_modules、pycache 不进入 seal。

不覆盖 timeout/brand、core 业务格式选择、所有 XML/Unicode 输入、命名空间/DTD/解析器、主动钩子的完整 XML 安全、其他领域消费者或总体接受。两个 util 不因此给 core 增加依赖。本报告给主调度独立核查，技术与人类总体接受仍由相应有权主体完成。
