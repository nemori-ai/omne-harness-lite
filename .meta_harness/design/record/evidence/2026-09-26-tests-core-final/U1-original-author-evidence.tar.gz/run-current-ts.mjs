import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { fileURLToPath, pathToFileURL } from 'node:url'
import path from 'node:path'
import ts from 'typescript'
import { calls } from './capture.mjs'

const root = path.dirname(fileURLToPath(import.meta.url))
const hub = path.resolve(root, '../../..')
const inputs = []
const results = []
const inputSources = []
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
mkdirSync(path.join(root, 'case-source'), { recursive: true })
for (const pkg of ['unix-format', 'xml-format']) {
  const original = path.join(hub, 'packages/util', pkg, 'tests/differential.spec.ts')
  const source = readFileSync(original, 'utf8')
  writeFileSync(path.join(root, 'case-source', `${pkg}.spec.ts.snapshot`), source)
  inputSources.push({ path: original, sha256: sha(source) })
  const parsed = ts.createSourceFile(original, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
  const statements = parsed.statements.filter(statement => {
    if (ts.isImportDeclaration(statement)) {
      return !['vitest', 'node:fs'].includes(statement.moduleSpecifier.text)
    }
    if (ts.isVariableStatement(statement) && statement.declarationList.declarations.some(d => d.name.getText(parsed) === 'golden')) return false
    if (ts.isExpressionStatement(statement) && ts.isCallExpression(statement.expression) && statement.expression.expression.getText(parsed) === 'describe') return false
    return true
  })
  const printer = ts.createPrinter()
  let code = statements.map(statement => printer.printNode(ts.EmitHint.Unspecified, statement, parsed)).join('\n')
  code = code.replaceAll(`from '@omne-harness-lite/${pkg}'`, `from './instrument-${pkg}.mjs'`)
  code = code.replaceAll(`from "@omne-harness-lite/${pkg}"`, `from './instrument-${pkg}.mjs'`)
  code += '\nexport { same };\n'
  if (pkg === 'xml-format') code += 'export function dateCase() { return formatXml({ occurred_at: new Date(Date.UTC(2024, 0, 15, 10, 30)) }, event) }\n'
  const module = ts.transpileModule(code, { compilerOptions: { target: ts.ScriptTarget.ES2024, module: ts.ModuleKind.ESNext } }).outputText
  writeFileSync(path.join(root, `${pkg}-cases.mjs`), module)
  const publicModule = await import(`@omne-harness-lite/${pkg}`)
  const wrappers = Object.keys(publicModule).filter(name => typeof publicModule[name] === 'function')
  writeFileSync(path.join(root, `instrument-${pkg}.mjs`),
    `import * as real from '@omne-harness-lite/${pkg}';\nimport { instrument } from './capture.mjs';\n` +
    wrappers.map(name => `export const ${name} = instrument('${name}', real.${name});`).join('\n') + '\n')
  const cases = await import(pathToFileURL(path.join(root, `${pkg}-cases.mjs`)))
  const renderers = Object.entries(cases.same)
  if (pkg === 'xml-format') renderers.push(['date_default', cases.dateCase])
  assert.equal(renderers.length, pkg === 'unix-format' ? 51 : 48)
  for (const [name, render] of renderers) {
    calls.length = 0
    const output = render()
    assert.equal(typeof output, 'string')
    assert.ok(calls.length > 0)
    const id = `${pkg}/${name}`
    inputs.push({ id, package: pkg, name, ...calls[0] })
    results.push({ id, status: 'output', output, utf8_bytes: Buffer.byteLength(output), sha256: sha(output), public_resolution: import.meta.resolve(`@omne-harness-lite/${pkg}`) })
  }
}
assert.equal(inputs.length, 99)
writeFileSync(path.join(root, 'inputs.json'), JSON.stringify({ inputSources, cases: inputs }, null, 2) + '\n')
writeFileSync(path.join(root, 'typescript-results.json'), JSON.stringify({ node: process.version, typescript: ts.version, cases: results }, null, 2) + '\n')
console.log(JSON.stringify({ executed: results.length, unix: 51, xml: 48, publicModules: [...new Set(results.map(r => r.public_resolution))] }))
