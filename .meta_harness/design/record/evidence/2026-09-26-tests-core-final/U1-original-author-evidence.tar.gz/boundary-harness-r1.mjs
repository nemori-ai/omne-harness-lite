import assert from 'node:assert/strict'
import { writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import * as unix from '@omne-harness-lite/unix-format'
import * as xml from '@omne-harness-lite/xml-format'

const root = path.dirname(fileURLToPath(import.meta.url))
const schema = { tag: 's', requiredFields: { body: { presentation: 'content' } } }
const cases = [
  { name: 'xml-illegal-NUL', args: [{ body: 'a\u0000b' }, schema], rejection: { type: 'TypeError', message: /XML|character/i }, rule: 'XF-2' },
  { name: 'xml-illegal-FFFE', args: [{ body: 'a\ufffeb' }, schema], rejection: { type: 'TypeError', message: /XML|character/i }, rule: 'XF-2' },
  { name: 'xml-duplicate-root-attributes', args: [{ a: 'x', b: 'y' }, { tag: 's', requiredFields: { a: { presentation: 'attr', xmlName: 'same' }, b: { presentation: 'attr', xmlName: 'same' } } }], rejection: { type: 'TypeError', message: /Duplicate.*attribute/i }, rule: 'XF-3' },
  { name: 'xml-inherited-optional-toString', args: [{ body: 'text' }, schema, { extraFields: ['toString'] }], rejection: { type: 'Error', message: /extraFields not declared/ }, rule: 'XF-1/XF-4' },
  { name: 'xml-unknown-presentation-override', args: [{ body: 'text' }, schema, { fieldOverrides: { unknown: { presentation: 'attr' } } }], rejection: { type: 'Error', message: /fieldOverrides not declared/ }, rule: 'XF-4' },
  { name: 'xml-invalid-name', args: [{ body: 'text' }, { ...schema, tag: '1bad' }], rejection: { type: 'Error', message: /XML.*name|name.*XML|Invalid/i }, rule: 'XF-3' },
  { name: 'xml-invalid-indent', args: [{ body: 'text' }, schema, { indentSize: 9 }], rejection: { type: 'RangeError', message: /indentSize/ }, rule: 'XF-4' },
  { name: 'xml-legal-supplementary-1FFFE', args: [{ body: '\u{1fffe}' }, schema], expected: '<s>\n  \u{1fffe}\n</s>', rule: 'XF-2' },
  { name: 'xml-trusted-raw-fragment', args: [{ child: { $reference: 'raw-xml', output: '<broken>' } }, { tag: 'parent', requiredFields: { child: {} } }], expected: '<parent>\n  <broken>\n</parent>', rule: 'XF-6' },
  { name: 'unix-negative-width', package: 'unix-format', function: 'formatTable', args: [['h'], [['v']], { maxWidth: -1 }], rejection: { type: 'RangeError', message: /maxWidth/ }, rule: 'UF-4' },
  { name: 'unix-signed-start', package: 'unix-format', function: 'formatNumberedLines', args: [['a', 'b'], { start: -3 }], expected: '    -3|a\n    -2|b', rule: 'UF-3' },
]

function decode(value) {
  if (Array.isArray(value)) return value.map(decode)
  if (value !== null && typeof value === 'object') {
    if (value.$reference === 'raw-xml') return { toXml: () => value.output }
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, decode(v)]))
  }
  return value
}

const inputs = []
const results = []
for (const probe of cases) {
  const pkg = probe.package ?? 'xml-format'
  const fn = probe.function ?? 'formatXml'
  const id = `boundary/${probe.name}`
  inputs.push({ id, package: pkg, name: probe.name, function: fn, args: probe.args, rule: probe.rule,
    expected: probe.rejection ? { status: 'error', error_type: probe.rejection.type, message_pattern: probe.rejection.message.source } : { status: 'output', output: probe.expected } })
  let result
  try {
    const output = (pkg === 'xml-format' ? xml : unix)[fn](...decode(probe.args))
    result = { id, status: 'output', output, utf8_bytes: Buffer.byteLength(output), sha256: createHash('sha256').update(output).digest('hex') }
  } catch (error) {
    result = { id, status: 'error', error_type: error.constructor.name, error: error.message }
  }
  results.push(result)
}
writeFileSync(path.join(root, 'boundary-inputs.json'), JSON.stringify({ cases: inputs }, null, 2) + '\n')
writeFileSync(path.join(root, 'boundary-typescript-results.json'), JSON.stringify({ cases: results }, null, 2) + '\n')
for (let index = 0; index < cases.length; index++) {
  const probe = cases[index]
  const result = results[index]
  if (probe.rejection) {
    assert.equal(result.status, 'error', result.id)
    assert.equal(result.error_type, probe.rejection.type, result.id)
    assert.match(result.error, probe.rejection.message, result.id)
  } else {
    assert.equal(result.status, 'output', result.id)
    assert.equal(result.output, probe.expected, result.id)
  }
}
console.log(JSON.stringify({ actualCurrentPublicBoundaryCases: results.length, expectedRejections: cases.filter(p => p.rejection).length, outputs: cases.filter(p => !p.rejection).length }))
