"""Seal readable payloads, exclude only rebuildable environments and caches."""
import hashlib
import json
import pathlib
import tarfile

ROOT = pathlib.Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(path):
    return {'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': digest(path)}


comparison = json.loads((ROOT / 'comparison.json').read_text())
lines = ['# 99 个实际差分输入的逐项结果', '',
         '完整输入和输出保存在 comparison.json；这里列全量身份和 UTF-8 字节判据。', '',
         '| # | 具名输入 | Python UTF-8 字节 | TS UTF-8 字节 | 结果 |',
         '| ---: | --- | ---: | ---: | --- |']
for index, row in enumerate(comparison['cases'], start=1):
    lines.append(f"| {index} | {row['id']} | {row['python']['utf8_bytes']} | {row['typescript']['utf8_bytes']} | {row['classification']} |")
boundary = json.loads((ROOT / 'boundary-comparison.json').read_text())
lines += ['', '## 11 个额外输入/选项边界', '',
          '| 具名输入 | 条款 | 原 Python 结果 | 当前 TS 结果 | 归类 |',
          '| --- | --- | --- | --- | --- |']
for row in boundary['cases']:
    py_status = row['python'].get('error_type', 'output')
    ts_status = row['typescript'].get('error_type', 'output')
    lines.append(f"| {row['id']} | {row['rule']} | {py_status} | {ts_status} | {row['classification']} |")
(ROOT / 'CASE-RESULTS.md').write_text('\n'.join(lines) + '\n')

source_paths = [ROOT / r['path'] for r in json.loads((ROOT / 'source-manifest.json').read_text())['files']]
source_paths += [ROOT / r['path'] for r in json.loads((ROOT / 'hub-source-manifest.json').read_text())['files']]
source_rows = [record(path) for path in sorted(source_paths)]
with tarfile.open(ROOT / 'source-input.tar.gz', 'w:gz') as archive:
    for path in sorted(source_paths):
        archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
with tarfile.open(ROOT / 'source-input.tar.gz', 'r:gz') as archive:
    expected = {r['path']: r for r in source_rows}
    assert len(archive.getmembers()) == len(expected)
    for member in archive:
        assert member.isfile() and member.name in expected
        payload = archive.extractfile(member).read()
        assert hashlib.sha256(payload).hexdigest() == expected[member.name]['sha256']
source_manifest = {'archive': record(ROOT / 'source-input.tar.gz'), 'files': source_rows,
                   'actual_tar_payloads_read_and_hashed': True}
(ROOT / 'source-tar-manifest.json').write_text(json.dumps(source_manifest, indent=2) + '\n')

excluded_names = {'manifest.json', 'SHA256SUMS', 'evidence.tar.gz', 'bundle-verification.json'}
payloads = []
for path in sorted(ROOT.rglob('*')):
    relative = path.relative_to(ROOT)
    if any(part in ('.venv', 'node_modules', '__pycache__') for part in relative.parts):
        continue
    if path.is_file() and not path.is_symlink() and path.name not in excluded_names:
        payloads.append(path)
manifest = {'scope': 'U1 fixed-Python finite formatter differential; no implementation/acceptance changes',
            'golden_inputs_executed': 99, 'boundary_inputs_executed': 11,
            'unexpected_differences': 0, 'unexecuted': 0,
            'files': [record(path) for path in payloads],
            'excluded_rebuildable': ['.venv/**', 'node_modules/**', '**/__pycache__/**']}
(ROOT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
payloads.append(ROOT / 'manifest.json')
checksum_rows = [record(path) for path in sorted(payloads)]
(ROOT / 'SHA256SUMS').write_text(''.join(f"{r['sha256']}  {r['path']}\n" for r in checksum_rows))
payloads.append(ROOT / 'SHA256SUMS')

with tarfile.open(ROOT / 'evidence.tar.gz', 'w:gz') as archive:
    for path in sorted(payloads):
        archive.add(path, arcname=str(path.relative_to(ROOT)), recursive=False)
expected = {str(path.relative_to(ROOT)): digest(path) for path in payloads}
with tarfile.open(ROOT / 'evidence.tar.gz', 'r:gz') as archive:
    assert len(archive.getmembers()) == len(expected)
    for member in archive:
        assert member.isfile()
        assert not member.name.startswith('/') and '..' not in pathlib.PurePosixPath(member.name).parts
        assert member.name in expected
        payload = archive.extractfile(member).read()
        assert hashlib.sha256(payload).hexdigest() == expected[member.name]
verification = {'evidence_archive': record(ROOT / 'evidence.tar.gz'),
                'manifest': record(ROOT / 'manifest.json'), 'SHA256SUMS': record(ROOT / 'SHA256SUMS'),
                'source_archive': record(ROOT / 'source-input.tar.gz'),
                'source_archive_payloads_verified': len(source_paths),
                'full_archive_payloads_verified': len(payloads),
                'all_members_regular_safe_readable_and_hash_equal': True}
(ROOT / 'bundle-verification.json').write_text(json.dumps(verification, indent=2) + '\n')
print(json.dumps(verification))
