"""Run only the finite formatter references and consumers, with actual invocations."""
import datetime
import hashlib
import importlib.metadata
import json
import os
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
HUB = ROOT.parents[2]


def hash_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def observe():
    paths = subprocess.check_output(['git', '-C', str(HUB), 'ls-files', '--',
                                     'packages/util/unix-format', 'packages/util/xml-format']).decode().splitlines()
    paths += [str(p.relative_to(HUB)) for pkg in ('unix-format', 'xml-format')
              for p in (HUB / 'packages/util' / pkg / 'dist').rglob('*') if p.is_file()]
    return {p: hash_file(HUB / p) for p in sorted(paths)}


before = observe()
commands = [
    (['node', str(ROOT / 'run-current-ts.mjs')], 0, 'final-typescript'),
    ([str(ROOT / '.venv/bin/python'), str(ROOT / 'run-reference.py')], 0, 'final-python'),
    ([str(ROOT / '.venv/bin/python'), str(ROOT / 'compare.py')], 0, 'final-comparison'),
    ([str(ROOT / '.venv/bin/python'), str(ROOT / 'compare.py'), '--typescript', str(ROOT / 'control-extra-newline.json'),
      '--output', str(ROOT / 'control-extra-newline-result.json')], 1, 'final-control-extra-newline'),
    ([str(ROOT / '.venv/bin/python'), str(ROOT / 'compare.py'), '--typescript', str(ROOT / 'control-hidden-date-delta.json'),
      '--output', str(ROOT / 'control-hidden-date-delta-result.json')], 1, 'final-control-hidden-date-delta'),
    (['node', str(ROOT / 'run-boundaries.mjs')], 0, 'final-boundary-typescript'),
    ([str(ROOT / '.venv/bin/python'), str(ROOT / 'run-reference.py'), '--input', str(ROOT / 'boundary-inputs.json'),
      '--output', str(ROOT / 'boundary-python-results.json')], 1, 'final-boundary-python'),
    ([str(ROOT / '.venv/bin/python'), str(ROOT / 'compare-boundaries.py')], 0, 'final-boundary-comparison'),
]
invocations = []
for command, expected_exit, label in commands:
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    proc = subprocess.run(command, cwd=HUB, capture_output=True)
    end = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (ROOT / f'{label}.stdout.log').write_bytes(proc.stdout)
    (ROOT / f'{label}.stderr.log').write_bytes(proc.stderr)
    if label == 'final-typescript':
        data = json.loads((ROOT / 'typescript-results.json').read_text())
        for case in data['cases']:
            if case['id'] == 'unix-format/error_plain':
                case['output'] += '\n'
        (ROOT / 'control-extra-newline.json').write_text(json.dumps(data, indent=2) + '\n')
        data = json.loads((ROOT / 'typescript-results.json').read_text())
        for case in data['cases']:
            if case['id'] == 'xml-format/date_default':
                case['output'] = '<event occurred_at="2024-01-15T10:30:00+00:00"/>'
        (ROOT / 'control-hidden-date-delta.json').write_text(json.dumps(data, indent=2) + '\n')
    if label == 'final-boundary-python':
        (ROOT / 'boundary-python-exit.txt').write_text(str(proc.returncode) + '\n')
    invocation = {'argv': command, 'cwd': str(HUB), 'started_utc': start, 'ended_utc': end,
                  'actual_exit': proc.returncode, 'expected_exit': expected_exit,
                  'stdout': f'{label}.stdout.log', 'stderr': f'{label}.stderr.log'}
    invocations.append(invocation)
    (ROOT / 'invocations.json').write_text(json.dumps(invocations, indent=2) + '\n')
    assert proc.returncode == expected_exit, invocation
    if label == 'final-control-extra-newline':
        assert b'AssertionError: unix-format/error_plain' in proc.stderr, 'wrong negative-control cause'
        assert not (ROOT / 'control-extra-newline-result.json').exists()
    if label == 'final-control-hidden-date-delta':
        assert b'AssertionError: xml-format/date_default' in proc.stderr, 'wrong negative-control cause'
        assert not (ROOT / 'control-hidden-date-delta-result.json').exists()

after = observe()
assert before == after, 'Formatter maintained/dist bytes changed during the reference execution'
source = json.loads((ROOT / 'source-manifest.json').read_text())
for row in source['files']:
    assert hash_file(ROOT / row['path']) == row['sha256'], row['source']
dependencies = json.loads((ROOT / 'python-dependencies.json').read_text())
for dependency in dependencies:
    assert importlib.metadata.version(dependency['name']) == dependency['version']
state = {'hub': str(HUB), 'branch': subprocess.check_output(['git', '-C', str(HUB), 'branch', '--show-current']).decode().strip(),
         'head': subprocess.check_output(['git', '-C', str(HUB), 'rev-parse', 'HEAD']).decode().strip(),
         'maintained_and_dist_before': before, 'maintained_and_dist_after': after,
         'all_formatter_bytes_unchanged_during_execution': True,
         'python_dependency_versions_verified_against_fixed_lock': True,
         'fixed_python_source_hashes_verified': True}
(ROOT / 'execution-state.json').write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps({'commands_executed': len(invocations), 'head': state['head'], 'formatter_files_hashed': len(before),
                  'golden_cases': 99, 'boundary_cases': 11, 'unexpected_exits': 0}))
