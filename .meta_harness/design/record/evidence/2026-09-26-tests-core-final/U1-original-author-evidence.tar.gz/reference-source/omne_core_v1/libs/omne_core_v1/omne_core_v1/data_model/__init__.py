"""Data Model Kernel — ADR-000 §2 Dim 2.

Provides the foundation data model infrastructure for the OMNE system:
ContextBlock V2/V1 base classes, serialization registry with LangChain
interop, and XML formatting framework for LLM-consumable output.
"""

from __future__ import annotations

from .context_block import (
    AnySerializable as AnySerializable,
)
from .context_block import (
    BaseContextBlock as BaseContextBlock,
)
from .context_block import (
    ContextBlock as ContextBlock,
)
from .context_block import (
    ensure_latest_version_schema as ensure_latest_version_schema,
)
from .legacy_block import (
    ContextBlockMetadata as ContextBlockMetadata,
)
from .legacy_block import (
    ContextBlockStatus as ContextBlockStatus,
)
from .legacy_block import (
    LegacyContextBlock as LegacyContextBlock,
)
from .registry import (
    SERIALIZABLE_REGISTRY as SERIALIZABLE_REGISTRY,
)
from .registry import (
    LcCompatibleSerializeMixin as LcCompatibleSerializeMixin,
)
from .registry import (
    register_serializable as register_serializable,
)
from .xml_format import (
    XMLFormatMixin as XMLFormatMixin,
)
from .xml_format import (
    XMLFormattable as XMLFormattable,
)
