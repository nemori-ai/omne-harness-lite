"""Type definitions for XML formatting of context blocks.

This module defines the core types used for declaring how context block fields
should be formatted into XML output.
"""

from __future__ import annotations

from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field


class FieldPresentation(str, Enum):
    """How a field should be presented in XML output.

    Attributes:
        ATTR: Render as XML attribute: ``<tag field="value" />``.
        ELEMENT: Render as child element: ``<tag><field>value</field></tag>``.
        CONTENT: Render as tag content: ``<tag>value</tag>``.
    """

    ATTR = "attr"
    ELEMENT = "element"
    CONTENT = "content"


class FieldSpec(BaseModel):
    """Specification for how a single field should be formatted.

    Attributes:
        presentation: How to present the field in XML output.
        xml_name: Override XML element/attribute name. If None, uses field name.
        include_when: Condition for including this field in output.
        attrs: Additional XML attributes for ELEMENT presentation.
        nested_fields: For nested objects, specify inner field formatting.
        item_tag: For list fields, the XML tag name for each item.
        item_fields: For list of complex objects, which fields to include
            and how.

    Examples:
        ```python
        from omne_core_v1.data_model.xml_format.types import (
            FieldPresentation,
            FieldSpec,
        )

        FieldSpec(presentation=FieldPresentation.ATTR)

        FieldSpec(presentation=FieldPresentation.ELEMENT, xml_name="custom_name")

        FieldSpec(presentation=FieldPresentation.ELEMENT, include_when="not_empty")

        FieldSpec(
            presentation=FieldPresentation.ELEMENT,
            xml_name="conditions",
            include_when="not_empty",
            attrs={"logic": "OR"},
        )

        FieldSpec(
            presentation=FieldPresentation.ELEMENT,
            xml_name="topics",
            include_when="not_empty",
            item_tag="topic",
            item_fields={"title": "attr", "content": "element"},
        )
        ```
    """

    presentation: FieldPresentation = Field(default=FieldPresentation.ELEMENT)
    """Default presentation style for this field."""

    xml_name: str | None = Field(default=None)
    """Override XML element/attribute name. None uses the field name."""

    include_when: Literal["always", "not_none", "not_empty", "not_default"] = Field(default="always")
    """Condition for including this field in output.

    - always: Always include the field.
    - not_none: Include only if value is not None.
    - not_empty: Include only if value is not None and not empty
      (for str, list, dict).
    - not_default: Include only if value differs from field default.
    """

    attrs: dict[str, str] | None = Field(default=None)
    """Additional XML attributes when presentation is ELEMENT.

    Example: ``{"logic": "OR"}`` will render as
    ``<element logic="OR">...</element>``.
    Only effective when presentation is ``FieldPresentation.ELEMENT``.
    """

    nested_fields: dict[str, FieldSpec] | None = Field(default=None)
    """For nested objects (like metadata), specify inner field formatting."""

    item_tag: str | None = Field(default=None)
    """For list fields, the XML tag name for each item. If None, uses singular form."""

    item_fields: dict[str, Literal["attr", "element", "content"]] | None = Field(default=None)
    """For list of complex objects, which fields to include and how to present them.

    Maps field names to presentation style:

    - ``"attr"``: Render as XML attribute.
    - ``"element"``: Render as child element.
    - ``"content"``: Render as tag content.

    If None, complex objects are rendered with all fields as elements.
    """


# Type aliases for clarity
type RequiredFields = dict[str, FieldSpec]
"""Dictionary mapping field names to their formatting specifications.

Required fields are always included in the XML output regardless of
runtime options.
"""

type OptionalFields = dict[str, FieldSpec]
"""Dictionary mapping field names to their formatting specifications.

Optional fields can be selectively included via runtime FormattingOptions.
"""


__all__ = [
    "FieldPresentation",
    "FieldSpec",
    "OptionalFields",
    "RequiredFields",
]
