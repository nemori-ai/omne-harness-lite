"""Man-page-style section renderers.

Renders structured help output resembling Unix ``man`` pages:

- ``format_section(title, body)`` → ``## TITLE`` or ``TITLE:`` header + indented body
- ``format_usage(tool_name, command, params_synopsis)`` → single-line USAGE synopsis
- ``format_command_list(entries)`` → column-aligned command table for overview help

All helpers honor ``UnixFormatOptions`` for indentation and markdown compatibility.
"""

from __future__ import annotations

from textwrap import indent as text_indent

from omne_core_v1.data_model.unix_format.options import UnixFormatOptions

__all__ = [
    "format_command_list",
    "format_section",
    "format_usage",
]


def format_section(title: str, body: str, *, options: UnixFormatOptions | None = None) -> str:
    """Render a titled section with indented body.

    Args:
        title: Section heading (uppercased by convention, e.g. "SYNOPSIS").
        body: Section contents; may contain newlines.
        options: Render configuration; defaults to ``UnixFormatOptions()``.

    Returns:
        Multi-line string with header on the first line followed by the
        indented body.
    """
    opts = options or UnixFormatOptions()
    header = f"## {title}" if opts.markdown_compatible else f"{title}:"
    padding = " " * opts.indent
    indented_body = text_indent(body, padding)
    return f"{header}\n{indented_body}"


def format_usage(tool_name: str, command: str, params_synopsis: str) -> str:
    """Render a single-line USAGE example.

    Args:
        tool_name: Name of the tool being documented.
        command: Sub-command identifier embedded in double quotes.
        params_synopsis: Rendered parameter synopsis (inserted verbatim).

    Returns:
        Single-line string of shape
        ``'USAGE: tool_name(command="command", params=<params_synopsis>)'``.
    """
    return f'USAGE: {tool_name}(command="{command}", params={params_synopsis})'


def format_command_list(entries: list[tuple[str, str, str]]) -> str:
    """Render a column-aligned command list for overview help.

    Args:
        entries: Sequence of ``(name, synopsis, description)`` triples. Each
            triple becomes one output line with three columns aligned to the
            widest element in each column.

    Returns:
        Multi-line string. Empty input → empty string.
    """
    if not entries:
        return ""
    name_w = max(len(name) for name, _, _ in entries)
    synopsis_w = max(len(synopsis) for _, synopsis, _ in entries)
    return "\n".join(f"  {name:<{name_w}}  {synopsis:<{synopsis_w}}  — {desc}" for name, synopsis, desc in entries)
