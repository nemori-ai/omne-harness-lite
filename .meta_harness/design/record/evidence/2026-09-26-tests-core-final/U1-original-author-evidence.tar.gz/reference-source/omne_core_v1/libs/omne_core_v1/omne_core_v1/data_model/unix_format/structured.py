"""Structured-data renderers: tables, key-value pairs, bullet lists.

All renderers emit plain ASCII with predictable alignment suitable for
LLM consumption. No ANSI color codes; no Unicode box-drawing characters.

Alignment is computed by code-point count; content containing East Asian
wide characters or emoji may visually misalign in terminals that use
display-width-based rendering. This is a known limitation — generally
acceptable for LLM consumption.
"""

from __future__ import annotations

from omne_core_v1.data_model.unix_format.options import UnixFormatOptions

__all__ = [
    "format_bullet_list",
    "format_key_value",
    "format_table",
]


def format_table(
    headers: list[str],
    rows: list[tuple[str, ...]],
    *,
    options: UnixFormatOptions | None = None,
    max_width: int | None = None,
) -> str:
    """Render a fixed-width ASCII table.

    Columns are sized to the widest content (header or cell) per column.
    When total width exceeds the effective ``max_width``, the last column
    is shrunk (never below 3 — the minimum to fit ``...``) and overflowing
    cells are truncated with a trailing ellipsis.

    Args:
        headers: Column headers; at least one required. An empty list
            produces an empty string.
        rows: Data rows. Each row MUST contain exactly ``len(headers)``
            cells; otherwise a ``ValueError`` is raised.
        options: Render configuration. If omitted, defaults apply.
        max_width: Explicit width cap overriding ``options.max_width``.
            Pass ``0`` to disable the cap entirely.

    Returns:
        Multi-line string with header row, separator row, and one row per
        entry in ``rows``. Empty ``headers`` returns ``""``.

    Raises:
        ValueError: If any row's cell count differs from ``len(headers)``.

    Note:
        When column content combined with separators cannot fit within
        ``max_width`` even after shrinking the last column to the ``...``
        minimum, the rendered table will exceed ``max_width``. This is
        best-effort behavior — adjust ``max_width`` upward if strict
        bounding is required.

        Alignment is computed by code-point count; content containing
        East Asian wide characters or emoji may visually misalign in
        terminals that use display-width-based rendering.
    """
    if not headers:
        return ""

    expected = len(headers)
    for idx, row in enumerate(rows):
        if len(row) != expected:
            raise ValueError(f"row {idx} has {len(row)} cells, expected {expected}")

    opts = options or UnixFormatOptions()
    effective_width = max_width if max_width is not None else opts.max_width

    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(cell))

    if effective_width > 0:
        total = sum(col_widths) + 2 * (len(col_widths) - 1)
        if total > effective_width:
            overflow = total - effective_width
            # Shrink the last column, never below 3 (to fit "...").
            col_widths[-1] = max(3, col_widths[-1] - overflow)

    def _format_row(row: tuple[str, ...]) -> str:
        cells: list[str] = []
        for i, cell in enumerate(row):
            w = col_widths[i]
            if len(cell) > w:
                cells.append(cell[: w - 3] + "...")
            else:
                cells.append(cell.ljust(w))
        return "  ".join(cells)

    header_line = _format_row(tuple(headers))
    separator = "  ".join("-" * w for w in col_widths)
    body_lines = [_format_row(row) for row in rows]
    return "\n".join([header_line, separator, *body_lines])


def format_key_value(pairs: dict[str, str]) -> str:
    """Render a key-value listing with colon-aligned keys.

    Keys are right-padded to the widest key so all colons align vertically.

    Args:
        pairs: Ordered mapping of key → value strings.

    Returns:
        Multi-line string; empty input returns ``""``.

    Note:
        Values containing newlines are emitted as-is without indentation
        continuation; multi-line values may be misread as additional
        entries. Callers needing multi-line values should pre-format with
        explicit continuation indent.

        Alignment is computed by code-point count; wide characters may
        visually misalign in display-width-based terminals.
    """
    if not pairs:
        return ""
    key_width = max(len(k) for k in pairs)
    return "\n".join(f"{key.ljust(key_width)}: {value}" for key, value in pairs.items())


def format_bullet_list(items: list[str]) -> str:
    """Render a dash-prefixed bullet list.

    Args:
        items: Bullet items, one per entry.

    Returns:
        Multi-line string with each item prefixed by ``- ``; empty input
        returns ``""``.

    Note:
        Items containing newlines are emitted as-is without continuation
        indent; multi-line items may be misread as additional bullets.
        Callers needing multi-line items should pre-format with explicit
        continuation indent.
    """
    if not items:
        return ""
    return "\n".join(f"- {item}" for item in items)
