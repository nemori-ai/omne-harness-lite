"""Context block XML transformer.

This module provides the ContextBlockXMLTransformer class that transforms
context blocks into formatted XML output suitable for LLM consumption.

This transformer is designed to be protocol-based and type-agnostic:
- Works with any object implementing the ``BaseContextBlock`` protocol
- No hard-coded dependencies on specific block types
- Fallback mechanisms ensure compatibility with minimal protocol implementations

Required protocol attributes:
    - id: str
    - category: str
    - kind: str
    - created_at: datetime

Optional protocol methods (with fallbacks):
    - get_namespace() -> str: Falls back to "{category}.{kind}"
    - get_xml_tag() -> str: Falls back to "{category}_{kind}"
"""

from __future__ import annotations

import re
from collections import defaultdict
from textwrap import indent as text_indent
from typing import TYPE_CHECKING, Literal
from xml.sax.saxutils import escape as xml_escape

from pydantic import BaseModel, Field

from ...time.utils import get_utc_now
from .mixin import XMLFormattable
from .options import FormattingOptions

# Quote-escaping map for xml_escape when used in attribute values
_ATTR_QUOTE_ESCAPES: dict[str, str] = {'"': "&quot;", "'": "&apos;"}

# Pattern restricting valid XML tag names to safe characters
_SAFE_XML_TAG_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_.\-]*$")

if TYPE_CHECKING:
    from collections.abc import Sequence

    from ..context_block import BaseContextBlock

# Type alias for block ordering specification
BlockOrdering = (
    Literal["chronological", "by_priority"] | list[str]  # List of semantic tags/namespaces
)


class ContextAssemblyProtocol(BaseModel):
    """Protocol for assembling context blocks into formatted output.

    This protocol defines how to organize, order, and format context blocks
    for LLM consumption.

    Attributes:
        ordering: How to order context blocks.
        grouping: How to group blocks in output.
        section_headers: Whether to add section headers.
        max_blocks: Maximum number of blocks to include.
        include_timestamps: Whether to include timestamp fields.
        section_descriptions: Optional descriptions for sections.

    Examples:
        ```python
        from omne_core_v1.data_model.xml_format import ContextAssemblyProtocol

        protocol = ContextAssemblyProtocol(
            ordering=["user.instruction", "chat.message"],
            grouping="flat",
            max_blocks=50,
        )
        ```
    """

    ordering: BlockOrdering = Field(
        default=[
            "world_observation.world_observation",
            "chat.period_summary",
            "chat.session_summary",
            "user.portrait",
            "user.instruction",
        ],
        description=(
            "How to order context blocks. Options: "
            "'chronological' (sort by time), "
            "'by_priority' (sort by importance), "
            "or a list of semantic tags to define custom order."
        ),
    )

    grouping: Literal["by_namespace", "by_category", "by_time", "flat"] = Field(
        default="by_namespace",
        description=(
            "How to group blocks in output. Options: "
            "'by_namespace' (group by namespace, e.g., user.instruction), "
            "'by_category' (group by block category, e.g., user, chat), "
            "'by_time' (group by temporal characteristics), "
            "'flat' (no grouping, linear sequence)"
        ),
    )

    section_headers: bool = Field(
        default=True,
        description="Whether to add section headers in the XML output",
    )

    max_blocks: int | None = Field(
        default=None,
        ge=1,
        description="Maximum number of blocks to include. None means no limit.",
    )

    include_timestamps: bool = Field(
        default=True,
        description="Whether to include timestamp information in output",
    )

    section_descriptions: dict[str, str] = Field(
        default_factory=dict,
        description="Optional descriptions for sections",
    )


class ContextBlockXMLTransformer:
    """Transforms context blocks into formatted XML output.

    This transformer orchestrates the formatting of multiple context blocks
    into a coherent XML structure. It delegates individual block formatting
    to each block's ``to_xml()`` method (via XMLFormatMixin) and handles
    sorting, grouping, and assembly.

    This class is protocol-based and works with any object that implements
    the ``BaseContextBlock`` protocol. It does not depend on any specific
    block implementations, ensuring extensibility for custom block types.

    For blocks implementing ``XMLFormattable`` (i.e., having a ``to_xml()``
    method), the transformer delegates formatting to the block itself.
    For other blocks, a default formatter is used based on protocol attributes.

    Attributes:
        indent_size: Number of spaces per indentation level.
        type_options: Per-type formatting options for batch formatting.

    Examples:
        ```python
        from omne_core_v1.data_model.xml_format import (
            ContextBlockXMLTransformer,
            FormattingOptions,
        )

        transformer = ContextBlockXMLTransformer(indent_size=2)
        xml = transformer.format_block(user_instruction)

        transformer = ContextBlockXMLTransformer(
            type_options={
                "user.instruction": FormattingOptions(extra_fields={"timeliness"}),
                "user.portrait": FormattingOptions(
                    extra_fields={"metadata.type", "metadata.confidence"},
                ),
            }
        )
        context_xml = transformer.format_context(blocks)
        ```
    """

    def __init__(
        self,
        indent_size: int = 2,
        type_options: dict[str, FormattingOptions] | None = None,
    ):
        """Initialize the transformer.

        Args:
            indent_size: Number of spaces for each indentation level.
            type_options: Per-type formatting options. Maps block namespace
                (e.g., 'user.instruction') to FormattingOptions for that type.
                Used when format_block/format_context is called without
                explicit options.
        """
        self.indent_size = indent_size
        self.type_options = type_options or {}

    def format_block(
        self,
        block: BaseContextBlock,
        options: FormattingOptions | None = None,
        *,
        type_options: dict[str, FormattingOptions] | None = None,
    ) -> str:
        """Format a single block to XML string.

        If the block implements XMLFormattable (has to_xml method), delegates
        to that method. Otherwise, uses a fallback default formatter.

        Options resolution order:
            1. Explicit ``options`` parameter (if provided)
            2. ``type_options`` parameter lookup by block namespace
            3. ``self.type_options`` lookup by block namespace
            4. Default FormattingOptions

        Args:
            block: The context block to format.
            options: Explicit formatting options for this block.
                If provided, used directly without type lookup.
            type_options: Per-type options mapping. If provided, overrides
                self.type_options for this call.

        Returns:
            Formatted XML string for the block.

        Examples:
            ```python
            xml = transformer.format_block(instruction)
            xml = transformer.format_block(instruction, my_options)
            xml = transformer.format_block(
                instruction,
                type_options={"user.instruction": custom_opts},
            )
            ```
        """
        # Resolve options: explicit > call-level type_options > instance type_options > default
        if options is None:
            namespace = self._get_block_namespace(block)
            # Merge type_options: call-level overrides instance-level
            effective_type_options = {**self.type_options, **(type_options or {})}
            options = effective_type_options.get(
                namespace,
                FormattingOptions(indent_size=self.indent_size),
            )

        # Check if block implements XMLFormattable
        if isinstance(block, XMLFormattable):
            return block.to_xml(options)

        # Fallback for blocks without XMLFormatMixin
        return self._default_format_block(block, options)

    def format_context(
        self,
        blocks: Sequence[BaseContextBlock],
        protocol: ContextAssemblyProtocol | None = None,
        *,
        type_options: dict[str, FormattingOptions] | None = None,
        default_options: FormattingOptions | None = None,
    ) -> str:
        """Format multiple blocks into a complete context XML.

        Each block is formatted using options resolved in this order:
            1. ``type_options`` parameter lookup by block namespace
            2. ``self.type_options`` lookup by block namespace
            3. ``default_options`` parameter (if provided)
            4. Auto-generated default FormattingOptions

        Args:
            blocks: List of context blocks to format.
            protocol: Assembly protocol to use. If None, uses defaults.
            type_options: Per-type options mapping for this call.
                Overrides self.type_options. Key is block namespace
                (e.g., 'user.instruction'), value is FormattingOptions.
            default_options: Fallback options for blocks without type_options.
                If None, creates from protocol settings.

        Returns:
            Complete XML string ready for LLM prompt.

        Examples:
            ```python
            xml = transformer.format_context(blocks)

            protocol = ContextAssemblyProtocol(ordering="chronological")
            xml = transformer.format_context(blocks, protocol)

            xml = transformer.format_context(
                blocks,
                type_options={
                    "user.instruction": FormattingOptions(
                        extra_fields={"timeliness"},
                    ),
                    "user.portrait": FormattingOptions(
                        extra_fields={"metadata.type"},
                    ),
                },
            )

            xml = transformer.format_context(
                blocks,
                default_options=FormattingOptions(include_timestamps=False),
            )
            ```
        """
        if protocol is None:
            protocol = ContextAssemblyProtocol()

        # Merge type_options: call-level overrides instance-level
        effective_type_options = {**self.type_options, **(type_options or {})}

        # Build default options if not provided
        if default_options is None:
            default_options = FormattingOptions(
                indent_size=self.indent_size,
                include_timestamps=protocol.include_timestamps,
            )

        # 1. Sort blocks according to protocol
        sorted_blocks = self._sort_blocks(blocks, protocol.ordering)

        # 2. Limit number of blocks if specified
        if protocol.max_blocks and len(sorted_blocks) > protocol.max_blocks:
            sorted_blocks = self._truncate_blocks(sorted_blocks, protocol.max_blocks)

        # 3. Group blocks according to protocol
        grouped = self._group_blocks(sorted_blocks, protocol)

        # 4. Build final XML
        return self._build_context_xml(grouped, protocol, effective_type_options, default_options)

    def _sort_blocks(
        self,
        blocks: Sequence[BaseContextBlock],
        ordering: BlockOrdering,
    ) -> Sequence[BaseContextBlock]:
        """Sort blocks according to ordering specification.

        For LLMs, more important and newer content should appear LAST
        due to recency bias - LLMs pay more attention to content near
        the end.

        Args:
            blocks: Blocks to sort.
            ordering: Ordering specification.

        Returns:
            Sorted list of blocks.
        """
        if ordering == "chronological":
            return sorted(blocks, key=lambda b: b.created_at)

        if ordering == "by_priority":
            # For now, sort by time (older first, newer last)
            return sorted(blocks, key=lambda b: (0, b.created_at))

        if isinstance(ordering, list) and ordering:
            # List of semantic tags/namespaces
            priority_map = {tag: idx for idx, tag in enumerate(ordering)}
            return sorted(
                blocks,
                key=lambda b: (
                    priority_map.get(self._get_block_namespace(b), -1),
                    b.created_at,
                ),
            )

        return blocks

    def _truncate_blocks(
        self,
        blocks: Sequence[BaseContextBlock],
        max_blocks: int,
    ) -> Sequence[BaseContextBlock]:
        """Truncate blocks list to max_blocks.

        Keeps the last max_blocks blocks since more recent/important
        content should be at the end.

        Args:
            blocks: Blocks to truncate.
            max_blocks: Maximum number to keep.

        Returns:
            Truncated list of blocks.
        """
        return blocks[-max_blocks:]

    def _group_blocks(
        self,
        blocks: Sequence[BaseContextBlock],
        protocol: ContextAssemblyProtocol,
    ) -> dict[str, Sequence[BaseContextBlock]]:
        """Group blocks according to protocol grouping strategy.

        Args:
            blocks: Sorted blocks to group.
            protocol: Assembly protocol with grouping setting.

        Returns:
            Dictionary mapping group names to lists of blocks.
        """
        match protocol.grouping:
            case "flat":
                return {"context": blocks}
            case "by_namespace":
                return self._group_by_namespace(blocks, protocol.ordering)
            case "by_category":
                return self._group_by_category(blocks, protocol.ordering)
            case "by_time":
                return self._group_by_time(blocks)
            case _:
                return {"context": blocks}

    def _group_by_namespace(
        self,
        blocks: Sequence[BaseContextBlock],
        ordering: BlockOrdering,
    ) -> dict[str, Sequence[BaseContextBlock]]:
        """Group blocks by their namespace.

        Args:
            blocks: Blocks to group.
            ordering: Ordering specification for group order.

        Returns:
            Ordered dictionary mapping namespace to list of blocks.
        """
        temp_groups: dict[str, list[BaseContextBlock]] = defaultdict(list)
        for block in blocks:
            namespace = self._get_block_namespace(block)
            temp_groups[namespace].append(block)

        # Determine group order
        if isinstance(ordering, list) and ordering:
            namespace_order = list(ordering)
            # Add any namespaces not in ordering
            for ns in temp_groups:
                if ns not in namespace_order:
                    namespace_order.append(ns)
        else:
            namespace_order = list(temp_groups.keys())

        # Build ordered dict
        ordered: dict[str, Sequence[BaseContextBlock]] = {}
        for ns in namespace_order:
            if ns in temp_groups:
                ordered[ns] = temp_groups[ns]

        return ordered

    def _group_by_category(
        self,
        blocks: Sequence[BaseContextBlock],
        ordering: BlockOrdering,
    ) -> dict[str, Sequence[BaseContextBlock]]:
        """Group blocks by their category.

        Args:
            blocks: Blocks to group.
            ordering: Ordering specification for group order.

        Returns:
            Ordered dictionary mapping category to list of blocks.
        """
        temp_groups: dict[str, list[BaseContextBlock]] = defaultdict(list)
        for block in blocks:
            category = str(block.category)
            temp_groups[category].append(block)

        # Determine category order from ordering (extract categories from namespaces)
        category_order: list[str] = []
        seen: set[str] = set()

        if isinstance(ordering, list):
            for item in ordering:
                category = str(item).split(".")[0] if "." in str(item) else str(item)
                if category not in seen:
                    category_order.append(category)
                    seen.add(category)

        # Add remaining categories
        for cat in temp_groups:
            if cat not in seen:
                category_order.append(cat)  # noqa: PERF401

        # Build ordered dict
        ordered: dict[str, Sequence[BaseContextBlock]] = {}
        for cat in category_order:
            if cat in temp_groups:
                ordered[cat] = temp_groups[cat]

        return ordered

    def _group_by_time(
        self,
        blocks: Sequence[BaseContextBlock],
    ) -> dict[str, Sequence[BaseContextBlock]]:
        """Group blocks by temporal characteristics.

        Args:
            blocks: Blocks to group.

        Returns:
            Ordered dictionary with time-based group names.
        """
        groups: dict[str, list[BaseContextBlock]] = {
            "long_term": [],
            "medium_term": [],
            "recent": [],
        }

        now = get_utc_now()

        for block in blocks:
            time_diff = now - block.created_at
            if time_diff.days > 30:
                groups["long_term"].append(block)
            elif time_diff.days > 7:
                groups["medium_term"].append(block)
            else:
                groups["recent"].append(block)

        # Return only non-empty groups
        return {k: v for k, v in groups.items() if v}

    def _build_context_xml(
        self,
        grouped: dict[str, Sequence[BaseContextBlock]],
        protocol: ContextAssemblyProtocol,
        type_options: dict[str, FormattingOptions],
        default_options: FormattingOptions,
    ) -> str:
        """Build final XML from grouped blocks.

        Args:
            grouped: Dictionary of grouped blocks.
            protocol: Assembly protocol.
            type_options: Effective per-type options (already merged).
            default_options: Fallback options for blocks without type_options.

        Returns:
            Complete XML string.
        """
        prefix = " " * self.indent_size
        parts: list[str] = ["<context>"]

        for section_name, section_blocks in grouped.items():
            # Format all blocks in this section
            block_xmls: list[str] = []
            for block in section_blocks:
                namespace = self._get_block_namespace(block)
                block_options = type_options.get(namespace, default_options)
                block_xmls.append(self.format_block(block, block_options))

            blocks_content = "\n".join(block_xmls)

            # Add section wrapper if enabled
            if protocol.section_headers and section_name != "context":
                escaped_section = xml_escape(section_name, _ATTR_QUOTE_ESCAPES)
                section_attrs = [f'type="{escaped_section}"']

                # Add description if available
                if section_name in protocol.section_descriptions:
                    desc = xml_escape(protocol.section_descriptions[section_name], _ATTR_QUOTE_ESCAPES)
                    section_attrs.append(f'description="{desc}"')

                # Indent blocks twice (once for section, once for content)
                indented_blocks = text_indent(blocks_content, prefix)
                section_content = f"<section {' '.join(section_attrs)}>\n{indented_blocks}\n</section>"
                parts.append(text_indent(section_content, prefix))
            else:
                # No section wrapper, just indent blocks once
                parts.append(text_indent(blocks_content, prefix))

        parts.append("</context>")
        return "\n".join(parts)

    def _get_block_namespace(self, block: BaseContextBlock) -> str:
        """Get the namespace of a block.

        Args:
            block: The context block.

        Returns:
            Block namespace string.
        """
        if hasattr(block, "get_namespace"):
            return block.get_namespace()
        return f"{block.category}.{block.kind}"

    def _default_format_block(
        self,
        block: BaseContextBlock,
        options: FormattingOptions,
    ) -> str:
        """Default formatter for blocks without XMLFormatMixin.

        Provides a basic XML representation for blocks that don't implement
        the XMLFormattable protocol.

        Args:
            block: The context block.
            options: Formatting options.

        Returns:
            Basic XML representation.
        """
        # Get tag name and sanitize to prevent XML injection
        tag = block.get_xml_tag() if hasattr(block, "get_xml_tag") else f"{block.category}_{block.kind}"
        if not _SAFE_XML_TAG_RE.match(tag):
            tag = re.sub(r"[^a-zA-Z0-9_.\-]", "_", tag)
            # Ensure tag starts with a letter or underscore
            if tag and not tag[0].isalpha() and tag[0] != "_":
                tag = f"_{tag}"

        # Build basic attributes with proper XML escaping
        escaped_id = xml_escape(str(block.id), _ATTR_QUOTE_ESCAPES)
        escaped_type = xml_escape(self._get_block_namespace(block), _ATTR_QUOTE_ESCAPES)
        attrs = [
            f'id="{escaped_id}"',
            f'type="{escaped_type}"',
        ]

        if options.include_timestamps:
            if options.timezone:
                timestamp = block.created_at.astimezone(options.timezone).isoformat()
            else:
                timestamp = block.created_at.isoformat()
            escaped_ts = xml_escape(timestamp, _ATTR_QUOTE_ESCAPES)
            attrs.append(f'created_at="{escaped_ts}"')

        return f"<{tag} {' '.join(attrs)}/>"


__all__ = [
    "BlockOrdering",
    "ContextAssemblyProtocol",
    "ContextBlockXMLTransformer",
]
