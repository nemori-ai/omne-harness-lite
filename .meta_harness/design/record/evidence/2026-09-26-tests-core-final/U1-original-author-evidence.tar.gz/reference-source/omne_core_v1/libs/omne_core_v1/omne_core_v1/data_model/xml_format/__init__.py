"""XML formatting infrastructure for LLM-facing output of context blocks.

Paired with ``data_model/unix_format/`` for Unix-CLI-style plain-text output.
"""

from __future__ import annotations

from .mixin import XMLFormatMixin as XMLFormatMixin
from .mixin import XMLFormattable as XMLFormattable
from .options import (
    FormattingOptions as FormattingOptions,
)
from .options import (
    RuntimeFieldOverride as RuntimeFieldOverride,
)
from .transformer import (
    BlockOrdering as BlockOrdering,
)
from .transformer import (
    ContextAssemblyProtocol as ContextAssemblyProtocol,
)
from .transformer import (
    ContextBlockXMLTransformer as ContextBlockXMLTransformer,
)
from .types import (
    FieldPresentation as FieldPresentation,
)
from .types import (
    FieldSpec as FieldSpec,
)
from .types import (
    OptionalFields as OptionalFields,
)
from .types import (
    RequiredFields as RequiredFields,
)

__all__ = [
    "BlockOrdering",
    "ContextAssemblyProtocol",
    "ContextBlockXMLTransformer",
    "FieldPresentation",
    "FieldSpec",
    "FormattingOptions",
    "OptionalFields",
    "RequiredFields",
    "RuntimeFieldOverride",
    "XMLFormatMixin",
    "XMLFormattable",
]
