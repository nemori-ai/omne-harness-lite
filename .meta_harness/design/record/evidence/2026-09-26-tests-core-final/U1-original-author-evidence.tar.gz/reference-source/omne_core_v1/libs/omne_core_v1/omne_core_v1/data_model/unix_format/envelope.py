"""ERROR / HINT / HOLD / success envelope helpers.

All envelope helpers produce strings consumed by LLMs or emitted as
``BaseTool._arun`` results.
"""

from __future__ import annotations

__all__ = [
    "format_error",
    "format_hold",
    "format_success",
]


def format_error(message: str, *, hint: str | None = None) -> str:
    """Render an ``ERROR`` envelope with optional ``HINT`` footer.

    Args:
        message: What went wrong. May contain newlines.
        hint: Optional actionable suggestion appended as ``\\nHINT: ...``.

    Returns:
        ``"ERROR: {message}"`` optionally followed by ``"\\nHINT: {hint}"``
        when ``hint`` is not ``None``.
    """
    if hint is None:
        return f"ERROR: {message}"
    return f"ERROR: {message}\nHINT: {hint}"


def format_hold(message: str, *, steps: list[str] | None = None) -> str:
    """Render a ``HOLD`` envelope with optional enumerated steps.

    Args:
        message: Pre-action instruction (e.g. "Read the skill first").
        steps: Optional enumerated follow-up steps (1-indexed in output).

    Returns:
        ``"HOLD: {message}"`` optionally followed by a numbered multi-line
        step list when ``steps`` is a non-empty sequence.
    """
    if not steps:
        return f"HOLD: {message}"
    numbered = "\n".join(f"  {i}. {step}" for i, step in enumerate(steps, start=1))
    return f"HOLD: {message}\n{numbered}"


def format_success(message: str, *, hint: str | None = None) -> str:
    """Render an ``OK`` envelope with optional ``HINT`` footer.

    Args:
        message: Positive result description.
        hint: Optional follow-up suggestion.

    Returns:
        ``"OK: {message}"`` optionally followed by ``"\\nHINT: {hint}"``
        when ``hint`` is not ``None``.
    """
    if hint is None:
        return f"OK: {message}"
    return f"OK: {message}\nHINT: {hint}"
