"""Line-numbered text blocks in the shape of ``cat -n``.

A numbered block is not a table with a number column. The difference matters to the
consumer: a table's leftmost column is data, while a line number is an *address* an agent
navigates by — it greps to find one, then asks for the region around it. That is why the
numbering here follows the caller's absolute position rather than restarting per block, and
why truncating an overlong line never splits it into two.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence

    from .options import UnixFormatOptions

__all__ = ["format_numbered_lines"]

_MINIMUM_GUTTER_WIDTH = 6
_TRUNCATION_MARKER = " [truncated]"


def format_numbered_lines(
    lines: Sequence[str],
    *,
    start: int = 1,
    separator: str = "|",
    per_line_char_limit: int | None = None,
    options: UnixFormatOptions | None = None,
) -> str:
    """Render a sequence of lines with a right-aligned line-number gutter.

    Args:
        lines: The lines to render, without trailing newlines.
        start: The absolute number of the first line. A slice of a larger text passes its
            real offset here; restarting at one would make every number a wrong address.
        separator: The mark between the gutter and the content.
        per_line_char_limit: Maximum characters of *content* per line. A longer line is cut
            and marked, and still counts as one line, so the numbering stays an address.
        options: Render configuration. ``max_width`` caps the whole rendered line — gutter,
            separator and content together — matching how the package's table renderer
            bounds its output; ``0`` disables the cap, and passing no options caps nothing.

    Returns:
        The rendered block, or an empty string when ``lines`` is empty.
    """
    if not lines:
        return ""
    width = max(_MINIMUM_GUTTER_WIDTH, len(str(start + len(lines) - 1)))
    max_width = options.max_width if options is not None else 0
    return "\n".join(
        _render_line(
            number=start + offset,
            content=_apply_content_limit(line, per_line_char_limit),
            width=width,
            separator=separator,
            max_width=max_width,
        )
        for offset, line in enumerate(lines)
    )


def _apply_content_limit(line: str, per_line_char_limit: int | None) -> str:
    """Cut an overlong line and mark it, leaving a line at the limit untouched."""
    if per_line_char_limit is None or len(line) <= per_line_char_limit:
        return line
    return f"{line[:per_line_char_limit]}{_TRUNCATION_MARKER}"


def _render_line(*, number: int, content: str, width: int, separator: str, max_width: int) -> str:
    """Render one gutter-plus-content line, bounded by the render width when one is set."""
    rendered = f"{str(number).rjust(width)} {separator} {content}"
    if max_width > 0:
        return rendered[:max_width]
    return rendered
