"""Runtime formatting options for XML output.

This module defines the runtime configuration options that control how
context blocks are formatted into XML.
"""

from __future__ import annotations

from datetime import timezone as tz_type  # noqa: TC003

from pydantic import BaseModel, ConfigDict, Field

from .types import FieldPresentation, FieldSpec  # noqa: TC001


class RuntimeFieldOverride(BaseModel):
    """Runtime override for a specific field's presentation.

    Allows runtime modification of how a field is formatted, including
    changing its presentation style or excluding it entirely.

    Attributes:
        presentation: Override the presentation style (ATTR, ELEMENT, CONTENT).
        include: Whether to include this field. Only works for optional fields.

    Examples:
        ```python
        from omne_core_v1.data_model.xml_format.options import RuntimeFieldOverride
        from omne_core_v1.data_model.xml_format.types import FieldPresentation

        RuntimeFieldOverride(presentation=FieldPresentation.ELEMENT)
        RuntimeFieldOverride(include=False)
        ```
    """

    presentation: FieldPresentation | None = Field(default=None)
    """Override the presentation style. None keeps the default."""

    include: bool = Field(default=True)
    """Whether to include this field. Only works for optional fields."""


class FormattingOptions(BaseModel):
    """Runtime options for formatting a single context block to XML.

    This class provides fine-grained control over the XML formatting process.
    Each ``FormattingOptions`` instance is designed to configure the formatting
    of a single block type -- the block already knows its own type.

    Attributes:
        include_timestamps: Whether to include timestamp fields in output.
        timezone: Timezone to use when formatting datetime values.
        indent_size: Number of spaces per indentation level.
        omit_root_tag: Whether to omit the root XML tag and return only
            the inner content.
        extra_fields: Additional optional fields to include in output.
        field_overrides: Field presentation overrides.
        manual_attributes: Custom attributes to add to the root XML tag.

    Examples:
        ```python
        from omne_core_v1.data_model.xml_format.options import (
            FormattingOptions,
            RuntimeFieldOverride,
        )
        from omne_core_v1.data_model.xml_format.types import FieldPresentation

        options = FormattingOptions(indent_size=4)

        options = FormattingOptions(extra_fields={"timeliness", "conditions"})

        options = FormattingOptions(
            field_overrides={
                "timeliness": RuntimeFieldOverride(
                    presentation=FieldPresentation.ELEMENT,
                )
            }
        )

        # Add custom attributes like similarity score to the root tag
        options = FormattingOptions(
            manual_attributes={"score": "0.95", "rank": "1"},
        )
        ```
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    # General formatting options
    include_timestamps: bool = Field(
        default=True,
        description="Whether to include timestamp fields in output",
    )

    timezone: tz_type | None = Field(
        default=None,
        description="Timezone for formatting datetime values. None means UTC.",
    )

    indent_size: int = Field(
        default=2,
        ge=0,
        le=8,
        description="Number of spaces per indentation level",
    )

    omit_root_tag: bool = Field(
        default=False,
        description=(
            "Whether to omit the root XML tag and return only the inner content. "
            "When True, only child elements and content are returned without the "
            "wrapping root element, and all content is dedented by one level."
        ),
    )

    # Field selection and overrides (directly for the block being formatted)
    extra_fields: set[str] = Field(
        default_factory=set,
        description=("Additional optional fields to include. Field names from the block's __optional_fields__."),
    )

    field_overrides: dict[str, RuntimeFieldOverride] = Field(
        default_factory=dict,
        description=("Field presentation overrides. Maps field names to RuntimeFieldOverride."),
    )

    manual_attributes: dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Custom attributes to add to the root XML tag. "
            "Useful for adding metadata like similarity scores. "
            "Maps attribute names to their string values."
        ),
    )

    def get_field_override(self, field_name: str) -> RuntimeFieldOverride | None:
        """Get field override for a specific field.

        Args:
            field_name: Name of the field.

        Returns:
            RuntimeFieldOverride if one exists, None otherwise.
        """
        return self.field_overrides.get(field_name)

    def apply_override_to_spec(
        self,
        spec: FieldSpec,
        override: RuntimeFieldOverride | None,
    ) -> FieldSpec:
        """Apply runtime override to a field specification.

        Args:
            spec: Original field specification.
            override: Runtime override to apply.

        Returns:
            Updated FieldSpec with overrides applied.
        """
        if override is None:
            return spec

        if override.presentation is not None:
            return spec.model_copy(update={"presentation": override.presentation})

        return spec


__all__ = [
    "FormattingOptions",
    "RuntimeFieldOverride",
]
