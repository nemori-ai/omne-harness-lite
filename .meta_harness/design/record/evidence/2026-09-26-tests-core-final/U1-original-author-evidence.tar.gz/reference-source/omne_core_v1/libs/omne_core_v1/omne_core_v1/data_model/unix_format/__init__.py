"""Unix-CLI-style plain-text output infrastructure for LLM-facing tool output.

Paired with ``data_model/xml_format/`` for XML-structured output.
"""

from __future__ import annotations

from omne_core_v1.data_model.unix_format.envelope import (
    format_error,
    format_hold,
    format_success,
)
from omne_core_v1.data_model.unix_format.numbered import format_numbered_lines
from omne_core_v1.data_model.unix_format.options import UnixFormatOptions
from omne_core_v1.data_model.unix_format.sections import (
    format_command_list,
    format_section,
    format_usage,
)
from omne_core_v1.data_model.unix_format.structured import (
    format_bullet_list,
    format_key_value,
    format_table,
)

__all__ = [
    "UnixFormatOptions",
    "format_bullet_list",
    "format_command_list",
    "format_error",
    "format_hold",
    "format_key_value",
    "format_numbered_lines",
    "format_section",
    "format_success",
    "format_table",
    "format_usage",
]
