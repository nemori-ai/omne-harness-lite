"""XMLFormatMixin for context blocks.

This module provides the XMLFormatMixin class that enables context blocks
to format themselves into XML output.

This mixin is designed to be type-agnostic and does not depend on any
specific block implementation:
- Can be mixed into any class (not just ContextBlock subclasses)
- Uses dynamic attribute access via getattr() for field values
- Only requires the class to declare __xml_tag__ and __required_fields__

The mixin follows the "composition over inheritance" principle, allowing
any data class to gain XML formatting capabilities by simply:
1. Inheriting from XMLFormatMixin
2. Declaring the required class variables (__xml_tag__, __required_fields__)
3. Optionally declaring __optional_fields__ for flexible output
"""

from __future__ import annotations

from collections.abc import Mapping, Sized
from datetime import datetime
from enum import Enum
from textwrap import indent as text_indent
from typing import Any, ClassVar, Literal, Protocol, cast, runtime_checkable
from xml.sax.saxutils import escape as xml_escape

from pydantic import BaseModel

from .options import FormattingOptions
from .types import FieldPresentation, FieldSpec, OptionalFields, RequiredFields


@runtime_checkable
class XMLFormattable(Protocol):
    """Protocol for objects that can be formatted to XML.

    Any object implementing this protocol can be used with the
    ContextBlockXMLTransformer.
    """

    def to_xml(self, options: FormattingOptions | None = None) -> str:
        """Format this object to an XML string.

        Args:
            options: Runtime formatting options. If None, uses defaults.

        Returns:
            Formatted XML string.
        """
        ...


class XMLFormatMixin:
    """Mixin that provides XML formatting capability to any data class.

    This mixin enables any class to format itself into XML output by declaring
    field formatting specifications at the class level. It is type-agnostic
    and does not require inheriting from ContextBlock or any specific base class.

    The mixin uses dynamic attribute access (getattr) to retrieve field values,
    making it compatible with Pydantic models, dataclasses, plain classes, or
    any object with the declared attributes.

    Required class variables:
        __xml_tag__: The XML tag name for this type.
        __required_fields__: Fields that must always be formatted.

    Optional class variables:
        __optional_fields__: Fields that can be included via FormattingOptions.

    Attributes:
        __xml_tag__: Class variable defining the XML tag name.
        __required_fields__: Class variable defining required field specifications.
        __optional_fields__: Class variable defining optional field specifications.

    Examples:
        ```python
        from pydantic import BaseModel

        from omne_core_v1.data_model.xml_format import (
            FieldPresentation,
            FieldSpec,
            FormattingOptions,
            XMLFormatMixin,
        )


        class MyCustomData(BaseModel, XMLFormatMixin):
            __xml_tag__ = "custom_data"
            __required_fields__ = {
                "name": FieldSpec(presentation=FieldPresentation.ATTR),
                "value": FieldSpec(presentation=FieldPresentation.ELEMENT),
            }

            name: str
            value: str


        obj = MyCustomData(name="n", value="v")
        xml = obj.to_xml(FormattingOptions())
        ```
    """

    # Subclasses must define these class variables
    __xml_tag__: ClassVar[str]
    __required_fields__: ClassVar[RequiredFields]
    __optional_fields__: ClassVar[OptionalFields] = {}

    @classmethod
    def get_xml_tag(cls) -> str:
        """Get the XML tag name for this class.

        Returns the value of __xml_tag__ class variable.
        This method provides compatibility with ContextBlockXMLTransformer's
        fallback formatter which calls get_xml_tag().

        Returns:
            The XML tag name.
        """
        return cls.__xml_tag__

    def to_xml(self, options: FormattingOptions | None = None) -> str:
        """Format this block to an XML string.

        Args:
            options: Runtime formatting options. If None, uses defaults.

        Returns:
            Formatted XML string.

        Examples:
            ```python
            from omne_core_v1.data_model.xml_format import FormattingOptions

            xml = block.to_xml()

            options = FormattingOptions(extra_fields={"timeliness"})
            xml = block.to_xml(options)
            ```
        """
        options = options or FormattingOptions()

        # Collect fields to format based on options
        fields_to_format = self._collect_fields_to_format(options)

        # Build XML components
        attrs: list[str] = []
        elements: list[str] = []
        content: str | None = None

        for field_name, spec in fields_to_format.items():
            # Apply runtime overrides if any
            override = options.get_field_override(field_name)
            effective_spec = options.apply_override_to_spec(spec, override)

            # Get field value
            value = self._get_field_value(field_name)

            # Check if field should be included
            if not self._should_include_field(value, effective_spec):
                continue

            # Format the field
            xml_name = effective_spec.xml_name or field_name.split(".")[-1]
            formatted_value = self._format_field_value(value, effective_spec, options)

            # Check if value is preformatted XML (complex list, simple list with
            # item_tag, or single XMLFormattable object)
            is_preformatted = False
            is_xmlformattable_single = False
            is_xmlformattable_list = False

            if isinstance(value, XMLFormattable) and not isinstance(value, list):
                # Single XMLFormattable object - its to_xml() output is preformatted
                is_xmlformattable_single = True
                is_preformatted = True
            elif isinstance(value, list):
                value_as_list = cast("list[Any]", value)
                if len(value_as_list) > 0:
                    first_item = value_as_list[0]
                    # Complex list (BaseModel instances)
                    is_preformatted = isinstance(first_item, BaseModel)
                    # If items are XMLFormattable, they have their own tags
                    is_xmlformattable_list = isinstance(first_item, XMLFormattable)
                    # Simple list with item_tag also produces preformatted XML
                    if effective_spec.item_tag and not is_preformatted:
                        is_preformatted = True

            match effective_spec.presentation:
                case FieldPresentation.ATTR:
                    attrs.append(f'{xml_name}="{self._escape_attr(formatted_value)}"')
                case FieldPresentation.ELEMENT:
                    if is_xmlformattable_list or is_xmlformattable_single:
                        # XMLFormattable items already have their own tags,
                        # so don't wrap them in another element
                        elements.append(formatted_value)
                    else:
                        element_xml = self._render_element(
                            xml_name,
                            formatted_value,
                            effective_spec,
                            options,
                            is_preformatted=is_preformatted,
                        )
                        elements.append(element_xml)
                case FieldPresentation.CONTENT:
                    content = formatted_value

        return self._assemble_xml(attrs, elements, content, options)

    def _collect_fields_to_format(
        self,
        options: FormattingOptions,
    ) -> dict[str, FieldSpec]:
        """Collect all fields that should be formatted based on options.

        Required fields are always included. Optional fields are included
        if they appear in options.extra_fields.

        Args:
            options: Runtime formatting options.

        Returns:
            Dictionary mapping field names to their effective specifications.
        """
        fields: dict[str, FieldSpec] = {}

        # Always include required fields
        fields.update(self.__required_fields__)

        # Add requested optional fields (directly from options.extra_fields)
        for field_name in options.extra_fields:
            if field_name in self.__optional_fields__:
                fields[field_name] = self.__optional_fields__[field_name]

        return fields

    def _get_field_value(self, field_name: str) -> object:
        """Get field value, supporting nested paths like 'metadata.type'.

        Args:
            field_name: Field name, possibly with dots for nested access.

        Returns:
            Field value, or None if not found.
        """
        parts = field_name.split(".")
        current: object = self

        for part in parts:
            if current is None:
                return None
            # Check dict-like access first (dict values are untyped)
            if isinstance(current, dict):
                current = current.get(part)
                continue
            # Then try attribute access (dynamic attribute lookup)
            try:
                current = getattr(current, part)
            except AttributeError:
                return None

        return current

    def _should_include_field(self, value: object, spec: FieldSpec) -> bool:
        """Determine if a field should be included based on spec and value.

        Args:
            value: The field value.
            spec: Field specification with include_when condition.

        Returns:
            True if the field should be included, False otherwise.
        """
        include_when = spec.include_when

        if include_when == "always":
            return True

        if include_when == "not_none":
            return value is not None

        if include_when == "not_empty":
            if value is None:
                return False
            # Use Sized protocol for len() check
            if isinstance(value, Sized):
                return len(value) > 0
            return True

        if include_when == "not_default":
            # For not_default, we include if value is not None
            # More sophisticated default checking would require field metadata
            return value is not None

        # Fallback for any unexpected include_when value
        return True

    def _format_field_value(
        self,
        value: object,
        spec: FieldSpec,
        options: FormattingOptions,
    ) -> str:
        """Format a field value to a string for XML output.

        Handles various types including datetime, bool, enums, and collections.

        Args:
            value: The field value to format.
            spec: Field specification.
            options: Formatting options.

        Returns:
            Formatted string representation of the value.
        """
        if value is None:
            return ""

        if isinstance(value, datetime):
            if options.timezone:
                value = value.astimezone(options.timezone)
            return value.isoformat()

        if isinstance(value, bool):
            return str(value).lower()

        if isinstance(value, list):
            value_list = cast("list[Any]", value)
            # Check if it's a list of complex objects (BaseModel instances)
            if value_list and isinstance(value_list[0], BaseModel):
                return self._format_complex_list(value_list, spec, options)
            # For simple lists, use item_tag if specified, otherwise join with comma
            if spec.item_tag:
                return self._format_simple_list_with_tag(value_list, spec)
            return ", ".join(str(item) for item in value_list)

        if isinstance(value, tuple):
            # For tuples, join items with comma (tuple elements are untyped)
            return ", ".join(str(item) for item in value)

        if isinstance(value, dict):
            # For dict, format as structured XML content
            value_dict = cast("dict[Any, Any]", value)
            return self._format_dict(value_dict, spec, options)

        if isinstance(value, Enum):
            # Handle Enum types
            return str(value.value)

        # Handle TimeWindow or similar Pydantic models with start/end attributes
        if self._is_time_window_like(value):
            return self._format_time_window(value)

        # Handle single XMLFormattable object
        if isinstance(value, XMLFormattable):
            return value.to_xml(options)

        return str(value)

    def _format_simple_list_with_tag(
        self,
        items: list[Any],
        spec: FieldSpec,
    ) -> str:
        """Format a list of simple values with individual XML tags.

        Used when item_tag is specified for lists of simple types (str, int,
        Enum, etc.) instead of the default comma-separated format.

        Args:
            items: List of simple values.
            spec: Field specification with item_tag.

        Returns:
            Formatted XML string with each item wrapped in item_tag.
        """
        if not items:
            return ""

        item_tag = spec.item_tag or "item"
        formatted_items: list[str] = []

        for item in items:
            # Handle Enum values
            value_str = str(item.value) if isinstance(item, Enum) else str(item)
            formatted_items.append(f"<{item_tag}>{xml_escape(value_str)}</{item_tag}>")

        return "\n".join(formatted_items)

    def _format_complex_list(
        self,
        items: list[Any],
        spec: FieldSpec,
        options: FormattingOptions,
    ) -> str:
        """Format a list of complex objects (BaseModel instances) to XML.

        If items implement XMLFormattable, delegates to their to_xml() method.
        Otherwise, renders each item as an XML element with its fields as
        children.

        Args:
            items: List of BaseModel instances.
            spec: Field specification with optional item_tag and item_fields.
            options: Formatting options.

        Returns:
            Formatted XML string with all items.
        """
        if not items:
            return ""

        # Determine item tag name
        item_tag = spec.item_tag or "item"
        item_fields = spec.item_fields

        formatted_items: list[str] = []
        for item in items:
            # If item is XMLFormattable, use its to_xml() method directly
            if isinstance(item, XMLFormattable):
                formatted_items.append(item.to_xml(options))
            else:
                formatted_items.append(self._format_complex_item(item, item_tag, item_fields, options))

        # Join all items, each already includes proper structure
        return "\n".join(formatted_items)

    def _format_complex_item(
        self,
        item: BaseModel,
        item_tag: str,
        item_fields: Mapping[str, Literal["attr", "element", "content"]] | None,
        options: FormattingOptions,
    ) -> str:
        """Format a single complex object (BaseModel instance) to XML element.

        Args:
            item: BaseModel instance to format.
            item_tag: XML tag name for the item.
            item_fields: Optional mapping of field names to presentation style.
            options: Formatting options.

        Returns:
            Formatted XML element string.
        """
        prefix = " " * options.indent_size
        attrs: list[str] = []
        elements: list[str] = []
        content: str | None = None

        # Get all model fields (access from class to avoid deprecation)
        model_fields = type(item).model_fields.keys()

        for field_name in model_fields:
            field_value = getattr(item, field_name, None)
            if field_value is None:
                continue

            # Determine presentation style
            if item_fields and field_name in item_fields:
                presentation = item_fields[field_name]
            else:
                # Default: simple values as attrs, complex as elements
                if isinstance(field_value, (str, int, float, bool)) and len(str(field_value)) < 50:
                    presentation = "attr"
                else:
                    presentation = "element"

            # Format the value
            formatted = self._format_item_field_value(field_value, options)

            if presentation == "attr":
                attrs.append(f'{field_name}="{self._escape_attr(formatted)}"')
            elif presentation == "element":
                element_content = self._escape_content(formatted)
                indented = text_indent(element_content, prefix, predicate=lambda l: l.strip() != "")  # noqa: E741
                elements.append(f"<{field_name}>\n{indented}\n</{field_name}>")
            elif presentation == "content":
                content = formatted

        # Assemble the item XML
        attrs_str = " " + " ".join(attrs) if attrs else ""

        if not elements and not content:
            return f"<{item_tag}{attrs_str}/>"

        parts: list[str] = [f"<{item_tag}{attrs_str}>"]

        if elements:
            elements_text = "\n".join(elements)
            parts.append(text_indent(elements_text, prefix))

        if content:
            parts.append(text_indent(self._escape_content(content), prefix))

        parts.append(f"</{item_tag}>")

        return "\n".join(parts)

    def _format_item_field_value(
        self,
        value: Any,
        options: FormattingOptions,
    ) -> str:
        """Format a field value of a complex item to string.

        Args:
            value: Field value to format.
            options: Formatting options.

        Returns:
            String representation of the value.
        """
        if value is None:
            return ""

        if isinstance(value, datetime):
            if options.timezone:
                value = value.astimezone(options.timezone)
            return value.isoformat()

        if isinstance(value, bool):
            return str(value).lower()

        if isinstance(value, Enum):
            return str(value.value)

        if isinstance(value, list):
            # Simple list - join with comma
            value_list = cast("list[Any]", value)
            return ", ".join(str(v) for v in value_list)

        if self._is_time_window_like(value):
            return self._format_time_window(value)

        if isinstance(value, BaseModel):
            # Nested model - format as simplified string
            return self._format_nested_model(value)

        return str(value)

    def _format_nested_model(self, model: BaseModel) -> str:
        """Format a nested BaseModel as a simplified string.

        Args:
            model: BaseModel instance to format.

        Returns:
            Simplified string representation.
        """
        parts: list[str] = []
        model_data: dict[str, Any] = model.model_dump(mode="python")
        for field_name, field_value in model_data.items():
            if field_value is not None:
                if isinstance(field_value, list):
                    field_list = cast("list[Any]", field_value)
                    formatted_value = ", ".join(str(v) for v in field_list)
                else:
                    formatted_value = str(field_value)
                parts.append(f"{field_name}: {formatted_value}")
        return "; ".join(parts)

    def _format_dict(
        self,
        value: dict[Any, Any],
        spec: FieldSpec,
        options: FormattingOptions,
    ) -> str:
        """Format a dictionary to XML-friendly string.

        Args:
            value: Dictionary to format.
            spec: Field specification.
            options: Formatting options.

        Returns:
            Formatted string representation.
        """
        if not value:
            return ""

        parts: list[str] = []

        for key, val in value.items():
            if isinstance(val, list):
                val_list = cast("list[Any]", val)
                val_str = ", ".join(str(v) for v in val_list)
            else:
                val_str = str(val)
            parts.append(f"{key}: {val_str}")

        return "\n".join(parts)

    def _is_time_window_like(self, value: object) -> bool:
        """Check if value is a TimeWindow-like object with start and end.

        Args:
            value: The value to check.

        Returns:
            True if value has model_dump, start, and end attributes.
        """
        return hasattr(value, "model_dump") and hasattr(value, "start") and hasattr(value, "end")

    def _format_time_window(self, value: object) -> str:
        """Format a TimeWindow-like object to string.

        Args:
            value: An object with start and end attributes.

        Returns:
            Formatted string like "start ~ end".
        """
        start = getattr(value, "start", None)
        end = getattr(value, "end", None)

        start_str = start.isoformat() if isinstance(start, datetime) else str(start)
        end_str = end.isoformat() if isinstance(end, datetime) else str(end)

        return f"{start_str} ~ {end_str}"

    def _render_element(
        self,
        name: str,
        value: str,
        spec: FieldSpec,
        options: FormattingOptions,
        is_preformatted: bool = False,
    ) -> str:
        """Render a single XML element.

        Always formats as::

            <name attr1="val1" attr2="val2">
              indented_content
            </name>

        Args:
            name: Element tag name.
            value: Element content.
            spec: Field specification.
            options: Formatting options.
            is_preformatted: If True, value is already formatted XML and
                should not be escaped.

        Returns:
            Formatted XML element string.
        """
        prefix = " " * options.indent_size

        # Build additional attributes string if spec.attrs is defined
        attrs_str = ""
        if spec.attrs:
            attr_parts = [f'{k}="{self._escape_attr(v)}"' for k, v in spec.attrs.items()]
            attrs_str = " " + " ".join(attr_parts) if attr_parts else ""

        if is_preformatted:
            # Value is already formatted XML (e.g., from complex list formatting)
            indented_value = text_indent(value, prefix, predicate=lambda line: line.strip() != "")
        else:
            escaped_value = self._escape_content(value)
            # Always use multi-line format: <tag>\n  content\n</tag>
            indented_value = text_indent(escaped_value, prefix, predicate=lambda line: line.strip() != "")

        return f"<{name}{attrs_str}>\n{indented_value}\n</{name}>"

    def _assemble_xml(
        self,
        attrs: list[str],
        elements: list[str],
        content: str | None,
        options: FormattingOptions,
    ) -> str:
        """Assemble final XML from component parts.

        Args:
            attrs: List of formatted attribute strings.
            elements: List of formatted element strings.
            content: Optional content to place directly in tag.
            options: Formatting options.

        Returns:
            Complete XML string.
        """
        tag = self.__xml_tag__
        prefix = " " * options.indent_size

        # If omit_root_tag is True, return only inner content without wrapper
        if options.omit_root_tag:
            parts: list[str] = []
            if elements:
                parts.append("\n".join(elements))
            if content:
                parts.append(self._escape_content(content))
            return "\n".join(parts) if parts else ""

        # Combine regular attrs with manual_attributes
        all_attrs = list(attrs)
        for attr_name, attr_value in options.manual_attributes.items():
            all_attrs.append(f'{attr_name}="{self._escape_attr(attr_value)}"')

        attrs_str = " " + " ".join(all_attrs) if all_attrs else ""

        # Self-closing tag if no content
        if not elements and not content:
            return f"<{tag}{attrs_str}/>"

        # Build tag with content
        parts: list[str] = [f"<{tag}{attrs_str}>"]

        if elements:
            # Join all elements and indent once
            elements_text = "\n".join(elements)
            parts.append(text_indent(elements_text, prefix))

        if content:
            escaped_content = self._escape_content(content)
            parts.append(text_indent(escaped_content, prefix))

        parts.append(f"</{tag}>")

        return "\n".join(parts)

    @staticmethod
    def _escape_attr(text: str) -> str:
        """Escape text for use in an XML attribute value.

        Args:
            text: Text to escape.

        Returns:
            Escaped text safe for XML attribute.
        """
        return xml_escape(text, {'"': "&quot;", "'": "&apos;"})

    @staticmethod
    def _escape_content(text: str) -> str:
        """Escape text for use in XML element content.

        Args:
            text: Text to escape.

        Returns:
            Escaped text safe for XML content.
        """
        return xml_escape(text)


__all__ = [
    "XMLFormatMixin",
    "XMLFormattable",
]
