"""Runtime options for ``unix_format`` renderers."""

from __future__ import annotations

from dataclasses import dataclass

__all__ = ["UnixFormatOptions"]


@dataclass(frozen=True, slots=True)
class UnixFormatOptions:
    """Render-time configuration for plain-text output.

    Attributes:
        max_width: Upper bound on output line width. Tables truncate columns
            to stay within this budget. ``0`` disables the cap.
        indent: Leading spaces for nested section bodies.
        markdown_compatible: When ``True``, ``format_section`` emits ``## HEADING``
            and code blocks use ```` ``` ```` fences. When ``False``, emits
            ``HEADING:`` and plain indented text only.
    """

    max_width: int = 120
    indent: int = 2
    markdown_compatible: bool = True
