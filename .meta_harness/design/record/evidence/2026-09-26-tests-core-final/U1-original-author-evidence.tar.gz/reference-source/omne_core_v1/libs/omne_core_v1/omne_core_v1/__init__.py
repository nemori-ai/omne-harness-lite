"""omne_core_v1 — protocol shell and top-level abstractions for the OMNE system.

Sub-packages are consumed explicitly::

    from omne_core_v1.identity import SessionIdentity
    from omne_core_v1.time import get_utc_now
    from omne_core_v1.logging import get_logger

The top-level package only exposes ``__version__``; it does not re-export
symbols across sub-packages.
"""

from importlib.metadata import version

__version__ = version("omne-core-v1")

__all__ = ["__version__"]
