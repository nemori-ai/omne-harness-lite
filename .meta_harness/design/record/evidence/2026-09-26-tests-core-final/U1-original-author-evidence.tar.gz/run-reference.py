"""Execute unchanged fixed Git formatter code; adapt only schema/input API shapes."""
import argparse
import hashlib
import importlib
import json
import pathlib
import sys
import types
from datetime import datetime
from typing import Any

from pydantic import BaseModel, create_model

ROOT = pathlib.Path(__file__).resolve().parent
LIB = ROOT / 'reference-source/omne_core_v1/libs/omne_core_v1/omne_core_v1'

# Namespace registration bypasses the unrelated aggregate package facades, which
# pull in ContextBlock/registry/time subsystems. No formatter function is replaced.
for name, directory in [
    ('omne_core_v1', LIB),
    ('omne_core_v1.data_model', LIB / 'data_model'),
    ('omne_core_v1.data_model.xml_format', LIB / 'data_model/xml_format'),
]:
    module = types.ModuleType(name)
    module.__path__ = [str(directory)]
    sys.modules[name] = module

uf = importlib.import_module('omne_core_v1.data_model.unix_format')
xml_types = importlib.import_module('omne_core_v1.data_model.xml_format.types')
xml_options = importlib.import_module('omne_core_v1.data_model.xml_format.options')
xml_mixin = importlib.import_module('omne_core_v1.data_model.xml_format.mixin')


class Child(BaseModel, xml_mixin.XMLFormatMixin):
    label: str


Child.__xml_tag__ = 'child'
Child.__required_fields__ = {'label': xml_types.FieldSpec(presentation='attr')}
Child.__optional_fields__ = {}


class RawXml:
    def __init__(self, output):
        self.output = output

    def to_xml(self, options=None):
        return self.output


def model(values, mixin=False, name='GoldenInput'):
    base = (BaseModel, xml_mixin.XMLFormatMixin) if mixin else BaseModel
    klass = create_model(name, __base__=base, **{k: (Any, ...) for k in values})
    return klass(**values)


def decode(value):
    if isinstance(value, list):
        return [decode(v) for v in value]
    if isinstance(value, dict):
        marker = value.get('$reference')
        if marker == 'bigint':
            return int(value['value'])
        if marker == 'date':
            return datetime.fromisoformat(value['value'].replace('Z', '+00:00'))
        if marker == 'map':
            return {decode(k): decode(v) for k, v in value['entries']}
        if marker == 'child':
            return Child(label=value['label'])
        if marker == 'raw-xml':
            return RawXml(value['output'])
        if marker == 'undefined':
            return None
        return {k: decode(v) for k, v in value.items()}
    return value


def spec(value):
    names = {'xmlName': 'xml_name', 'includeWhen': 'include_when', 'itemTag': 'item_tag', 'itemFields': 'item_fields'}
    adapted = {names.get(k, k): v for k, v in value.items()}
    if adapted.get('include_when') == 'not_nullish':
        adapted['include_when'] = 'not_none'
    return xml_types.FieldSpec(**adapted)


def xml_render(args):
    values, schema, *provided_options = args
    # Original Python recognizes complex list objects and nested records through
    # BaseModel, whereas the migrated TS accepts plain records. Preserve values,
    # field order, and required/optional schema; no rendering is done here.
    for key, value in list(values.items()):
        if isinstance(value, list):
            converted = []
            for index, item in enumerate(value):
                if isinstance(item, dict):
                    item = {k: model(v, name='NestedItem') if isinstance(v, dict) else v for k, v in item.items()}
                    item = model(item, name=f'ComplexItem{index}')
                converted.append(item)
            values[key] = converted
    obj = model(values, mixin=True)
    type(obj).__xml_tag__ = schema['tag']
    type(obj).__required_fields__ = {k: spec(v) for k, v in schema['requiredFields'].items()}
    type(obj).__optional_fields__ = {k: spec(v) for k, v in schema.get('optionalFields', {}).items()}
    names = {'indentSize': 'indent_size', 'omitRootTag': 'omit_root_tag', 'extraFields': 'extra_fields', 'fieldOverrides': 'field_overrides', 'manualAttributes': 'manual_attributes'}
    options = {names.get(k, k): v for k, v in (provided_options[0] if provided_options else {}).items()}
    return obj.to_xml(xml_options.FormattingOptions(**options))


def unix_render(function, args):
    names = {'formatError': 'format_error', 'formatSuccess': 'format_success', 'formatHold': 'format_hold', 'formatSection': 'format_section', 'formatUsage': 'format_usage', 'formatCommandList': 'format_command_list', 'formatTable': 'format_table', 'formatKeyValue': 'format_key_value', 'formatBulletList': 'format_bullet_list', 'formatNumberedLines': 'format_numbered_lines'}
    original = getattr(uf, names[function])
    if function in ('formatError', 'formatSuccess', 'formatHold'):
        return original(args[0], **(args[1] if len(args) > 1 else {}))
    if function in ('formatSection', 'formatTable'):
        if len(args) == 3:
            mapping = {'maxWidth': 'max_width', 'markdownCompatible': 'markdown_compatible'}
            return original(*args[:2], options=uf.UnixFormatOptions(**{mapping.get(k, k): v for k, v in args[2].items()}))
        return original(*args)
    if function == 'formatNumberedLines':
        options = dict(args[1]) if len(args) > 1 else {}
        mapped = {'perLineCharLimit': 'per_line_char_limit'}
        options = {mapped.get(k, k): v for k, v in options.items()}
        if 'maxWidth' in options:
            options['options'] = uf.UnixFormatOptions(max_width=options.pop('maxWidth'))
        return original(args[0], **options)
    return original(*args)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=pathlib.Path, default=ROOT / 'inputs.json')
    parser.add_argument('--output', type=pathlib.Path, default=ROOT / 'python-results.json')
    opts = parser.parse_args()
    cases = json.loads(opts.input.read_text())['cases']
    results = []
    for case in cases:
        try:
            args = decode(case['args'])
            output = xml_render(args) if case['package'] == 'xml-format' else unix_render(case['function'], args)
            raw = output.encode('utf-8')
            result = {'id': case['id'], 'status': 'output', 'output': output, 'utf8_bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        except Exception as exc:
            result = {'id': case['id'], 'status': 'error', 'error_type': type(exc).__name__, 'error': str(exc)}
        results.append(result)
    modules = [{'name': name, 'file': mod.__file__, 'sha256': hashlib.sha256(pathlib.Path(mod.__file__).read_bytes()).hexdigest()} for name, mod in sys.modules.items() if name.startswith('omne_core_v1.') and getattr(mod, '__file__', None)]
    data = {'python': sys.version, 'cases': results, 'actual_modules': modules}
    opts.output.write_text(json.dumps(data, indent=2, ensure_ascii=True) + '\n')
    print(json.dumps({'executed': len(results), 'outputs': sum(r['status'] == 'output' for r in results), 'errors': [r['id'] for r in results if r['status'] != 'output']}))
    if any(r['status'] != 'output' for r in results):
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
