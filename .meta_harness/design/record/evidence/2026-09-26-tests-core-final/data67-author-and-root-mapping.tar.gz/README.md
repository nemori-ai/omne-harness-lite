# D068 六 data 的作者义务映射

[obligation-map.json](obligation-map.json) 是入口；[test-index.json](test-index.json) 提供实际测试全名、源文件、原 Vitest JSON 的行 1 与精确 JSON pointer。这里仅补证据导航，技术验收归 root，最终交付验收归用户。

采用输入为 D068 接受提交 `3fab9200` 的六份 data/3 与本树相关 realization。源码为 `29abb1851ab5f3615355a7a2629b38587d44057e`，root 已集成于 HUB `fad84ef3`。矩阵快照 [matrix-input.json](matrix-input.json) SHA-256 为 `eb454167f973f7decab97842f92cb9fa9c9e6392a7537bca2d03167373cc3c80`；未改变矩阵的接受字段。

| 包 | core-local ID |
| --- | ---: |
| content-blocks | 12 |
| messages | 15 |
| model-response | 5 |
| loop-extension | 6 |
| tool-definition | 18 |
| asset-model | 11 |
| 合计 | 67 |

每项给出采用3的条款标题、行号与 SHA，版本内 examples、版本外 verification/realization 的文件 SHA，实际测试键，公开 API/资源与消费者、源码保护点，以及仍归 root/W6 的部分。18 项 schema/public/purity 都有实际入口和资源。另列 52 项 composition/external 交接及调度纠正后的实际依赖；不关闭整条 CS，也不把替身或已接纳形状当作真实存储、派发、权限、持久化或执行事实。

Messages 的旧 `alignment.spec.ts` 仍读取冻结2，仅作历史回归。当前3复制关系指向 MR `copies.spec.ts` 的 11 条实际断言，分别绑定 Msg3/MR3/Loop3 的真实公开资源与仍采用2的 CallAccounts 资源。Loop 的 before_action 形状接纳不授权运行时执行 unparseable。

[source-controls.json](source-controls.json) 记录 51 份实际产品 TS 源的 SHA 与透明的直接环境操作文字检查，既有27条 AST 规则扫描另列。规则负例定位到实际 checker 测试名和源；root 原299项/10文件及27规则的日志、归档源与哈希见 [durable-root-artifacts.json](durable-root-artifacts.json)，保持原运行时间，不捏造逐断言 JSON，不重复运行。文字检查不是纯度定理。

[self-check.json](self-check.json) 的14组结构检查通过：67个 ID、2410条已封存测试的定位与源哈希、13份完整当前3/保留2/私有TD2资源、91个实际根运行时导出，以及原196项 seal 全部不变。原 seal SHA 保持 `472e854d6358c56bc293fe6cb61e3ccc700faa69ffe64d02abab0ce8320217fb`；产品源码和受维护工作树保持 clean。新自检曾修正相对路径与 export-type-star 声明定位，原两份结构检查失败记录保留，未改变实现或测试。

复核命令见 [self-check-command.json](self-check-command.json)，最终生成命令见 [generation-command.json](generation-command.json)。新补交文件的哈希清单在 [manifest.json](manifest.json)；原 `tmp/d068-data-adoption/**` 未修改。本次没有新产品测试、合并、推送或接受动作。
