"""Produce an evidence map; findings do not mutate or accept matrix obligations."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

HUB = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
OUT = HUB / 'tmp/core-delivery/retained-local-evidence-audit'


def read(name):
    return json.loads((OUT / name).read_text())


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


matrix = read('input-acceptance-matrix.json')
inventory = read('current-inventory.json')
history = read('historical-evidence.json')
graphs = read('retained-schema-resource-closure.json')
guards = read('guard-evidence.json')

# (own current clauses, actual source markers, actual test files/title regex, observations)
BASE = {
 'model-profile.self-shape-order': (
  ['S-2','S-4','S-5','S-6','S-7','S-8','S-9','S-10','S-11','S-13','S-16','S-24','S-25','S-28'],
  [('profile.ts','judgeModelProfileDocument'),('json.ts','jsonValue'),('schema.ts','exactNumbers')],
  [('examples.spec.ts','.*'),('behavior.spec.ts','M-FIRST|JSON-BOUNDARY|SCHEMA-TYPES|EXACT-PARAM'),('types.spec-d.ts','.*')],
  '155 extracted normative example rows check Schema and ordered named judgment separately. Later malformed members defeat earlier named failures. ModelProfileContent does not admit registration/updatedAt. Input snapshots reject accessor/cycle/non-JSON values without invoking them.'),
 'model-profile.max-output': (
  ['S-8','S-16','S-18','S-24','S-25','S-27','S-28'],
  [('profile.ts','judgeModelProfileDocument'),('profile.ts','max_output_exceeds_profile'),('numbers.ts','compareNumbers')],
  [('behavior.spec.ts','S18-|EXACT-INTEGER-ORACLE|EXACT-LIMIT|EXACT-SNAPSHOT|EXACT-EXPONENT')],
  'Profile and creation-content each have independent positive/negative semantic checks above 2^53. Schema shape may accept an out-of-profile maxOutputTokens while judgment rejects it. Snapshot has no cross-field judge. Fixed seed 20260926 BigInt oracle is independent of the comparison implementation.'),
 'model-profile.exact-reference': (
  ['S-1','S-7','S-13','S-14'],
  [('profile.ts','refMatches'),('types.ts','ModelProfileRef')],
  [('behavior.spec.ts','S14-'),('types.spec-d.ts','TYPE-S13|TYPE-MODALITY')],
  'Official origin+route exact matching and explicit customized scope matching are local computations. Same name in another tenant/layer does not match; no directory lookup, fallback or current registration state is inferred. Modality is imported from the canonical content-block type, not redefined.'),
 'model-profile.parameter-name-function': (
  ['S-15','S-16','S-17','S-19','S-20','S-21'],
  [('parameters.ts','parameterNames'),('types.ts','ModelRequestParameters')],
  [('behavior.spec.ts','S17-S20|EXACT-PARAM'),('types.spec-d.ts','.*')],
  'Enumerates only present unified/extra keys with no defaults, dropped extra keys or value changes. The profile parameter rejection tests also distinguish missing/null/wrong-type values. No actual upstream forwarding or adapter retry behavior is proven.'),
 'call-accounts.closed-values': (
  ['S-4','S-6','S-7','S-8','S-9','S-11','S-14','S-15','S-16','S-17','S-27','S-28','S-29','S-37'],
  [('judge.ts','judgeAccountValue'),('schema.ts','structureValid'),('schema.ts','snapshotJson'),('types.ts','AttemptId')],
  [('examples.spec.ts','.*'),('boundaries.spec.ts','.*'),('types.spec-d.ts','.*'),('calendar.spec.ts','.*')],
  '116 normative rows are each checked through Schema and ordered judgment, including required four token fields, explicit unknown, five rejection values and six-step priority. RunId/ModelCallId remain textual identities; AttemptId is an exact positive JSON integer. Inherited/getter/cycle/non-JSON objects are not repaired. Shared Instant behavior includes early years and explicit offset spellings.'),
 'call-accounts.exact-decimal': (
  ['S-4','S-5','S-6','S-12','S-23'],
  [('decimal.ts','ExactDecimal'),('decimal.ts','add('),('decimal.ts','compare('),('decimal.ts','toJsonNumber')],
  [('decimal.spec.ts','.*'),('boundaries.spec.ts','exact reasoning|subnormal')],
  'BigInt coefficient/exponent arithmetic preserves decimal amounts and token integers; no binary floating sum. Covers 0.1+0.2, more than 17 significant digits, equivalent exponents, negative zero and subnormal negatives. 200 fixed-seed 0x6c41 decimal trials compare with an independent integer-coefficient oracle. These are finite tests, not an unbounded mathematical proof.'),
 'call-accounts.correction-effective': (
  ['S-17','S-18','S-22','S-23','S-24','S-39'],
  [('evaluate.ts','effectiveTargets'),('evaluate.ts','effectiveCost'),('judge.ts','compareAccountInstants')],
  [('evaluate.spec.ts','correct|orphan|repeat|same callId|collision-free|latest|amounts|pair|invariant|input|getter|snapshot|late')],
  'Corrected cost uses exact Instant ordering including sub-millisecond and offset-equivalent instants. Equal-at equal decimal values are accepted, different amounts fail; a conflicting old pair still fails when a later correction exists. Local duplicate/orphan/tie failures are explicit and distinct from unknown. The input group is admitted before projection; original cost and alternate upstream cost remain unchanged.'),
 'call-accounts.summary-authority': (
  ['S-7','S-10','S-11','S-12','S-13','S-18','S-23','S-24'],
  [('evaluate.ts','AccountGroup'),('evaluate.ts','summarize('),('evaluate.ts','summarizeUsage'),('evaluate.ts','sum(')],
  [('evaluate.spec.ts','.*'),('usage.spec.ts','.*'),('types.spec-d.ts','.*')],
  'AccountGroup admission precedes immutable authority projection; model_response cost and tool own costs contribute, model_call mirrors/total_usd/tool Usage do not. Empty group is distinct from unknown accounts. Model-only summarizeUsage accepts explicit ModelUsageInput[] and cannot silently accept a monetary group; it does not decide unresolved G-10 full monetary-group token failure precedence. Ordinary unknown still contributes an unknown count.'),
 'skill-package.shape-declarations': (
  ['S-1','S-2','S-3','S-4','S-6','S-7','S-8','S-9','S-11','S-12','S-13','S-14','S-15','S-16','S-17','S-18','S-19','S-24','S-32'],
  [('judge.ts','judgeSkillPackage'),('declarations.ts','skillAttributeDeclarations'),('declarations.ts','skillReferences'),('dependencies.ts','skillDependencies'),('body.ts','skillBodyContract')],
  [('normative.spec.ts','.*'),('ports.spec.ts','.*'),('types.spec-d.ts','.*')],
  'Normative JSON examples/variants and ordered eight rejection values are separate from the text/directory reader domain. Author setting defaults are checked against exact owned domains; missing declaration members/type coercion are refused. Derivation copies immutable author settings only, no reserved governance or implicit host permissions. Genuine AM integration remains a W6 item.'),
 'skill-package.markdown-yaml': (
  ['S-4','S-5','S-8','S-20','S-24'],
  [('md.ts','readSkillMd'),('md.ts','keyValidity'),('md.ts','parseDocument'),('types.ts','SkillReadUndetermined')],
  [('readers.spec.ts','YAML|examples 6|block scalars|unknown keys|rejects|preserves every body|closing line|read gap|determined|M16|permits')],
  'YAML 2.9.1 parses YAML 1.2 Core with intAsBigInt, own equality handling and no scalar coercion. Whole-line LF/CRLF delimiters and BOM/first closer/body bytes are preserved. S5 ordinary unknown/external property keys are discarded with visible metadata, without rejecting the package. Unknown custom scalar tag in a key leaves canonical equality undefined by frozen2: undetermined is honest unresolved technical output, not contract-complete S20 success/rejection.'),
 'skill-package.normalized-package': (
  ['S-5','S-6','S-8','S-9','S-10','S-11','S-12','S-20','S-21','S-24'],
  [('entries.ts','readSkillPackage'),('judge.ts','pathEscapes'),('scripts.ts','skillScripts')],
  [('readers.spec.ts','row |caller-resolved|special file|strict JSON|prefix-conflicting|syntax failure|exact number|ordered rejection'),('types.spec-d.ts','.*')],
  'Pure normalized-entry half consumes caller observations: exact SKILL.md case, reserved definition path, unknown/special/unresolved/outside link facts, duplicate/prefix-conflicting paths, strict definition JSON, resource order and scripts/ classification. It neither reads the real filesystem nor resolves links. readSkillMd undetermined propagates before package construction; SP3 prevents full S20/S21 text-domain closure.'),
 'skill-package.dependency-projection-function': (
  ['S-9','S-11','S-13','S-14','S-16','S-17','S-32'],
  [('dependencies.ts','skillDependencies'),('scripts.ts','skillScripts'),('declarations.ts','skillReferences'),('body.ts','skillBodyContract')],
  [('ports.spec.ts','derives only|body port'),('readers.spec.ts','row 1|row 6'),('normative.spec.ts','.*')],
  'Emits exact declared tool/service/environment dependencies and script entries. Compatibility/allowed-tools/metadata do not become dependencies or permissions. No execution environment matching or script execution is inferred. BodyContract exports category-specific body and references/declarations, not a runtime loader.'),
 'mcp-endpoint.body-schema-and-url': (
  ['S-1','S-3','S-4','S-5','S-6','S-7','S-8','S-12','S-20','S-26'],
  [('judge.ts','judgeMcpValue'),('judge.ts','validUrl'),('schema.ts','validate'),('types.ts','McpEndpoint')],
  [('value-gates.spec.ts','.*')],
  'Seven fixed definitions plus semantic ordered receiver checks distinguish raw lowercase http/https, host, no fragment/userinfo, literal argv/environment and secret-free authored body. URL is admitted before WHATWG normalization; original input is retained. SC1 stdio admission does not execute a process or interpret a shell.'),
 'mcp-endpoint.action-copy': (
  ['S-9','S-10','S-20','S-23'],
  [('types.ts','ActionSnapshot'),('judge.ts','judgeMcpValue'),('schema.ts','validators')],
  [('value-gates.spec.ts','.*'),('declarations.spec.ts','knowledge provenance|action order'),('types.spec-d.ts','.*')],
  'not_fetched differs from fetched empty and fetched requires observation time. Remote descriptor inputSchema is an object-shaped JSON value, preserved with extension members; pathological regex and unavailable refs are never compiled here. Exact immutable declaration provenance does not prove a remote fetch occurred.'),
 'mcp-endpoint.names-and-attributes': (
  ['S-2','S-7','S-8','S-11','S-13','S-14','S-15','S-16','S-17','S-20','S-26'],
  [('judge.ts','actionEntryName'),('declarations.ts','deriveMcpDeclarations'),('declarations.ts','executeItem'),('body.ts','mcpBodyContract')],
  [('declarations.spec.ts','.*'),('value-gates.spec.ts','suffix|collision|rewrite|normative section 8|identifier'),('types.spec-d.ts','.*')],
  'endpoint:remote is exact literal concatenation, with no decoder/trimming or invented name normalization. Endpoint registration reserves 3-character projection suffix. Four fixed author declarations plus execute:raw-name entries preserve order, action snapshot knowledge, absent-vs-empty env and absent credentials. Current body port owns a complete frozen resource; old154 proves the former naked-ref port only. Current root157 is required for the stronger resource handoff.'),
 'slash-command.definition-port': (
  ['S-1','S-2','S-3','S-4','S-6','S-7','S-8','S-9','S-10','S-11','S-28'],
  [('body.ts','slashCommandBodyContract'),('declarations.ts','slashCommandAttributeDeclarations'),('declarations.ts','slashCommandReferences'),('judge.ts','judgeSlashCommand')],
  [('projections.spec.ts','P-'),('normative.spec.ts','EX-[12356]|shape|reserved|receiver'),('public.spec-d.ts','SC-6')],
  'The real category port owns its complete schema and returns empty category declarations for all 3 binding kinds; skill references are explicit and detached. AM alone appends disabled/usableBy. This is a non-vacuous body port test with valid and rejected bodies, all nine definitions, resource definitions/base URI, and mutation isolation, not an empty implementation inventory.'),
 'slash-command.recognition': (
  ['S-2','S-13','S-14','S-15'],
  [('recognize.ts','recognize'),('judge.ts','judgeInvocation')],
  [('normative.spec.ts','D-'),('boundaries.spec.ts','W-U|non-W|scalar-roundtrip|R-'),('walkthrough.spec.ts','CS-1|CS-2')],
  '50 fixed normative rows are applied through three caller forms of the same public function. An independent literal 26-codepoint whitespace table and scalar length oracles check exact raw/name/span and one-command/escaped // behavior. Lone surrogate is a technical precondition violation, not a fourth recognition arm. No cross-language implementation conformance is claimed.'),
 'slash-command.parse-bind': (
  ['S-8','S-9','S-16','S-17','S-18','S-19','S-20','S-23','S-28','S-29'],
  [('parser.ts','parseInvocation'),('parser.ts','tokenize'),('parser.ts','bind('),('parser.ts','valueOf'),('judge.ts','judgeInvocation')],
  [('normative.spec.ts','D-'),('boundaries.spec.ts','token |integer |named |B-'),('public.spec-d.ts','SC-3|SC-4'),('walkthrough.spec.ts','CS-1|CS-2|CS-4|CS-6')],
  'Exactly explicit Invocation+command set; no permission/context argument. Pre-admission snapshots protect input ownership. Tokenization precedes binding, unknown command precedes lexical failures, token first-error spans are original raw scalar positions, required checks come after supplied arguments. Safe-integer boundaries are decided with BigInt then converted; missing parameters and empty declarations are distinct.'),
 'slash-command.expansion': (
  ['S-3','S-4','S-6','S-10','S-20','S-21','S-22','S-23','S-28'],
  [('parser.ts','expandPrompt'),('template.ts','substitute'),('skill.ts','expandSkill')],
  [('projections.spec.ts','K-'),('boundaries.spec.ts','T-'),('normative.spec.ts','EX-5|D-'),('walkthrough.spec.ts','CS-3|CS-6')],
  'Prompt substitution is one-pass with longest digit placeholder and exact escaping/raw argument rules. Selected skill and caller block labels are explicit inputs; body is never interpolated. S22 gives two exact blocks when arguments exist, and omits the argument block for empty arguments (the matrix short phrase does not override S22). Invalid annotations/count/package fail technical preconditions; caller authorization/logging/delivery remain external.'),
 'slash-command.invocation-judge-function': (
  ['S-13','S-14','S-15','S-26','S-28','S-29'],
  [('judge.ts','judgeInvocation'),('judge.ts','invocationLegal'),('recognize.ts','recognize'),('parser.ts','parseInvocation')],
  [('boundaries.spec.ts','scalar-roundtrip|R-precondition|raw|Invocation|invocation|span|JSON|getter'),('walkthrough.spec.ts','CS-2'),('normative.spec.ts','EX-3|D-')],
  'The separately exported judge recomputes recognition from raw and compares exact name, argumentText and codepoint span. Forged raw/span/argument strings are malformed; parser snapshots and checks invocation before proceeding. No repair or conversion to a parse failure branch is used to admit malformed invocation.'),
}

CS_NOTES = {
 'model-profile': {
  1: 'Only exact customized reference and withdrawn/listed pure data. Withdrawal observation, directory resolution and failed run remain external.',
  2: 'Only draft shape/content and explicit scoped-reference data. Same-scope uniqueness write admission is external.',
  3: 'Only allowed provider list/allowFallback data and precise reference. Retry policy/executor actual emissions and fallback selection remain external.',
  4: 'Only parameter vocabulary/present keys and unchanged extras. Adapter error reporting, no-drop and retry behavior remain external.',
  5: 'Only modality, exact limits and snapshot/content representations. Real model message assembly and log snapshot ownership are external.'},
 'skill-package': {
  2: 'Only explicit name/description plus declared dependencies. Registry availability/current installed dependency facts and environment matching are external.',
  3: 'Only supplied text/package body/resource representation. Skills() authorization and actual resource byte reads are external. Related input text SP3 remains unresolved.',
  4: 'Only script membership, environment requirement and setting projection. Actual Skills().exec_script authorization, environment composition and execution are external; normalized reader SP3 caveat remains.',
  8: 'Only immutable whole SkillPackage value. Resource byte transfer/version-integrity and destination configuration retention are external.'},
 'mcp-endpoint': {
  1: 'Only secret-free body and exact credential reference declaration domain. Governed credential write/current grant/resolution/seal are external.',
  3: 'Only explicit action snapshot/raw naming/timeout and immutable attribute declarations. Live bridge tools/list conversion/protocol failure/current OAuth resolution are external.',
  4: 'Only body/credential declaration domain values. Setting UI, custodian authorization and secret treatment on display are external.'},
 'slash-command': {
  1: 'Same pure public parsing produces exact failure; actual delivery dispatch and no outbound effect are external.',
  2: 'Caller supplies current command set explicitly; removed/nonexistent both unknown. Actual reception timing/reacquisition/authorization isolation is external.',
  3: 'Explicit chosen valid skill/package and caller annotations produce exact blocks. Authorization success, record writing and sending are external.',
  4: 'Explicit command set has valid origin/name/binding; current registry installed-set selection remains external.',
  6: 'Importer supplies already translated definition; template semantics are checked locally. External ecosystem metadata translation/import is external.'},
}


def clause(node, label):
    path = f'.meta_harness/design/spec/data/{node}/v2/contract.md'
    pattern = rf'^#+ .*?\b{re.escape(label)}(?:\s|\b)'
    for number, text in enumerate((HUB / path).read_text().splitlines(), 1):
        if re.search(pattern, text):
            return {'path': path, 'section': label, 'line': number, 'heading': text.lstrip('# ')}
    raise ValueError((node, label, 'missing clause'))


def source(node, filename, marker):
    path = f'packages/core/{node}/src/{filename}'
    lines = (HUB / path).read_text().splitlines()
    matches = [i for i, line in enumerate(lines, 1) if marker in line]
    if not matches:
        raise ValueError((path, marker, 'missing source marker'))
    return {'path': path, 'marker': marker, 'lines': matches,
            'sha256': hashlib.sha256((HUB / path).read_bytes()).hexdigest()}


def tests(node, selectors):
    selected = []
    for basename, pattern in selectors:
        found = []
        for report in history[node]['test_inventory']:
            if Path(report['file']).name == basename:
                found.extend(x for x in report['assertions'] if re.search(pattern, x['fullName']))
        # The MCP type-only file has top-level expectTypeOf rather than Vitest it.
        src = next(x for x in inventory[node]['test_sources'] if Path(x['path']).name == basename)
        selected.append({'file': src['path'], 'current_source_sha256': src['sha256'],
                         'selector': pattern, 'historical_executed_assertions': found,
                         'current_source_test_expressions': src['test_expressions'],
                         'typecheck_only_file': not src['test_expressions']})
    return selected


def guard_subset(node):
    records = []
    for dirname, record in guards.items():
        matching = [r for r in record['probes']['records'] if r['name'].startswith(node + '-')]
        if matching:
            records.append({'bundle': dirname, 'source_head': record['probes']['sourceHead'],
                             'seal_failed_count': record['seal_verification']['failed_count'],
                             'records': matching,
                             'diagnostic_condition': 'Negative cases assert hasBodyGuard for body-projection-inputs, expected exit1, no signal and changed target path; nonzero alone is not sufficient.'})
    return records


def common(node, kind):
    if kind == 'schema-frozen-bytes':
        if node in ['model-profile', 'call-accounts']:
            file = 'examples.spec.ts'
        elif node == 'skill-package':
            file = 'normative.spec.ts'
        elif node == 'mcp-endpoint':
            file = 'value-gates.spec.ts'
        else:
            file = 'normative.spec.ts'
        return ([], [('schema.ts','validate'),('schema.ts','SCHEMA_DEF_NAMES')], [(file, '.*')],
                'Static exact byte hashes and owned-selector reference closure have been independently collected. Actual validator outcomes remain separately bound to normative examples and semantic judges; final current root test run is still required.')
    if kind == 'public-package-consumer':
        typefile = 'public.spec-d.ts' if node == 'slash-command' else 'types.spec-d.ts'
        return ([], [('index.ts','export'),('schema.ts','SCHEMA_DEF_NAMES')], [(typefile, '.*')],
                'Complete actual runtime/type/JSON subpath inventory is attached, not inferred from a small consumer. Historical built consumers have explicit commands/log hashes but some import only a subset. Final root W6 independent installed/packed consumer must cover every listed symbol and resource, strict mutual-state/type counterexamples and precise private-subpath refusal.')
    if kind == 'source-purity':
        markers = [('index.ts','export'),('schema.ts','import')]
        files = []
        if node in ['skill-package','mcp-endpoint','slash-command']:
            markers.append(('declarations.ts','import type'))
        if node == 'mcp-endpoint':
            files = [('source-purity.spec.ts','.*')]
        return ([], markers, files,
                'Actual src imports/public functions were inspected separately from old CLI results. Import allowlisting does not prove runtime purity. Historical body-projection controls assert a specific diagnostic at the mutated target; current root must run maintained core-pure-imports plus checker negative suite and positive scan against this exact source. No ambient runtime/session/Cordis state is supplied to these public pure functions.')
    raise ValueError(kind)


rows = []
for original in matrix['obligations']:
    node, identity = original['node'], original['id']
    if node not in inventory:
        continue
    record = {'id': identity, 'node': node, 'stage': original['stage'],
              'owner': original['owner'], 'input_coordinate': original['input_coordinate'],
              'original_input_coordinate': original.get('original_input_coordinate'),
              'coordinate_adoption': original.get('coordinate_adoption'),
              'scope_disposition': original.get('scope_disposition'),
              'matrix_source': original.get('current_source', original['source']),
              'matrix_obligation': original['obligation'],
              'mandatory_evidence': original['mandatory_evidence'],
              'linked_obligation_ids': original.get('linked_obligation_ids', []),
              'technical_acceptance': None,
              'audit_role': 'Read-only evidence author; root independently decides technical acceptance.'}
    if original['stage'] != 'core-local':
        record['finding'] = 'original-owner-and-stage-preserved; no acceptance by this audit'
        record['current_clauses'] = []
        for entry in record['matrix_source']:
            match = re.search(r'CS-\d+', entry['section'])
            if match:
                record['current_clauses'].append(clause(node, match[0]))
        record['handoff'] = ('W6 owner must supply current real-core composition evidence; local linked evidence cannot close this row.'
                            if original['stage'] == 'core-composition' else
                            'Whole-CS/runtime/storage/FS/protocol effect remains with the original external owner; this audit does not close it.')
        if identity in ['skill-package.walkthrough-cs-6', 'skill-package.walkthrough-cs-6-core-step']:
            record['uncovered'] = ['SP3: unknown custom scalar tag in a YAML key prevents frozen2 canonical duplicate/equality determination. Full S20/CS6 closure awaits semantic owner ruling; ordinary unknown keys still follow S5.']
        else:
            record['uncovered'] = [record['handoff']]
        rows.append(record)
        continue
    suffix = identity.removeprefix(node + '.')
    linked = original.get('linked_obligation_ids', [])
    if identity in BASE:
        selected_bases = [identity]
    elif suffix in ['public-package-consumer','source-purity','schema-frozen-bytes']:
        selected_bases = [identity]
    elif suffix.startswith('walkthrough-'):
        selected_bases = [x for x in linked if x in BASE]
        if not selected_bases:
            raise ValueError((identity, linked, 'no local mapping'))
    else:
        raise ValueError((identity, 'unmapped original ID'))
    clauses, locations, selectors, notes = [], [], [], []
    for base in selected_bases:
        item = BASE.get(base)
        if item is None:
            item = common(node, suffix)
        labels, markers, selected, note = item
        clauses.extend(clause(node, label) for label in labels)
        locations.extend(source(node, filename, marker) for filename, marker in markers)
        selectors.extend(selected)
        notes.append(note)
    if suffix.startswith('walkthrough-'):
        index = int(re.search(r'cs-(\d+)', suffix)[1])
        clauses.append(clause(node, f'CS-{index}'))
        notes.append(CS_NOTES[node][index])
        if node == 'slash-command':
            selectors.append(('walkthrough.spec.ts',f'CS-{index}'))
    record['current_clauses'] = list({(x['path'],x['section']):x for x in clauses}.values())
    record['source_protection_points'] = list({(x['path'],x['marker']):x for x in locations}.values())
    record['actual_test_evidence'] = tests(node, list(dict.fromkeys(selectors)))
    record['observations'] = notes
    record['historical_reuse'] = {
        'summary': history[node]['summary'], 'raw_test_report': history[node]['raw_test_report'],
        'raw_test_report_sha256': history[node]['raw_test_report_sha256'],
        'input_and_source_record': history[node]['provenance'],
        'input_and_source_record_sha256': history[node]['provenance_sha256'],
        'sealed_regular_files_verified': history[node]['seal_verification']['verified_count'],
        'sealed_regular_file_failures': history[node]['seal_verification']['failed_count'],
        'current_source_delta': [x for x in history[node]['source_comparisons']
                                 if not x['identical_bytes']],
        'applicability': 'Historical v1 run only. D066 identity clause mapping, retained exact v2 resource imports and the current hashes are explicit prerequisites. Reuse supplies regression context; current test names/files may have changed and root must rerun actual current package tests/typecheck/build without relabeling the old run.'}
    record['finding'] = 'evidence-mapped; pending-root-current-run-and-technical-decision'
    record['root_independent_verification_required'] = [
        f'Current @omne-harness-lite/{node} package test/typecheck/build in final root make check; record actual command, exits, zero skip, source/config/environment hashes.',
        'Final W6 installed public consumer and current static checker evidence are needed for the common consumer/purity rows; only owner evidence can satisfy composition rows.']
    record['uncovered'] = []
    if suffix == 'schema-frozen-bytes':
        record['resources'] = inventory[node]['resources']
        record['schema_value'] = {k: inventory[node][k] for k in
                                 ['package_schema','package_schema_sha256','package_schema_matches_frozen','schema_id','schema_defs']}
        record['retained_resource_closure'] = graphs[node]
    if suffix == 'public-package-consumer':
        record['public_surface'] = {k: inventory[node][k] for k in
                                    ['public_symbols','package_exports','schema_id','schema_defs']}
        record['public_surface']['public_class_members'] = inventory[node].get('public_class_members', {})
        record['uncovered'].append('Old limited consumer imports do not establish completeness of the current full inventory. Final W6 consumer must demonstrate all actual runtime/type/schema selectors and exact denied private imports, not any arbitrary failing tsc/node command.')
    if suffix == 'source-purity':
        record['historical_checker_controls'] = guard_subset(node)
        record['uncovered'].append('This read-only audit did not execute current core-pure-imports negative controls or the real current CLI scan. Historical mutation controls and direct source inspection do not substitute for root final current source/checker evidence.')
    sp3 = node == 'skill-package' and any(base in selected_bases for base in
                       ['skill-package.markdown-yaml','skill-package.normalized-package'])
    if sp3:
        record['finding'] = ('evidence-mapped; inherited-reader-caveat; caller-supplied determined package remains independently checkable'
                             if identity == 'skill-package.walkthrough-cs-4-core-step' else
                             'partial-input-domain; SP3 unresolved; ordinary independent local cases remain mapped')
        record['uncovered'].append('S20#5 canonical equality/duplicate keys with an unknown custom scalar tag used as key is unspecified in frozen2. Current undetermined propagates into normalized package reading; S20/full CS6 cannot be signed. Do not label this malformed or reject all ordinary unknown fields (S5).')
    if node == 'mcp-endpoint' and (suffix in ['names-and-attributes','public-package-consumer','schema-frozen-bytes'] or 3 == (int(re.search(r'cs-(\d+)',suffix)[1]) if suffix.startswith('walkthrough-') else -1)):
        record['current_root_supplement'] = 'mcp-current-root-evidence.json: initial155pass/2failure retained; fixture Loop2->Loop3 for actual AM3, product MCP2 untouched; current157 pass and type/format logs. Root W6 dependency run still owns final integrated result.'
        record['actual_test_evidence'].append({
            'file': 'packages/core/mcp-endpoint/tests/body-resource.spec.ts',
            'current_source_sha256': hashlib.sha256((HUB/'packages/core/mcp-endpoint/tests/body-resource.spec.ts').read_bytes()).hexdigest(),
            'current_source_test_expressions': next(x['test_expressions'] for x in inventory[node]['test_sources']
                           if x['path'].endswith('/body-resource.spec.ts')),
            'historical_executed_assertions': [],
            'current_run_reference': 'mcp-current-root-evidence.json',
            'boundary': 'Root current157 supplemental run, not part of historical154.'})
    rows.append(record)

assert len(rows) == 89
assert sum(x['stage']=='core-local' for x in rows) == 52
assert len({x['id'] for x in rows}) == 89
write('obligation-evidence-map.json', {
    'format':1, 'input_matrix_sha256':hashlib.sha256((OUT/'input-acceptance-matrix.json').read_bytes()).hexdigest(),
    'head_at_mapping':subprocess.check_output(['git','rev-parse','HEAD'],cwd=HUB,text=True).strip(),
    'authority':'Read-only authored technical findings, no technical or final acceptance.',
    'scope':'Five retained data/v2 nodes; 52 local rows and original9 composition/28 external preserved.',
    'obligations':rows})
print('mapped', len(rows), 'rows; SP3 partial', [x['id'] for x in rows if x['finding'].startswith('partial')])
