# Retained core v2 local evidence audit

这是技术证据作者的只读发现，未签收任何义务。主调度需亲自核对并使用当前全量检查作技术接受；最后总体交付接受仍归人。

HUB：`panqiwei/core-delivery@a53644ad585d433627073c066f46d500f1aee6c6`。首动作定位 `98462a0b62dff8fc48f407076090eb22a6633d04`；本报告输入矩阵固定为 `eb454167f973f7decab97842f92cb9fa9c9e6392a7537bca2d03167373cc3c80`。根可追加接受记录；原 327 项的 ID、阶段、归属、source、坐标、链接与范围投影在收尾复核时未变。

使用 worktree-discipline 核对给定 HUB；按 harness-design-handbook 的 handoff/spec-evolution 读取本任务明确的接受坐标和 realization。只写本目录，没有执行产品测试、构建、格式化，或修改源码、规格、锁、矩阵、原 seal、主分支。

## 结果与局限

- 89 项完整逐 ID 地图：52 core-local、9 core-composition、28 external；后两类保持原归属，whole-CS 与 Connector 纵线未被这份审计收口。
- 15 份 contract/schema/examples 对 frozen 登记 SHA 全部精确匹配，五份包内 Schema 与各自接受 v2 精确同字节。21 个实际 Schema import 都记录了 exports 目标与 frozen 真身；从各公开自有 `$defs` 出发的静态引用闭包无缺失。此项不是执行 Schema 判别器。
- 五个原封存的实际 JSON 测试报告分别是 185、602、406、154、408 通过，均 0 失败、0 跳过；它们保留 v1 运行时期。D066 的 identity 条款迁移与当前保留 v2 Schema 导入支持对应关系，但旧结果不被改称 v2 当前运行。
- Skill SP3：未知自定义 YAML scalar tag 用于键时，冻结 v2 没有决定 canonical equality/重复键规则。当前 `undetermined` 诚实保留缺口，不能签全 S20 或 CS6；normalized reader 传播这一分支。普通未知属性仍按 S5 忽略并留可见痕迹。CS3 相关读入域标局部未闭合，CS4 的已经明确提供的包/脚本成员仍可独立核对。
- MCP 的完整 Schema 资源端口在旧154封存后补强；初次当前运行155绿/2红保留。实际 fixture 调用 AM3，却提供 Loop2；仅将 fixture 的 Loop 资源换成3，保留断言与 MCP 产品/Schema2。根的新日志记录157通过，类型与格式日志也保留；全 W6 与最终根检查继续归其拥有者。
- 历史有限消费者不等于完整当前公开面；JSON 中列出每个实际函数、类型、类方法、Schema selector、JSON subpath。root/W6 必须使用完整正向消费者和明确的 TS/Node 私有子路径拒绝证据，不能把任意非零退出当负控。
- 现行 core-pure-imports CLI 正扫与负控需要根的当前 source/checker 运行。历史 body-projection probes 有明确的诊断名、被突变的实际模块、预期退出1/无signal，不只记录非零。导入绿也不能代替运行纯性的检查。

## 证据入口

| 文件 | 内容 |
| --- | --- |
| [obligation-evidence-map.json](obligation-evidence-map.json) | 全89原ID、精确当前条款/行号、实际测试名/文件/源SHA、源码保护点、旧封存及复用前提、未覆盖与根复验 |
| [current-inventory.json](current-inventory.json) | 接受坐标、完整实际公开面/类型/类方法/Schema defs/subpaths、全部五包维护文件与文档SHA |
| [retained-schema-resource-closure.json](retained-schema-resource-closure.json) | 原样v2 Schema资源真身导入、实际exports映射与自有selector静态引用闭包 |
| [historical-evidence.json](historical-evidence.json) | 每份原seal校验、实际 raw JSON test名/状态、原输入/环境/命令/source记录、逐文件当前SHA比较 |
| [source-delta-readback.json](source-delta-readback.json) | 历史提交到当前源码的 Git 差异取证；纯值算法未改，Schema导入限定旧2/expiry1，MCP端口补完整资源 |
| [guard-evidence.json](guard-evidence.json) | W4/W5真实静态checker的原封存、具体诊断负控、测量器自检与限制 |
| [mcp-current-root-evidence.json](mcp-current-root-evidence.json) | 根的原红、fixture依据/前后SHA、当前157/类型/格式原件路径与SHA |
| [audit-consistency.json](audit-consistency.json) | 327项不改范围/归属、89项未接受、52项源码映射、测试引用与收尾无漂移检查 |
| [collector-controls.json](collector-controls.json) | 取证工具能发现故意缺失ref并解析数组JSON pointer的自检；非产品验证 |

## 原封存实际可复用范围

| 节点 | 原raw tests | seal覆盖regular文件 | 主要当前变化与限制 |
| --- | ---: | ---: | --- |
| model-profile | 185 | 16 | 算法与类型字节保留；schema import 显式 content2/expiry1、冻结2与例子坐标/哈希已更新；最终当前运行待根。 |
| call-accounts | 602 | 75 | 精确计算与admission字节保留；schema import显式content2/expiry1、冻结2/例子fixture已更新；model-only Usage helper不裁G10。 |
| skill-package | 406 | 53 | YAML/规范化/判断算法字节保留；schema import显式AM2/CB2/TD2，当前测试owned-ref指2；SP3不闭合。 |
| mcp-endpoint | 154 | 92 | schema与宣告ref显式旧2；body从裸ref补完整资源并新增3项测试，需用root当前157替代此段旧154论据。 |
| slash-command | 408 | 50 | 识别/解析/展开/端口算法字节保留；schema import显式AM2/CB2，schema及测试冻结来源更新；原consumer 6条链接描述不能证明当前依赖安装。 |

所有 raw JSON 测试报告与输入/source provenance 本身都在各原 seal 的已核对 regular文件中；未改任何 seal。W4/W5 checker seals分别578/644个regular文件全部一致。Slash archive保留6个symlink描述，目标字符串hash一致，但归档没有这6条node_modules链接，亦未封存依赖树；故只证明当时命令/日志与链接描述，不证明已构建消费者能在当前环境原样重放。

MCP fixture 前后SHA分别 `98b79c2e37c4f0900d1b048d81b26c789578db89a6f665a1d61338110fdb5964` / `9b765d92ca2abfa240d694a32f98d7d9fbf6b24acb5d539cc7bdfff1df28b734`，当前源码与后者一致。根after日志是157实际通过；before JSON有独立exit元数据，after/type/format日志本身没有独立exit元数据，本报告没有替根补造它们。最终make原始命令/exit与SHA应补全最后接受依据。

## 52 项本地证据导航

下表只是导航，全部实际实例测试名称、对应source/hash、采用条款和局限在 JSON；“待根”不是接受。

| 原ID | 当前条款 | 实际测试文件 | 局限 |
| --- | --- | --- | --- |
| model-profile.self-shape-order | S-2, S-4, S-5, S-6, S-7, S-8, S-9, S-10, S-11, S-13, S-16, S-24, S-25, S-28 | examples.spec.ts, behavior.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| model-profile.max-output | S-8, S-16, S-18, S-24, S-25, S-27, S-28 | behavior.spec.ts | 当前独立运行待根 |
| model-profile.exact-reference | S-1, S-7, S-13, S-14 | behavior.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| call-accounts.closed-values | S-4, S-6, S-7, S-8, S-9, S-11, S-14, S-15, S-16, S-17, S-27, S-28, S-29, S-37 | examples.spec.ts, boundaries.spec.ts, types.spec-d.ts, calendar.spec.ts | 当前独立运行待根 |
| call-accounts.exact-decimal | S-4, S-5, S-6, S-12, S-23 | decimal.spec.ts, boundaries.spec.ts | 当前独立运行待根 |
| call-accounts.correction-effective | S-17, S-18, S-22, S-23, S-24, S-39 | evaluate.spec.ts | 当前独立运行待根 |
| call-accounts.summary-authority | S-7, S-10, S-11, S-12, S-13, S-18, S-23, S-24 | evaluate.spec.ts, usage.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| skill-package.shape-declarations | S-1, S-2, S-3, S-4, S-6, S-7, S-8, S-9, S-11, S-12, S-13, S-14, S-15, S-16, S-17, S-18, S-19, S-24, S-32 | normative.spec.ts, ports.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| skill-package.markdown-yaml | S-4, S-5, S-8, S-20, S-24 | readers.spec.ts | SP3读入域 |
| skill-package.normalized-package | S-5, S-6, S-8, S-9, S-10, S-11, S-12, S-20, S-21, S-24 | readers.spec.ts, types.spec-d.ts | SP3读入域 |
| mcp-endpoint.body-schema-and-url | S-1, S-3, S-4, S-5, S-6, S-7, S-8, S-12, S-20, S-26 | value-gates.spec.ts | 当前独立运行待根 |
| mcp-endpoint.action-copy | S-9, S-10, S-20, S-23 | value-gates.spec.ts, declarations.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| mcp-endpoint.names-and-attributes | S-2, S-7, S-8, S-11, S-13, S-14, S-15, S-16, S-17, S-20, S-26 | declarations.spec.ts, value-gates.spec.ts, types.spec-d.ts, body-resource.spec.ts | 当前独立运行待根 |
| slash-command.definition-port | S-1, S-2, S-3, S-4, S-6, S-7, S-8, S-9, S-10, S-11, S-28 | projections.spec.ts, normative.spec.ts, public.spec-d.ts | 当前独立运行待根 |
| slash-command.recognition | S-2, S-13, S-14, S-15 | normative.spec.ts, boundaries.spec.ts, walkthrough.spec.ts | 当前独立运行待根 |
| slash-command.parse-bind | S-8, S-9, S-16, S-17, S-18, S-19, S-20, S-23, S-28, S-29 | normative.spec.ts, boundaries.spec.ts, public.spec-d.ts, walkthrough.spec.ts | 当前独立运行待根 |
| slash-command.expansion | S-3, S-4, S-6, S-10, S-20, S-21, S-22, S-23, S-28 | projections.spec.ts, boundaries.spec.ts, normative.spec.ts, walkthrough.spec.ts | 当前独立运行待根 |
| call-accounts.public-package-consumer | realization公开面／计划共同门 | types.spec-d.ts | 完整公共消费者待W6/根 |
| call-accounts.source-purity | realization公开面／计划共同门 | 真实source/checker门 | 当前CLI正扫/负控待根 |
| call-accounts.schema-frozen-bytes | realization公开面／计划共同门 | examples.spec.ts | 当前独立运行待根 |
| mcp-endpoint.public-package-consumer | realization公开面／计划共同门 | types.spec-d.ts, body-resource.spec.ts | 完整公共消费者待W6/根 |
| mcp-endpoint.source-purity | realization公开面／计划共同门 | source-purity.spec.ts | 当前CLI正扫/负控待根 |
| mcp-endpoint.schema-frozen-bytes | realization公开面／计划共同门 | value-gates.spec.ts, body-resource.spec.ts | 当前独立运行待根 |
| model-profile.public-package-consumer | realization公开面／计划共同门 | types.spec-d.ts | 完整公共消费者待W6/根 |
| model-profile.source-purity | realization公开面／计划共同门 | 真实source/checker门 | 当前CLI正扫/负控待根 |
| model-profile.schema-frozen-bytes | realization公开面／计划共同门 | examples.spec.ts | 当前独立运行待根 |
| skill-package.public-package-consumer | realization公开面／计划共同门 | types.spec-d.ts | 完整公共消费者待W6/根 |
| skill-package.source-purity | realization公开面／计划共同门 | 真实source/checker门 | 当前CLI正扫/负控待根 |
| skill-package.schema-frozen-bytes | realization公开面／计划共同门 | normative.spec.ts | 当前独立运行待根 |
| slash-command.public-package-consumer | realization公开面／计划共同门 | public.spec-d.ts | 完整公共消费者待W6/根 |
| slash-command.source-purity | realization公开面／计划共同门 | 真实source/checker门 | 当前CLI正扫/负控待根 |
| slash-command.schema-frozen-bytes | realization公开面／计划共同门 | normative.spec.ts | 当前独立运行待根 |
| model-profile.walkthrough-cs-1-core-step | S-1, S-7, S-13, S-14, CS-1 | behavior.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| model-profile.walkthrough-cs-2-core-step | S-2, S-4, S-5, S-6, S-7, S-8, S-9, S-10, S-11, S-13, S-16, S-24, S-25, S-28, CS-2 | examples.spec.ts, behavior.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| model-profile.walkthrough-cs-3-core-step | S-1, S-7, S-13, S-14, CS-3 | behavior.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| model-profile.walkthrough-cs-4-core-step | S-2, S-4, S-5, S-6, S-7, S-8, S-9, S-10, S-11, S-13, S-16, S-24, S-25, S-28, CS-4 | examples.spec.ts, behavior.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| model-profile.walkthrough-cs-5-core-step | S-2, S-4, S-5, S-6, S-7, S-8, S-9, S-10, S-11, S-13, S-16, S-24, S-25, S-28, CS-5 | examples.spec.ts, behavior.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| skill-package.walkthrough-cs-2-core-step | S-1, S-2, S-3, S-4, S-6, S-7, S-8, S-9, S-11, S-12, S-13, S-14, S-15, S-16, S-17, S-18, S-19, S-24, S-32, CS-2 | normative.spec.ts, ports.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| skill-package.walkthrough-cs-3-core-step | S-4, S-5, S-8, S-20, S-24, CS-3 | readers.spec.ts | SP3读入域 |
| skill-package.walkthrough-cs-4-core-step | S-5, S-6, S-8, S-9, S-10, S-11, S-12, S-20, S-21, S-24, CS-4 | readers.spec.ts, types.spec-d.ts | 已提供包可独立核对；SP3读入传播 |
| skill-package.walkthrough-cs-8-core-step | S-1, S-2, S-3, S-4, S-6, S-7, S-8, S-9, S-11, S-12, S-13, S-14, S-15, S-16, S-17, S-18, S-19, S-24, S-32, CS-8 | normative.spec.ts, ports.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| mcp-endpoint.walkthrough-cs-1-core-step | S-1, S-3, S-4, S-5, S-6, S-7, S-8, S-12, S-20, S-26, CS-1 | value-gates.spec.ts | 当前独立运行待根 |
| mcp-endpoint.walkthrough-cs-3-core-step | S-9, S-10, S-20, S-23, S-2, S-7, S-8, S-11, S-13, S-14, S-15, S-16, S-17, S-26, CS-3 | value-gates.spec.ts, declarations.spec.ts, types.spec-d.ts, body-resource.spec.ts | 当前独立运行待根 |
| mcp-endpoint.walkthrough-cs-4-core-step | S-1, S-3, S-4, S-5, S-6, S-7, S-8, S-12, S-20, S-26, CS-4 | value-gates.spec.ts | 当前独立运行待根 |
| slash-command.walkthrough-cs-1-core-step | S-2, S-13, S-14, S-15, S-8, S-9, S-16, S-17, S-18, S-19, S-20, S-23, S-28, S-29, CS-1 | normative.spec.ts, boundaries.spec.ts, walkthrough.spec.ts, public.spec-d.ts | 当前独立运行待根 |
| slash-command.walkthrough-cs-2-core-step | S-2, S-13, S-14, S-15, S-8, S-9, S-16, S-17, S-18, S-19, S-20, S-23, S-28, S-29, CS-2 | normative.spec.ts, boundaries.spec.ts, walkthrough.spec.ts, public.spec-d.ts | 当前独立运行待根 |
| slash-command.walkthrough-cs-3-core-step | S-3, S-4, S-6, S-10, S-20, S-21, S-22, S-23, S-28, CS-3 | projections.spec.ts, boundaries.spec.ts, normative.spec.ts, walkthrough.spec.ts | 当前独立运行待根 |
| slash-command.walkthrough-cs-4-core-step | S-1, S-2, S-3, S-4, S-6, S-7, S-8, S-9, S-10, S-11, S-28, S-13, S-14, S-15, CS-4 | projections.spec.ts, normative.spec.ts, public.spec-d.ts, boundaries.spec.ts, walkthrough.spec.ts | 当前独立运行待根 |
| slash-command.walkthrough-cs-6-core-step | S-1, S-2, S-3, S-4, S-6, S-7, S-8, S-9, S-10, S-11, S-28, S-20, S-21, S-22, S-23, CS-6 | projections.spec.ts, normative.spec.ts, public.spec-d.ts, boundaries.spec.ts, walkthrough.spec.ts | 当前独立运行待根 |
| model-profile.parameter-name-function | S-15, S-16, S-17, S-19, S-20, S-21 | behavior.spec.ts, types.spec-d.ts | 当前独立运行待根 |
| skill-package.dependency-projection-function | S-9, S-11, S-13, S-14, S-16, S-17, S-32 | ports.spec.ts, readers.spec.ts, normative.spec.ts | 当前独立运行待根 |
| slash-command.invocation-judge-function | S-13, S-14, S-15, S-26, S-28, S-29 | boundaries.spec.ts, walkthrough.spec.ts, normative.spec.ts | 当前独立运行待根 |

## 37 项范围归属保持

| 原ID | 原阶段 | 原拥有者 |
| --- | --- | --- |
| model-profile.directory-runtime | external | 模型档案目录与模型请求运行时 owner |
| call-accounts.stream-account-chain | core-composition | root W6 核心组合交付负责人 |
| call-accounts.persisted-ledger | external | 模型/工具请求运行时、session-log、计量组装与trim生产者 owner |
| skill-package.filesystem-execution | external | Skills 读/脚本执行者、目录读取与放行 owner |
| mcp-endpoint.schema-boundary-chain | core-composition | root W6 核心组合交付负责人 |
| mcp-endpoint.bridge-custodian | external | MCP bridge、凭据 custodian、资产治理 owner |
| slash-command.delivery-reception | external | 交付/受理面、asset-registry/governance、导入器与ServiceName解析 owner |
| mcp-endpoint.walkthrough-cs-1 | external | data.asset-model；capability.asset-governance 的对应消费者/提供者；事实来源owner按同节前提 |
| mcp-endpoint.walkthrough-cs-2 | external | capability.asset-evaluation 的对应消费者/提供者；事实来源owner按同节前提 |
| mcp-endpoint.walkthrough-cs-3 | external | capability.mcp-bridge 的对应消费者/提供者；事实来源owner按同节前提 |
| mcp-endpoint.walkthrough-cs-4 | external | 同节明确点名的 设置页要呈现「有没有、哪一层的、什么时候取的」：  有没有  看这一格有没有凭据配值；  哪一层  看这份持有的格；   什么时候取的  ：经 OAuth 的，看这份持有上  granted owner |
| model-profile.walkthrough-cs-1 | external | capability.model-profile-directory 的对应消费者/提供者；事实来源owner按同节前提 |
| model-profile.walkthrough-cs-2 | external | 同节明确点名的 维护档案的能力 owner |
| model-profile.walkthrough-cs-3 | external | 同节明确点名的 默认重试件 owner |
| model-profile.walkthrough-cs-4 | external | data.model-response 的对应消费者/提供者；事实来源owner按同节前提 |
| model-profile.walkthrough-cs-5 | external | 同节明确点名的 组装 owner |
| skill-package.walkthrough-cs-1 | external | data.asset-model；capability.name 的对应消费者/提供者；事实来源owner按同节前提 |
| skill-package.walkthrough-cs-2 | external | capability.asset-registry；data.tool-definition 的对应消费者/提供者；事实来源owner按同节前提 |
| skill-package.walkthrough-cs-3 | external | 同节明确点名的 Skills()  的契约 owner |
| skill-package.walkthrough-cs-4 | external | data.tool-definition；data.asset-model 的对应消费者/提供者；事实来源owner按同节前提 |
| skill-package.walkthrough-cs-5 | external | data.content-blocks 的对应消费者/提供者；事实来源owner按同节前提 |
| skill-package.walkthrough-cs-6 | external | capability.asset-evaluation；data.asset-model 的对应消费者/提供者；事实来源owner按同节前提 |
| skill-package.walkthrough-cs-7 | external | capability.asset-evaluation；data.asset-model 的对应消费者/提供者；事实来源owner按同节前提 |
| skill-package.walkthrough-cs-8 | external | capability.asset-transfer 的对应消费者/提供者；事实来源owner按同节前提 |
| slash-command.walkthrough-cs-1 | external | 同节明确点名的 交付面（人读形式） owner |
| slash-command.walkthrough-cs-2 | external | 同节明确点名的 受理面 owner |
| slash-command.walkthrough-cs-3 | external | 同节明确点名的 受理面 owner |
| slash-command.walkthrough-cs-4 | external | capability.asset-registry；capability.name 的对应消费者/提供者；事实来源owner按同节前提 |
| slash-command.walkthrough-cs-5 | external | capability.asset-governance 的对应消费者/提供者；事实来源owner按同节前提 |
| slash-command.walkthrough-cs-6 | external | 同节明确点名的 导入器 owner |
| skill-package.walkthrough-cs-1-core-step | core-composition | root W6 组合交付负责人及对应真实core节点 |
| skill-package.walkthrough-cs-5-core-step | core-composition | root W6 组合交付负责人及对应真实core节点 |
| skill-package.walkthrough-cs-6-core-step | core-composition | root W6 组合交付负责人及对应真实core节点 |
| skill-package.walkthrough-cs-7-core-step | core-composition | root W6 组合交付负责人及对应真实core节点 |
| mcp-endpoint.walkthrough-cs-2-core-step | core-composition | root W6 组合交付负责人及对应真实core节点 |
| slash-command.walkthrough-cs-5-core-step | core-composition | root W6 组合交付负责人及对应真实core节点 |
| slash-command.walkthrough-cs-7-core-step | core-composition | root W6 组合交付负责人及对应真实core节点 |

## 导航补记需求

CA/MCP/Slash realization README仍写“源码不存在／全部未实现／证据未开始”，与已存在源码、原封存和当前检查事实不同；版本外verification里也保留待实施的旧阶段描述。Skill入口已加当前SP3声明，旧设计阶段快照仍在。这是当前状态/验证导航回填需求，不是冻结2条款冲突，也不授予本证据作者改设计的权限。根的实现接受记录应将实际结果、SP3与external余项准确导航到各节点。Slash SC6已按D060/S11校准为空分类声明，未改冻结资源。

## 本作者实际执行

运行 ` .venv/bin/python tmp/core-delivery/retained-local-evidence-audit/collect.py`、`map.py`、`report.py`；它们只读文件/Git信息并写本目录。原产品测试命令与环境来自原provenance，不由本作者声称重跑。取证工具开发中的缺失marker/数组pointer诊断已修正后重跑，最后一致性检查通过；未作为产品反例或产品成功证据。

本包交给root做亲自技术核查与当前make对账；本作者无接受权。
