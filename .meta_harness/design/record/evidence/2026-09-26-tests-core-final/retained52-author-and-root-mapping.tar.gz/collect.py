"""Read-only provenance collector. Writes only this audit directory; runs no tests/builds."""
import hashlib
import json
import re
import subprocess
from pathlib import Path
from urllib.parse import urldefrag, urljoin, unquote

HUB = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
MAIN = Path('/data/qiwei/repos/omne-harness-lite')
OUT = HUB / 'tmp/core-delivery/retained-local-evidence-audit'
ARCHIVE = MAIN / 'tmp/core-delivery/spoke-evidence'
NODES = ['model-profile', 'call-accounts', 'skill-package', 'mcp-endpoint', 'slash-command']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


catalog = read(HUB / '.meta_harness/design/registry/catalog.json')
frozen = read(HUB / '.meta_harness/design/registry/frozen.json')['files']
inventory = {}
for node in NODES:
    package = HUB / 'packages/core' / node
    spec = HUB / '.meta_harness/design/spec/data' / node
    realization = HUB / '.meta_harness/design/realization/packages/core' / node
    adopted = next(c for c in catalog['contracts']
                   if c['coordinate']['contract_id'] == f'data.{node}'
                   and c['coordinate']['version'] == 2)
    schema = package / 'schema' / f'{node}.schema.json'
    schema_doc = read(schema)
    resources = []
    for resource in adopted['resources']:
        path = HUB / '.meta_harness/design' / resource
        resources.append({'path': str(path.relative_to(HUB)), 'sha256': sha(path),
                          'frozen_sha256': frozen.get(resource),
                          'matches_frozen': sha(path) == frozen.get(resource)})
    paths = sorted(p for p in package.rglob('*')
                   if p.is_file() and not any(t in p.parts for t in ['node_modules', 'dist']))
    files = [{'path': str(p.relative_to(HUB)), 'sha256': sha(p), 'bytes': p.stat().st_size}
             for p in paths]
    index = (package / 'src/index.ts').read_text()
    exports = []
    for match in re.finditer(r'export\s+(type\s+)?\{(.*?)\}\s+from\s+[\'\"]([^\'\"]+)[\'\"]',
                             index, re.S):
        default_type, items, module = match.groups()
        for item in items.split(','):
            item = item.strip()
            if item:
                is_type = bool(default_type) or item.startswith('type ')
                name = item.removeprefix('type ').strip()
                if ' as ' in name:
                    name = name.split(' as ')[-1]
                exports.append({'name': name, 'kind': 'type' if is_type else 'runtime',
                                'from': module})
    for module in re.findall(r'export type \* from [\'\"]([^\'\"]+)[\'\"]', index):
        path = package / 'src' / module
        for name in re.findall(r'^export (?:type|interface) (\w+)', path.read_text(), re.M):
            exports.append({'name': name, 'kind': 'type', 'from': module})
    exported_schema = next(p for p in resources if p['path'].endswith('.schema.json'))
    schema_source = (package / 'src/schema.ts').read_text()
    schema_imports = re.findall(r"import \w+ from '(.*?/schema(?:/v\d+)?)' with", schema_source)
    refs = []

    def visit(value, pointer=''):
        if isinstance(value, dict):
            for key, child in value.items():
                if key == '$ref':
                    refs.append({'pointer': pointer + '/$ref', 'value': child})
                visit(child, pointer + '/' + key)
        elif isinstance(value, list):
            for i, child in enumerate(value):
                visit(child, pointer + '/' + str(i))

    visit(schema_doc)
    current_clause_anchors = []
    for line, value in enumerate((spec / 'v2/contract.md').read_text().splitlines(), 1):
        if re.match(r'\|\s*(?:S-?\d+|M\d+|R\d+|CS-?\d+)\s*\|', value) or (
                value.startswith('#') and re.search(r'\b(?:S-?\d+|CS-?\d+)', value)):
            current_clause_anchors.append({'line': line, 'text': value})
    docs = [spec / 'verification.md', *(realization / n for n in
             ['README.md', 'design.md', 'bindings.yaml', 'verification.md'])]
    docs.extend(spec / 'v2' / n for n in ['contract.md', 'examples.md', f'{node}.schema.json'])
    test_sources = []
    for file in (package / 'tests').glob('*'):
        if file.is_file() and file.suffix == '.ts':
            tests = []
            for line, text in enumerate(file.read_text().splitlines(), 1):
                if re.search(r'\b(?:it|test)(?:\.each\([^)]*\))?\(', text):
                    tests.append({'line': line, 'expression': text.strip()})
            test_sources.append({'path': str(file.relative_to(HUB)), 'sha256': sha(file),
                                 'test_expressions': tests})
    inventory[node] = {'coordinate': adopted['coordinate'], 'accepted_status': adopted['status'],
                       'acceptance': adopted.get('acceptance'), 'accepted_entry': adopted,
                       'resources': resources, 'package_schema': str(schema.relative_to(HUB)),
                       'package_schema_sha256': sha(schema),
                       'package_schema_matches_frozen': sha(schema) == exported_schema['sha256'],
                       'schema_id': schema_doc['$id'], 'schema_defs': list(schema_doc['$defs']),
                       'schema_import_specifiers': schema_imports, 'schema_refs': refs,
                       'package_exports': read(package / 'package.json')['exports'],
                       'public_symbols': sorted(exports, key=lambda i: (i['kind'], i['name'])),
                       'files': files, 'documents': [
                           {'path': str(p.relative_to(HUB)), 'sha256': sha(p)} for p in docs],
                       'clause_anchors': current_clause_anchors, 'test_sources': test_sources}
    if node == 'call-accounts':
        inventory[node]['public_class_members'] = {
            'ExactDecimal': {'constructor': 'private', 'static': ['from'],
                             'instance': ['add', 'compare', 'isInteger (getter)', 'toString', 'toJsonNumber']},
            'AccountGroup': {'constructor': 'private', 'static': ['prepare', 'summarize'],
                             'instance': []}}
write('current-inventory.json', inventory)

# Check only references reachable from each exported validator selector. A full
# imported AM resource contains other category definitions that this validator
# does not select; those are not falsely claimed as a compiled whole-AM graph.
graphs = {}
for node in NODES:
    resource_by_id = {}
    imported = []
    for specifier in inventory[node]['schema_import_specifiers']:
        package_name, subpath = specifier.removeprefix('@omne-harness-lite/').split('/', 1)
        package = HUB / 'packages/core' / package_name
        package_json = read(package / 'package.json')
        export = package_json['exports']['./' + subpath]
        if isinstance(export, dict):
            export = export.get('default', export.get('import'))
        resource_path = package / export
        doc = read(resource_path)
        resource_by_id[doc['$id']] = doc
        frozen_match = [name for name, digest in frozen.items()
                        if name.endswith('.schema.json') and digest == sha(resource_path)]
        imported.append({'specifier': specifier, 'export_target': export,
                         'path': str(resource_path.relative_to(HUB)), 'sha256': sha(resource_path),
                         'id': doc['$id'], 'frozen_resource_matches': frozen_match})
    encountered, missing, seen = [], [], set()

    def traverse_schema(value, base):
        if isinstance(value, dict):
            if '$id' in value:
                base = urljoin(base, value['$id'])
            if '$ref' in value:
                ref = urljoin(base, value['$ref'])
                if ref not in seen:
                    seen.add(ref)
                    resource_id, fragment = urldefrag(ref)
                    document = resource_by_id.get(resource_id)
                    if document is None:
                        missing.append(ref)
                    else:
                        target = document
                        try:
                            if fragment:
                                if not fragment.startswith('/'):
                                    raise KeyError('non-pointer anchor')
                                for token in unquote(fragment).split('/')[1:]:
                                    token = token.replace('~1', '/').replace('~0', '~')
                                    target = target[int(token)] if isinstance(target, list) else target[token]
                            encountered.append(ref)
                            traverse_schema(target, resource_id)
                        except (KeyError, TypeError):
                            missing.append(ref)
            for key, child in value.items():
                if key not in ['$ref', '$defs']:
                    traverse_schema(child, base)
        elif isinstance(value, list):
            for child in value:
                traverse_schema(child, base)

    own_id = inventory[node]['schema_id']
    own = resource_by_id[own_id]
    for definition in inventory[node]['schema_defs']:
        traverse_schema(own['$defs'][definition], own_id)
    graphs[node] = {'imports': imported, 'reachable_refs': encountered,
                    'unresolved_reachable_refs': missing,
                    'boundary': 'Static JSON pointer/resource closure for exported own $defs, not an execution of validators.'}
write('retained-schema-resource-closure.json', graphs)

# Verify that the collector's reference walker sees a deliberate missing target
# and handles numeric JSON-pointer traversal used by the real Slash schema.
before_missing = list(missing)
assert all(not graph['unresolved_reachable_refs'] for graph in graphs.values())
bad_ref = own_id + '#/$defs/AuditDeliberatelyMissing'
traverse_schema({'$ref': bad_ref}, own_id)
assert missing == before_missing + [bad_ref]
assert any('/oneOf/1/' in reference for reference in graphs['slash-command']['reachable_refs'])
missing[:] = before_missing
write('collector-controls.json', {'missing_ref_control': bad_ref,
    'missing_ref_detected': True, 'array_pointer_positive_detected': True,
    'boundary': 'Static pointer collector sanity checks; not tests of product validators.'})

config = {
    'model-profile': ('model-profile', 'vitest.json', 'results.json'),
    'call-accounts': ('w2-call-accounts', 'delivery-tests.json', 'delivery-manifest.json'),
    'skill-package': ('w4-skill-package', 'tmp/w4-skill-package/test-results-core-profile.json',
                      'tmp/w4-skill-package/results.json'),
    'mcp-endpoint': ('w4-mcp-endpoint', 'final-tests.json', 'source-and-input-manifest.json'),
    'slash-command': ('w5-slash-command', 'vitest.json', 'inputs.json'),
}


def verify_lines(base, path):
    entries = []
    for value in path.read_text().splitlines():
        if not value.strip():
            continue
        expected, name = value.split(maxsplit=1)
        entries.append({'path': name.lstrip('*'), 'sha256': expected})
    return verify_entries(base, entries)


def verify_entries(base, entries):
    verified, failed, links = [], [], []
    for entry in entries:
        if entry.get('kind') == 'directory':
            continue
        name = entry['path']
        path = base / name
        if entry.get('kind') == 'symlink':
            target = entry['target']
            links.append({'sealed_path': name, 'expected_target': target,
                          'target_string_sha256': hashlib.sha256(target.encode()).hexdigest(),
                          'descriptor_matches': hashlib.sha256(target.encode()).hexdigest()
                                                == entry['sha256_link_target'],
                          'archive_link_present': path.is_symlink(),
                          'archive_target': str(path.readlink()) if path.is_symlink() else None,
                          'limitation': 'A sealed link-target string is not a sealed install or dependency tree.'})
            continue
        if not path.is_file() and name.startswith('tmp/'):
            # Retired flat evidence bundles preserve seal paths from the original spoke.
            path = base / '/'.join(name.split('/')[2:])
        expected = entry.get('sha256')
        result = {'sealed_path': name, 'actual_path': str(path), 'expected_sha256': expected,
                  'exists': path.is_file()}
        if path.is_file():
            result['actual_sha256'] = sha(path)
            result['matches'] = result['actual_sha256'] == expected
            if 'bytes' in entry:
                result['expected_bytes'] = entry['bytes']
                result['actual_bytes'] = path.stat().st_size
                result['matches'] &= result['actual_bytes'] == entry['bytes']
        else:
            result['matches'] = False
        (verified if result['matches'] else failed).append(result)
    return {'verified_count': len(verified), 'failed_count': len(failed),
            'failed_entries': failed, 'verified_entries': verified,
            'symlink_descriptors': links}


archives = {}
for node, (dirname, test_json, provenance) in config.items():
    base = ARCHIVE / dirname
    report = read(base / test_json)
    seal_path = {'model-profile': 'sha256-manifest.json',
                 'call-accounts': 'evidence-manifest.json',
                 'skill-package': 'tmp/w4-skill-package/sha256.txt',
                 'mcp-endpoint': 'evidence-manifest.json',
                 'slash-command': 'evidence-manifest.json'}[node]
    seal = base / seal_path
    if node == 'skill-package':
        verified = verify_lines(base, seal)
    else:
        raw = read(seal)
        if node == 'model-profile':
            entries = [{'path': k, 'sha256': v} for k, v in raw.items()]
        else:
            entries = raw.get('files', raw.get('entries'))
        verified = verify_entries(base, entries)
    test_inventory = []
    for file in report.get('testResults', []):
        filename = file['name']
        if '/packages/core/' in filename:
            filename = 'packages/core/' + filename.split('/packages/core/')[-1]
        test_inventory.append({'file': filename, 'status': file['status'],
                               'assertions': [{k: x.get(k) for k in
                                  ['fullName', 'title', 'ancestorTitles', 'status', 'failureMessages']}
                                   for x in file.get('assertionResults', [])]})
    if node == 'model-profile':
        old_sources = read(base / provenance)['files']
        source_entries = [{'path': k, 'sha256': v} for k, v in old_sources.items()]
    elif node == 'call-accounts':
        source_entries = read(base / 'source-config-hashes.json')['files']
    elif node == 'skill-package':
        source_entries = read(base / provenance)['sourceHashes']
    elif node == 'mcp-endpoint':
        source_entries = [{'path': k, 'sha256': v} for k, v in
                          read(base / provenance)['sourceHashes'].items()]
    else:
        source_entries = read(base / 'source-config-sha256.json')['sources']
    comparisons = []
    for entry in source_entries:
        name, old_hash = entry['path'], entry['sha256']
        if not name.startswith('packages/core/' + node + '/'):
            continue
        if '/dist/' in name or '/node_modules/' in name:
            continue
        current = HUB / name
        comparisons.append({'path': name, 'historical_sha256': old_hash,
                            'current_sha256': sha(current) if current.is_file() else None,
                            'identical_bytes': current.is_file() and sha(current) == old_hash})
    archives[node] = {
        'archive_root': str(base), 'historical_coordinate_epoch': 'v1; not relabeled as a v2 run',
        'seal': str(seal), 'seal_sha256': sha(seal), 'seal_verification': verified,
        'provenance': str(base / provenance), 'provenance_sha256': sha(base / provenance),
        'provenance_record': read(base / provenance),
        'raw_test_report': str(base / test_json), 'raw_test_report_sha256': sha(base / test_json),
        'summary': {k: report.get(k) for k in ['success', 'numTotalTests', 'numPassedTests',
                      'numFailedTests', 'numPendingTests', 'numTodoTests']},
        'test_inventory': test_inventory, 'source_comparisons': comparisons,
        'missing_from_historical_hash_inventory': sorted(
            {x['path'] for x in inventory[node]['files']} - {x['path'] for x in comparisons})}
write('historical-evidence.json', archives)

guards = {}
for dirname in ['w4-body-guards', 'w5-slash-guards']:
    base = ARCHIVE / dirname
    guards[dirname] = {
        'archive_root': str(base), 'seal_sha256': sha(base / 'SHA256SUMS'),
        'seal_verification': verify_lines(base, base / 'SHA256SUMS'),
        'probes': read(base / 'probe-results.json'),
        'runner_checks': read(base / 'runner-checks.json'),
        'coverage': read(base / 'coverage.json'),
        'provenance': read(base / 'provenance.json')}
write('guard-evidence.json', guards)

mcp_current = {}
for name in ['MCP-resource-fixture-correction.json', 'MCP-current-AM3-fixture-before.json',
             'MCP-current-AM3-fixture-before.log', 'MCP-current-AM3-fixture-after.log',
             'MCP-current-AM3-fixture-types.log', 'MCP-current-AM3-fixture-format.log']:
    path = HUB / 'tmp/core-delivery' / name
    mcp_current[name] = {'path': str(path.relative_to(HUB)), 'sha256': sha(path),
                         'bytes': path.stat().st_size}
    if path.suffix == '.json':
        mcp_current[name]['record'] = read(path)
    else:
        mcp_current[name]['raw_text'] = path.read_text()
write('mcp-current-root-evidence.json', mcp_current)

matrix = read(OUT / 'input-acceptance-matrix.json')
selected = [o for o in matrix['obligations'] if o['node'] in NODES]
stage_counts = {stage: sum(o['stage'] == stage for o in selected)
                for stage in ['core-local', 'core-composition', 'external']}
summary = {'head_at_collection': subprocess.check_output(['git', 'rev-parse', 'HEAD'],
                           cwd=HUB, text=True).strip(),
           'collector_authority': 'read-only findings, no tests/builds or acceptance performed',
           'input_matrix_sha256': sha(OUT / 'input-acceptance-matrix.json'),
           'obligation_count': len(selected), 'stage_counts': stage_counts,
           'frozen_resources_all_exact': all(r['matches_frozen'] for n in inventory.values()
                                             for r in n['resources']),
           'package_schemas_all_exact': all(n['package_schema_matches_frozen']
                                           for n in inventory.values()),
           'historical_tests': {n: a['summary'] for n, a in archives.items()},
           'seal_results': {n: {k: a['seal_verification'][k] for k in
                                 ['verified_count', 'failed_count']} for n, a in archives.items()},
           'guard_seal_results': {n: {k: a['seal_verification'][k] for k in
                                 ['verified_count', 'failed_count']} for n, a in guards.items()}}
write('collection-summary.json', summary)
print(json.dumps(summary, ensure_ascii=False, indent=2))
