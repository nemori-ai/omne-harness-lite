"""Read-only final consistency check and navigable author report."""
import hashlib
import json
import subprocess
from pathlib import Path

HUB = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
OUT = HUB / 'tmp/core-delivery/retained-local-evidence-audit'


def read(name):
    return json.loads((OUT / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


mapping = read('obligation-evidence-map.json')
inventory = read('current-inventory.json')
history = read('historical-evidence.json')
rows = mapping['obligations']
head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=HUB,text=True).strip()
tracked = subprocess.check_output(['git','status','--short'],cwd=HUB,text=True)
current_matrix = json.loads((HUB/'tmp/core-delivery/acceptance-matrix.json').read_text())
input_matrix = read('input-acceptance-matrix.json')
keys = ['id','node','stage','owner','source','current_source','input_coordinate',
        'original_input_coordinate','linked_obligation_ids','scope_disposition']


def projection(matrix):
    return {r['id']:{key:r.get(key) for key in keys} for r in matrix['obligations']}


matrix_unchanged = projection(current_matrix) == projection(input_matrix)
assert matrix_unchanged
drift = []
for node, inv in inventory.items():
    for item in inv['files'] + inv['documents']:
        if sha(HUB/item['path']) != item['sha256']:
            drift.append(item['path'])
assert not drift
for row in rows:
    assert row['technical_acceptance'] is None
    if row['stage'] == 'core-local':
        assert row['source_protection_points']
        for test in row['actual_test_evidence']:
            assert test.get('historical_executed_assertions') or test.get('typecheck_only_file') or test.get('current_run_reference')
            assert sha(HUB/test['file']) == test['current_source_sha256']
assert read('collector-controls.json')['missing_ref_detected']
assert all(not x['unresolved_reachable_refs'] for x in read('retained-schema-resource-closure.json').values())

checks = {'head_at_read_only_final_check':head, 'tracked_status_at_check':tracked,
          'input_matrix_sha256':sha(OUT/'input-acceptance-matrix.json'),
          'all327_id_stage_owner_source_coordinate_link_scope_projection_unchanged':matrix_unchanged,
          'five_nodes_maintained_source_tests_docs_drift':drift,
          'all89_acceptance_fields_null':True,
          'all52_local_have_source_points':True,
          'all_selected_test_files_have_actual_named_archived_execution_or_explicit_type_only_current_root_classification':True,
          'all_static_owned_selector_resource_refs_resolve':True,
          'collector_negative_and_array_pointer_controls':read('collector-controls.json'),
          'execution_boundary':'Only collector/map/report scripts were executed; no product test/build/format/mutation command was run by this author.'}
(OUT/'audit-consistency.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')

lines = [
 '# Retained core v2 local evidence audit', '',
 '这是技术证据作者的只读发现，未签收任何义务。主调度需亲自核对并使用当前全量检查作技术接受；最后总体交付接受仍归人。', '',
 f'HUB：`panqiwei/core-delivery@{head}`。首动作定位 `98462a0b62dff8fc48f407076090eb22a6633d04`；本报告输入矩阵固定为 `eb454167f973f7decab97842f92cb9fa9c9e6392a7537bca2d03167373cc3c80`。根可追加接受记录；原 327 项的 ID、阶段、归属、source、坐标、链接与范围投影在收尾复核时未变。', '',
 '使用 worktree-discipline 核对给定 HUB；按 harness-design-handbook 的 handoff/spec-evolution 读取本任务明确的接受坐标和 realization。只写本目录，没有执行产品测试、构建、格式化，或修改源码、规格、锁、矩阵、原 seal、主分支。', '',
 '## 结果与局限', '',
 '- 89 项完整逐 ID 地图：52 core-local、9 core-composition、28 external；后两类保持原归属，whole-CS 与 Connector 纵线未被这份审计收口。',
 '- 15 份 contract/schema/examples 对 frozen 登记 SHA 全部精确匹配，五份包内 Schema 与各自接受 v2 精确同字节。21 个实际 Schema import 都记录了 exports 目标与 frozen 真身；从各公开自有 `$defs` 出发的静态引用闭包无缺失。此项不是执行 Schema 判别器。',
 '- 五个原封存的实际 JSON 测试报告分别是 185、602、406、154、408 通过，均 0 失败、0 跳过；它们保留 v1 运行时期。D066 的 identity 条款迁移与当前保留 v2 Schema 导入支持对应关系，但旧结果不被改称 v2 当前运行。',
 '- Skill SP3：未知自定义 YAML scalar tag 用于键时，冻结 v2 没有决定 canonical equality/重复键规则。当前 `undetermined` 诚实保留缺口，不能签全 S20 或 CS6；normalized reader 传播这一分支。普通未知属性仍按 S5 忽略并留可见痕迹。CS3 相关读入域标局部未闭合，CS4 的已经明确提供的包/脚本成员仍可独立核对。',
 '- MCP 的完整 Schema 资源端口在旧154封存后补强；初次当前运行155绿/2红保留。实际 fixture 调用 AM3，却提供 Loop2；仅将 fixture 的 Loop 资源换成3，保留断言与 MCP 产品/Schema2。根的新日志记录157通过，类型与格式日志也保留；全 W6 与最终根检查继续归其拥有者。',
 '- 历史有限消费者不等于完整当前公开面；JSON 中列出每个实际函数、类型、类方法、Schema selector、JSON subpath。root/W6 必须使用完整正向消费者和明确的 TS/Node 私有子路径拒绝证据，不能把任意非零退出当负控。',
 '- 现行 core-pure-imports CLI 正扫与负控需要根的当前 source/checker 运行。历史 body-projection probes 有明确的诊断名、被突变的实际模块、预期退出1/无signal，不只记录非零。导入绿也不能代替运行纯性的检查。', '',
 '## 证据入口', '',
 '| 文件 | 内容 |',
 '| --- | --- |',
 '| [obligation-evidence-map.json](obligation-evidence-map.json) | 全89原ID、精确当前条款/行号、实际测试名/文件/源SHA、源码保护点、旧封存及复用前提、未覆盖与根复验 |',
 '| [current-inventory.json](current-inventory.json) | 接受坐标、完整实际公开面/类型/类方法/Schema defs/subpaths、全部五包维护文件与文档SHA |',
 '| [retained-schema-resource-closure.json](retained-schema-resource-closure.json) | 原样v2 Schema资源真身导入、实际exports映射与自有selector静态引用闭包 |',
 '| [historical-evidence.json](historical-evidence.json) | 每份原seal校验、实际 raw JSON test名/状态、原输入/环境/命令/source记录、逐文件当前SHA比较 |',
 '| [source-delta-readback.json](source-delta-readback.json) | 历史提交到当前源码的 Git 差异取证；纯值算法未改，Schema导入限定旧2/expiry1，MCP端口补完整资源 |',
 '| [guard-evidence.json](guard-evidence.json) | W4/W5真实静态checker的原封存、具体诊断负控、测量器自检与限制 |',
 '| [mcp-current-root-evidence.json](mcp-current-root-evidence.json) | 根的原红、fixture依据/前后SHA、当前157/类型/格式原件路径与SHA |',
 '| [audit-consistency.json](audit-consistency.json) | 327项不改范围/归属、89项未接受、52项源码映射、测试引用与收尾无漂移检查 |',
 '| [collector-controls.json](collector-controls.json) | 取证工具能发现故意缺失ref并解析数组JSON pointer的自检；非产品验证 |', '',
 '## 原封存实际可复用范围', '',
 '| 节点 | 原raw tests | seal覆盖regular文件 | 主要当前变化与限制 |',
 '| --- | ---: | ---: | --- |',
]
limitations = {
 'model-profile':'算法与类型字节保留；schema import 显式 content2/expiry1、冻结2与例子坐标/哈希已更新；最终当前运行待根。',
 'call-accounts':'精确计算与admission字节保留；schema import显式content2/expiry1、冻结2/例子fixture已更新；model-only Usage helper不裁G10。',
 'skill-package':'YAML/规范化/判断算法字节保留；schema import显式AM2/CB2/TD2，当前测试owned-ref指2；SP3不闭合。',
 'mcp-endpoint':'schema与宣告ref显式旧2；body从裸ref补完整资源并新增3项测试，需用root当前157替代此段旧154论据。',
 'slash-command':'识别/解析/展开/端口算法字节保留；schema import显式AM2/CB2，schema及测试冻结来源更新；原consumer 6条链接描述不能证明当前依赖安装。'}
for node, item in history.items():
    lines.append(f"| {node} | {item['summary']['numPassedTests']} | {item['seal_verification']['verified_count']} | {limitations[node]} |")
lines.extend(['',
 '所有 raw JSON 测试报告与输入/source provenance 本身都在各原 seal 的已核对 regular文件中；未改任何 seal。W4/W5 checker seals分别578/644个regular文件全部一致。Slash archive保留6个symlink描述，目标字符串hash一致，但归档没有这6条node_modules链接，亦未封存依赖树；故只证明当时命令/日志与链接描述，不证明已构建消费者能在当前环境原样重放。', '',
 'MCP fixture 前后SHA分别 `98b79c2e37c4f0900d1b048d81b26c789578db89a6f665a1d61338110fdb5964` / `9b765d92ca2abfa240d694a32f98d7d9fbf6b24acb5d539cc7bdfff1df28b734`，当前源码与后者一致。根after日志是157实际通过；before JSON有独立exit元数据，after/type/format日志本身没有独立exit元数据，本报告没有替根补造它们。最终make原始命令/exit与SHA应补全最后接受依据。', '',
 '## 52 项本地证据导航', '',
 '下表只是导航，全部实际实例测试名称、对应source/hash、采用条款和局限在 JSON；“待根”不是接受。', '',
 '| 原ID | 当前条款 | 实际测试文件 | 局限 |',
 '| --- | --- | --- | --- |'])
for row in rows:
    if row['stage'] != 'core-local':
        continue
    clauses = ', '.join(x['section'] for x in row['current_clauses']) or 'realization公开面／计划共同门'
    files = ', '.join(dict.fromkeys(Path(x['file']).name for x in row['actual_test_evidence'])) or '真实source/checker门'
    caveat = ('SP3读入域' if row['finding'].startswith('partial') else
              '已提供包可独立核对；SP3读入传播' if 'inherited-reader-caveat' in row['finding'] else
              '完整公共消费者待W6/根' if row['id'].endswith('public-package-consumer') else
              '当前CLI正扫/负控待根' if row['id'].endswith('source-purity') else '当前独立运行待根')
    lines.append(f"| {row['id']} | {clauses} | {files} | {caveat} |")
lines.extend(['', '## 37 项范围归属保持', '', '| 原ID | 原阶段 | 原拥有者 |', '| --- | --- | --- |'])
for row in rows:
    if row['stage'] != 'core-local':
        lines.append(f"| {row['id']} | {row['stage']} | {row['owner']} |")
lines.extend(['', '## 导航补记需求', '',
 'CA/MCP/Slash realization README仍写“源码不存在／全部未实现／证据未开始”，与已存在源码、原封存和当前检查事实不同；版本外verification里也保留待实施的旧阶段描述。Skill入口已加当前SP3声明，旧设计阶段快照仍在。这是当前状态/验证导航回填需求，不是冻结2条款冲突，也不授予本证据作者改设计的权限。根的实现接受记录应将实际结果、SP3与external余项准确导航到各节点。Slash SC6已按D060/S11校准为空分类声明，未改冻结资源。', '',
 '## 本作者实际执行', '',
 '运行 ` .venv/bin/python tmp/core-delivery/retained-local-evidence-audit/collect.py`、`map.py`、`report.py`；它们只读文件/Git信息并写本目录。原产品测试命令与环境来自原provenance，不由本作者声称重跑。取证工具开发中的缺失marker/数组pointer诊断已修正后重跑，最后一致性检查通过；未作为产品反例或产品成功证据。', '',
 '本包交给root做亲自技术核查与当前make对账；本作者无接受权。', ''])
(OUT/'README.md').write_text('\n'.join(lines))
print(json.dumps({'head':head,'rows':len(rows),'local':52,'all_checks':True,
                  'report':str(OUT/'README.md'),'map_sha256':sha(OUT/'obligation-evidence-map.json')},ensure_ascii=False))
