import { createHash } from 'node:crypto'
import { Agent, request } from 'node:https'
import { TLSSocket } from 'node:tls'
import type { IncomingMessage } from 'node:http'
import { captureConfiguration, type PublicHealthOptions } from './config.ts'
import { PUBLIC_HEALTH_BODY, decodeHealthReply, type PublicHealthOutcome } from './protocol.ts'

const HEADER_LIMIT = 16 * 1024
const BODY_LIMIT = 64 * 1024
const TRUST_ERROR_CODES = new Set([
  'CERT_HAS_EXPIRED',
  'CERT_NOT_YET_VALID',
  'DEPTH_ZERO_SELF_SIGNED_CERT',
  'SELF_SIGNED_CERT_IN_CHAIN',
  'UNABLE_TO_GET_ISSUER_CERT',
  'UNABLE_TO_GET_ISSUER_CERT_LOCALLY',
  'UNABLE_TO_VERIFY_LEAF_SIGNATURE',
  'ERR_TLS_CERT_ALTNAME_INVALID',
  'CERT_REVOKED',
  'CERT_SIGNATURE_FAILURE',
])

/** D-038：固定、无秘密、无持久状态；一次调用拥有并关闭一个连接。 */
export async function readPublicHealth(options: PublicHealthOptions): Promise<PublicHealthOutcome> {
  const config = captureConfiguration(options)
  const signal = config.signal
  if (signal?.aborted === true) return { kind: 'unavailable', reason: 'cancelled' }

  return new Promise<PublicHealthOutcome>((resolve, reject) => {
    const agent = new Agent({ keepAlive: false, maxCachedSessions: 0, proxyEnv: {} })
    let socket: TLSSocket | undefined
    let socketClosed = true
    let requestClosed = false
    let outcome: PublicHealthOutcome | undefined
    let timer: ReturnType<typeof setTimeout> | undefined
    // ClientRequest.close 不等于 IncomingMessage.close；另等实际 socket.close。
    const maybeResolve = (): void => {
      if (outcome !== undefined && requestClosed && socketClosed) resolve(outcome)
    }
    const complete = (result: PublicHealthOutcome): void => {
      if (outcome !== undefined) return
      outcome = result
      clearTimeout(timer)
      signal?.removeEventListener('abort', cancel)
      req.destroy()
      socket?.destroy()
      agent.destroy()
      maybeResolve()
    }
    const cancel = (): void => complete({ kind: 'unavailable', reason: 'cancelled' })
    let req: ReturnType<typeof request>
    try {
      req = request(config.url, {
        agent,
        method: 'POST',
        minVersion: 'TLSv1.3',
        rejectUnauthorized: config.pin === undefined,
        ...(config.ca === undefined ? {} : { ca: config.ca }),
        maxHeaderSize: HEADER_LIMIT,
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': PUBLIC_HEALTH_BODY.length,
          Connection: 'close',
        },
      })
    } catch (error) {
      agent.destroy()
      reject(error)
      return
    }
    req.once('close', () => {
      requestClosed = true
      if (outcome === undefined) complete({ kind: 'unavailable', reason: 'connection' })
      maybeResolve()
    })
    req.on('error', (error: NodeJS.ErrnoException) => {
      complete({
        kind: 'unavailable',
        reason: TRUST_ERROR_CODES.has(error.code ?? '') ? 'trust' : 'connection',
      })
    })
    req.on('information', () => complete({ kind: 'unavailable', reason: 'response-framing' }))
    req.on('upgrade', (_response, upgraded) => {
      upgraded.destroy()
      complete({ kind: 'unavailable', reason: 'response-framing' })
    })
    req.once('socket', connected => {
      if (!(connected instanceof TLSSocket)) {
        connected.destroy()
        complete({ kind: 'unavailable', reason: 'connection' })
        return
      }
      socket = connected
      socketClosed = connected.closed
      connected.once('close', () => {
        socketClosed = true
        maybeResolve()
      })
      if (outcome !== undefined) {
        connected.destroy()
        return
      }
      connected.once('secureConnect', () => {
        if (outcome !== undefined) return
        if (config.pin !== undefined) {
          const certificate = connected.getPeerX509Certificate()
          const actual =
            certificate === undefined
              ? undefined
              : createHash('sha256')
                  .update(certificate.publicKey.export({ type: 'spki', format: 'der' }))
                  .digest('hex')
          if (actual !== config.pin) {
            complete({ kind: 'unavailable', reason: 'trust' })
            return
          }
        }
        // 唯一写入点：TLS及所选信任核实之后；没有 flushHeaders 或自动重发。
        req.end(PUBLIC_HEALTH_BODY)
      })
    })
    req.once('response', response => collectResponse(response, complete))
    timer = setTimeout(() => complete({ kind: 'unavailable', reason: 'timeout' }), config.timeoutMs)
    signal?.addEventListener('abort', cancel, { once: true })
    // 覆盖订阅前发生的取消；取消也可能发生在 socket 分配之前。
    if (signal?.aborted === true) cancel()
  })
}

function collectResponse(
  response: IncomingMessage,
  complete: (value: PublicHealthOutcome) => void,
): void {
  response.on('error', () => complete({ kind: 'unavailable', reason: 'response-framing' }))
  response.once('aborted', () => complete({ kind: 'unavailable', reason: 'response-framing' }))
  const length = response.headers['content-length']
  if (
    response.httpVersion !== '1.1' ||
    typeof length !== 'string' ||
    !/^\d+$/.test(length) ||
    response.headers['transfer-encoding'] !== undefined
  ) {
    complete({ kind: 'unavailable', reason: 'response-framing' })
    return
  }
  const expected = Number(length)
  if (!Number.isSafeInteger(expected) || expected > BODY_LIMIT) {
    complete({ kind: 'unavailable', reason: 'response-limit' })
    return
  }
  let size = 0
  const chunks: Buffer[] = []
  response.on('data', (chunk: Buffer) => {
    size += chunk.length
    if (size > BODY_LIMIT) complete({ kind: 'unavailable', reason: 'response-limit' })
    else chunks.push(chunk)
  })
  response.once('end', () => {
    if (!response.complete || size !== expected) {
      complete({ kind: 'unavailable', reason: 'response-framing' })
      return
    }
    complete(decodeHealthReply(Buffer.concat(chunks), response.statusCode))
  })
}
