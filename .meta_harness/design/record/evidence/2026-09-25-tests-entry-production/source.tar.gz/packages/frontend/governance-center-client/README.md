# governance-center-client

Node24 的治理中心公开 health 客户端；本期只提供固定、无秘密的健康请求。
设计与采用范围见 [实现映射](../../../.meta_harness/design/realization/packages/frontend/governance-center-client/README.md)。

```ts
import { readPublicHealth } from '@omne-harness-lite/governance-center-client'

const outcome = await readPublicHealth({
  url: 'https://governance.example.internal:8443/',
  trust: { mode: 'ca', certificateAuthorities: caPem },
  signal: abortController.signal,
})
```

默认使用系统 CA 与 URL 主机名；显式 CA 内容在调用开始时复制。SPKI 模式要求调用方已确认的64位十六进制 SHA256：`{ mode: 'spki', sha256: confirmedPin }`。没有 insecure、代理、重定向、自动重试或登录材料参数。

结果分别为 `health`、`entry-answer`、`unavailable`；只有 health 携带已校验的原三字段。`reachable` 不代表治理业务就绪。非法本地配置抛 `GovernanceClientConfigurationError`；异常程序缺陷不伪装成成功。

默认总期限10秒（可配置1～120000ms），头部16KiB、体64KiB。取消和超限得到明确 unavailable；调用返回前关闭本调用网络资源并清理订阅。Node系统DNS工作不一定随取消停止，不能据此保证进程即时退出。

```sh
pnpm --filter @omne-harness-lite/governance-center-client build
pnpm --filter @omne-harness-lite/governance-center-client typecheck
pnpm --filter @omne-harness-lite/governance-center-client test
```

测试用 openssl 生成临时证书并运行回环 TLS 对端；不访问外部中心或真实账号。当前没有 CLI 命令、本地登录存储或治理写 API。
