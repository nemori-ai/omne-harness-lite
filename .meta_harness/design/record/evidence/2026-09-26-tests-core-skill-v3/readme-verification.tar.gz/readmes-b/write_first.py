from pathlib import Path
root = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
def write(name, en, zh, examples):
    for lang, intro in [('en',en),('zh',zh)]:
        text=f'# @omne-harness-lite/{name}\n\n'+('[中文](README_ZH.md)' if lang=='en' else '[English](README.md)')+'\n\n'+intro+'\n\n'
        for title_en,title_zh,explain_en,explain_zh,code in examples:
            text+='## '+(title_en if lang=='en' else title_zh)+'\n\n'+(explain_en if lang=='en' else explain_zh)+'\n\n```ts\n'+code.strip()+'\n```\n\n'
        text+=boundaries[name][0 if lang=='en' else 1]+'\n'
        (root/'packages/core'/name/('README.md' if lang=='en' else 'README_ZH.md')).write_text(text)

workspace_en='This package is an unpublished, private ESM workspace member. Use it from this repository with its declared Node and pnpm versions; see the [development guide](../../../docs/development.md). Imports below use the public package entry. Each example is self-contained.'
workspace_zh='本包是尚未发布的私有 ESM workspace 成员。请在本仓库内使用声明的 Node 与 pnpm 版本，环境准备见[开发指南](../../../docs/development.md)。以下导入均使用包的公开入口，每个示例都可以独立使用。'
boundaries={
'asset-model':('''## Failures and boundaries

Judgments return `{ ok: true }` or `{ rejected }`; nested body rejections retain their names. Schema-only `validate` does not replace `judgeAssetValue`. Invalid body-contract configuration or a provider that emits invalid, duplicate or reserved declarations throws `TypeError`.

The supplied five body contracts cover Tool, Loop Extension, Skill, MCP and Slash Command. The shared types still describe Connector, but this composition has no Connector provider: a body operation that needs it throws `BodyProviderUnavailableError`. Plugin declarations and Agent Definition declarations are `underivable`, not an empty declaration set. MCP derivation preserves whether its action snapshot was supplied, fetched or not fetched.

Directory normalization is lexical: it requires an absolute path and does not resolve symlinks or read the filesystem. `carrierRecordId` includes the tenant, directory and capability; it is an identifier, not a content hash. Use `contentFingerprint` when tracking body changes. The module does not persist assets, establish sharing or authorization, or enforce uniqueness and mutation rules across stored records.

Public JSON Schema entries are `@omne-harness-lite/asset-model/schema` (v3) and `/schema/v2` (retained v2). See [source exports](src/index.ts), [tests](tests/) and [asset evaluation](../asset-evaluation/README.md).''','''## 失败与边界

判定返回 `{ ok: true }` 或 `{ rejected }`，嵌套正文的拒绝保留原名。只检查 Schema 的 `validate` 不能替代 `judgeAssetValue`。正文端口配置不合法，或提供者推出了非法、重复、保留项声明时，抛出 `TypeError`。

提供的五个正文端口覆盖 Tool、Loop Extension、Skill、MCP 与 Slash Command。共享类型仍描述 Connector，但这组组合没有 Connector 提供者：需要该正文规则的操作会抛出 `BodyProviderUnavailableError`。Plugin 与 Agent Definition 的声明是 `underivable`，不能当成空声明集合。MCP 推导保留动作副本是否传入、已经取得或尚未取得的信息。

目录规范化只做字面处理：要求绝对路径，不解析符号链接，不读取文件系统。`carrierRecordId` 包含租户、目录与能力标识；它是标识，不是内容摘要。跟踪正文变化请使用 `contentFingerprint`。本模块不持久化资产，不确立分享或授权，也不保证存储记录之间的唯一性与变更规则。

公开 JSON Schema 入口是 `@omne-harness-lite/asset-model/schema`（v3）和 `/schema/v2`（保留的 v2）。参见[源码导出](src/index.ts)、[测试](tests/)与[资产求值](../asset-evaluation/README_ZH.md)。'''),
'asset-evaluation':('''## Failures and boundaries

`evaluate` returns one of `{ ok }`, `{ invalidInput }`, `{ compositionCycle }` or `{ categoryUnsupported }`. Input diagnostics precede evaluation. An `ok` result can contain `filteredOut` and `unresolved`; a consumer must not dispatch an assembly with unresolved references. Reachable Plugin bodies and non-root Agent Definition bodies currently produce `categoryUnsupported` rather than assumed empty composition.

The implemented input domain is `NonConnectorEvaluationInput`. `defaultBodyContracts` contains the five real Tool, Loop Extension, Skill, MCP and Slash Command providers. Connector asset records, drafts or version bodies are outside that domain and throw `BodyProviderUnavailableError`. Connector identifiers and references are not recursively forbidden, and `readWorkspaceCarrier` accepts the full manifest domain.

Both operations are pure calculations over explicit input. The caller supplies a consistent, authorized snapshot and verifies workspace ownership and provenance. No files, clocks, stores, models or tools are accessed. The reader does not load `source` bodies; it returns holdings without `since`, which the caller supplies from the actual read event. Permission classification, bound intersection and pick checks are also exported as `classifyPermissionAssignment`, `boundOf` and `pickWithinBound`; they calculate values without granting execution authority.

See [source exports](src/index.ts), [tests](tests/) and [asset model](../asset-model/README.md).''','''## 失败与边界

`evaluate` 返回 `{ ok }`、`{ invalidInput }`、`{ compositionCycle }`、`{ categoryUnsupported }` 四种结果之一。先检查输入，再求值。`ok` 中仍可能有 `filteredOut` 与 `unresolved`；消费者不能派发仍有未解析引用的装配。可达的 Plugin 正文与非根 Agent Definition 正文当前会产生 `categoryUnsupported`，不会假定它们没有组合成员。

已实现的输入域是 `NonConnectorEvaluationInput`。`defaultBodyContracts` 包含五个真实的 Tool、Loop Extension、Skill、MCP、Slash Command 提供者。Connector 的资产记录、草稿或版本正文超出该域，会抛出 `BodyProviderUnavailableError`。一般的 Connector 标识与引用不会被递归禁止，`readWorkspaceCarrier` 仍接收完整的清单域。

两个操作都是对显式输入的纯计算。调用方提供一致且经过授权的快照，并核实工作区所有权与来源。这里不访问文件、时钟、存储、模型或工具。读入器不加载 `source` 正文；返回的持有没有 `since`，由调用方按实际读入事件补上。另导出 `classifyPermissionAssignment`、`boundOf`、`pickWithinBound`，用于权限分类、约束交集与选值检查；它们只计算值，不授予执行权。

参见[源码导出](src/index.ts)、[测试](tests/)与[资产模型](../asset-model/README_ZH.md)。'''),
 'tool-definition':('''## Failures and boundaries

`judgeToolDefinition` and `judgeToolReturn` return `{ ok: true }` or `{ rejected }`. `malformed` includes an `M` diagnostic and `schema_unsupported` can include an implementation-limit diagnostic. Call arguments yield `{ ok: { command?, args } }`, `{ invalid }` or `{ unsupported }`; calling the parameter judge with an invalid definition throws `TypeError`. The caller owns the judge and its schema compilation cache.

Input schemas use the supported Draft 2020-12 subset. Every declared parameter needs a description. During argument judgment, omitted root `additionalProperties` means false in the private validator view; model-facing schemas are not rewritten. Regex limits are exposed as `PATTERN_MAX_CODE_POINTS` and `PATTERN_MAX_FINITE_COUNT`. Judgment is synchronous; worker termination and execution time limits belong to the consumer.

A Tool Result is returned content, not an execution outcome. Tool calls are forbidden in result content and offload summaries, including complete calls whose arguments could not be parsed. A JSON-looking string remains text. Identity uniqueness, permissions, dependency availability, background work and execution belong to the runtime. This package does not execute tools or contact models.

Public JSON Schema entries are `@omne-harness-lite/tool-definition/schema` (v3) and `/schema/v2`. See [source exports](src/index.ts), [tests](tests/) and [content blocks](../content-blocks/README.md).''','''## 失败与边界

`judgeToolDefinition` 与 `judgeToolReturn` 返回 `{ ok: true }` 或 `{ rejected }`。`malformed` 带 `M` 诊断，`schema_unsupported` 可带实现上限诊断。调用参数返回 `{ ok: { command?, args } }`、`{ invalid }` 或 `{ unsupported }`；给参数判定器传入不合法的定义会抛出 `TypeError`。调用方拥有判定器及其 Schema 编译缓存。

输入 Schema 使用支持的 Draft 2020-12 子集，每个声明的参数都需要说明。参数判定时，根层未写 `additionalProperties` 会在私有校验视图中按 false 处理；模型侧 Schema 不被改写。正则上限通过 `PATTERN_MAX_CODE_POINTS` 与 `PATTERN_MAX_FINITE_COUNT` 导出。判定是同步计算，工作线程的终止与执行时限由消费者负责。

Tool Result 是返回内容，不是执行收场。结果内容与 offload 摘要都禁止工具调用，包括已经完整但参数无法解析的调用。看起来像 JSON 的字符串仍是文本。身份唯一性、权限、依赖可用性、后台工作与执行归运行时负责；本包不执行工具、不访问模型。

公开 JSON Schema 入口是 `@omne-harness-lite/tool-definition/schema`（v3）和 `/schema/v2`。参见[源码导出](src/index.ts)、[测试](tests/)与[内容块](../content-blocks/README_ZH.md)。'''),
'model-profile':('''## Failures and boundaries

`judgeModelProfileDocument` judges four document kinds: `ModelProfile`, `ModelProfileContent`, `ModelProfileRef` and `ModelRequestParameters`. It returns one `{ rejected }` in a fixed order, with malformed structure checked first. `validate` checks schema shape; cross-field checks such as `max_output_exceeds_profile` require the judge. `ModelProfileSnapshot` has a type and schema entry, but no document-judgment entry.

References compare exact origin, route name and, for custom profiles, supplied scope. Names are case-sensitive and are not Unicode-normalized. A mismatch is a boolean about the supplied row, not a directory lookup failure. Matching does not check registration or authorization.

Numeric fields accept `JsonNumber`, including `LosslessNumber`; judgments compare exact represented numbers. Missing request parameters are not filled in. The package does not store profiles, create snapshots, enforce name uniqueness, manage credentials or send OpenRouter requests; request routing and lifecycle belong to consumers.

The JSON Schema is available through `@omne-harness-lite/model-profile/schema`. See [source exports](src/index.ts), [tests](tests/) and [model response](../model-response/README.md).''','''## 失败与边界

`judgeModelProfileDocument` 判定四类文档：`ModelProfile`、`ModelProfileContent`、`ModelProfileRef`、`ModelRequestParameters`。它按固定次序返回一个 `{ rejected }`，先检查形状不完整的情况。`validate` 检查 Schema 形状；`max_output_exceeds_profile` 等跨字段关系需要完整判定器。`ModelProfileSnapshot` 有类型与 Schema 入口，但没有文档判定入口。

引用精确比较来源、路由名；自建档案还比较显式传入的范围。名字区分大小写，不做 Unicode 规范化。不匹配只是对给定行的布尔答案，不是目录查找失败；匹配也不检查在册状态或授权。

数值字段接收 `JsonNumber`，包括 `LosslessNumber`；判定比较原表示的精确数值。缺席的请求参数不会被补上。本包不存储档案、不创建快照、不保证名字唯一、不管理凭据、不发送 OpenRouter 请求；请求路由与生命周期由消费者负责。

JSON Schema 通过 `@omne-harness-lite/model-profile/schema` 公开。参见[源码导出](src/index.ts)、[测试](tests/)与[模型响应](../model-response/README_ZH.md)。''')}
write('asset-model',f'''Pure asset values and validation for exchanging capability identities, definitions, holdings, assignments and workspace manifests. Body-specific rules are supplied explicitly, so callers can use the asset model independently of a runtime or storage system.

{workspace_en}

| Public API | Use |
| --- | --- |
| `createAssetModelJudge(bodyContracts)` | Build schema and ordered representation judgments |
| `attributeDeclarationsOf`, `referencesOf` | Project body declarations and composition references |
| `capabilityCanonicalString`, `parseCapabilityCanonicalString` | Exchange capability identifiers |
| `normalizeWorkspaceDirectory`, `carrierRecordId`, `contentFingerprint` | Identify workspaces and track content |
| `parseWorkspaceManifestText` | Strictly parse and judge manifest JSON |''',f'''资产值与校验的纯模块，用于交换能力标识、资产定义、持有、配值与工作区清单。正文专属规则由调用方显式提供，因此资产模型可以脱离运行时与存储独立使用。

{workspace_zh}

| 公开 API | 用途 |
| --- | --- |
| `createAssetModelJudge(bodyContracts)` | 构造 Schema 与按次序执行的表示判定 |
| `attributeDeclarationsOf`、`referencesOf` | 推出正文的属性声明与组合引用 |
| `capabilityCanonicalString`、`parseCapabilityCanonicalString` | 交换能力标识 |
| `normalizeWorkspaceDirectory`、`carrierRecordId`、`contentFingerprint` | 标识工作区并跟踪内容 |
| `parseWorkspaceManifestText` | 严格解析并判定清单 JSON |''',[
('Identify a workspace asset','标识工作区资产','Tenant identity is explicit. Equivalent lexical paths produce the same carrier identity.','租户身份显式传入，字面等价的目录路径产生相同的工作区资产标识。','''import { parseTenantId, unwrap } from '@omne-harness-lite/identity-values'
import {
  capabilityCanonicalString, parseCapabilityCanonicalString,
  normalizeWorkspaceDirectory, carrierRecordId, contentFingerprint,
} from '@omne-harness-lite/asset-model'

const tenant = unwrap(parseTenantId({ organization: 'org_acme', account: 'acc_alice' }))
const capability = { category: 'tool', name: 'repo:inspect' } as const
const workspace = { tenant, directory: normalizeWorkspaceDirectory('/work/repo/./') }
console.log(capabilityCanonicalString(capability)) // tool/repo:inspect
console.log(parseCapabilityCanonicalString('tool/repo:inspect'))
// { ok: { category: 'tool', name: 'repo:inspect' } }
console.log(carrierRecordId(workspace, capability).startsWith('wsc1.')) // true
console.log(contentFingerprint({ a: 1, b: 2 }) === contentFingerprint({ b: 2, a: 1 })) // true'''),
('Validate a body and a manifest','校验正文与清单','Use the five actual body providers. Body projections add the reserved `disabled` and `usableBy` declarations. Manifest text parsing rejects duplicate JSON keys.','使用五个真实的正文提供者。正文推导会加上保留项 `disabled` 与 `usableBy`；清单文本解析会拒绝重复 JSON 键。','''import {
  createAssetModelJudge, attributeDeclarationsOf, referencesOf,
  parseWorkspaceManifestText, type AssetContent, type NonConnectorBodyContracts,
} from '@omne-harness-lite/asset-model'
import { toolBodyContract } from '@omne-harness-lite/tool-definition'
import { loopExtensionBodyContract } from '@omne-harness-lite/loop-extension'
import { skillBodyContract } from '@omne-harness-lite/skill-package'
import { mcpBodyContract } from '@omne-harness-lite/mcp-endpoint'
import { slashCommandBodyContract } from '@omne-harness-lite/slash-command'

const bodies: NonConnectorBodyContracts = {
  tool: toolBodyContract,
  loop_extension: loopExtensionBodyContract,
  skill: skillBodyContract,
  mcp: mcpBodyContract,
  slash_command: slashCommandBodyContract,
}
const content = {
  category: 'tool',
  definition: {
    name: 'repo:inspect', description: 'Inspect a repository',
    paradigm: 'single', origin: { kind: 'authored' },
    input: { type: 'object', properties: {} },
    permissions: { execute: { default: 'ask' } },
    composes: { skills: ['review'] },
  },
} satisfies AssetContent
const judge = createAssetModelJudge(bodies)
console.log(judge.judgeAssetValue('AssetContent', content)) // { ok: true }
const declarations = attributeDeclarationsOf(content, bodies)
if ('underivable' in declarations) throw new Error('Tool declarations required')
console.log(declarations.declarations.map(item => item.item))
// ['execute', 'disabled', 'usableBy']
console.log(referencesOf(content, bodies))
// { references: [{ category: 'skill', name: 'review' }] }
console.log(parseWorkspaceManifestText(
  '{"format":1,"assets":[],"assignments":[],"disabled":[]}', bodies,
)) // { ok: { format: 1, assets: [], assignments: [], disabled: [] } }
console.log(parseWorkspaceManifestText(
  '{"format":1,"format":1,"assets":[],"assignments":[],"disabled":[]}', bodies,
)) // { rejected: 'malformed' }''')])
write('asset-evaluation',f'''Compute effective assets, composition and attribute values from explicit holdings across factory, organization, tenant, workspace and session layers. The package also turns a parsed workspace manifest into carrier holdings with a record of ignored entries.

{workspace_en}

| Public API | Use |
| --- | --- |
| `evaluate` | Validate inputs, filter/select assets, expand composition and resolve values |
| `readWorkspaceCarrier` | Convert a complete manifest value into workspace holdings |
| `defaultBodyContracts` | Reuse the five available body providers |
| `evaluationInputFingerprint` | Fingerprint the full evaluation input |
| Permission helpers | Classify assignments and calculate bounds |''',f'''根据出厂、组织、租户、工作区、会话各层的显式持有，计算生效资产、组合与属性值。本包也能把已经解析的工作区清单转换为承载持有，并记录被忽略的条目。

{workspace_zh}

| 公开 API | 用途 |
| --- | --- |
| `evaluate` | 校验输入、过滤与选择资产、展开组合、求属性值 |
| `readWorkspaceCarrier` | 把完整清单值转换为工作区持有 |
| `defaultBodyContracts` | 复用五个已经接入的正文提供者 |
| `evaluationInputFingerprint` | 为完整求值输入生成指纹 |
| 权限辅助函数 | 分类配值并计算约束 |''',[
('Evaluate a complete input','求值一份完整输入','This example includes the root definition and every held definition. A missing optional reference is reported in `unresolved`.','示例提供根定义与每份持有所指的定义。缺失的可选引用会列入 `unresolved`。','''import { parseTenantId, unwrap } from '@omne-harness-lite/identity-values'
import { toOpaqueJson } from '@omne-harness-lite/content-blocks'
import { type AssetHolding } from '@omne-harness-lite/asset-model'
import { evaluate, type NonConnectorEvaluationInput } from '@omne-harness-lite/asset-evaluation'

const tenant = unwrap(parseTenantId({ organization: 'org_acme', account: 'acc_alice' }))
const at = '2026-09-26T10:00:00Z'
const root = { category: 'agent_definition', name: 'assistant' } as const
const tool = { category: 'tool', name: 'inspect' } as const
function factory(capability: AssetHolding['capability'], asset: string): AssetHolding {
  return {
    holder: { layer: 'factory' }, capability, asset, basis: { kind: 'official' },
    versionSelection: { kind: 'current' }, immutable: false, assignments: [], since: at,
  }
}
const input: NonConnectorEvaluationInput = {
  tenant, standing: { standing: 'effective', role: 'member' },
  root: { definition: root, references: [
    { capability: tool, resident: true },
    { capability: { category: 'skill', name: 'missing-review' } },
  ] },
  holdings: [factory(root, 'asset_root'), factory(tool, 'asset_inspect')],
  definitions: [
    { id: 'asset_root', capability: root, origin: 'official', versions: [
      { number: 1, publishedAt: at,
        content: { category: 'agent_definition', body: toOpaqueJson({}) } },
    ] },
    { id: 'asset_inspect', capability: tool, origin: 'official', versions: [
      { number: 1, publishedAt: at, content: { category: 'tool', definition: {
        name: 'inspect', description: 'Inspect files', paradigm: 'single',
        origin: { kind: 'authored' }, input: { type: 'object', properties: {} },
        permissions: { execute: { default: 'ask' } },
      } } },
    ] },
  ],
}
const result = evaluate(input)
if (!('ok' in result)) throw new Error(JSON.stringify(result))
console.log(result.ok.assets.map(asset => asset.capability.name)) // ['assistant', 'inspect']
console.log(result.ok.unresolved.map(entry => entry.capability.name)) // ['missing-review']
console.log(result.ok.values.find(value => value.item === 'execute')?.value) // { allowed: ['ask'] }'''),
('Read carrier holdings with diagnostics','读入承载持有及诊断','The manifest has all three required lists. The reader ignores an immutable flag and records an assignment to an unknown asset.','清单包含三个必需列表。读入器忽略锁标记，并记录针对未知资产的配值。','''import { parseTenantId, unwrap } from '@omne-harness-lite/identity-values'
import { type WorkspaceCarrierManifest } from '@omne-harness-lite/asset-model'
import { readWorkspaceCarrier } from '@omne-harness-lite/asset-evaluation'

const tenant = unwrap(parseTenantId({ organization: 'org_acme', account: 'acc_alice' }))
const capability = { category: 'tool', name: 'inspect' } as const
const manifest: WorkspaceCarrierManifest = {
  format: 1,
  assets: [{ capability, source: 'tools/inspect.json' }],
  assignments: [
    { capability, item: 'timeout', value: 'PT10S', immutable: true },
    { capability: { category: 'skill', name: 'missing' }, item: 'variant', value: 'brief' },
  ],
  disabled: [capability],
}
const result = readWorkspaceCarrier(manifest, { tenant, directory: '/work/repo' })
if ('invalidInput' in result) throw new Error(JSON.stringify(result.invalidInput))
console.log(result.ok.holdings[0]?.assignments.map(entry => entry.item)) // ['timeout', 'disabled']
console.log(result.ok.dropped.map(entry => entry.reason)) // ['immutable_flag', 'unknown_asset']''')])
write('tool-definition',f'''Define single-function or multi-command tools, project their model-facing entries, judge parameters, and normalize tool return content. These functions can be used without the OMNE runtime.

{workspace_en}

| Public API | Use |
| --- | --- |
| `judgeToolDefinition`, `createParameterJudge` | Admit definitions and validate selected command arguments |
| `modelEntry`, `modelInput`, `modelName`, `definitionNameOf` | Project one model-facing entry per tool |
| `judgeToolReturn`, `toolResultOf` | Judge and normalize return content |
| `toolDependencies`, `toolAttributeDeclarations`, `toolReferences` | Project dependencies, settings and composition |
| `toolBodyContract` | Plug Tool rules into the asset model |''',f'''定义单函数或多命令工具，生成模型侧条目，判定参数并规范化工具返回内容。这些函数可以脱离 OMNE 运行时使用。

{workspace_zh}

| 公开 API | 用途 |
| --- | --- |
| `judgeToolDefinition`、`createParameterJudge` | 接收定义并校验所选命令的参数 |
| `modelEntry`、`modelInput`、`modelName`、`definitionNameOf` | 每个工具生成一个模型侧条目 |
| `judgeToolReturn`、`toolResultOf` | 判定并规范化返回内容 |
| `toolDependencies`、`toolAttributeDeclarations`、`toolReferences` | 推出依赖、设置与组合 |
| `toolBodyContract` | 为资产模型提供 Tool 正文规则 |''',[
('Project and validate a single tool','生成并校验单函数工具','A caller-owned parameter judge can be reused for admission and calls. Unknown arguments fail even when the authored root omits `additionalProperties`.','调用方拥有的参数判定器可以复用于定义接收与调用。作者未写根层 `additionalProperties` 时，未知参数仍会被拒绝。','''import {
  createParameterJudge, judgeToolDefinition, modelEntry, type ToolDefinition,
} from '@omne-harness-lite/tool-definition'

const tool: ToolDefinition = {
  name: 'repo:read', description: 'Read one repository file',
  paradigm: 'single', origin: { kind: 'authored' },
  input: {
    type: 'object',
    properties: { path: { type: 'string', description: 'Repository-relative path' } },
    required: ['path'],
  },
  permissions: { execute: { default: 'ask' } },
}
const judge = createParameterJudge()
console.log(judgeToolDefinition(tool, judge)) // { ok: true }
console.log(modelEntry(tool).name) // repo__read
console.log(judge.judgeCallArguments(tool, { path: 'README.md' }))
// { ok: { args: { path: 'README.md' } } }
console.log('invalid' in judge.judgeCallArguments(tool, { path: 'README.md', extra: true })) // true'''),
('Select a multi-command schema','选择多命令 Schema','The model sees one entry; argument judgment uses the selected command schema.','模型只看到一个条目；参数判定使用所选命令的 Schema。','''import { createParameterJudge, modelInput, type ToolDefinition } from '@omne-harness-lite/tool-definition'

const tool: ToolDefinition = {
  name: 'repo', description: 'Repository operations', paradigm: 'multi',
  origin: { kind: 'authored' }, permissions: { execute: { default: 'ask' } },
  commands: {
    status: { description: 'Show status', input: { type: 'object', properties: {} } },
    read: { description: 'Read a file', input: {
      type: 'object', properties: { path: { type: 'string', description: 'Relative file path' } },
      required: ['path'],
    } },
  },
}
const judge = createParameterJudge()
console.log(modelInput(tool).required) // ['command']
console.log(judge.judgeCallArguments(tool, { command: 'status' }))
// { ok: { command: 'status', args: {} } }
console.log('invalid' in judge.judgeCallArguments(tool, { command: 'read', args: {} })) // true'''),
('Normalize text and reject calls in results','规范化文本并拒绝结果中的调用','The caller supplies the identity for a string return. An unparsed tool call remains a call and cannot become result content.','调用方为字符串返回提供身份。未解析的工具调用仍是调用，不能成为结果内容。','''import { parseOpaqueIdentifier, unwrap } from '@omne-harness-lite/identity-values'
import { toolResultOf, judgeToolReturn } from '@omne-harness-lite/tool-definition'

const blockId = unwrap(parseOpaqueIdentifier('result_text', 'BlockId'))
const result = toolResultOf('{"status":"ok"}', blockId)
console.log(result.content[0]?.kind) // text
console.log(judgeToolReturn({ content: [{
  id: 'call_block', kind: 'tool_call', complete: true, callId: 'call_1',
  tool: 'repo__read', rawArguments: '{broken', unparseable: true,
  visibility: { toHuman: true, toModel: true },
}] })) // { rejected: 'result_call_in_content' }''')])
write('model-profile',f'''Model profile data, exact scoped references, and request parameter validation. Describe a route and its provider/modality limits without binding it to credentials or a model client.

{workspace_en}

| Public API | Use |
| --- | --- |
| `judgeModelProfileDocument` | Judge profiles, creation content, references and parameters |
| `refMatches` | Compare a reference to one supplied row and scope |
| `parameterNames` | List unified parameter names and keys in `extra` |
| `ModelProfileSnapshot` | Type the profile facts captured by a request writer |
| `validate` | Validate any exported schema definition |''',f'''提供模型档案数据、精确范围引用与请求参数校验。描述路由、供应商与模态限制，不绑定凭据或模型客户端。

{workspace_zh}

| 公开 API | 用途 |
| --- | --- |
| `judgeModelProfileDocument` | 判定档案、建档内容、引用与参数 |
| `refMatches` | 将引用与显式传入的一行及其范围比较 |
| `parameterNames` | 列出统一参数名与 `extra` 中的键 |
| `ModelProfileSnapshot` | 描述请求写入方捕获的档案事实 |
| `validate` | 校验公开 Schema 定义项 |''',[
('Judge a profile and its output limit','判定档案及其输出上限','Use the full judge for relationships that schema shape alone cannot enforce.','完整判定器会检查单靠 Schema 形状无法保证的关系。','''import {
  judgeModelProfileDocument, validate, parameterNames, type ModelProfile,
} from '@omne-harness-lite/model-profile'

const profile: ModelProfile = {
  routeName: 'vendor/chat', origin: 'official', providers: ['provider-a'],
  allowFallback: false, inputModalities: ['text'], outputModalities: ['text'],
  maxInputTokens: 32000, maxOutputTokens: 8192, inputConstraints: {},
  parameters: { maxOutputTokens: 4096, extra: { top_k: 40 } },
  registration: 'listed', updatedAt: '2026-09-26T10:00:00Z',
}
console.log(judgeModelProfileDocument('ModelProfile', profile)) // { ok: true }
console.log(parameterNames(profile.parameters!)) // ['maxOutputTokens', 'top_k']
const oversized = { ...profile, parameters: { maxOutputTokens: 8193 } }
console.log(validate('ModelProfile', oversized).valid) // true
console.log(judgeModelProfileDocument('ModelProfile', oversized))
// { rejected: 'max_output_exceeds_profile' }'''),
('Match a custom reference in its exact scope','在精确范围内匹配自建引用','The profile row carries no scope field. Its directory supplies scope as a separate argument; withdrawal does not alter identity matching.','档案行没有 scope 字段；目录通过独立参数交出该行的范围。撤回状态不改变身份匹配。','''import { parseScopeLayerIdentity, unwrap } from '@omne-harness-lite/identity-values'
import { refMatches, type ModelProfile, type ModelProfileRef } from '@omne-harness-lite/model-profile'

const alice = unwrap(parseScopeLayerIdentity({
  layer: 'tenant', tenant: { organization: 'org_acme', account: 'acc_alice' },
}))
const bob = unwrap(parseScopeLayerIdentity({
  layer: 'tenant', tenant: { organization: 'org_acme', account: 'acc_bob' },
}))
const profile: ModelProfile = {
  routeName: 'vendor/chat', origin: 'custom', providers: ['provider-a'],
  allowFallback: false, inputModalities: ['text'], outputModalities: ['text'],
  maxInputTokens: 32000, maxOutputTokens: 8192, inputConstraints: {},
  registration: 'withdrawn', updatedAt: '2026-09-26T10:00:00Z',
}
const ref: ModelProfileRef = { origin: 'custom', routeName: 'vendor/chat', scope: alice }
console.log(refMatches(ref, profile, alice)) // true
console.log(refMatches(ref, profile, bob)) // false''')])
