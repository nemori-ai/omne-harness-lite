from pathlib import Path
root = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
def write(name, en, zh, examples, bounds_en, bounds_zh):
    for lang, intro, bounds in [('en',en,bounds_en),('zh',zh,bounds_zh)]:
        text=f'# @omne-harness-lite/{name}\n\n'+('[中文](README_ZH.md)' if lang=='en' else '[English](README.md)')+'\n\n'+intro+'\n\n'
        for title_en,title_zh,explain_en,explain_zh,code in examples:
            text+='## '+(title_en if lang=='en' else title_zh)+'\n\n'+(explain_en if lang=='en' else explain_zh)+'\n\n```ts\n'+code.strip()+'\n```\n\n'
        text+=bounds+'\n'
        (root/'packages/core'/name/('README.md' if lang=='en' else 'README_ZH.md')).write_text(text)
workspace_en='This package is an unpublished, private ESM workspace member. Use it from this repository with its declared Node and pnpm versions; see the [development guide](../../../docs/development.md). Imports below use the public package entry. Each example is self-contained.'
workspace_zh='本包是尚未发布的私有 ESM workspace 成员。请在本仓库内使用声明的 Node 与 pnpm 版本，环境准备见[开发指南](../../../docs/development.md)。以下导入均使用包的公开入口，每个示例都可以独立使用。'
write('model-response',f'''Represent the record of one model dispatch: its route snapshot, actual parameters, response outcome, timing, delivered content, usage and cost. The package judges complete records without sending model requests or owning persistence.

{workspace_en}

| Public API | Use |
| --- | --- |
| `ModelResponse`, `Route`, `Failure`, `Timing` | Type the conditional response shapes |
| `judgeModelResponse` | Judge independent members and outcome relationships in order |
| `validate`, `SCHEMA_DEF_NAMES`, `schemaId` | Access the schema validation surface |''',f'''表示一次模型发出的记录：路由快照、实际参数、响应收场、时序、已交付内容、用量与费用。本包判定完整记录，不发送模型请求、不拥有持久化。

{workspace_zh}

| 公开 API | 用途 |
| --- | --- |
| `ModelResponse`、`Route`、`Failure`、`Timing` | 描述响应的条件形状 |
| `judgeModelResponse` | 按次序判定独立成员与收场关系 |
| `validate`、`SCHEMA_DEF_NAMES`、`schemaId` | 使用 Schema 校验面 |''',[
('Judge a complete response','判定完整响应','Create branded message and block identities through public APIs. This record uses an official profile and a factory credential scope.','通过公开 API 构造带类型身份的消息与块。此记录使用官方档案与出厂凭据范围。','''import { parseOpaqueIdentifier, unwrap } from '@omne-harness-lite/identity-values'
import { judgeContentBlock } from '@omne-harness-lite/content-blocks'
import { judgeModelResponse, type ModelResponse } from '@omne-harness-lite/model-response'

const block = judgeContentBlock({
  id: 'block_1', kind: 'text', text: 'Ready.',
  visibility: { toHuman: true, toModel: true },
})
if ('rejected' in block || block.ok.kind !== 'text') throw new Error('Text block required')
const response: ModelResponse = {
  id: 'response_1', call: { callId: 'model_call_1' }, dispatch: 1,
  route: {
    profile: { origin: 'official', routeName: 'vendor/chat' },
    profileSnapshot: {
      providers: ['provider-a'], allowFallback: false,
      inputModalities: ['text'], outputModalities: ['text'],
      maxInputTokens: 32000, maxOutputTokens: 8192,
      updatedAt: '2026-09-26T09:00:00Z',
    },
    selectedBy: 'session', provider: 'provider-a',
    credentialScope: { layer: 'factory' }, parameters: { maxOutputTokens: 64 },
  },
  outcome: 'complete',
  reply: {
    id: unwrap(parseOpaqueIdentifier('message_1', 'MessageId')),
    type: 'assistant', response: 'response_1', ending: 'complete',
    blocks: [block.ok], createdAt: '2026-09-26T10:00:02Z',
  },
  replyDisposition: 'persisted',
  timing: {
    sentAt: '2026-09-26T10:00:00Z', firstTokenAt: '2026-09-26T10:00:01Z',
    endedAt: '2026-09-26T10:00:02Z',
  },
  usage: { input_tokens: 12, output_tokens: 2, cache_read_tokens: 0,
    cache_write_tokens: 0, source: 'upstream' },
  cost: { cost_usd: 0.0001, source: 'upstream_usage' },
}
console.log(judgeModelResponse(response)) // { ok: true }
console.log(judgeModelResponse({ ...response, reply: { ...response.reply, ending: 'truncated_at_limit' } }))
// { rejected: 'reply_ending_mismatch' }'''),
('Judge failure and rejection precedence','判定故障与拒绝次序','Unknown cost remains unknown. An in-band status-code relationship is checked after the named response relationships.','未知费用保留为未知；带内故障与状态码的关系，在具名响应关系之后检查。','''import { judgeModelResponse, type ModelResponse } from '@omne-harness-lite/model-response'

const response: ModelResponse = {
  id: 'response_failed', call: { callId: 'model_call_2' }, dispatch: 1,
  route: {
    profile: { origin: 'official', routeName: 'vendor/chat' },
    profileSnapshot: {
      providers: ['provider-a'], allowFallback: false,
      inputModalities: ['text'], outputModalities: ['text'],
      maxInputTokens: 32000, maxOutputTokens: 8192,
      updatedAt: '2026-09-26T09:00:00Z',
    },
    selectedBy: 'session', provider: 'provider-a',
    credentialScope: { layer: 'factory' }, parameters: {},
  },
  outcome: 'failed', failure: { cause: 'request_rejected', statusCode: 429 },
  timing: { sentAt: '2026-09-26T10:00:00Z', endedAt: '2026-09-26T10:00:02Z' },
  usage: { input_tokens: 'unknown', output_tokens: 'unknown', cache_read_tokens: 'unknown',
    cache_write_tokens: 'unknown', source: 'none' },
  cost: { cost_usd: 'unknown', source: 'none' },
}
console.log(judgeModelResponse(response)) // { ok: true }
console.log(judgeModelResponse({ ...response, outcome: 'future', dispatch: 0 }))
// { rejected: 'outcome_unknown' }
console.log(judgeModelResponse({
  ...response, outcome: 'interrupted', initiator: 'user',
  failure: { cause: 'request_rejected', inBand: true },
})) // { rejected: 'failure_on_interrupted' }''')],'''## Failures and boundaries

`judgeModelResponse` returns `{ ok: true }` or one `{ rejected }`. Precedence is: unknown outcome, integer dispatch below one, unknown failure cause, other independent member malformation; then `reply_missing`, `reply_on_failure`, `reply_and_delivered`, `failure_missing`, `failure_on_interrupted`, `failure_on_success`, `reply_ending_mismatch`, `first_token_inconsistent`; remaining cross-member violations are `malformed`. For example, missing `statusCode` with `failure.inBand: true` does not hide `failure_on_interrupted`. Schema-only `validate` reports shape validity rather than this rejection order.

Complete and truncated responses carry a reply and disposition. Mid-reply failure carries `delivered` and a first-token time, with no reply. Interruption has its own shapes and is not a failure. `late` belongs only to a response associated with a run. Numeric counts and costs use exact `JsonNumber` values, and unknown amounts are not replaced with zero.

Passing validation establishes representation validity. Actual dispatch provenance, identity uniqueness, clock provenance, truthful usage, redaction, snapshot capture and persistence remain the writer's responsibility. A rejected record is a writer defect; it must not be reclassified as a failed model call or used as a reason to automatically resend. This module reads no clocks or stores and performs no model calls.

Public JSON Schema entries are `@omne-harness-lite/model-response/schema` (v3) and `/schema/v2`. See [source exports](src/index.ts), [tests](tests/) and [model profile](../model-profile/README.md).''','''## 失败与边界

`judgeModelResponse` 返回 `{ ok: true }` 或一个 `{ rejected }`。优先次序是：未知收场、小于一的整数发出序号、未知故障成因、其他独立成员形状错误；随后依次是 `reply_missing`、`reply_on_failure`、`reply_and_delivered`、`failure_missing`、`failure_on_interrupted`、`failure_on_success`、`reply_ending_mismatch`、`first_token_inconsistent`；剩余跨成员违例是 `malformed`。例如 `failure.inBand: true` 缺 `statusCode` 不会盖过 `failure_on_interrupted`。只检查 Schema 的 `validate` 返回形状是否有效，不表达上述拒绝次序。

完整与截断响应带回复及其去向。回复中途故障带 `delivered` 与首 token 时刻，不带回复。中断有自己的条件形状，不属于故障。`late` 只属于关联运行的响应。计数与费用使用精确的 `JsonNumber`，未知金额不会被替换为零。

通过校验只说明表示有效。实际发出来源、身份唯一性、时钟来源、真实用量、脱敏、快照捕获与持久化仍由写入方负责。被拒绝的记录说明写入方有缺陷，不能被重新分类为模型调用故障，也不能据此自动重发。本模块不读时钟或存储，不调用模型。

公开 JSON Schema 入口是 `@omne-harness-lite/model-response/schema`（v3）和 `/schema/v2`。参见[源码导出](src/index.ts)、[测试](tests/)与[模型档案](../model-profile/README_ZH.md)。''')
write('loop-extension',f'''Data and judgments for extensions at eleven agent-loop positions. Define an extension's declared power and implementation, admit invocation input, and check a recorded conclusion against that exact input.

{workspace_en}

| Public API | Use |
| --- | --- |
| `judgeDefinition`, `judgeInput`, `judgeOutput` | Admit protocol values and obtain typed copies |
| `judgeConclusion(value, inputs)` | Check conclusion shape, allowed combinations and immutable fields |
| `POSITIONS`, `POWERS`, `POWER_CONCLUSIONS`, `POSITION_CONCLUSIONS` | Inspect legal positions and output combinations |
| `loopExtensionBodyContract` | Supply definition rules to the asset model |
| `validate`, `judgeValue` | Use the schema and generic judgment surfaces |''',f'''提供十一处 Agent Loop 位置上拓展件的数据与判定。声明拓展件的干预力与实现，接收调用输入，并对照该次精确输入检查结论记录。

{workspace_zh}

| 公开 API | 用途 |
| --- | --- |
| `judgeDefinition`、`judgeInput`、`judgeOutput` | 接收协议值并取得带类型的副本 |
| `judgeConclusion(value, inputs)` | 检查结论形状、合法组合与不可改字段 |
| `POSITIONS`、`POWERS`、`POWER_CONCLUSIONS`、`POSITION_CONCLUSIONS` | 查看位置与结论的合法组合 |
| `loopExtensionBodyContract` | 为资产模型提供拓展件定义规则 |
| `validate`、`judgeValue` | 使用 Schema 与通用判定面 |''',[
('Admit a definition','接收拓展件定义','A declaration describes a builtin implementation; admission does not load or invoke that implementation.','声明描述一个内置实现；接收定义不会加载或调用它。','''import {
  judgeDefinition, POWER_CONCLUSIONS, POSITION_CONCLUSIONS,
  type LoopExtensionDefinition,
} from '@omne-harness-lite/loop-extension'

const definition: LoopExtensionDefinition = {
  name: 'review-before-action', position: 'before_action', power: 'veto',
  onError: 'record', unavailability: 'veto',
  needs: ['audit-log'], implementation: { kind: 'builtin', builtinName: 'action-review' },
}
console.log('ok' in judgeDefinition(definition)) // true
console.log(POWER_CONCLUSIONS.observe) // ['observed']
console.log(POSITION_CONCLUSIONS.after_terminal) // ['observed']'''),
('Compare a rewrite with its actual input','对照实际输入检查改写','Changing parsed arguments is representable here; changing call identity is rejected. The input judge establishes the opaque handle and content-block types.','这里允许表示对已解析参数的改写，但拒绝改变调用身份。输入判定器构造不透明句柄与内容块类型。','''import { judgeInput, judgeConclusion } from '@omne-harness-lite/loop-extension'

const input = judgeInput({
  position: 'before_action', run: 'run_1', attempt: 1,
  subject: {
    call: {
      id: 'block_call', kind: 'tool_call', complete: true, callId: 'call_1',
      tool: 'repo__read', arguments: { path: 'README.md' },
      visibility: { toHuman: true, toModel: true },
    },
    definition: { name: 'repo__read' }, batch: ['call_1'],
  },
  earlier: [], log: 'log_1', environment: 'environment_1',
})
if ('rejected' in input || input.ok.position !== 'before_action') throw new Error('Action input required')
const subject = input.ok.subject
const context = { input: input.ok, extensionName: 'review-before-action' }
const conclusion = {
  extension: context.extensionName, position: 'before_action', power: 'rewrite',
  callId: 'call_1', at: '2026-09-26T10:00:00Z',
  output: { kind: 'rewrite', subject: {
    ...subject, call: { ...subject.call, arguments: { path: 'CONTRIBUTING.md' } },
  } },
}
console.log('ok' in judgeConclusion(conclusion, context)) // true
console.log(judgeConclusion({
  ...conclusion, output: { kind: 'rewrite', subject: {
    ...subject, call: { ...subject.call, tool: 'other' },
  } },
}, context)) // { rejected: 'rewrite_touches_immutable' }''')],'''## Failures and boundaries

Judgments return a typed `{ ok }` copy or `{ rejected }`. `judgeConclusion` needs an admitted `ExtensionInput` and the actual extension name, paired to the same position, dimension and action identity. Missing or invalid auxiliary configuration throws `TypeError`; protocol rejection remains a separate result. Schema-only guards and `validate` cannot compare a rewrite against the actual invocation.

A valid conclusion is not dispatch authorization. The caller supplies the effective power, checks model/provider eligibility, performs admission, records conclusions, and applies them in loop order. `select_model`, `retry`, `ask` and `veto` are values here; no model selection, retry, waiting, veto effect or command execution happens in this package. Log and environment handles are opaque.

Rewrites preserve the immutable members for their position. An unparseable tool call cannot be repaired into parsed arguments by an extension. Injected reminders must name the actual extension as their source. Dependencies, policy execution, persistence and recovery belong to consumers.

Public JSON Schema entries are `@omne-harness-lite/loop-extension/schema` (v3) and `/schema/v2`. See [source exports](src/index.ts), [tests](tests/) and [tool definition](../tool-definition/README.md).''','''## 失败与边界

判定返回带类型的 `{ ok }` 副本或 `{ rejected }`。`judgeConclusion` 需要已经接收的 `ExtensionInput` 与真实拓展件名，并与该次位置、维度及动作身份配对。辅助配置缺失或不合法会抛出 `TypeError`；协议拒绝仍是独立结果。只检查 Schema 的类型守卫与 `validate` 无法对照实际调用检查改写。

合法结论不代表派发授权。调用方提供生效干预力，检查模型与供应商资格，完成放行，记录结论并按 Loop 次序应用。`select_model`、`retry`、`ask`、`veto` 在这里都是值；本包不执行模型选择、重试、等待、否决效果或命令。日志与环境句柄是不透明的。

改写保留对应位置的不可改成员。拓展件不能把无法解析的工具调用修补成已解析参数。注入提醒必须以真实拓展件名作为来源。依赖、策略执行、持久化与恢复归消费者负责。

公开 JSON Schema 入口是 `@omne-harness-lite/loop-extension/schema`（v3）和 `/schema/v2`。参见[源码导出](src/index.ts)、[测试](tests/)与[工具定义](../tool-definition/README_ZH.md)。''')
write('mcp-endpoint',f'''Pure data for authored MCP connection targets, timeouts, action snapshots and OAuth binding representations. Derive asset declarations from an endpoint and the action snapshot explicitly supplied by a caller.

{workspace_en}

| Public API | Use |
| --- | --- |
| `judgeMcpEndpoint`, `judgeMcpValue` | Judge endpoint and related representations |
| `deriveMcpDeclarations` | Derive fixed settings and known per-action permission declarations |
| `actionEntryName` | Construct a projectable tool entry name |
| `mcpBodyContract` | Supply MCP rules to the asset model |
| `validate`, `schemaId`, `SCHEMA_DEF_NAMES` | Use the schema surface |''',f'''提供作者声明的 MCP 连接目标、超时、动作副本与 OAuth 绑定表示的纯数据模块。根据接入点与调用方显式传入的动作副本推出资产声明。

{workspace_zh}

| 公开 API | 用途 |
| --- | --- |
| `judgeMcpEndpoint`、`judgeMcpValue` | 判定接入点与相关表示 |
| `deriveMcpDeclarations` | 推出固定设置与已知的逐动作权限声明 |
| `actionEntryName` | 构造可投影的工具条目名 |
| `mcpBodyContract` | 为资产模型提供 MCP 正文规则 |
| `validate`、`schemaId`、`SCHEMA_DEF_NAMES` | 使用 Schema 校验面 |''',[
('Judge a connection target','判定连接目标','Endpoint names are supplied separately from the body. The example address is data and is never contacted.','接入点名字独立于正文传入。示例地址只是数据，不会发起连接。','''import { judgeMcpEndpoint, judgeMcpValue, type McpEndpoint } from '@omne-harness-lite/mcp-endpoint'

const endpoint: McpEndpoint = {
  transport: { kind: 'streamable_http', url: 'https://mcp.example.invalid/api' },
  timeouts: { connect: 'PT5S', call: 'PT30S' },
  permissions: { execute: { default: 'ask' } },
}
console.log(judgeMcpEndpoint(endpoint, { capabilityName: 'repo' })) // { ok: true }
console.log(judgeMcpEndpoint({
  ...endpoint, transport: { kind: 'streamable_http', url: 'https://user:secret@example.invalid' },
})) // { rejected: 'url_invalid' }
console.log(judgeMcpValue('OAuthBinding', {
  id: 'oauth_binding_1', state: 'granted', since: '2026-09-26T10:00:00Z',
})) // { ok: true }'''),
('Preserve snapshot knowledge and project names','保留动作副本信息并投影名字','A fetched empty action set is different from one that was never fetched. Fixed connection settings are available in both cases.','已经取得的空动作集合与尚未取得动作集合不同；两种情况下都能推出固定连接设置。','''import {
  deriveMcpDeclarations, actionEntryName, judgeMcpValue,
  type McpEndpoint, type ActionSnapshot,
} from '@omne-harness-lite/mcp-endpoint'

const endpoint: McpEndpoint = {
  transport: { kind: 'stdio', command: 'repo-mcp', args: ['--readonly'] },
  timeouts: { connect: 'PT5S', call: 'PT30S' },
  permissions: { execute: { default: 'ask' } },
}
const actions: ActionSnapshot = {
  kind: 'fetched', fetchedAt: '2026-09-26T10:00:00Z',
  tools: [{ name: 'read', description: 'Read a file', inputSchema: {
    type: 'object', properties: { path: { type: 'string' } },
  } }],
}
console.log(judgeMcpValue('ActionSnapshot', actions)) // { ok: true }
const known = deriveMcpDeclarations(endpoint, actions)
console.log(known.actionSnapshotKind) // fetched
console.log(known.declarations.map(item => item.item))
// ['connectionTarget', 'credential', 'connectTimeout', 'callTimeout', 'execute:read']
console.log(deriveMcpDeclarations(endpoint, { kind: 'not_fetched' }).actionSnapshotKind) // not_fetched
console.log(deriveMcpDeclarations(endpoint).actionSnapshotKind) // undefined
console.log(actionEntryName('repo', 'read')) // { ok: 'repo:read' }
console.log(actionEntryName('repo', 'has space')) // { notProjectable: true }''')],'''## Failures and boundaries

Judgments return `{ ok: true }` or `{ rejected }`; `malformed` includes an `M` diagnostic. Name projection returns `{ ok: name }` or `{ notProjectable: true }`. Action entry construction is forward-only: keep the endpoint and remote name as separate facts rather than decoding a concatenated name.

MCP descriptor extension fields stay JSON data. `inputSchema` is not compiled or repaired here; projection to executable Tool definitions needs Tool admission in a consumer. Snapshot knowledge is explicit: omitted, `not_fetched`, and `fetched` are distinct. Per-action permissions are derived only from a fetched snapshot; no snapshot does not mean an empty known action set.

The package does not start stdio processes, connect HTTP, discover or call tools, perform OAuth, resolve credentials, or refresh snapshots. OAuth bindings describe data, not authorized state transitions. URL checks validate syntax rather than endpoint trust or secrecy; credentials belong outside the endpoint body. Runtime transport, authorization and lifecycle belong to consumers.

The JSON Schema is available through `@omne-harness-lite/mcp-endpoint/schema`. See [source exports](src/index.ts), [tests](tests/) and [asset evaluation](../asset-evaluation/README.md).''','''## 失败与边界

判定返回 `{ ok: true }` 或 `{ rejected }`，`malformed` 带 `M` 诊断。名字投影返回 `{ ok: name }` 或 `{ notProjectable: true }`。动作条目名只提供向前构造；应分别保留接入点与对端名字，不通过拼接后的名字反解它们。

MCP 描述的拓展字段保留为 JSON 数据。这里不编译或修补 `inputSchema`；投影为可执行 Tool 定义需要消费者进行 Tool 接收判定。动作副本的信息显式区分：未传入、`not_fetched`、`fetched` 是三种情况。只有取得副本后才推出逐动作权限；没有副本不表示已知动作集合为空。

本包不启动 stdio 进程，不连接 HTTP，不发现或调用工具，不执行 OAuth，不解析凭据，不刷新副本。OAuth 绑定描述数据，不授权状态转移。URL 检查只验证语法，不判定端点可信性或秘密；凭据应放在接入点正文之外。运行时传输、授权与生命周期归消费者负责。

JSON Schema 通过 `@omne-harness-lite/mcp-endpoint/schema` 公开。参见[源码导出](src/index.ts)、[测试](tests/)与[资产求值](../asset-evaluation/README_ZH.md)。''')
write('slash-command',f'''Recognize delivery-surface slash commands, parse arguments against an explicit session command set, and expand prompt or selected skill content. Results describe what a consumer should do; the package performs no delivery or service dispatch.

{workspace_en}

| Public API | Use |
| --- | --- |
| `recognize` | Distinguish text, literal slash text and invocation attempts |
| `parseInvocation` | Parse against the supplied session command set |
| `expandPrompt`, `expandSkill` | Project prompt text or selected skill blocks |
| `judgeSlashCommand`, `judgeInvocation`, `judgeSlashCommandValue` | Validate definitions and exchange values |
| `slashCommandBodyContract`, declaration/reference helpers | Integrate definitions with asset evaluation |''',f'''识别交付面的斜杠命令，根据显式会话命令集解析参数，并展开提示词或已选技能内容。结果描述消费者应做的事；本包不交付内容、不派发服务。

{workspace_zh}

| 公开 API | 用途 |
| --- | --- |
| `recognize` | 区分普通文本、字面斜杠文本与命令尝试 |
| `parseInvocation` | 根据显式传入的会话命令集解析 |
| `expandPrompt`、`expandSkill` | 投影提示词文本或已选技能内容块 |
| `judgeSlashCommand`、`judgeInvocation`、`judgeSlashCommandValue` | 校验定义与交换值 |
| `slashCommandBodyContract`、声明与引用辅助函数 | 将定义接入资产求值 |''',[
('Recognize and parse a prompt command','识别并解析提示词命令','Only a slash in the first code point starts an invocation. `//` sends literal slash text; an unknown invocation stays a failure.','只有首个码点上的斜杠才开始命令尝试。`//` 表示发送字面斜杠文本；未知命令仍是失败。','''import { recognize, parseInvocation, type SlashCommandDefinition } from '@omne-harness-lite/slash-command'

const definition: SlashCommandDefinition = {
  description: 'Summarize text', binding: { kind: 'prompt', template: 'Summarize: $ARGUMENTS' },
}
console.log(recognize('//summarize text')) // { kind: 'literal', text: '/summarize text' }
console.log(recognize(' /summarize text').kind) // text
const recognized = recognize('/summarize a short note')
if (recognized.kind !== 'invocation') throw new Error('Invocation required')
console.log(parseInvocation(recognized.invocation, { summarize: definition }))
// { kind: 'expanded', text: 'Summarize: a short note' }
console.log(parseInvocation(recognized.invocation, {}))
// { kind: 'failed', reason: 'unknown_command', at: { start: 0, end: 10 },
//   explanation: 'This session has no command with this name.' }'''),
('Parse typed service arguments','解析带类型的服务参数','Service commands use the official reserved namespace. Parsing produces data; it does not resolve or invoke the service.','服务命令使用官方保留命名空间。解析只产生数据，不解析或调用服务。','''import {
  judgeSlashCommand, recognize, parseInvocation, type SlashCommandDefinition,
} from '@omne-harness-lite/slash-command'

const name = 'omne-official:reload'
const definition: SlashCommandDefinition = {
  description: 'Reload an asset', binding: { kind: 'command', service: 'registry.reload' },
  parameters: [{ name: 'version', kind: 'integer', required: true, positional: true }],
}
console.log(judgeSlashCommand(definition, { capabilityName: name, origin: 'official' })) // { ok: true }
const recognized = recognize('/omne-official:reload 7')
if (recognized.kind !== 'invocation') throw new Error('Invocation required')
console.log(parseInvocation(recognized.invocation, { [name]: definition }))
// { kind: 'command', service: 'registry.reload', arguments: { version: 7 } }
console.log(judgeSlashCommand(definition, { capabilityName: name, origin: 'customized' }))
// { rejected: 'name_reserved' }'''),
('Expand an explicitly selected skill','展开显式选择的技能','The caller has already selected the effective, authorized skill. The body remains literal; arguments become a separate annotated block.','调用方已经选定生效且经过授权的技能。正文保留字面内容，参数成为另一个带来源的块。','''import { parseOpaqueIdentifier, unwrap } from '@omne-harness-lite/identity-values'
import { recognize, parseInvocation, expandSkill } from '@omne-harness-lite/slash-command'

const recognized = recognize('/review focus on errors')
if (recognized.kind !== 'invocation') throw new Error('Invocation required')
const parsed = parseInvocation(recognized.invocation, {
  review: { description: 'Review code', binding: {
    kind: 'skill', skill: { category: 'skill', name: 'review' },
  } },
})
if (parsed.kind !== 'skill') throw new Error('Skill binding required')
const skill = {
  manifest: { name: 'review', description: 'Review code' },
  body: 'Review the code. Keep $0 literal.', resources: [],
}
const blocks = expandSkill(recognized.invocation, parsed.skill.name, skill, [
  { id: unwrap(parseOpaqueIdentifier('skill_body', 'BlockId')),
    visibility: { toHuman: true, toModel: true } },
  { id: unwrap(parseOpaqueIdentifier('skill_arguments', 'BlockId')),
    visibility: { toHuman: true, toModel: true } },
])
console.log(blocks.map(block => block.text))
// ['Review the code. Keep $0 literal.', 'focus on errors']
console.log(blocks.map(block => block.origin?.kind)) // ['skill_body', 'slash_command_args']''')],'''## Failures and boundaries

Representation judgments return `{ ok: true }` or `{ rejected }`. Parsing returns `expanded`, `skill`, `command` or `failed`; a failure contains a reason, explanation and, where applicable, a Unicode code-point span. Missing and unauthorized commands look identical because parsing sees only the supplied set. A failure must not be silently converted to text delivery.

`recognize` is for human input arriving through a delivery surface. Callers must keep model output and connector, scheduled or peer-session text out of this grammar. Matching is case-sensitive. Quoted arguments, typed positional/named parameters and enum values are parsed only when the definition supplies `parameters`; without declarations, the argument text remains free text.

`expandSkill` takes the already selected SkillPackage and one caller-supplied block annotation per output block. It does not fetch, choose or authorize skills. Auxiliary inputs that violate helper preconditions throw `TypeError`, distinct from parse failure. The package does not log, send content, execute commands or resolve service names; those effects belong to the caller.

The JSON Schema is available through `@omne-harness-lite/slash-command/schema`. See [source exports](src/index.ts), [tests](tests/) and [skill package](../skill-package/README.md).''','''## 失败与边界

表示判定返回 `{ ok: true }` 或 `{ rejected }`。解析返回 `expanded`、`skill`、`command` 或 `failed`；失败带原因、说明以及适用时的 Unicode 码点区间。因为解析只看到传入的集合，缺失与无权限的命令表现相同。不能把失败静默转换为文本交付。

`recognize` 用于经交付面到达的人工输入。调用方应确保模型输出、连接件、定时或其他会话文本不进入这套文法。名字区分大小写。只有定义提供 `parameters` 时，才解析引号、带类型的位置与具名参数及枚举值；没有声明时，参数文字仍是自由文本。

`expandSkill` 接收已经选定的 SkillPackage，并要求调用方为每个输出块提供一份身份与可见性标注。它不读取、不选择、不授权技能。不符合辅助函数前提的输入会抛出 `TypeError`，与解析失败不同。本包不记录日志、不发送内容、不执行命令、不解析服务名；这些效果由调用方负责。

JSON Schema 通过 `@omne-harness-lite/slash-command/schema` 公开。参见[源码导出](src/index.ts)、[测试](tests/)与[技能包](../skill-package/README_ZH.md)。''')
