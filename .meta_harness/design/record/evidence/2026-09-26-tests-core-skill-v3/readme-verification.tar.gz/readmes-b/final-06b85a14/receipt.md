# Core README example verification receipt

Source checkout: `/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery`.
Source HEAD: `06b85a14ab3439b35b4f51211adcb0731fea6908`.
README inputs were uncommitted documentation at this source HEAD; exact bytes are preserved under `readmes/` and SHA-256 values are in `verification.json`.

All 21 unique README TypeScript examples passed TypeScript 6.0.3 with `strict`, `exactOptionalPropertyTypes`, `noUncheckedIndexedAccess`, and `skipLibCheck: false`. All 21 compiled examples ran in Node v24.18.0 with exit 0, empty stderr, and exact expected stdout. There are no pending examples.

| Package | Examples | Topics |
| --- | ---: | --- |
| asset-model | 2 | Asset body validation; explicit Skill v2 body contract |
| asset-evaluation | 2 | Evaluation metadata; accepted body evaluation |
| tool-definition | 3 | Tool definitions; parsed calls/results; malformed call rejection |
| model-profile | 2 | Profile judgment; request configuration projection |
| model-response | 2 | Response judgment; failure precedence |
| loop-extension | 2 | Extension values; hook-plan derivation |
| mcp-endpoint | 2 | Endpoint values; declarations and dependencies |
| slash-command | 3 | Commands; Skill projection; argument substitution |
| skill-package | 3 | Text/directory input; value projections; retained v2 body contract |

Both languages contain identical example code bytes. The 18 READMEs pass scoped Prettier checking and `git diff --check`; local-link audit found no missing links or private-design links. Public entry-point resolution confirms root Skill v3, retained `/v2`, `/schema`, `/schema/v2`, and Asset Evaluation's v2 Skill body dependency.

`manifest.json` binds extracted source hashes to expected-output provenance. `runtime-results.json` and each raw runtime log preserve actual and expected stdout. Skill v3 stdout expectations come from literal scripts under `oracles/` that do not import product code. Previously validated expectations are explicitly identified as historical expectations; the actual current executions are new evidence. Existing original and formatted evidence directories were preserved.

`before-artifact-sha256.json` and `after-artifact-sha256.json` are identical for all core dist/schema artifacts. This verification did not run build or install, modify product source, stage or commit files, or overwrite old evidence. These results verify documentation examples and do not constitute delivery acceptance.

All subprocesses have exited. The README worker releases its HUB checkout and evidence consumer; the parent may copy/seal this directory and retire the worktree according to the authorized integration flow.
