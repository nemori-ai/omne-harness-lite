console.log(true)
console.log([
  ['user-invocable', 'external_attribute'],
  ['vendor-note', 'unknown'],
])
console.log(['references/checklist.md'])
console.log({ rejected: 'malformed', malformed: 'M16' })
