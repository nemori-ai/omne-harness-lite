from pathlib import Path
import re,json,hashlib,subprocess
root=Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='06b85a14ab3439b35b4f51211adcb0731fea6908'
scratch=root/'tmp/core-delivery/readmes-b/final-06b85a14'
scratch.mkdir(exist_ok=True)
examples=scratch/'examples';examples.mkdir(exist_ok=True)
expected=scratch/'oracles';expected.mkdir(exist_ok=True)
names=['asset-model','asset-evaluation','tool-definition','model-profile','model-response','loop-extension','mcp-endpoint','slash-command','skill-package']
rows=[];missing=[];document_hashes={}
prior={row['file']:row for row in json.loads((scratch.parent/'runtime-results.json').read_text())}
for name in names:
 en=(root/'packages/core'/name/'README.md').read_text()
 zh=(root/'packages/core'/name/'README_ZH.md').read_text()
 codes=re.findall(r'```ts\n([\s\S]*?)\n```',en)
 assert codes==re.findall(r'```ts\n([\s\S]*?)\n```',zh)
 assert 2<=len(codes)<=3
 assert '.meta_harness' not in en+zh
 for i,code in enumerate(codes,1):
  filename=f'{name}-{i}.mts'
  (examples/filename).write_text(code+'\n')
  row={'file':filename,'package':name,'source_sha256':hashlib.sha256((code+'\n').encode()).hexdigest()}
  if filename in prior:
   (expected/(filename+'.stdout')).write_text(prior[filename]['output'])
   row['oracle']='previous stable runtime stdout retained as the unchanged expected output'
  elif filename=='asset-model-2.mts':
   (expected/(filename+'.stdout')).write_bytes((scratch.parent/'stable-root-runtime.log').read_bytes())
   row['oracle']='previous Skill2 root-equivalent runtime stdout, final example actually imports /v2'
  else:row['oracle']='independent literal-output program generated from README expected outputs; no product imports'
  rows.append(row)
 for filename in ['README.md','README_ZH.md']:
  path=root/'packages/core'/name/filename
  document_hashes[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
  for link in re.findall(r'\]\(([^)]+)\)',path.read_text()):
   if not link.startswith(('https:','http:','#')) and not (path.parent/link.split('#')[0]).exists():missing.append({'file':str(path.relative_to(root)),'link':link})
config={'extends':'../../../../tsconfig.base.json','compilerOptions':{'strict':True,'skipLibCheck':False,'exactOptionalPropertyTypes':True,'noUncheckedIndexedAccess':True,'resolveJsonModule':True,'declaration':False,'declarationMap':False,'sourceMap':False,'rootDir':'examples','outDir':'compiled'},'files':[f"examples/{row['file']}" for row in rows]}
(scratch/'tsconfig.json').write_text(json.dumps(config,indent=2)+'\n')
(scratch/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
(scratch/'documentation-audit.json').write_text(json.dumps({'head':head,'readmes':18,'examples':21,'bilingual_code_equal':True,'missing_links':missing,'private_design_links':0,'readme_sha256':document_hashes},indent=2)+'\n')
artifacts={}
for package in (root/'packages/core').iterdir():
 for folder in ['dist','schema']:
  if (package/folder).exists():
   for path in (package/folder).rglob('*'):
    if path.is_file():artifacts[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
(scratch/'before-artifact-sha256.json').write_text(json.dumps(artifacts,indent=2)+'\n')
print('Final extraction: 21 bilingual-identical examples on HEAD '+head+'; missing links: '+str(missing))
