import { parseTenantId, unwrap } from '@omne-harness-lite/identity-values';
import { toOpaqueJson } from '@omne-harness-lite/content-blocks';
import {} from '@omne-harness-lite/asset-model';
import { evaluate } from '@omne-harness-lite/asset-evaluation';
const tenant = unwrap(parseTenantId({ organization: 'org_acme', account: 'acc_alice' }));
const at = '2026-09-26T10:00:00Z';
const root = { category: 'agent_definition', name: 'assistant' };
const tool = { category: 'tool', name: 'inspect' };
function factory(capability, asset) {
    return {
        holder: { layer: 'factory' },
        capability,
        asset,
        basis: { kind: 'official' },
        versionSelection: { kind: 'current' },
        immutable: false,
        assignments: [],
        since: at,
    };
}
const input = {
    tenant,
    standing: { standing: 'effective', role: 'member' },
    root: {
        definition: root,
        references: [
            { capability: tool, resident: true },
            { capability: { category: 'skill', name: 'missing-review' } },
        ],
    },
    holdings: [factory(root, 'asset_root'), factory(tool, 'asset_inspect')],
    definitions: [
        {
            id: 'asset_root',
            capability: root,
            origin: 'official',
            versions: [
                {
                    number: 1,
                    publishedAt: at,
                    content: { category: 'agent_definition', body: toOpaqueJson({}) },
                },
            ],
        },
        {
            id: 'asset_inspect',
            capability: tool,
            origin: 'official',
            versions: [
                {
                    number: 1,
                    publishedAt: at,
                    content: {
                        category: 'tool',
                        definition: {
                            name: 'inspect',
                            description: 'Inspect files',
                            paradigm: 'single',
                            origin: { kind: 'authored' },
                            input: { type: 'object', properties: {} },
                            permissions: { execute: { default: 'ask' } },
                        },
                    },
                },
            ],
        },
    ],
};
const result = evaluate(input);
if (!('ok' in result))
    throw new Error(JSON.stringify(result));
console.log(result.ok.assets.map(asset => asset.capability.name)); // ['assistant', 'inspect']
console.log(result.ok.unresolved.map(entry => entry.capability.name)); // ['missing-review']
console.log(result.ok.values.find(value => value.item === 'execute')?.value); // { allowed: ['ask'] }
