console.log({ ok: true })
console.log({ ok: true })
console.log({ rejected: 'malformed', malformed: 'M12' })
