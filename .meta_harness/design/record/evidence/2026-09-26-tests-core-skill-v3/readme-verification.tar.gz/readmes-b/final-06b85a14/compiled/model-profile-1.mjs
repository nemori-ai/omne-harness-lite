import { judgeModelProfileDocument, validate, parameterNames, } from '@omne-harness-lite/model-profile';
const profile = {
    routeName: 'vendor/chat',
    origin: 'official',
    providers: ['provider-a'],
    allowFallback: false,
    inputModalities: ['text'],
    outputModalities: ['text'],
    maxInputTokens: 32000,
    maxOutputTokens: 8192,
    inputConstraints: {},
    parameters: { maxOutputTokens: 4096, extra: { top_k: 40 } },
    registration: 'listed',
    updatedAt: '2026-09-26T10:00:00Z',
};
console.log(judgeModelProfileDocument('ModelProfile', profile)); // { ok: true }
if (profile.parameters === undefined)
    throw new Error('Parameters required');
console.log(parameterNames(profile.parameters)); // ['maxOutputTokens', 'top_k']
const oversized = { ...profile, parameters: { maxOutputTokens: 8193 } };
console.log(validate('ModelProfile', oversized).valid); // true
console.log(judgeModelProfileDocument('ModelProfile', oversized));
// { rejected: 'max_output_exceeds_profile' }
