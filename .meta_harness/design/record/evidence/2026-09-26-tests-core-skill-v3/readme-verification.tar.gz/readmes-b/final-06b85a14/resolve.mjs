import { defaultBodyContracts } from '@omne-harness-lite/asset-evaluation'
import { schemaId as skill3Schema, skillBodyContract as skill3 } from '@omne-harness-lite/skill-package'
import { schemaId as skill2Schema, skillBodyContract as skill2 } from '@omne-harness-lite/skill-package/v2'
const entries = [
  '@omne-harness-lite/skill-package',
  '@omne-harness-lite/skill-package/v2',
  '@omne-harness-lite/skill-package/schema',
  '@omne-harness-lite/skill-package/schema/v2',
  '@omne-harness-lite/asset-evaluation',
  '@omne-harness-lite/slash-command',
]
if (skill3.schema.$id !== skill3Schema || skill2.schema.$id !== skill2Schema || defaultBodyContracts.skill.schema.$id !== skill2Schema || skill3Schema === skill2Schema) {
  throw new Error('Unexpected version composition')
}
console.log(JSON.stringify({
  resolved: Object.fromEntries(entries.map(entry => [entry, import.meta.resolve(entry)])),
  schemas: { defaultSkill: skill3Schema, retainedSkill: skill2Schema, assetEvaluationSkill: defaultBodyContracts.skill.schema.$id },
}, null, 2))
