import {
  judgeSkillPackage,
  skillAttributeDeclarations,
  skillReferences,
  skillDependencies,
  skillScripts,
  skillBodyContract,
  type SkillPackage,
} from '@omne-harness-lite/skill-package'

const pkg: SkillPackage = {
  manifest: { name: 'review', description: 'Review code', 'allowed-tools': 'Bash Read' },
  body: 'Review every change. Keep $0 literal.',
  definition: {
    format: 1,
    tools: [{ category: 'tool', name: 'repo:read' }],
    dependencies: ['repository-index'],
    settings: [
      {
        item: 'variant',
        kind: 'setting',
        category: 'preference',
        domain: { kind: 'open', schema: { type: 'string', enum: ['brief', 'full'] } },
        default: 'brief',
      },
    ],
    environmentRequirement: { bindingLayer: 'stateless_sandbox', facilities: ['python'] },
  },
  resources: [
    { path: 'references/checklist.md' },
    { path: 'scripts/review.py', mediaType: 'text/x-python' },
  ],
}
console.log(judgeSkillPackage(pkg, { capabilityName: 'review' })) // { ok: true }
console.log(skillAttributeDeclarations(pkg).map(entry => entry.item)) // ['variant']
console.log(skillReferences(pkg)) // [{ category: 'tool', name: 'repo:read' }]
console.log(skillDependencies(pkg).map(entry => entry.kind))
// ['tool', 'external_service', 'execution_environment']
console.log(skillScripts(pkg).map(entry => entry.path)) // ['scripts/review.py']
console.log(skillBodyContract.category) // skill
