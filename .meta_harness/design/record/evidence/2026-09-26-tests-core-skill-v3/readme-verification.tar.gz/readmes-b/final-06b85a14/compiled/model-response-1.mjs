import { parseOpaqueIdentifier, unwrap } from '@omne-harness-lite/identity-values';
import { judgeContentBlock } from '@omne-harness-lite/content-blocks';
import { judgeModelResponse } from '@omne-harness-lite/model-response';
const block = judgeContentBlock({
    id: 'block_1',
    kind: 'text',
    text: 'Ready.',
    visibility: { toHuman: true, toModel: true },
});
if ('rejected' in block || block.ok.kind !== 'text')
    throw new Error('Text block required');
const { origin: _origin, ...replyBlock } = block.ok;
const response = {
    id: 'response_1',
    call: { callId: 'model_call_1' },
    dispatch: 1,
    route: {
        profile: { origin: 'official', routeName: 'vendor/chat' },
        profileSnapshot: {
            providers: ['provider-a'],
            allowFallback: false,
            inputModalities: ['text'],
            outputModalities: ['text'],
            maxInputTokens: 32000,
            maxOutputTokens: 8192,
            updatedAt: '2026-09-26T09:00:00Z',
        },
        selectedBy: 'session',
        provider: 'provider-a',
        credentialScope: { layer: 'factory' },
        parameters: { maxOutputTokens: 64 },
    },
    outcome: 'complete',
    reply: {
        id: unwrap(parseOpaqueIdentifier('message_1', 'MessageId')),
        type: 'assistant',
        response: 'response_1',
        ending: 'complete',
        blocks: [replyBlock],
        createdAt: '2026-09-26T10:00:02Z',
    },
    replyDisposition: 'persisted',
    timing: {
        sentAt: '2026-09-26T10:00:00Z',
        firstTokenAt: '2026-09-26T10:00:01Z',
        endedAt: '2026-09-26T10:00:02Z',
    },
    usage: {
        input_tokens: 12,
        output_tokens: 2,
        cache_read_tokens: 0,
        cache_write_tokens: 0,
        source: 'upstream',
    },
    cost: { cost_usd: 0.0001, source: 'upstream_usage' },
};
console.log(judgeModelResponse(response)); // { ok: true }
console.log(judgeModelResponse({ ...response, reply: { ...response.reply, ending: 'truncated_at_limit' } }));
// { rejected: 'reply_ending_mismatch' }
