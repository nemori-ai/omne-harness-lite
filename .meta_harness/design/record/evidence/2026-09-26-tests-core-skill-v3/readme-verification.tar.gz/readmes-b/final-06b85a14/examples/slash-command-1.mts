import {
  recognize,
  parseInvocation,
  type SlashCommandDefinition,
} from '@omne-harness-lite/slash-command'

const definition: SlashCommandDefinition = {
  description: 'Summarize text',
  binding: { kind: 'prompt', template: 'Summarize: $ARGUMENTS' },
}
console.log(recognize('//summarize text')) // { kind: 'literal', text: '/summarize text' }
console.log(recognize(' /summarize text').kind) // text
const recognized = recognize('/summarize a short note')
if (recognized.kind !== 'invocation') throw new Error('Invocation required')
console.log(parseInvocation(recognized.invocation, { summarize: definition }))
// { kind: 'expanded', text: 'Summarize: a short note' }
console.log(parseInvocation(recognized.invocation, {}))
// { kind: 'failed', reason: 'unknown_command', at: { start: 0, end: 10 },
//   explanation: 'This session has no command with this name.' }
