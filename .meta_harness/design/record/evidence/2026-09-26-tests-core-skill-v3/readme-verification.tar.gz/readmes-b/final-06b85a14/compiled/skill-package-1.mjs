import { readSkillMd, readSkillPackage, } from '@omne-harness-lite/skill-package';
const body = '\nKeep $ARGUMENTS literal.\r\n';
const text = [
    '---',
    'name: review',
    'description: Review code',
    'user-invocable: false',
    'vendor-note: arbitrary',
    '---',
].join('\n') +
    '\n' +
    body;
const markdown = readSkillMd(text);
if (!('ok' in markdown))
    throw new Error(JSON.stringify(markdown));
console.log(markdown.ok.body === body); // true
console.log(markdown.ok.unknownKeys.map(entry => [entry.key, entry.category]));
// [['user-invocable', 'external_attribute'], ['vendor-note', 'unknown']]
const entries = [
    { kind: 'file', path: 'SKILL.md', text },
    { kind: 'directory', path: '.omne' },
    {
        kind: 'file',
        path: '.omne/skill.json',
        text: '{"format":1,"tools":[{"category":"tool","name":"repo:read"}]}',
    },
    { kind: 'directory', path: 'references' },
    { kind: 'file', path: 'references/checklist.md', mediaType: 'text/markdown' },
];
const read = readSkillPackage(entries, { capabilityName: 'review' });
if (!('ok' in read))
    throw new Error(JSON.stringify(read));
console.log(read.ok.package.resources.map(resource => resource.path)); // ['references/checklist.md']
console.log(readSkillMd([
    '---',
    'name: review',
    'description: Review code',
    '!opaque a: first',
    '!opaque b: second',
    '---',
    'body',
].join('\n'))); // { rejected: 'malformed', malformed: 'M16' }
