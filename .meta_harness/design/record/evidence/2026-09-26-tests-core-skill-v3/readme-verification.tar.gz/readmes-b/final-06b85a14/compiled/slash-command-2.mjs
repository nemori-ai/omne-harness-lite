import { judgeSlashCommand, recognize, parseInvocation, } from '@omne-harness-lite/slash-command';
const name = 'omne-official:reload';
const definition = {
    description: 'Reload an asset',
    binding: { kind: 'command', service: 'registry.reload' },
    parameters: [{ name: 'version', kind: 'integer', required: true, positional: true }],
};
console.log(judgeSlashCommand(definition, { capabilityName: name, origin: 'official' })); // { ok: true }
const recognized = recognize('/omne-official:reload 7');
if (recognized.kind !== 'invocation')
    throw new Error('Invocation required');
console.log(parseInvocation(recognized.invocation, { [name]: definition }));
// { kind: 'command', service: 'registry.reload', arguments: { version: 7 } }
console.log(judgeSlashCommand(definition, { capabilityName: name, origin: 'customized' }));
// { rejected: 'name_reserved' }
