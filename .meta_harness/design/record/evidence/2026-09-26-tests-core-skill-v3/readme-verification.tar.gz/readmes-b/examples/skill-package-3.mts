import { schemaId, judgeSkillPackage, type SkillPackage } from '@omne-harness-lite/skill-package'
import {
  judgeSkillPackage as judgeV2, skillBodyContract as bodyV2,
} from '@omne-harness-lite/skill-package/v2'

const pkg: SkillPackage = {
  manifest: { name: 'review', description: 'Review code' },
  body: 'Review code.', resources: [],
}
const judgment = judgeV2(pkg)
if ('rejected' in judgment) throw new Error(judgment.rejected)
console.log(bodyV2.judge(pkg, { capabilityName: 'review' })) // { ok: true }
const withV3Reference: SkillPackage = {
  ...pkg,
  definition: { format: 1, settings: [{
    item: 'variant', kind: 'setting', category: 'preference',
    domain: { kind: 'open', schema: { $ref: `${schemaId}#/$defs/SkillName` } },
    default: 'review',
  }] },
}
console.log(judgeSkillPackage(withV3Reference)) // { ok: true }
console.log(judgeV2(withV3Reference)) // { rejected: 'malformed', malformed: 'M12' }
