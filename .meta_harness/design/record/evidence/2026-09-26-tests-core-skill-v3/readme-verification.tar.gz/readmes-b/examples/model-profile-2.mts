import { parseScopeLayerIdentity, unwrap } from '@omne-harness-lite/identity-values'
import { refMatches, type ModelProfile, type ModelProfileRef } from '@omne-harness-lite/model-profile'

const alice = unwrap(parseScopeLayerIdentity({
  layer: 'tenant', tenant: { organization: 'org_acme', account: 'acc_alice' },
}))
const bob = unwrap(parseScopeLayerIdentity({
  layer: 'tenant', tenant: { organization: 'org_acme', account: 'acc_bob' },
}))
const profile: ModelProfile = {
  routeName: 'vendor/chat', origin: 'custom', providers: ['provider-a'],
  allowFallback: false, inputModalities: ['text'], outputModalities: ['text'],
  maxInputTokens: 32000, maxOutputTokens: 8192, inputConstraints: {},
  registration: 'withdrawn', updatedAt: '2026-09-26T10:00:00Z',
}
const ref: ModelProfileRef = { origin: 'custom', routeName: 'vendor/chat', scope: alice }
console.log(refMatches(ref, profile, alice)) // true
console.log(refMatches(ref, profile, bob)) // false
