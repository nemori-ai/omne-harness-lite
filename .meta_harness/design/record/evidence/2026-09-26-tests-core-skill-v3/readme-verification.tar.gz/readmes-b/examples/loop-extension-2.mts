import { judgeInput, judgeConclusion } from '@omne-harness-lite/loop-extension'

const input = judgeInput({
  position: 'before_action', run: 'run_1', attempt: 1,
  subject: {
    call: {
      id: 'block_call', kind: 'tool_call', complete: true, callId: 'call_1',
      tool: 'repo__read', arguments: { path: 'README.md' },
      visibility: { toHuman: true, toModel: true },
    },
    definition: { name: 'repo__read' }, batch: ['call_1'],
  },
  earlier: [], log: 'log_1', environment: 'environment_1',
})
if ('rejected' in input || input.ok.position !== 'before_action') throw new Error('Action input required')
const subject = input.ok.subject
const context = { input: input.ok, extensionName: 'review-before-action' }
const conclusion = {
  extension: context.extensionName, position: 'before_action', power: 'rewrite',
  callId: 'call_1', at: '2026-09-26T10:00:00Z',
  output: { kind: 'rewrite', subject: {
    ...subject, call: { ...subject.call, arguments: { path: 'CONTRIBUTING.md' } },
  } },
}
console.log('ok' in judgeConclusion(conclusion, context)) // true
console.log(judgeConclusion({
  ...conclusion, output: { kind: 'rewrite', subject: {
    ...subject, call: { ...subject.call, tool: 'other' },
  } },
}, context)) // { rejected: 'rewrite_touches_immutable' }
