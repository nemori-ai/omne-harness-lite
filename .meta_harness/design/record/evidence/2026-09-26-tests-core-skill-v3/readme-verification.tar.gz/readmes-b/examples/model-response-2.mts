import { judgeModelResponse, type ModelResponse } from '@omne-harness-lite/model-response'

const response: ModelResponse = {
  id: 'response_failed', call: { callId: 'model_call_2' }, dispatch: 1,
  route: {
    profile: { origin: 'official', routeName: 'vendor/chat' },
    profileSnapshot: {
      providers: ['provider-a'], allowFallback: false,
      inputModalities: ['text'], outputModalities: ['text'],
      maxInputTokens: 32000, maxOutputTokens: 8192,
      updatedAt: '2026-09-26T09:00:00Z',
    },
    selectedBy: 'session', provider: 'provider-a',
    credentialScope: { layer: 'factory' }, parameters: {},
  },
  outcome: 'failed', failure: { cause: 'request_rejected', statusCode: 429 },
  timing: { sentAt: '2026-09-26T10:00:00Z', endedAt: '2026-09-26T10:00:02Z' },
  usage: { input_tokens: 'unknown', output_tokens: 'unknown', cache_read_tokens: 'unknown',
    cache_write_tokens: 'unknown', source: 'none' },
  cost: { cost_usd: 'unknown', source: 'none' },
}
console.log(judgeModelResponse(response)) // { ok: true }
console.log(judgeModelResponse({ ...response, outcome: 'future', dispatch: 0 }))
// { rejected: 'outcome_unknown' }
console.log(judgeModelResponse({
  ...response, outcome: 'interrupted', initiator: 'user',
  failure: { cause: 'request_rejected', inBand: true },
})) // { rejected: 'failure_on_interrupted' }
