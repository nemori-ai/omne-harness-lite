import {
  createAssetModelJudge, attributeDeclarationsOf, referencesOf,
  parseWorkspaceManifestText, type AssetContent, type NonConnectorBodyContracts,
} from '@omne-harness-lite/asset-model'
import { toolBodyContract } from '@omne-harness-lite/tool-definition'
import { loopExtensionBodyContract } from '@omne-harness-lite/loop-extension'
import { skillBodyContract } from '@omne-harness-lite/skill-package'
import { mcpBodyContract } from '@omne-harness-lite/mcp-endpoint'
import { slashCommandBodyContract } from '@omne-harness-lite/slash-command'

const bodies: NonConnectorBodyContracts = {
  tool: toolBodyContract,
  loop_extension: loopExtensionBodyContract,
  skill: skillBodyContract,
  mcp: mcpBodyContract,
  slash_command: slashCommandBodyContract,
}
const content = {
  category: 'tool',
  definition: {
    name: 'repo:inspect', description: 'Inspect a repository',
    paradigm: 'single', origin: { kind: 'authored' },
    input: { type: 'object', properties: {} },
    permissions: { execute: { default: 'ask' } },
    composes: { skills: ['review'] },
  },
} satisfies AssetContent
const judge = createAssetModelJudge(bodies)
console.log(judge.judgeAssetValue('AssetContent', content)) // { ok: true }
const declarations = attributeDeclarationsOf(content, bodies)
if ('underivable' in declarations) throw new Error('Tool declarations required')
console.log(declarations.declarations.map(item => item.item))
// ['execute', 'disabled', 'usableBy']
console.log(referencesOf(content, bodies))
// { references: [{ category: 'skill', name: 'review' }] }
console.log(parseWorkspaceManifestText(
  '{"format":1,"assets":[],"assignments":[],"disabled":[]}', bodies,
)) // { ok: { format: 1, assets: [], assignments: [], disabled: [] } }
console.log(parseWorkspaceManifestText(
  '{"format":1,"format":1,"assets":[],"assignments":[],"disabled":[]}', bodies,
)) // { rejected: 'malformed' }
