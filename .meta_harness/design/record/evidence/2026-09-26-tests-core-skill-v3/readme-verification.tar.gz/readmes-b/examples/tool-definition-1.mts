import {
  createParameterJudge, judgeToolDefinition, modelEntry, type ToolDefinition,
} from '@omne-harness-lite/tool-definition'

const tool: ToolDefinition = {
  name: 'repo:read', description: 'Read one repository file',
  paradigm: 'single', origin: { kind: 'authored' },
  input: {
    type: 'object',
    properties: { path: { type: 'string', description: 'Repository-relative path' } },
    required: ['path'],
  },
  permissions: { execute: { default: 'ask' } },
}
const judge = createParameterJudge()
console.log(judgeToolDefinition(tool, judge)) // { ok: true }
console.log(modelEntry(tool).name) // repo__read
console.log(judge.judgeCallArguments(tool, { path: 'README.md' }))
// { ok: { args: { path: 'README.md' } } }
console.log('invalid' in judge.judgeCallArguments(tool, { path: 'README.md', extra: true })) // true
