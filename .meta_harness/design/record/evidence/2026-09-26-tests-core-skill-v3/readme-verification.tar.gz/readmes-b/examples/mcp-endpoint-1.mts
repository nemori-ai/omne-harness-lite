import { judgeMcpEndpoint, judgeMcpValue, type McpEndpoint } from '@omne-harness-lite/mcp-endpoint'

const endpoint: McpEndpoint = {
  transport: { kind: 'streamable_http', url: 'https://mcp.example.invalid/api' },
  timeouts: { connect: 'PT5S', call: 'PT30S' },
  permissions: { execute: { default: 'ask' } },
}
console.log(judgeMcpEndpoint(endpoint, { capabilityName: 'repo' })) // { ok: true }
console.log(judgeMcpEndpoint({
  ...endpoint, transport: { kind: 'streamable_http', url: 'https://user:secret@example.invalid' },
})) // { rejected: 'url_invalid' }
console.log(judgeMcpValue('OAuthBinding', {
  id: 'oauth_binding_1', state: 'granted', since: '2026-09-26T10:00:00Z',
})) // { ok: true }
