import {
  judgeDefinition, POWER_CONCLUSIONS, POSITION_CONCLUSIONS,
  type LoopExtensionDefinition,
} from '@omne-harness-lite/loop-extension'

const definition: LoopExtensionDefinition = {
  name: 'review-before-action', position: 'before_action', power: 'veto',
  onError: 'record', unavailability: 'veto',
  needs: ['audit-log'], implementation: { kind: 'builtin', builtinName: 'action-review' },
}
console.log('ok' in judgeDefinition(definition)) // true
console.log(POWER_CONCLUSIONS.observe) // ['observed']
console.log(POSITION_CONCLUSIONS.after_terminal) // ['observed']
