import {
  deriveMcpDeclarations, actionEntryName, judgeMcpValue,
  type McpEndpoint, type ActionSnapshot,
} from '@omne-harness-lite/mcp-endpoint'

const endpoint: McpEndpoint = {
  transport: { kind: 'stdio', command: 'repo-mcp', args: ['--readonly'] },
  timeouts: { connect: 'PT5S', call: 'PT30S' },
  permissions: { execute: { default: 'ask' } },
}
const actions: ActionSnapshot = {
  kind: 'fetched', fetchedAt: '2026-09-26T10:00:00Z',
  tools: [{ name: 'read', description: 'Read a file', inputSchema: {
    type: 'object', properties: { path: { type: 'string' } },
  } }],
}
console.log(judgeMcpValue('ActionSnapshot', actions)) // { ok: true }
const known = deriveMcpDeclarations(endpoint, actions)
console.log(known.actionSnapshotKind) // fetched
console.log(known.declarations.map(item => item.item))
// ['connectionTarget', 'credential', 'connectTimeout', 'callTimeout', 'execute:read']
console.log(deriveMcpDeclarations(endpoint, { kind: 'not_fetched' }).actionSnapshotKind) // not_fetched
console.log(deriveMcpDeclarations(endpoint).actionSnapshotKind) // undefined
console.log(actionEntryName('repo', 'read')) // { ok: 'repo:read' }
console.log(actionEntryName('repo', 'has space')) // { notProjectable: true }
