import { parseOpaqueIdentifier, unwrap } from '@omne-harness-lite/identity-values';
import { toolResultOf, judgeToolReturn } from '@omne-harness-lite/tool-definition';
const blockId = unwrap(parseOpaqueIdentifier('result_text', 'BlockId'));
const result = toolResultOf('{"status":"ok"}', blockId);
console.log(result.content[0]?.kind); // text
console.log(judgeToolReturn({ content: [{
            id: 'call_block', kind: 'tool_call', complete: true, callId: 'call_1',
            tool: 'repo__read', rawArguments: '{broken', unparseable: true,
            visibility: { toHuman: true, toModel: true },
        }] })); // { rejected: 'result_call_in_content' }
