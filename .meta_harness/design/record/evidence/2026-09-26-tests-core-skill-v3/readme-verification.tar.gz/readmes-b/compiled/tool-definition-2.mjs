import { createParameterJudge, modelInput } from '@omne-harness-lite/tool-definition';
const tool = {
    name: 'repo', description: 'Repository operations', paradigm: 'multi',
    origin: { kind: 'authored' }, permissions: { execute: { default: 'ask' } },
    commands: {
        status: { description: 'Show status', input: { type: 'object', properties: {} } },
        read: { description: 'Read a file', input: {
                type: 'object', properties: { path: { type: 'string', description: 'Relative file path' } },
                required: ['path'],
            } },
    },
};
const judge = createParameterJudge();
console.log(modelInput(tool).required); // ['command']
console.log(judge.judgeCallArguments(tool, { command: 'status' }));
// { ok: { command: 'status', args: {} } }
console.log('invalid' in judge.judgeCallArguments(tool, { command: 'read', args: {} })); // true
