import { parseOpaqueIdentifier, unwrap } from '@omne-harness-lite/identity-values';
import { recognize, parseInvocation, expandSkill } from '@omne-harness-lite/slash-command';
const recognized = recognize('/review focus on errors');
if (recognized.kind !== 'invocation')
    throw new Error('Invocation required');
const parsed = parseInvocation(recognized.invocation, {
    review: { description: 'Review code', binding: {
            kind: 'skill', skill: { category: 'skill', name: 'review' },
        } },
});
if (parsed.kind !== 'skill')
    throw new Error('Skill binding required');
const skill = {
    manifest: { name: 'review', description: 'Review code' },
    body: 'Review the code. Keep $0 literal.', resources: [],
};
const blocks = expandSkill(recognized.invocation, parsed.skill.name, skill, [
    { id: unwrap(parseOpaqueIdentifier('skill_body', 'BlockId')),
        visibility: { toHuman: true, toModel: true } },
    { id: unwrap(parseOpaqueIdentifier('skill_arguments', 'BlockId')),
        visibility: { toHuman: true, toModel: true } },
]);
console.log(blocks.map(block => block.text));
// ['Review the code. Keep $0 literal.', 'focus on errors']
console.log(blocks.map(block => block.origin?.kind)); // ['skill_body', 'slash_command_args']
