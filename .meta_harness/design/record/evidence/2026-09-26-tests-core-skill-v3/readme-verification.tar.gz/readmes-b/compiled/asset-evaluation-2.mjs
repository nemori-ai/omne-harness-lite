import { parseTenantId, unwrap } from '@omne-harness-lite/identity-values';
import {} from '@omne-harness-lite/asset-model';
import { readWorkspaceCarrier } from '@omne-harness-lite/asset-evaluation';
const tenant = unwrap(parseTenantId({ organization: 'org_acme', account: 'acc_alice' }));
const capability = { category: 'tool', name: 'inspect' };
const manifest = {
    format: 1,
    assets: [{ capability, source: 'tools/inspect.json' }],
    assignments: [
        { capability, item: 'timeout', value: 'PT10S', immutable: true },
        { capability: { category: 'skill', name: 'missing' }, item: 'variant', value: 'brief' },
    ],
    disabled: [capability],
};
const result = readWorkspaceCarrier(manifest, { tenant, directory: '/work/repo' });
if ('invalidInput' in result)
    throw new Error(JSON.stringify(result.invalidInput));
console.log(result.ok.holdings[0]?.assignments.map(entry => entry.item)); // ['timeout', 'disabled']
console.log(result.ok.dropped.map(entry => entry.reason)); // ['immutable_flag', 'unknown_asset']
