import { parseTenantId, unwrap } from '@omne-harness-lite/identity-values';
import { capabilityCanonicalString, parseCapabilityCanonicalString, normalizeWorkspaceDirectory, carrierRecordId, contentFingerprint, } from '@omne-harness-lite/asset-model';
const tenant = unwrap(parseTenantId({ organization: 'org_acme', account: 'acc_alice' }));
const capability = { category: 'tool', name: 'repo:inspect' };
const workspace = { tenant, directory: normalizeWorkspaceDirectory('/work/repo/./') };
console.log(capabilityCanonicalString(capability)); // tool/repo:inspect
console.log(parseCapabilityCanonicalString('tool/repo:inspect'));
// { ok: { category: 'tool', name: 'repo:inspect' } }
console.log(carrierRecordId(workspace, capability).startsWith('wsc1.')); // true
console.log(contentFingerprint({ a: 1, b: 2 }) === contentFingerprint({ b: 2, a: 1 })); // true
