from pathlib import Path
import hashlib,json,re
root=Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
scratch=root/'tmp/core-delivery/readmes-b/formatted'
examples=scratch/'examples'
examples.mkdir(exist_ok=True)
names=['asset-model','asset-evaluation','tool-definition','model-profile','model-response','loop-extension','mcp-endpoint','slash-command','skill-package']
rows=[]; missing=[]; document_hashes={}
for name in names:
 en=(root/'packages/core'/name/'README.md').read_text()
 zh=(root/'packages/core'/name/'README_ZH.md').read_text()
 codes=re.findall(r'```ts\n([\s\S]*?)\n```',en)
 assert codes==re.findall(r'```ts\n([\s\S]*?)\n```',zh), name
 assert 2<=len(codes)<=3
 assert '.meta_harness' not in en+zh
 for i,code in enumerate(codes,1):
  filename=f'{name}-{i}.mts'
  (examples/filename).write_text(code+'\n')
  rows.append({'file':filename,'pending':name=='skill-package' or (name=='asset-model' and i==2),'sha256':hashlib.sha256((code+'\n').encode()).hexdigest()})
 for filename in ['README.md','README_ZH.md']:
  path=root/'packages/core'/name/filename
  document_hashes[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
  for link in re.findall(r'\]\(([^)]+)\)',path.read_text()):
   if not link.startswith(('https:','http:','#')) and not (path.parent/link.split('#')[0]).exists(): missing.append({'file':str(path.relative_to(root)),'link':link})
config={'extends':'../../../../tsconfig.base.json','compilerOptions':{'skipLibCheck':False,'resolveJsonModule':True,'declaration':False,'declarationMap':False,'sourceMap':False,'rootDir':'examples','outDir':'compiled'},'files':[f"examples/{row['file']}" for row in rows if not row['pending']]}
(scratch/'tsconfig.json').write_text(json.dumps(config,indent=2)+'\n')
(scratch/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
(scratch/'documentation-audit.json').write_text(json.dumps({'readmes':18,'examples':21,'bilingual_code_equal':True,'missing_links':missing,'private_design_links':0,'readme_sha256':document_hashes},indent=2)+'\n')
print('Extracted 21 formatted bilingual-identical examples: 17 stable, 4 pending; missing links:',missing)
