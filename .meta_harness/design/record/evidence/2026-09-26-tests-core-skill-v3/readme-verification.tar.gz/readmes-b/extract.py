from pathlib import Path
import json, re, os
root=Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
scratch=root/'tmp/core-delivery/readmes-b'
examples=scratch/'examples'
examples.mkdir(exist_ok=True)
packages=['asset-model','asset-evaluation','tool-definition','model-profile','model-response','loop-extension','mcp-endpoint','slash-command']
manifest=[]
for name in packages:
 en=(root/'packages/core'/name/'README.md').read_text()
 zh=(root/'packages/core'/name/'README_ZH.md').read_text()
 english=re.findall(r'```ts\n([\s\S]*?)\n```',en)
 chinese=re.findall(r'```ts\n([\s\S]*?)\n```',zh)
 assert english==chinese, f'{name}: code differs between translations'
 assert 2 <= len(english) <= 3
 for i,code in enumerate(english,1):
  fn=f'{name}-{i}.mts'
  (examples/fn).write_text(code+'\n')
  manifest.append({'file':fn,'package':name,'number':i,'pending': name=='asset-model' and i==2})
scoped=scratch/'node_modules/@omne-harness-lite'
scoped.mkdir(parents=True,exist_ok=True)
for package in (root/'packages/core').iterdir():
 if (package/'package.json').exists() and not (scoped/package.name).exists():
  os.symlink(package,scoped/package.name)
types=scratch/'node_modules/@types'
types.mkdir(exist_ok=True)
if not (types/'node').exists(): os.symlink(root/'packages/core/tool-definition/node_modules/@types/node',types/'node')
(scratch/'package.json').write_text(json.dumps({'private':True,'type':'module'},indent=2)+'\n')
base={'extends':'../../../tsconfig.base.json','compilerOptions':{'skipLibCheck':False,'resolveJsonModule':True,'declaration':False,'declarationMap':False,'sourceMap':False,'rootDir':'examples','outDir':'compiled'},'files':[f"examples/{item['file']}" for item in manifest if not item['pending']]}
(scratch/'tsconfig.json').write_text(json.dumps(base,indent=2)+'\n')
(scratch/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(f'{len(manifest)} bilingual-identical examples extracted; 17 current entries, 1 pending final Skill /v2 entry')
