from pathlib import Path
import json, subprocess, hashlib, os, re
root=Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
scratch=root/'tmp/core-delivery/readmes-a-current'
data=json.loads((scratch/'examples.json').read_text())
for name in data:
 if not (root/'packages/core'/name/'dist/index.js').exists():
  raise SystemExit(f'MISSING DIST: {name}; no build attempted')
modules=scratch/'node_modules'
(modules/'@omne-harness-lite').mkdir(parents=True,exist_ok=True)
for member in (root/'packages/core').iterdir():
 if (member/'package.json').exists():
  link=modules/'@omne-harness-lite'/member.name
  if not link.exists(): link.symlink_to(member, target_is_directory=True)
for dest,source in [('@deepseek-ai/cordis','packages/core/kernel-basis/node_modules/@deepseek-ai/cordis'),('zod','packages/core/kernel-basis/node_modules/zod'),('@types/node','packages/core/content-blocks/node_modules/@types/node')]:
 link=modules/dest
 link.parent.mkdir(parents=True,exist_ok=True)
 if not link.exists(): link.symlink_to(root/source, target_is_directory=True)
(scratch/'package.json').write_text(json.dumps({'private':True,'type':'module'}))
inputs=scratch/'inputs'
inputs.mkdir(exist_ok=True)
records=[]
for name,value in data.items():
 english=(root/'packages/core'/name/'README.md').read_text()
 chinese=(root/'packages/core'/name/'README_ZH.md').read_text()
 code=re.findall(r'```ts\n(.*?)\n```',english,re.S)
 counterpart=re.findall(r'```ts\n(.*?)\n```',chinese,re.S)
 if code!=counterpart or len(code)!=len(value['examples']): raise SystemExit(f'Bilingual code mismatch: {name}')
 for index,item in enumerate(value['examples'],1):
  p=inputs/f'{name}-{index}.ts'
  p.write_text(code[index-1]+'\n')
  records.append({'package':name,'example':index,'input':str(p.relative_to(scratch)),'title':item['en']})
config={'extends':str(root/'tsconfig.base.json'),'compilerOptions':{'outDir':'./compiled','rootDir':'./inputs','declaration':False,'declarationMap':False,'sourceMap':False,'skipLibCheck':False},'include':['inputs/*.ts']}
(scratch/'tsconfig.json').write_text(json.dumps(config,indent=2)+'\n')
def run(cmd,log):
 result=subprocess.run(cmd,cwd=scratch,text=True,capture_output=True)
 (scratch/log).write_text('$ '+ ' '.join(cmd)+'\nexit: '+str(result.returncode)+'\nstdout:\n'+result.stdout+'\nstderr:\n'+result.stderr)
 return result
compiler=str(root/'packages/core/content-blocks/node_modules/.bin/tsc')
typed=run([compiler,'--project','tsconfig.json'],'typecheck.log')
print('STRICT TYPECHECK', typed.returncode)
print(typed.stdout)
if typed.returncode:
 (scratch/'results.json').write_text(json.dumps({'typecheck':typed.returncode,'records':records},indent=2)+'\n')
 raise SystemExit(typed.returncode)
for record in records:
 file=record['input'].replace('inputs/','compiled/').replace('.ts','.js')
 log=f"{record['package']}-{record['example']}.log"
 result=run(['node',file],log)
 record.update(exit=result.returncode,log=log,stdout=result.stdout,stderr=result.stderr)
 print(record['package'],record['example'],'PASS' if result.returncode==0 else 'FAIL')
 if result.returncode: print(result.stderr)
versions=run(['node','--version'],'node-version.log')
known={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'node':versions.stdout.strip(),'compiler':subprocess.check_output([compiler,'--version'],cwd=scratch,text=True).strip(),'typecheck':typed.returncode,'records':records,'dist_sha256':{},'readme_sha256':{}}
for name in data:
 for file in ['dist/index.js','dist/index.d.ts']:
  path=root/'packages/core'/name/file
  known['dist_sha256'][str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
 for file in ['README.md','README_ZH.md']:
  path=root/'packages/core'/name/file
  known['readme_sha256'][str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
(scratch/'results.json').write_text(json.dumps(known,ensure_ascii=False,indent=2)+'\n')
raise SystemExit(0 if all(r['exit']==0 for r in records) else 1)
