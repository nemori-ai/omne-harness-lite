import { narrow, type Storage } from '@omne-harness-lite/storage'

interface Tables {
  counters: { id: string; value: number }
}
export async function increment(storage: Storage, id: string): Promise<number> {
  return storage.write(async tx => {
    await tx.lockRow('counters', { id })
    const db = narrow<Tables>(tx)
    const row = await db
      .selectFrom('counters')
      .select('value')
      .where('id', '=', id)
      .executeTakeFirstOrThrow()
    const next = row.value + 1
    await db.updateTable('counters').set({ value: next }).where('id', '=', id).execute()
    return next
  })
}
