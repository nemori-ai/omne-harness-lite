import { LosslessNumber } from '@omne-harness-lite/content-blocks'
import { effectiveCost, prepareAccountGroup, summarize } from '@omne-harness-lite/call-accounts'

const cost = { cost_usd: new LosslessNumber('0.1'), source: 'upstream_usage' } as const
const usage = {
  input_tokens: 10,
  output_tokens: 2,
  cache_read_tokens: 0,
  cache_write_tokens: 0,
  source: 'upstream',
} as const
const corrections = [
  {
    sessionLog: 'session_1',
    correction: {
      target: { kind: 'model_response', responseId: 'response_1' },
      cost_usd: new LosslessNumber('0.3'),
      obtainedVia: 'manual',
      at: '2026-09-26T12:00:00Z',
    },
  },
] as const
const admitted = prepareAccountGroup({
  models: [{ responseId: 'response_1', cost, usage }],
  tools: [],
  corrections,
})
if ('rejected' in admitted) throw new Error(admitted.rejected)
const summary = summarize(admitted.ok)
if ('failed' in summary) throw new Error(summary.failed)
console.log(summary.knownSum.toString(), summary.unknownCount) // 0.3 0
const effective = effectiveCost(
  { kind: 'model_response', responseId: 'response_1', cost },
  corrections,
)
if ('ok' in effective)
  console.log(effective.ok.source) // later_correction
else throw new Error('cost evaluation failed')
