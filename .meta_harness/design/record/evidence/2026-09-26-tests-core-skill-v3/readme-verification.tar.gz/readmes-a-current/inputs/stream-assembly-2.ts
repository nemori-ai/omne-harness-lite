import { start, accept, closeOut, type AssemblyState } from '@omne-harness-lite/stream-assembly'

const initial = start({ kind: 'model_call', callId: 'model_call_1', dispatch: 1 })
if ('rejected' in initial) throw new Error(initial.rejected)
let state: AssemblyState = initial.ok
for (const event of [
  {
    t: 'open',
    index: 0,
    id: 'block_1',
    kind: 'tool_call',
    fill: 'append',
    visibility: { toHuman: true, toModel: true },
    head: { callId: 'call_1', tool: 'lookup' },
  },
  { t: 'fill', index: 0, payload: '{"x":1,"x":2}' },
  { t: 'close', index: 0 },
  { t: 'finish', reason: 'end' },
]) {
  const next = accept(state, event)
  if ('rejected' in next) throw new Error(next.rejected)
  state = next.ok
}
const result = closeOut(state)
if ('rejected' in result) throw new Error(result.rejected)
const call = result.ok.blocks[0]
if (call?.kind !== 'tool_call' || !call.complete || !('unparseable' in call))
  throw new Error('expected unparseable call')
console.log(call.unparseable, call.rawArguments) // true {"x":1,"x":2}
