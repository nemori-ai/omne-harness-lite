import {
  acceptable,
  deriveState,
  instantFromRfc3339,
  instantToRfc3339,
  parseOfferTtl,
  timingFrom,
} from '@omne-harness-lite/offer-expiry'

const issued = instantFromRfc3339('2026-09-26T10:00:00Z')
const ttl = parseOfferTtl('PT1H')
if (!('ok' in issued) || !('ok' in ttl)) throw new Error('invalid timing input')
const timing = timingFrom(issued.ok, ttl.ok)
if (timing === 'unavailable' || !('ok' in timing)) throw new Error('timing construction failed')
const state = deriveState({
  timing: timing.ok,
  settled: null,
  now: timing.ok.expiresAt,
  target: 'exists',
})
console.log(instantToRfc3339(timing.ok.expiresAt)) // 2026-09-26T11:00:00.000Z
console.log(state) // pending: equality at the deadline is still acceptable
if (state !== 'unavailable') console.log(acceptable(state)) // true
