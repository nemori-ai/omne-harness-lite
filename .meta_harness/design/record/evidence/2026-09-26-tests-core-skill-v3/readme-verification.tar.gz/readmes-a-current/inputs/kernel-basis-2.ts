import { fail, isSuccess, succeed, type Outcome } from '@omne-harness-lite/kernel-basis'

function lookup(available: boolean): Outcome<string, 'unavailable'> {
  return available ? succeed('ready') : fail('unavailable')
}
const result = lookup(false)
if (isSuccess(result)) console.log(result.ok)
else console.log(result.failure) // unavailable
