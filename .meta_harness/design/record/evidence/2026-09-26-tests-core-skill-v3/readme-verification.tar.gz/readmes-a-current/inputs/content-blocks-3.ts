import { LosslessNumber } from '@omne-harness-lite/content-blocks'
import { createSchemaRuntime } from '@omne-harness-lite/content-blocks/schema-runtime'

const runtime = createSchemaRuntime([])
const validator = runtime.compile({
  type: 'integer',
  minimum: new LosslessNumber('9007199254740993'),
})
console.log(validator.validate(new LosslessNumber('9007199254740992'))) // false
console.log(validator.validate(new LosslessNumber('9007199254740993'))) // true
console.log(validator.validate(new LosslessNumber('1.00000000000000000001'))) // false
