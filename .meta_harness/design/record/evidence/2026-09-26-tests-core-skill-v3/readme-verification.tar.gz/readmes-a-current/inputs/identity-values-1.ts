import {
  isOk,
  parseTenantId,
  tenantIdEquals,
  toCanonicalJson,
} from '@omne-harness-lite/identity-values'

const first = parseTenantId({ organization: 'org_1', account: 'acct_1' })
const second = parseTenantId({ account: 'acct_1', organization: 'org_1' })
if (!isOk(first) || !isOk(second)) throw new Error('invalid tenant input')
console.log(tenantIdEquals(first.ok, second.ok)) // true
console.log(toCanonicalJson(first.ok)) // {"organization":"org_1","account":"acct_1"}

const invalid = parseTenantId({ organization: 'org_1', account: 'acct_1', role: 'member' })
if ('invalidInput' in invalid) console.log('rejected extra member')
