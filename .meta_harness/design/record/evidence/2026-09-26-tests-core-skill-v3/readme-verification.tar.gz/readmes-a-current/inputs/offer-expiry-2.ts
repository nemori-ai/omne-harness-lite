import { deriveState, parseOfferTiming } from '@omne-harness-lite/offer-expiry'

const parsed = parseOfferTiming({
  issuedAt: '2026-09-26T10:00:00Z',
  expiresAt: '2026-09-26T11:00:00Z',
})
if (!('ok' in parsed)) throw new Error(parsed.invalidInput)
console.log(
  deriveState({
    timing: parsed.ok,
    settled: 'declined',
    now: 'unavailable',
    target: 'unavailable',
  }),
)
// declined
console.log(deriveState({ timing: parsed.ok, settled: null, now: 'unavailable', target: 'absent' }))
// unavailable
console.log(
  deriveState({ timing: parsed.ok, settled: null, now: parsed.ok.issuedAt, target: 'absent' }),
)
// expired
