import {
  start,
  accept,
  snapshot,
  closeOut,
  type AssemblyState,
} from '@omne-harness-lite/stream-assembly'

import { jsonNumberSource } from '@omne-harness-lite/content-blocks'

const initial = start({ kind: 'model_call', callId: 'model_call_1', dispatch: 1 })
if ('rejected' in initial) throw new Error(initial.rejected)
let state: AssemblyState = initial.ok
const events = [
  {
    t: 'open',
    index: 0,
    id: 'block_1',
    kind: 'text',
    fill: 'append',
    visibility: { toHuman: true, toModel: true },
  },
  { t: 'fill', index: 0, payload: 'Hello' },
  {
    t: 'close',
    index: 0,
    block: {
      kind: 'text',
      id: 'block_1',
      visibility: { toHuman: true, toModel: true },
      text: 'Hello',
    },
  },
  { t: 'finish', reason: 'end' },
]
for (const event of events) {
  const next = accept(state, event)
  if ('rejected' in next) throw new Error(next.rejected)
  state = next.ok
}
console.log(jsonNumberSource(snapshot(state).position)) // 4
console.log(snapshot(initial.ok).position) // 0: previous states remain usable
const settled = closeOut(state)
if ('rejected' in settled) throw new Error(settled.rejected)
console.log(settled.ok.blocks[0]?.kind, settled.ok.ending.reason) // text end
if ('usage' in settled.ok.account) console.log(settled.ok.account.usage.source) // none: no reported account
