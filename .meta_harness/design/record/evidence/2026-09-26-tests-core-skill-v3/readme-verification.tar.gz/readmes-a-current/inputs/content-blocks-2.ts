import {
  judgeContentBlock,
  toOpaqueJson,
  writeJsonLossless,
  LosslessNumber,
} from '@omne-harness-lite/content-blocks'

const result = judgeContentBlock({
  kind: 'thinking',
  id: 'b_1',
  visibility: { toHuman: false, toModel: true },
  text: 'Considering the request',
  opaque: toOpaqueJson({ vendor: 'token', n: new LosslessNumber('1.10') }),
})
if ('rejected' in result) throw new Error(result.rejected)
console.log(Object.isFrozen(result.ok)) // true
console.log(writeJsonLossless(result.ok)) // includes "opaque":{"vendor":"token","n":1.10}
console.log(judgeContentBlock({ kind: 'text', id: 'b_2', text: 'Hello' }))
// { rejected: 'visibility_missing' }
