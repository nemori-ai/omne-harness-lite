import { composeMigrations } from '@omne-harness-lite/storage';
const fragments = [
    {
        name: 'counter-table',
        migration: {
            async up(db) {
                await db.schema
                    .createTable('counters')
                    .addColumn('id', 'text', column => column.primaryKey())
                    .addColumn('value', 'integer', column => column.notNull())
                    .execute();
            },
        },
    },
];
const provider = composeMigrations(fragments);
console.log(Object.keys(await provider.getMigrations())); // ['0001_counter-table']
