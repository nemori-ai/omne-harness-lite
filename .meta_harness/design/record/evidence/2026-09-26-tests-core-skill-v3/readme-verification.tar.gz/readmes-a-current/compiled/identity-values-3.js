import { handoffWarrant, parseAccountId, unwrap } from '@omne-harness-lite/identity-values';
const account = unwrap(parseAccountId('acct_1'));
const other = unwrap(parseAccountId('acct_2'));
const pem = handoffWarrant.generateKeyPair();
const signing = handoffWarrant.loadSigningKey(pem.privateKeyPem);
const verification = handoffWarrant.loadVerificationKey(pem.publicKeyPem);
if (!('ok' in signing) || !('ok' in verification))
    throw new Error('invalid key configuration');
const warrant = handoffWarrant.issue(signing.ok, 'activation', account);
console.log(handoffWarrant.verify(verification.ok, 'activation', account, warrant)); // ok
console.log(handoffWarrant.verify(verification.ok, 'activation', other, warrant)); // invalid
console.log(handoffWarrant.verify(verification.ok, 'purge', account, warrant)); // invalid
