import { isStandardBase64, reduceFills } from '@omne-harness-lite/arrival-events';
console.log(reduceFills({ kind: 'text', fill: 'append' }, ['Hello, ', 'Ada'])); // Hello, Ada
console.log(reduceFills({ kind: 'tool_call', fill: 'append' }, ['{"x":', '1}'])); // {"x":1}
console.log(reduceFills({ kind: 'voice', fill: 'append' }, ['AQ==', 'Ag=='])); // AQI=
console.log(reduceFills({ kind: 'text', fill: 'replace' }, ['old', 'new'])); // new
console.log(reduceFills({ kind: 'text', fill: 'append' }, [])); // undefined
console.log(isStandardBase64('AQ==')); // true
console.log(isStandardBase64('AR==')); // false: nonzero unused tail bits
