import { start, accept, snapshot, closeOut, abandon } from '@omne-harness-lite/stream-assembly';
const initial = start({ kind: 'tool_execution', callId: 'call_1' });
if ('rejected' in initial)
    throw new Error(initial.rejected);
console.log(closeOut(initial.ok)); // { rejected: 'stream_not_finished' }
console.log(accept(initial.ok, { t: 'fill', index: 0, payload: 'Hello' }));
// { rejected: 'block_not_open' }
console.log(snapshot(initial.ok).position); // 0: refused input has no effect
const lost = abandon(initial.ok);
if ('rejected' in lost)
    throw new Error(lost.rejected);
console.log(lost.ok.ending.reason); // lost
const finished = accept(initial.ok, { t: 'finish', reason: 'end' });
if ('rejected' in finished)
    throw new Error(finished.rejected);
console.log(accept(finished.ok, { t: 'unknown' })); // { rejected: 'event_unknown' }
console.log(accept(finished.ok, { t: 'fill', index: 0, payload: 'late' }));
// { rejected: 'event_after_finish' }
