import { summarizeUsage } from '@omne-harness-lite/call-accounts';
const summary = summarizeUsage([
    {
        responseId: 'response_1',
        usage: {
            input_tokens: 10,
            output_tokens: 2,
            cache_read_tokens: 0,
            cache_write_tokens: 0,
            source: 'upstream',
        },
    },
    {
        responseId: 'response_2',
        usage: {
            input_tokens: 'unknown',
            output_tokens: 'unknown',
            cache_read_tokens: 'unknown',
            cache_write_tokens: 'unknown',
            source: 'none',
        },
    },
]);
if ('rejected' in summary || 'failed' in summary)
    throw new Error('usage evaluation failed');
console.log(summary.input_tokens.knownSum.toString()); // 10
console.log(summary.input_tokens.unknownCount); // 1
