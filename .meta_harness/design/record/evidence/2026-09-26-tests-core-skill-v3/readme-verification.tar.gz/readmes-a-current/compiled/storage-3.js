import { mapStorageError, StorageDefect, StorageUnavailable } from '@omne-harness-lite/storage';
console.log(mapStorageError(new StorageUnavailable('offline'), 'storage-unavailable'));
// { failure: 'storage-unavailable' }
const defect = new StorageDefect('unknown column');
try {
    mapStorageError(defect, 'storage-unavailable');
}
catch (error) {
    console.log(error === defect); // true: the original defect is rethrown
}
