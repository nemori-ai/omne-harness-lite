import { z } from 'zod';
import { definePlugin, resolveOptional } from '@omne-harness-lite/kernel-basis';
import { bootAssembly } from '@omne-harness-lite/kernel-basis/testing';
const plugin = definePlugin({
    name: 'uses-settings',
    inject: ['settings'],
    Config: z.object({}),
    apply(ctx) {
        const settings = resolveOptional(ctx, 'settings');
        if (settings === undefined)
            throw new Error('settings unavailable');
        ctx.provide('message', settings.greeting);
    },
});
const assembly = await bootAssembly({
    services: [{ name: 'settings', value: { greeting: 'Hello' } }],
    plugins: [{ plugin, config: {} }],
});
try {
    console.log(resolveOptional(assembly.ctx, 'message')); // Hello
}
finally {
    await assembly.dispose();
}
