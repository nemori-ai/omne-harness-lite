import { readJsonStrict, writeJsonLossless } from '@omne-harness-lite/content-blocks';
const source = '{"large":9007199254740993,"price":1.10,"huge":1e400,"zero":-0}';
const read = readJsonStrict(source);
if ('failed' in read)
    throw new Error(read.failed);
console.log(writeJsonLossless(read.ok) === source); // true
console.log(readJsonStrict('{"x":1,"\u0078":2}')); // { failed: 'duplicate_member' }
