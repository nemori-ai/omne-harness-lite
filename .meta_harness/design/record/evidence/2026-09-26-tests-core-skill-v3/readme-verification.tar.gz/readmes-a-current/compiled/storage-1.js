import { narrow } from '@omne-harness-lite/storage';
export async function increment(storage, id) {
    return storage.write(async (tx) => {
        await tx.lockRow('counters', { id });
        const db = narrow(tx);
        const row = await db
            .selectFrom('counters')
            .select('value')
            .where('id', '=', id)
            .executeTakeFirstOrThrow();
        const next = row.value + 1;
        await db.updateTable('counters').set({ value: next }).where('id', '=', id).execute();
        return next;
    });
}
