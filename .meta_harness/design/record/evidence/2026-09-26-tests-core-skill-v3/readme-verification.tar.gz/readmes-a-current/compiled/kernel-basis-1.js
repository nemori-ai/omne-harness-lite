import { Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
import { definePlugin, fiberIsActive, resolveOptional } from '@omne-harness-lite/kernel-basis';
const greeting = definePlugin({
    name: 'greeting',
    Config: z.object({ prefix: z.string().min(1) }),
    apply(ctx, config) {
        ctx.provide('greeting', { greet: (name) => `${config.prefix}, ${name}` });
    },
});
const ctx = new Context();
const fiber = ctx.plugin(greeting, { prefix: 'Hello' });
try {
    await fiber;
    const service = resolveOptional(ctx, 'greeting');
    if (service === undefined)
        throw new Error('greeting unavailable');
    console.log(service.greet('Ada')); // Hello, Ada
    console.log(fiberIsActive(fiber.ctx)); // true
}
finally {
    await fiber.dispose();
}
console.log(resolveOptional(ctx, 'greeting')); // undefined
