import { LosslessNumber, writeJsonLossless } from '@omne-harness-lite/content-blocks';
import { ExactDecimal, judgeAccountValue } from '@omne-harness-lite/call-accounts';
const total = ExactDecimal.from(new LosslessNumber('0.1')).add(ExactDecimal.from(new LosslessNumber('0.2')));
console.log(total.compare(ExactDecimal.from(new LosslessNumber('0.3')))); // 0
console.log(writeJsonLossless({ cost_usd: total.toJsonNumber() })); // {"cost_usd":0.3}
console.log(judgeAccountValue('Cost', { cost_usd: 'unknown', source: 'upstream_usage' }));
// { rejected: 'unknown_with_source' }
