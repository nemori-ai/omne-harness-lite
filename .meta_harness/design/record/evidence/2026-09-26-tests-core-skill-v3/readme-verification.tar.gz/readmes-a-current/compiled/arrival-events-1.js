import { judgeArrivalEnvelope, judgeArrivalEnvelopeText } from '@omne-harness-lite/arrival-events';
console.log(judgeArrivalEnvelope({
    target: { kind: 'model_call', callId: 'model_call_1', dispatch: 1 },
    event: {
        t: 'open',
        index: 0,
        id: 'block_1',
        kind: 'text',
        fill: 'append',
        visibility: { toHuman: true, toModel: true },
    },
})); // { ok: true }
console.log(judgeArrivalEnvelopeText(JSON.stringify({
    target: { kind: 'tool_execution', callId: 'call_1' },
    event: {
        t: 'open',
        index: 0,
        id: 'block_2',
        kind: 'text',
        fill: 'append',
        visibility: { toHuman: true, toModel: false },
    },
}))); // { ok: true }
console.log(judgeArrivalEnvelope({
    target: { kind: 'model_call', callId: 'model_call_1', dispatch: 1 },
    event: {
        t: 'open',
        index: 1,
        id: 'block_3',
        kind: 'image',
        fill: 'append',
        visibility: { toHuman: true, toModel: true },
    },
})); // { rejected: 'fill_kind_not_appendable' }
