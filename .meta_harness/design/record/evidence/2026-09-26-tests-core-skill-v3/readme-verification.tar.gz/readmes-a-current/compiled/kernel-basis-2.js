import { fail, isSuccess, succeed } from '@omne-harness-lite/kernel-basis';
function lookup(available) {
    return available ? succeed('ready') : fail('unavailable');
}
const result = lookup(false);
if (isSuccess(result))
    console.log(result.ok);
else
    console.log(result.failure); // unavailable
