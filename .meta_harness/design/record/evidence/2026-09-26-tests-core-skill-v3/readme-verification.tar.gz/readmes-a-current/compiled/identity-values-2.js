import { ancestorChain, parseOrganizationId, shareAncestor, unwrap, } from '@omne-harness-lite/identity-values';
const root = unwrap(parseOrganizationId('root'));
const child = unwrap(parseOrganizationId('child'));
const parentOf = (id) => (id === child ? root : id === root ? null : 'unavailable');
console.log(ancestorChain(child, parentOf)); // { ok: ['root'] }
console.log(shareAncestor(child, root, parentOf)); // { ok: true }
console.log(ancestorChain(child, () => 'unavailable')); // { failure: 'unavailable' }
