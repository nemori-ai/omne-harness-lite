# README group A delivery evidence

Known: worktree `/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery`, branch `panqiwei/core-delivery`, baseline `45c1b504ea7da5ff49042c6ecee3e489f76b2042`; Node `v24.18.0`, TypeScript `Version 6.0.3`.

Known: only the assigned packages' `README.md` and `README_ZH.md` are product-tree writes. No package implementation, manifest, lock, design, tool source, index, commit or build was changed. Temporary inputs and logs remain in this exclusive scratch directory.

Known: 25 unique TypeScript examples extracted from the actual formatted English READMEs; the Chinese code blocks are byte-identical. Strict typecheck passed with `exactOptionalPropertyTypes`, `noUncheckedIndexedAccess`, `isolatedModules`, and `skipLibCheck: false`. All 25 emitted inputs executed on the existing package `dist` with exit 0 and empty stderr. The expected stdout of every example matched the preserved hand-written output oracle.

Known: local links in all 18 READMEs exist, there are no private `.meta_harness` links, and Prettier final check passes. Initial formatting warnings were corrected; their original check output is preserved.

Assumed: documentation consumers have built the workspace and declared every directly imported package. Examples use explicit known demo identity/time literals; they do not establish external authorization or clock facts.

Unknown / unverified: storage example 1 exports a typed provider-injected `increment` function and is compiled/loaded but not called against a database. The README states its required provider, table and existing-row preconditions. No storage durability, live DB transaction, production transport, model request, tool execution or publication is claimed. Other 24 examples exercise their public operations directly.

| Package | Examples | Main use cases |
| --- | --- | --- |
| `identity-values` | 3 | tenant parse/equality, ancestry snapshot, signed warrants |
| `kernel-basis` | 3 | real Cordis plugin lifetime, typed outcome, test assembly |
| `storage` | 3 | typed consumer function, migration composition, availability-only mapping |
| `offer-expiry` | 2 | timing/deadline, settlement and unavailable precedence |
| `content-blocks` | 3 | lossless JSON/duplicates, immutable opaque block, exact Schema runtime |
| `call-accounts` | 3 | exact arithmetic, admitted group/correction, model usage unknown count |
| `messages` | 3 | strict message reception, complete-prefix compaction/readability, invocation record |
| `arrival-events` | 2 | model/tool representation, text/raw argument/audio reduction |
| `stream-assembly` | 3 | all five public operations, raw tool sealing, refusal precedence and lost continuity |

Evidence: `inputs/*.ts`, `compiled/*.js`, `tsconfig.json`, `typecheck.log`, package-example logs, `expected-stdout.json`, `output-oracle.log`, `local-links.log`, `format-*.log`, and `results.json` (environment, per-example inputs/output, built entry/readme hashes).

No self-acceptance is made; integration review remains with the root dispatcher.
