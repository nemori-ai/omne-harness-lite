import assert from 'node:assert/strict'
import { StorageSqlConfig } from '@omne-harness-lite/storage-sql'

const config: StorageSqlConfig = {
  dialect: 'postgres',
  connectionString: 'postgresql://example@127.0.0.1:5432/example',
}
assert.equal(StorageSqlConfig.safeParse(config).success, true)
console.log(config.dialect)
