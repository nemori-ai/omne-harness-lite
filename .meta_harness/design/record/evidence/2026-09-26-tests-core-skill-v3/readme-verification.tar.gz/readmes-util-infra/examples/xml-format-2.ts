import assert from 'node:assert/strict'
import { formatXml, type XmlSchema } from '@omne-harness-lite/xml-format'

const schema: XmlSchema = {
  tag: 'report',
  requiredFields: {
    asOf: { presentation: 'attr', xmlName: 'as_of' },
    tags: { itemTag: 'tag' },
  },
}
const xml = formatXml(
  {
    asOf: new Date('2026-09-26T12:00:00Z'),
    tags: ['ready', 'R&D'],
  },
  schema,
)
assert.ok(xml.includes('as_of="2026-09-26T12:00:00.000Z"'))
assert.ok(xml.includes('<tag>R&amp;D</tag>'))
console.log(xml)
