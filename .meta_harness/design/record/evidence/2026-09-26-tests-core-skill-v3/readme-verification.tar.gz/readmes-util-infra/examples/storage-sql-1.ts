import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import type { MigrationProvider } from 'kysely/migration'
import { StorageUnavailable, narrow } from '@omne-harness-lite/storage'
import { openStorage, type SqlStorage } from '@omne-harness-lite/storage-sql'

interface Tables {
  notes: { id: string; title: string }
}
const migrations: MigrationProvider = {
  async getMigrations() {
    return {
      '0001_notes': {
        async up(db) {
          await db.schema
            .createTable('notes')
            .ifNotExists()
            .addColumn('id', 'text', c => c.primaryKey())
            .addColumn('title', 'text', c => c.notNull())
            .execute()
        },
      },
    }
  },
}
const directory = await mkdtemp(join(tmpdir(), 'omne-sql-example-'))
let storage: SqlStorage | undefined
try {
  const db = await openStorage({
    dialect: 'sqlite',
    file: join(directory, 'notes.sqlite'),
    migrations,
    upgrade: false,
  })
  storage = db
  let notified = false
  await db.atomic(async unit => {
    unit.assertStorage(db)
    await unit.mutate(async tx => {
      await narrow<Tables>(tx).insertInto('notes').values({ id: 'n1', title: 'Draft' }).execute()
    })
    await unit.run(async () => {
      await unit.mutate(async tx => {
        await narrow<Tables>(tx)
          .updateTable('notes')
          .set({ title: 'Ready' })
          .where('id', '=', 'n1')
          .execute()
      })
    })
    unit.afterCommit(() => {
      notified = true
    })
  })
  assert.equal(notified, true)
  const abort = new Error('cancel this write')
  await assert.rejects(
    db.write(async tx => {
      await narrow<Tables>(tx)
        .updateTable('notes')
        .set({ title: 'Discarded' })
        .where('id', '=', 'n1')
        .execute()
      throw abort
    }),
    error => error === abort,
  )
  const note = await db.read(async tx =>
    narrow<Tables>(tx)
      .selectFrom('notes')
      .select(['id', 'title'])
      .where('id', '=', 'n1')
      .executeTakeFirstOrThrow(),
  )
  assert.equal(note.title, 'Ready')
  console.log(note.title)
  await db.close()
  await assert.rejects(
    db.read(async () => 1),
    StorageUnavailable,
  )
} finally {
  await storage?.close()
  await rm(directory, { recursive: true, force: true })
}
