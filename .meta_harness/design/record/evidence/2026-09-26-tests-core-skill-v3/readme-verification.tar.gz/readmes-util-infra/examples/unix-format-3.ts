import assert from 'node:assert/strict'
import { formatError, formatHold, formatNumberedLines } from '@omne-harness-lite/unix-format'

const excerpt = formatNumberedLines(['alpha', '😀beta'], {
  start: 41,
  perLineCharLimit: 3,
})
assert.equal(excerpt, '    41 | alp [truncated]\n    42 | 😀be [truncated]')
console.log(excerpt)
console.log(formatError('Note was not found', { hint: 'Run list first' }))
console.log(formatHold('Choose a note', { steps: ['List notes', 'Read its ID'] }))
