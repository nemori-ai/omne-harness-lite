import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Context, type Fiber } from '@deepseek-ai/cordis'
import { CLOCK_SERVICE, clockMigrations, clockPlugin } from '@omne-harness-lite/clock'
import type { Clock } from '@omne-harness-lite/offer-expiry'
import { composeMigrations } from '@omne-harness-lite/storage'
import { createUpgradeGuard, storageSqlPlugin } from '@omne-harness-lite/storage-sql'

const directory = await mkdtemp(join(tmpdir(), 'omne-clock-plugin-example-'))
const ctx = new Context()
const guard = createUpgradeGuard()
let storageFiber: Fiber | undefined
let clockFiber: Fiber | undefined
try {
  storageFiber = ctx.plugin(storageSqlPlugin, {
    dialect: 'sqlite',
    file: join(directory, 'clock.sqlite'),
    migrations: composeMigrations(clockMigrations),
    upgrade: { checks: [], guard },
  })
  await storageFiber
  clockFiber = ctx.plugin(clockPlugin, {})
  await clockFiber
  const clock = ctx.get(CLOCK_SERVICE) as Clock | undefined
  assert.ok(clock)
  const now = clock.now()
  assert.notEqual(now, 'unavailable')
  const confirmation = await guard.confirm()
  assert.ok(!confirmation.snapshotTaken || confirmation.snapshotRemoved)
  console.log(now)
} finally {
  await clockFiber?.dispose()
  await storageFiber?.dispose()
  // Cordis logs disposer failures; retain the fixture if recovery is pending.
  assert.equal(await guard.pending(), 'clear')
  await rm(directory, { recursive: true, force: true })
}
