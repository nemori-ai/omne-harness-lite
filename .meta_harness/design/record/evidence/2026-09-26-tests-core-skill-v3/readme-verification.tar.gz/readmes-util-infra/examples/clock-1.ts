import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { LeaseClock, clockMigrations, type TimeSources } from '@omne-harness-lite/clock'
import { composeMigrations } from '@omne-harness-lite/storage'
import { openStorage, type SqlStorage } from '@omne-harness-lite/storage-sql'

const directory = await mkdtemp(join(tmpdir(), 'omne-clock-example-'))
let storage: SqlStorage | undefined
let clock: LeaseClock | undefined
let wall = 1_900_000_000_000
const sources: TimeSources = { wall: () => wall, monotonic: () => 0n }
try {
  storage = await openStorage({
    dialect: 'sqlite',
    file: join(directory, 'clock.sqlite'),
    migrations: composeMigrations(clockMigrations),
    upgrade: false,
  })
  clock = new LeaseClock({ storage, sources })
  assert.equal(clock.now(), 'unavailable')
  await clock.start()
  assert.equal(clock.now(), wall)
  wall -= 100
  assert.equal(clock.now(), 'unavailable')
  wall += 100
  assert.equal(clock.now(), wall)
  console.log(clock.now())
} finally {
  await clock?.close()
  await storage?.close()
  await rm(directory, { recursive: true, force: true })
}
