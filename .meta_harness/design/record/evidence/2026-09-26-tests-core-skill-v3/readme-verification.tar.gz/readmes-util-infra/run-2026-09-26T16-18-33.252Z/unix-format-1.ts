import assert from 'node:assert/strict'
import {
  formatCommandList,
  formatSection,
  formatUsage,
} from '@omne-harness-lite/unix-format'

const commands = formatCommandList([
  ['list', '{}', 'List saved notes'],
  ['read', '{id}', 'Read one note'],
])
const help = formatSection(
  'NOTES',
  `${formatUsage('notes', 'read', '{id}')}\n${commands}`,
  { markdownCompatible: false, indent: 2 },
)
assert.ok(help.startsWith('NOTES:\n  USAGE: notes(command="read", params={id})'))
console.log(help)
