import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Context, type Fiber } from '@deepseek-ai/cordis'
import { sql } from 'kysely'
import {
  STORAGE_SERVICE,
  createUpgradeGuard,
  storageSqlPlugin,
  type SqlStorage,
} from '@omne-harness-lite/storage-sql'

const directory = await mkdtemp(join(tmpdir(), 'omne-sql-owner-example-'))
const ctx = new Context()
const guard = createUpgradeGuard()
let fiber: Fiber | undefined
try {
  fiber = ctx.plugin(storageSqlPlugin, {
    dialect: 'sqlite', file: join(directory, 'owned.sqlite'),
    synchronous: 'full',
    migrations: { getMigrations: async () => ({}) },
    upgrade: { checks: [], guard },
  })
  await fiber
  const storage = ctx.get(STORAGE_SERVICE) as SqlStorage | undefined
  assert.ok(storage)
  const rows = await storage.read(async tx =>
    (await sql<{ ready: number }>`SELECT 1 AS ready`.execute(tx.db)).rows)
  assert.equal(rows[0]?.ready, 1)
  const confirmation = await guard.confirm()
  assert.ok(!confirmation.snapshotTaken || confirmation.snapshotRemoved)
  console.log(confirmation)
} finally {
  await fiber?.dispose()
  // Cordis logs disposer failures; retain the fixture if recovery is pending.
  assert.equal(await guard.pending(), 'clear')
  await rm(directory, { recursive: true, force: true })
}
