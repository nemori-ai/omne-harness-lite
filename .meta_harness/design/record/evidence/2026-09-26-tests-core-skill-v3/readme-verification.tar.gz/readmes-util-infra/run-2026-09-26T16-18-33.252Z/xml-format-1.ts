import assert from 'node:assert/strict'
import { formatXml, type XmlSchema } from '@omne-harness-lite/xml-format'

const schema: XmlSchema = {
  tag: 'note',
  requiredFields: {
    id: { presentation: 'attr' },
    title: { presentation: 'element' },
  },
  optionalFields: {
    priority: { presentation: 'attr', includeWhen: 'not_nullish' },
  },
}
const xml = formatXml(
  { id: 'n"1', title: 'Tea & <biscuits>', priority: 0, internal: 'omitted' },
  schema,
  { extraFields: ['priority'] },
)
assert.equal(xml, '<note id="n&quot;1" priority="0">\n  <title>\n    Tea &amp; &lt;biscuits&gt;\n  </title>\n</note>')
console.log(xml)
