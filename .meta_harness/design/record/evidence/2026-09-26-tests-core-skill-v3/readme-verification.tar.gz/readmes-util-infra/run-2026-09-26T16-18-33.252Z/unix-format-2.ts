import assert from 'node:assert/strict'
import { formatKeyValue, formatTable } from '@omne-harness-lite/unix-format'

const table = formatTable(
  ['ID', 'Description'],
  [['a', 'A much longer description']],
  { maxWidth: 18 },
)
assert.ok(table.includes('A much long...'))
console.log(table)

const metadata = formatKeyValue(new Map([
  ['10', 'ten'],
  ['2', 'two'],
]))
assert.equal(metadata, '10: ten\n2 : two')
console.log(metadata)
