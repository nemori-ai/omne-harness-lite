import assert from 'node:assert/strict'
import {
  formatXml,
  isXmlFormattable,
  type XmlFormattable,
} from '@omne-harness-lite/xml-format'

// The caller supplies and owns the validity of this raw XML fragment.
const reference: XmlFormattable = {
  toXml: () => '<reference id="ref-1"/>',
}
assert.equal(isXmlFormattable(reference), true)
const xml = formatXml({ reference }, {
  tag: 'note',
  requiredFields: { reference: {} },
})
assert.equal(xml, '<note>\n  <reference id="ref-1"/>\n</note>')
console.log(xml)
