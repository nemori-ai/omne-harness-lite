from pathlib import Path
import sys

root = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
sys.path.insert(0, str(root / 'tools/spec-tools/src'))
from omne_harness_lite_spec_tools.doc_support import markdown_links, validate_link

packages = ['packages/util/unix-format', 'packages/util/xml-format',
            'packages/infra/clock', 'packages/infra/storage-sql']
count = 0
for package in packages:
    for name in ['README.md', 'README_ZH.md']:
        path = root / package / name
        assert '.meta_harness' not in path.read_text()
        for link in markdown_links(path):
            validate_link(path, link, root)
            count += 1
print(f'PASS: 8 assigned README files; {count} local links; no private-workspace dependency.')
