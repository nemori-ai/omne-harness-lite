import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readdirSync, readFileSync, symlinkSync, writeFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { spawnSync } from 'node:child_process'

const root = '/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery'
const scratch = join(root, 'tmp/core-delivery/readmes-util-infra')
const output = join(scratch, 'run-' + new Date().toISOString().replaceAll(':', '-'))
mkdirSync(output, { recursive: true })
mkdirSync(join(scratch, 'examples'), { recursive: true })
writeFileSync(join(scratch, 'package.json'), JSON.stringify({ private: true, type: 'module' }, null, 2))
const packages = [
  'packages/util/unix-format', 'packages/util/xml-format',
  'packages/infra/clock', 'packages/infra/storage-sql',
]
const inputs = [...packages, 'packages/core/storage', 'packages/core/kernel-basis', 'packages/core/offer-expiry']
const link = (target, path) => {
  mkdirSync(dirname(path), { recursive: true })
  if (!existsSync(path)) symlinkSync(target, path, 'dir')
}
for (const relative of inputs) {
  const info = JSON.parse(readFileSync(join(root, relative, 'package.json'), 'utf8'))
  link(join(root, relative), join(scratch, 'node_modules', info.name))
}
link(join(root, 'packages/infra/clock/node_modules/@deepseek-ai/cordis'), join(scratch, 'node_modules/@deepseek-ai/cordis'))
link(join(root, 'packages/infra/storage-sql/node_modules/kysely'), join(scratch, 'node_modules/kysely'))
link(join(root, 'packages/infra/clock/node_modules/@types/node'), join(scratch, 'node_modules/@types/node'))
const hash = value => createHash('sha256').update(value).digest('hex')
function tree(relative) {
  const path = join(root, relative)
  return readdirSync(path, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name)).flatMap(entry =>
    entry.isDirectory() ? tree(join(relative, entry.name)) : [{ path: join(relative, entry.name), sha256: hash(readFileSync(join(path, entry.name))) }])
}
function snapshot() {
  return [
    ...inputs.flatMap(relative => [
      { path: join(relative, 'package.json'), sha256: hash(readFileSync(join(root, relative, 'package.json'))) },
      ...tree(join(relative, 'src')), ...tree(join(relative, 'dist')),
    ]),
    ...['package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'tsconfig.base.json'].map(relative => ({ path: relative, sha256: hash(readFileSync(join(root, relative))) })),
  ]
}
const before = snapshot()
writeFileSync(join(output, 'inputs-before.json'), JSON.stringify(before, null, 2))
const examples = []
for (const relative of packages) {
  const en = readFileSync(join(root, relative, 'README.md'), 'utf8')
  const zh = readFileSync(join(root, relative, 'README_ZH.md'), 'utf8')
  const extract = text => [...text.matchAll(/```ts\n([\s\S]*?)\n```/g)].map(match => match[1])
  const blocks = extract(en)
  assert.deepEqual(extract(zh), blocks, relative + ' bilingual examples differ')
  blocks.forEach((code, index) => {
    const name = relative.split('/').at(-1) + '-' + (index + 1) + '.ts'
    const file = join(scratch, 'examples', name)
    writeFileSync(file, code + '\n')
    writeFileSync(join(output, name), code + '\n')
    examples.push({ file, name, package: relative, codeSha256: hash(code), postgresConnection: false })
  })
}
writeFileSync(join(scratch, 'tsconfig.json'), JSON.stringify({
  compilerOptions: {
    target: 'ES2024', module: 'NodeNext', moduleResolution: 'NodeNext', lib: ['ES2024'],
    types: ['node'], strict: true, exactOptionalPropertyTypes: true, noUncheckedIndexedAccess: true,
    noImplicitOverride: true, useUnknownInCatchVariables: true, verbatimModuleSyntax: true,
    isolatedModules: true, skipLibCheck: false, noEmit: true,
  },
  include: ['examples/*.ts'],
}, null, 2))
const run = (name, command, args, cwd = root) => {
  const result = spawnSync(command, args, { cwd, encoding: 'utf8' })
  writeFileSync(join(output, name + '.stdout'), result.stdout ?? '')
  writeFileSync(join(output, name + '.stderr'), result.stderr ?? String(result.error ?? ''))
  return { name, command: [command, ...args], cwd, status: result.status, error: result.error?.message }
}
const typecheck = run('typecheck', process.execPath, [join(root, 'packages/infra/storage-sql/node_modules/typescript/bin/tsc'), '-p', join(scratch, 'tsconfig.json')])
const runs = examples.map(example => ({ ...example, ...run(example.name, process.execPath, [example.file]) }))
const after = snapshot()
writeFileSync(join(output, 'inputs-after.json'), JSON.stringify(after, null, 2))
const head = spawnSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).stdout.trim()
const branch = spawnSync('git', ['branch', '--show-current'], { cwd: root, encoding: 'utf8' }).stdout.trim()
const docs = packages.flatMap(relative => ['README.md', 'README_ZH.md'].map(name => ({ path: join(relative, name), sha256: hash(readFileSync(join(root, relative, name))) })))
const receipt = {
  root, head, branch, node: process.version, typecheck, runs, docs,
  unchangedSourceAndDistDuringRun: JSON.stringify(before) === JSON.stringify(after),
  buildRun: false,
  limits: ['README examples only; no package regression suites', 'PostgreSQL configuration validation only; no PostgreSQL connection or transaction', 'SQLite temporary file databases; no user databases or environment secrets'],
}
writeFileSync(join(output, 'receipt.json'), JSON.stringify(receipt, null, 2))
writeFileSync(join(scratch, 'latest-run.txt'), output + '\n')
console.log(JSON.stringify({ output, head, typecheck: typecheck.status, examples: runs.map(r => ({ name: r.name, status: r.status })), unchangedInputs: receipt.unchangedSourceAndDistDuringRun }, null, 2))
if (typecheck.status !== 0 || runs.some(result => result.status !== 0) || !receipt.unchangedSourceAndDistDuringRun) process.exitCode = 1
