import { describe, expect, it } from 'vitest'
import validationMeta from 'ajv/dist/refs/json-schema-2020-12/meta/validation.json' with { type: 'json' }
import { writeJsonLossless, readJsonStrict, type JsonValue } from '../src/json.ts'
import {
  createSchemaRuntime,
  type SchemaDocument,
  type SchemaRuntimeOptions,
} from '../src/schema-runtime.ts'
function json(text: string): JsonValue {
  const parsed = readJsonStrict(text)
  if ('failed' in parsed) throw new Error('invalid test JSON')
  return parsed.ok
}

function schema(text: string): SchemaDocument {
  const value = json(text)
  if (typeof value === 'boolean') return value
  if (value === null || typeof value !== 'object' || Array.isArray(value))
    throw new Error('expected test Schema')
  const result = Object.fromEntries(Object.entries(value))
  return result
}
const runtime = createSchemaRuntime([])
describe('protected schema-runtime original-value boundary', () => {
  it('pins standard meta inputs independently of other consumers of Ajv JSON resources', () => {
    const definition = validationMeta.$defs.nonNegativeInteger
    const before = definition.type
    try {
      definition.type = 'string'
      const fresh = createSchemaRuntime([])
      expect(fresh.metaValidate({ minLength: 1 })).toBe(true)
      expect(fresh.metaValidate({ minLength: -1 })).toBe(false)
      expect(fresh.metaValidate({ minLength: '1' })).toBe(false)
    } finally {
      definition.type = before
    }
  })
  it.each([
    ['{"type":"integer"}', '1.0000000000000000000001', false],
    ['{"type":["integer","null"]}', '1e400', true],
    ['{"type":["integer","null"]}', 'null', true],
    ['{"type":["integer","string"]}', '1.0000000000000000000001', false],
    ['{"type":["integer","string"]}', '1e400', true],
    ['{"type":["integer","string"]}', '"one"', true],
    ['{"minimum":9007199254740993}', '9007199254740992', false],
    ['{"maximum":-9007199254740993}', '-9007199254740992', false],
    ['{"exclusiveMinimum":0.1}', '0.100000000000000000001', true],
    ['{"exclusiveMaximum":1e400}', '1e399', true],
    ['{"multipleOf":0.1}', '0.3', true],
    ['{"multipleOf":0.1}', '0.300000000000000000001', false],
    ['{"const":{"n":9007199254740993}}', '{"n":9007199254740992}', false],
    ['{"enum":[9007199254740992,9007199254740993]}', '9007199254740993', true],
    ['{"uniqueItems":true}', '[9007199254740992,9007199254740993]', true],
    ['{"uniqueItems":true}', '[1,1.0]', false],
    ['{"exact_minimum":"not a private encoding"}', '-1', true],
    ['{"minimum":0,"exact_minimum":"-10"}', '-1', false],
    ['{"minLength":9007199254740993}', '"x"', false],
    ['{"maxLength":9007199254740993}', '"x"', true],
    ['{"minLength":1e400}', '"😀"', false],
    ['{"maxLength":1e400}', '"😀"', true],
    ['{"minLength":2}', '"😀"', false],
    ['{"maxLength":1}', '"😀"', true],
    ['{"minItems":1e400}', '[]', false],
    ['{"maxItems":1e400}', '[1,2]', true],
    ['{"minProperties":9007199254740993}', '{}', false],
    ['{"maxProperties":9007199254740993}', '{"x":1}', true],
    ['{"propertyNames":{"minLength":2}}', '{"a":1}', false],
    ['{"propertyNames":{"maxLength":1}}', '{"😀":1}', true],
    ['{"propertyNames":{"type":["integer","string"]}}', '{"a":1}', true],
    ['{"propertyNames":{"enum":[1,"a"]}}', '{"a":1}', true],
    ['{"propertyNames":{"enum":[1,"a"]}}', '{"b":1}', false],
  ] as const)('validates %s against %s without changing the source', (text, input, expected) => {
    const originalSchema = schema(text)
    const value = json(input)
    expect(runtime.metaValidate(originalSchema)).toBe(true)
    expect(runtime.compile(originalSchema).validate(value)).toBe(expected)
    expect(writeJsonLossless(originalSchema)).toBe(text)
    expect(writeJsonLossless(value)).toBe(input)
  })
  it.each([
    ['{"multipleOf":1e-400}', true],
    ['{"multipleOf":-1e-400}', false],
    ['{"minLength":1.000000000000000000001}', false],
    ['{"maxLength":1e400}', true],
    ['{"type":["integer","integer"]}', false],
    ['{"required":["a","a"]}', false],
  ] as const)('meta-validates exact numeric and enum source %s', (text, expected) => {
    const input = schema(text)
    expect(runtime.metaValidate(input)).toBe(expected)
    expect(writeJsonLossless(input)).toBe(text)
    if (!expected) expect(() => runtime.compile(input)).toThrow(TypeError)
  })
  it('clones fixed resources and author Schemas at their respective binding moments', () => {
    const resource = { $id: 'https://test.invalid/fixed', $defs: { Exact: { const: 1 } } }
    const pinned = createSchemaRuntime([resource])
    resource.$defs.Exact.const = 2
    const author = {
      type: 'object',
      properties: { n: { $ref: 'https://test.invalid/fixed#/$defs/Exact' } },
      required: ['n'],
    }
    const compiled = pinned.compile(author)
    author.properties.n.$ref = 'https://test.invalid/missing'
    expect(compiled.validate(json('{"n":1.0}'))).toBe(true)
    expect(compiled.validate({ n: 2 })).toBe(false)
    expect(Object.isFrozen(pinned)).toBe(true)
    expect(Object.isFrozen(compiled)).toBe(true)
  })
  it('keeps original instance contexts separate across interleaved calls', () => {
    const first = runtime.compile(
      schema(
        '{"type":"object","properties":{"a/b":{"maximum":9007199254740992}},"required":["a/b"]}',
      ),
    )
    const second = runtime.compile(schema('{"type":"array","items":{"minimum":9007199254740993}}'))
    expect(first.validate(json('{"a/b":9007199254740993}'))).toBe(false)
    expect(second.validate(json('[9007199254740993]'))).toBe(true)
    expect(first.validate(json('{"a/b":9007199254740992}'))).toBe(true)
    expect(second.validate(json('[9007199254740992]'))).toBe(false)
  })
  it('recovers original numbers below escaped members and external numeric refs', () => {
    const pinned = createSchemaRuntime([
      schema(
        '{"$id":"https://test.invalid/escaped","$defs":{"Number":{"minimum":9007199254740993}}}',
      ),
    ])
    const compiled = pinned.compile({
      type: 'object',
      properties: {
        'a/b~c': { type: 'array', items: { $ref: 'https://test.invalid/escaped#/$defs/Number' } },
      },
      required: ['a/b~c'],
    })
    expect(compiled.validate(json('{"a/b~c":[9007199254740992]}'))).toBe(false)
    expect(compiled.validate(json('{"a/b~c":[9007199254740993]}'))).toBe(true)
    expect(compiled.validate(json('{"a/b~c":[9007199254740992]}'))).toBe(false)
  })
  it('keeps identical resource ids private to each caller-owned runtime', () => {
    const first = createSchemaRuntime([{ $id: 'https://test.invalid/private', const: 1 }])
    const second = createSchemaRuntime([{ $id: 'https://test.invalid/private', const: 2 }])
    const a = first.compile({ $ref: 'https://test.invalid/private' })
    const b = second.compile({ $ref: 'https://test.invalid/private' })
    expect(a.validate(json('1.0'))).toBe(true)
    expect(b.validate(json('1.0'))).toBe(false)
    expect(a.validate(2)).toBe(false)
    expect(b.validate(2)).toBe(true)
  })
  it('keeps metadata results independent of compilation and prior caller mutations', () => {
    const author = { minLength: 1 }
    const compiled = runtime.compile(author)
    author.minLength = -1
    expect(runtime.metaValidate(author)).toBe(false)
    expect(compiled.validate('x')).toBe(true)
    expect(compiled.validate('')).toBe(false)
    expect(runtime.metaValidate({ minLength: 1 })).toBe(true)
  })
  it.each(['minContains', 'maxContains'] as const)(
    'preserves %s comparisons on actual JavaScript arrays for overflow bounds',
    keyword => {
      const input = schema(`{"contains":true,"${keyword}":9007199254740993}`)
      expect(runtime.metaValidate(input)).toBe(true)
      expect(runtime.compile(input).validate([1])).toBe(keyword === 'maxContains')
      expect(writeJsonLossless(input)).toBe(`{"contains":true,"${keyword}":9007199254740993}`)
    },
  )
  it('propagates reference and compile failures, without remote loading or async validation', () => {
    expect(() => runtime.compile({ $ref: 'https://unavailable.invalid/schema' })).toThrow()
    expect(() => createSchemaRuntime([{ $id: 'x', type: 'imaginary' }])).toThrow(TypeError)
    expect(() => createSchemaRuntime([true])).toThrow(TypeError)
    expect(runtime.compile({ $async: true, type: 'string' }).validate('x')).toBe(true)
    expect(runtime.compile({ $async: true, type: 'string' }).validate(1)).toBe(false)
    const defect = new SyntaxError('caller pattern failed')
    const failing = createSchemaRuntime([], {
      patternFactory: () => {
        throw defect
      },
    })
    expect(() => failing.compile({ pattern: 'x' })).toThrow(defect)
  })
})

describe('supported Draft 2020-12 compositions with fixed resources', () => {
  it('checks the host array bound without allocating an enormous JSON array', () => {
    const sparse: unknown[] = []
    sparse.length = 2 ** 32 - 1
    expect(sparse.length).toBe(2 ** 32 - 1)
    expect(() => {
      sparse.length = 2 ** 32
    }).toThrow(RangeError)
  })
  it.each([
    [
      '{"allOf":[{"minimum":9007199254740993},{"maximum":9007199254740993}]}',
      '9007199254740993',
      true,
    ],
    ['{"anyOf":[{"const":9007199254740993},{"type":"null"}]}', '9007199254740992', false],
    [
      '{"oneOf":[{"minimum":9007199254740992},{"minimum":9007199254740993}]}',
      '9007199254740993',
      false,
    ],
    ['{"not":{"const":9007199254740993}}', '9007199254740992', true],
    [
      '{"if":{"type":"number"},"then":{"minimum":9007199254740993},"else":{"type":"null"}}',
      '9007199254740992',
      false,
    ],
    [
      '{"type":"object","additionalProperties":{"type":"integer"}}',
      '{"x":1.0000000000000000001}',
      false,
    ],
    [
      '{"type":"object","properties":{"x":{"minimum":9007199254740993}},"unevaluatedProperties":false}',
      '{"x":9007199254740993,"y":0}',
      false,
    ],
    ['{"type":"object","dependentSchemas":{"x":{"required":["y"]}}}', '{"x":1}', false],
    ['{"type":"object","propertyNames":{"enum":["a","b"]}}', '{"a":1,"b":2}', true],
    [
      '{"type":"array","prefixItems":[{"const":9007199254740993}],"items":false}',
      '[9007199254740993]',
      true,
    ],
    [
      '{"type":"array","contains":{"const":9007199254740993},"minContains":1,"maxContains":1}',
      '[9007199254740992,9007199254740993]',
      true,
    ],
    ['{"type":"array","prefixItems":[true],"unevaluatedItems":false}', '[1,2]', false],
    ['{"type":"string","format":"not-a-known-format"}', '"anything"', true],
    ['false', 'null', false],
    ['true', 'null', true],
    [
      '{"contains":true,"minContains":9007199254740994,"maxContains":9007199254740993}',
      '[1]',
      false,
    ],
    ['{"contains":false,"minContains":0,"maxContains":1e400}', '[1]', true],
    ['{"contains":false,"minContains":1e400}', '[]', false],
    [
      '{"$defs":{"One":{"const":1}},"contains":{"$ref":"#/$defs/One"},"maxContains":1e400}',
      '[1,2]',
      true,
    ],
    ['{"allOf":[{"contains":true,"maxContains":1e400}]}', '[1]', true],
    ['{"allOf":[{"contains":true,"minContains":1e400}]}', '[1]', false],
    ['{"contains":true,"minContains":1e400}', 'null', true],
    ['{"type":"array","contains":true,"minContains":1e400}', 'null', false],
    ['{"type":"integer","nullable":true}', 'null', false],
    ['{"dependencies":{"x":["y"]}}', '{"x":1}', true],
    ['{"id":5,"$recursiveAnchor":"unknown-annotation"}', 'null', true],
  ] as const)('checks composition %s', (text, value, expected) =>
    expect(runtime.compile(schema(text)).validate(json(value))).toBe(expected),
  )
  it('uses explicit fixed external refs and recursive dynamic references with original numbers', () => {
    const resource = schema(
      '{"$id":"https://test.invalid/tree","$dynamicAnchor":"node","type":"object","properties":{"n":{"type":"integer"},"next":{"$dynamicRef":"#node"}},"required":["n"]}',
    )
    const compiled = createSchemaRuntime([resource]).compile({ $ref: 'https://test.invalid/tree' })
    expect(compiled.validate(json('{"n":1,"next":{"n":1.0000000000000000001}}'))).toBe(false)
    expect(compiled.validate(json('{"n":1,"next":{"n":1e400}}'))).toBe(true)
  })
})

describe('caller-owned pattern engine for frozen M56 choice', () => {
  const mixed = {
    type: 'object',
    properties: {
      ordinary: { type: 'string', pattern: '^\\-$' },
      unicode: { type: 'string', pattern: '^[\\u{1F600}-\\u{1F64F}]$' },
    },
    required: ['ordinary', 'unicode'],
  }
  const options: SchemaRuntimeOptions = {
    patternFactory(source) {
      try {
        return new RegExp(source)
      } catch (error) {
        if (!(error instanceof SyntaxError)) throw error
        return new RegExp(source, 'u')
      }
    },
  }
  it('actually compiles both selected flags in one schema; a default-u compiler cannot', () => {
    expect(() => runtime.compile(mixed)).toThrow(SyntaxError)
    const compiled = createSchemaRuntime([], options).compile(mixed)
    expect(compiled.validate({ ordinary: '-', unicode: '😀' })).toBe(true)
    expect(compiled.validate({ ordinary: '-', unicode: 'x' })).toBe(false)
    expect(compiled.validate({ ordinary: 'x', unicode: '😀' })).toBe(false)
  })
  it.each(['g', 'y'])('rejects stateful flag %s during construction of a compiled pattern', flags =>
    expect(() =>
      createSchemaRuntime([], { patternFactory: source => new RegExp(source, flags) }).compile({
        pattern: 'x',
      }),
    ).toThrow(TypeError),
  )
})
