import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    include: ['tests/**/*.spec.ts'],
    // Actual Schema compilation is exercised rather than replaced; a single worker
    // makes the runner budget independent of simultaneous package validation jobs.
    maxWorkers: 1,
    testTimeout: 30_000,
    typecheck: {
      enabled: true,
      include: ['tests/**/*.spec-d.ts'],
      tsconfig: './tsconfig.test.json',
    },
  },
})
