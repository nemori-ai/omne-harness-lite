# 验证覆盖与实际证据

本文件在版本目录之外，可更新；结果始终绑定实际的规范修订与实现修订。

> **当前状态：改写后的模型已执行一次（run `-2`），上一次 run 对当前模型不适用；规范场景一条都没演练过。**
> `composition.account-registration` v1 已由 [D-023](../../../record/decisions/tenant-domain-design-acceptance/README.md) 接受并冻结（2026-09-22），提供者设计在 [`realization/packages/tenancy/account-registration`](../../../realization/packages/tenancy/account-registration/README.md)；尚无源码、尚无装配。**此后版本目录不再原地改，语义改动发布 v2。**
>
> **[2026-09-22 的第一次运行](#实际执行)跑的是改写之前的模型**：
> 它检查的 `Activate` 守卫写的是 `orgCount >= 1`，而评审轮一把那个守卫判为错误
> （[`#S-14` 按契约读不到组织那一侧](../../capabilities/account-identity/v1/contract.md#s-2-消费者与依赖方向)）
> 并改成 `warrant[a] ∧ ~expired`，另加了 `warrant` 变量、两条 `Rejected` 分支、
> `ClaimExpired` 守卫谓词，并把 `progress.cfg` 的 `Expiring` 由 FALSE 改为 TRUE。
> **模型与配置都变了，那三行结果只保留其历史记录价值，不再支持本表任何一条。**
>
> **改写后的模型已在 [run `2026-09-22-formal-tenant-domain-2`](#实际执行) 跑过三个配置，全部无反例。**
> **但「无反例」在本包仍然不能被读成强证据**：
> [八个变异核对与两个有效性核对，本 run 一个都没登记](#实际执行)。
> 变异没做，不变式可能是平凡的；有效性没做，「成功路径可达」这件事还没被验证过——
> **不变式全绿也可能只是因为成功状态根本到不了**。
> 修订模型的那位 agent 自报这十个核对全部通过，**但那次执行没有快照、没有原始输出，
> 因此[只记作「修订者自报，未登记」](../../../record/evidence/2026-09-22-formal-tenant-domain-2/README.md#变异核对修订者自报本-run-未登记)，不计入本页任何一条。**
> 规范场景同样**一条都没演练过**，它们要的是真实实现，而实现不存在。
> 原始产物在 [`record/evidence/`](../../../record/evidence/README.md)。

## 证据义务

| 规范条款与性质 | 证据形式与抽象映射 | 实际证据入口、输入与范围 | 未完成义务、责任与受阻消费者 |
|---|---|---|---|
| [S-13](v1/contract.md#s-13-一个可用账号有且仅有一个个人组织) 可用账号有且仅有一个个人组织（含「不存在已激活却无个人组织的账号」那一面） | TLC：`ActivatedHasPersonalOrganization` ∧ `OnePersonalOrganizationPerAccount`，配置 [`basic.cfg`](v1/formal/basic.cfg) 与 [`crash.cfg`](v1/formal/crash.cfg) | **已执行**（[run `-2` · `basic` 与 `crash`](#实际执行)）：两个配置都**无反例**、完整穷尽。[第一次 run 跑的是改写之前的模型](#实际执行)（`Activate` 的守卫不同、`warrant` 变量不存在），**那两格不计入本条** | 范围仅限模型抽象（见 [formal/README 的语义映射](v1/formal/README.md#语义映射)），**不覆盖真实存储的提交原子性**。**变异核对未做**，因此这两条不变式是否平凡尚未被验证 |
| [S-14](v1/contract.md#s-14-一个登录标识上至多一个账号) 一个登录标识至多一个账号 | **不由模型兑现**——模型把它吸收进了建模方式（[说明](v1/formal/README.md#模型吸收了哪一条不变量)）。证据形式是规范场景 [S-31](v1/contract.md#s-31-规范场景两个同标识并发注册) | **未执行。**需要一个实现了 ① 的提供者与真实存储 | 阻断在提供者缺席。**不得把 TLC 通过读成这一条已被检查** |
| [S-15](v1/contract.md#s-15-激活不回退) 激活不回退 | TLC：由 `TypeOK` 与动作集合共同表达（`account` 无从 `"activated"` 出发的转移）；另由 `capability.account-identity` 的静态检查兑现 | **已执行**（[run `-2`](#实际执行)）：`TypeOK` 含 `warrant` 一项，三个配置下都无反例 | 静态检查那一半仍未执行，责任在 `capability.account-identity` 的提供者 |
| [S-16](v1/contract.md#s-16-中断绝不被呈现为成功) 中断不呈现为成功 | TLC：`NoFalseSuccess`，**必须在 [`crash.cfg`](v1/formal/crash.cfg) 下检查**——无故障的配置证明不了这一条 | **已执行**（[run `-2` · `crash`](#实际执行)）：**无反例**，6978 distinct、完整穷尽 | 结论范围：`Attempts = {a1, a2, a3}`、模型抽象之内 |
| [S-10](v1/contract.md#s-10-激活是唯一提交点) 激活的前置是个人组织已存在 | TLC：`OrganizationBeforeActivation`，动作性质 `[][A]_vars` | **已执行**（[run `-2` · `basic` 与 `crash`](#实际执行)）：**无反例**。**`progress.cfg` 不检查这一条**——它的性质集合只有 `TypeOK` 与 `EventualOutcome` | 同上 |
| [S-35](v1/contract.md#s-35-个人组织不会变成孤儿) 个人组织不会变成孤儿 | TLC：`NoOrphanPersonalOrganization`，**只有 [`crash.cfg`](v1/formal/crash.cfg) 真正检查它**——`basic.cfg` 里 `Expiring = FALSE`，清除链根本不发生 | **已执行**（[run `-2` · **只有 `crash`** 计入](#实际执行)）：**无反例**。**`basic.cfg` 那一格不计入本条**——那里 `Expiring = FALSE`，它是平凡的 | **两个变异核对（M4／M5）仍然没做**：去掉清除链次序、去掉 `OrganizeOk` 的 `~expired`。**缺了它们，「无反例」区分不了「次序排对了」与「次序之间那个窗口也堵住了」**——而那正是本条唯一的保护点 |
| [S-20](v1/contract.md#s-20-收敛) 静止时没有第三种形态 | TLC：`ConvergentOutcome`。**它是 S-13 与 S-16 的投影，不是独立证据**（[说明](v1/formal/README.md#convergentoutcome-不是一条独立性质)） | **已执行**（[run `-2` · `basic` 与 `crash`](#实际执行)）：**无反例**。**`progress.cfg` 不检查这一条** | **证据强度等于 S-13 与 S-16 通过，不叠加** |
| [S-19](v1/contract.md#s-19-有前提的进展) 有前提的进展 | TLC：`EventualOutcome`（leads-to），**只在 [`progress.cfg`](v1/formal/progress.cfg)**，前提写成 `Failures = FALSE`、`Abandoning = FALSE` 与显式公平性 | **已执行**（[run `-2` · `progress`](#实际执行)）：**无反例**，`Expiring = TRUE`；时序性质 2 branches，在 374 total distinct states 上检查完。**检查范围比上一次大得多**（那次 62） | **前提 (a)(b)(c) 在真实系统中不可观察**：(b)(c) 在模型里是常量取值（`Abandoning = FALSE`、`Failures = FALSE`）加公平性假设，(a) 由前件 `pc[a] # "start"` 承接、不是常量，(d) 未建模——**都不是被证明的事实**；该性质**没有上界**，不能改写成回归检查的时限断言。**前提 (d)（服务面可解析）根本没有被建模**，[如实记在 formal/README](v1/formal/README.md#本版本选用什么)。**`Expiring` 不是前提**，评审轮一补上两条 `Rejected` 分支之后它由 FALSE 改为 TRUE——**关掉它反而缩小检查范围**。**还有一支根本不在前件内**：① 撞上已过期记录时尝试留在 `"start"`，而前件是 `pc[a] # "start"`，**TLC 对它什么也没说**；那一支的进展由 [S-8](v1/contract.md#s-8-三步次序与责任交接) 的分支表承担，证据是本表里「① 撞上过期记录时由本组合接手」与「① 最多重跑一次」两行的规范场景。**不得把 `progress.cfg` 无反例读成「撞上过期记录的尝试也一定会走到终结结果」** |
| 不变式非平凡 | **变异核对**：[八个变异 M1～M8](v1/formal/README.md#变异核对证明不变式不平凡)每个都必须使某条不变式出反例 | **未登记。**（评审轮一由七个增到八个：`Activate` 拆守卫之后，原来那条「去掉 `orgCount >= 1`」换成 **M6 去掉 `~expired`** 与 **M7 去掉 `warrant[a]`** 两个。）**修订模型的 agent 自报八个全部出反例，但那次执行在它自己的工作区、无输入快照、无原始输出，[按证据准入不登记](../../../record/evidence/2026-09-22-formal-tenant-domain-2/README.md#变异核对修订者自报本-run-未登记)** | 责任：主线。**跳过它，上面每一条的「通过」都只说明断言没被违反，不说明断言有内容。**M4／M5 抓同一条不变量的两个不同的洞，M6／M7 抓另一条不变量在 ③ 那一侧的两个洞，**四个缺一不可** |
| 模型有效性 | **有效性核对**：两个临时否定不变量必须出反例，证明成功路径与「停在未激活」路径都可达 | **未登记。**两次 run 都没做；**修订者自报两个都按预期失败，同样无快照、不登记** | 责任：主线。**在它做完之前，上面全部「无反例」都还留着一种解释：成功状态根本不可达。**这两个否定配置**不写成文件、不登记为 formal task**——期望失败的检查与该清单的语义相反（检查器按退出码判成败） |
| [S-27](v1/contract.md#s-27-规范场景中途失败后用同一标识重来) 中途失败后用同一标识重来 | 规范场景演练：真实存储 + 在 ② 提交前注入故障 | **未执行。**需要两个参与方的提供者 | 阻断在提供者缺席。受阻消费者：注册入口 |
| [S-28](v1/contract.md#s-28-规范场景在任意位置中断没有第三种形态) 任意位置中断没有第三种形态 | 规范场景演练，三个中断位置各一次，**此后不再重试** | **未执行** | 同上。这条与 TLC 的 `ConvergentOutcome` **不能互相替代**：模型检查交错，场景检查真实存储 |
| [S-29](v1/contract.md#s-29-规范场景参与方缺席时不放行) 参与方缺席时不放行 | 故障注入：让 `capability.organization-governance` 不可用，观察 ③ **不激活** | **未执行** | 同上。这条最容易在实现里被一个「读不到就当已经建好了」抹掉，**必须真跑** |
| [S-30](v1/contract.md#s-30-规范场景编排者被卸载在途尝试等同崩溃) 编排者被卸载等同崩溃 | 规范场景演练：在 ①② 之间卸载编排提供者 | **未执行。**需要可装卸的提供者装配 | 同上。同时验证[不承诺清理](v1/contract.md#s-3-本契约明确不承诺什么)：**没有任何清理动作发生** |
| [S-31](v1/contract.md#s-31-规范场景两个同标识并发注册) 两个同标识并发注册 | 规范场景演练，同凭据与不同凭据各一次 | **未执行** | 同上。它同时是 [S-14](v1/contract.md#s-14-一个登录标识上至多一个账号) 与 [S-18](v1/contract.md#s-18-回执侧不承诺唯一) 的唯一证据形式 |
| [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 清除链走得通且可重扫 | 规范场景演练：让一条未激活记录过期，跑清除链；**在两步之间中断一次**，再重扫 | **未执行。**需要两个参与方的提供者、可操纵的时间源与可配置的留存期限 | 阻断在提供者缺席。**两步之间中断那一支必须真跑**：中断后的状态（账号记录在、未激活、没有个人组织）与[注册走到 ① 之后的状态逐字相同](v1/contract.md#s-11-失败停在哪)，两条收场（重扫走完／发起者带同一凭据回来）都要观察到。**重扫那一支还要观察到 ① 幂等成功时仍然产出依据**——否则 ② 永远续不上。**走完的可观察形式是返回面的 `ok`**（[S-34](v1/contract.md#s-34-第二条动作链未激活到期清除)：两步都 `ok`，含幂等） |
| [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 次序在运行期挡得住 | 规范场景演练：**跳过 ① 直接调 ②**（`capability.account-identity/v1#S-38`），不带清除依据 | **未执行** | 责任：两个参与方的提供者。**必须观察到** `purge-warrant-invalid`，**账号记录原样还在**。**这一支是「次序不只是一句条款」的唯一证据**；没有它，`#S-38` 的依据前置在真实实现里可能是个摆设，而 [S-35](v1/contract.md#s-35-个人组织不会变成孤儿) 就只剩模型里那条守卫撑着 |
| [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 失败分三类，**处置按发起者分两套** | 演练：逐支制造十个失败值——[`#S-53`](../../capabilities/organization-governance/v1/contract.md#s-53-清除未激活账号的个人组织) 的 `accountIsActivated`／`accountNotExpired`（**终止型**）、`organizationIsNotPersonal`／`invalidInput`／`accountDoesNotExist`（**缺陷型**）、`unavailable`（**抖动型**）；[`#S-38`](../../capabilities/account-identity/v1/contract.md#s-38-清除到期的未激活账号记录) 的 `not-expired`（**终止型**）、`purge-warrant-invalid`／`invalid-input`（**缺陷型**）、`storage-unavailable`（**抖动型**）。**缺陷型与抖动型每一支都要在两个发起者下各跑一次**（清扫发起、主链就地发起）；**终止型里 ① 的两支只在清扫发起下制造；② 的 `not-expired` 两个发起者下都不可达**，只能靠故障注入伪造，观察到即记缺陷并报出（见右） | **未执行** | 责任：清扫提供者的装配 ＋ 编排本链的提供者。**清扫发起时必须观察到**：终止型与缺陷型使该目标**退出本轮候选**（缺陷型另报出来）、抖动型使它**下一轮按幂等续做**，**三类都不产生终结结果**。**主链就地发起时必须观察到**：缺陷型 ⇒ `interrupted` 并另记缺陷、抖动型 ⇒ `interrupted`，**两类都不重跑 ①**；**终止型在这条路径上不可达**（① 刚判过期、「已过期」单调、激活过不了 [`#S-14` 前置③](../../capabilities/account-identity/v1/contract.md#s-14-激活账号)），**若用故障注入伪造出一支**（例如注入一个把「已过期」翻回「否」的读面），必须观察到本次尝试 `interrupted` 并**另记为缺陷**，**不重跑 ①**、不得报成 `identifier-taken`。**把终止型当抖动会让清扫无限重试一个永远不会成功的目标**；反过来会让一条该清的记录被永久跳过。**这一行的两列分法是评审轮二定的**，`purge-warrant-invalid`／`organizationIsNotPersonal` 同时由抖动型／终止型改判为缺陷型；**评审轮三把主链那一列的终止型由「重跑 ① 一次」改为「不可达 ⇒ 缺陷型」**，并把失败值改按本名带坐标 |
| [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) ① 的两支「账号记录不存在」 | 演练，**两支必须同跑**：① **账号记录已不在、个人组织还在** ⇒ [`#S-53`](../../capabilities/organization-governance/v1/contract.md#s-53-清除未激活账号的个人组织) 给 `accountDoesNotExist`；② **账号记录与个人组织都已不在** ⇒ 幂等 `ok` **并产出依据** | **未执行。**需要能把两侧记录分别删掉的装配 | 责任：两个参与方的提供者 ＋ 编排者。**必须观察到**：第 ① 支 ⇒ **停在本步、什么都不删、不产依据**，本次尝试（主链发起时）`interrupted` 并记缺陷——**它是[「个人组织存在 ⇒ 账号记录存在」被破的唯一运行期观测点](v1/contract.md#s-35-个人组织不会变成孤儿)**；第 ② 支 ⇒ 链条**照常走完 ②**。**绝不能观察到**：第 ① 支把那个组织顺手删掉，或把 `accountDoesNotExist` 折进 `unavailable`（那会把一次结构性缺陷伪装成基础设施抖动，观测点就此消失）。**这一行是评审轮二新增的** |
| [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 两个发起者在同一条记录上并发 | 演练：清扫与主链就地发起同时命中同一条过期记录，**两种 ① 先后各跑一次**（清扫 ① 先／主链 ① 先） | **未执行。**需要两个参与方的提供者与可控的并发注入 | 责任：编排者 ＋ 清扫提供者的装配。**必须观察到**：后到的 ① 走 [`#S-53`](../../capabilities/organization-governance/v1/contract.md#s-53-清除未激活账号的个人组织) ⑦甲（组织已清、账号仍在）**仍过 ②甲 现读**再 `ok` ＋ 依据，两条链各自 ② 幂等收敛，终态唯一；**绝不能观察到**：⑦甲 写成「组织不在直接 `ok`」——那会给一个已激活账号发依据。**这一行是 architecture-reviewer 2026-09-22 非阻断 3 补登的**：模型里发起者不区分（`sweep` 单变量），这条交错不在 `Registration.tla` 里 |
| [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) **「① 最多重跑一次」** | 演练：让一次尝试撞上已过期记录、跑完清除链、重跑 ① **仍然**撞上一条已过期记录（需要构造第二条过期记录） | **未执行。**需要可操纵的时间源与能在窗口里插入第二次注册的装配 | 责任：编排本链的提供者。**必须观察到**：本次尝试终结为 `interrupted`，**不再重跑第三次**。**这条只能靠场景**——[模型里没有任何变量记着「已经重跑过」](v1/formal/README.md#语义映射)，破坏它也不会违反本模型检查的任何一条性质 |
| [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 与注册主链并发 | **真并发**演练：同一账号的注册主链 ② 与清除链 ① 并发 | **未执行** | 责任：提供者。**绝不能观察到**一个账号记录已不存在的个人组织。**顺序调用跑不出这条**——它要的正是那个窗口 |
| [S-8](v1/contract.md#s-8-三步次序与责任交接) ① 撞上过期记录时由本组合接手 | 规范场景演练：让一条未激活记录过期（**不跑清扫**），用**同一标识**发起一次新注册 | **未执行。**需要两个参与方的提供者与可操纵的时间源 | 责任：提供者。**必须观察到**：这一次尝试**就能**走到 `registered`，得到的 AccountId **与原来那条不同**，且结束时**没有孤儿个人组织**。**绝不能观察到** `identifier-taken`、也不能观察到「要等清扫跑过才成」。**这条是评审轮一新增的**，对应[验收判据「到期之后另一个人用那个标识注册得成」](../../../product/PF-001-identity-scope-and-agent-constraints/acceptance.md#三判据)。**再跑一支**：清除链中途失败 ⇒ 本次尝试 `interrupted`，**本组合不绕过清除链的任何前置** |
| [S-8](v1/contract.md#s-8-三步次序与责任交接) 的**失败值 → 终结结果映射** | 演练：逐个制造[映射表](v1/contract.md#参与方失败值到终结结果的映射)里的参与方失败值 | **未执行** | 责任：提供者。**必须观察到**每一个都落在表里那个终结结果上，**且四个终结结果之外没有第五种收场**。**「组合缺陷／入口缺陷」那三类要可被区分地记录下来**——合进普通 `interrupted` 统计，一条坏掉的依据链看起来就只是「存储不太稳」 |
| [S-8](v1/contract.md#s-8-三步次序与责任交接) ② 幂等那一路**也产出激活依据** | 规范场景演练：先让一次尝试走完 ②，再以同一标识、同一凭据发起第二次尝试 | **未执行** | 责任：提供者。**必须观察到**第二次在 ② 拿到的是既有的那个个人组织（`#S-20` 的⑦），**并且照样拿到一份可用的激活依据**，③ 走得通。**一个只在新建那一路产出依据的实现，会让每一次重来都永远卡在 ③**——而顺序演练里第一次尝试总是新建，看不出这一条 |
| [`capability.account-identity/v1#S-14`](../../capabilities/account-identity/v1/contract.md#s-14-激活账号) 前置③在组合层的可观察形式（＝ [`capability.account-identity/v1#S-43`](../../capabilities/account-identity/v1/contract.md#s-43-依据产出之后记录才过期) 的组合侧那一面） | **同一次演练的两面**：能力侧场景 [`#S-43`](../../capabilities/account-identity/v1/contract.md#s-43-依据产出之后记录才过期) 的两支（故障注入支 ＋ 真并发支）——一次尝试走完 ②（依据已在手），让记录过期并跑清除链 ①，**然后**才调 ③；另让 ③ 与清除链 ① 在同一条已过期记录上并发提交 | **未执行** | 责任：提供者。**必须观察到** `account-record-expired`，**账号停在未激活**，本次尝试 `interrupted`；并发支两者**不会都成功**。**绝不能观察到**凭那份依据激活成功。**这是 [S-13](v1/contract.md#s-13-一个可用账号有且仅有一个个人组织) 第三个保护点的唯一真实证据**——模型里它对应 `ActivateOk` 的 `~expired`（变异 M6）。**两边不得各跑各的**：能力侧记「账号停在未激活」，本包记「发起者看到 `interrupted`」，证的是同一件事；`#S-43` 因此是本契约消费的 clause（[S-2](v1/contract.md#s-2-参与方与精确承诺)） |
| [S-25](v1/contract.md#s-25-装配给的保证-vs-协议须给的保证) 跨进程后由协议兑现的部分 | **本版不验证**：跨进程的新鲜度界尚未定义（[G-3](v1/contract.md#九已知缺口)） | 不适用 | 责任：架构设计。**本版一切结果只保留其单机范围，不得外推。**清除链把这条推进一格：[S-35](v1/contract.md#s-35-个人组织不会变成孤儿) 依赖「已过期」被两边各自现读到同一个答案 |

## 实际执行

**按时间倒序。上面那一组对应当前模型，下面那一组对应旧模型。**

| run id | 任务 id | 配置与范围 | 结果 | evidence |
|---|---|---|---|---|
| `2026-09-22-formal-tenant-domain-2` | `account-registration-v1-basic` | [`basic.cfg`](v1/formal/basic.cfg)：`Attempts = {a1, a2}`，`Failures` / `Abandoning` / `Expiring` **全 FALSE**，用 `SafeSpec`（**无公平性**） | **无反例**，退出 0；55 generated · 31 distinct · **0 left on queue**（完整穷尽）· 深度 7 | [原始输出](../../../record/evidence/2026-09-22-formal-tenant-domain-2/account-registration-v1-basic/output/tlc-basic.log) |
| 同上 | `account-registration-v1-crash` | [`crash.cfg`](v1/formal/crash.cfg)：`Attempts = {a1, a2, a3}`，三个常量**全 TRUE**，用 `SafeSpec` | **无反例**，退出 0；32170 generated · **6978 distinct** · 0 left · 深度 16 | [原始输出](../../../record/evidence/2026-09-22-formal-tenant-domain-2/account-registration-v1-crash/output/tlc-crash.log) |
| 同上 | `account-registration-v1-progress` | [`progress.cfg`](v1/formal/progress.cfg)：`Attempts = {a1, a2}`，`Failures`／`Abandoning` FALSE、**`Expiring = TRUE`**，用 `Spec`（**带公平性**：每次尝试的 `Organize`／`Activate` 各有 `WF_vars`，`Claim` **刻意不加**） | **无反例**，退出 0；491 generated · **187 distinct** · 0 left · 深度 12；时序性质 2 branches，在 **374** total distinct states 上检查完 | [原始输出](../../../record/evidence/2026-09-22-formal-tenant-domain-2/account-registration-v1-progress/output/tlc-progress.log) |
| `2026-09-22-formal-tenant-domain` | 同样三个任务 id | **对应旧模型**：`Activate` 守卫是 `orgCount >= 1`、无 `warrant`、无两条 `Rejected` 分支；`progress.cfg` 的 `Expiring = FALSE` | 当时也**全部无反例**：basic 55/31、crash **17600/4422**（深度 13）、progress 时序在 **62** total distinct states 上检查完 | [run README](../../../record/evidence/2026-09-22-formal-tenant-domain/README.md) |

**工具与环境**：两次相同——TLC2 2026.09.12.025210、Eclipse Adoptium 21.0.12.1，4 workers；
精确版本、主机、时间戳与命令重建说明在
[run `-2` 的 README](../../../record/evidence/2026-09-22-formal-tenant-domain-2/README.md#工具与环境)。
**输入快照逐文件带 SHA-256**，与本包版本目录下的同名文件逐字节相同（写本页时核对过）。
**退出码不在 TLC 日志里**，由主线执行时记录。

**`basic.cfg` 两次的数字逐项相同（55/31/0，深度 7），这不说明模型没变**：
新增的两条 `Rejected` 分支在 `Expiring = FALSE` 下都不可达，`warrant` 又与 `pc` 同步变化。
[这是读日志与模型得出的解释，run README 里写明了推理](../../../record/evidence/2026-09-22-formal-tenant-domain-2/README.md#三处数字必须单独解释否则会被读错)。

**run `-2` 没有做的，逐项写明**：

- **变异核对，本 run 一个都没登记**（评审轮一之后是八个）。
- **两个有效性核对，本 run 一个都没登记。**
- 上面两行的口径是**「修订者自报，未登记」**，不是「已通过」：那次执行无快照、无原始输出。
- **规范场景，一条都没演练。**

**上一次 run 那一行是历史记录，不是当前证据。**评审轮一改写了模型与 `progress.cfg`，
[本页开头已逐项写明改了什么](#验证覆盖与实际证据)；**它的结论不支持证据义务表里的任何一条**。
它留在这里是为了给出可比对的基线，**不得被引用为「这三个配置在当前模型上跑通过」**。

**三个配置的分工不因为都通过而合并。**`basic.cfg` 里
`NoOrphanPersonalOrganization` 是平凡的（清除链不发生），
它在那里的通过**不是** [S-35](v1/contract.md#s-35-个人组织不会变成孤儿) 的证据；
`progress.cfg` 关掉的两条（`Failures`／`Abandoning`）**就是** [S-19](v1/contract.md#s-19-有前提的进展) 的前提本身，
不是顺手关掉的——**`Expiring` 那一条不是前提，评审轮一已把它改为开着，run `-2` 跑的就是开着的版本**。

**这两次执行都不提升本契约的状态。**它仍是 `candidate`，未接受、未冻结。

## 结果与反例

### 反例：一条都没有

**对当前模型，只有一次运行**：[run `-2`](#实际执行)，三个配置**都没有找到反例**。
[2026-09-22 的第一次运行跑的是评审轮一改写之前的模型](#实际执行)——
它当时也全部无反例，**但那不是当前模型的结论**，只作可比对的基线。
**因此不要把「两次都没有反例」当作一句关于本契约的陈述**：它把一个已作废的结果算进了覆盖面。
下一次执行时按上表的列补行，另记：模型修订（未冻结时写明「未冻结，无 hash 可绑」）、
状态数与是否完整穷尽（有界或超时都要写明，**不能记成「通过」**）、
反例的原始 trace 位置与它对应的契约条款；
**变异核对与有效性核对的结果单独记**，不与正常运行混在一张表里。

记录多时按执行拆文件并从本页链接，原始产物归
[`record/evidence/`](../../../record/evidence/README.md)。

### 必须分开陈述的三类结果

1. **TLC 在给定配置下的检查结果**——只支持已建模且已执行的范围；
2. **规范场景在真实组合上的演练结果**——只支持实际观察到的边界行为；
3. **两个参与方契约各自的符合性**——不属于本包，不得用它们的结果替本包的义务收口。

三者不能跨范围互相冒充。尤其：**TLC 全绿不表示实现正确**，它连实现都没看见。

## 形式化工件

本包**选用 TLA+ 行为模型**，入口 [`v1/formal/README.md`](v1/formal/README.md)。

选它的理由不是「组合契约都该有个模型」，而是本契约
[以自定义的提交协议为依据省略了跨边界原子提交](v1/contract.md#s-24-内核不提供由本契约兑现的表)——
省略控制就要承接证明义务。**不选 Alloy、不建 Schema**，理由在
[S-26](v1/contract.md#s-26-本版选用的形式工件)。

三个配置的分工与「为什么不合并」在 [formal/README](v1/formal/README.md#三个配置各检查什么为什么要分开)。

## 变化的影响

- **已执行：architecture-reviewer 批次评审的处置**（2026-09-22）。非阻断 1：[S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 写死清扫提供者只发起本组合的清除链、不自持依据，因此 [S-22](v1/contract.md#s-22-编排本链的提供者被卸载或换代) 同样覆盖它，`purge-warrant-invalid` 不会因产出方换代而被误记为缺陷；非阻断 3：本页证据义务表**新增一行**「两个发起者在同一条记录上并发」（模型未建此交错，场景形式）。评审整体结论：批次的责任交接闭合，两条阻断均一处措辞／一行登记闭合，不触及能力边界。
- **已执行：能力拆分投票裁定落地（修正 2 部分）**（2026-09-22，依据
  [`record/proposals/tenant-capability-split/`](../../../record/proposals/tenant-capability-split/README.md#后续消费)
  的主线处置）。三票独立评审**全投维持五份拆分**，主线裁「A ＋ 修两处瑕疵」；
  **本轮只落地修正 2（改写拆分理由）**，修正 1（当前租户身份的存与取移交）未落盘，理由见下。
  **改动直接落在 v1 上**——本契约仍是 `candidate`，未接受、未冻结。
  **[`Registration.tla`](v1/formal/Registration.tla) 与三个 `.cfg` 一个字节没改**
  （它们建模的是注册三步与清除链的交错，**不涉及拆分理由的措辞**），因此
  [run `-2` 的三行结论全部仍然适用](#实际执行)。

  | 改的是什么 | 怎么改的 | 对证据的影响 |
  |---|---|---|
  | **[S-2](v1/contract.md#s-2-参与方与精确承诺) 后注「换一次认证方式就会把整个组织治理重启一遍」** | **整段改写成一张四行表。**那句话在契约层不成立——治理 inject 的是账号能力的读面，**账号提供者换代本来就会重跑治理**，那个方向合不合并都一样。四行分别是：**反方向的半径收敛**（只需要「来者是谁」的消费者不因治理换代重跑，[`capability.account-identity/v1#S-17`](../../capabilities/account-identity/v1/contract.md#s-17-校验登录状态)／[`#S-18`](../../capabilities/account-identity/v1/contract.md#s-18-读账号)）、**契约层的失败隔离**（[`capability.organization-governance/v1#S-43`](../../capabilities/organization-governance/v1/contract.md#s-43-依赖的提供者不可用)／[`capability.account-identity/v1#S-28`](../../capabilities/account-identity/v1/contract.md#s-28-依赖不可用撤除与重启时的在途归属)）、**SYS-DEPLOY 的分布式缝已逐条标价**（[`#S-30`](../../capabilities/account-identity/v1/contract.md#s-30-装配给的保证-vs-协议须给的保证)／[`#S-42`](../../capabilities/organization-governance/v1/contract.md#s-42-装配给的保证-vs-协议须给的保证)／本契约 [S-25](v1/contract.md#s-25-装配给的保证-vs-协议须给的保证)）、**账号身份非范围化**（[`#S-12`](../../capabilities/account-identity/v1/contract.md#s-12-账号身份事实不是范围化对象)、SYS-TENANT） | **不新增证据义务，不改任何承诺。**改的是一段设计理由的措辞，**没有动 [S-8](v1/contract.md#s-8-三步次序与责任交接) 的次序、[S-5](v1/contract.md#s-5-终结结果集合) 的终结结果集合、任何映射或提交点**。**catalog 不变**：新引的那批坐标是**拆分理由的依据**，不是本契约据以写出承诺、判定、映射或证据落点的条款，按[登记口径](../../README.md#当前状态)不登记为消费（正文已写明这一句），本契约的消费面仍以 [S-2](v1/contract.md#s-2-参与方与精确承诺) 的表为准 |

  **未落盘：修正 1（「当前租户身份」的存与取移交 `capability.account-identity`）。**
  它被一条硬约束挡住——当前租户身份的初值是「该账号的个人组织里的那个租户」，
  而个人组织的 `OrganizationId` **不可从 `AccountId` 派生**，是治理契约的事实；
  账号契约要算得出它就得消费治理读面，**依赖方向会翻转**。
  详见 [`capability.organization-governance` 的验证入口](../../capabilities/organization-governance/verification.md#变化的影响)。
  **本契约不受这项未决影响**：它的两条动作链都不读当前租户身份
  （清扫提供者[「不带任何租户身份」](v1/contract.md#s-2-参与方与精确承诺)，注册跑在账号可用之前）。

- **已执行：PF-001 升到 rev 15**（2026-09-22，
  [changelog rev 15](../../../product/PF-001-identity-scope-and-agent-constraints/changelog.md)）。
  **rev 15 只改 [flows §4](../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作) 成员名单那一行**
  （拆成「有效成员」与「已解除的成员」两行，后者只归超管），**本契约不受影响**——
  它引的七处**一处也不在 flows §4 那张表里，原文逐字未变**（逐处见下一条）。
  **[decisions §二那条「注册以激活为单一提交点」也特别核过](../../../product/PF-001-identity-scope-and-agent-constraints/decisions.md#二pm-推导)**：
  rev 15 在那一节只改了「两类邀约的读面归哪一类」那一行，**本契约引的这一条一字未动**。
  **注册这条链上没有任何角色矩阵能管的动作**：它跑在账号可用之前，那时还谈不上「本组织的成员」，
  更谈不上「已解除的成员」。
  **只改 rev 标注**：抬头与[缺口表下那句「本契约当前的设计依据」](v1/contract.md#九已知缺口)，
  `rev 14` → `rev 15`。**不新增证据义务，已有结论不受影响。**
- **已执行：PF-001 升到 rev 14**（2026-09-22，
  [changelog rev 14](../../../product/PF-001-identity-scope-and-agent-constraints/changelog.md)）。
  **rev 14 只改了 [flows §4 角色与操作](../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作) 那张表**
  （补三行读面授权，答的是 `capability.organization-governance/v1` 登记的缺口 G-11），
  **本契约不受影响**——它引的是 [§4 账号](../../../product/PF-001-identity-scope-and-agent-constraints/design.md#账号)、
  [§4 个人组织](../../../product/PF-001-identity-scope-and-agent-constraints/design.md#个人组织)、
  [§4 租户](../../../product/PF-001-identity-scope-and-agent-constraints/design.md#租户)、
  [§4 未激活的账号记录不会永久占着那个名字](../../../product/PF-001-identity-scope-and-agent-constraints/design.md#未激活的账号记录不会永久占着那个名字)、
  [flows §1.1](../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#11-注册)、
  [§2](../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常)、
  [§3.1](../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#31-账号)，
  **一处也不在 flows §4 那张表里，原文逐字未变**。
  **注册这条链上没有任何角色矩阵能管的动作**：它跑在账号可用之前，那时还谈不上「本组织的成员」。
  **只改 rev 标注**：抬头与[缺口表下那句「本契约当前的设计依据」](v1/contract.md#九已知缺口)，
  `rev 13` → `rev 14`。**不新增证据义务，已有结论不受影响。**
- **已执行：评审轮三修订**（2026-09-22，处置表在本轮任务区）。
  **本轮改动直接落在 v1 上**——本契约仍是 `candidate`，未接受、未冻结。
  **`Registration.tla` 与三个 `.cfg` 一个字节没改**，因此
  [run `-2` 的三行结论全部仍然适用](#实际执行)。逐条落成：

  | 评审发现与处置 | 本契约怎么改 | 对证据的影响 |
  |---|---|---|
  | **B1「终止型 × 主链就地发起」格（重跑 ① 一次、正常交错）与 [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 自己的推理（① 能跑 ⇒ 已过期、单调、③ 再也通不过）互斥** | 该格改为「**主链路径上不可达；出现 ⇒ 按缺陷型处置（`interrupted` 记缺陷），不重跑 ①**」；[S-8](v1/contract.md#s-8-三步次序与责任交接) 的过期分支、[映射表](v1/contract.md#参与方失败值到终结结果的映射)那一行、[S-12](v1/contract.md#s-12-重试规则) 第五行、[S-19](v1/contract.md#s-19-有前提的进展) 的边界句与 [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 的两行都改为「**重跑 ① 一次」只保留在清除链两步都 `ok`（含幂等）走完那一路**；「那条记录在这期间被激活了 ⇒ `identifier-taken`」那句删去 | **本表「失败分三类」那一行的主链列预期改写**（上表已改）：终止型三支在主链路径上不再是可构造的正常收场，只能靠故障注入伪造，观察到即记缺陷。**「① 最多重跑一次」那一行不变**——它本来就只在两步都 `ok` 那一路。**模型不改**：两步清除在模型里不区分发起者，主链那一列的处置不在模型语义里 |
  | **N1 清除链返回面的失败值枚举与两步的闭合集合对不上**（`unavailable` vs `storage-unavailable`、`invalidInput` vs `invalid-input`） | [映射表](v1/contract.md#参与方失败值到终结结果的映射)清除链行、[按发起者分的表](v1/contract.md#参与方失败值到终结结果的映射)、[S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 的分类表与 ② 存储不可用那一行，全部改为**十个值按本名带坐标**：[`#S-53`](../../capabilities/organization-governance/v1/contract.md#s-53-清除未激活账号的个人组织) 六个（`accountIsActivated`／`accountNotExpired`／`organizationIsNotPersonal`／`accountDoesNotExist`／`invalidInput`／`unavailable`），[`#S-38`](../../capabilities/account-identity/v1/contract.md#s-38-清除到期的未激活账号记录) 四个（`not-expired`／`purge-warrant-invalid`／`invalid-input`／`storage-unavailable`） | **本表「失败分三类」那一行改按十个本名逐支制造**；此前没有已执行的场景证据，无旧结果需要重判 |
  | **N2「以凭据合规为条件」只加在 [S-12](v1/contract.md#s-12-重试规则) 第五行** | 提到表抬头：各行都以本次凭据合规为条件，唯一例外是第三行（幂等认回只比对不重判） | 无（那一支的演练归 `capability.account-identity` 的 [S-34](../../capabilities/account-identity/v1/contract.md#s-34-同标识两路对比)） |
  | **N3 清除链返回面只定义了失败侧** | [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 写明：成功 ≝ 两步都 `ok`（含幂等）；返回面 = `ok` ｜（参与方失败值原样，三分类）；[S-9](v1/contract.md#s-9-幂等边界) 同句 | 无新增义务；**本表「清除链走得通且可重扫」那一行的预期此后可写成 `ok`** |
  | **N4 [formal/README](v1/formal/README.md#本版本选用什么) 引 [`#S-41`](../../capabilities/account-identity/v1/contract.md#s-41-未激活记录到期释放标识) ④⑤／[`#S-42`](../../capabilities/account-identity/v1/contract.md#s-42-伪造的依据两侧都被拒) 第 1 支、本页引 [`#S-43`](../../capabilities/account-identity/v1/contract.md#s-43-依据产出之后记录才过期)，S-2 却没登** | 按「引用即消费」：[S-2](v1/contract.md#s-2-参与方与精确承诺) 的 account-identity clauses 补 `#S-41`／`#S-42`／`#S-43`，[包入口](README.md)同步；formal/README 写明「不自设场景」不等于「不消费」；本页 [`#S-14` 前置③那一行](#证据义务)补 `#S-43` 坐标并写明两边是同一次演练的两面 | 无新增义务。**catalog 那一侧由主线同步**（写本页时核对：`catalog.json` 里对 `capability.account-identity` v1 的依赖项已是九条，与 [S-2](v1/contract.md#s-2-参与方与精确承诺) 一致） |
  | **跨包同改 1 撤销「清除依据一次性」**（轮三处置表） | [S-2](v1/contract.md#s-2-参与方与精确承诺) 保证列与[激活依据由谁产出](v1/contract.md#激活依据由谁产出绑定什么)改为「凭证只绑定 AccountId、不绑定尝试、不作废」，「同一次尝试内产出即用」降为 S-8 ② 的流程规则；`Registration.tla:224` 注释有意留置（保住 run `-2` 输入快照逐字节相同），formal/README 已用文字说明 | **无新增义务**；本包此前从未登记作废义务 |

  **本包此前在规范场景上没有任何已执行证据，因此本轮没有旧场景结果需要重判；
  TLC 那三行因为模型未改而全部仍然适用。**

- **已执行：评审轮二修订**（2026-09-22，处置表在本轮任务区）。
  **本轮改动直接落在 v1 上**——本契约仍是 `candidate`，未接受、未冻结。
  **`Registration.tla` 与三个 `.cfg` 一个字节没改**，因此
  [run `-2` 的三行结论全部仍然适用](#实际执行)。逐条落成：

  | 评审发现与处置 | 本契约怎么改 | 对证据的影响 |
  |---|---|---|
  | **阻断 1 清除链失败值有三种互相矛盾的终结答案**（[S-8](v1/contract.md#s-8-三步次序与责任交接) 的过期分支说 `interrupted`、[S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 的分类表说「整条链终止」、[失败值映射表](v1/contract.md#参与方失败值到终结结果的映射)说「不产生终结结果」） | [映射表](v1/contract.md#参与方失败值到终结结果的映射)末行**按发起者拆成两列**：**主链就地发起**——终止型 ⇒ **重跑 ① 一次、以重跑结果终结**（通常 `identifier-taken`），缺陷型 ⇒ `interrupted` 并记缺陷，抖动型 ⇒ `interrupted`；**清扫发起**——三类都**不产生终结结果**。[S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 的分类表随之由两类改三类，`purge-warrant-invalid`（抖动→缺陷）与 `organizationIsNotPersonal`（终止→缺陷）改判 | **本表那一行重写**：每一支都要在两个发起者下各跑一次。**分类改判使两支的预期收场改变**，但此前没有任何已执行的场景证据，**没有旧结果需要重判** |
  | **阻断 2 [`#S-53`](../../capabilities/organization-governance/v1/contract.md#s-53-清除未激活账号的个人组织) 的 `accountDoesNotExist` 在本契约没有落点** | 治理侧把求值次序改为「先读账号；账号不存在再看组织：**组织也不存在 ⇒ `ok`（幂等、产出依据）**，组织仍在 ⇒ `accountDoesNotExist`（缺陷观测）」。本契约 [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 的 ① 因此补**两行**：都不在 ⇒ 幂等走完，组织仍在 ⇒ 缺陷型、停在本步。[映射表](v1/contract.md#参与方失败值到终结结果的映射)另加一张小表**区分 [`#S-20`](../../capabilities/organization-governance/v1/contract.md#s-20-创建个人组织) 与 [`#S-53`](../../capabilities/organization-governance/v1/contract.md#s-53-清除未激活账号的个人组织) 的同名 `accountDoesNotExist`**；[S-35](v1/contract.md#s-35-个人组织不会变成孤儿) 写明它是那条不变量**唯一的运行期观测点** | **本表新增一行**（① 的两支「账号记录不存在」，两支同跑）。**模型不改**：`ExpireOrganization` 对「已清过」本来就幂等，新旧两支在模型的抽象里是同一个转移 |
  | **阻断 3 依据仍标 PF-001 rev 12** | 抬头改 **rev 13**，并写明 rev 13 §4 的「个人组织与第一个租户随之消失」正是[清除链两步合起来要兑现的那一条](v1/contract.md#s-34-第二条动作链未激活到期清除)；§九那句「本版关掉了一条缺口」改为「关掉它的是 rev 12，本契约当前依据是 rev 13」 | 无新增义务，见下面那条复核 |
  | **阻断 4 [S-19](v1/contract.md#s-19-有前提的进展) 的 ① 过期支不在 `EventualOutcome` 前件内，而契约与 formal/README 有两种读法** | **取（甲）**：[S-19](v1/contract.md#s-19-有前提的进展) 与 [formal/README](v1/formal/README.md#本版本选用什么) 都写明——那一支的尝试**留在 `"start"`**，前件是 `pc[a] # "start"`，**TLC 对它什么也没说**；进展由 [S-8](v1/contract.md#s-8-三步次序与责任交接) 的分支表承担，**证据是本表登记的规范场景**。语义映射另统一两句：**两步清除动作不区分发起者**（主链就地与清扫映射到同一对动作）、**「重跑只做一次」不建模** | **`Registration.tla` 语义不改**（这是（甲）的全部要点）。**本表 [S-19](v1/contract.md#s-19-有前提的进展) 那一行加了一句边界**，另新增「① 最多重跑一次」一行——**那条规则不是不变量，破坏它不会违反模型检查的任何一条性质** |
  | **5 [G-7](v1/contract.md#九已知缺口) 已闭合；[S-2](v1/contract.md#s-2-参与方与精确承诺) 的 clauses 漏 `#S-19`／`#S-39`；对 `#S-35` 是「消费」不是「间接消费」** | [G-7](v1/contract.md#九已知缺口) 标闭合（catalog 已登记 `data.identity-values` v1 的 `S-1`／`S-2`／`S-35`）；[S-2](v1/contract.md#s-2-参与方与精确承诺) 的 account-identity 行补 `#S-19`／`#S-39`；抬头把 `#S-35` 写成一条正式消费并给出它撑着哪条推理 | 无 |
  | **6 [formal/README](v1/formal/README.md#本版本选用什么) 的 [S-19](v1/contract.md#s-19-有前提的进展) 行写「前提 (a)(b)」** | 改为 **(b)(c)**（`Abandoning = FALSE` 是 (b)、`Failures = FALSE` 是 (c)），**(a) 由前件 `pc[a] # "start"` 承接**，不需要常量 | 无——**这是表述错，不是范围错**；`progress.cfg` 的常量取值一个没变，run `-2` 的结论照旧 |
  | **7 本页 [`#反例一条都没有`](#反例一条都没有) 与 [`#变化的影响`](#变化的影响) 各有一处旧模型残留** | 「两次运行都没有反例」改为「**对当前模型只有 run `-2` 一次**，第一次那轮只作基线」；「新增的场景义务逐条列在表尾」改为「**各就各位，按所属条款排**」 | 无 |
  | **8 清除链对清扫提供者的返回面没写** | [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 写明：返回 = **参与方失败值原样 ＋ 三分类标签**，不翻译不归并；[S-5](v1/contract.md#s-5-终结结果集合) 的四个值**不适用于本链**；「不发回执」指的是**不对注册发起者说话** | 无新增义务；**本表「失败分三类」那一行的预期因此可写成可观察的形状** |
  | **9 [`#S-13`](../../capabilities/account-identity/v1/contract.md#s-13-产生账号未激活) 的失败值优先级** | 能力侧定序**表示层 → 凭据合规 → 占用判定**；本契约 [S-12](v1/contract.md#s-12-重试规则) 第五行注明**以凭据合规为条件**，并点明「匹配与否」不是「合规与否」 | 无新增义务（那一支的演练归 `capability.account-identity` 的 [S-34](../../capabilities/account-identity/v1/contract.md#s-34-同标识两路对比)） |
  | **10 `covers.json` 的 `acceptance.md#三判据` 行缺 [S-12](v1/contract.md#s-12-重试规则)／[S-34](v1/contract.md#s-34-第二条动作链未激活到期清除)** | **不在本包**：登记在 registry；评审轮二后已由主线补登记（2026-09-22），[G-7](v1/contract.md#九已知缺口) 的说明同步 | 无 |
  | **11 [formal/README](v1/formal/README.md#本版本选用什么) 两处场景坐标空着** | 填上 [`capability.account-identity/v1#S-41`](../../capabilities/account-identity/v1/contract.md#s-41-未激活记录到期释放标识) 的 **④⑤** 与 [`#S-42`](../../capabilities/account-identity/v1/contract.md#s-42-伪造的依据两侧都被拒) 的第 1 支，并写明**本契约有意不自设清除链依据的场景**——那三支检查的是 [`#S-38`](../../capabilities/account-identity/v1/contract.md#s-38-清除到期的未激活账号记录) 的前置，属那份能力契约的义务 | 无新增义务；**本包在清除链上的义务仍是跨两步的那几条** |

  **本包此前在规范场景上没有任何已执行证据，因此本轮没有旧场景结果需要重判；
  TLC 那三行因为模型未改而全部仍然适用。**

- **已执行：PF-001 升到 rev 13**（2026-09-22，[changelog](../../../product/PF-001-identity-scope-and-agent-constraints/changelog.md)）。
  **本契约引的正文逐条复核过**，结论是**条款一条没改，但清除链多了一条正向依据**：

  | 本契约引的哪一处 | rev 13 动了什么 | 复核结论 |
  |---|---|---|
  | [design §4 未激活的账号记录不会永久占着那个名字](../../../product/PF-001-identity-scope-and-agent-constraints/design.md#未激活的账号记录不会永久占着那个名字) | 补上「为它准备的**个人组织与第一个租户随之消失**」 | **这是[清除链](v1/contract.md#s-34-第二条动作链未激活到期清除)的产品依据，此前只能从 flows §3.1 推**。rev 13 把它写成正文之后，「为什么要清两样、为什么先清组织」有了直接出处。**条款不变**——两步的次序与幂等边界早就是这个形状 |
  | [flows §3.1 账号](../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#31-账号) | 状态表那一行补「**为它建的个人组织与第一个租户随之消失**」 | 与上一条同一件事，**与 [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 逐字对上** |
  | [flows §2 分支与异常](../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常) | 「已过留存期限」那一行改为「**那条记录连同它的个人空间被清掉，标识释放，按新注册走（用户不需要等任何清扫）**」 | **正向依据**：它逐字对上[本组合就地接手那条分支](v1/contract.md#撞上一条已过期的记录时为什么由本组合接手)。「用户不需要等任何清扫」这半句坐实了 [G-6](v1/contract.md#九已知缺口) 的降级——**清扫不承担任何验收判据** |
  | [design §2 非目标](../../../product/PF-001-identity-scope-and-agent-constraints/design.md#非目标) | 「账号与组织的终止」一行写明**个人组织到期清除是那条里的例外，且不是一条终止路径** | **本契约不受影响**：[S-3](v1/contract.md#s-3-本契约明确不承诺什么) 的「不承诺回滚、不删已提交的事实」讲的是**已激活**那一侧，与这个例外不冲突 |

  **对证据的影响：无。**模型与配置都不改，没有新增义务，也没有旧结果需要重判。

- **已执行：评审轮一修订**（2026-09-22，处置表在本轮任务区）。
  **本轮改动直接落在 v1 上**——本契约仍是 `candidate`，未接受、未冻结。
  逐条落成：

  | 评审发现与处置 | 本契约怎么改 | 对证据的影响 |
  |---|---|---|
  | **B-1 真洞：旧激活依据在个人组织被清之后仍能激活**（⇒「已激活 ∧ 无个人组织」；**模型把 `Activate` 的守卫写成 `orgCount >= 1`，正好把它藏住了**） | [`capability.account-identity/v1#S-14`](../../capabilities/account-identity/v1/contract.md#s-14-激活账号) 新增前置③与失败值 `account-record-expired`（在激活自己那一次提交里现读单调事实）；本契约 [S-8](v1/contract.md#s-8-三步次序与责任交接) 的 ③ 分支、[S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 的交错表、[S-35](v1/contract.md#s-35-个人组织不会变成孤儿) 的前提由两条改为**三条**同步 | **模型改了**：`Activate` 拆成 `ActivateOk`（守卫 `warrant[a] ∧ ~expired`）与 `ActivateRejected`，新增 `warrant` 变量（按 `Attempts` 索引，`OrganizeOk` 置真、`ClaimFresh` 清零）。**变异核对由七个增到八个**：原「去掉 `orgCount >= 1`」换成 **M6（去掉 `~expired`）** 与 **M7（去掉 `warrant[a]`）**。**上一次运行的三行结论全部作废** |
  | **B-1（能力侧）到期即可重新注册不依赖清扫** | [`#S-13`](../../capabilities/account-identity/v1/contract.md#s-13-产生账号未激活) 新失败值 `identifier-held-by-expired-record`；本契约 [S-8](v1/contract.md#s-8-三步次序与责任交接) 新增一条**不终结**的分支（就地跑清除链再重跑 ①）、[S-12](v1/contract.md#s-12-重试规则) 第五行改写、[S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 写明**两个发起者** | **模型改了**：`ClaimExpired(a)` 守卫谓词从 `ClaimTaken` 里减出去，那一格不再终结为 `identifier-taken`。**新增一条场景义务**（见下表尾） |
  | **B-3 参与方失败值没有终结结果** | [S-8](v1/contract.md#s-8-三步次序与责任交接) 新增[失败值 → 终结结果映射表](v1/contract.md#参与方失败值到终结结果的映射)，含「组合缺陷／入口缺陷」的另记要求；②③各补 `Rejected` 分支 | **模型改了**：`OrganizeRejected` 与 `ActivateRejected` 两支。**新增一条场景义务**：逐个参与方失败值核对终结结果 |
  | **B-6 [S-19](v1/contract.md#s-19-有前提的进展) 的前提三处不一致、(d) 未建模** | 补完 B-3 的分支之后实测 `progress.cfg` 开 `Expiring`：**通过**，因此**删掉那条前提**，`progress.cfg` 改为 `Expiring = TRUE`；契约、`formal/README`、`progress.cfg` 三处统一；**(d) 未建模如实写进 formal/README** | **配置改了**，`progress.cfg` 的结论范围随之改变；**(d) 的证据形式明确落到规范场景 [S-29](v1/contract.md#s-29-规范场景参与方缺席时不放行)** |
  | **B-2 激活依据无产出端**（本行「绑定 AccountId 与本次尝试、不跨尝试复用」的口径已由评审轮三撤销：凭证只绑定 AccountId） | [S-8](v1/contract.md#s-8-三步次序与责任交接) 的 ② 写明依据由**本组合**在 `#S-20` 成功返回（**含幂等返回既有组织**）时产出，绑定 AccountId 与本次尝试、不跨尝试复用；「个人组织存在可读」= `#S-20` 的幂等返回，不另需读面 | **新增一条场景义务**：幂等那一路**也要**产出依据 |
  | **B-4 `#S-20` 的 ②／⑥／⑦ 三处冲突** | 取⑦：[S-2](v1/contract.md#s-2-参与方与精确承诺) 与 [S-8](v1/contract.md#s-8-三步次序与责任交接) 改为「幂等返回既有个人组织，不报错」 | 无 |
  | **B-5 37 处裸 `#S-n`** | 全部补上坐标与链接；抬头加一句「本页此后每一个 `#S-n` 都带坐标」 | 无 |
  | **N-2 对 `data.identity-values` 的依赖没登记** | 抬头新增「精确语义依赖」一节（`#S-1`／`#S-2`，另有对 `#S-35` 的间接消费），并登记 [G-7](v1/contract.md#九已知缺口) | **catalog 要补一条依赖项**，见 [G-7](v1/contract.md#九已知缺口) |
  | **N-4 清除链的消费者没写** | [S-2](v1/contract.md#s-2-参与方与精确承诺) 增「清扫提供者」一行（输入只有 AccountId、**不带租户身份**、不承担正确性）；[S-25](v1/contract.md#s-25-装配给的保证-vs-协议须给的保证) 写明「`#S-53` 只由本组合调用」是**装配给** | **[S-25](v1/contract.md#s-25-装配给的保证-vs-协议须给的保证) 的结构检查范围扩大** |
  | **N-6 `not-expired` 在 ② 那个位置的来源** | 推理写进 [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除)：它只可能来自「已激活」，而补上 `#S-14` 前置③之后**这一支变得不可达**，因此改为「只报不改」的观测点 | **这一支不再需要场景演练**，改为「观察到即为一次契约违反」 |
  | **N-7／范围外 4 到期释放没有上界** | 由 B-1 的裁决消解：[验收判据不再依赖清扫](v1/contract.md#撞上一条已过期的记录时为什么由本组合接手)；[G-6](v1/contract.md#九已知缺口) 的清扫**降级为卫生义务** | **[G-6](v1/contract.md#九已知缺口) 不再阻断任何验收判据** |
  | **N-8／N-9 表述** | [S-25](v1/contract.md#s-25-装配给的保证-vs-协议须给的保证) 补清除链两行；[S-6](v1/contract.md#s-6-每个终结结果的含义与对应的存储状态) 的「三种」改为「四行、三种」并说明 | 无 |

  **新增的场景义务在[证据义务表](#证据义务)里各就各位，不集中在表尾**——
  按它们所属的条款排，[S-8](v1/contract.md#s-8-三步次序与责任交接) 的几条挨着 [S-8](v1/contract.md#s-8-三步次序与责任交接)，
  [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 的几条挨着 [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除)。
  **本轮之后 TLC 跑过一次**：[run `2026-09-22-formal-tenant-domain-2`](#实际执行)，三个配置全部无反例。
  [评审轮一之前那次运行的结论不再适用](#实际执行)——模型与 `progress.cfg` 都改了。
  **变异与有效性核对仍未登记。**

- **已执行：两份参与方契约成稿，[S-2](v1/contract.md#s-2-参与方与精确承诺) 的消费面改用真实条款号**（2026-09-22）：
  ① = `capability.account-identity/v1#S-13`、③ = `#S-14`、读激活状态 = `#S-18`、
  ② = `capability.organization-governance/v1#S-20`。
  逐条核对过「向本组合提供的保证」：`#S-13` 的幂等边界是登录标识、`#S-14` 对已激活无二次效果、
  `#S-20` 在单次提交内产生组织＋有效成员关系＋超级管理员且**明写不要求账号已激活**——
  与本表原有的三行保证**逐条对上，没有冲突**。**本契约语义不变，不需要新版本**；已有证据（当前为空）不受影响。
- **已执行：PF-001 升到 rev 12**（2026-09-22，[changelog](../../../product/PF-001-identity-scope-and-agent-constraints/changelog.md)）。
  **本轮改动直接落在 v1 上，不发布第二个版本**——本契约仍是 `candidate`，
  未接受、未冻结，[不可原地覆盖的是已发布规格](../../README.md)。
  **这一条推翻了本文件更早一版写的「须发布新版本」**：那句话的前提是本契约已发布，而它没有。
  （**catalog 已于当日晚些时候登记**，状态仍是 `candidate`，资源未进 `frozen.json`——
  **登记不是发布**，这句推理不受影响。）

  | 改的是什么 | 怎么改的 | 对证据的影响 |
  |---|---|---|
  | **缺口 G-2 被产品关掉**（未激活记录有了留存期限） | [S-3](v1/contract.md#s-3-本契约明确不承诺什么) 的「不承诺清理」改写：不按「多久没动」清、也不承诺任何记录一定被清掉，但**有了一条以期限为判据的动作链**；新增 [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除)（第二条动作链）与 [S-35](v1/contract.md#s-35-个人组织不会变成孤儿)（新不变量）；[S-6](v1/contract.md#s-6-每个终结结果的含义与对应的存储状态) 的存储状态表加一行、[S-9](v1/contract.md#s-9-幂等边界) 的①幂等边界加上期限那一半、[S-12](v1/contract.md#s-12-重试规则) 的表加两行 | **模型改了**：新增 `expired`（单调）与 `sweep` 两个变量、三个动作（`Expire`／`ExpireOrganization`／`ExpireAccount`）、一条不变量 `NoOrphanPersonalOrganization`、一个常量 `Expiring`；三个配置各加一行常量，`crash.cfg` 打开它。**旧模型的结论对新模型不适用**（本包本来也没有旧结论——一次都没跑过）。**变异核对由五个增到七个** |
  | **交错分析推出的一条新前置** | `capability.organization-governance/v1#S-20` 增加前置「该账号记录未过留存期限」与失败值 `accountRecordExpired`；`capability.account-identity/v1#S-18` 的返回值增加「是否已过留存期限」并写明**它是单调的** | **这条不是产品正文写的，是本轮从交错走查里推出来的**：没有它，清除链 ① 与注册主链 ② 的交错会留下一个谁也到不了、谁也再清不掉的个人组织。[S-35](v1/contract.md#s-35-个人组织不会变成孤儿) 的**第二个前提**就是它，**前提失效则该不变量失效**；变异核对里有专门一格抓这个洞 |
  | **主线裁定：让运行期与模型守卫对得上** | ① `capability.organization-governance/v1#S-53` 补前置「已过留存期限」＋失败值 `accountNotExpired`，并在成功（含幂等成功）时**产出清除依据**；② `capability.account-identity/v1#S-38` 把「持有与该 AccountId 绑定的清除依据」写成前置，失败值加 `purge-warrant-invalid`。本契约随之改：[S-2](v1/contract.md#s-2-参与方与精确承诺) 两侧保证与前提、[S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 的四列表（加两行失败分支＋**终止型／抖动型**分类表）、次序那一节（依据＝次序的运行期对应物）、[S-35](v1/contract.md#s-35-个人组织不会变成孤儿) 的前提由一条变两条 | **[S-35](v1/contract.md#s-35-个人组织不会变成孤儿) 的两个前提此后都有运行期对应物**：次序靠依据、窗口靠 `accountRecordExpired`。**证据因此从「只能靠模型」变成「可以真跑」**——新增三条场景义务（跳过 ① 直接调 ②、四种失败分两类、依据的产出条件）。**`Registration.tla` 不改**：`sweep = "orgCleared"` 那条守卫的语义正是这份依据，两个变异核对照旧 |

  **[S-19](v1/contract.md#s-19-有前提的进展) 的进展性质不受影响，也没有被加强。**
  清除链**不在它的前提里**：本契约仍然不承诺任何一条到期记录会被清掉，
  [谁来跑清扫归装配](v1/contract.md#九已知缺口)（新登记的缺口 G-6）。
- **已执行：两份参与方契约在 catalog 登记**（2026-09-22，[G-4](v1/contract.md#九已知缺口) 就此闭合）：
  [S-2](v1/contract.md#s-2-参与方与精确承诺) 已写明的 `coordinate` 与 `clauses`
  逐字抄进依赖项（`capability.account-identity` v1 取 `S-13`／`S-14`／`S-18`／`S-38`，
  `capability.organization-governance` v1 取 `S-20`／`S-53`），**语义不变，不需要新版本**。
  参与方**仍是两个**；三份契约都还是 `candidate`，
  **因此「依赖已登记」不等于「依赖可用」**。
  此后那两份契约若改了被消费的条款，回到能力契约解决，**不在这里改条款**。
- **产品对回执未送达给出表现**（[G-1](v1/contract.md#九已知缺口)）：
  若产品确认「按既有条款推论办」，本契约不变，模型不变；
  若产品要求回执可补发或重来时给不同提示，那是**新的产品规则**，语义改变，**须发布新版本**，
  模型的 `Activate` 第二分支与 `ConvergentOutcome` 都要重判。
- **清扫的发起方式与节奏定下**（[G-6](v1/contract.md#九已知缺口)）：
  [S-34](v1/contract.md#s-34-第二条动作链未激活到期清除) 的条款不变，
  但[那条进展性质](v1/contract.md#s-19-有前提的进展)**可能第一次有上界**；
  若真给出上界，它要写成有界形式并另加一条时序性质，**语义扩张，须发布新版本**。
  **在此之前不得把「记录终将被清掉」当作任何条款的保护点。**
- **跨进程演化**（[G-3](v1/contract.md#九已知缺口)）：
  [S-25](v1/contract.md#s-25-装配给的保证-vs-协议须给的保证) 右列三条从「装配给」转为「协议给」，
  **语义边界改变，须发布新版本**；本版模型的单机假设全部失效，不得外推。
- **凭据合规规则定下**（[G-2](v1/contract.md#九已知缺口)）：
  `credential-rejected` 的语义不变，本契约**不需要新版本**，模型也不变。

结果不改写规范。发现语义问题回到来源设计（PF-001），不在这里改契约。
