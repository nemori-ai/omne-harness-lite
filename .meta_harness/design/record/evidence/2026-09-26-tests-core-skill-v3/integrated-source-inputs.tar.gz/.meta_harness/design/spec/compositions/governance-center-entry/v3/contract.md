# composition.governance-center-entry v3

- 基线 omne-harness-lite-design-2026-09-15；版本3，candidate；未接受、未冻结，旧消费者不自动升级。
- PF-001 rev18、PF-016 rev7、PF-017 rev5；AI3/OE2 已由 D040 接受，OG2已由D042接受；AR2已由D043接受，HT2绑定由D044接受，不据本稿开放生产。
- 保留 v2 S-1～S-54 的业务性质和 31 条业务路由；新增 S-55～S-59 在线备份、本机维护与隔离生命周期。PF-017 rev5 为本增量输入；技术契约仍为候选。
- 公共体检的路由字面及答复保持 v1，属于 S8 的跨版本稳定面；其他路由按本版精确依赖命名，无旧版别名。

## 一、含义与使用范围

### S-1 本契约拥有什么

本契约拥有**客户端 ↔ [治理中心](../../../../ubiquitous_language/terms/grounding-and-isolation.md#ul-governance-center--治理中心--governance-center)这条边在中心一侧的整体性质与交接**：

| 拥有 | 条款 |
|---|---|
| 请求信封、出示物、四种入口答复、答复集合的闭合 | [S-4](#s-4-请求信封)～[S-9](#s-9-列表句柄) |
| 判定次序：版本 → 认人 → 身份推导 → 补授权 → 路由到领域操作；「判不了优先于无效」 | [S-10](#s-10-判定次序)～[S-14](#s-14-失败映射) |
| 每个请求现读、入口不跨请求缓存（中心一侧 δ = 0）；不记住来访、不区别对待来者 | [S-15](#s-15-δ--0每个请求现读入口不跨请求缓存)、[S-16](#s-16-不记住来访不区别对待来者) |
| **封闭的路由表**：逐条投影三份契约的操作，每条写明身份怎么推、补什么授权、失败怎么映射；有意不投影的清单 | [S-17](#s-17-路由表封闭每条路由的九件事从哪读)～[S-24](#s-24-有意不投影) |
| 公开体检；运维面（只在中心所在的机器上、没有治理路由）与完整体检 | [S-18](#s-18-公开体检)、[S-25](#s-25-运维面只在中心所在的机器上且没有治理路由)、[S-26](#s-26-完整体检) |
| [治理中心标识](../../../../ubiquitous_language/terms/grounding-and-isolation.md#ul-governance-center-identifier--治理中心标识--governance-center-identifier)的形状、相等、铸造与存放 | [S-27](#s-27-governancecenterid-的形状与相等)、[S-28](#s-28-铸造存放与不变) |
| 输出枚举与工程记录的边界 | [S-29](#s-29-秘密不进任何输出)、[S-30](#s-30-工程记录) |
| 这条边的「装配给 vs 协议给」 | [S-36](#s-36-装配给的保证-vs-协议须给的保证) |

新增维护组合拥有在线一致副本、持久发布、文件校验、隔离恢复及维护在途责任（S-55～S-59）。文件校验与隔离恢复是同一运维者的本机工具，不是第三张治理面。

**本契约不拥有任何治理语义。**账号、登录状态、组织、成员资格、邀约、当前租户身份的全部判定仍在各自的能力契约里；
本契约只决定**一个到达中心的请求按什么次序被判、以谁的身份交给哪一个领域操作、领域的答复怎样变成线上的答复**。

### S-2 参与方与精确承诺

| 参与方 | 精确消费条款 | 向本组合提供什么 |
|---|---|---|
| capability.account-identity v3（D040 accepted） | S-3、S-8、S-10、S-13、S-14、S-15、S-16、S-17、S-18、S-20、S-26、S-28、S-29、S-30、S-37、S-38、S-44、S-45、S-46、S-48、S-49、S-50、S-51、S-52、S-54 | 账号不透明材料/政策、有界登录与出示物交换、句柄来源、登录列表、主动改密、活动/参与边界、迁移、已授权邀请解析；不消费单独账号产生/激活/清除，它们归注册组合 |
| capability.organization-governance v2（D042 accepted） | S-10、S-11、S-16、S-21、S-22、S-23、S-24、S-25、S-26、S-27、S-28、S-29、S-30、S-31、S-32、S-33、S-34、S-35、S-36、S-37、S-42、S-53、S-55、S-56、S-57、S-58、S-59、S-60、S-61、S-62、S-63、S-64 | 组织/成员/邀约操作与现读、两个拒绝、共同参与；输入身份由本入口核实，不从网络直接信任 |
| composition.account-registration v2（D043 accepted） | S-2、S-4、S-5、S-6、S-8、S-12、S-22、S-23、S-25、S-36 | 独立注册链四终结与重发；提交未确认不证明无效果；同一受限调用面及原凭证信任关系，完整在途工作按各提交拥有者收场 |
| data.identity-values v1 | S-1、S-2、S-3、S-4、S-7、S-8、S-9、S-10、S-11、S-12、S-16、S-17、S-18、S-19、S-20、S-21、S-23、S-27、S-28、S-30、S-31、S-33 | 身份交换形状、相等、默认拒绝、隔离与准入现读；expectedTenant同样按TenantId结构相等 |
| data.offer-expiry v2（D040 accepted） | S-4、S-7、S-8、S-9、S-12、S-13、S-14、S-15、S-16、S-17、S-20、S-22 | 时间/状态线上形状、五值状态、不可用与严格到期规则、时长与计算溢出、同源时间及同提交前提 |

引用符号AI/OG/OE分别指以上精确版本；AR指v2。能力操作的授权/失败仍归它们，入口不自行扩展。AR2 已接受；本候选还须新维护传输绑定与提供者映射采用。存储维护的受消费要求由 S-59 明列，不另造能力契约。

**消费者**（本契约的兑现者与使用者，不是参与方）：兑现客户端一面与运维面的**入口层**（无词条），实现映射节点是 [`realization/packages/tenancy/governance-center-entry`](../../../../realization/packages/tenancy/governance-center-entry/README.md)（当前实现仍旧版）；
承载它的装配 [`realization/apps/tenancy-host`](../../../../realization/apps/tenancy-host/README.md)（本版整装仍待实施）；据点一侧的客户端代理 [`realization/apps/cli`](../../../../realization/apps/cli/README.md)（不在本程实施边界）。

### S-3 本契约明确不承诺什么

- **送达。**请求—答复，答复丢了由客户端重发；本契约不承诺任何一次答复送达，也不提供按请求去重（各路由的重发语义见 [S-17](#s-17-路由表封闭每条路由的九件事从哪读) 的第 5 件事）。
- **推送。**中心从不主动向据点发任何东西（[PF-016 §5.6](../../../../product/PF-016-cli-tui-delivery-surface/design.md#56-哪些东西在中心一侧哪些在据点一侧)）。领域能力的通知事件**不上线**。
- **限流与背压。**[产品非目标](../../../../product/PF-017-governance-center-as-deployable-application/design.md#非目标)。
- **跨协议版本的兼容窗口。**对不上就明说（[S-8](#s-8-协议版本与跨版本不变的两样)），不承诺新中心配旧客户端或反之。
- **传输机制。**信封与答复怎样落到某种传输上（头、路径、状态码、体、帧）归实现映射；本契约只约束[那次落地必须保持的性质](#s-4-请求信封)与[跨协议版本不变的两样](#s-8-协议版本与跨版本不变的两样)。传输绑定作为版本化工件发布之前，是缺口 [G-10](#十三已知缺口)。
- **防冒充的具体手段。**「客户端确认连上的真是那个中心」是[产品交给技术设计的硬要求](../../../../product/PF-017-governance-center-as-deployable-application/design.md#八边界与依赖)，归传输那一层；它用到的材料是部署配置输入，**不是**[部署密钥](../../../../ubiquitous_language/terms/grounding-and-isolation.md#ul-deployment-key--部署密钥--deployment-key)。本契约既不兑现它，也不以它为任何条款的前提；手段与它的验证义务是缺口 [G-11](#十三已知缺口)。
- **会话。**路由表里没有任何会话操作；中心不知道任何会话（[PF-016 §4 治理中心](../../../../product/PF-016-cli-tui-delivery-surface/design.md#治理中心)：来往里没有会话）。
- **时序侧信道。**与 [`capability.account-identity/v3#S-3`](../../../capabilities/account-identity/v3/contract.md#s-3-明确不承诺什么) 同一口径：「逐字相同」只约束答复本身，不约束耗时。
- **客户端一侧。**标识比较、「问不到」的呈现、三类现读的放行归 PF-016；本契约只给它们判定依据。
- **存储里的登录状态不可被直接冒用。**这一条**由账号能力兑现，不由本组合兑现**：存储与备份里只有出示物的不可逆形式（[AI S-45](../../../capabilities/account-identity/v3/contract.md#s-45-登录状态出示物)），本组合也不保存出示物（[S-5](#s-5-出示物)）。历史 `composition.governance-center-entry/v1#G-1`（[v1 缺口表](../v1/contract.md#十三已知缺口)）因此闭合；不是本版表示候选采用的 G-1。

## 二、信封、出示物与答复

### S-4 请求信封

客户端一面的每个请求（[公开体检](#s-18-公开体检)除外）是一个**信封**，恰含下列成员，**没有别的成员**：

| 成员 | 必需 | 含义 |
|---|---|---|
| `protocolVersion` | 是 | 客户端声明的线上协议版本 |
| `presentedLoginState` | 否 | **出示物**（无词条）：以哪一个[登录状态](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-login-state--登录状态--login-state)的名义，见 [S-5](#s-5-出示物) |
| `operation` | 是 | 路由标识，取值恰为 [S-17](#s-17-路由表封闭每条路由的九件事从哪读) 的路由表 |
| `payload` | 是 | 这条路由的载荷；路由没有载荷项时是一个空对象 |

`protocolVersion` 的交换表示是一个非空字符串；`payload` 里各项的成员名见 [S-17](#s-17-路由表封闭每条路由的九件事从哪读) 的成员名规则。

**时间不进信封。**信封里没有任何时刻或时长字段是「现在」的依据；过期与到期只量中心的钟
（[PF-017 §5.4](../../../../product/PF-017-governance-center-as-deployable-application/design.md#54-中心自己的时间)）。
载荷里的「这一份邀约的时长」是一个时段，不是时刻，它不告诉中心现在几点。

**传输落地的约束**：信封的每个成员在传输上各有唯一的承载位置，**不丢、不并、不重排出第二份**。
同一成员在传输上出现不止一次，**不由实现挑其中一个**，按成员各归判定次序的那一步（[S-10](#s-10-判定次序)）：

| 出现不止一次的成员 | 答复 | 在哪一步 |
|---|---|---|
| `protocolVersion` | `version-mismatch` | ① 版本：看不懂是哪一版 |
| `operation` | `invalid-input` | ①′ 信封 |
| `payload` | `invalid-input` | 载荷——要认人的路由在**认出人之后**；免认人的路由在 ①′ 之后 |
| 出示物 | `login-state-rejected` | ② 认人：[「多个出示物」](#s-5-出示物)那一支 |

形状由 [Schema](governance-center-entry.schema.json) 的 `Envelope` 给出。**Schema 校验不过对应哪一种答复，由 [S-10](#s-10-判定次序) 按不过的是哪个成员决定**，不是一律 `invalid-input`。

### S-5 出示物

- **出示物就是 [AI S-45](../../../capabilities/account-identity/v3/contract.md#s-45-登录状态出示物) 的「登录状态出示物」**：[AI S-15](../../../capabilities/account-identity/v3/contract.md#s-15-验证凭据并签发登录状态) 签发一个登录状态时一次性交出的那个不透明字符串，
  按持有者即被认的方式使用（bearer；[PF-001 §4 登录状态](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#登录状态)）：持有它本身就是 [AI S-44](../../../capabilities/account-identity/v3/contract.md#s-44-按出示物换取身份) 校验的那件事。
  **它不是 `LoginStateId`**：`LoginStateId` 是它的不可逆形式，可以被看见（列表里就有，[S-9](#s-9-列表句柄)），拿来当出示物过不了 AI S-44。
  这是产品负责人把登录态的合法性、鉴权与保存交给业界通行做法之后的形状（[PF-017 INT-011](../../../../product/PF-017-governance-center-as-deployable-application/interviews/2026-09-23-rulings.md#int-011)）。
- **交换表示就是 AI S-45 的「交换表示」一行，入口层用同一条判、不另立一条**：Unicode 标量值序列（不含孤立的代理码点）、非空、至多 1024 个标量值、首末字符都不属于 [`data.identity-values/v1#S-31`](../../../data/identity-values/v1/contract.md#s-31-不透明标识的交换表示) 列出的空白码点集合；逐码点相等，不做任何规范化。上界 1024 是 AI S-45 的候选值，随它的接受一起定。入口层不解析它、不对它的字母表设任何限制。
- **恰好一个。**一个请求带了不止一个出示物 ⇒ [S-11](#s-11-认人) 判「无效」。
- **出示物不是「输入」，是身份。**它在表示层就不合格（不满足上一条的交换表示）时，
  **答 `login-state-rejected`，不答 `invalid-input`**——它属于「带的登录状态从没被这个中心签发过」那一种情形。
  这与 [`data.identity-values/v1#S-33`](../../../data/identity-values/v1/contract.md#s-33-表示层校验与判定分开) 不冲突：那条说表示层拒绝不是一次判定结果；
  这里是一次**不用查就判得了的判定**——一个不合形状的值不可能是本中心签发的任何一个登录状态。
- **缺席没有默认值**（[`data.identity-values/v1#S-17`](../../../data/identity-values/v1/contract.md#s-17-身份参数没有默认值)）：不从「上一次请求」「这台机器」「这条连接」补。
- **出示物只在一个输出里出现一次**：[登录路由](#s-19-免认人的两条路由注册登录)成功时交出新签发的那一个。此外任何答复、体检、工程记录里都没有它（[S-29](#s-29-秘密不进任何输出)）。
- **入口层不保存出示物**；它只在处理这一个请求的期间存在。

### S-6 四种入口答复

| 值 | 它是什么 | 来者该做什么 | 产品措辞依据 |
|---|---|---|---|
| `version-mismatch` | 版本对不上：中心没有去判这个请求的任何别的东西 | 升级 | [§6.16](../../../../product/PF-017-governance-center-as-deployable-application/design.md#616-版本对不上就明说) |
| `login-state-rejected` | **一个成立的结论**：这次来的身份此刻不作数 | 重新登录 | [§6.4](../../../../product/PF-017-governance-center-as-deployable-application/design.md#64-无效与答不出是两个不同的答复)、[§6.5](../../../../product/PF-017-governance-center-as-deployable-application/design.md#65-拒绝的时候什么都不多说) |
| `unavailable` | **没有结论**：此刻判不了（数据所在够不着、时钟读不到或倒退、中心自身的故障） | 稍后再试；**不要重新登录** | 同上 |
| `invalid-input` | 看得懂是哪一版，但信封不合格（`operation` 缺席、出现不止一次或不在路由表内，或有表外成员），或那件事的输入（`payload`）在表示层就不合格；判定没有开始 | 改输入 | [§6.4 ④](../../../../product/PF-017-governance-center-as-deployable-application/design.md#64-无效与答不出是两个不同的答复) |

- **四个值不得合并，不得互相冒充。**尤其：**判不了永远不说成 `login-state-rejected`**；`unavailable` 既不是放行，也不是拒绝。
- **`unavailable` 对来者不带原因。**原因只在[完整体检](#s-26-完整体检)与[工程记录](#s-30-工程记录)里。
- **同一个值的每一次答复逐字相同**，覆盖**整个线上答复**——传输层的状态、头与体一并算，不只是一句文案。
  实现为每个值固定一份字节序列；除此之外答复里没有任何随请求变化的部分（没有请求编号、时间戳、原因码）。
- `login-state-rejected` 沿用 [`capability.account-identity/v3#S-44`](../../../capabilities/account-identity/v3/contract.md#s-44-按出示物换取身份) 的字面；四个值与领域失败值同形（kebab-case）。

### S-7 答复集合闭合

对一个信封，中心的答复**恰为下列三类之一**，没有第四类、没有「其他」：

```text
客户端一面的答复  ≝  四种入口答复之一（S-6）
                  |  路由结果：成功   —— { result: <被投影操作的成功返回> }
                  |  路由结果：具名失败 —— { failure: <被投影操作失败集合里的一个具名值> }
```

对[公开体检的请求](#s-18-公开体检)，答复恰为公开体检答复，别无他物。
路由结果里的具名失败值**原样透传**领域契约的名字（[S-14](#s-14-失败映射)），全集在 Schema 的 `RouteFailure` 里枚举、封闭；
`failure` 沿用 `data.identity-values` v1 结果包装的既有写法；`result` 里的形状由 [S-17](#s-17-路由表封闭每条路由的九件事从哪读) 的成员名规则决定。

### S-8 协议版本与跨版本不变的两样

- **哪些 `protocolVersion` 算对得上，是具名参数 `accepted_protocol_versions`**：一个非空的版本集合。**本契约不填值**；取值与「哪些版本算对得上」归技术设计（[§6.16](../../../../product/PF-017-governance-center-as-deployable-application/design.md#616-版本对不上就明说)）。
  它随中心的构建定下，运行期间不变；**没有它，中心不起来**（缺即启动失败，不取任何默认集合）。
- **跨所有协议版本不变的，恰有两样**：
  1. [公开体检](#s-18-公开体检)的请求形状与答复形状；
  2. `version-mismatch` 这个答复的形状与字节序列。
  理由：版本对不上的客户端正要靠这两样看见「对不上的是哪一版」「连的还是不是原来那个中心」
  （[§6.4](../../../../product/PF-017-governance-center-as-deployable-application/design.md#64-无效与答不出是两个不同的答复)）。后续任何版本**不得改动这两样**，只能在它们之外演化。
- **这两样在传输上也跨版本稳定**：无论传输绑定怎样定、怎样演化（[G-10](#十三已知缺口)），**客户端认出「这是 `version-mismatch`」的办法**与**发出公开体检请求的办法**（落到传输上的路径、状态码、帧等一切细节）必须跨协议版本不变。
  只把信封与答复的形状钉住而让它们的传输落地随版本变，版本对不上的客户端照样认不出对不上。

### S-9 列表句柄

**列表句柄**（无词条，成员 `loginStateHandle`）是[登录状态列表](#s-20-登录状态的两条路由撤销列出)与[撤销](#s-20-登录状态的两条路由撤销列出)在线上指认某一个登录状态用的值。
**它就是那个登录状态的 [`LoginStateId`](../../../data/identity-values/v1/contract.md#s-9-loginstateid)**，入口层不另派生任何东西。

| 性质 | 内容 | 由谁保证 |
|---|---|---|
| 就是 `LoginStateId` | 列表里每一项的句柄、登录成功答复里的句柄，都是 AI 给出的那个 `LoginStateId` 原值；入口层不改写、不另算 | 本契约 |
| 不是出示物、得不到出示物 | `LoginStateId` 是出示物的不可逆形式；拿它当出示物，AI S-44 答 `login-state-rejected`（[S-11](#s-11-认人)） | [AI S-45](../../../capabilities/account-identity/v3/contract.md#s-45-登录状态出示物) 的派生规则 |
| 不是秘密 | 可以出现在答复里与工程记录里 | 同上：本版登录状态的安全性在出示物的熵上，不在 `LoginStateId`（[S-36](#s-36-装配给的保证-vs-协议须给的保证) 的「认人、出示物安全、句柄来源」行） |
| 部署内唯一 | 两个登录状态不会有同一个句柄，所以按句柄撤销不会多撤 | AI S-45（由存储的唯一约束兑现）；`data.identity-values` v1 [`#S-9`](../../../data/identity-values/v1/contract.md#s-9-loginstateid) |
| 跨重启、升级、换密钥稳定 | 同一个登录状态的句柄在重启、升级、更换[部署密钥](../../../../ubiquitous_language/terms/grounding-and-isolation.md#ul-deployment-key--部署密钥--deployment-key)之后**不变**——换密钥[什么都不该丢](../../../../product/PF-017-governance-center-as-deployable-application/design.md#部署密钥) | AI S-45 的派生式：确定、不加盐、**不以任何密钥为键**，且 `LoginStateId` 写进登录状态记录、跟着数据走 |
| 交换表示 | `data.identity-values` v1 的 `LoginStateId`（[`#S-31`](../../../data/identity-values/v1/contract.md#s-31-不透明标识的交换表示)）；比较逐码点，不做规范化。**消费者不得解析它**——它恰是 64 个十六进制字符这件事只让 AI 的派生可复现，不是给线上读的结构。入口层判撤销载荷里的句柄也只用 IV S-31，**不收紧到 64 个十六进制字符**，与 AI S-45 对 AI S-16／AI S-17／AI S-37 表示层的要求同一条词法 | IV；AI S-45 |

**客户端须把句柄与出示物一起保存**：两样只在登录成功时一并交出（[S-19](#s-19-免认人的两条路由注册登录)），此后客户端据句柄在列表里认出自己那一项、用它退出；
线上没有「凭出示物换句柄」的路由，客户端也**不自行按派生式去算**——派生规则只归 AI S-45 一处。
**为什么列表可以直接给 `LoginStateId`**：[登录状态](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#登录状态)按持有者认，持有的是出示物；
列表里的 `LoginStateId` 过不了 AI S-44，同一账号的一台设备列一次，**拿不走**其余设备能用的东西（[§8 不交出能直接用的凭证](../../../../product/PF-017-governance-center-as-deployable-application/design.md#八边界与依赖)；[AI S-37](../../../capabilities/account-identity/v3/contract.md#s-37-列出本账号有效登录状态)：列出的 `LoginStateId` 不是出示物）。

## 三、判定次序

### S-10 判定次序

**一个请求到达中心，恰按下面的次序走；任何一步判不了，就停在那一步答 `unavailable`，不再往下，永不改说成 `login-state-rejected`。
不用查就判得了的，照判。**
这是[产品写死的先后](../../../../product/PF-017-governance-center-as-deployable-application/design.md#64-无效与答不出是两个不同的答复)与[认出一个来者只有一条路](../../../../product/PF-017-governance-center-as-deployable-application/design.md#53-认出一个来者只有一条路)在线上的落点；来者一侧看到的流程见 [flows §1.3](../../../../product/PF-017-governance-center-as-deployable-application/flows.md#13-一个客户端带着登录状态来)。

| 步 | 做什么 | 要查吗 | 这一步的出口 |
|---|---|---|---|
| **0 公开体检** | 请求是[公开体检的形状](#s-18-公开体检) ⇒ 直接答公开体检 | 不查 | 公开体检答复。**不看版本，不看出示物，不读存储** |
| **① 版本** | 信封不可解析、缺 `protocolVersion`、它出现不止一次（[S-4](#s-4-请求信封)）、或它不在 `accepted_protocol_versions` 内 | 不查 | `version-mismatch`。**出示物一眼都不看** |
| **①′ 信封** | `operation` 缺席、出现不止一次或不在路由表内，或信封有表外成员。（`payload` 缺席、出现不止一次或不是对象不在这一步，属于下面的「载荷」） | 不查 | `invalid-input` |
| 免认人的路由（[S-19](#s-19-免认人的两条路由注册登录)） | 载荷表示层校验 ⇒ 直接到第 ③ 步。**出示物不看**（带了也不看，既不因它放行，也不因它拒绝） | 不查 | `invalid-input` |
| **② 认人**（[S-11](#s-11-认人)） | 其余路由 | 视情形 | 通过 ⇒ 下一步；`login-state-rejected`；`unavailable` |
| **载荷** | 载荷表示层校验——**认出人之后才看输入** | 不查 | `invalid-input` |
| **身份推导**（[S-12](#s-12-身份推导)） | 交给领域操作的身份值从认人结果推出 | 要查的路由才查 | 下一步；`login-state-rejected`；`unavailable` |
| **补授权**（[S-13](#s-13-补授权)） | 只对四条读路由 | 查 | 下一步；路由结果 `notAuthorized`；`unavailable` |
| **③ 办事**（[S-14](#s-14-失败映射)） | 调被投影的那一个领域操作，映射它的答复 | 领域自己查 | 路由结果；`unavailable`；`invalid-input`；`login-state-rejected` |

**由这张表直接推出、且都是本意的三条**（[PF-017 §6.4](../../../../product/PF-017-governance-center-as-deployable-application/design.md#64-无效与答不出是两个不同的答复)、[§6.5](../../../../product/PF-017-governance-center-as-deployable-application/design.md#65-拒绝的时候什么都不多说)）：

1. 判不了的时候，**什么都没带**的来者仍得到 `login-state-rejected`（不用查）；他去登录，登录要查，得到 `unavailable`。
2. 同一份格式不对的载荷，配有效的登录状态得 `invalid-input`，配已撤销的得 `login-state-rejected`，配存储此刻读不到时的任何要查的出示物得 `unavailable`。
3. 注册与登录的载荷不合格，存储此刻读不到也照样得 `invalid-input`。

**「看不懂的请求」答 `version-mismatch`，不答 `invalid-input`**：信封都解析不出来的请求，中心不知道它是哪一版、要办哪件事，
[它不会试着把一个看不懂的请求猜着办了](../../../../product/PF-017-governance-center-as-deployable-application/design.md#616-版本对不上就明说)。
`invalid-input` 在「看得懂是哪一版，但信封不合格（`operation` 缺席、出现不止一次或不在路由表内，或有表外成员），或那件事的输入（`payload`）在表示层就不合格」时给出——与 [S-6](#s-6-四种入口答复) 那一格同一句。

**「输入」指载荷，信封不是输入；信封不合格在认人之前拒绝。**[§6.4 ④](../../../../product/PF-017-governance-center-as-deployable-application/design.md#64-无效与答不出是两个不同的答复)说「要登录状态的事，认出人之后才看输入」，
那里的「输入」是**那件事本身的输入**，在线上就是 `payload`；`operation` 与表外成员是**信封**的事——不知道要办哪件事，就谈不上「那件事的输入」，
所以 ①′ 排在认人之前、答 `invalid-input`，与 ④ 不冲突。这一读法是产品负责人 2026-09-23 的裁定（[PF-017 INT-013](../../../../product/PF-017-governance-center-as-deployable-application/interviews/2026-09-23-rulings.md#int-013)：认人之前拒绝）。

### S-11 认人

第 ② 步只看两件事：**是不是本中心签发的**、**此刻是否仍有效**（[§6.3](../../../../product/PF-017-governance-center-as-deployable-application/design.md#63-只信自己签发的此刻仍有效的登录状态别人说验过了不算数)）。
它是[认出一个来者的那一条路](../../../../product/PF-017-governance-center-as-deployable-application/design.md#53-认出一个来者只有一条路)，对应 [flows §1.3](../../../../product/PF-017-governance-center-as-deployable-application/flows.md#13-一个客户端带着登录状态来) 里中心那一侧。

| 出示物的情形 | 要查吗 | 答复 |
|---|---|---|
| 没带 | 不查 | `login-state-rejected` |
| 带了不止一个 | 不查 | `login-state-rejected` |
| 表示层不合格 | 不查 | `login-state-rejected`（[S-5](#s-5-出示物)） |
| 恰一个、形状合格 | 现读 [`capability.account-identity/v3#S-44`](../../../capabilities/account-identity/v3/contract.md#s-44-按出示物换取身份)（按出示物换取身份），输入就是出示物 | 见下 |

| [AI S-44](../../../capabilities/account-identity/v3/contract.md#s-44-按出示物换取身份) 的出口 | 本步的收场 |
|---|---|
| `{LoginStateId, AccountId}` | **认出了人**，带着这两个值往下走（[S-12](#s-12-身份推导)：认人所得 `LoginStateId`、认人所得 `AccountId`） |
| `login-state-rejected`（查不到、已撤销、所属账号未激活——**从没签发过、已退出或撤销、别的中心签的**，以及**拿一个 `LoginStateId`（例如列表里的一项）当出示物**，都落在这里） | `login-state-rejected` |
| `invalid-input` | `login-state-rejected`。**本版到不了**：入口层判出示物的表示层用的就是 AI S-44 的那一条（[AI S-45](../../../capabilities/account-identity/v3/contract.md#s-45-登录状态出示物) 的交换表示）；前提一旦不成立，收场已经写在这里——出示物是身份，不是输入 |
| `storage-unavailable` | `unavailable` |
| 失败集合之外的任何东西（未列出的值、返回了却没有值、抛出——「一直不返回」不在这一行，归 [S-32](#s-32-进展性质与前提) 的进展前提，本契约不设超时） | `unavailable`，**并记为缺陷**（[S-14](#s-14-失败映射)） |

**认人只走 AI S-44**：本组合从不以线上收到的任何 `LoginStateId` 调 [AI S-17](../../../capabilities/account-identity/v3/contract.md#s-17-校验登录状态) 来认人——那是 AI 只对进程内开放的面（[AI S-30](../../../capabilities/account-identity/v3/contract.md#s-30-装配给的保证-vs-协议须给的保证) 的「只有 S-44 认出示物」行）。

**六种不认的情形——没带、带了不止一个、表示层不合格、从没签发过、已退出或撤销、别的中心签的——在版本对得上、判得了时，整个线上答复逐字相同**（[§6.5](../../../../product/PF-017-governance-center-as-deployable-application/design.md#65-拒绝的时候什么都不多说)）。
从中心的任何拒绝里，读不出一个名字存不存在，也读不出一个登录状态曾经有没有过。
「别的中心签的」在本中心看来就是「查不到」，本中心不去、也无从分辨它是别处签发的还是从没存在过。

**认人时没有第四个出口**：「客户端已经验过了」「刚才还有效」「这台机器可信」「运维者说放行」都不是本步的输入，信封里也没有能承载它们的成员（[§6.2](../../../../product/PF-017-governance-center-as-deployable-application/design.md#62-中心只认登录状态不认客户端)）。

### S-12 身份推导

**交给领域操作的每一个身份值，都只从认人的结果推出；线上载荷里的身份值从不作授权依据。**

| 交给领域的身份值 | 从哪来 | 读不到／读到不作数时 |
|---|---|---|
| 调用方的 `AccountId`——下文称**认人所得 `AccountId`** | 第 ② 步 [AI S-44](../../../capabilities/account-identity/v3/contract.md#s-44-按出示物换取身份) 给出的那一个 | —（已在第 ② 步定下） |
| 出示物所属那个登录状态的 `LoginStateId`——下文称**认人所得 `LoginStateId`** | 同上，AI S-44 一并给出 | —（已在第 ② 步定下） |
| 行事的 `TenantId`（发起者、调用方、接受者 `TenantId`）——下文称**推导所得 `TenantId`** | 现读 [OG S-36](../../../capabilities/organization-governance/v2/contract.md#s-36-当前租户身份查询)，参数是认人所得 `LoginStateId`——即登录状态上[当前选中的租户身份](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-current-tenant-identity--当前租户身份--current-tenant-identity)（[PF-001 §4 当前租户身份](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#当前租户身份)） | `unavailable` ⇒ `unavailable`；`loginStateNotValid` ⇒ `login-state-rejected`（其间被撤销，见 [S-33](#s-33-认出人之后登录状态被撤销)）；`invalidInput` 本版到不了，出现即 `unavailable` 并记为缺陷；返回的 `TenantId` 的 `account` 分量不等于认人所得 `AccountId` ⇒ `unavailable` 并记为缺陷（[S-14](#s-14-失败映射) 的矛盾清单）；**失败集合之外的任何东西（未列出的值、没有返回、抛出）⇒ `unavailable`，并记为缺陷** |
| 被传给领域的 `LoginStateId`（[OG S-36](../../../capabilities/organization-governance/v2/contract.md#s-36-当前租户身份查询)、[OG S-37](../../../capabilities/organization-governance/v2/contract.md#s-37-切换当前租户身份)、[AI S-16](../../../capabilities/account-identity/v3/contract.md#s-16-撤销登录状态)、[AI S-37](../../../capabilities/account-identity/v3/contract.md#s-37-列出本账号有效登录状态) 四条路由的发起方、调用方） | 认人所得 `LoginStateId`。**出示物本身从不交给领域**：收出示物的面只有 AI S-44 | — |

- **推导发生在请求到达的那一刻，每个请求推一次，随请求交下去**；领域操作不在使用点重取当前租户身份
  （[`data.identity-values/v1#S-17`](../../../data/identity-values/v1/contract.md#s-17-身份参数没有默认值)、[`#S-28`](../../../data/identity-values/v1/contract.md#s-28-当前租户身份在创建那一刻捕获)）。
  **请求到达就是流程开始**，所以在这里取一次当前租户身份不是「在使用点现取」。
- **只有需要行事 `TenantId` 的路由才现读 [OG S-36](../../../capabilities/organization-governance/v2/contract.md#s-36-当前租户身份查询)**（逐条见路由表）；只需要 `AccountId` 的路由不读它。
- **载荷里出现的身份值只作「对象」**（邀请谁、切到哪个租户身份、读哪个组织），由领域操作自己判它能不能被这样用；
  **载荷的expectedTenant仅供比较，不决定「以谁的身份」**——发起者、调用方、接受者的身份一律推导，不收（[PF-001 §6.4 隔离](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)：跨范围操作显式携带的租户身份须有所有权或成员资格依据）。
- **载荷里的 `TenantId` 与 `ScopeLayerIdentity` 按 [`data.identity-values/v1#S-7`](../../../data/identity-values/v1/contract.md#s-7-tenantid-的规范序列化形式) 的规范形式原样传**：
  带判别式、两个分量，**不压平成两个可空字段**（[`#S-16`](../../../data/identity-values/v1/contract.md#s-16-按归属层显式携带身份值)），入口层不改写、不补齐。
- expectedTenant按S51仅作比较，身份仍来自实际当前选择；指定路由缺席/非法为invalid-input，不匹配为expectedTenantMismatch。同一登录被另一个客户端切换后，旧预期请求不得落入新组织。

### S-13 补授权

四条被投影的读操作在能力契约里**没有授权前置**（[`capability.organization-governance/v2#S-42`](../../../capabilities/organization-governance/v2/contract.md#s-42-装配给的保证-vs-协议须给的保证) 第 9 行）。
上线之前，本组合给它们补一道：**调用方在该组织里有效。**

**这是本契约按隔离原则给四条读面加的前置**，依据是 [PF-001 §6.4 隔离](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)：
没有明确所有权或成员资格依据时，跨租户访问默认拒绝。一个组织的类型、它的上级链、别人在它里面的成员资格效力，都不向与那个组织无关的人开放。
产品负责人 2026-09-23 裁定这是隔离原则的自然延伸，由架构与规格设计自定、不需要产品另提需求（[PF-017 INT-014](../../../../product/PF-017-governance-center-as-deployable-application/interviews/2026-09-23-rulings.md#int-014)）。

| 路由 | 「该组织」是哪个 | 补的那一道 |
|---|---|---|
| [`#S-22`](../../../capabilities/organization-governance/v2/contract.md#s-22-读组织) 读组织 | 载荷里的那个 `OrganizationId` | 现读 [`#S-26`](../../../capabilities/organization-governance/v2/contract.md#s-26-成员资格判定)`((该组织, 认人所得 AccountId))` |
| [`#S-26`](../../../capabilities/organization-governance/v2/contract.md#s-26-成员资格判定) 成员资格判定 | 载荷里那个 `TenantId` 的组织分量 | 同上 |
| [`#S-34`](../../../capabilities/organization-governance/v2/contract.md#s-34-上级链与有共同上级) 上级链／有共同上级 | 载荷里的**每一个** `OrganizationId`（一个或两个） | 对每一个都现读，**全部读完、不短路**；按下表合成 |
| [`#S-35`](../../../capabilities/organization-governance/v2/contract.md#s-35-层身份) 层身份 | 载荷里那个 `TenantId` 的组织分量 | 同上 |

| 那次现读的结果（多个组织时全部读完，按本表行序取第一条成立的） | 收场 |
|---|---|
| 任一次得到失败集合之外的东西，或 `invalidInput`（补授权是入口层自己发起的现读，交进去的组织已按 IV 的形状核过；领域仍判它不合形状，是两边的形状规则不一致，错不在来者） | `unavailable`，**并记为缺陷**（[S-14](#s-14-失败映射)） |
| 任一次 `{ failure: "unavailable" }` | `unavailable`——**不得收成 `notAuthorized`**，那是把判不了说成失权；**哪怕另一个组织已经读出 `ineffective`** |
| 任一次 `ineffective` | 路由结果 `{ failure: "notAuthorized" }`，**不调**被投影的操作。产品反馈是[「你不在这个组织里」](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常) |
| 每一次都 `effective`（任一角色） | 过，往下调被投影的操作 |

上述逐项读取适用于共同边界仍有效且参与操作正常返回读数的情形。AI3 S51/OG2 S63声明的共同边界失败若使本次工作不能继续，立即沿S49结束并回滚，不在失效边界上继续读取，也不把未读取的组织说成有效或无效；此前已读出的无效不能掩盖不可用，已观察到的缺陷仍需记录。此处停止属于整次工作失败，不是以某个组织失权提前返回notAuthorized。

**为什么不短路**：先读到 `ineffective` 就停，答复就取决于读的先后——同一个请求，两个组织换个次序，一次得 `notAuthorized`、一次得 `unavailable`。全部读完再合成，答复只取决于各次读数，「判不了优先于无效」在补授权里同样成立。

- 「调用方」是认人所得 `AccountId`；**不是**当前租户身份——读一个组织不需要先切过去。
- 因为补授权排在前面，**一个不存在的组织在线上得到的是 `notAuthorized`**（没有人在不存在的组织里有效），
  `organizationDoesNotExist` 在这两条路由上到不了；这不泄漏任何组织的存在性。
- 本组合给 [`#S-26`](../../../capabilities/organization-governance/v2/contract.md#s-26-成员资格判定) 路由补的这一道，使一个人**问自己在一个他不在的组织里的效力**得到 `notAuthorized` 而不是 `ineffective`。这是这一道补授权的直接后果。
- [`#S-27`](../../../capabilities/organization-governance/v2/contract.md#s-27-我的租户) 与 [`#S-57`](../../../capabilities/organization-governance/v2/contract.md#s-57-列出账号收到的待接受邀请) 不在此列：它们以「输入的 `AccountId` 就是调用者本人」为界，本组合交给它们的正是认人所得 `AccountId`。

### S-14 失败映射

**第 ③ 步的共同映射**，每条路由照此办，路由表只写例外：

| 领域给出的 | 线上答复 |
|---|---|
| 成功返回（该条款 ⑤），且合本契约 Schema 的 `Result_<路由>` | `{ result: … }` |
| AI 的 `storage-unavailable`；OG 的 `unavailable`（[三类收场之一](../../../capabilities/organization-governance/v2/contract.md#s-16-缺席时的默认答案)）；`MembershipStandingResult` 的 `{ failure: "unavailable" }` | `unavailable` |
| 表示层不合格：AI 的 `invalid-input`、OG 的 `invalidInput`（[同上](../../../capabilities/organization-governance/v2/contract.md#s-16-缺席时的默认答案)）——**这一次请求实际交给领域的输入里有来自载荷的项** | `invalid-input` |
| 同上——**这一次请求实际交给领域的输入里没有来自载荷的项**（交进去的全是入口层产出的值：认人所得 `AccountId`、认人所得 `LoginStateId`、推导所得 `TenantId`） | `unavailable`，**并记为缺陷**：入口层自己产出的值被领域判为不合形状，错不在来者 |
| **「出示的那个登录状态此刻不作数」**：[AI S-37](../../../capabilities/account-identity/v3/contract.md#s-37-列出本账号有效登录状态) 的 `login-state-rejected`、[AI S-16](../../../capabilities/account-identity/v3/contract.md#s-16-撤销登录状态) 的 `not-authorized`、[OG S-36](../../../capabilities/organization-governance/v2/contract.md#s-36-当前租户身份查询)／[OG S-37](../../../capabilities/organization-governance/v2/contract.md#s-37-切换当前租户身份) 的 `loginStateNotValid` | `login-state-rejected`（[S-33](#s-33-认出人之后登录状态被撤销)） |
| **在本组合里结构上到不了的具名值**：AR 的 `identifier-held-by-expired-record`（[S-19](#s-19-免认人的两条路由注册登录)）；[OG S-21](../../../capabilities/organization-governance/v2/contract.md#s-21-创建团队组织)、[OG S-25](../../../capabilities/organization-governance/v2/contract.md#s-25-接受邀请) 就**调用方本人**给出的 `accountNotActivated`、`accountDoesNotExist`——认人所得 `AccountId` 必属一个已激活账号（[AI S-44](../../../capabilities/account-identity/v3/contract.md#s-44-按出示物换取身份) 对未激活账号答 `login-state-rejected`），而[已激活不回退、不消失](../../../capabilities/account-identity/v3/contract.md#s-20-已激活不回退不消失) | `unavailable`，**并记为缺陷**。与空列表同一口径 |
| 该条款失败集合里的其余具名值 | `{ failure: <原名> }`，**原样透传**，不改名、不合并、不加原因 |
| **失败集合之外的任何东西**（未列出的值、返回了却没有值、抛出；「一直不返回」归 [S-32](#s-32-进展性质与前提) 的进展前提） | `unavailable`，**并记为缺陷** |
| **与该条款承诺矛盾的返回——封闭清单，恰下列三样，此外不检**：① 成功返回不合本契约 Schema 的 `Result_<路由>`；② [OG S-27](../../../capabilities/organization-governance/v2/contract.md#s-27-我的租户) 或 [AI S-37](../../../capabilities/account-identity/v3/contract.md#s-37-列出本账号有效登录状态) 返回空列表；③ [OG S-36](../../../capabilities/organization-governance/v2/contract.md#s-36-当前租户身份查询) 返回的 `TenantId` 的 `account` 分量不等于认人所得 `AccountId`（[S-12](#s-12-身份推导)） | `unavailable`，**并记为缺陷** |

**「记为缺陷」**的全部情形就是：[S-11](#s-11-认人) 出口表里「失败集合之外」那一行、[S-12](#s-12-身份推导) 推导所得 `TenantId` 那一行写「记为缺陷」的各支、[S-13](#s-13-补授权) 合成表的第一行、上表标了它的四行，以及 [S-19](#s-19-免认人的两条路由注册登录)～[S-23](#s-23-当前租户身份的两条路由) 各表里写「缺陷」的格，以及S49的结果/编码缺陷、S50与S53明示缺陷；它们计入[完整体检](#s-26-完整体检)的 `defectCount`，细节只在[工程记录](#s-30-工程记录)里。

- **缺陷答 `unavailable`**，不答 `login-state-rejected`（人会白白重新登录），也不答成功（在出错的地方给出看起来对的答案；[§6.4](../../../../product/PF-017-governance-center-as-deployable-application/design.md#64-无效与答不出是两个不同的答复)「答不出」含中心自身的故障）。
  代价照实写：人被叫「稍后再试」，而缺陷不会自己好，要等运维者处理（[§6.6](../../../../product/PF-017-governance-center-as-deployable-application/design.md#66-要么整个起来要么不起来)）。
- **「出示的登录状态不作数」为什么不原样透传**：这些值表示后续必要核验发现登录不再有效，包括期限到达；改密准备阶段的再次准入还可能看见代际变化或撤销。
  透传出去，同一个「已撤销」就有了两种线上答复，[S-11](#s-11-认人) 的逐字相同在这个窗口里被打破。
- **结果为什么是封闭的**：路由结果的具名值全集就是各被投影条款失败集合的并，减去上表映射掉的那些；Schema 的 `RouteFailure` 把它枚举出来，没有「其他」；S51新增expectedTenantMismatch亦属闭合集合。

### S-15 δ = 0：每个请求现读，入口不跨请求缓存

- **每个请求都现读**：第 ② 步现读 [AI S-44](../../../capabilities/account-identity/v3/contract.md#s-44-按出示物换取身份)，身份推导现读 [OG S-36](../../../capabilities/organization-governance/v2/contract.md#s-36-当前租户身份查询)，补授权现读 [OG S-26](../../../capabilities/organization-governance/v2/contract.md#s-26-成员资格判定)；领域操作按各自契约现读成员资格与角色。
  这就是[只信此刻仍有效的](../../../../product/PF-017-governance-center-as-deployable-application/design.md#63-只信自己签发的此刻仍有效的登录状态别人说验过了不算数)在中心一侧的样子。
- **入口层不跨请求缓存任何认人结果、授权判定、推导出的身份或成员资格效力**——一条都不缓存。
  撤销、退出、解除、降级、切换在提交之后，**下一个到达中心的请求**就看得到（[`data.identity-values/v1#S-27`](../../../data/identity-values/v1/contract.md#s-27-每道准入现读)、[PF-001 §6.6](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#66-撤销不等于强制停止)）。
- **这是中心一侧的承诺。**据点上的副本与它们的陈旧窗口归 PF-016（[§5.6](../../../../product/PF-016-cli-tui-delivery-surface/design.md#56-哪些东西在中心一侧哪些在据点一侧) 的分界；[§6.9](../../../../product/PF-016-cli-tui-delivery-surface/design.md#69-需要现读成员资格的那几件事不拿副本放行) 的三类现读由据点放行、本契约只保证中心此刻的答案是现读的；[§6.17](../../../../product/PF-016-cli-tui-delivery-surface/design.md#617-治理中心不可达已经开着的会话照常干活)：撤销在一台机器上生效的时刻，是它再连上中心的那一刻）。
- **将来要缓存，须发新版本**，并在其中写明失效条件与最大陈旧窗口；读面以「不可用」失败时不写入缓存。

### S-16 不记住来访，不区别对待来者

- **成功业务按 AI3 S49 更新所属登录的最后活动，影响空闲期限；失败、纯认人和体检不更新。**中心不登记来者是哪台机器、哪个程序（[flows §1.3](../../../../product/PF-017-governance-center-as-deployable-application/flows.md#13-一个客户端带着登录状态来)）。活动持久事实归账号能力，入口不保存第二份。
- **对端地址、机器、客户端程序一律不作资格**，不进任何判定（[`data.identity-values/v1#S-21`](../../../data/identity-values/v1/contract.md#s-21-判定依据的构成封闭)、[§6.2](../../../../product/PF-017-governance-center-as-deployable-application/design.md#62-中心只认登录状态不认客户端)）。
  同一个有效登录状态、同一件事，从哪里来都得到同一个答复；人用的那份客户端与一段脚本走同一条路（[PF-016 §6.5](../../../../product/PF-016-cli-tui-delivery-surface/design.md#65-人能做的脚本能做脚本能做的人能做)）。
- **中心上不存在「可信机器」「可信程序」的登记，也不存在接受外部担保的成员。**

## 四、路由表

### S-17 路由表封闭；每条路由的九件事从哪读

**路由表是一张封闭的、逐条写明的映射**：每条路由对应一个被投影的操作，**没有泛化的分派**
（没有「按名字调用某个能力的某个操作」这种路由；[§5.1](../../../../product/PF-017-governance-center-as-deployable-application/design.md#51-中心有两张面没有第三张)：客户端那一面只有这些门）。表外的 `operation` ⇒ `invalid-input`（[S-10](#s-10-判定次序) ①′）。

**路由标识**：被投影条款的坐标，写成 `<contract_id>/v<version>#S-n`；本契约自有的公开体检是
`composition.governance-center-entry/v1#S-18`。

**每条路由的九件事**按下表合成：「共同」一栏对每条路由都成立，路由表那一行只写这条路由自己的那几格。

| 九件事 | 共同 | 路由表那一行给什么 |
|---|---|---|
| **1 输入与授权** | 信封（[S-4](#s-4-请求信封)）。授权 = 判定次序的各关（[S-10](#s-10-判定次序)）＋ 被投影条款自己的授权前置 | 经不经第 ② 步；身份怎么推；补什么授权；载荷携带被投影条款 ① 的哪几项 |
| **2 前置** | 版本对得上、信封合格；经 ② 的路由认出了人；载荷合格；推导与补授权都过 | —（被投影条款的前置照原样） |
| **3 提交点与原子性** | 受认证业务采用 S49 共同提交，参与领域的临时返回不是提交；免认证注册/登录维持其独立链 | 有多于一步领域调用的路由写明哪一步提交 |
| **4 返回与失败集合** | 成功 ⇒ `{ result: 被投影条款 ⑤ }`；失败 ⇒ 按 [S-14](#s-14-失败映射)。这条路由可达的入口答复：不经 ② 的路由不会得到 `login-state-rejected` | 透传的具名值（被投影条款 ⑥ 减去映射掉的）；例外 |
| **5 幂等边界与重发** | 入口层不加任何幂等机制；幂等与重复照被投影条款 ⑦。**答复丢了、客户端重发，就是再发一次请求**，得到的是它在那一刻的答案 | 重发时可观察到什么 |
| **6 事件** | **入口层不发、不订阅、不转发任何事件**；领域的通知事件不上线 | — |
| **7 缺席时的默认答案** | 出示物缺席 ⇒ `login-state-rejected`（经 ② 的路由；[`data.identity-values/v1#S-18`](../../../data/identity-values/v1/contract.md#s-18-缺席即拒绝)）；**载荷里的身份值缺席 ⇒ `invalid-input`，不从任何地方补**；被投影条款写明「缺席取默认」的非身份项（时长、指定角色、过滤开关、创建键）缺席时**原样作缺席交下去**，由领域取它自己的默认，入口层不替它填 | — |
| **8 在途归属** | 入口拥有受认证请求的临时结果与共同提交；领域事实仍归各owner，结束后不跨请求保存授权状态；答复没送达时，事实要么已提交、要么没发生（[§6.8](../../../../product/PF-017-governance-center-as-deployable-application/design.md#68-停机已确认的都在没确认的等于没发生)）；其间的撤销见 [S-33](#s-33-认出人之后登录状态被撤销) | 多步路由写明中途失败留下什么 |
| **9 装配给／协议给** | S36的认人/句柄、身份与授权现读、有效性/活动、可用性/整体装载、持久性及在途条款按本路由是否认证/写入适用；免认人注册沿注册链，登录沿AI15独立提交；公开体检沿S18不查存储 | 本行精确投影的能力条款仍拥有业务前提；不按旧S36行号或行名寻找附加保证 |

新增路由的完整九项规则沿S49～53与本节共同表合成；expectedTenant按S51补进本节所有适用载荷，旧表不列该比较成员不表示可省。

**线上形状归本契约**：参与能力不发布此边界的 Schema，**31 条路由的载荷与成功返回的线上形状由本契约定义**；
成员名从各条款 ①／⑤ 的散文措辞推出，列在下面的命名表里，Schema 里每条路由各一个 `Payload_<路由>` 与 `Result_<路由>`，成员封闭。
身份值一律按 `data.identity-values` v1 的规范形式、引用它的 Schema；邀约的两个时刻与派生状态引用 `data.offer-expiry` v2 的 Schema。
**载荷的expectedTenant仅供比较，不决定「以谁的身份」**（[S-12](#s-12-身份推导)）：下表「推导」一栏的身份值不在载荷里。
这张表的成员名是本契约**首次命名**，2026-09-23 已由主线认可进命名账本（[G-9](#十三已知缺口) 已闭合）；此后任何改名都是本契约的语义变更。

#### 命名原则

- camelCase。**标识按它指认的东西取名，不带 `Id` 后缀**，与 `TenantId` 的两个分量 `organization`／`account` 同式：`organization`、`tenant`、`invitation`、`affiliationRequest`。
- **同一个概念跨路由同名**：发起方组织一律 `issuerOrganization`（与 `issuerIsPersonalOrganization` 同词）；被邀请的账号一律 `invitedAccount`（与 `notTheInvitedAccount` 同词）；接收方组织 `recipientOrganization`；角色一律 `role`（与 `MembershipStanding` 的 `role` 同）；这一份的有效时长 `offerTtl`（`data.offer-expiry` v2 的 `offer_ttl`，与部署参数 `…TtlDefault` 同式）；过滤开关 `includeConcluded`（与 `alreadyConcluded` 同词）、`includeIneffective`（与 `ineffective` 同词）。
- **已有账本名不另起**：`loginState`、`loginStateHandle`、`issuedAt`；值类型沿用它在 `data.identity-values`／`data.offer-expiry` 里的名字：`organizationKind`、`offerTiming`、`offerState`。
- **⑤ 是一个值就直接给那个值**，不包一层对象；⑤ 是 `ok` 就是字符串 `"ok"`。**可选项缺席就是不出现**，不写 `null`。

#### 路由的线上成员（命名表）

「IV」= `data.identity-values` v1 的 Schema 定义，「OE」= `data.offer-expiry` v2 的；`?` = 可选（缺席时原样作缺席交给领域，[S-17](#s-17-路由表封闭每条路由的九件事从哪读) 第 7 件事）。

| 路由 | 载荷成员 · 类型 · ← 参与条款 ① 的哪一项 | 推导（不在载荷里） | 成功返回 · ← ⑤ |
|---|---|---|---|
| 注册 `composition.account-registration/v2#S-8` | `loginIdentifier` · IV `LoginIdentifier` ← 登录标识；`credential` · 非空字符串（内部格式见下注 1） ← 凭据材料 | — | `"registered"` ← `registered`（[AR S-4](../../account-registration/v2/contract.md#s-4-注册成功)、[AR S-5](../../account-registration/v2/contract.md#s-5-终结结果集合)） |
| 登录 `capability.account-identity/v3#S-15` | `loginIdentifier`、`credential`，同上 ← ① 登录标识、凭据材料 | — | `{ loginState, loginStateHandle }` ← `{出示物, LoginStateId}`（句柄就是 LoginStateId，[S-9](#s-9-列表句柄)） |
| 撤销 `capability.account-identity/v3#S-16` | `loginStateHandle` · IV `LoginStateId` ← 目标 LoginStateId（[S-20](#s-20-登录状态的两条路由撤销列出)） | 认人所得 LoginStateId（发起方） | `"ok"` ← `ok` |
| 列出 `capability.account-identity/v3#S-37` | 无 | 认人所得 LoginStateId | `[{ loginStateHandle, issuedAt, lastActivityAt, absoluteExpiresAt, idleExpiresAt }]`，至少一项 ← 每项的LoginStateId、I、L、I+8h、L+1h（四个时间均为OE Instant）；取读取时值，不反写随后touch值 |
| `capability.organization-governance/v2#S-21` | `creationKey?` · `CreationKey` ← 创建键 | 认人所得 AccountId（创建者） | IV `OrganizationId` ← `OrganizationId` |
| `capability.organization-governance/v2#S-22` | `organization` · IV `OrganizationId` ← `OrganizationId` | — | `{ organization, organizationKind, parentOrganization? }` ← `{ OrganizationId, OrganizationKind, 上级组织（有或无） }` |
| `capability.organization-governance/v2#S-23` | `invitedAccount` · IV `AccountId` ← 目标 AccountId；`role?` · IV `TenantRole` ← 指定角色；`offerTtl?` · 整数毫秒 ← 这一份的有效时长 | 推导所得 TenantId（发起者） | `InvitationId` ← `InvitationId` |
| `capability.organization-governance/v2#S-24` | `invitation` · `InvitationId` ← `InvitationId` | 推导所得 TenantId（发起者） | `"ok"` |
| `capability.organization-governance/v2#S-25` | `invitation` ← `InvitationId` | 认人所得 AccountId（接受者） | IV `TenantId` ← `TenantId` |
| `capability.organization-governance/v2#S-26` | `tenant` · IV `TenantId` ← `TenantId` | — | IV `MembershipStanding` ← 一个 `MembershipStanding` |
| `capability.organization-governance/v2#S-27` | 无 | 认人所得 AccountId | `[TenantId]`，至少一项 ← `TenantId` 列表 |
| `capability.organization-governance/v2#S-28` | `targetTenant` · IV `TenantId` ← 目标 TenantId；`role` · IV `TenantRole` ← 目标角色 | 推导所得 TenantId（发起者） | `"ok"` |
| `capability.organization-governance/v2#S-29` | `targetTenant` ← 目标 TenantId | 推导所得 TenantId（发起者） | `"ok"` |
| `capability.organization-governance/v2#S-30` | `recipientOrganization` · IV `OrganizationId` ← 接收方 OrganizationId；`direction` · `recipientAsParent`／`recipientAsChild` ← 方向；`offerTtl?` ← 这一份的有效时长 | 推导所得 TenantId（发起者） | `AffiliationRequestId` ← `AffiliationRequestId` |
| `capability.organization-governance/v2#S-31` | `affiliationRequest` · `AffiliationRequestId` ← `AffiliationRequestId` | 推导所得 TenantId（发起者） | `"ok"` |
| `capability.organization-governance/v2#S-32` | `affiliationRequest` ← `AffiliationRequestId` | 推导所得 TenantId（接受者） | `"ok"` |
| `capability.organization-governance/v2#S-33` | `childOrganization` · IV `OrganizationId` ← 被解除的那条隶属关系（下级 OrganizationId） | 推导所得 TenantId（发起者） | `"ok"` |
| `capability.organization-governance/v2#S-34` | `organizations` · 一或两个 IV `OrganizationId` ← 一个或两个 `OrganizationId` | — | 一个 ⇒ `[OrganizationId]`（上级链，不含自己）；两个 ⇒ 布尔（有共同上级） |
| `capability.organization-governance/v2#S-35` | `tenant` ← `TenantId` | — | `{ organizationLayer, tenantLayer }`，各一个 IV `ScopeLayerIdentity`（`layer` 分别是 `organization`／`tenant`）← 组织级、租户级 |
| `capability.organization-governance/v2#S-36` | 无 | 认人所得 LoginStateId | IV `TenantId` ← `TenantId` |
| `capability.organization-governance/v2#S-37` | `targetTenant` ← 目标 TenantId | 认人所得 LoginStateId | `"ok"` |
| `capability.organization-governance/v2#S-55` | `invitation` ← `InvitationId`；`callerIdentityKind` · `account`／`tenant` ← 调用方身份的判别式 | 按判别式取认人所得 AccountId 或推导所得 TenantId（调用方） | `InvitationView` ← ⑤ |
| `capability.organization-governance/v2#S-56` | `affiliationRequest` ← `AffiliationRequestId` | 推导所得 TenantId（调用方） | `AffiliationRequestView` ← ⑤ |
| `capability.organization-governance/v2#S-57` | `includeConcluded?` · 布尔 ← 「连已终结的一起要」 | 认人所得 AccountId | `[InvitationView]` ← 邀请列表 |
| `capability.organization-governance/v2#S-58` | `includeConcluded?` | 推导所得 TenantId（调用方） | `{ invitations: [InvitationView], affiliationRequests: [AffiliationRequestView] }` ← 两段 |
| `capability.organization-governance/v2#S-59` | `includeIneffective?` · 布尔 ← 「连无效的一起要」 | 推导所得 TenantId（调用方） | `[MemberView]` ← 成员关系记录列表 |
| `capability.organization-governance/v2#S-60` | `includeConcluded?` | 推导所得 TenantId（调用方） | `[IncomingAffiliationRequestView]` ← 收到的隶属请求列表 |

| 共用形状 | 成员 | ← 出处 |
|---|---|---|
| `OrganizationView` | `organization`、`organizationKind`（IV `OrganizationKind`）、`parentOrganization?` | [OG S-22](../../../capabilities/organization-governance/v2/contract.md#s-22-读组织) ⑤；「无上级」⇒ 成员不出现 |
| `InvitationView` | `invitation`、`issuerOrganization`、`invitedAccount`、`role`、`offerTiming`（OE `OfferTiming`）、`offerState`（OE `OfferState`） | [OG S-55](../../../capabilities/organization-governance/v2/contract.md#s-55-读邀请) ⑤ `{ InvitationId, 发出它的组织, 被邀请的账号, 指定的角色, OfferTiming, 派生状态 }` |
| `AffiliationRequestView` | `affiliationRequest`、`issuerOrganization`、`recipientOrganization`、`direction`、`offerTiming`、`offerState` | [OG S-56](../../../capabilities/organization-governance/v2/contract.md#s-56-读隶属请求) ⑤ `{ AffiliationRequestId, 发起方组织, 接收方组织, 方向, OfferTiming, 派生状态 }` |
| `IncomingAffiliationRequestView` | 同上，没有 `recipientOrganization` | [OG S-60](../../../capabilities/organization-governance/v2/contract.md#s-60-列出组织收到的隶属请求) ⑤（接收方就是调用方自己，那一条不列它） |
| `MemberView` | `tenant`、`role`、`effective`（布尔） | [OG S-59](../../../capabilities/organization-governance/v2/contract.md#s-59-列出组织成员) ⑤ `{ TenantId, 角色, 有效性 }`；`effective` 是记录此刻的有效性，**不是**一次 `MembershipStanding` 判定 |

**散文推不出、或靠推导补上的地方**，逐条写明，不自造语义：

1. **`credential` 在线上是一个非空字符串**（Schema `CredentialMaterial`）；它的**内部格式**归凭据方案的 owner——与 [AI S-26](../../../capabilities/account-identity/v3/contract.md#s-26-credential_policy) `credential_policy` 同一个 owner（[AI S-8](../../../capabilities/account-identity/v3/contract.md#s-8-凭据材料)：结构、强度规则与比对方式属实现选择）。
   入口层的表示层校验**用该 owner 给出的同一条解析规则**，解析不过 ⇒ `invalid-input`（[S-19](#s-19-免认人的两条路由注册登录)）。入口层不自定第二套，也不对它做 Schema 之外的收紧。
2. **首次命名的取值**：`direction` 的两个取值 `recipientAsParent`／`recipientAsChild`。[OG S-11](../../../capabilities/organization-governance/v2/contract.md#s-11-隶属请求) 与 [OG S-30](../../../capabilities/organization-governance/v2/contract.md#s-30-发出隶属请求) ① 只有「请对方作自己的上级／下级」的散文，没有取值名。
3. **表示上的推导**：
   - `InvitationId`、`AffiliationRequestId`、`CreationKey`（创建键）是**本契约自定的三个值定义**，形状按 [`data.identity-values/v1#S-31`](../../../data/identity-values/v1/contract.md#s-31-不透明标识的交换表示) 的散文（非空、首尾不得是那张表里的空白码点、逐码点相等）——OG 只说它们不透明；
   - `offerTtl` 取整数毫秒——与部署参数的两个默认时长同一概念、同一表示。**线上只约束「是整数，且不大于 2⁵³−1」**（上界是 JSON 数在各实现里都能精确表示的最大整数）：不合这一条是入口的 `invalid-input`；
     合这一条但非正，原样交给OG S23并返回invalidOfferDuration；合法正时长与发出时刻计算溢出则消费OE2 S14返回unavailable，不写邀约。这两种失败不可合并。
     线上「不是整数」这一支到不了 OG——线上的形状归本契约（[S-17](#s-17-路由表封闭每条路由的九件事从哪读)），所以它是 `invalid-input`，不与 OG 的字面冲突；
   - [OG S-34](../../../capabilities/organization-governance/v2/contract.md#s-34-上级链与有共同上级) 的一个操作两种返回，按载荷里组织的个数区分。

**答复不带 `operation`**：只看一个答复判不出它属于哪条路由，所以 Schema 的 `RouteSuccess.result` 是 31 个 `Result_<路由>` 的并；
按路由的核对用 Schema 的 `Exchange`（把请求的 `operation` 与它的答复放在一起，线上没有这个对象）。

### S-18 公开体检

本契约自有的操作，路由标识 `composition.governance-center-entry/v1#S-18`。

| 九件事 | 内容 |
|---|---|
| **1 输入与授权** | 请求是一个对象，其 `operation` 成员等于上述路由标识；**其余成员一律忽略**——包括 `protocolVersion` 与出示物。**无授权**：任何够得到中心的人在登录之前就能读（[§6.17](../../../../product/PF-017-governance-center-as-deployable-application/design.md#617-体检只说部署不说里面有谁)） |
| **2 前置** | 中心在应答。**不受版本那一关挡，不看出示物，不读存储，不读钟** |
| **3 提交点与原子性** | 无。纯读，读的全是启动时已载入的常量 |
| **4 返回与失败集合** | `{ reachable: true, centerId: GovernanceCenterId, version }`，恰此三样。**失败集合为空**：中心在应答就答得出；中心不在应答时来者什么都得不到（那是「问不到」，不是一个答复） |
| **5 幂等边界与重发** | 纯读，任意重复。三样在一次运行期间不变 |
| **6 事件** | 无 |
| **7 缺席时的默认答案** | 不适用：本操作没有输入。**`reachable` 只说「中心在应答」**，不说此刻能不能答别的事；数据所在够不着、钟倒退、中心自身故障时照样答 `true`，标识与版本照样读得出（[§4 中心体检](../../../../product/PF-017-governance-center-as-deployable-application/design.md#中心体检)） |
| **8 在途归属** | 无 |
| **9 装配给／协议给** | 请求与答复形状**跨协议版本不变**（[S-8](#s-8-协议版本与跨版本不变的两样)）；`centerId` 是启动时载入的那一个（[S-28](#s-28-铸造存放与不变)） |

**不含**任何治理事实（账号数、组织、谁登录着）与任何秘密的值。`version` 是中心所装版本的标识；它与 `accepted_protocol_versions` 的对应关系归技术设计。

### S-19 免认人的两条路由：注册、登录

这两条**不经第 ② 步**，出示物带了也不看（[§6.2 例外的边界](../../../../product/PF-017-governance-center-as-deployable-application/design.md#62-中心只认登录状态不认客户端)）。
注册不设任何门槛，靠的是[部署前提](../../../../product/PF-017-governance-center-as-deployable-application/design.md#部署前提)：够得到中心的就是组织里的人。

**两条路由的载荷表示层校验相同**：`loginIdentifier` 按 IV `LoginIdentifier` 的形状判；`credential` 须是非空字符串，并**用凭据方案 owner 给出的那一条解析规则**判——
那个 owner 与 [AI S-26](../../../capabilities/account-identity/v3/contract.md#s-26-credential_policy) `credential_policy` 是同一个，入口层不自定第二套。
**解析不过 ⇒ `invalid-input`，从不把解析不过的值交给领域**。解析只判「它是不是那个方案下的一份凭据材料」，不判它可不可接受——可接受与否是 `credential_policy` 的事，在注册里收成 `credential-rejected`。
**那条解析规则的发布处**是凭据方案 owner 的实现映射节点 [`realization/packages/tenancy/credential-verification`](../../../../realization/packages/tenancy/credential-verification/README.md)；据点侧的客户端代理据它得知 `credential` 该送什么。
**换凭据方案会移动线上 `invalid-input` 的边界，须发本契约的新版本**——不得只换那个节点而让本契约的线上答复悄悄变样。

| 路由 | 身份怎么推 | 载荷 | 返回与映射 | 重发 | 第 9 件事（另读 S-36 的） |
|---|---|---|---|---|---|
| **注册** `composition.account-registration/v2#S-8` | 无身份可推 | 登录标识、凭据材料。**表示层校验归本组合**（[AR S-2「注册入口」一行](../../account-registration/v2/contract.md#s-2-参与方与精确承诺)）：不合格 ⇒ `invalid-input`，**不交进去**（交进去的收场是 `interrupted`） | [四个终结结果](../../account-registration/v2/contract.md#s-5-终结结果集合)：`registered`（[注册成功](../../account-registration/v2/contract.md#s-4-注册成功)）⇒ `{ result: "registered" }`；`identifier-taken`／`credential-rejected`／`interrupted` ⇒ `{ failure: <原名> }`。**`interrupted` 原样呈现，不改写**——不改成成功、不改成 `identifier-taken`，**也不改成 `unavailable`**：它已经含着「底层不可用」那一支（[AR S-6](../../account-registration/v2/contract.md#s-6-每个终结结果的含义与对应的存储状态)），其含义为本次未取得可确认成功；不证明账号未激活或业务未提交。`identifier-held-by-expired-record` **结构上到不了**本组合（它在注册组合内部就地消化）；出现即缺陷 | 按 [AR S-12](../../account-registration/v2/contract.md#s-12-重试规则)：同一标识、同一凭据重来，接着走完或得 `identifier-taken`（激活已提交而回执丢失时） | 「注册入口与清除限制」 |
| **登录** `capability.account-identity/v3#S-15` | 无身份可推 | 登录标识、凭据材料（表示层校验同上） | 成功 ⇒ `{ result: { loginState, loginStateHandle } }`：`loginState` 是 AI S-15 交出的**出示物（它在全部输出里唯一出现的一处）**，`loginStateHandle` 是同一个登录状态的 `LoginStateId`，即它的列表句柄——客户端据后者在列表里认出自己、用它退出（[S-9](#s-9-列表句柄)）。`identifier-or-credential-rejected` 原样透传：**三种登录失败逐字相同**（[AI S-15](../../../capabilities/account-identity/v3/contract.md#s-15-验证凭据并签发登录状态)）。`invalid-input` ⇒ `invalid-input`；`storage-unavailable` ⇒ `unavailable` | **不幂等**：重发会签发另一个登录状态；多出来的那个在列表里看得见、撤得掉（[AI S-15 在途归属](../../../capabilities/account-identity/v3/contract.md#s-15-验证凭据并签发登录状态)） | 「认人、出示物安全、句柄来源」「认人、出示物安全、句柄来源」（新签发的那一个就是此后的出示物）「有界登录与成功活动」 |

提交点：注册是[激活那一次提交](../../account-registration/v2/contract.md#s-8-三步次序与责任交接)；登录是登录状态记录写入的那一次提交。

### S-20 登录状态的两条路由：撤销、列出

两条都经第 ② 步；交给领域的发起方、调用方 `LoginStateId` 是认人所得 `LoginStateId`（[S-12](#s-12-身份推导)；[PF-001 §4 登录状态](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#登录状态)：一台机器上的一个登录状态可以被列出、被撤销）。

| 路由 | 身份怎么推 | 载荷 | 返回与映射 | 重发 | 第 9 件事（另读 S-36 的） |
|---|---|---|---|---|---|
| **撤销（含退出）** `capability.account-identity/v3#S-16` | 发起方 = 认人所得 `LoginStateId`；**目标 = 载荷里的 `loginStateHandle`**，即目标登录状态的 `LoginStateId`（[S-9](#s-9-列表句柄)），原样交给 [AI S-16](../../../capabilities/account-identity/v3/contract.md#s-16-撤销登录状态)——它只作对象，**从不作认人依据**。AI S-16 明写目标可以来自线上载荷，按来源读的只是发起方 | `loginStateHandle`（必需，无默认值——**缺席不是「退出自己」**；退出就是带上自己那一个的句柄） | 成功 `ok`，含 AI S-16「已撤销 ⇒ `ok`」那一支（目标已被撤掉、发起方仍有效时）。`login-state-not-found` **原样透传**——AI S-16 把「不存在」「不是你的」并成的那一个值，产品反馈是[「这个登录已经不在有效之列」](../../../../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常)。`not-authorized` ⇒ `login-state-rejected`（发起方在认人之后被撤，[S-33](#s-33-认出人之后登录状态被撤销)）；`invalid-input` ⇒ `invalid-input`（交进去的输入里有来自载荷的目标，[S-14](#s-14-失败映射)）；`storage-unavailable` ⇒ `unavailable` | 撤销已提交、答复丢了之后重发：**撤的是别的那一个** ⇒ AI S-16 幂等 ⇒ `ok`；**撤的是自己（退出）** ⇒ 第 ② 步就 `login-state-rejected`。两者都是「已经撤掉了」的可观察形式 | 「有界登录与成功活动」 |
| **列出** `capability.account-identity/v3#S-37` | 调用方 = 认人所得 `LoginStateId` | 无（空对象） | 成功 ⇒ `{ result: [ … ] }`，每一项恰为 `{ loginStateHandle, issuedAt, lastActivityAt, absoluteExpiresAt, idleExpiresAt }`：`loginStateHandle` 是那一项的 `LoginStateId`，`issuedAt`为I，lastActivityAt为读取时L，absoluteExpiresAt为I+8h，idleExpiresAt为L+1h，四者均OE Instant。随后touch不反向改写该次列表。**不含出示物**（AI 本来就不给，[AI S-37](../../../capabilities/account-identity/v3/contract.md#s-37-列出本账号有效登录状态)）。空列表 ⇒ 缺陷（成功调用必含调用方自己那一个）。`login-state-rejected` ⇒ `login-state-rejected`；`storage-unavailable` ⇒ `unavailable`；`invalid-input` ⇒ 缺陷 | 读取可重复，成功更新活动 | 「有界登录与成功活动」（列表里不再有已撤销的） |

撤销经参与面在S49共同提交中执行，成功后最终活动不复活已撤销自身。入口不先读列表；目标归属仍由AI判定。

### S-21 组织治理：写路由

全部经第 ② 步。「认人所得 `AccountId`」「推导所得 `TenantId`」见 [S-12](#s-12-身份推导)。
提交点一律是被投影条款 ④ 的单次提交。
**第 9 件事**：全部写路由另读 [S-36](#s-36-装配给的保证-vs-协议须给的保证) 的「认人、出示物安全、句柄来源」；以推导所得 `TenantId` 行事的另读「每道准入现读、当前选择与成员资格可见性」「每道准入现读、当前选择与成员资格可见性」。下表末列只写此外的行。

| 路由 `capability.organization-governance/v2#…` | 交给领域的身份 | 载荷（该条款 ① 的哪几项） | 透传的具名值 | 重发 | 第 9 件事（此外另读的） |
|---|---|---|---|---|---|
| [`S-21`](../../../capabilities/organization-governance/v2/contract.md#s-21-创建团队组织) 创建团队组织 | 认人所得 `AccountId`（创建者） | 创建键（可选） | 无。`accountNotActivated`、`accountDoesNotExist` 在这里说的是调用方本人，**出现即缺陷**（[S-14](#s-14-失败映射)） | 带创建键 ⇒ 认回同一个组织；**不带 ⇒ 每次一个新组织**。客户端要安全重发，就带创建键 | — |
| [`S-23`](../../../capabilities/organization-governance/v2/contract.md#s-23-发出邀请) 发出邀请 | 推导所得 `TenantId`（发起者） | 目标 `AccountId`、指定角色（可选）、时长（可选） | `issuerIsPersonalOrganization`、`notAuthorized`、`accountNotActivated`、`accountDoesNotExist`（说的是被邀请者）、`alreadyAnEffectiveMember`、`invalidOfferDuration` | 不幂等：重发多一份邀请（该条款 ⑦：不制造新状态）。**时长是否为正由领域判**，`invalidOfferDuration` 原样透传；入口层对 `offerTtl` 只校验它是不大于 2⁵³−1 的整数（毫秒），不合 ⇒ `invalid-input` | 「持有AccountId的内部读面不上线」（残余暴露）、「邀约时间、状态与不可用」、「邀约时间、状态与不可用」、「邀约时间、状态与不可用」 |
| [`S-24`](../../../capabilities/organization-governance/v2/contract.md#s-24-撤回邀请) 撤回邀请 | 推导所得 `TenantId`（发起者） | `InvitationId` | `invitationDoesNotExist`、`notAuthorized`、`alreadyConcluded` | 幂等：已撤回 ⇒ `ok` | 「每道准入现读、当前选择与成员资格可见性」 |
| [`S-25`](../../../capabilities/organization-governance/v2/contract.md#s-25-接受邀请) 接受邀请 | 认人所得 `AccountId`（接受者） | `InvitationId` | `invitationDoesNotExist`、`offerNoLongerValid`、`notTheInvitedAccount`、`alreadyAnEffectiveMember`。`accountNotActivated`、`accountDoesNotExist` 说的是调用方本人，**出现即缺陷** | 已接受、答复丢了之后重发 ⇒ `offerNoLongerValid`；客户端据「我的租户」确认自己已在其中 | 「邀约时间、状态与不可用」、「邀约时间、状态与不可用」、「每道准入现读、当前选择与成员资格可见性」 |
| [`S-28`](../../../capabilities/organization-governance/v2/contract.md#s-28-调整角色) 调整角色 | 推导所得 `TenantId`（发起者） | 目标 `TenantId`、目标角色 | `notAuthorized`、`membershipNotEffective`、`wouldLeaveNoSuperAdministrator` | 幂等 | 「每道准入现读、当前选择与成员资格可见性」、「身份形状与隔离」 |
| [`S-29`](../../../capabilities/organization-governance/v2/contract.md#s-29-解除成员) 解除成员 | 推导所得 `TenantId`（发起者） | 目标 `TenantId` | `personalOrganizationMemberCannotLeave`、`notAuthorized`、`membershipNotEffective`、`wouldLeaveNoSuperAdministrator` | 已解除后重发 ⇒ `membershipNotEffective` | 「每道准入现读、当前选择与成员资格可见性」、「身份形状与隔离」 |
| [`S-30`](../../../capabilities/organization-governance/v2/contract.md#s-30-发出隶属请求) 发出隶属请求 | 推导所得 `TenantId`（发起者） | 接收方 `OrganizationId`、方向、时长（可选） | `personalOrganizationTakesNoPartInAffiliation`、`notAuthorized`、`organizationDoesNotExist`、`wouldFormACycle`、`invalidOfferDuration` | 不幂等，同 [OG S-23](../../../capabilities/organization-governance/v2/contract.md#s-23-发出邀请) 一行 | 「邀约时间、状态与不可用」、「邀约时间、状态与不可用」、「邀约时间、状态与不可用」 |
| [`S-31`](../../../capabilities/organization-governance/v2/contract.md#s-31-撤回隶属请求) 撤回隶属请求 | 推导所得 `TenantId`（发起者） | `AffiliationRequestId` | `affiliationRequestDoesNotExist`、`notAuthorized`、`alreadyConcluded` | 幂等 | — |
| [`S-32`](../../../capabilities/organization-governance/v2/contract.md#s-32-接受隶属请求) 接受隶属请求 | 推导所得 `TenantId`（接受者） | `AffiliationRequestId` | `affiliationRequestDoesNotExist`、`offerNoLongerValid`、`notAuthorized`、`alreadyHasAParentOrganization`、`wouldFormACycle`、`personalOrganizationTakesNoPartInAffiliation` | 已接受后重发 ⇒ `offerNoLongerValid` | 「邀约时间、状态与不可用」、「邀约时间、状态与不可用」 |
| [`S-33`](../../../capabilities/organization-governance/v2/contract.md#s-33-解除隶属) 解除隶属 | 推导所得 `TenantId`（发起者） | 下级 `OrganizationId` | `noSuchAffiliation`、`notAuthorized` | 已解除后重发 ⇒ `noSuchAffiliation` | — |

OG23按AccountId发邀请；本版另由S50限定组合支持按登录标识邀请，不开放账号搜索。

### S-22 组织治理：读路由与补授权

全部经第 ② 步；标「补授权」的四条先过 [S-13](#s-13-补授权)。领域读取可重复；入口成功读取仍按S49共同提交最后活动，不是无写操作。
**第 9 件事**：全部读路由另读 [S-36](#s-36-装配给的保证-vs-协议须给的保证) 的「认人、出示物安全、句柄来源」；以推导所得 `TenantId` 行事的另读「每道准入现读、当前选择与成员资格可见性」「每道准入现读、当前选择与成员资格可见性」。下表末列只写此外的行。

| 路由 `capability.organization-governance/v2#…` | 交给领域的身份 | 补授权 | 载荷 | 透传的具名值与例外 | 第 9 件事（此外另读的） |
|---|---|---|---|---|---|
| [`S-22`](../../../capabilities/organization-governance/v2/contract.md#s-22-读组织) 读组织 | 无 | 有 | `OrganizationId` | `notAuthorized`（补授权给出）；`organizationDoesNotExist` 经补授权到不了 | 「每道准入现读、当前选择与成员资格可见性」（补授权那次现读） |
| [`S-26`](../../../capabilities/organization-governance/v2/contract.md#s-26-成员资格判定) 成员资格判定 | 无 | 有 | `TenantId` | `notAuthorized`（补授权给出）。成功 ⇒ 一个 `MembershipStanding`；`{ failure: "unavailable" }` ⇒ `unavailable` | 「每道准入现读、当前选择与成员资格可见性」、「身份形状与隔离」 |
| [`S-27`](../../../capabilities/organization-governance/v2/contract.md#s-27-我的租户) 我的租户 | 认人所得 `AccountId` | 无 | 无 | 无具名值。`invalidInput` ⇒ 缺陷。**空列表 ⇒ 缺陷**：认得出的来者是已激活的账号，而已激活的账号[本版不可能一个有效租户都没有](../../../capabilities/organization-governance/v2/contract.md#s-27-我的租户) | 「每道准入现读、当前选择与成员资格可见性」、「身份形状与隔离」 |
| [`S-34`](../../../capabilities/organization-governance/v2/contract.md#s-34-上级链与有共同上级) 上级链／有共同上级 | 无 | 有（每一个组织，不短路） | 一个或两个 `OrganizationId` | `notAuthorized`（补授权给出）；`organizationDoesNotExist` 经补授权到不了 | 「每道准入现读、当前选择与成员资格可见性」（补授权那次现读） |
| [`S-35`](../../../capabilities/organization-governance/v2/contract.md#s-35-层身份) 层身份 | 无 | 有 | `TenantId` | `notAuthorized`（补授权给出）。返回的两个 `ScopeLayerIdentity` 按 [`data.identity-values/v1#S-11`](../../../data/identity-values/v1/contract.md#s-11-scopelayeridentity) 带判别式原样给出 | 「身份形状与隔离」、「身份形状与隔离」 |
| [`S-55`](../../../capabilities/organization-governance/v2/contract.md#s-55-读邀请) 读邀请 | 调用方身份按载荷里的判别式：`account` ⇒ 认人所得 `AccountId`；`tenant` ⇒ 推导所得 `TenantId` | 无 | `InvitationId`、调用方身份的判别式 `callerIdentityKind`（`account`／`tenant`，不含身份值本身） | `invitationDoesNotExist`。判别式缺席或不在集合内 ⇒ `invalid-input`，**入口层不替它猜是哪一支** | 「邀约时间、状态与不可用」、「邀约时间、状态与不可用」 |
| [`S-56`](../../../capabilities/organization-governance/v2/contract.md#s-56-读隶属请求) 读隶属请求 | 推导所得 `TenantId`（调用方） | 无 | `AffiliationRequestId` | `affiliationRequestDoesNotExist` | 同上 |
| [`S-57`](../../../capabilities/organization-governance/v2/contract.md#s-57-列出账号收到的待接受邀请) 列出账号收到的待接受邀请 | 认人所得 `AccountId` | 无 | 过滤开关（可选） | 无具名值 | 同上 |
| [`S-58`](../../../capabilities/organization-governance/v2/contract.md#s-58-列出组织发出的邀请与隶属请求) 列出组织发出的邀请与隶属请求 | 推导所得 `TenantId`（调用方） | 无 | 过滤开关（可选） | `notAuthorized` | 同上 |
| [`S-59`](../../../capabilities/organization-governance/v2/contract.md#s-59-列出组织成员) 列出组织成员 | 推导所得 `TenantId`（调用方） | 无 | 过滤开关（可选） | `notAuthorized` | 「每道准入现读、当前选择与成员资格可见性」 |
| [`S-60`](../../../capabilities/organization-governance/v2/contract.md#s-60-列出组织收到的隶属请求) 列出组织收到的隶属请求 | 推导所得 `TenantId`（调用方） | 无 | 过滤开关（可选） | `notAuthorized` | 「邀约时间、状态与不可用」、「邀约时间、状态与不可用」 |

**读成员名单、邀约、隶属请求时的组织是当前租户身份的那个组织**（[OG S-56](../../../capabilities/organization-governance/v2/contract.md#s-56-读隶属请求)、[OG S-58](../../../capabilities/organization-governance/v2/contract.md#s-58-列出组织发出的邀请与隶属请求)～[S-60](../../../capabilities/organization-governance/v2/contract.md#s-60-列出组织收到的隶属请求) 的调用方是推导所得 `TenantId`）；要读另一个组织的，先切过去。

### S-23 当前租户身份的两条路由

| 路由 `capability.organization-governance/v2#…` | 交给领域的身份 | 载荷 | 返回与映射 | 提交与重发 | 第 9 件事（另读 S-36 的） |
|---|---|---|---|---|---|
| [`S-36`](../../../capabilities/organization-governance/v2/contract.md#s-36-当前租户身份查询) 当前租户身份查询 | 认人所得 `LoginStateId` | 无 | 成功 ⇒ `{ result: TenantId }`（规范形式）。`loginStateNotValid` ⇒ `login-state-rejected`；`invalidInput` ⇒ 缺陷；返回的 `account` 分量不等于认人所得 `AccountId` ⇒ 缺陷 | 读取可重复，成功更新活动 | 「每道准入现读、当前选择与成员资格可见性」、「身份形状与隔离」 |
| [`S-37`](../../../capabilities/organization-governance/v2/contract.md#s-37-切换当前租户身份) 切换当前租户身份 | 认人所得 `LoginStateId` | 目标 `TenantId` | `ok`；透传 `notOwnTenant`、`membershipNotEffective`；`loginStateNotValid` ⇒ `login-state-rejected` | S49共同提交；带旧expectedTenant重发可能expectedTenantMismatch，先查询真实选择，不自动重试 | 「每道准入现读、当前选择与成员资格可见性」、「每道准入现读、当前选择与成员资格可见性」、「身份形状与隔离」 |

**切换提交之后，下一个请求的身份推导就读到新值**（[S-15](#s-15-δ--0每个请求现读入口不跨请求缓存)；[PF-001 §4 当前租户身份](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#当前租户身份)）。本路由**不是**[三类现读](../../../../product/PF-016-cli-tui-delivery-surface/design.md#69-需要现读成员资格的那几件事不拿副本放行)的放行者——那一侧归据点；本契约只保证中心此刻的答案是现读的。

### S-24 有意不投影

下列操作**没有路由**。路由表是封闭的，不在表里就是没有这扇门，不是「有门但被拒」
（[§6.13](../../../../product/PF-017-governance-center-as-deployable-application/design.md#613-运维者没有任何一扇门通向账号能做的事)；谁能做什么见 [flows §4 角色与操作](../../../../product/PF-017-governance-center-as-deployable-application/flows.md#四角色与操作)）。

| 不投影的 | 为什么 |
|---|---|
| [AI S-13](../../../capabilities/account-identity/v3/contract.md#s-13-产生账号未激活)、[AI S-14](../../../capabilities/account-identity/v3/contract.md#s-14-激活账号)、[AI S-38](../../../capabilities/account-identity/v3/contract.md#s-38-清除到期的未激活账号记录) | 只归注册组合（它们的唯一调用方）；从线上直接够到，`identifier-held-by-expired-record` 就流向了终端（[S-36](#s-36-装配给的保证-vs-协议须给的保证) 的对应行） |
| [AI S-18](../../../capabilities/account-identity/v3/contract.md#s-18-读账号)（读账号） | 它以「持有 `AccountId` 即可读」为授权；上线等于让任何拿到一个 `AccountId` 的人读它的激活与过期状态 |
| [AI S-44](../../../capabilities/account-identity/v3/contract.md#s-44-按出示物换取身份)、[AI S-17](../../../capabilities/account-identity/v3/contract.md#s-17-校验登录状态) 作为路由 | AI S-44 是每个经 ② 的请求的第 ② 步，不另开一条；AI S-17 按 `LoginStateId` 认人，**只对进程内调用方开放**（AI S-30 的「只有 S-44 认出示物」行），上线就等于让任何读到列表的人认成别人 |
| [OG S-20](../../../capabilities/organization-governance/v2/contract.md#s-20-创建个人组织)（创建个人组织） | 只归注册组合的动作链 |
| [OG S-53](../../../capabilities/organization-governance/v2/contract.md#s-53-清除未激活账号的个人组织)（清除个人组织） | 它没有授权前置，只能由注册组合的清除链调用；上线就是一条直接删任何账号个人组织的入口 |
| AR 的清除链 | 由清扫与注册主链发起，不是来者的动作 |
| 任何存储级、时钟级、部署级的面 | 中心的两张面没有第三张（[§5.1](../../../../product/PF-017-governance-center-as-deployable-application/design.md#51-中心有两张面没有第三张)）；客户端一面**没有任何写部署事实的操作**，也读不到完整体检 |
| 任何会话操作 | 中心不知道任何会话 |

## 五、运维面

### S-25 运维面只在中心所在的机器上，且没有治理路由

- **运维面**（无词条）是运行中的中心上属于[运维者](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-deployment-operator--运维者--deployment-operator)那一面的**唯一**部分，**只在中心所在的机器上可达**，与客户端一面**不共用任何通道**
（[PF-017 §4 运维者](../../../../product/PF-017-governance-center-as-deployable-application/design.md#运维者)、[§5.1 两张面](../../../../product/PF-017-governance-center-as-deployable-application/design.md#51-中心有两张面没有第三张)）。
  「只在本机可达」是部署边界（谁握着那台机器），**不是任何治理判定的输入**；客户端一面从不按对端地址放行（[S-16](#s-16-不记住来访不区别对待来者)）。
- **运行中运维面恰有三个逻辑操作**：读[完整体检](#s-26-完整体检)、[backup](#s-55-backup)、[backup-status](#s-56-backup-status)。31 条客户端业务路由没有增删。没有任何运维操作映射到账号、组织治理或注册的领域操作；不是有而拒绝，是没有。
- 完整体检保持纯读、原答复形状不变；backup 发布备份，backup-status 可重新取得已有输出的持久确认。两者均不改变治理事实、登录活动或授权。部署密钥、参数、版本、启停仍由部署管理承担。
- [verify](#s-57-verify) 与 [restore-isolated](#s-58-restore-isolated) 是同一运维者的本机文件工具；不要求运行中心，不占网络路由，不是第三张治理面。位置必须显式提供，不能借此访问运行中心的任意服务面。
- 本机机器控制是唯一授权前提，不接受账号或租户身份代替它；缺少此前提不开放工具。通道分离、没有治理路由及仅消费副本核对共同保证边界。握着宿主的人直接改数据不在产品沙箱保证内。

### S-26 完整体检

| 九件事 | 内容 |
|---|---|
| **1 输入与授权** | 无输入。无产品层授权：够得到运维面的就是握着那台机器的人——[运维者](../../../../product/PF-017-governance-center-as-deployable-application/design.md#运维者)（[S-25](#s-25-运维面只在中心所在的机器上且没有治理路由)） |
| **2 前置** | 中心在应答 |
| **3 提交点与原子性** | 无。纯读 |
| **4 返回与失败集合** | `{ reachable, centerId, version, startedAt, storageReachable, deploymentKeyPresent, deploymentKeyComplete, clockSane, defectCount, deploymentParameters }`，恰此十项。**失败集合为空**：每一项读不到都是一个答案（`false`），不是一次失败 |
| **5 幂等边界与重发** | 纯读，任意重复 |
| **6 事件** | 无 |
| **7 缺席时的默认答案** | `storageReachable`：**本次读取时**现探数据所在，探不通 ⇒ `false`；`clockSane`：**本次读取时**现读钟，读不到或比中心用过的最晚时刻早 ⇒ `false`；`defectCount`：自本次启动以来**入口层自己**记过的缺陷数（[S-14](#s-14-失败映射)），非负整数，重启归零；「记过缺陷」即 `defectCount > 0`。**不以「上一次读到的」顶替** |
| **8 在途归属** | 无 |
| **9 装配给／协议给** | 见 [S-36](#s-36-装配给的保证-vs-协议须给的保证) 的「运维者没有门」与「中心标识与治理事实同一存储」两行 |

| 项 | 含义 |
|---|---|
| `reachable`、`centerId`、`version` | 与[公开体检](#s-18-公开体检)同。**`reachable` 在这里恒为 `true`**：运维面与客户端一面同起同停（[S-34](#s-34-起来即整体停机时在途请求归谁)），运维面在应答，客户端一面就在应答 |
| `startedAt` | 这一次启动成功的时刻（中心的钟），形状是 OE `Instant`。**启动成功以钟可读为条件**（[S-34](#s-34-起来即整体停机时在途请求归谁)），所以中心在应答时它总有定义 |
| `deploymentKeyPresent`、`deploymentKeyComplete` | [部署密钥](../../../../product/PF-017-governance-center-as-deployable-application/design.md#部署密钥)**启动时载入的结果**，不是现在去看文件。缺了或不完整中心本来就起不来，所以中心在应答时两项都是 `true`；中心开着时机器上那份被删了，照旧是 `true`，下次启动才起不来（[§6.14](../../../../product/PF-017-governance-center-as-deployable-application/design.md#614-产品不把任何秘密的值交给运维者)） |
| `defectCount` | 自本次启动以来**入口层自己记过的**缺陷数：恰计 [S-14](#s-14-失败映射) 列出的各缺陷情形（含那张表里的矛盾清单），非负整数，启动时为 0，重启归零。它说「中心自身出过故障」，不说是哪个请求、哪个人——缺陷的细节只在[工程记录](#s-30-工程记录)里。**参与方自己记的缺陷**（各参与契约在它们内部判出的）只在工程记录里，**本版不汇入这个数**——它为 0 不等于参与方没出过错 |
| `deploymentParameters` | 五项[部署参数](../../../../product/PF-017-governance-center-as-deployable-application/design.md#部署参数)此刻生效的值（启动时读入）：`unactivatedRetention`、`invitationTtlDefault`、`affiliationRequestTtlDefault`、`copyNoticeTtlDefault`、`sharingInvitationTtlDefault`。**五项缺一不可，不出厂默认**（[§6.15](../../../../product/PF-017-governance-center-as-deployable-application/design.md#615-部署参数由运维者给值起动时读缺一不可)）；每项是一个时长，以正整数毫秒表示。后两项本版**没有消费它们的契约**（[G-4](#十三已知缺口)）：照样要值、照样校验、照样在这里可见 |

**不含**：部署密钥的值、任何凭据的值、任何治理事实（账号有几个、组织有哪些、谁登录着、谁邀请了谁）——[中心体检](../../../../product/PF-017-governance-center-as-deployable-application/design.md#中心体检)只说部署（[§6.17](../../../../product/PF-017-governance-center-as-deployable-application/design.md#617-体检只说部署不说里面有谁)）。
**也不含**与部署参数同类、但不属于部署参数的技术参数（例如创建键的保留期、凭据规则）——它们不是[部署参数](../../../../product/PF-017-governance-center-as-deployable-application/design.md#部署参数)。

## 六、治理中心标识

### S-27 GovernanceCenterId 的形状与相等

- **`GovernanceCenterId` 是[治理中心标识](../../../../ubiquitous_language/terms/grounding-and-isolation.md#ul-governance-center-identifier--治理中心标识--governance-center-identifier)的值类型**（产品定义见 [PF-017 §4 中心标识](../../../../product/PF-017-governance-center-as-deployable-application/design.md#中心标识)），随本契约 Schema 定义：一个 **128 位随机值**，
  规范形式**恰有一种**——32 个小写十六进制字符。**相等只在这个形式上定义**：逐字符相等；大写、带空白、带分隔符的都不是合法值。
  口径与 [`data.identity-values/v1#S-7`](../../../data/identity-values/v1/contract.md#s-7-tenantid-的规范序列化形式) 对 `TenantId` 的规定同形：一种形式、一个比较规则，不做任何规范化。
- **「是同一个中心」＝ 标识相等**；不同即另一个中心（[§6.12](../../../../product/PF-017-governance-center-as-deployable-application/design.md#612-同一个中心换了地址还是它另一个中心必须被认出来)）。
- 它**不是地址，不是秘密**，不由运维者起名，**不从部署密钥、地址或任何运行实例的身份派生**。
- 它**只管「是不是同一个」，不证明「真的是它」**——防冒充不在本契约（[S-3](#s-3-本契约明确不承诺什么)）。

### S-28 铸造、存放与不变

| 九件事 | 内容 |
|---|---|
| **1 输入与授权** | 无输入。不是一个线上操作：它是入口层**每次启动**时做的一件事，没有任何人能从任何一面触发它 |
| **2 前置** | 数据所在够得着，且**读得出**标识那一格的状态。**那一格与存储结构同时立起**：存储结构建立的那一次就带着它，状态是「未铸」（兑现方式归实现映射）。所以读或铸判「是不是第一次」时只看这一格本身，**不看别的 owner 的数据**——读或铸这一步不判「治理事实是否为空」；「那一格所在的表整个不在」由启动前的只读核对另行挡住（见下文前提） |
| **3 提交点与原子性** | **首次启动的提交点**：读到「未铸」⇒ 生成一个、写进那一格的那一次提交；那一格与治理事实在**同一个存储**。这次提交**不写任何治理事实**——中心生来是空的。之前任何一步失败，那一格仍是「未铸」，下一次启动仍然算第一次 |
| **4 返回与失败集合** | 启动成功 ⇒ 这次运行期间的 `centerId` 定下（公开体检与完整体检都读它）。**那一格只有三种读法**：读到「未铸」⇒ 铸造并写入（上一行）；读到已铸、且值合 [S-27](#s-27-governancecenterid-的形状与相等) ⇒ 用它；**那一格不存在，或值不合 S-27 ⇒ 启动失败**——这份数据不是一个中心从零立起来之后的样子（搬错了、截断了、恢复不全或被手改），铸一个新的只会给一份已有数据换一个身份，照用一个不合形状的值会在公开体检里交出不合 Schema 的 `centerId`。失败集合恰为四支，都让中心不起来、并告诉运维者是哪一支，不产生一个「没有标识的运行中的中心」：**读不到**；**写不进**；**那一格不存在**；**值不合 S-27** |
| **5 幂等边界** | **读到已铸的标识 ⇒ 用它，不再铸。**同一份数据上每次启动得到同一个值 |
| **6 事件** | 无 |
| **7 缺席时的默认答案** | **「读不到」绝不当作「未铸」**：存储此刻读不出那一格 ⇒ 启动失败，**绝不铸一个新的**——那会把一次抖动变成「另一个中心」，全组织的据点一夜之间认不出它。**「那一格不存在」也绝不当作「未铸」**：只有读到「未铸」这个状态才铸 |
| **8 在途归属** | 首次写入中途崩溃：那次提交要么成立（下次读到已铸），要么没有（下次仍读到「未铸」）；没有第三种 |
| **9 装配给／协议给** | 见 [S-36](#s-36-装配给的保证-vs-协议须给的保证) 的「中心标识与治理事实同一存储」「那一格立起过就不被重建」两行 |

**前提（装配给，本组合不兑现）：那一格立起过，就不会在启动时被当作新建重新立起。**
恢复不全把那一格所在的表丢了时，若启动把它当成一份全新的存储、重新建立那张表，读到的就是「未铸」，中心会带着已有的账号与组织铸出另一个标识。
这一支由启动前的只读核对挡住：**存储里已有别的治理事实、却没有那一格所在的表 ⇒ 启动失败，不重建、不铸造**。
核对的机制归存储提供者（[`realization/packages/infra/storage-sql` 的迁移前只读核对](../../../../realization/packages/infra/storage-sql/design.md#迁移前只读核对)），
判据由本组合的实现映射给出并由承载装配接进那道核对；「已有别的治理事实」怎样判归实现映射。
一份只剩迁移登记、别的结构都丢了的存储不在这一支里：那时那一格读不到，按上表「读不到 ⇒ 启动失败」收场，同样不铸。

**性质**：

1. **一生不变**：此后没有任何写路径改它——客户端一面没有、运维面没有、部署动作也不改它。
   停机、重启、升级、换密钥、改参数、搬家、从备份恢复，都是同一个标识；**只有从零重立才换**。前提：用的是同一份数据（[§4 中心标识](../../../../product/PF-017-governance-center-as-deployable-application/design.md#中心标识)：跟着数据走）。
2. **跟着数据走**：它与治理事实在同一个存储里，备份治理事实就备份了它，恢复治理事实就恢复了它。放在存储之外的任何地方，「只备份了库」就会把它丢掉。
3. **两次从零首启得到不同的标识**：这是承诺，由 128 位随机兑现，是一个概率界。
   **碰撞的收场**：碰撞的两个仍是两个中心（中心的身份是它的数据，标识只是用来比较的那个值），**本契约不检测碰撞**；
   客户端据相等会把其中一个误判为「搬家了」——与「同一份数据在两处同时起来」同属[产品分不出、不检测](../../../../product/PF-017-governance-center-as-deployable-application/design.md#612-同一个中心换了地址还是它另一个中心必须被认出来)的一类后果。
4. **启动时载入，此后读的是载入的值**：数据所在中途够不着，公开体检照样答得出标识。

## 七、输出与观测

### S-29 秘密不进任何输出

中心的**对人或客户端的答复与诊断**——客户端一面的每一种答复、公开体检、完整体检、维护结果及元信息、工程记录、启动失败的说明——**都不含**：

| 不含 | 例外 |
|---|---|
| [部署密钥](../../../../product/PF-017-governance-center-as-deployable-application/design.md#部署密钥)的值 | 无（生成它的办法在交出时给过一次，那不是中心运行时的输出） |
| 账号的凭据材料 | 无 |
| [模型凭据](../../../../ubiquitous_language/terms/capabilities-and-composition.md#ul-model-credential--模型凭据--model-credential)的值 | 无。**本契约对它只承诺「不进任何输出」**，不承诺「在数据里读不出来」（[§6.14](../../../../product/PF-017-governance-center-as-deployable-application/design.md#614-产品不把任何秘密的值交给运维者)） |
| 出示物 | **恰一处**：登录路由成功时交出新签发的那一个（[S-19](#s-19-免认人的两条路由注册登录)）。线上交出去的其余东西都不能当登录状态用（[§8 不交出能直接用的凭证](../../../../product/PF-017-governance-center-as-deployable-application/design.md#八边界与依赖)） |

列表句柄（即 `LoginStateId`）不是秘密，可以出现（[S-9](#s-9-列表句柄)）。

S-55/S-58 的受保护数据副本承载原始持久事实，可能含凭据材料；它不是以上答复与诊断，也不加密、不承诺宿主不可读。维护工具不得将其作为文本、日志、错误原因或元信息输出。存储中的登录出示物仍遵守 AI S-45/S-46 的不可逆要求。

### S-30 工程记录

入口层对每一个请求留一条可定位、可解释的工程记录（[SYS-OBSERVABILITY C1／C3](../../../../foundation/observability-and-logging/requirements.md#已确认要求与工程含义)），至少分得出：
走到了判定次序的哪一步、给出了四种入口答复里的哪一种或哪一个路由结果、`unavailable` 是缺陷还是判不了、判不了时是**哪一次现读**给出的**哪一个失败值**、缺陷是哪条路由的哪个领域答复。

**记录的是入口层自己观察到的失败值，不多于它**：参与契约把钟读不到折进了它们各自的不可用值（AI 的 `storage-unavailable`、OG 的 `unavailable`），入口层从这些值里**分不出**存储与钟，记录里也就不写成分得出。
**只有入口层自己做的读**——启动时读中心标识那一次（[S-28](#s-28-铸造存放与不变)）与为 `startedAt` 读钟那一次（[S-34](#s-34-起来即整体停机时在途请求归谁)）、运维面为[完整体检](#s-26-完整体检)现探数据所在与现读钟——才区分存储不可用与时钟不可用。

**边界**（[flows §1.3](../../../../product/PF-017-governance-center-as-deployable-application/flows.md#13-一个客户端带着登录状态来)、[C6](../../../../foundation/observability-and-logging/requirements.md#已确认要求与工程含义)）：

- **不记对端地址**；
- **账号与租户只以不可逆的关联号出现**，从记录里还原不出 `AccountId`、`TenantId`；
- 不含 [S-29](#s-29-秘密不进任何输出) 列出的任何一样；
- 对来者逐字相同的那六种不认情形，记录里**可以**区分「没带／多个／表示层不合格」与「查过了、不认」——后者内部三种（从没签发、已撤销、别的中心签的），[AI S-44 本身就不区分](../../../capabilities/account-identity/v3/contract.md#s-44-按出示物换取身份)，记录里也分不出。

运维者读这些记录，与「握着磁盘的人」是同一类事，**不是产品开给他的一扇门**（[§6.13](../../../../product/PF-017-governance-center-as-deployable-application/design.md#613-运维者没有任何一扇门通向账号能做的事)）。

## 八、性质与前提

### S-31 不变量与安全性质

本表是 [acceptance §二「绝不能发生的事」](../../../../product/PF-017-governance-center-as-deployable-application/acceptance.md#二绝不能发生的事)里归本契约的那几行的落点；各行的兑现条款在「谁在何处保护」一列。
那一节另有两行归本契约、不在本表：「中心半开」由 [S-34](#s-34-起来即整体停机时在途请求归谁) 兑现，「工程记录里出现对端地址或可还原的账号、租户标识」由 [S-30](#s-30-工程记录) 兑现。

| 性质 | 谁在何处保护 | 前提 | 来源 |
|---|---|---|---|
| **版本先于一切**：版本对不上时，除公开体检外只答 `version-mismatch`，出示物没被看过，那件事没发生 | [S-10](#s-10-判定次序) ① | — | [§6.4 ①](../../../../product/PF-017-governance-center-as-deployable-application/design.md#64-无效与答不出是两个不同的答复)、[§6.16](../../../../product/PF-017-governance-center-as-deployable-application/design.md#616-版本对不上就明说) |
| **只认自己签发的、此刻有效的** | [S-11](#s-11-认人)：每请求凭出示物现读 [AI S-44](../../../capabilities/account-identity/v3/contract.md#s-44-按出示物换取身份) | 出示物猜不中——本组合的前提，是 AI 的提供者义务（[S-36](#s-36-装配给的保证-vs-协议须给的保证) 的「认人、出示物安全、句柄来源」行） | [§6.3](../../../../product/PF-017-governance-center-as-deployable-application/design.md#63-只信自己签发的此刻仍有效的登录状态别人说验过了不算数) |
| **判不了不下结论**：任何一步判不了 ⇒ `unavailable`；永不说成 `login-state-rejected`，永不放行，永不拿旧答案或空清单顶 | [S-10](#s-10-判定次序)、[S-14](#s-14-失败映射)、[S-15](#s-15-δ--0每个请求现读入口不跨请求缓存) | 领域契约把判不了收成各自的不可用值。**例外是注册组合**：它把底层的判不了收进 `interrupted`，本组合原样呈现、不改成 `unavailable`（[S-19](#s-19-免认人的两条路由注册登录)）；那条路由上「判不了」对来者是 `interrupted`，仍不是放行，也不是 `login-state-rejected` | [§6.4 ②](../../../../product/PF-017-governance-center-as-deployable-application/design.md#64-无效与答不出是两个不同的答复) |
| **拒绝不泄漏**：六种不认情形同一个线上答复；认出人之后才读到的撤销也是这一个 | [S-11](#s-11-认人)、[S-14](#s-14-失败映射)、[S-33](#s-33-认出人之后登录状态被撤销)、[S-6](#s-6-四种入口答复) 的逐字相同 | 时序侧信道不在范围 | [§6.5](../../../../product/PF-017-governance-center-as-deployable-application/design.md#65-拒绝的时候什么都不多说) |
| **此刻有效才认**（中心一侧 δ = 0） | [S-15](#s-15-δ--0每个请求现读入口不跨请求缓存) | — | [§6.3](../../../../product/PF-017-governance-center-as-deployable-application/design.md#63-只信自己签发的此刻仍有效的登录状态别人说验过了不算数)、[PF-001 §6.6](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#66-撤销不等于强制停止) |
| **没有替身担保，不区别对待来者** | [S-11](#s-11-认人)、[S-16](#s-16-不记住来访不区别对待来者) | — | [§6.2](../../../../product/PF-017-governance-center-as-deployable-application/design.md#62-中心只认登录状态不认客户端) |
| **认出来者不削弱隔离**：交给领域的身份只从认人推出；隔离判定仍在各 owner 的数据访问层 | [S-12](#s-12-身份推导)、[S-13](#s-13-补授权) | 各 owner 兑现 `data.identity-values` v1 的隔离义务 | [SYS-TENANT](../../../../foundation/cross-system-constraints/requirements.md#sys-tenant)、[PF-001 §6.4](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离) |
| **两张面，没有第三张**：客户端一面只有路由表里的路由；运行中运维面恰有 `full-health`、`backup`、`backup-status`，没有治理路由；`verify`/`restore-isolated` 只是本机文件工具，不是第三张面；没有额外「内部」「管理」「脚本专用」治理入口 | [S-17](#s-17-路由表封闭每条路由的九件事从哪读)、[S-24](#s-24-有意不投影)、[S-25](#s-25-运维面只在中心所在的机器上且没有治理路由)、S-55～S-59 | 本版 [v3 静态检查义务](../verification.md#v3-静态检查义务) SC-1～SC-3 落地；旧 v1 SC 结果不替代本版 | [§5.1](../../../../product/PF-017-governance-center-as-deployable-application/design.md#51-中心有两张面没有第三张) |
| **运维者没有门，超管没有部署的门** | [S-24](#s-24-有意不投影)、[S-25](#s-25-运维面只在中心所在的机器上且没有治理路由) | 同上；直接翻数据的人挡不住 | [§6.13](../../../../product/PF-017-governance-center-as-deployable-application/design.md#613-运维者没有任何一扇门通向账号能做的事)、[flows §4](../../../../product/PF-017-governance-center-as-deployable-application/flows.md#四角色与操作) |
| **秘密不进任何输出；体检不越界** | [S-18](#s-18-公开体检)、[S-26](#s-26-完整体检)、[S-29](#s-29-秘密不进任何输出) | 模型凭据只到「不进输出」 | [§6.14](../../../../product/PF-017-governance-center-as-deployable-application/design.md#614-产品不把任何秘密的值交给运维者)、[§6.17](../../../../product/PF-017-governance-center-as-deployable-application/design.md#617-体检只说部署不说里面有谁) |
| **中心标识一生不变；两次从零首启不同** | [S-28](#s-28-铸造存放与不变) | 同一份数据；碰撞按概率界；那一格立起过就不被重建（装配给，[S-36](#s-36-装配给的保证-vs-协议须给的保证)）；首启那次提交跨 OS 崩溃的耐久按 [S-36](#s-36-装配给的保证-vs-协议须给的保证)「持久性、迁移与恢复」行 | [§4 中心标识](../../../../product/PF-017-governance-center-as-deployable-application/design.md#中心标识)、[§6.12](../../../../product/PF-017-governance-center-as-deployable-application/design.md#612-同一个中心换了地址还是它另一个中心必须被认出来) |
| **过期只量中心的钟** | [S-4](#s-4-请求信封)：信封不含时间 | — | [§5.4](../../../../product/PF-017-governance-center-as-deployable-application/design.md#54-中心自己的时间) |
| **来往里没有会话；中心从不主动发** | [S-3](#s-3-本契约明确不承诺什么)、[S-24](#s-24-有意不投影) | — | [PF-016 §4 治理中心](../../../../product/PF-016-cli-tui-delivery-surface/design.md#治理中心)、[§5.6](../../../../product/PF-016-cli-tui-delivery-surface/design.md#56-哪些东西在中心一侧哪些在据点一侧) |
| **登录效力依AI3 S48由撤销、凭据代次与时间共同判定；正常重启不重置时刻/代次** | 登录状态记录在存储里（[`capability.account-identity/v3#S-10`](../../../capabilities/account-identity/v3/contract.md#s-10-撤销是持久记录不是内存生命周期) 的既有性质）＋ 本组合不缓存、不另存 | **不经备份恢复**（[S-36](#s-36-装配给的保证-vs-协议须给的保证) 的「持久性、迁移与恢复」行；[G-7](#十三已知缺口)） | [§6.7](../../../../product/PF-017-governance-center-as-deployable-application/design.md#67-重启不让任何人退出登录) |

### S-32 进展性质与前提

前提编号只在本表内作行标：**P1** 中心在运行且够得到；**P2** 数据所在够得着；**P3** 时钟读得到且未倒退；**P4** 版本对得上；
**P6** 其间没有从备份恢复；**P8** 未激活记录在留存期限内；**P9** 账号已激活、来者持有凭据。

已确认的治理事实需承受本期普通进程/OS/断电故障的持久性目标；具体同步与介质前提由采用的提供者兑现，不沿用旧版丢末段提交的豁免。整机/磁盘损毁灾备验收按INT-009延期；不能因此从旧备份直接开放并恢复旧凭据/权限。恢复开闸由单独协议负责，当前未闭合。

| 进展 | 前提 | 前提不成立时来者看到什么 | 前提由谁负责 |
|---|---|---|---|
| 带着有效登录状态来的请求，**这一次**就得到领域的答复（做成了，或按 PF-001 的理由没做成） | P1、P2、P3、P4 | P1 不成立：什么都得不到（问不到）；P2／P3：`unavailable`；P4：`version-mismatch`——**三者都不是 `login-state-rejected`** | P1～P3 归运维者（钟的运行中回拨检出归时钟的提供者，见 [S-36](#s-36-装配给的保证-vs-协议须给的保证)）；P4 归运维者与客户端一起升级 |
| 答过 `unavailable` 之后，P2、P3 一恢复，**同一个登录状态若仍满足AI3 S48**，下一个请求可继续；已到期须重新登录 | P1 | 同上 | 同上 |
| 正常重启/后续升级保留登录的I/L/g/G/撤销 | 启动成功且登录此刻仍满足AI3 S48；首次有界迁移除外 | 到期/撤销/代次不符按login-state-rejected；备份恢复必须先通过安全核实，不能允许旧登录/凭据/权限复活 | 账号持久状态、升级与恢复装配 |
| 登录状态失效的人重新登录，得到一个新的登录状态，当前租户身份从个人组织起算 | P1～P4、P9 | P9 不成立：`identifier-or-credential-rejected` | 账号能力 |
| 停机时注册走到一半的人，起来之后用同一标识同一凭据接着走完 | P1、P8 | P8 不成立：那条记录已清，名字按新注册走 | 注册组合 |
| 空中心上，任何够得到它的人都能注册、登录、建组织并成为那个组织的超管（无害靠[部署前提](../../../../product/PF-017-governance-center-as-deployable-application/design.md#部署前提)） | P1～P4 | 同第一行 | 同第一行 |

**上界**：每一行都是「这一次」「下一个请求」这种有界形式——入口层不排队、不重试、不等待前提恢复；前提成立时，一个请求在它自己的处理里得到答复
（旧EntryDecision只覆盖抽象决策流水线；新版共同提交、准备阶段和依赖静止不由旧EventuallyAnswered证明，见[形式范围](formal/README.md)）。
中心起不来之后运维者补上被点名的那一样就能起、丢了密钥换一套就能起、改了参数下次启动生效——这几条归承载装配，不在本契约。

## 九、并发、撤除与替换

### S-33 认出人之后登录状态被撤销

普通受认证业务从认人到共同提交沿同一序列保护；外部撤销/改密先成立则本请求准入拒绝，本请求先准入并持有保护则它先收场，随后撤销成立。时间仍会推进，必要身份核验发现已失效时统一 login-state-rejected；已确定业务成功后的最终计时按 AI3 S49，可以提交已准入业务但不能复活登录。

改密准备不持有共同写锁；准备结束后的提交阶段按AI3 S50先核快照G、再核发起登录，不提前exchange改变失败优先级，不沿用准备时准入。外部变更不靠旧校验结果穿透。

### S-34 起来即整体；停机时在途请求归谁

- **起来即整体。**客户端一面要么以**整张路由表**开始应答，要么根本不应答；不存在「一部分路由在服务、另一部分不在」的中心（[§6.6](../../../../product/PF-017-governance-center-as-deployable-application/design.md#66-要么整个起来要么不起来)）。
  入口层所依赖的任一参与方的面缺席，客户端一面就不应答——来者看到的是「问不到」，不是某些路由答 `unavailable`、某些照常。
- **起来即整体覆盖两张面：运维面与客户端一面同起同停。**两张面一起开始应答、一起停止应答新请求；不存在「运维面已可用、客户端一面还没起来」或反过来的中间态。
  所以运维面在应答时，客户端一面也在应答——[完整体检](#s-26-完整体检)的 `reachable` 恒为 `true` 由此成立。
- **「面缺席」只有三种时候**：启动（还没起来）、停机、某个参与方的提供者**换代**。
  **存储或时钟不可用只能表现为返回值上的不可用**（[IV S-19](../../../data/identity-values/v1/contract.md#s-19-不可用即明确失败)），**不得表现为面缺席**——由存储与时钟的提供者兑现（实现映射）；否则一次读不到就会让整个中心问不到，而「答不出」本该是一个答复（[S-6](#s-6-四种入口答复)）。
- **换代期间**：在途请求跑完，各由其真实提交拥有者结束共同或独立事务；换代中到达的新请求**两张面都不应答**（来者看到的是「问不到」）；**换代不计缺陷**，不进 `defectCount`。
  **前提（装配给）：本版运行中不换代存储与时钟的提供者。**两张面都依赖它们；它们一换代，两张面各自重来、谁先谁后不由装配定，「同起同停」与「换代之后两张面都恢复应答」在那一刻都没有保证。
  所以本条的「换代」在本版只指参与方能力（账号、组织治理、注册）的提供者；存储与时钟要在运行中换代，须先给出两张面恢复的保证，并作为本契约的新版本发布。
- **启动成功以钟可读为条件**：启动时读不到中心的钟，就还没有启动成功——等到读到为止；超过承载装配定的界仍读不到 ⇒ **启动失败，并告诉运维者原因是钟**。
  完整体检的 `startedAt` 就是启动成功那一刻读到的时刻（[S-26](#s-26-完整体检)），所以它总有定义。
- **中心开始应答的那一刻就是它「起来了」的那一刻**；在那之前的任何失败，外面看到的只是「问不到」。
- **升级整体性与 §6.10 第 1 行的启动前核对不归本契约**（S-28 前提依赖的那道启动前核对是另一回事，归 S-36）：[§6.9 升级要么整体成、要么整体不成](../../../../product/PF-017-governance-center-as-deployable-application/design.md#69-升级同一个中心要么整体成要么整体不成)，与 [§6.10](../../../../product/PF-017-governance-center-as-deployable-application/design.md#610-时间不能倒着走) 第 1 行的启动前只读核对，本契约不兑现。
  它们没有契约家，本版由承载装配直接承接，登记为 [G-12](#十三已知缺口)；本契约对它们只有上一条：升级不成或核对不过发生在「起来」之前，外面看到的只是「问不到」。
- **停机**：先停止两张面的新请求准入；业务答复等待可有界，但有界等待不等于完整工作已结束。已接纳的完整业务工作（含事务外凭据准备）必须真实结束后才释放必要依赖；共同事务必须完成或回滚，网络等待超时不等于事务已取消；
  来者可能收不到答复——那件事要么已提交、要么没发生，**没有半个**（[§6.8](../../../../product/PF-017-governance-center-as-deployable-application/design.md#68-停机已确认的都在没确认的等于没发生)）。业务网络等待的上界归承载装配；维护工作按 S-59 真实结束后才释放源属主，正常关闭在执行无进展时无有限完成保证。
- **维护准入也属于整体开闸**：所需维护能力缺席、升级尚未确认、不能维持唯一源属主时不开始服务；运行中的介质或时间故障按 S-55～S-59 明确失败，不伪造成功。断连接、停止通知、超时或取消请求不结束维护工作。
- **撤除之后仍然为真的**：全部治理事实与中心标识都在存储里；未提交临时结果和待发通知丢弃，不跨重启复用；已确认提交事实不因未发送答复被撤销，提交未确认按S49如实处理。

## 十、内核不提供的部分

### S-35 内核不提供、由本契约兑现的表

| 内核不提供 | 需要吗 | 怎么兑现 |
|---|---|---|
| **跨进程的身份与可见性** | **需要，这是本契约的核心** | 出示物、每请求重验（[S-11](#s-11-认人)）、身份推导（[S-12](#s-12-身份推导)）、补授权（[S-13](#s-13-补授权)） |
| 权限边界 | 需要：运维者对治理事实没有门 | 通道分离 ＋ 路由表封闭 ＋ 运维面不引用治理能力（[S-25](#s-25-运维面只在中心所在的机器上且没有治理路由)），由静态检查守 |
| 有序的异步清理 | 需要：停止接收 → 等在途 → 关闭 | [S-34](#s-34-起来即整体停机时在途请求归谁)：三步是一个有序过程，不是三件各自并发的收尾 |
| 持久化与崩溃恢复 | 需要：中心标识跨重启、跟着数据走 | [S-28](#s-28-铸造存放与不变)：存在治理事实同一个存储里 |
| 时序保证 | 需要：入口在所依赖的面都可用之后才应答 | [S-34](#s-34-起来即整体停机时在途请求归谁) |
| 可靠投递 | 不需要 | 不承诺送达（[S-3](#s-3-本契约明确不承诺什么)） |
| 背压与流控 | 不需要 | 非目标（[S-3](#s-3-本契约明确不承诺什么)） |
| 跨 owner 共同提交 | 本组合及领域参与面 | S49同一一致性域；内核不提供数据库原子性，网络/通知不属于可回滚效果 |

## 十一、装配给 vs 协议给

### S-36 装配给的保证 vs 协议须给的保证

**这条边把「调用方」搬到了进程外，领域没有被拆开**：各领域能力仍在同一个进程、同一个存储、同一口钟里。
所以左列靠「同一存储、同一提交、同一时钟」的保证**在这条边上不失效**，仍由装配给；要由**本契约的协议条款**重新兑现的，
是**和调用方身份有关、和流向调用方的值有关**的那几行。右列写：这条边上它由谁兑现；中心自身将来也被拆开时还要补什么。
每一行都写做不到会怎样。

| 保证 | 单机提供者/装配前提 | 入口承担 | 跨进程后 |
|---|---|---|---|
| 认人、出示物安全、句柄来源 | AI3 S17/30/44/45/46/51；随机安全与只存不可逆形式由AI提供者兑现 | 仅S44认网络出示物，不暴露内部句柄认人，不日志秘密；拒绝反馈闭合 | 每个接收边界重新验证，不信上游裸身份 |
| 每道准入现读、当前选择与成员资格可见性 | OG2 S26/36/42/63、IV S27/28 | S12/13/49/51同边界现推身份、比较预期、授权和执行，不缓存 | 实际协议须兑现相同一致性；未兑现不开放 |
| 有界登录与成功活动 | AI3 S48/49/51 | S49真实提交后输出、失败整体回滚、不通过纯认人续期 | 观察者与提交共同保护，不依赖无界传播 |
| 主动改密、代际与签发竞争 | AI3 S15/50/51 | S52在准备后重核，先G后登录；全旧登录失效，不发新登录 | 凭据证明与写入必须拥有同样的快照重核 |
| 注册入口与清除限制 | AR2 S2/6/8/22/23/25/36、AI3 S13/14/28/38及OG2 S53：同一受限注册调用面和原凭证信任关系 | 不暴露单独产生/激活/清除；只呈现组合结果 | 调用方授权与依据不可伪造须由协议兑现 |
| 持有AccountId的内部读面不上线 | AI3 S18/S54；不透明AccountId由AI提供者兑现 | 不投影S18；S50查名先做超管补授权；OG23已知AccountId的邀请残余存在性反馈沿既定产品边界 | 不能把内部ID当对外认证凭据 |
| 邀约时间、状态与不可用 | OE2 S4/7～9/12～17/20/22，OG2 S10/11/63 | 不收客户端时间；派生declined等五值；非法默认启动失败归装配；计算溢出unavailable | 同源不可倒退时钟、终结/效果共同边界须重新兑现 |
| 身份形状与隔离 | IV本版S2消费清单 | 保留规范TenantId与ScopeLayerIdentity，expectedTenant只比较，不替代资格 | 同一交换表示并在数据边界重验 |
| 可用性和整体装载 | AI3/OG2失败边界、S34及承载装配 | 缺依赖不半开；判不了明确unavailable；版本/信封的确定拒绝无需数据库 | 各参与方协议须有明确不可用和整体开闸 |
| 持久性、迁移与恢复 | AI3 S10/52及PF017 rev5；介质兑现同步、host保存升级前缀 | 不把未确认说成没发生，不在入口补偿或重试业务 | 整机灾备验收延期；旧备份安全核实后方可开闸 |
| 在途与撤除 | S34/49；入口跟踪完整业务工作、装配等待业务收场再释放依赖 | 运输连接关闭不等于事务/凭据准备结束，通知仅确认提交后尽力发 | 取消/排空/持久结果仍须显式协议，不能靠断连接 |
| 中心标识与治理事实同一存储 | S28中心身份与治理事实的共同持久边界 | 读或首次铸造按S28；不另在文件保存第二份身份 | 拆分存储后仍须共同恢复/确认协议，不得让身份与事实指向不同中心 |
| 那一格立起过就不被重建 | S28既有存储标记及承载启动前只读核对 | 旧数据缺占位/中心标识等异常按S28失败，不悄悄当全新中心重新铸造 | 已建立历史的保留与恢复由协议重新兑现 |

| 维护一致观察与真实结束 | S-59 存储维护拥有固定观察、所有资源与实际工作；缺失不准入 | S-55～S-58 不能以通知或取消代替结束；做不到不释放属主 | 须有明确工作归属、排空与唯一属主协议；未兑现不开放维护 |
| 持久发布与不确定结果 | 介质兑现持久确认，发布位置独占；确认失败不能算成功 | S-55/S-56/S-58 分清有效输出与 outcome-unknown，不自动重试 | 发布与确认必须保持同一输出身份，做不到保留 unknown |
| 明文残余隔离 | S-59 在明文之前建立持久隔离，清理不得撤掉崩溃残余的拒绝依据 | 所有支持的生产打开路径都拒绝；不可核实则拒绝打开 | 每个打开者须消费同一拒绝约定；做不到不纳入支持集合、不开放 |
| 每日有效副本 | 有限目录、可用源/介质/时间/吞吐、每小时调度及剩余 4 小时预算 | S-56 按真实校验和持久确认判 current/overdue/missing；前提失效不宣称每天达成 | 调度与时间/存储保证须重建；本版不承诺跨机灾备 |

表内每条对相应路由适用；旧版本的表行号不是本版依赖。物理位置不作治理资格、无账号管理后门、运维面隔离和中心标识保持归本版S16/24～28，不因共同事务改变。

---

## 十二、规范表达与证据义务

### S-37 本版选用的形式工件

本契约**触发了行为模型的义务**：它新增的是一条**跨 owner 的整体性质**——判定次序 × 四种入口答复 × 「判不了优先于无效」，
横跨三份契约的操作与它们各自的失败集合。局部契约各自正确，不蕴含这张映射在每一种交错下都对。

形式表达：[EntryDecision.tla](formal/EntryDecision.tla)检查暂定分类顺序及失败分流，[EntryCommit.tla](formal/EntryCommit.tla)检查抽象提交/最终计时/通知，[ExpectedTenant.tla](formal/ExpectedTenant.tla)检查S51比较与保护。各自配置与前提见[formal映射](formal/README.md)；三者没有组成端到端精化证明，真实存储/多组织补授权/完整业务排空由提供者场景验证。AI3模型仅复用各自有限范围。

**不选 Alloy**：本契约要检查的是次序与映射，是行为；「路由表封闭」「运维面不引用治理能力」是代码结构的事实，由静态检查守，不需要结构模型。

**建 Schema**：[`governance-center-entry.schema.json`](governance-center-entry.schema.json)——信封（按 `operation` 判别到 31 条路由各自的载荷）、四种入口答复、路由结果（31 条路由各自的成功返回；按路由核对用 `Exchange`）、公开与完整体检、`GovernanceCenterId`、出示物的交换表示（列表句柄直接引用 `data.identity-values` v1 的 `LoginStateId`），以及本契约自定的三个不透明标识、凭据材料与这一份的时长；
正反实例在 [examples.md](examples.md)。

### 规范场景

场景约束来者可观察的结果，检查真实组合；执行状态在[验证入口](../verification.md)，不写进本版本目录。

### S-38 规范场景：答复的先后

版本对不上的客户端带着有效、已撤销、别的中心签的、什么都没带四种来：**四次都只得 `version-mismatch`**，同一客户端读公开体检照常读得到三样。
版本对得上时让数据所在够不着：带已撤销的得 `unavailable`；什么都不带的得 `login-state-rejected`。
数据所在够得着时：有效登录状态配格式不对的载荷得 `invalid-input`；已撤销的配同一份载荷得 `login-state-rejected`。
依据：[acceptance §三「答复的先后」](../../../../product/PF-017-governance-center-as-deployable-application/acceptance.md#三判据)。

### S-39 规范场景：拒绝逐字相同

版本对得上、判得了时，分别以没带、多个、表示层不合格、从没签发过、已撤销、别的中心签的六种来者做同一件事：
**六次线上答复逐字节相同**（状态、头、体一并比较）。普通共同事务中外部撤销与请求按S33先后收场，不要求制造保护区间内的外部提交。另在认人后、必要身份重核前跨过登录时效：重核拒绝与前六次逐字节相同；改密准备间隙的外部撤销/代际变化分别按S52检查，不把G变化误写成普通登录拒绝。
依据：[acceptance §三「拒绝逐字相同」「只认自己签发且此刻有效的」](../../../../product/PF-017-governance-center-as-deployable-application/acceptance.md#三判据)。

### S-40 规范场景：三个出口不合并

让数据所在够不着，用一个**有效**登录状态来问事：得 `unavailable`；修好之后同一个登录状态照常能用，**不需要重新登录**。
让领域操作给出一个失败集合之外的值：得 `unavailable`，完整体检的 `defectCount` 随之加一。
在两个组织之一读不到成员资格、另一个读出「无效」时读它们的上级链：得 `unavailable`，不是 `notAuthorized`；换一个读的先后，答复不变。
依据：[acceptance §三「三个出口不合并」](../../../../product/PF-017-governance-center-as-deployable-application/acceptance.md#三判据)。

### S-41 规范场景：列表不给能直接用的东西

在一台机器上列出本账号的登录状态，把列表里的每一项拿到另一台机器上当出示物用：**每一次都得 `login-state-rejected`**。
用列表里另一项的句柄撤销它：成功；再撤一次：仍是成功（[AI S-16](../../../capabilities/account-identity/v3/contract.md#s-16-撤销登录状态) 的幂等）；用一个从没签发过的句柄撤销：`login-state-not-found`；用自己的句柄撤销（退出）之后，带着它再来：`login-state-rejected`。
先登录三次、撤销其中一次，再停机做一份数据备份：把备份里的**每一个字符串值**都放进信封当出示物来问事：**每一次都得 `login-state-rejected`**，与没带时的答复逐字相同；**同一次里两个仍有效的出示物照常能用**（正对照，缺了它一个恒拒的入口也会让前一半看起来成立）。
依据：[acceptance §三「不交出能直接用的凭证」](../../../../product/PF-017-governance-center-as-deployable-application/acceptance.md#三判据)的两半；备份那一半在账号能力一侧的形式是 [AI S-46](../../../capabilities/account-identity/v3/contract.md#s-46-存储里翻不出能用的出示物)，这里从线上再验一次。
**分工**：本场景只核「拿来用，用不了」这一半；「三个出示物以原样、base64url、十六进制三种形式都不出现在持久内容里」那一搜归 AI S-46 第 1 支，本场景不重复，也不以本场景的通过代替它。

### S-42 规范场景：只认登录状态，不认客户端

同一个有效登录状态，先后从两台机器、用人用的客户端与一段脚本做同一件事：**答复逐字相同**。
撤销一个登录状态后**立刻**用它问事：`login-state-rejected`。
依据：[acceptance §三「只认登录状态，不认客户端」「只认自己签发且此刻有效的」](../../../../product/PF-017-governance-center-as-deployable-application/acceptance.md#三判据)。

### S-43 规范场景：身份推导与补授权

切换当前租户身份到组织 A 后发出邀请：邀请由 A 发出；载荷里夹带一个「以组织 B 的租户身份」的成员：`invalid-input`，没有邀请被发出。
读一个自己不在的组织：`notAuthorized`；读一个不存在的组织：同样 `notAuthorized`；让成员资格读面读不到时再读：`unavailable`。

### S-44 规范场景：中心标识

从零立两个中心：标识不同。同一份数据先后在两个地址上启动：标识相同。停机、重启、升级、换密钥之后：标识不变。
**让标识那一格在启动时读不出来**：中心起不来，**没有铸出新的标识**；修好后再启动，是原来那个标识。
**拿一份那一格所在的表还在、那一格却不在的数据启动**：中心起不来、说明原因，**没有铸出新的标识**。
**把那一格的值改成不合 [S-27](#s-27-governancecenterid-的形状与相等) 的形状再启动**：中心起不来、说明原因，**没有铸出新的标识**，公开体检里从没出现过那个值。
**恢复一份已有账号与组织、却丢了那一格所在的表的数据再启动**：中心起不来（启动前的只读核对以「已有治理事实却没有那一格所在的表」拒绝），**没有重建那张表、没有铸出新的标识**——这一支检查的是 S-28 的前提，由承载装配、存储提供者与本组合的实现映射一起演练。
数据所在中途够不着时读公开体检：三样照样都在。
依据：[acceptance §三「同一个中心换地址还是它」「体检只说部署」](../../../../product/PF-017-governance-center-as-deployable-application/acceptance.md#三判据)。

### S-45 规范场景：两张面没有第三张

在中心所在的机器上，找不到任何一条不带登录状态就能注册、建组织、邀请、移除、改角色、撤销他人登录状态、看谁在里面的操作——**不是有但被拒，是没有**。
从客户端一面，找不到读完整体检或改任何部署事实的操作。
依据：[acceptance §三「运维者没有门」](../../../../product/PF-017-governance-center-as-deployable-application/acceptance.md#三判据)。

### S-46 规范场景：输出里搜不到秘密

生成密钥、启动、跑完上面各场景之后，在全部答复、两种体检、工程记录与启动失败说明里搜部署密钥的值、凭据材料、模型凭据的值、出示物；
出示物按 [AI S-46](../../../capabilities/account-identity/v3/contract.md#s-46-存储里翻不出能用的出示物) 的同一套搜法，以原样、UTF-8 字节的 base64url（带填充与不带填充）、UTF-8 字节的十六进制（大小写）三种形式逐一搜：
**除登录成功答复里那一处出示物之外，一处都搜不到**；工程记录里搜不到对端地址、搜不到任何 `AccountId` 与 `TenantId`。
依据：[acceptance §三「秘密不经产品的任何呈现与输出交出去」](../../../../product/PF-017-governance-center-as-deployable-application/acceptance.md#三判据)。

## 十三、已知缺口

**缺口不填默认值。**下列各项等待具名 owner 裁决，实现不得据一个看起来合理的猜测推进。
**已闭合的号保留在表里、标「已闭合」、不复用**，并留一句是怎样闭合的。

| # | 缺口 | owner | 闭合条件 |
|---|---|---|---|
| G-1 | v3 candidate 尚未接受，维护提供者与正式支持制品集合尚未采用；既有 AI3/OE2/OG2/AR2/EC2/HT2 接受不覆盖本增量 | 架构主线 | 独立评审、精确采用与消费者迁移，记录支持制品 |
| G-2 | 本版S51已定义expectedTenant与共同提交内比较；旧版按新身份照办的后果不再适用 | 本版owner | 规格采用及真实入口并发实证 |
| G-3 | 本版由S50限定组合补齐按登录标识邀请；没有搜索/前缀匹配/裸查询面 | 本版owner | 规格采用及真实授权与查名同提交验证 |
| G-4 | **部署参数里 PF-003 的两项（`copyNoticeTtlDefault`、`sharingInvitationTtlDefault`）没有消费它们的契约。**本版照样要值、校验、在完整体检里可见，但没有任何判定用到它们 | 复制通知与分享邀请的契约（尚未立） | 那两份契约立起来并消费它们 |
| G-5 | **已闭合（2026-09-23）**：线上的表示名与交换表示。闭合方式：主线裁定信封成员名、路由标识、登录成功答复与列表项的成员、各交换表示并认进命名账本，[S-4](#s-4-请求信封)、[S-9](#s-9-列表句柄)、[S-17](#s-17-路由表封闭每条路由的九件事从哪读)、[S-27](#s-27-governancecenterid-的形状与相等) 据此定稿 | — | 已闭合 |
| G-6 | **已闭合（2026-09-23）**：完整体检里「记过缺陷」那一项的字段名。闭合方式：主线裁定为 `defectCount`，[S-26](#s-26-完整体检) 据此定稿 | — | 已闭合 |
| G-7 | 恢复安全开放未闭合；普通持久性与备份工具属于本期，整机灾备验收延期，不许可旧权限复活 | 生产恢复方案 owner | 新鲜安全依据与恢复核实、开闸路径真实验证 |
| G-8 | **中心自身被拆成多个进程之后**，[S-36](#s-36-装配给的保证-vs-协议须给的保证) 各行右列里的新鲜度界、δ 与「够不着某个领域时的收场」未定义 | 架构设计（本版单机，不阻断） | 分布式演化启动时给出，并作为本契约的新版本发布 |
| G-9 | **已闭合（2026-09-23）**：[S-17 命名表](#路由的线上成员命名表)是本契约首次命名，待主线认可。闭合方式：主线通读并认可进命名账本 | — | 已闭合 |
| G-10 | **新增维护传输绑定尚无已接受版本；既有业务绑定 HT2 已接受。**本契约只约束落地必须保持的性质（[S-4](#s-4-请求信封) 的承载位置与重复成员、[S-6](#s-6-四种入口答复) 的整个线上答复逐字相同、[S-8](#s-8-协议版本与跨版本不变的两样) 跨版本不变的两样）；具体绑定没有可冻结、可按版本引用的工件，客户端代理与规范场景 [S-39](#s-39-规范场景拒绝逐字相同) 的逐字节比较都没有可对照的那一版 | 入口层的实现映射节点（[`realization/packages/tenancy/governance-center-entry`](../../../../realization/packages/tenancy/governance-center-entry/README.md)，`candidate`） | 该节点发布传输绑定，并作为冻结资源登记 |
| G-11 | **已闭合于既有客户端传输绑定 HT2**；客户端确认真实中心的保证沿原采用，本版不改。新增维护传输的版本缺口单列 G-10 | 入口层的实现映射节点 | 原保证保持，本版不重开防冒充方案 |
| G-12 | **升级整体成或整体不成（[PF-017 §6.9](../../../../product/PF-017-governance-center-as-deployable-application/design.md#69-升级同一个中心要么整体成要么整体不成)）与启动前只读核对（[§6.10](../../../../product/PF-017-governance-center-as-deployable-application/design.md#610-时间不能倒着走) 第 1 行）没有契约家。**本版由承载装配直接承接（[`realization/apps/tenancy-host`「升级的整体性」](../../../../realization/apps/tenancy-host/design.md#升级的整体性迁移前只读核对快照与确认)）；它的残余（例如某一种存储方言上不满足整体性）只登记在那个节点里，在契约层与 registry 上看不见（[S-34](#s-34-起来即整体停机时在途请求归谁)） | 架构主线 | 立一份部署级契约，或并入本契约的新版本 |

## 十四、版本差异与规范工件

### S-47 版本差异

相对 v2，新增 S-55～S-59 本机维护，S-25 不再只读；S-29 区分受保护副本与答复诊断；S-34/S-36 补齐维护工作、持久发布与隔离责任。31 条业务路由及公开/完整体检形状保持 v2。维护绑定另行演进，不自动要求员工客户端升级。

继承 v2 相对 v1 的变化：采用有界登录/凭据代次、拒绝终结及显式共同参与；协议路由坐标变化，新增四条业务路由与expectedTenant载荷，旧版客户端须通过稳定体检识别不兼容版本。旧版本资源不改、消费者不自动升级。

### S-48 本版规范工件

本契约、Schema、examples与formal映射。形式模型接续v1判定次序，并单独验证S49/51新增共同提交边界；不得用旧撤销交错模型声称新版存储验证完毕。维护新增有限行为模型及四种故障配置；真实介质和进程验证未开始。

### S-49 受认证业务共同提交

输入为通过版本/信封/出示物表示检查的请求。普通受认证路由由本组合开启共同边界（改密的准备/重核例外完整沿S52）：AI3 S44参与面认人→载荷校验→必要身份推导及S51比较→补授权→领域参与操作→规范返回集合与出站Schema核验→成功时AI3 S49最终活动→真实提交→释放通知并发答复。步骤任一异常、不可编码成功体或必要最终时钟不可用，使整个共同事务回滚，结束后才映射unavailable；不能内部catch后提交半份业务。预生成成功字节不等于发送成功。

参与契约原本归类为不可用的共同边界失败（AI3 S51/OG2 S63，例如存储不可用）属于受约定的不可用传播，不是S11/S12/S14所称集合外异常；结束共同边界后按原不可用类别映射，只有这一类不增加缺陷计数。已关闭、不同域、未许可重入或游离并发使用等被参与契约明确归为缺陷的失败仍须记缺陷；未声明的异常、矛盾返回或编码错误也记为缺陷。已被声明失败污染的边界不得为完成补授权列表而继续调用参与方。

只以路由成功返回为业务成功（包括成功读与幂等ok），具名失败不touch。允许失败落盘的唯一例外是AI3明确的首次未激活到期事实；不能因此保留部分业务。纯认人、体检不touch。撤销自身/改密成功仍取最终时间，但失效登录不touch。AI3 S51和OG2 S63决定参与集合及作用域约束，禁止普通调用隐式嵌套。

不新增幂等机制。unavailable可能表示提交未确认，不保证无效果；调用方不得自动重试非幂等动作，先用已有读面核实。注册interrupted亦不证明未提交。网络发出失败不倒退已提交业务/活动。通知沿领域契约提交后尽力派发，不跨崩溃可靠送达。

### S-50 按登录标识发出邀请

路由 `composition.governance-center-entry/v2#S-50`。载荷恰为loginIdentifier、expectedTenant及可选role/offerTtl，身份值均沿既有Schema。经认人/载荷/S51比较后，先OG S26核当前租户：有效且superAdministrator才继续；有效普通成员或ineffective为notAuthorized；failure unavailable为unavailable；内部invalidInput、缺值或集合外形状为缺陷并回滚、外层unavailable。所有非成功分支均不得查目标账号。获授权后在同边界调用AI3 S54解析已激活账号；account-not-found统一为accountDoesNotExist，不泄露未激活状态；不可用为unavailable。随后用解析的AccountId调用OG2 S23。成功返回InvitationId；OG23此时给accountNotActivated与已解析激活事实矛盾，按缺陷回滚；其余失败集合与OG23映射一致，不加入搜索/列表/前缀匹配。

前置、业务写与最后活动同S49提交；不幂等、无自动重试；发出的通知归OG23，不新发事件。表示错误invalid-input；未授权无查名副作用。旧按AccountId路由OG23保留，新路由只是限定组合，不能将AI54暴露为任意查名。

### S-51 预期租户是比较条件

expectedTenant为IV TenantId，不能作为行事身份或授权依据。以下载荷必须携带：OG2 S23、24、28～33、37、56、58～60、62；本组合S50；OG2 S55仅callerIdentityKind=tenant时必须携带，account时禁止该成员。其他路由禁止该成员。缺席/形状不合在认人后载荷阶段invalid-input，不从服务器或本地缓存补值。

同一共同边界读取OG S36真实当前选择，再与expectedTenant按IV结构相等比较；不等返回 `{failure:"expectedTenantMismatch"}`，不执行目标业务、不touch，不自动切换/重发。实际身份的账号分量必须与AI44相同，否则缺陷并回滚。相等也必须继续各自授权，不能以比较通过替代成员/超管现读。

切换S37携带的expectedTenant指切换前选择，targetTenant才是目标；查询S36不要求预期值，可用于刷新真实状态。两个客户端共享登录并发切换，旧预期的后续操作只能失败，不能落入另一个组织。失败不带实际租户，客户端另查S36后由人确认。

### S-52 主动更换凭据投影

路由 `capability.account-identity/v3#S-50`，载荷恰为currentCredential、newCredential，表示沿CredentialMaterial；无AccountId、无expectedTenant。认人后校验载荷，再调用AI3 S50准备阶段：校验有效发起登录、取得账号/G/材料、当前凭据验证、政策与新材料派生。昂贵工作不占共同写入边界，准备不是业务成功、不touch。

最终共同边界由AI S50按原账号/G重核，再核发起登录；无需在此之前额外exchange掩盖G已变时的current-credential-rejected。准备所得句柄/证明只能用于这次操作，不能由网络构造。成功替换后AI49最终计时，同提交，答 `{result:"ok"}`；不签发新登录。login-state-rejected与invalid-input映射同入口值；current-credential-rejected、credential-rejected原名透传；storage-unavailable或提交未知为unavailable。政策原因不上线，保持失败形状闭合。非幂等，不重试、不逆向补偿，无事件。

### S-53 接收方拒绝投影

两条路由 `capability.organization-governance/v2#S-61` / `#S-62`：前者载荷invitation、推导AI账号；后者affiliationRequest/expectedTenant、推导真实当前租户。成功均ok，分别消费OG61/62的完整前置、幂等、终结不覆盖和无事件。共同边界沿S49；OG不可用→unavailable、invalidInput→invalid-input，其余具名失败原名。对本人accountNotActivated/accountDoesNotExist视为与已认证事实矛盾的缺陷。拒绝自己的已declined可幂等成功；未知提交不能替客户端自动重复。

### S-54 新增验证义务

- 31条路由的载荷、结果与封闭失败按路由核验，不只用全局failure枚举；declined读面实例、缺/错/多余expectedTenant、改密秘密输出全覆盖。
- 成功读/写/幂等成功touch，具名失败/health/纯exchange不touch；最终时钟失败整体回滚，schema不符整体回滚且没有通知。
- 暂存活动到提交期间，真实第二连接观察不能绕锁；成员降级、租户切换、邀约竞争与业务同边界。预期不符不执行目标操作，去掉比较的负控应失败。
- 改密准备与提交间G变化先报current-credential-rejected；撤销但G未变报login-state-rejected；旧凭据签发竞争和全部旧登录失效由AI测试加真实入口旅程核对。
- 停机/依赖换代等待共同事务收场；提交未知不宣称未发生，通知不提前；重启/升级不续期。
- 维护增量另按 S-55～S-59 与 examples 的维护场景验证；4个操作的形状、真实收场、持久发布/unknown、隔离残余和每日进展前提分别取证，不以原业务模型或完整体检代替。

## 十六、本机维护候选

本节依据 PF-017 rev5 的不停服备份和恢复隔离要求；数值、逻辑名与返回值均为主线的候选选择。
`backup`、`verify`、`restore-isolated` 使用日常含义，`Metadata`、`BackupDescriptor` 只是本组合的数据表示，不产生新业务身份。

### S-55 backup

| 九件事 | 内容 |
|---|---|
| 1 输入与授权 | 恰 `{onlyIfDue:boolean}`，必填；不得带路径、账号、租户、凭据或查询语句。只向具有本机机器控制权的运维者开放，授权不能由业务登录代替 |
| 2 前置 | S-34 两面共同应答、当前升级已确认、源仍由同一排他属主拥有、S-59 维护责任齐备；同一在线中心部署属主最多一个维护工作（含backup、backup-status及其目录候选检查），已占用答 `busy`，不排队 |
| 3 提交点与原子性 | 源在 `[startedAt,finishedAt]` 内固定一次一致观察，各 owner 检查同一完整副本，随后独占发布。输出完整且发布持久已确认才 `completed`；公开可见但确认不了不是成功。源业务继续，不改源治理事实/原中心身份/登录计时/时钟底线；一致观察不是停服或业务提交 |
| 4 返回与失败集合 | 成功恰 `{status:'completed',backup:BackupDescriptor}`；仅 `onlyIfDue=true` 且 S-56 重新校验、持久确认的 latest 未到 20 小时时为 `{status:'not-due',backup:BackupDescriptor}`。正常失败恰 `invalid-input,busy,unavailable,capacity,invalid-backup,target-exists,cancelled` 的单 `status` 对象；发布或重取确认失败为 `{status:'outcome-unknown',fileName:<候选名>,targetLocation:null}`。各值边界见 S-59；不认识的内部缺陷独立传播，不塞进集合 |
| 5 幂等边界与重发 | `onlyIfDue=false` 每次成功是新独占输出，不覆盖同名文件；名称冲突为 `target-exists`。无请求去重，不能自动重试 unknown。`onlyIfDue=true` 每次按 S-56 的目录候选及先核完整性/中心身份、后评价当前中心时间的次序重判：无有效副本或 `now-startedAt>=20小时` 才新建；扫描中重取确认失败立即 unknown，本次不新建、不降级信较旧副本。以后显式新检查可重新确认同一输出 |
| 6 事件 | 无领域事件，不续登录、不写成功业务活动；结果和无秘密诊断不承诺送达 |
| 7 缺席时的默认答案 | 缺必填表示为 `invalid-input`；缺配置或能力不能整体开闸；应答中的源/时钟/介质不可用为 `unavailable`，已发布确认不明按 unknown。不能用空库、默认路径、上次结果或假成功替代 |
| 8 在途归属 | 源维护属主从接纳一直负责到导出真实结束、固定观察及句柄释放、发布/残余收场完成。断连、5分钟预算触发取消、停止通知均不移交或结束责任。取消及清理的结果按 S-59 |
| 9 装配给／协议给 | S-36/S-59：单机提供者兑现一致观察、排他属主、完整性与耐久，入口兑现闭合答复；跨进程须重建同样的观察、所有权与发布确认保证，做不到不开放 |

### S-56 backup-status

| 九件事 | 内容 |
|---|---|
| 1 输入与授权 | 恰 `{}`；同 S-55 本机机器控制，不接受业务身份或用户指定扫描路径 |
| 2 前置 | 与 S-55 相同的整体开闸、升级确认及唯一源属主；占同一维护名额，忙则 `busy`，不排队 |
| 3 提交点与原子性 | 按本条下文精确筛选配置备份目录中的候选；先核完整性及当前中心身份，再评价其时间并重新取得合格候选的持久发布确认；确认属于持久副作用。成功答复以本次完成的校验和确认及同次时间观察为依据，无业务提交，不改变完整体检的纯读约定 |
| 4 返回与失败集合 | 恰 `{status:'observed',health:'current'|'overdue'|'missing',latest:BackupDescriptor|null,invalidCount:0..256}`；失败恰 `invalid-input,busy,unavailable,capacity,cancelled` 的单 `status` 对象，或 `{status:'outcome-unknown',fileName:<候选名>,targetLocation:null}`。已知损坏计入 invalidCount，不是有效副本；读取不可用不能冒充损坏。完整候选重取确认失败立即 unknown，不能略过它答旧副本 current |
| 5 幂等边界与重发 | 每次重新校验和确认，不依赖曾打印的成功、名字或修改时间；明确的新检查可确认过去 unknown 的完整输出，不是自动重放原请求。并发按 S-59；不删除任何成功备份 |
| 6 事件 | 无；健康结果只属于维护诊断，不写治理或登录活动 |
| 7 缺席时的默认答案 | 成功扫描证明没有有效副本才 `missing/latest=null`，不能把读取失败当空集。取不到 now、now 早于任一已通过完整性及当前中心身份核对的待评价候选 startedAt 为 `unavailable`，不计算负年龄；其他中心的候选在时间评价前已排除，其未来时间不阻止当前中心到期备份；依赖缺失同 S-55 |
| 8 在途归属 | 维护属主负责读、核对、确认与隔离暂存收场；连接结束不释放名额/源属主。取消仅在未遗留不确定确认且清理已确认时可报 `cancelled`；已开始的持久确认无法确定仍 unknown |
| 9 装配给／协议给 | 本机装配给有界扫描、同一输出校验与确认及可靠时间；协议给精确状态，不能把校验成功当持久成功。跨进程无法维持输出身份和确认关联则不开放 |

**目录候选及判定次序。**S-55 的到期扫描与本操作使用同一规则：

1. 只取配置备份目录的**直接条目**，名称须完全符合 S-59/Schema 的 `BackupFileName`。其他名称一律忽略，包括名称不匹配的隔离工作目录；不递归进入，不计入256个候选上限，也不计 invalidCount。名称匹配的条目无论类型均先计候选名数；候选名数超过256先答 `capacity`，不先略去坏件/外中心文件后报告健康。
2. 对候选判断条目类型。匹配名的非普通文件、符号链接不跟随，每个计一次 invalidCount 并排除；无法读取或判断类型的I/O故障为 `unavailable`，不得伪称坏件。
3. 对普通文件完成封装及数据完整性、owner元信息检查。已知格式/完整性不合格计一次 invalidCount 并排除；S-59 已有容量边界仍为 `capacity`，读取故障仍为 `unavailable`，都不伪称校验拒绝。
4. 完整合法但 metadata.centerId 不等于当前运行中心的候选计一次 invalidCount 并排除，不删除或改写。**排除发生在时间及最新性评价之前**；外中心的 startedAt 即使晚于 now 也不触发时间不可用，不阻止本中心到期备份。
5. 仅对剩余当前中心候选评价时间、取得其持久发布确认并选择有效副本。当前中心候选未来时刻仍按第7件事为 `unavailable`；完整候选重取确认失败仍为 `outcome-unknown`，不能降级使用旧副本。I/O异常和确认故障不计 invalidCount。

**选择与时间边界。**不存在有效副本时 health=`missing` 且 latest=`null`。有效者按 startedAt 最大选择 latest；同刻按 fileName 逐 ASCII 码点字典序最小者选择（无 locale）；只作确定性选择，不赋予更新事实含义。年龄 `now-startedAt>24小时` 为 `overdue`，其余 `current`。20小时恰好到期、24小时恰好仍 current，两条边界分别服务补做和健康判定。

**带前提的进展。**调度每小时尝试 S-55 且 `onlyIfDue=true`；初次没有有效副本即到期。调度不得启动有意停止或仍在停止的中心。调度实际延误、等待/校验、导出与发布合计不超过剩余4小时，并且源、介质、可靠时间和吞吐持续可用，才有每天有效副本的保证。任一前提失败显式报告缺失/失败/超期，不把触发过视为成功。目录有限、容量足够也是前提；不自动删除成功备份，不承诺同机副本可抵抗整机损毁，也不承诺灾备 RPO/RTO。

### S-57 verify

| 九件事 | 内容 |
|---|---|
| 1 输入与授权 | 恰 `{sourceLocation:string}`；sourceLocation 是已有封装文件位置，位置形状见 S-59，必填无默认。同一部署运维者的本机工具，以机器控制授权，不要求活跃中心、不接受账号/租户/凭据 |
| 2 前置 | 有能力对给定文件固定同一输入观察、完整读取并保持检查用明文独立持久隔离；离线每个调用作用域最多一个维护工作，同一维护工作区必须跨进程互斥，已占用答 `busy`，不排队。不同工作区可并行只读检查同一封装，不以源文件相同要求全机互斥；不把活跃中心的身份替换进文件 |
| 3 提交点与原子性 | 输入不改；校验已知封装、精确长度/摘要、迁移和数据完整性、原中心身份及原时钟底线。成功只证明本次被检查文件完整，不迁移、不重铸、不重计登录，不重新取得其既有发布的持久确认 |
| 4 返回与失败集合 | 成功恰 `{status:'verified',metadata:Metadata,businessOpen:false}`；正常失败恰 `invalid-input,busy,unavailable,capacity,invalid-backup,cancelled` 的单 `status` 对象。没有 completed/unknown，也无目标发布 |
| 5 幂等边界与重发 | 不改输入，可显式再校验；不同次检查不保证文件仍相同，但每次都固定同一输入观察。并发遵守调用作用域单槽及同一工作区跨进程互斥；不同工作区并行只读同一封装时，各自暂存仍独立持久隔离。失败/成功均不允许生产打开文件或检查残余 |
| 6 事件 | 无，不产生登录/治理事件；无秘密诊断归本机运维者 |
| 7 缺席时的默认答案 | 位置缺失或表示不合格为 `invalid-input`；读不到为 `unavailable`；已知格式/完整性/owner检查不通过为 `invalid-backup`。不把损坏当空源，不从运行中心补数据 |
| 8 在途归属 | 本机维护执行方拥有全部文件检查与隔离暂存直到真实结束及清理/残余稳定；取消、工具调用断开不弃置责任。无需运行中心仍须保留隔离 |
| 9 装配给／协议给 | 本机工具给稳定输入观察及所有 owner 的只读检查，结果给 verified 与 businessOpen=false；无法保证输入未变或隔离则失败。未来跨进程必须重新兑现同一观察与隔离，不提升为恢复可用 |

### S-58 restore-isolated

| 九件事 | 内容 |
|---|---|
| 1 输入与授权 | 恰 `{sourceLocation:string,targetLocation:string}`，两个位置都显式、形状见 S-59；同 S-57 本机机器控制，不要求活跃中心，不提供治理授权 |
| 2 前置 | 源可按 S-57 固定同一输入观察并核对，离线调用作用域及工作区排他边界同 S-57；targetLocation 必须是尚不存在的新私有目标目录，目标独占发布；既有目录即使为空也 `target-exists`。最终交付隔离封装，不是可服务数据库。不得覆盖/并入已有目标或活跃数据，无默认或强制覆盖分支 |
| 3 提交点与原子性 | 同一完整输入核对通过后向独占的新目标发布隔离数据；发布持久确认前不得成功。只取得数据，原中心标识、治理事实、登录时间与时钟底线原值保留；不迁移、不改授权、不开放业务 |
| 4 返回与失败集合 | 成功恰 `{status:'restored-isolated',metadata:Metadata,targetLocation:string,businessOpen:false}`；正常失败恰 `invalid-input,busy,unavailable,capacity,invalid-backup,target-exists,cancelled` 的单 `status` 对象；本次目标发布后持久确认不了为 `{status:'outcome-unknown',fileName:null,targetLocation:<请求目标>}`。源既有发布耐久不由本操作声称 |
| 5 幂等边界与重发 | 独占目标，重复不会覆盖；unknown 保留目标、不能自动重试。不从已有目标推定先前成功；明确的新 verify 只能证明完整性。并发按 S-59 的调用作用域单槽、同一工作区跨进程互斥及目标独占；不同工作区可并行只读同一封装，但每次输入观察固定、暂存独立持久隔离，不能并发覆盖同一目标 |
| 6 事件 | 无治理事件，无自动开闸通知；本机结果明确 businessOpen=false |
| 7 缺席时的默认答案 | 缺位置/错误表示 `invalid-input`；依赖不可用 `unavailable`，不建空中心；校验不通过 `invalid-backup`；安全再开放没有操作、没有默认答案，始终保持隔离 |
| 8 在途归属 | 本机维护执行方负责至输入检查、发布/确认、句柄释放与隔离残余收场真实完成。发布后不能因断连或取消删掉已公布目标，不确定按 unknown 留存 |
| 9 装配给／协议给 | 本机工具给目标独占、全量检查、持久隔离和发布确认；协议给“数据已取得，业务未开放”。做不到任一前提不报告成功。跨进程须同样兑现，不借网络成功回执冒充安全开放 |

### S-59 维护的共同表示、隔离与真实结束

**闭合表示。**S-55～S-58 每个返回只含该分支列出的成员；形状见 [Schema](governance-center-entry.schema.json)。维护 `status` 集合与 S-6/S-7 的业务入口答复分开，不能包装成业务成功、拒绝或授权结果。

| 表示 | 精确成员与约束 |
|---|---|
| 文件位置 | 1～4096 Unicode 标量值，无 NUL、C0、C1，不含孤立代理码点。具体平台路径约束归绑定；没有默认位置 |
| Metadata | 恰 `format,centerId,sourceBuildId,migrationNames,startedAt,finishedAt,byteLength,sha256` |
| format/centerId | format 恰 `omne-center-backup/1`；centerId 引用本契约 S-27 GovernanceCenterId，不另造身份。S-55 必须来自同一完整副本且等于运行中心；S-57/S-58 只核本件内部一致合法 |
| sourceBuildId | 64位小写十六进制字符串或 null；null 仅表示开发构建未知，不能冒认正式制品 |
| migrationNames | 有序、唯一、非空列表，最多256项；每项1～128位ASCII字母/数字/下划线；核对所记录的完整迁移前缀，不借此执行迁移 |
| startedAt/finishedAt | 引用 OE2 Instant；startedAt≤finishedAt，区间包住固定一致观察，finishedAt 不是观察时点。绝对时间解析与相互顺序是语义核对义务 |
| byteLength/sha256 | 数据内容字节数，整数1～1073741824；原数据内容的64位小写十六进制摘要，摘要只查完整性不证明来源可信 |
| BackupDescriptor | 恰 `{fileName,metadata}`；fileName 为32位小写十六进制字符后接 `.omne-backup`，部署文件名不是业务身份，不覆盖已存在同名 |

**失败语义。**`invalid-input` 只说明输入表示不合格；`busy` 是相应维护执行方的单槽或同一工作区已被占用且不排队；`unavailable` 是读/时间/依赖/收场不能完成；`capacity` 包括数据超过1GiB、候选超过256、头超过16KiB或空间不满足；`invalid-backup` 是已知格式、完整性或 owner 检查不符合；`target-exists` 仅有目标发布的 S-55/S-58 可达；`cancelled` 仅在未发布且工作与清理已确认收场时可达。不得将“不能判定”冒充校验拒绝。目录枚举中的已知坏候选按 S-56 计数，不让 invalid-backup 假冒 missing。

发布已发生而耐久确认不了时，唯一结果是 `outcome-unknown`，仅该操作的位置非 null。已发布物保留；完整性通过不能消除未知耐久。持久确认已成立则即使取消后到也按真实完成结果交付，不倒称 cancelled。句柄已实际关闭后，未发布暂存残余清理失败且仍隔离时答 `unavailable`，即使本次输出持久发布已确认也如此；本机无秘密诊断明确已发布输出保留及本任务残余位置。`unavailable` 不证明没有效果；不得删除已发布物，也不得假称无残余。若发布耐久仍不确定则 `outcome-unknown` 优先于清理失败。以后新的 S-56/onlyIfDue 可重新核对并确认现存副本计有效。未声明的内部缺陷沿既有缺陷边界单独传播并稳定诊断，不转换为正常 `invalid-input`。正常失败与缺陷诊断都不输出原始查询语句、账号资料或凭据。

**存储维护受消费要求。**本组合要求源维护提供方显式拥有以下性质，不据此新增独立治理能力；具体类型由节点绑定：

| 要求 | 责任与做不到的结果 |
|---|---|
| 同一一致观察 | 固定源观察后业务可继续；导出、结构、中心身份、时钟底线、迁移前缀检查全部针对同一完整副本；无法保证则失败，不能拼接多个时点 |
| 原数据只读 | 所有 owner 的副本检查不迁移、不铸造身份、不改治理、不续登录、不更新时钟底线；读不到与不合法分开，不能补初值 |
| 工作与资源同属主 | 单槽范围是同一维护执行方管理的工作：在线同一中心部署属主最大一个，含backup、backup-status及目录候选检查；离线每个调用作用域一个，同一维护工作区跨进程互斥。不同工作区可并行只读检查同一封装，每次固定同一输入观察、暂存独立持久隔离，restore目标独占不变；不得仅因只读源封装相同而拒绝不同工作区的调用。所有固定观察、句柄、执行与暂存直到实际释放/收场仍归接纳方，取消与连接结束不提前归还相应单槽/工作区所有权 |
| 关闭 | 在线两面停止接纳后原工作继续归原部署属主；导出真实结束、观察和所有句柄释放、发布或隔离残余收场完成，才可释放源排他所有权。离线工作同样真实收场后才归还调用作用域单槽及工作区所有权，不据此取得对同一源封装的全机排他权。5分钟只是请求取消预算；无执行进展时保持 stopping，正常关闭无有限上界。强制终止是非正常故障，不能作为同时启动第二部署属主或第二工作区属主的许可 |
| 独占持久发布 | 新名字/目标不可覆盖，完成只在完整输出与持久发布确认都成立后。确认失败保留输出，后续显式检查可以重新确认，不自动重试发布 |
| 明文先隔离 | 任何明文副本出现前先建立持久隔离；普通失败、取消与崩溃残余同样受保护。清理不能撤销残余的拒绝依据，即使删除在崩溃后回退也仍拒绝 |
| 生产打开拒绝 | 所有当前正式支持的生产打开路径一律拒绝备份封装、恢复封装和任何持久隔离中的明文；不能核实也拒绝。支持制品集合须由采用决定精确登记；历史实验制品不获此保证，新正式制品不可绕过。持有宿主者恶意改数据/移除保护不属沙箱保证 |

**完整动作链。**准入方接纳后，相应维护执行方持有工作责任（在线为部署属主，离线为调用作用域及工作区属主）；一致观察完成不等于导出结束。导出真实结束后，各 owner 只读检查同一副本；不通过则清理、保持隔离并报告。检查通过才独占发布；确认持久才答 completed/restored-isolated，失败则 unknown 留存。即使答复送不达，属主仍完成观察/句柄释放及暂存收场；之后才归还维护名额，源正常关闭另须全部在途工作结束。verify 没有发布步骤，status 只有重新确认步骤。任何一步退出都不能留下可作为生产库打开的明文。

**验证义务。**[维护规范场景](examples.md#维护场景)和 [有限行为模型](formal/README.md#维护模型)分别承接时间/数据边界与生命周期交错。真实执行须覆盖并发业务固定观察、断连/关闭/取消竞态、超过旧等待期限仍持有属主、所有发布切点强杀、空间不足、损坏、目标冲突、清理失败和删除回退的残余、支持制品全部打开路径拒绝、到期补做及定时不启动有意停止中心。有限模型不能证明真实介质耐久或全部打开路径；不得用模型通过替代这些证据。

## 报给主线

- G-1：本候选和正式支持制品集合须精确采用；真实维护验证未开始。PF-017 rev5 已作为输入，不因此接受本契约。
- G-7：安全再开放仍无政策；本版只隔离，不设计核对者、忘密、全量登出或升超管。
- G-10：新增维护传输绑定须另发版本，保留员工业务面不变的范围。
- G-12：既有升级整体性/启动前核对的契约家仍待主线处置，本版只消费“当前升级已确认”，不冒称闭合该旧缺口。
- 继承的“入口层”“运维面”“出示物”“列表句柄”（无词条）仍按旧契约用法；新增维护数据表示不登记为领域身份。
