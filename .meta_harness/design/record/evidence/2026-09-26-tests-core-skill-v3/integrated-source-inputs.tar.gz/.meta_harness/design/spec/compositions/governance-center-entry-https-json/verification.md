# 验证覆盖与实际证据

本文件在版本目录之外，可更新；结果始终绑定实际的规范修订与实现修订。

## v3 维护绑定候选

2026-09-25：[HT3](v3/contract.md)为candidate，未接受；依赖EC3 candidate、IV1/OE2 accepted，产品依据PF-017 rev5/PF-016 rev7。

| 性质与条款 | 证据义务 | 本轮状态／owner |
|---|---|---|
| S-11～S-15/S-21字节与数据引用 | [examples](v3/examples.md)24份完整HTTP报文的文本/十六进制/长度/摘要相符；新增payload/result按EC3定义核验 | **通过（工件检查）**；8份继承报文逐字节保持、16份新增报文符合引用定义，不证明真实网络实现 |
| S-19客户端2与ops1独立 | 同构建上客户端原请求与旧字节相符；只有运维socket解释opsVersion，文件工具不上线 | **未开始**；入口与host版本映射 |
| S-20/S-21运维解析、通道与下限 | 缺/多/错/重复字段、UTF-8/BOM/语法、深度64/成员1024、头8192/体65536/30秒的边界和优先级；禁止原body日志 | **未开始**；入口解析/服务器 |
| S-21/S-23失败结果映射 | 所有EC闭合结果保持，required null不省略，unknown不变成功/未发生，unavailable不变无答复 | **未开始**；运维写出器与本机工具 |
| S-5/S-20/S-23真实关闭 | 断连、写失败、网络排空期限不释放EC维护属主；新请求停止、已受理维护真实收场，无自动重做backup | **未开始**；入口、host与EC维护提供者真实组合 |

本轮字节检查命令：`.venv/bin/python tmp/production-cli-onboarding/check-ht3.py`。
实际输出：`PASS: 24 complete HTTP examples (8 inherited byte-identical, 16 new); text/hex/length/SHA-256 consistent; all new payloads/results match EC3 definitions.`
原始输出在任务区`tmp/production-cli-onboarding/ht3-byte-check.log`，不是已归档的正式实现证据。
本轮设计检查使用`.venv/bin/python .meta_harness/tooling/src/check_design.py --root .meta_harness/design --formal registered`，
实际输出`PASS: design tree …/.meta_harness/design passed gate=internal; formal=registered.`，原始输出为任务区`tmp/production-cli-onboarding/ht3-design-check.log`。
该次运行时HT3候选条目尚在交主线集成的片段中，因此本结果不冒称新catalog坐标已完成集成校验；集成后须再运行同一检查器。
本版不新增Schema、TLA+/Alloy工件或formal task：共享表示只引用EC3，维护行为权威仍归EC3；本次**未运行形式工具**。

### v3 变化的影响

客户端已有字节/路由/协议号保持；绑定标签变为https-json/3，不能推导员工线上版本3。S-19/S-20/S-21/S-23/S-24/S-29/S-31明确运维解析、独立opsVersion、维护结果和工作归属；S-10/S-12明确共用边界及必需null，原客户端字节不变。
HT1/HT2旧运维“任意成帧报文都回体检”证据不能复用于本版；运维嵌套/成员上界现已适用，必须重建解析、通道和真实关闭证据。EC3若改表示/结果须重新对齐本绑定，不能默默跟随。
候选登记片段提供2份资源、3项精确依赖、未复核covers；编号族沿用、无新形式任务。G-2/G-3/G-4保留既有owner与范围，候选采用和真实适配验证尚未完成。

2026-09-25独立评审修订：按主线裁定修正v3 S-29，停机排空界内完成的请求可答，超界仅结束网络交付，原owner仍负责已受理工作至真实结束；不增加超时取消或自动重试。与S-16/S-21/S-23及EC3 S-59对齐，字节例和共享表示未变；真实停机适配场景仍未开始。

2026-09-25批内对齐：按主线裁定在HT3 S-16/S-21/S-23/S-29及examples明确“已受理运维EC独立defect未交合法结果→关闭无答复，本机ops-internal-defect”；底层输出自身出错单列传输失败，原owner与子资源继续真实收场。该诊断不是EC返回字段/status，客户端业务unavailable映射保持。与EC3 S-25/S-31/S-34/S-55/S-56/S-59核对操作名、只读体检与持久维护区别、闭合结果/必填null、目录与时间判定归属、断连/缺陷/unknown收场；两版均采用PF-017 rev5，catalog消费方向仍HT3→EC3，引用锚点/Schema定义保持。没有改旧冻结版、Schema、模型或registry。新增缺陷对照及真实连接场景**未开始**，字节例的既有通过不覆盖它们。

同轮EC3收窄维护排他范围后，HT3 S-23的在线维护名额仍指同一中心部署属主的单槽；离线调用作用域/共享工作区边界留在EC3 S-57～S-59，文件工具不上线，不产生新运维动作或传输字段。

批内对齐后已核对主线集成的catalog：HT3与EC3均为candidate，HT3精确消费EC3/IV1/OE2。重跑字节检查输出仍为24份完整HTTP例通过、旧8份不变；EC3样例108例通过。集成后的`check_design.py --formal registered`实际退出0，输出`PASS … gate=internal; formal=registered`，补齐上文首轮尚未集成时的检查范围；这不是形式工具或真实套接字执行结果。

## 既有版本的证据

> **当前状态：已接受并冻结（D-029，2026-09-23）。**实现测试的一次运行已入库：[`2026-09-23-tests-tenancy-leg-2`](../../../record/evidence/2026-09-23-tests-tenancy-leg-2/README.md)（源码提交 `c9b5850`；入口层提供者是[实现映射节点](../../../realization/packages/tenancy/governance-center-entry/README.md)）。
> V-1～V-9 与 V-11 都有通过的承担者；**V-10 无证据**（`apps/cli` 的客户端代理不存在）。承担者写成「文件 › describe › it」，文件都在入口层包 `packages/tenancy/governance-center-entry/tests/` 下；逐条状态在该 run 的 `cases.tsv`。
> 「实际执行」一节另留起草者对 examples 的自检，它不是任何一条证据义务。**通过不提升或改变任何接受状态。**

## 证据义务

| 规范条款与性质 | 证据形式 | 实际证据入口、输入与范围 | 未完成义务、责任与受阻消费者 |
|---|---|---|---|
| **V-1** [S-11](v1/contract.md#s-11-答复的外形)、[S-13](v1/contract.md#s-13-四种入口答复的固定字节) 四种入口答复逐字节等于 examples；[S-15](v1/contract.md#s-15-公开体检答复) 公开体检答复的形状 | 入口层 T-2 的固定字节快照：四份答复的完整字节与 [examples §1、§3](v1/examples.md#1-version-mismatch) 逐字节相等（含 SHA-256）；公开体检答复把标识与版本代成 examples §2 的值后逐字节相等；每份答复在连接上**一次写出**（S-11：比较的是 HTTP 报文层的字节，另核写出次数）；规范场景 [S-26](v1/contract.md#s-26-规范场景固定字节只看请求体) | **已通过**（run `2026-09-23-tests-tenancy-leg-2`）：`bytes.spec.ts` › `T-2：四种入口答复与 examples §1、§3 逐字节相同`（5 条）、`T-2：公开体检（examples §2）`（2 条），快照直接读本页所指的 `examples.md`（该 run 核对的哈希 `0efcc32c…` 与冻结登记相同）；一次写出 `transport.spec.ts` › `V-1：每一份答复在连接上一次写出`；真实组合 `center.spec.ts` › `T-2 线上逐字节相同（真实组合）`（2 条）；场景 S-26 `transport.spec.ts` › `V-5 只看请求体（规范场景 S-26）`（15 条）。另有该 run 的[独立字节核对](../../../record/evidence/2026-09-23-tests-tenancy-leg-2/README.md#一入口层产出的答复字节-vs-传输绑定-examplesmd-15)（函数级，§1～§5 七份答复逐字节相同） | 责任：入口层。**T-2 的快照必须取自本页所指的 examples，不另抄一份**；本契约接受前 T-2 对的是候选 |
| **V-2** [S-18](v1/contract.md#s-18-跨协议版本不改的两样在本传输上)、[S-19](v1/contract.md#s-19-随协议版本演化的部分换传输) 跨协议版本不改的两样 | 回归测试：把 `version-mismatch` 的 133 个字节、公开体检请求与答复的形状、S-7 的读法（解析器层：同一请求体读不读得下来、读成什么值，不经过 ①）、TLS 最低版本与服务端认证方式、四项接收上界与接收时限的下限钉在测试里；改 `accepted_protocol_versions`、加一条路由，这组测试都不许动也都须通过（加一个协议版本时，字节、形状、S-7 读法、TLS 参数与下限的断言不许动；判定次序与 ① 触发条件的断言——含端到端发公开体检请求拿到公开体检答复这一件，它依赖「第 0 步先于 ①」——只钉本版承载的协议版本，见 G-4）；规范场景 [S-27](v1/contract.md#s-27-规范场景跨协议版本) | **已通过**（钉住的各项，同 run）：`bytes.spec.ts` › `V-2：任何别的答复的体都不等于 "version-mismatch" 那 18 个字节`；133 个字节 `bytes.spec.ts` › `T-2：…` › `version-mismatch`；S-7 读法 `json.spec.ts` › `S-7 四级读法（examples §6）`（8 条）；下限 `framing.spec.ts` › `接收上界与时限的取值不低于契约下限（S-10 下限表；V-2 钉住的那几项）`；TLS 最低版本 `transport.spec.ts` › `V-7 与 T-19：…` › `只提供 TLS 1.2 的客户端握不了手`。「改 `accepted_protocol_versions`、加一条路由时这组测试都不许动」是对今后改动的约束，本 run 核不了；场景 S-27 只在本版承载的协议版本上断言 | 责任：入口层。另核「任何别的答复的体都不等于那 18 个字节」：对每条路由的每个具名失败与入口答复断言一次。「第 0 步先于 ①」与 ① 的触发条件是否跨协议版本冻结归 EC（[G-4](v1/contract.md#十一已知缺口)）：这两件的断言只钉本版承载的协议版本上的行为 |
| **V-3** [S-7](v1/contract.md#s-7-请求体怎样读成信封) 请求体的读法 | 解析器逐例测试：[examples §6](v1/examples.md#6-请求体的读法与重复成员) 第 1～8、15、16、18 行，含 BOM、非法 UTF-8、原始字节里的代理码点编码、转义写出的孤立代理码点、非对象顶层、尾随字符、`9007199254740990.5` 不是整数 | **已通过**（同 run）：`json.spec.ts` › `S-7 四级读法（examples §6）`（8 条）、`S-7 JSON 值的读法`（6 条），逐行对应看用例名里的 `#` 号；第 15、16 行 `decide.spec.ts` › `T-15 …` › `examples §6 #15、#16：offerTtl 9007199254740990.5 不是整数 ⇒ invalid-input；1e3 合形状、交给领域的是 1000` | 责任：入口层（严格 JSON 解析器）。第 15 行专门挡「先舍入到双精度」这一种改坏 |
| **V-4** [S-8](v1/contract.md#s-8-重复成员) 重复成员 | 解析器报告测试 ＋ 真实组合：[examples §6](v1/examples.md#6-请求体的读法与重复成员) 第 9～14、17、19 行；四个顶层成员各重复一次，答复落在 EC S-4 那张表写的那一步；载荷里面的重复落在载荷那一步；名字经转义还原后才比较 | **已通过**（同 run）：`json.spec.ts` › `S-8 重复成员：报告每一处，不取其一（examples §6 #9～#14、#17、#19）`（7 条）；`decide.spec.ts` › `T-15 重复成员落在它那一步（S-4；https-json/1 S-8）`（9 条，含出示物重复其一有效、`operation` 重复以转义写出） | 责任：入口层（节点 T-15）。「取其一」是最容易的改坏：必须有一例是两份出示物其一有效（第 11 行） |
| **V-5** [S-5](v1/contract.md#s-5-一条连接恰承载一个请求答复)、[S-6](v1/contract.md#s-6-只看请求体)、[S-33](v1/contract.md#s-33-与-http-规范的有意偏离) 只看请求体、一连接一请求、不写 `1xx`、写完怎样关闭 | 真实组合：规范场景 [S-26](v1/contract.md#s-26-规范场景固定字节只看请求体)——换方法（含 `HEAD`，答复照样带体）、换路径、加 `Expect: 100-continue`（不写 `100`）、`Connection: keep-alive`、`Authorization`，缺 `Host`，答复字节不变、此外无字节；流水线里的第二个请求（多写的字节在读尽上界之内）不被答，第一份答复完整到达；关闭次序：先见对端的写方向关闭（TLS 上先有 `close_notify`），再读尽、全关；多写的字节超出读尽上界或读尽时限到了，连接被立即全关——这一支只断言中心立即全关，不断言客户端收全答复（S-5 允许它收不全） | **已通过**（同 run）：`transport.spec.ts` › `V-5 只看请求体（规范场景 S-26）`（15 条）；`transport.spec.ts` › `读尽时限（S-5；两张面同一连接层）`（1 条） | 责任：入口层 |
| **V-6** [S-10](v1/contract.md#s-10-只答完整收到能成帧的请求报文)、[S-16](v1/contract.md#s-16-问不到不写任何答复字节)、[S-33](v1/contract.md#s-33-与-http-规范的有意偏离) 问不到 | 真实组合：规范场景 [S-29](v1/contract.md#s-29-规范场景问不到与运维面) 的前一半——开门之前、停机开始之后、成帧不了（`Transfer-Encoding` 任何取值、单独 LF、obs-fold、字段名后空白、不一致的 `Content-Length`、没收齐就断开或到了接收时限）、超过各接收上界（各取「上界 + 1」一例），都收不到任何 HTTP 字节，也收不到任何 `4xx`；停机开始时报文已完整收到的在排空上界内答完，只收了一半的被关闭、收不到字节 | **已通过**（同 run）：`transport.spec.ts` › `V-6：开门之前问不到`（1 条）、`V-6 成帧不了与超界：收不到任何 HTTP 字节，也收不到 4xx`（10 条）；`framing.spec.ts` › `成帧不了（S-10）`（20 条）；停机 `lifecycle.spec.ts` › `T-12 停机时的在途请求（S-34）`（2 条） | 责任：入口层 ＋ 承载装配（开门与停机）。上界与时限的取值归入口节点；下限之内不被切见 V-11；合 Schema 的信封超出下限见 [G-3](v1/contract.md#十一已知缺口) |
| **V-7** [S-4](v1/contract.md#s-4-客户端一面的连接只有-tls服务端认证)、[S-22](v1/contract.md#s-22-经传输的秘密) 只有 TLS、服务端认证、不收早期数据、私钥与原始请求不外泄 | 真实组合：规范场景 [S-30](v1/contract.md#s-30-规范场景只有-tls服务端认证)——含会话票据不许早期数据、以早期数据送出的写路由请求没有发生；在全部输出里搜私钥、原始请求目标与原始请求头；与入口节点 T-19、T-11 同一组测试 | **已通过**（中心一侧，同 run）：`transport.spec.ts` › `V-7 与 T-19：只有 TLS、服务端认证、不收早期数据`（4 条）；输出里搜秘密 `center.spec.ts` › `T-11 秘密不进任何输出（本文件全部答复、体检、工程记录）`（按用例名，搜索范围是该文件的全部输出）。客户端一侧**无**：`apps/cli` 不存在 | 责任：入口层 ＋ 承载装配（材料）。**客户端「确认不了就不交出登录状态」不在这里**：归 `apps/cli` 的客户端代理，那个提供者尚不存在——受阻消费者（[G-2](v1/contract.md#十一已知缺口)） |
| **V-8** [S-20](v1/contract.md#s-20-运维面的承载)、[S-21](v1/contract.md#s-21-运维面的答复) 运维面的承载与答复 | 真实组合：规范场景 [S-29](v1/contract.md#s-29-规范场景问不到与运维面) 的后一半——套接字文件恰为目录下的 `governance-center-ops.sock`；任意请求得完整体检、成员次序如 examples §5；嵌套再深、成员再多（只要头部块与请求体在上界内）也照答；目录权限不合、目录不存在、有人在听的残留套接字、不是套接字的文件，各自起不来；没人听的残留被替换；客户端一面不应答时运维面也不应答；停机时在途的照答、没收齐的被关闭 | **已通过**（同 run）：`ops.spec.ts` › `V-8 运维面的承载（S-20）`（3 条）、`T-9、V-8 运维面的答复（S-21、S-26）`（2 条）；客户端一面不应答时运维面也不应答 `ops.spec.ts` › `T-18 两张面同起同停与十项的来源`（serving 之前／stopped 之后不答）与 `transport.spec.ts` › `V-6：开门之前问不到`；接收时限 `slow.spec.ts` › `接收时限：…` › `运维面同一时限…` | 责任：入口层（节点 T-9）＋ 承载装配（目录） |
| **V-9** [S-12](v1/contract.md#s-12-体的写出规则) 体的写出规则 | 写出器逐例测试：[examples §7](v1/examples.md#7-体的写出规则逐例) 每一行；27 条路由的成功返回各取一例，按这次请求的 `operation` 对应的 `Result_<路由>` 的书写次序写出后再按 EC Schema 的 `Exchange` 校验；含 IV 的 `TenantId`、`MembershipStanding` 两支、`ScopeLayerIdentity` 两支各一例 | **已通过**（同 run）：`bytes.spec.ts` › `V-9：体的写出规则逐例（examples §7）`（11 条）；`decide.spec.ts` › `V-9 与 T-10 的成功那一支：27 条路由的成功返回`（28 条） | 责任：入口层。时间点那几行专门挡「照搬一个总写三位小数的时间格式化」 |
| **V-10** [S-17](v1/contract.md#s-17-客户端怎样读答复) 客户端怎样读答复 | 客户端代理的测试：只看体认出 `version-mismatch`；截断、超时、非 200、体读不成 JSON 都归问不到；客户端一律以 `POST`、`Content-Length` 发请求 | **无证据**，受阻：`apps/cli` 的客户端代理不存在（run `2026-09-23-tests-tenancy-leg-2` 的对应清单同写「无」） | 责任：`apps/cli` |
| **V-11** [S-10](v1/contract.md#s-10-只答完整收到能成帧的请求报文)、[S-7](v1/contract.md#s-7-请求体怎样读成信封) 接收下限与各上界判的先后 | 真实组合：规范场景 [S-28](v1/contract.md#s-28-规范场景请求体的读法与重复成员) 的「恰在下限上」四例与接近 30 秒才发完的一例，都得公开体检答复；接收时限到了仍没收齐的，关闭不写；逐例测试：`Content-Length` 大于请求体上界时不读请求体即关闭；请求体里先有非法 UTF-8、后有超深嵌套 ⇒ `version-mismatch`（第 1 级对整个请求体先判）；第 3 级里语法错在前 ⇒ `version-mismatch`、超界在前 ⇒ 关闭不写 | **已通过**（同 run）：`framing.spec.ts` › `接收上界：恰在下限上照收，上界 + 1 即判（V-11；S-10）`（3 条）；`json.spec.ts` › `嵌套深度与成员数两个上界（S-7 表下、S-10；V-11）`（6 条）；接近 30 秒才发完 `slow.spec.ts` › `接收时限：下限 30 秒之内不被切，到了时限还没收齐就关闭不写`（3 条，按真实时长） | 责任：入口层（严格 JSON 解析器与成帧器）。「下限之内不被切」是本条最要紧的一支：只测超界关闭而不测下限之内照答，挡不住把上界取得过低 |

## 实际执行

**已入库的运行（2026-09-23）：**

| 运行 | 输入与配置范围 | 结果 | 证据位置 |
|---|---|---|---|
| [`2026-09-23-tests-tenancy-leg-2`](../../../record/evidence/2026-09-23-tests-tenancy-leg-2/README.md)（V-1～V-9、V-11） | 源码提交 `c9b5850`；入口层包 `tests/` 十三个文件：真 TLS 连接与 HTTP 报文层字节（测试根证书）、真 Unix 套接字、`slow.spec.ts` 按真实时长（接收时限 30 秒）；真实组合为真实 CV／AI v2／OG／AR 与入口层插件同装一个 Cordis Context、`storage-sql` sqlite 临时文件库、钟是包内替身；T-2 快照直接读 `v1/examples.md`（哈希 `0efcc32c…`，= 冻结登记）；Node v24.18.0（OpenSSL 3.5.7）、vitest 4.1.11；另有该 run 用 `byte-checks/` 对入口层构建产物做的函数级独立字节核对 | 入口层包 424 条 **422 通过、2 跳过**、0 失败（两条跳过是装配一侧承担的占位，不涉本契约）；独立核对：§1～§5 七份答复与入口层产出逐字节相同，§2 请求页面自洽；测量自检两次故意改坏都被检出 | 该 run 的 [`output/governance-center-entry.log`](../../../record/evidence/2026-09-23-tests-tenancy-leg-2/output/governance-center-entry.log)、`json/governance-center-entry.json`、`byte-checks/`；义务对应 [`coverage.md`](../../../record/evidence/2026-09-23-tests-tenancy-leg-2/coverage.md#compositiongovernance-center-entry-https-jsonv-1v-11) |

**有限检查不写成无条件证明**：单主机、单次运行；TLS 用测试根证书与 Node 自带的 OpenSSL 3.5.7，不说明别的 TLS 栈；独立字节核对是函数级的字节，连接上一次写出由 `transport.spec.ts` › `V-1` 另证；V-2 钉住的是本版承载的协议版本上的取值，跨版本那一半要等第二个协议版本；**V-10 与 V-7 的客户端一侧没有承担者**（`apps/cli` 不存在）。

**下面是起草者此前对 examples 的自检。**每一次执行都绑定它核对的那份 `v1/examples.md` 所在的提交。**这些都是起草者对 examples 的自检，不是任何一条证据义务。**

| 日期 | 执行者 | 核对的 examples.md | 结果 |
|---|---|---|---|
| 2026-09-23 | 首稿起草者 | 当时的工作树，随后以提交 `02ae8ee` 入库；**首稿当时未记提交号** | 下表四项全部一致或通过（首稿记录） |
| 2026-09-23 | 评审第一轮修订的起草者 | 提交 `02ae8ee` 的 `v1/examples.md`（为补上首稿缺的提交号而重跑） | 8 份字节串（7 份答复、1 份请求）下表四项全部通过；jsonschema 4.26.0，注册表同下 |
| 2026-09-23 | 评审第一轮修订的起草者 | 提交 `2c03302` 的 `v1/examples.md`（本轮修订后；该文件 SHA-256 `0efcc32c45b447b1a0f9fda89a4a34ddcc058418f3c53167fbaceb3a8c302246`） | 同上，8 份全部通过；§1～§5 的字节与 `02ae8ee` 相同 |

四项核对的做法：

| 核对 | 做法 | 结果（首稿记录） |
|---|---|---|
| 两种写法是同一串字节 | 脚本把 [examples.md](v1/examples.md) §1～§5 每一份的转义文本（去掉排版换行、`\r\n` 还原为 CR LF）与十六进制（去掉空白）分别还原成字节，逐字节比较；再与页上写明的总字节数、头部与体的字节数、SHA-256 比较 | 8 份（7 份答复、1 份请求）全部一致 |
| 外形合 S-11 | 每一份答复：状态行是 `HTTP/1.1 200 OK`；头恰为四个、次序与写法如 S-11；`Content-Length` 等于体的字节数；请求的 `Content-Length` 等于请求体的字节数 | 全部合 |
| 体合入口契约的 Schema | jsonschema 4.26.0 ＋ referencing（Draft 2020-12），注册表含入口契约、`data.identity-values` v1 与 `data.offer-expiry` v1 的 Schema：§1、§3 的体过 `EntryAnswer` 与 `ClientFaceReply`；§2 答复的体过 `PublicHealthReply`、请求体过 `PublicHealthRequest`；§4 的体过 `RouteSuccess`，并以 `operation` = `capability.account-identity/v2#S-37` 过 `Exchange`；§5 的体过 `FullHealthReply` | 全部通过 |
| 体合 S-12 | 每一份体按 JSON 读回再以「无空白、非 ASCII 不转义」重新写出，与原字节逐字节比较；逐层核对象成员的次序等于所合定义的 `properties` 书写次序；每个时间点合「UTC、`Z`、秒小数只在非零时写且取最少位数」 | 全部合。另做了三个反例确认核对会失败：成员次序对调、`.000Z`、公开体检成员次序对调，各被检出 |

脚本与它的反例只在起草者的临时目录里，没有入库；它们不替代 V-1、V-9。评审第一轮修订时重写了一份同样四项的脚本，另以三个反例（完整体检成员次序对调、时间点写成 `.250Z`、十六进制改一个字节）确认它会失败，三个都被检出。

## 变化的影响

- **2026-09-23 首稿**（起草者）：新建本 topic 与 v1 的 `contract.md`（S-1～S-32，G-1～G-3）、`examples.md`（§1～§7）；registry 登记见 [catalog](../../../registry/README.md) 与 covers。尚未经过 spec-reviewer 评审。
- **2026-09-23 评审第一轮修订**（spec-drafter，按主线裁决账本 §十四；spec-reviewer 第一轮 2 阻断、8 应修、12 建议）：原地改 `contract.md`，**`examples.md` §1～§5 的字节一个未变**（只改说明文字：占位值出处、HTTP 报文层、运维面文件名、客户端用 `POST`）。
  - **新增条款** [S-33](v1/contract.md#s-33-与-http-规范的有意偏离)（与 HTTP 规范的有意偏离，列全）。**新增缺口** G-4（「第 0 步先于 ①」是否跨协议版本冻结，owner EC 的 spec owner）、G-5（接收时限没有下限，owner 主线）；**G-1 闭合**（文件名 `governance-center-ops.sock`）；G-3 收窄为「合 Schema 的信封可能超出下限」。
  - **语义收紧，消费者要跟的**：只接受 `Content-Length` 成帧（任何 `Transfer-Encoding`、单独 LF、obs-fold、字段名后空白都成帧不了）；四项接收上界有了下限（8 KiB、64 KiB、64、1024），下限之内不切；不收 TLS 早期数据；写完答复按「半关—读尽—全关」关闭；「在途」= 报文已完整收到；客户端一律 `POST`；TLS 最低版本与服务端认证方式进 S-18 的不变集；多协议版本时按 `protocolVersion` 所属版本的绑定写答复。
  - **受影响的消费者**：入口层节点 `realization/packages/tenancy/governance-center-entry`（成帧器只收 `Content-Length`、四项上界取值不低于下限、关闭次序、早期数据、T-2 快照不变）；`apps/cli` 客户端代理（一律 `POST`、`Content-Length`，发完不再写）。
  - **证据义务**：V-1、V-2、V-5～V-10 按新条款补了断言；新增 V-11（接收下限与判的先后）。全部仍「未开始」。
  - **registry**：catalog 依赖加 `data.identity-values` v1（S-7、S-10、S-11）；covers 补 PF-017 acceptance §二 → S-30，§8 那条补 S-30。
- **2026-09-23 主线对修订报回三项的裁决**（spec-drafter 落字）：
  - **G-5 闭合**：接收时限有下限 30 秒（从连接建立到报文收齐，不早于 30 秒切断），跨版本不改；写进 S-10 的下限表，「在下限之内」含「在接收时限的下限之内收齐」，S-18 的不变集与前提随之改。取值仍归入口层（≥ 30 秒）。受影响消费者：入口层节点（接收时限取值不低于 30 秒）。
  - **G-4 扩范围**：EC ① 的触发条件（读不下来、`protocolVersion` 缺席／重复／不被接受）与「第 0 步先于 ①」一并归 G-4；S-18 措辞不变。
  - **运维面**：接收时限适用、下限同样 30 秒（S-20）；读尽上界与读尽时限的口径维持。
  - V-2、V-6、V-11 与规范场景 S-28 随之补上接收时限一例；examples 未动。
- **2026-09-24 评审第二轮修订**（主线亲自落字，按第二轮定向复评 2 阻断 3 应修 4 建议）：S-18 第三条与 S-9 末条改为只冻结形状、字节与 S-7 读法，① 的触发条件与「第 0 步先于 ①」明确归 G-4；S-33「列全」收窄为「已按下列各节核过」并补 `Date`、头部过大 `4xx`、`CONNECT`、前置条件四行与「应当」级举例，两处待核点名；S-16／S-5 钉死握手完成后先发 `close_notify`；S-10 加「语法按 ABNF 严格判、宽松选项一律不采用」与 `Content-Length` 唯一读法；接收时限的起点（握手完成／连接接受）与终点（中心读到最后一个字节，读取延迟不算客户端的）；S-7 深度与成员数只数到最长 JSON text 前缀、语法错与超界同码点时超界先；S-5 读尽上界按 HTTP 报文层计；S-19 补绑定与协议版本的映射一句；S-18 表公开体检行补「在下限之内」。**examples 未动，字节不变。**V-2 的跨版本断言按 G-4 分成两组。
- **2026-09-23 评审第三轮修订**（主线亲自落字，按第三轮收口复核 1 阻断 7 非阻断）：S-33 两处待核按 RFC 9110 原文核完——§7.4（源服务器必须拒绝目标源不符的 `https` 请求）补一行，§13.2.1 不排除 `POST`、原 §13.1／§13.2 行保留并把 §13.2.1 与 §8.6 列进已核清单，§9.3.6 行补「必须拒绝空端口／无效端口的 `CONNECT`」；S-7 删「同码点按超界」——超界只由前缀里的码点触发，两者不会同码点；S-16 改「不主动以重置结束」并说明缓冲有未读字节时传输层仍可能重置；S-10 `Content-Length` 的 ABNF 改引 RFC 9110 §8.6、「值」指去 OWS 后的 field-value，「严格判」限定为报文层语法；G-5 行与 S-28 的起点改指 S-10；S-3／S-5 说明握手阶段时长上界归实现映射；S-18 表公开体检行注明「认法」；V-2 两组断言按 G-4 分清、补 S-7 读法的解析器层断言。**examples 未动，字节不变。**
