# 验证覆盖与实际证据

本文件在版本目录之外，可更新；结果始终绑定实际的规范修订与实现修订。

> **当前状态：未开始。**`data.tool-definition` v2 是 **`candidate`**（2026-09-23 起草；2026-09-25 修复波 3 原地改——[实现映射反推](#实现映射反推2026-09-25)），未接受、未冻结；没有提供者设计、没有源码、没有装配。
> 下表登记的是**已经触发的证据义务**，不是已完成的检查。
> 2026-09-24 第一轮独立评审（基线 HUB `765b01dc`）的处置见[独立评审](#独立评审)。
> 起草时只做过人工对读；**整批对齐（2026-09-24）跑过 V-1 的本地自检与 V-2 的生成结果重算比对**——Schema 一关与 Schema 之外那一步、定义的拒绝值按 S-26 次序比对、由定义重算模型面与实例比较（见[本地自检](#本地自检schema-正反实例整批对齐2026-09-24)）；其余义务仍未开始。

## 证据义务

| # | 义务 | 证据形式 | 覆盖哪些条款 | 实际状态 |
|---|---|---|---|---|
| V-1 | **形状校验**：[`examples.md`](v2/examples.md) 第 1～8 节的正反实例逐条过**表示层校验**；反例还要核对**报出的拒绝值与 M 编号**与第三列一致 | Draft 2020-12 校验器（须能解析 `data.content-blocks` v2）＋ Schema 之外那一步（参数 schema 按官方元 schema 判合法，[S-4](v2/contract.md#s-4-单函数工具)）＋ 一段按 [S-26](v2/contract.md#s-26-表示层拒绝值与判定次序) 次序给出拒绝值的判定 | [S-3](v2/contract.md#s-3-两种范式)～[S-5](v2/contract.md#s-5-多命令工具)、[S-9](v2/contract.md#s-9-四项依赖名)～[S-18](v2/contract.md#s-18-名字的表示与相等)、[S-21](v2/contract.md#s-21-toolresult-的三样)～[S-23](v2/contract.md#s-23-卸载)、[S-26](v2/contract.md#s-26-表示层拒绝值与判定次序)、[S-28](v2/contract.md#s-28-判别式与枚举闭合)～[S-30](v2/contract.md#s-30-实现不在定义里) 的**形状那一面** | **本地自检已跑**（整批对齐，2026-09-24，最后一次在 flat 形落地之后）：第 1～8、11 节 122 处 0 不符，含定义反例的拒绝值与 Schema 之外那一步（[本地自检](#本地自检schema-正反实例整批对齐2026-09-24)）；M 编号本身未机检 |
| V-2 | **生成规则逐字核对**：[`examples.md` 第 9 节](v2/examples.md#9-生成规则的逐字核对)，三命令实例对 [S-7](v2/contract.md#s-7-多命令-input-的生成规则) 五条（flat 形），外加九条调用按模型面与所选命令各判一次、「只带命令清单」变体生成结果不变；[第 11 节](v2/examples.md#11-一份定义投成三家的线上形状)两个条目（单函数带转写、三命令）按 [S-6](v2/contract.md#s-6-模型面只有一个条目) 重算 | 人工对读 ＋ 暂存区机检：由定义算出 `modelInput` 与 `ModelToolEntry`，与实例作 JSON 值比较；**将来**入库为可复跑的检查，并把第 9 节的调用逐条过生成出的 schema、第 11 节三家形状与条目逐字比对 | [S-6](v2/contract.md#s-6-模型面只有一个条目)、[S-7](v2/contract.md#s-7-多命令-input-的生成规则)、[S-18](v2/contract.md#s-18-名字的表示与相等) | **起草者人工对读（2026-09-23；2026-09-24 按 flat 形重做），五条与三条硬要求都对得上，调用表的两列判定与规则一致；生成结果与两个条目的重算比对过了本地自检（[本地自检](#本地自检schema-正反实例整批对齐2026-09-24)）；调用表未机检；未登记为证据** |
| V-3 | **`help` 与 `inspect` 一致**：对带 `help` 的单函数工具与多命令工具（工具一层、命令一层）各调一次 `Tools().inspect`，比对两处说法；并观察 `help` **不**作为可调命令出现在模型面 | 规范场景演练 | [S-8](v2/contract.md#s-8-说明与用法) | **未开始。**需要 `Tools()` 的提供者 |
| V-4 | **声明与实际对得上**：两支——没声明附件存储却返回附件；没声明结果端 `image` 却返回图块 | 规范场景演练 | [S-19](v2/contract.md#s-19-由定义得出的依赖声明)、[S-24](v2/contract.md#s-24-结果与声明对得上) | **未开始。**需要执行运行时；「对不上时落什么」停在 [G-15](v2/contract.md#十已知缺口)，演练只能先断言「被识别为违反声明」 |
| V-5 | **裸字符串的等价**：工具返回一个字符串（含一个看起来像 JSON 的字符串），观察落进消息的是恰一个文本块、两个标注都为真、字符串未被解析 | 规范场景演练 | [S-20](v2/contract.md#s-20-两种写法与等价规则) | **未开始。**需要执行运行时 |
| V-6 | **卸载**：三支——带摘要；不带摘要（占位说明大小与取回途径、**不是系统写的摘要**）；以及**会话日志里没有 `raw`** | 规范场景演练 ＋ 日志检查 | [S-23](v2/contract.md#s-23-卸载) | **未开始。**需要执行运行时与会话日志；占位的组合方式停在 [G-11](v2/contract.md#十已知缺口) |
| V-7 | **后台许可**：一个没有 `allowBackground: true` 的工具，在用户手动切、插队顺带两个触发源下都不转后台；阈值那一支在表示层就被挡住——有阈值无许可的定义被拒（M15，形状面归 V-1），而各层不能为没声明的项配值（资产持有那一侧） | 规范场景演练 | [S-12](v2/contract.md#s-12-后台许可与转后台阈值) | **未开始。**需要执行运行时；两个触发源**必须同跑**——只跑其中一支，一个只在那条路径上查许可的实现看起来完全正常 |
| V-8 | **表示层拒绝不折叠**：一份坏定义进装配，观察它**不被**装成替换件、**不被**从动作空间静默略过、**不被**当成 `forbid` | 规范场景演练 | [S-27](v2/contract.md#s-27-表示层拒绝不是判定) | **未开始。**需要装配与执行运行时；正向该怎么收场停在 [G-15](v2/contract.md#十已知缺口)——**停在缺口不算通过**，三种折叠都没发生才算本条成立 |
| V-9 | **多命令派发以 `commands[c].input` 判参数**：[`examples.md` 第 9 节](v2/examples.md#9-生成规则的逐字核对)里**过了模型面、判定不过**的三条调用都被拒（不因过了生成出的 input 就放行），`{"command": c}` 按 `{}` 判；模型面就不过的四条同样不被执行 | 规范场景演练 | [S-7](v2/contract.md#s-7-多命令-input-的生成规则) 第 3、4 条、[CS-1](v2/contract.md#cs-1-派发一次多命令调用) | **未开始。**需要执行运行时；判定不过时的收场由执行运行时定为 `failed{arguments_invalid}`、带该命令的用法（`capability.tool-execution-runtime/v2#S-11`、`#S-23`；`c` 不在命令表时同一种类、带命令清单——不是「不可用」）；另加一支：`input` 顶层没写 `additionalProperties` 的命令收到未知键也被拒（[S-5](v2/contract.md#s-5-多命令工具) 末条） |
| V-10 | **静态检查**：定义记录的类型里不出现运行时对象、闭包、代码或装载方式；名字不被解析（不按前缀、分隔符取来源） | 实现语言的静态检查（形式归 realization） | [S-1](v2/contract.md#s-1-工具定义是什么)、[S-18](v2/contract.md#s-18-名字的表示与相等)、[S-30](v2/contract.md#s-30-实现不在定义里) | **未开始**；检查器尚不存在 |
| V-11 | **消费者走查**：[CS-1～CS-8](v2/contract.md#消费者核对场景) 逐条按「消费者 X 在情形 Y 下依赖 S-n，得到 Z」走一遍，走不通即本契约的缺口 | 结构化走查（评审对象） | 八条合计覆盖 S-5～S-25 的用法面 | **未开始。**不需要提供者，现在就做得了；CS-7、CS-8 会停在 G-5、G-9 上——**停在缺口不算走不通**，如实记为本版到此为止（CS-5 原停在 G-8，G-8 已关闭） |
| V-12 | **判参数时 `format` 只作注解；编不出来不当作「不判」**（2026-09-25，M37）：一个带 `format: email` 的参数收到 `"not-an-email"` 照常判为合格；一份在这个实现上 `schema_unsupported` 的作者工具**不被**装配后以「不判参数、全放行」运行，它被调用时那一项即刻 `failed{schema_unsupported}`、同批别的项照常，判一次调用超出判定时限同此（D-060 §八 N-22 T-16）；MCP 来源的同一情形以同形替换件出现、原因 `schema_unsupported` | 规范场景演练，**跨契约**（执行运行时判参数；桥投影；会话资产注册表呈现） | [S-4](v2/contract.md#s-4-单函数工具) 末段、[S-26](v2/contract.md#s-26-表示层拒绝值与判定次序) 第 13 行、[S-27](v2/contract.md#s-27-表示层拒绝不是判定) 末段 | **未开始。**需要执行运行时与桥；上限的值未登记（[G-16](v2/contract.md#十已知缺口)），演练时按提供者设计登记的那一份构造输入 |

**设置类别的工作区过滤**（`targetEnvironment` 工作区配不了）的演练**不在本契约**：本契约只把类别定死（[S-10](v2/contract.md#s-10-设置项声明)，形状面归 V-1），
过滤是资产持有与配值那一侧的义务，登在它将来的验证入口。

## 结果与反例

### 已做的人工对读（2026-09-23，未登记）

| 项 | 值 |
|---|---|
| 对象 | 本包 `v2/contract.md`、`v2/tool-definition.schema.json`、`v2/examples.md` 起草当时的内容，及同日按主线裁定修订后的内容（**未冻结，无 hash 可绑**） |
| 方式 | 起草者逐字对读；**没有运行任何校验器** |
| 做了什么 | ① `examples.md` 第 9 节：第 2 节生成结果对 S-7 六条，调用按所选命令判；② 「核对记」：第 1～8 节实例对条款、拒绝值次序与 M 编号 |
| 结果 | 首次对读：原规则六条对得上，同时演示了 G-3 的缺陷（后经主线改判）。修订后重对：① 改判后的六条都对得上，原规则下会误过、误拒的调用在新规则下判得与所选命令一致；② 未发现实例与条款不一致 |
| 范围与局限 | **只是对读。**不支持任何一条行为条款；不支持「Schema 真的接受/拒绝这些实例」——那要 V-1；块与附件引用的实例依赖 `data.content-blocks` 的最终形状 |

### 本地自检：Schema 正反实例（整批对齐，2026-09-24）

| 项 | 值 |
|---|---|
| 工具 | Draft 2020-12 校验器（`jsonschema`，按仓库 `uv.lock`），以对齐后整棵设计树的全部 Schema 建 registry；脚本在任务暂存区，不入库 |
| 输入 | [`examples.md`](v2/examples.md) 第 1～4、7、11 节的 JSON 块（第 11 节只取两个 `ModelToolEntry` 块，三家供应商形状不在内）；第 5 节的改写行（按「B／第 2 节的例子／第 3 节的例子／上一行」改一处还原）；第 6、8 节与第 11 节的表 |
| 做了什么 | ① Schema 一关；② **定义**另走 Schema 之外那一步：参数 schema 按官方元 schema 判合法、三条硬要求（顶层 object 带 `properties`、每个参数带说明、只用十七个关键字）、命令 `input` 的根相对 `$ref` 与 `$id`、`name` 转写后的长度；④ **生成与投影重算**：按 [S-7](v2/contract.md#s-7-多命令-input-的生成规则) 由第 2 节的 `commands` 算出 flat 形，与第 2 节那份比较（含把三个命令的 `input` 换成空参数后结果不变），并对它走三条硬要求；按 [S-6](v2/contract.md#s-6-模型面只有一个条目) 由第 2、3 节的定义算出条目，与第 11 节两块比较；③ **定义反例报出的拒绝值**按 [S-26](v2/contract.md#s-26-表示层拒绝值与判定次序) 的次序算出，与第三列比对；④ 第 2 节生成出的 `modelInput` 同样过三条硬要求 |
| 结果 | **122 处（预期通过 43、拒绝 79），0 处不符** |
| 范围与局限 | `malformed` 的 **M 编号**不比对（只比对拒绝值）；返回值反例只判 Schema；第 9 节的调用表与第 10 节不参与；生成与投影的比较是 JSON 值相等（命令表字符串逐字符），不比对键的书写次序 |

### 尚无的记录

V-1、V-3～V-12 尚无执行记录。首次执行时在此记录工具与版本、环境、配置、输入范围、可复现步骤与原始结果位置；
原始产物归 [`record/evidence/`](../../../record/evidence/README.md)。记录时**分开陈述** Schema 校验、生成规则比对、规范场景演练与真实组合的符合性，四者不互相冒充。

## 对齐义务

**这些是本契约与别的契约之间要一起落的事**，不是本契约自己的证据义务。

| 对齐什么 | 涉及 | 现状 |
|---|---|---|
| **模型交回的调用名按逆转写对回定义**（`__` 换回 `:`，[S-6](v2/contract.md#s-6-模型面只有一个条目)、[S-18](v2/contract.md#s-18-名字的表示与相等)）——**只在工具执行运行时起执行者之前做**；把条目按键名放进三家外壳 | `capability.tool-execution-runtime` v2（逆转写，登记消费本契约 S-6）；`capability.model-request-runtime` v2 的传输适配（只做键名映射，**不做**逆转写） | **已对齐**：`capability.tool-execution-runtime/v2#S-23` ② 第 6 条（逆转写在起执行者之前，登记消费本契约 S-6）；`capability.model-request-runtime/v2#S-51` 末段与 S-38 第 11 条（传输适配不做逆转写）。M8 之后工具执行运行时查注册表改用 `call.tool` 原样，逆转写的位置不变（丙在修复波 2 落） |
| **系统里流转的工具指认用模型面名字 `ModelToolName`**（[S-6](v2/contract.md#s-6-模型面只有一个条目)） | `data.loop-extension` v2 的 `ModelRequest.tools` 与 `ToolDefinitionRef.name`；`capability.model-request-runtime` v2 S-7 的 `tools`；`capability.tool-admission` v2 S-7 的 `definition`（比较在模型面名字上做、S-18 逐码点不变）；`capability.asset-registry` v2 `tool` 类条目的查找键（S-25 ④）与 `effectivePermissions` 的键（S-11）；`data.content-blocks` v2 调用块的 `tool` | **已对齐**：loop-extension S-14／S-15、model-request-runtime S-7、tool-admission S-7。**修复波 2 同轮落**（[D-060 §七 M8](../../../record/decisions/mainline-self-rulings-2026-09/decision.md#七s25-第二轮独立复评之后的主线裁定m1m292026-09-25-追加)）：asset-registry 的两个键（丁）；调用块的 `tool`——落点是 `data.content-blocks` 的 G-9（L12 登、M8 关），那份契约本就被本契约依赖，`$ref` 会成环，按 [registry「互引成环的登记口径」](../../../registry/README.md#covers) 逐字同写、以本契约 `$defs/ModelToolName` 为家（甲）。**本契约改 `ModelToolName` 时须回头同步那一份** |
| **PF-006 §5.3「多命令工具的定义里带多少」那张表**：「带全部命令的完整参数 → 一次到位、不必多一趟」与产品负责人 2026-09-24 的 flat 裁定不再一致——模型面不展示任何命令的参数（[S-7](v2/contract.md#s-7-多命令-input-的生成规则) 第 1 条），两种写法的模型面相同 | 产品正文 PF-006（主线另做产品修订） | **已闭合（2026-09-24）**：PF-006 rev 19 §5.3 整节重写为「模型面前只有紧凑的命令清单一种样子」，「一次到位」那一端作废，与本契约一致 |
| **MCP 条目名要合 `name` 的收窄**（字符集、三种相邻、转写后 ≤ 128），不合即拼不出；对端参数 schema 过不了三条硬要求的，先由桥最小规范化，仍不合才投不成条目 | `data.mcp-endpoint` v2 S-11、S-26（接入点 name 登记时收窄）、`capability.mcp-bridge` v2 S-17 | **已落（2026-09-24，主线裁定）**：桥的 G-18 与接入点的 G-11 关闭 |

## 独立评审

| 项 | 值 |
|---|---|
| reviewer | spec-reviewer（只读） |
| 日期 | 2026-09-24 |
| 基线 | HUB `765b01dc`（批 R2a：本契约与 loop-extension、skill-package、slash-command、mcp-endpoint、connector） |
| 处置 | 2026-09-24 修复波 1，候选期内原地改；主线在修复简报里对跨契约的几处作了裁定（下表「主线处置裁定」，已收进 [D-060 §五](../../../record/decisions/mainline-self-rulings-2026-09/decision.md#五s25-第一轮修复波的主线裁定k1k502026-09-24-夜追加)，K1～K50） |

| 发现 | 处置 | 落点 |
|---|---|---|
| X-1 产品依据 rev 落后（PF-002 16→20、PF-007 16→18、PF-009 7→8、PF-012 10→14） | **改**。逐 rev 复核：PF-002 rev 17「谁可以使用它」八类共用 ⇒ [S-31](v2/contract.md#s-31-属性项的推出规则) 第 3 条补「不产出 `usableBy`」并登记消费 `data.asset-model` S-36；rev 18（组织层不持凭据）、rev 19（Skill 两项设置删除）、rev 20（连接件、D-5）与本契约无关。PF-007 rev 17 §5.6 加「放行判断不可用时全拒件」——[S-15](v2/contract.md#s-15-执行权限) 只引三档，不变；§4 多命令措辞与 PF-006 rev 19 对齐，与 S-7/S-8 一致（T-5 同轮收紧）；rev 18（问询出口）无关。PF-009 rev 8（系统消息不落日志）、PF-012 rev 11～14（回复否决、不可用处置、转换件不是资产）与 S-20、S-23 所引无关 | 抬头 |
| X-2 `category_unknown`／`origin_unknown` 与 `data.asset-model` 同名不同义 | **改**（主线处置裁定：改为 `setting_category_unknown`、`tool_origin_unknown`；技能包同一错误报同一值） | [S-10](v2/contract.md#s-10-设置项声明)、[S-17](v2/contract.md#s-17-来源)、[S-26](v2/contract.md#s-26-表示层拒绝值与判定次序)（加一段说明）；Schema 两处说明；`examples.md` 第 5 节两行 |
| X-6 依据只在任务区账本 | **改**：S5-b～f、A3 改链 D-060；产品负责人的 U-24-1／U-24-2 链 D-059；「`ToolSource` 改名」D-060 无此项，改写为本契约的命名选择（理由在 S-17）；「未知键一律拒」「模型面不改写」D-060 未收录，保留「主线裁定 2026-09-24」并报主线补登。**第二轮改链**（XB-1）：D-060 §六 N-1 已登这几项，设计依据表改链 N-1 | 设计依据表、S-4、S-5、S-6、S-7、S-17、S-18、S-26、S-31、G-1、G-3、G-4、G-7 |
| X-8(a) 正文 `name` 与 `capability.name` 相等由 asset-model S-10 定，却没登 | **改**：抬头依赖表与 catalog 补 `data.asset-model` S-10 | 抬头；`registry/catalog.json` |
| T-1 Schema 说明与 S-5 冲突；`$comment` 写 M1～M23 | **改** | Schema `CommandDefinition.description`、根 `$comment` |
| T-2 S-4 第 2、3 条的子 schema 位置集合不同；两条同时违反时报法不定 | **改**：「schema 的位置」写成一份封闭清单，第 2、3 条共用；清单外关键字下面不走（由 M27 报那个关键字）；同时违反报 `parameter_description_missing` | [S-4](v2/contract.md#s-4-单函数工具) |
| T-3 S-24 第 3 条「投不出时是任意」数据层无判据 | **改**（主线处置裁定：`origin.kind = mcp` 的定义不按结果端模态判，与 `capability.mcp-bridge/v2#S-17` 一致；取代 D-060 S19-e 的写法） | [S-24](v2/contract.md#s-24-结果与声明对得上) 第 3 条、设计依据表、G-8 |
| T-4 catalog 登 content-blocks 十条含 S-1，抬头写九条 | **改**：抬头补 S-1（`ToolResult` 的块取自那七类） | 抬头 |
| T-5 `args` 固定说明提「本工具自带的 help 命令」，与 S-8「help 是文本字段」冲突 | **改**：固定说明只写 `Tools().inspect` | [S-7](v2/contract.md#s-7-多命令-input-的生成规则) 固定文本；`examples.md` 第 2、9、11 节六处 |
| L-3（批内，loop-extension）MCP 来源没有能力标识，`tools` 表达不了 | **本契约一侧改**（主线处置裁定：流转的工具指认用模型面名字）：新 `$defs/ModelToolName`（21 项），`ModelToolEntry.name` 引它；S-6 写明逆转写只在工具执行运行时起执行者之前做、传输适配不做 | [S-6](v2/contract.md#s-6-模型面只有一个条目)、第七节、五（定义项）；Schema；[对齐义务](#对齐义务) |

### 第二轮

| 项 | 值 |
|---|---|
| reviewer | spec-reviewer（只读），发现表 `tmp/assets-runtimes/reviews/r2-R2a.md` |
| 日期 | 2026-09-25 |
| 基线 | HUB `8ad37c50`（批 R2a） |
| 处置 | 修复波 2，候选期内原地改；主线裁定见 [D-060 §七](../../../record/decisions/mainline-self-rulings-2026-09/decision.md#七s25-第二轮独立复评之后的主线裁定m1m292026-09-25-追加)（M1～M29） |

| 编号 | 发现 | 处置 | 落点 |
|---|---|---|---|
| XB-1（本契约那一行） | 设计依据表「未知键一律拒」仍写「D-060 未收录」 | **改**：改链 [D-060 §六 N-1](../../../record/decisions/mainline-self-rulings-2026-09/decision.md#六修复波-1b-的主线裁定与接受的命名2026-09-25追加)；第一轮 X-6 那一行补注 | 设计依据表；上表 X-6 行 |
| TD-a | S-7 第 3 条「作者声明的 `help` 命令」有两种读法 | **改**：写成「作者写的 `help` 文本」，与 S-8 一致 | [S-7](v2/contract.md#s-7-多命令-input-的生成规则) 第 3 条 |
| TD-b | 对齐义务两行仍写「待 R4a／R5 落」；调用块 `tool` 的落点是 content-blocks G-9；V-1 写 116 处、本地自检写 122 处 | **改**：两行改为已对齐并指到落点条款；调用块那一项指 `data.content-blocks` G-9（M8 关，互引成环按 M2 口径逐字同写、以本契约为家）；V-1 改 122 处 | [对齐义务](#对齐义务)；V-1 |
| （M8 跨批同一句） | 「模型面名字」全链只指 `ModelToolName` | **改**：S-6 流转清单补会话资产注册表的查找键与 `effectivePermissions` 的键、工具执行运行时以 `call.tool` 原样查注册表；消费者 `$ref` 一句补「互引成环的按 M2 口径逐字同写」 | [S-6](v2/contract.md#s-6-模型面只有一个条目) |

## 实际执行

**没有任何一次运行覆盖本契约。**本契约不建形式工件（理由见[包入口](README.md#版本包)），因此也没有登记任何 formal task。
**catalog 登记（2026-09-23，`candidate`）不产生任何证据**，它只是把坐标与资源放进采用面。

## 变化的影响

- **`data.content-blocks` v2 尚未定型**（2026-09-23 起草时记）。本契约 `$ref` 它的 `ContentBlock`、`AttachmentRef`、`CapabilityId`、`Modality`、`MediaType`，
  正文引用它的 `ExecutionOutcome`、「工具结果块里不得含工具调用块」（`call_in_result`）与「块的模态由媒体类型决定」两条规则。
  **它定型时要做的事**：
  ① 核对这五个 `$defs` 名仍在、形状与本包实例的写法一致（`id`、`kind`、`visibility`、`text`；`storage`、`key`、`mediaType`、`bytes`、`name`；`category`、`name`）——
  不一致则改本包 `examples.md` 第 3、7、8 节与 Schema 的引用，**Schema 若要改就要重跑 V-1**；
  ② 把 catalog 里这条依赖的 `clauses` 从 `$defs` 名与规则名换成那份契约的 `S-n`，把契约正文里的纯文本指称换成带坐标的链接；
  ③ 核对它给语音、图块定的「内联字节」写法——本包 `Offload.raw` 的内联形式照它写了一份（成员名 `inline`、base64），**两处应收成一份定义**（已报主线）；
  ④ 核对它的 `TextBlock.text` 是否允许空串——裸字符串 `""` 按 [S-20](v2/contract.md#s-20-两种写法与等价规则) 等价于一个 `text` 为空的文本块。
  **在它定型并与本包对齐之前，本包的 V-1 无法运行**，设计检查器在本包所在的检出里也会把这些引用报成未解析。
- **主线 2026-09-23 裁定，候选期内原地改**（起草后同日）：
  ① **G-3 改判**：[S-7](v2/contract.md#s-7-多命令-input-的生成规则) 改为每个命令一支的顶层 `oneOf`（支里带命令的 `description`），`examples.md` 第 2、9 节重写，V-2 重做、V-9 改写；G-3 关闭。
  ② **`$defs/JsonSchema` 不再 `$ref` 官方元 schema**，改为 `{"type": "object"}`；参数 schema 的合法性改由实现校验，[S-4](v2/contract.md#s-4-单函数工具)、[S-26](v2/contract.md#s-26-表示层拒绝值与判定次序) 写明表示层校验是 Schema 加 Schema 之外那一步。
  **后果**：布尔 schema 从此被拒（`input_not_schema`）；`examples.md` 第 5 节的 `{"type": 5}` 与 `{"required": "id"}` 两行改为「Schema 通过、表示层拒绝」；检查器不再报这一处未解析。
  ③ **`malformed` 的来由逐条列为 M1～M23**（[S-26](v2/contract.md#s-26-表示层拒绝值与判定次序)），不增专名；`examples.md` 第 5、8 节注明 M 编号，第 8 节补四条反例。
  ④ **G-7 裁定为拒**：有阈值而无后台许可即 `malformed`（M15），Schema 在两个范式上各加一条 if/then；[S-12](v2/contract.md#s-12-后台许可与转后台阈值)、P-5、V-7 随之改写。
  ⑤ **G-4 关闭**：`help` 是文本字段，「help 命令空间」由 `Tools().inspect` 呈现（[S-8](v2/contract.md#s-8-说明与用法)），CS-6、V-3、V-11 随之改写。
  ⑥ **Q5／Q6／Q7 的依据改指 D-058**（`record/decisions/message-and-shape-rulings/`，本检出尚无此目录；合入后在契约的设计依据表补链接）。
  **对消费者**：没有已采用的消费者，无迁移。凡依赖原 S-7 形状、或依赖「阈值无许可也收下」的草稿，按新条款重读。
- **2026-09-24 整批对齐（候选，未冻结，原地改）**：

  | 改了什么 | 依据 | 条款 | Schema | 实例 |
  |---|---|---|---|---|
  | 依赖改为逐项坐标：`data.content-blocks` 九条、新增 `data.asset-model` 四条 | 两份契约已在同一棵树 | 抬头 | — | — |
  | `SettingCategory` 删掉本地定义，`$ref` `data.asset-model` 的；新增 [S-31](v2/contract.md#s-31-属性项的推出规则) 推出规则，`SettingDeclaration` 写明是 `AttributeDeclaration` 在定义里的写法（**未照简报字面改成 `$ref AttributeDeclaration`，已报主线**） | `data.asset-model` 对齐义务；简报 §B asset-model 行 | S-10、S-31、S-26 前的定义项 | `SettingDeclaration.category`；删 `SettingCategory` | 第 6 节表头 |
  | `ToolOrigin` 改名 `ToolSource`（成员名 `origin` 不变） | 简报 §B asset-model 行 | S-17、定义项 | 三处 | — |
  | `name` 就是能力标识的 `name`、词法从 `data.asset-model/v2#S-2`，不是第二身份 | 同上 | S-2 | — | — |
  | 内联原始结果的 `inline` `$ref` `data.content-blocks` 的 `InlineBytes`（原第 ③ 项闭合） | 简报 §A | S-23 | `Offload` | — |
  | 命令 `input` 里禁止根相对 `$ref` 与 `$id`（M24）；G-12 那一项关闭 | 账本 S5-f | S-7、S-26 | —（Schema 之外那一步） | 第 5 节加两行 |
  | MCP 条目两端模态按桥的投影判，投不出即「任意」；G-8 关闭 | 账本 S19-e | S-17、S-24 | — | — |
  | D-058 依据补成链接 | D-058 已合入 | 设计依据 | — | — |
  | 「不拥有」与消费者表里「尚未建立」的指路改成已有候选的坐标（工具执行运行时、放行判断、资产三份、MCP 桥）；S-15 的 MCP 默认值指到桥 S-17 | 那几份候选已在同一棵树；不改语义 | 概述、S-15 | — | — |

  **本地自检**（Draft 2020-12，`jsonschema` 按仓库 `uv.lock`，脚本在任务暂存区、不入库）：以对齐后整棵设计树的全部 Schema 建 registry，
  第 1～4、7 节的 JSON 块、第 5 节的改写行（按「B／第 2 节的例子／第 3 节的例子／上一行」改一处还原成实例）、第 6、8 节的表逐条求值：**92 处（预期通过 31、拒绝 61），0 处不符**。
  标「Schema 通过 · 表示层拒绝」的四行按 Schema 通过计；它们被拒的那一步（合法 schema、M24）不在机检内。第 9、10 节不参与。

- **2026-09-24 产品负责人要求：工具定义必须能直接构造出各家模型供应商要求的工具 payload**（依据：研究 `tool-definition-shape-sources` 的 V-1～V-4；候选，未冻结，原地改）：

  | 改了什么 | 条款 | Schema | 实例 |
  |---|---|---|---|
  | 模型面条目定形 `ModelToolEntry = { name, description, parameters }`，`name` 是转写后的名字；三家线上形状只差键名与外壳，投影是纯键名映射、不改写 schema；这一句进第七节 | S-6、第七节、P-15、CS-2、十一 | 新 `$defs/ModelToolEntry`（19 项） | 新第 11 节 |
  | `name` 的字符集 `[A-Za-z0-9_:-]`、不含 `__`／`_:`／`:_`（新拒绝值 `name_reserved_sequence`）、转写后 ≤ 128（M25）；**多禁 `_:`、`:_` 两种相邻是规格层推导**：只禁 `__` 时 `a_:b` 与 `a:_b` 转写成同一个名字，逆转写不唯一（已报主线）；G-1 收窄 | S-18、S-26、G-1 | `name` 加 `pattern`、`maxLength` | 第 5 节加四行 |
  | 参数 schema 三条硬要求：顶层 `type: "object"` 带 `properties`（M26）；任何一处 `properties` 的成员带非空说明（新拒绝值 `parameter_description_missing`，排在 `input_not_schema` 之后）；只用十七个关键字（M27，任何 `$ref` 都不在其中）；G-12 收窄 | S-4、S-5、S-26、G-12 | `JsonSchema` 要求顶层 `type` 与 `properties` | 全部定义补参数说明；B 改为带空 `properties`；第 5 节加七行、改五行 |
  | 多命令生成规则：顶层加空 `properties`（为第 1 条硬要求，推导）；`command` 带固定说明「要执行的命令；本支只接受 "n"」、`args` 顶层 `description` 置为命令的说明（主线裁定 2026-09-24，待产品负责人确认）；「只带命令清单」的写法改为 `{"type": "object", "properties": {}}` | S-5、S-7 | `CommandDefinition` 的说明 | 第 2、9 节重写 |
  | 表示层拒绝值由十个变为十二个，`malformed` 的来由到 M27 | S-26 | — | — |

  **对消费者**：没有已采用的消费者，无迁移。**表示改变**：不带参数说明、顶层不带 `properties`、用了子集外关键字、名字带 `.` 或 `__` 的定义从收到拒——**MCP 对端的参数 schema 常见这几样**（`$schema`、`title`、参数无说明），这些动作从此投不成条目，后果已报主线。
  **证据**：V-1 本地自检重跑，116 处 0 不符（[本地自检](#本地自检schema-正反实例整批对齐2026-09-24)）；V-2 重对。

- **2026-09-24 产品负责人裁定：多命令工具的模型面只支持 flat 形，不生成 `oneOf` 判别联合**（依据：产品负责人裁定 2026-09-24；D-058 Q5「一份 schema 带判别字段」的 flat 读法；对照 omne-next `multi_command.py` 默认 `dispatch_mode="flat"`，研究 O-2；候选，未冻结，原地改；**取代上一条里 S-7 那一行**）：

  | 改了什么 | 条款 | Schema | 实例 |
  |---|---|---|---|
  | `generateMultiInput` 改为 flat 形：`command` 是按码点升序的命令名 `enum`、说明是定死格式的命令表（每行 `n — 命令说明`）；`args` 只是 `{"type": "object", "description": 固定一句}`、**不带 `properties`**；`required` 只有 `command`；`args` 缺席等价于 `{}`；判定仍以 `commands[c].input` 为准；M24 保留（理由改为判定时的解析基准） | S-7、设计依据表、抬头两处 | `CommandDefinition`、`help` 的说明改写 | 第 2 节生成结果重写；第 5 节两行依据改写；第 9 节按五条重做、调用表改为两列判定；第 10 节两行；第 11 节加三命令工具的条目与三家形状 |
  | 两种写法（只带命令清单／带全部参数）的模型面相同，带多少只改变判定与 `inspect`／`help` 的细度 | S-5、S-8、S-18 | — | 第 9 节末段 |
  | CS-1 不再说「过 `modelInput` 与之等价」：模型面只保证命令名对、`args` 是对象 | CS-1、第七节 | — | — |
  | G-3 关闭的说明改写；G-12 删去 `oneOf` 呈现质量与「扁平改判留作 v2」那一项（已按 flat 落定） | G-3、G-12 | — | — |

  **对消费者**：没有已采用的消费者，无迁移。**语义改变**：过了模型面不再意味着参数合格——执行运行时必须按 `commands[c].input` 判（原先的 `oneOf` 形下两者等价）；装配与传输适配收到的多命令条目不再含任何命令的参数 schema。
  **与产品正文**：PF-006 §5.3 那张表「带全部命令的完整参数 → 一次到位」一格与本裁定不再一致，记在[对齐义务](#对齐义务)。
  **证据**：V-1 本地自检重跑并加了生成与投影重算，122 处 0 不符（[本地自检](#本地自检schema-正反实例整批对齐2026-09-24)）；V-2 重对；V-9 改写。

- **（同日续）flat 形的实测依据**：S-7 的理由段补「实测见研究 V-5」（四家真实请求都接受 flat 形；有 `Tools().inspect` 时先查用法再调用，没有时会猜参数名）。执行运行时据此在起执行者之前按 `commands[c].input` 校验、不合带用法落 `failed`——登在 `capability.tool-execution-runtime` 的对齐义务，本契约条款不变。
- **（同日续）`name` 的三条抽成 `$defs/ToolName`（20 项）**：两个范式的 `name` 改为 `$ref` 它，`data.mcp-endpoint` 的动作条目名 `McpActionName` 也 `$ref` 它——条目名就是那份工具定义的 `name`，收窄只有一个家（[S-18](v2/contract.md#s-18-名字的表示与相等)）。语义与取值不变；本地自检重跑，0 处不符。

- **2026-09-24 按 PF-006 rev 19 修订（修订批第五节；候选，未冻结，原地改）**：

  | 改了什么 | 依据 | 条款 | Schema | 实例 |
  |---|---|---|---|---|
  | 产品依据由 PF-006 rev 17 升到 rev 19；设计依据表加「说明必填」一行（新锚点）、「前台上限与并发上限」一行、MCP 最小规范化一行；flat 那一行补产品正文坐标 | PF-006 rev 18/19 | 抬头、设计依据 | — | — |
  | 核对 §5.3 措辞：「只带命令清单」时参数对不对由工具自己判、`inspect` 答得出的只有命令清单；说明必填与命令那一行说明必填挂上产品正文链接 | PF-006 rev 19 §5.3 | S-4 第 2 条、S-5、S-7、S-8 | — | 第 9 节两处措辞；`remove` 改为与调用表一致的 `delete` |
  | 超时即前台上限、并发即并发上限，语义由 PF-006 §6.6 给、执行运行时兑现；**G-6 关闭**；S-12 的触发源写上「前台上限到了」与「发起时就在后台」同样不绕开许可 | PF-006 rev 18 §6.6「前台上限与并发上限」与触发源表 | S-12、S-13、S-14、九、G-6 | — | — |
  | MCP 来源定义的说明与参数 schema 由桥最小规范化，本契约照常校验、不因来源放宽 | 主线裁定 2026-09-24（桥 G-18） | S-17、CS-5、Schema 管得到什么、十一 | — | 第 3 节说明、第 5 节 `$schema` 那一行 |
  | 第七节「一次 run 之内」改为「一次执行尝试之内」 | PF-006 rev 18 §6.13 | 第七节 | — | — |

  **对消费者**：没有已采用的消费者，无迁移。**语义不变**：形状、拒绝值、生成规则与判定次序一处没动；G-6 关闭只是把原先「未定」的两项语义指到产品正文与执行运行时。
  **证据**：Schema 与实例的 JSON 块未改，V-1、V-2 的本地自检结果仍适用于本轮；第 9 节只改了散文。
- **2026-09-24 主线对修订批报回项的裁定（候选，未冻结，原地改）**：
  **未知键一律拒**（主线裁定 2026-09-24，依据研究 V-5 结论 ③）——判参数时 `input` 顶层没写 `additionalProperties` 按 `false` 读，作者显式写 `true` 或一份 schema 才收未知键；
  [S-5](v2/contract.md#s-5-多命令工具) 加末条、「只带命令清单」的写法改为 `{"type": "object", "properties": {}, "additionalProperties": true}`，[S-7](v2/contract.md#s-7-多命令-input-的生成规则) 第 3 条补一句指过去；
  「只管顶层、嵌套对象按原义读」是本契约的推导（已报主线）。`examples.md` 第 9 节末段改写并加一张三行判定表。
  **对消费者**：没有已采用的消费者，无迁移。**语义改变**：只写 `{"type": "object", "properties": {}}` 的命令从「收任何对象」变为「不收任何参数键」；执行运行时的 `arguments_invalid` 按这条判（`capability.tool-execution-runtime/v2#S-11`）。
  **证据**：Schema 与生成规则不变（模型面逐字不变），V-1、V-2 的本地自检结果仍适用；第 9 节的调用表属对读，未机检。
  **（同日第二轮，主线裁定）**单函数工具的模型面保持 [S-6](v2/contract.md#s-6-模型面只有一个条目) 原样、不自动补 `additionalProperties: false`；S-5 末条补一句「模型面允许而运行时拒的键会以用法文本告知」。语义与表示不变。
- **2026-09-24 第一轮独立评审的处置（修复波 1；候选，未冻结，原地改）**：逐条见[独立评审](#独立评审)。
  **表示改变**：两个拒绝值改名（`category_unknown` → `setting_category_unknown`、`origin_unknown` → `tool_origin_unknown`）；多命令模型面 `args` 的固定说明改为「所选命令的参数；各命令的参数用法经 Tools().inspect 取得」——**生成出的 `modelInput` 逐字变了**，两个实现须同时换；新 `$defs/ModelToolName`。
  **语义改变**：MCP 来源的定义不再「按桥的投影判」结果端模态，而是一律不判（第 1 条附件仍判）；逆转写只在工具执行运行时做。**语义收紧、不改结论**：S-4 的位置清单封闭（原两条列法不同，按任一读法判得出的值在清单内一致）。
  **对消费者**：没有已采用的消费者，无迁移；`data.loop-extension` 同轮改引 `ModelToolName`，model-request-runtime、tool-admission、tool-execution-runtime 由 R4a／R5 同轮改（[对齐义务](#对齐义务)）。
  **证据**（本轮机检，Draft 2020-12，`jsonschema` 4.26.0 按仓库 `uv.lock`，脚本在任务暂存区、不入库）：`examples.md` 带「校验对象」的 13 个 JSON 块逐个求值，0 处不符；由第 2 节 `commands` 按 S-7 重算 flat 形与第 2 节那份 JSON 值相等（新固定说明），第 11 节两个 `notes` 条目的 `parameters` 与之相等；第 5 节新增三行 Schema 通过、按 S-4 位置清单算出的拒绝值与第三列一致；`ModelToolName` 收 `issue-tracker__search_issues`、`notes`，拒 `a:b` 与 129 个字符。
  **未重跑**：第 5、6、8 节其余表行的改写还原（上一轮 122 处 0 不符；本轮这些行只改了两个拒绝值的名字）；M 编号仍不机检。
- **任一已知缺口被裁决**而改变语义或表示：候选期内原地改并在此记一行；**接受之后出 v2**，本版证据只保留原范围。
- **跨进程演化启动**：[第七节](v2/contract.md#七装配给与协议给)标「须由协议兑现」的三行（同一份定义、`help` 读同一版本、每个边界重新校验）从装配给转为协议给；本版证据只保留其单机范围。
- **2026-09-24 同日稍后（不改语义）**：K 裁定收进 [D-060 §五](../../../record/decisions/mainline-self-rulings-2026-09/decision.md#五s25-第一轮修复波的主线裁定k1k502026-09-24-夜追加) 之后，正文里标「第一轮独立评审的处置」的四处改链 D-060 §五（K6、K10、K11）。

- **2026-09-24 修复波 1b（主线裁定 [D-060 §六 L10](../../../record/decisions/mainline-self-rulings-2026-09/decision.md#六修复波-1b-的主线裁定与接受的命名2026-09-25追加)；候选未冻结，原地改）**：[S-6](v2/contract.md#s-6-模型面只有一个条目) 替换件那一条补一句——本契约只定替换件的形状；**一条目此刻是不是替换件、为什么是，由会话资产注册表判**（`capability.asset-registry` v2 S-8、S-10），**替换件怎么造归执行运行时**。两处是指路，不登 catalog 依赖（那份契约消费本契约 S-6，反向登记会成环）。
  L1 与本包无关：本契约不链接 `data.content-blocks` 的 S-8（已全树核过）。**语义与表示都不变**，Schema 与实例未改，V-1 不重跑。
- **2026-09-25 第二轮独立评审的处置（修复波 2；候选未冻结，原地改）**：逐条见[第二轮](#第二轮)。
  **（修复波 3 另起一节，见[实现映射反推](#实现映射反推2026-09-25)。）**
  **语义与表示都不变**：S-7 一处措辞（`help` 文本）、S-6 把 M8 已裁的两个消费者列进「流转的工具指认」清单（本契约的承诺本来就覆盖它们）、依据改链、对齐现状更新。Schema 与实例未改，V-1 不重跑。**对消费者**：无迁移。

- **2026-09-25 修复波 3（实现映射反推；候选未冻结，原地改）**：见下节。**语义改变**：表示层拒绝值十二个 → 十三个（`schema_unsupported`，排在最后）；参数 schema 在判参数时 `format` 只作注解。**表示改变**：Schema 只改一处说明文字，约束不变。
- **2026-09-25 修复波 3 跨批对齐（drafter 丑；候选未冻结，原地改）**：落 D-060 §八 N-22 T-16，见[下节末](#跨批对齐追加2026-09-25drafter-丑)。**语义改变**：判一次调用超出判定时限与编不出同一收场（执行运行时的 `failed{schema_unsupported}`）；G-15 关闭；G-16 多一样上限（判定时限）。**表示改变**：无，Schema 与拒绝值集合都不变。

结果不改写规范。发现语义问题回到来源设计（PF-006／PF-002／PF-005），不在这里改契约。

## 实现映射反推（2026-09-25）

起因：realization-drafter 戊起草 `core/tool-definition` 节点时报回 TM-2、TM-3；主线裁定见 [D-060 §八 M37](../../../record/decisions/mainline-self-rulings-2026-09/decision.md#八实现映射起草反推出的契约修订m31m442026-09-25-追加)。**裁定不代替接受**，本契约仍是 candidate。

| 裁定 | 落点 | 本契约推导的部分（已报主线） |
|---|---|---|
| **M37** `format` 只作注解不作断言 | [S-4](v2/contract.md#s-4-单函数工具) 末段第一条；Schema 那一行（`format` 是判参数一方的读法）；`JsonSchema` 的 Schema 说明；examples §5 末段、§10 一行 | 「要约束形状写 `pattern`」一句是说明，不是新规则 |
| **M37** 作者或远端 schema 编译不了、或 `pattern` 超出实现上限 ⇒ 新拒绝值 `schema_unsupported`（本契约 S-4 收） | [S-4](v2/contract.md#s-4-单函数工具) 末段第二条；[S-26](v2/contract.md#s-26-表示层拒绝值与判定次序) 十二 → 十三、**第 13 行**、表示层校验一句、「两个实现同一个值」的例外；第二节「三类东西」一行；第七节加一行；**新 [G-16](v2/contract.md#十已知缺口)**；examples §5 三行 | ① **排在最后（第 13 行）**：只有前面每一步都过了的 schema 才去编；与 `input_not_schema` 分开——那是不合 Draft 2020-12，这是合法却编不出；② **上限不在本契约里定**，两样（长度、回溯保护）写成由提供者设计登记，值与「哪些构造算超出」挂 G-16；③ 因此 S-26「两个实现同一个值」对第 13 行不成立，写成具名例外；④ 编不出来**不得**退成「不判参数」 |
| **M37** MCP 动作条目据此 `stand_in{for: schema_unsupported}` | [S-27](v2/contract.md#s-27-表示层拒绝不是判定) 末段（唯一形状合法的拒绝，给 MCP 来源开的口子；作者写的工具仍照 S-27 前文、收场归 G-15）；P-12 那一行；`data.mcp-endpoint` S-10 同步（同批由癸落） | 口子只开给 MCP 来源：M37 只说 MCP 动作条目；作者写的工具遇到它怎样收场仍归 G-15，不推 |

**对证据的影响**：V-1 的本地自检不覆盖第 5 节新加的两行 `schema_unsupported`——它们依赖实现登记的上限（G-16），通用校验器给不出；`input_not_schema` 那一行（`"^("`）在下一次自检时一并跑。新义务 **V-12**（判参数时 `format` 不据以拒绝；编不出来的 schema 不被当作「不判」）归执行运行时的场景，未开始。

**对消费者**：
- `capability.tool-execution-runtime`：判参数时照 `format` 只作注解；作者写的工具的 `schema_unsupported` 怎样收场仍是本契约的 G-15——**同批由子一侧对齐，本轮未读到落稿**。
- `capability.mcp-bridge` S-17 `projectActions`：远端参数 schema 过了前十二行、却 `schema_unsupported` 的动作要打「只能以替换件出现」的标记、原因写 `schema_unsupported`——**本轮没有 drafter 负责那份契约，已报主线**。
- `capability.asset-registry`：`stand_in{for}` 的原因原样取桥给的（它的 S-12 第一行），不必改。

**registry**：catalog 本契约的依赖不变（没有新消费的条款）；`data.mcp-endpoint` → 本契约的 clauses 补 `S-4`、`S-27`（那份契约 S-10 据以写 `schema_unsupported`）；covers、formal-tasks、id-namespaces 不变。

### 跨批对齐追加（2026-09-25，drafter 丑）

| 裁定 | 落点 | 本契约推导的部分（已报主线） |
|---|---|---|
| **[D-060 §八 N-22](../../../record/decisions/mainline-self-rulings-2026-09/decision.md#八实现映射起草反推出的契约修订m31m442026-09-25-追加) T-16** 参数判定编不出或超出上限（含判定超时）⇒ 那一项 `failed{schema_unsupported}`，带说明、不牵连同批；作者写的工具碰上 `schema_unsupported` 同此收场，本契约 G-15 据此关闭 | [S-4](v2/contract.md#s-4-单函数工具) 末段加第三条（判定超时同一收场、不是定义的表示层拒绝）；[S-26](v2/contract.md#s-26-表示层拒绝值与判定次序) 第 13 行加一句指向执行运行时 S-23 ④；[S-27](v2/contract.md#s-27-表示层拒绝不是判定) 两处（返回值被拒的收场、作者写的工具碰上它）；[S-24](v2/contract.md#s-24-结果与声明对得上) 末句；**[G-15](v2/contract.md#十已知缺口) 关闭**；[G-16](v2/contract.md#十已知缺口) 加「判定时限」；examples §10 加一行 | ① **判定时限是 G-16 的第三样上限**：T-16 说「含判定超时」，时限的值总要有人登记，与另两样同一个 owner；② **超时不是定义的表示层拒绝**：S-26 第 13 行只管编不编得出与上限，定义照收，判那一次调用时才收场；③ **G-15 三处都有了答案才关**：返回值被拒与违反声明由执行运行时 S-41 的 `failed{result_rejected}` 早已落地（那份契约自称「替它的 G-15 落地」），定义被拒经资产治理写面在写草稿时就挡下，剩下的只有 `schema_unsupported`（T-16）；**工作区提供的定义**怎样解析、在哪判，是 `capability.asset-evaluation` 的 G-6，不算本条未闭合 |

**对消费者**：`capability.tool-execution-runtime` 同批改（S-11 九个种类、S-23 ④⑤，丑落）；`capability.mcp-bridge` S-17 已按 M37 跟进（丑落，上节「已报主线」那一条就此办完）。
**registry**：`capability.tool-execution-runtime` → 本契约的 clauses 补 `S-26`；本契约的依赖不变（引执行运行时 S-23、S-41 是落点指路，data 契约不登对 capability 的依赖）。
**对证据的影响**：新行在 §10（不参与机检）；本轮暂存区机检（`jsonschema` 4.26.0）覆盖 examples 第 1～8、11 节的实例与由 B／第 2、3 节派生的反例，**116 处 0 不符**（含第 5 节 `schema_unsupported` 两行的「Schema 通过」；第 13 行本身依实现上限，通用校验器给不出）。新义务并入 V-12（判定超时不照常执行、只落这一项），归执行运行时的场景，未开始。

## 2026-09-26 D-068 当前 v3

`data.tool-definition · v3` 已接受并冻结，[精确契约](v3/contract.md) 的接受范围与32资源摘要见 [D-068](../../../record/decisions/core-implementation-spec-reconciliation/acceptance.json)。本段为当前导航，此前旧版接受与验证记录保留原适用范围。新版推荐不自动升级消费者；八个core提供者须显式采用，24个外部消费者仍钉2。实现、公开旧Schema闭包及新组合证据尚待完成，不从规格接受推断通过。
