# capability.asset-transfer v2

- **契约坐标**：`(omne-harness-lite-design-2026-09-15, capability.asset-transfer, 2)`
- **状态**：已由 [D-061](../../../../record/decisions/assets-runtimes-contract-acceptance/decision.md) 接受；精确资源冻结与采用状态由版本外入口及 registry 维护。
- **设计依据**（PF-003 rev 5）：
  [§4 资产复制](../../../../product/PF-003-asset-transfer-and-sharing/design.md#资产复制)、
  [§4 分享](../../../../product/PF-003-asset-transfer-and-sharing/design.md#分享)、
  [§4 复制血缘](../../../../product/PF-003-asset-transfer-and-sharing/design.md#复制血缘)、
  [§5.1](../../../../product/PF-003-asset-transfer-and-sharing/design.md#51-两种需要两个动作)、
  [§5.2](../../../../product/PF-003-asset-transfer-and-sharing/design.md#52-边界是那棵隶属树不是单个组织)、
  [§6.1](../../../../product/PF-003-asset-transfer-and-sharing/design.md#61-一条不变量团队资产不出那棵树)～[§6.14](../../../../product/PF-003-asset-transfer-and-sharing/design.md#614-待确认的复制通知与分享邀请会过期)
  （**§6.3 的标题保留旧措辞、锚点不变，内容是两条通则**）；
  [flows §1.1](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#11-把个人组织里的东西复制给团队)～[§1.10](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#110-把我租户级的工具分享给同事)、
  [flows §二](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#二分支与异常)、
  [flows §3.1](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#31-一份复制来的资产在目标组织里)～[§3.4](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#34-一份待确认的邀约复制通知与分享邀请同形)、
  [flows §四](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#四角色与操作)；
  [acceptance](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md)；
  [decisions §一、§二](../../../../product/PF-003-asset-transfer-and-sharing/decisions.md#一拍板记录)
- **相邻依据**：PF-002 rev 20（下列小节在 rev 17～20 里含义未改：rev 17～19 在第二轮修订时按 changelog 核过，rev 20 于 2026-09-24 独立评审第一轮核过——它改的是连接件的事件目录与订阅、治理类设置与拓展件不可用处置，不碰下列小节）的
  [flows §1.1 给组织加一个资产](../../../../product/PF-002-assets-settings-and-permissions/flows.md#11-给组织加一个资产)、
  [flows §3.1](../../../../product/PF-002-assets-settings-and-permissions/flows.md#31-一个资产在某个范围里)、
  [flows §四](../../../../product/PF-002-assets-settings-and-permissions/flows.md#四角色与操作)、
  [§4 Plugin](../../../../product/PF-002-assets-settings-and-permissions/design.md#plugin)、
  [§6.3](../../../../product/PF-002-assets-settings-and-permissions/design.md#63-组合的引用指向能力标识)、
  [§6.4](../../../../product/PF-002-assets-settings-and-permissions/design.md#64-移除与禁用是两个动作)；
  PF-001 rev 19 的
  [§4 拥有、获权、选用](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#拥有获权选用)、
  [§6.6](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#66-撤销不等于强制停止)、
  [§6.7](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#67-创作与归属)、
  [§6.8](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#68-管理结果)、
  [退出之后再加入，回来的是同一个租户](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#退出之后再加入回来的是同一个租户)；
  [SYS-TENANT](../../../../foundation/cross-system-constraints/requirements.md#sys-tenant)、
  [SYS-DEPLOY](../../../../foundation/cross-system-constraints/requirements.md#sys-deploy)
- **精确语义依赖**（五项，消费 clauses 见 [S-4](#s-4-依赖方向与被消费的面)，catalog 按它登记）：
  - `omne-harness-lite-design-2026-09-15 · capability.organization-governance · v3`（candidate；**v2 是 v1 的加法版**：[S-9](#s-9-分享此刻是否生效) 的第三个合取项要读 v2 新增的两个时刻，所以**整体钉 v2**。本契约用到的条款里，`#S-22` 在 v2 多返回一项（隶属建立时刻）、多一种 `unavailable` 触发，其余与 v1 同义——逐条见[组织治理 v2 第十三节](../../organization-governance/v3/contract.md#十三版本差异与规范工件)；[S-4](#s-4-依赖方向与被消费的面) 按 v2 的写法消费）
  - `omne-harness-lite-design-2026-09-15 · data.identity-values · v1`
  - `omne-harness-lite-design-2026-09-15 · data.offer-expiry · v1`
  - `omne-harness-lite-design-2026-09-15 · data.asset-model · v2`（candidate）
  - `omne-harness-lite-design-2026-09-15 · capability.asset-governance · v2`（candidate；本契约组合它的写面与读面）
- **主线裁定**（不是产品依据；产品负责人追认或推翻由后续决定取代）：
  - 落地由同一提供者在同一次提交内完成——见 [D-060 §一 PA-3](../../../../record/decisions/mainline-self-rulings-2026-09/decision.md#块-a-拆分提案报回的推荐-bcore-纯模块--治理与流转一个插件)；
    组织型复制的作者是 (目标组织, 确认的那位超管)，已由 PF-003 §6.5 吸收——见 [D-060 §二 S-U24-3b](../../../../record/decisions/mainline-self-rulings-2026-09/decision.md#二2026-09-24-用户在场期间主线随用户裁决所作的自定账本-二-原文标主线自定的行)；
    不复活读 `capability.organization-governance` v3 的两个时刻（R2-2，原 G-11 闭合）、`data.identity-values` v1 的 CS-3 按「各自组织的租户身份分别署名、账号相同不构成本人型」读（R2-3）、
    分享方删除已分享出去的资产 ⇒ 那段分享 `revoked`、原因 `sourceDeleted`（R2-4，原 G-9 闭合）、本人型复制带尝试键、同键重放认回首次结果（R2-5，原 G-12 闭合）、
    组织型复制通知的目标侧投影带源组织、不带源资产本身（R2-6，原 G-13 闭合）、**提升不被分享挡住，提升那一刻分享方的全部 active 分享随之结束**、原因 `ownerChanged`（R2-7）、
    `targetLayerNotSelf`、`layerNotAllowed`、`recipientNotMember` 这几个名字（R2-8）——见 [D-060 §三](../../../../record/decisions/mainline-self-rulings-2026-09/decision.md#三2026-09-24-第二轮规格修订的主线裁定简报-r2-1r2-16-原文与-g-24g-25)；
  - 下列几条见 [D-060 §六 N-7](../../../../record/decisions/mainline-self-rulings-2026-09/decision.md#六修复波-1b-的主线裁定与接受的命名2026-09-25追加)（asset-transfer 那一段：T-1 失败名、T-2 发现面、S11 名、A-M21、A-M25；租户格 `organization` 依据与分享结束后的持有、删除即归档在同一行的 asset-governance 那一段），本契约按它们写：
    确认路径三种来路同收 `offerNoLongerValid`、撤回路径已终结同收 `alreadyConcluded`，与组织治理同名；
    接收方的发现面 `listPendingForOrganization`，本契约不发自己的事件、落地与持有变化由资产治理的事件承载；
    租户格以 `organization` 依据持有被分享给本组织的那一份；`unavailable`、`versionNotPublished` 与资产治理同名；
    分享结束后被分享方的持有保留、不可用；资产删除后已发布版本作不可解引用的归档保留
  - 独立评审第一轮的主线裁定——读两个时刻的调用主体是运行时代行（K37，[S-9](#s-9-分享此刻是否生效) ②、[S-34](#s-34-装配给的保证-vs-协议须给的保证)）；复制落地的 `byAgent` 由本契约 [S-11](#s-11-复制的收场) 的写集合给（K38）；分享结束不通知（K39，[S-33](#s-33-本版不发本契约自己的事件)）——见 [D-060 §五](../../../../record/decisions/mainline-self-rulings-2026-09/decision.md#五s25-第一轮修复波的主线裁定k1k502026-09-24-夜追加)
- **产品负责人 2026-09-24 当场裁定、PF-003 rev 5 已落正文**（[D-059 资产的复制与分享](../../../../record/decisions/assets-runtimes-split-and-rulings/decision.md#资产的复制与分享-pf-003-rev-5)）：方向矩阵与三条规则；**分享结束之后关系又接上，不复活**（[§6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)）；普通成员复制进团队只落自己的租户级、不需要超管确认，超管可选层
- **条款编号**：`S-n`，**只在本契约本版本内有效**，只追加不重排；外部引用写全坐标，如 `capability.asset-transfer/v2#S-22`。
  缺口编号 `G-n`，见[十一](#十一已知缺口)
- **三个对象有词条**：[复制通知](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-copy-notice--复制通知--copy-notice)、
  [分享邀请](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-sharing-invitation--分享邀请--sharing-invitation)、
  [分享关系](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-sharing-relationship--分享关系--sharing-relationship)——
  本文简称「分享」的那份记录就是一段分享关系确认之后（本人型：发起之后）的样子，待确认那一段是分享邀请；类型名 `CopyNotice`／`SharingInvitation`／`Sharing` 是本契约的规格层名字。
  **本人型、组织型、组织内分享不另立词条**：它们是两个动作的情形叫法，叫法与英文钉在
  [UL-asset-copy 注意 ⑤](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-asset-copy--资产复制--asset-copy)（the personal form / the organizational form）与
  [UL-asset-sharing 注意 ⑤](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-asset-sharing--资产分享--asset-sharing)（intra-organization sharing / the personal form）。
- **用到两个没有词条的技术名**：**隶属建立时刻**（`parentEstablishedAt`）、**成员关系生效时刻**（`membershipEffectiveSince`）——
  统一语言复核判为产品正文未述、不立词条，本文标「（无词条）」；工作定义在 [S-9](#s-9-分享此刻是否生效)，
  持有与读面在 `capability.organization-governance/v3#S-7`、`#S-8`，两份契约同名同义

---

## 一、含义与使用范围

### S-1 本契约拥有什么

本契约拥有**资产怎么在主体之间流动**这一件事的两个动作，以及它们共同守的那条边界：

| # | 拥有的事实与判定 | 正文 |
|---|---|---|
| 1 | **资产复制**的两条通则：**本人型**发起即落地（带尝试键时同键重放认回首次结果）；**组织型**产生一份[复制通知](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-copy-notice--复制通知--copy-notice)，确认那一刻落地。落地的首次、重复、撞标识无血缘 | [S-5](#s-5-复制通知)、[S-10](#s-10-复制血缘怎么判怎么记)、[S-11](#s-11-复制的收场)、[S-20](#s-20-发起复制)～[S-23](#s-23-读复制通知) |
| 2 | [分享邀请](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-sharing-invitation--分享邀请--sharing-invitation)的全生命周期——组织—组织、个人—个人、组织内分享三种要对方点头的 | [S-6](#s-6-分享邀请)、[S-24](#s-24-发起分享)～[S-27](#s-27-读分享邀请) |
| 3 | **分享**（[分享关系](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-sharing-relationship--分享关系--sharing-relationship)确认之后的那份记录）：确认之后（本人型：发起之后）那份获权记录、它**此刻是否生效**、结束的全部来路（含分享方删除资产、所有权易手）、**结束之后不复活** | [S-8](#s-8-分享)、[S-9](#s-9-分享此刻是否生效)、[S-28](#s-28-撤销分享)～[S-32](#s-32-成员关系解除复制执行不了已确认的不动)、[S-52](#s-52-分享方删除资产或所有权易手分享随之结束) |
| 4 | [复制血缘](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-copy-lineage--复制血缘--copy-lineage)**怎么判、何时产生、此后怎么记**——**在落进的那一层里找**（形状归 `data.asset-model` 的 `CopyLineage`） | [S-10](#s-10-复制血缘怎么判怎么记) |
| 5 | **方向与落点**：谁的东西能到哪一层、是哪一种、要谁点头（[PF-003 §6.2](../../../../product/PF-003-asset-transfer-and-sharing/design.md#62-谁能流向谁) 的矩阵逐格）；**团队资产不出那棵树**在发起、确认、使用三个时点的守卫 | [S-12](#s-12-流转边界团队资产不出那棵树)、[S-13](#s-13-发起者一侧的资产)、[S-49](#s-49-方向与落点矩阵逐格) |
| 6 | 两类待确认件的**指向对象存在性读面**——`data.offer-expiry/v1#S-19` 派给「持有该对象的契约」的那一格，资产那两类由本契约承担 | [S-7](#s-7-两类待确认件共用的过期语义) |

### S-2 本契约不拥有什么

| 不拥有 | 归谁 |
|---|---|
| 资产记录、版本、持有、复制血缘、分享标识的**形状** | `data.asset-model` v2（`AssetDefinition`、`AssetVersion`、`AssetHolding`、`HoldingBasis`、`CopyLineage`、`LineageId`、`SharingId`…），本契约只引名 |
| 创作、发布、提升、删除、持有与配值的**一般写面**及其角色矩阵 | `capability.asset-governance` v2。落地与分享取持有时本契约**组合**它的写面（[S-18](#s-18-确认是一次提交同一落点的确认序列化)），不复述那些写面的规则。**删除与提升那一次提交里要一并结束的分享**是本契约的记录，规则在 [S-52](#s-52-分享方删除资产或所有权易手分享随之结束) |
| 一次组装里**哪份资产生效、值取什么** | `capability.asset-evaluation`。本契约只给它一条判据：basis 为 shared 的持有什么时候可用（[S-9](#s-9-分享此刻是否生效)） |
| 组织、成员关系、隶属关系本身，上级链读面，**隶属建立时刻与成员关系生效时刻** | `capability.organization-governance` v3（两个时刻由它的 S-7、S-8 持有，S-22、S-59 读出）；**判据**归 `data.identity-values` v1 |
| 租户级 → 组织级的**提升** | `capability.asset-governance` 的提升面（[PF-001 §6.7](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#67-创作与归属)）；矩阵里「提升」那几格只是指路 |
| 组织级资产在本组织里**给谁用** | PF-002 的权限项「谁可以使用它」（`data.asset-model` 的 `usableBy`）——组织级的东西不走组织内分享 |
| 一份待确认件**何时不再可被确认** | `data.offer-expiry` v1，整块引用不复制（[S-7](#s-7-两类待确认件共用的过期语义)） |
| 导出、另存为模板、打包下载等**其他**能把资产带出范围的路径 | 各自的 owner。[PF-003 §6.1](../../../../product/PF-003-asset-transfer-and-sharing/design.md#61-一条不变量团队资产不出那棵树)那条不变量对它们同样成立，**它们引用 [S-12](#s-12-流转边界团队资产不出那棵树) 自证，本契约不替它们兑现** |

### S-3 本契约明确不承诺什么

- **不承诺投递。**「对方收到了一份复制通知／分享邀请」的含义**只是对方查询得到它**（[S-23](#s-23-读复制通知)、[S-27](#s-27-读分享邀请)）；
  接收的一方靠 [S-48](#s-48-列出组织收到的待确认件) 发现一份它还不知道标识的待确认件。本契约不推送。
- **不发出任何停止信号**（[S-36](#s-36-撤销不发出停止信号)）。
- **不提供钉住某一版**（[PF-003 §2 非目标](../../../../product/PF-003-asset-transfer-and-sharing/design.md#非目标)）、**不做冲突探测与合并**、**不提示「源侧有更新」**、**分享不带强制**。
- **不承诺对外交换格式，本版不附 Schema。**操作的输入与返回用散文写含义，值类型引用 data 契约；
  线上形状归把这些操作送过进程边界的那份 composition（[规格容器的规矩](../../../README.md#准入门槛与停止条件)）。
- **不定义界面。**「个人组织 → 团队组织级没有分享这个动作」是界面不给入口的事；本契约给的是一个可预先求出的判定（[S-15](#s-15-结构性禁止不是权限判定)）。

### S-4 依赖方向与被消费的面

**依赖方向**：本契约 → 组织治理、身份值、过期语义、资产数据形状、资产治理。
**反方向一条也没有**：资产治理的通用写面**不读本契约**——basis 为 shared 的持有由谁写都行，
**它可不可用在使用那一刻按 [S-9](#s-9-分享此刻是否生效) 判**，写入时不需要回头问本契约。
**求值也不读本契约**：组输入的一方在组输入时按 [S-9](#s-9-分享此刻是否生效) 的判据现读，不成立的持有不交进去（`capability.asset-evaluation` 的前提 PRE-2）；求值本身是纯计算。
**删除与提升是唯一的一处交汇**（[S-52](#s-52-分享方删除资产或所有权易手分享随之结束)）：那两次提交由资产治理发起，结束分享的写入是**本契约的记录、本契约的规则**，
由同一提供者在那一次提交里一并完成——与落地经组合入口进本契约确认的那一次提交（[S-18](#s-18-确认是一次提交同一落点的确认序列化)）**同一个安排、方向相反**。
资产治理那一侧只需把这一步列进它那两次提交的写集合（指路到 S-52），**不读本契约的任何判定**；提升与删除两次都已列进（`capability.asset-governance/v2#S-27` ④、`#S-28` ④，两处 ⑧ 都写明这一步写不下去则整次失败）。

#### `capability.organization-governance` v3 侧

**钉 v2**：v2 是 v1 的加法版。`#S-7`、`#S-8` 的时刻与 `#S-22`、`#S-59` 带出时刻的那一项是 v2 新增的；`#S-22` 在 v2 还多一种 `unavailable` 触发（时刻读不到），`#S-33` ④ 的写集合多清一个时刻；下表其余条款本契约用到的那一部分 v2 未改——逐条见[组织治理 v2 第十三节](../../organization-governance/v3/contract.md#十三版本差异与规范工件)。

| 被消费的条款 | 用在哪 |
|---|---|
| `#S-6` 个人组织的结构性禁止（禁止 3：上级恒空、不作上级） | [S-12](#s-12-流转边界团队资产不出那棵树)「个人组织永远不在任何树上」 |
| `#S-7` 上级组织属性（v2：**隶属建立时刻**，随上级值写下、随它清空） | [S-9](#s-9-分享此刻是否生效) 第三个合取项的隶属那一半 |
| `#S-8` 成员关系记录（v2：**成员关系生效时刻**，只随「变为有效」写下，解除不清、再加入改写） | [S-9](#s-9-分享此刻是否生效) 第三个合取项的成员那一半 |
| `#S-12` 上级链与有共同上级 | [S-12](#s-12-流转边界团队资产不出那棵树) 的边界判据（定义式引 `data.identity-values`，本契约不复述） |
| `#S-22` 读组织 | 落点／被分享方组织的**变体与存在**（[S-20](#s-20-发起复制)、[S-24](#s-24-发起分享) 的边界一步）；**v2：连接二者的每个组织的隶属建立时刻**（[S-9](#s-9-分享此刻是否生效)，按它末段的先后读） |
| `#S-26` 成员资格判定 | 每一处「发起者／确认者／被分享的租户成员资格有效、持什么角色」 |
| `#S-33` 解除隶属 | [S-31](#s-31-隶属解除分享在使用时失效不靠事件)：解除只清上级组织属性，分享随求值条件转假 |
| `#S-34` 上级链与有共同上级（读面） | [S-12](#s-12-流转边界团队资产不出那棵树) 在三个时点求 `shareAncestor` 用的就是这一支，**不自己从链上算**；[S-9](#s-9-分享此刻是否生效) 求「连接二者的隶属关系」用它的上级链 |
| `#S-38` 解除只改成员关系的有效性 | [S-32](#s-32-成员关系解除复制执行不了已确认的不动)：成员退出不删他的租户级持有，所以不使指着它的待确认件过期 |
| `#S-40` 事件都是通知（含「PF-003 的分享失效不靠 `affiliation.dissolved`」） | [S-31](#s-31-隶属解除分享在使用时失效不靠事件) 的整条写法 |
| `#S-42` 装配给的保证 vs 协议须给的保证：「（v2）两个时刻可比」那一行（同一时间源、不后退、先后两次串行提交的时刻不相等）与「调用方身份已经核实过」那一行 | [S-9](#s-9-分享此刻是否生效) ② 的先后比较与「不复活」（[第七节](#七性质与前提)安全性质）的前提；[S-34](#s-34-装配给的保证-vs-协议须给的保证) 代行读两个时刻的调用主体（K37）——那一行一改，这两处跟着核 |
| `#S-59` 列出组织成员（v2：每项带**成员关系生效时刻**；末段的先后读法） | [S-9](#s-9-分享此刻是否生效) 第三个合取项读租户那一端的时刻：默认档、取它那一项；调用主体是运行时代行（[S-9](#s-9-分享此刻是否生效) ②、[S-34](#s-34-装配给的保证-vs-协议须给的保证)） |

> **不消费 `#S-36`**（当前租户身份查询）：它在 v2 也带出生效时刻，但它按登录状态回答「这次登录站在哪」，本契约要的是某个给定租户的时刻，走 `#S-59`。
> **原 G-11 由 v2 闭合**：v1 的上级组织属性只有「此刻的上级」、成员关系记录只有有效性与角色，两个时刻没有落处；v2 加了它们与读面（主线裁定 D-060 §三 R2-1）。

#### `data.identity-values` v1 侧

| 被消费的条款 | 用在哪 |
|---|---|
| `#S-3` OrganizationId、`#S-4` OrganizationKind、`#S-5` TenantId 的构成与相等 | 全部输入；「目标侧租户 = (落点组织, 发起者账号)」由 `#S-5` 的结构得出 |
| `#S-11` ScopeLayerIdentity | **复制的落点与分享的被分享方都是一层**：一个组织的组织级，或一个租户的租户级（[S-49](#s-49-方向与落点矩阵逐格)） |
| `#S-13` sameAccountDistinctTenants | **只在本人型那一支**：[S-49](#s-49-方向与落点矩阵逐格)「落点是发起者自己在另一个组织的租户」的纯值判定。它的消费者核对 [CS-3](../../../data/identity-values/v1/contract.md#cs-3-资产复制的前提) 按 rev 4 把它写成一切资产复制的前提；那份契约已冻结不改，**本契约按下面的读法使它成立**（主线裁定 D-060 §三 R2-3，不开缺口）：**CS-3 是本人型那一支的前提**；组织型的两侧**按各自组织的租户身份分别署名**——发起者是 (源组织, 他)、确认者兼作者是 (目标组织, 确认的超管)——**两侧账号恰好相同**（同一个人在两个团队组织都是超管）时 `sameAccountDistinctTenants` 为真，**但这不使它成为本人型**：是哪一种由源的所有者与落点那一层定（[S-13](#s-13-发起者一侧的资产)、[S-49](#s-49-方向与落点矩阵逐格)），不由两侧账号相不相同定 |
| `#S-14` 上级链、`#S-15` shareAncestor | [S-12](#s-12-流转边界团队资产不出那棵树) 的判据权威（消费者核对 [CS-4](../../../data/identity-values/v1/contract.md#cs-4-分享边界有共同上级)）；[S-9](#s-9-分享此刻是否生效)「连接二者的隶属关系」按 `#S-14` 的含自身链求对称差 |
| `#S-16` 按归属层显式携带身份值、`#S-17` 身份参数没有默认值、`#S-18` 缺席即拒绝 | [S-16](#s-16-缺席时的默认答案) |
| `#S-19` 不可用即明确失败 | [S-16](#s-16-缺席时的默认答案) 与各操作的 ⑧ |
| `#S-26` 成员无效使租户级持有不可达但不销毁 | [S-32](#s-32-成员关系解除复制执行不了已确认的不动) |
| `#S-27` 每道准入现读 | [S-17](#s-17-每道准入现读确认时再判一遍) |
| `#S-30` 跨边界须重新验证 | [S-34](#s-34-装配给的保证-vs-协议须给的保证) 右列 |
| `#S-31` 不透明标识的交换表示 | `CopyNoticeId`／`SharingInvitationId` 的词法与相等；[S-16](#s-16-缺席时的默认答案) 纯值判定的逐码点比较 |
| `#S-32` 判别式集合闭合、`#S-33` 表示层校验与判定分开 | [S-16](#s-16-缺席时的默认答案) 的 `invalidInput` |

#### `data.offer-expiry` v1 侧

**整块引用不复制**（[S-7](#s-7-两类待确认件共用的过期语义)）：
`#S-2`、`#S-4`～`#S-14`、`#S-16`～`#S-20`，由正文里按号引用的位置收齐。
**`#S-19` 与 `#S-20` 是本契约的一格落点**：那两条把「指向对象的存在性读面」派给持有该对象的契约，
资产那两类由本契约兑现（[S-7](#s-7-两类待确认件共用的过期语义)）。

#### `data.asset-model` v2 侧

| 被消费的条款 | 用在哪 |
|---|---|
| [`#S-4`](../../../data/asset-model/v2/contract.md#s-4-资产记录号) 资产记录号（不回收不复用） | 全部输入；[S-7](#s-7-两类待确认件共用的过期语义) 的存在性 |
| [`#S-5`](../../../data/asset-model/v2/contract.md#s-5-资产来源) 资产来源、[`#S-6`](../../../data/asset-model/v2/contract.md#s-6-所有者与作者分记) 所有者与作者、[`#S-7`](../../../data/asset-model/v2/contract.md#s-7-所有者至多变一次) 所有者至多变一次 | [S-11](#s-11-复制的收场) 的写集合、[S-13](#s-13-发起者一侧的资产) 的「自己的」、[S-8](#s-8-分享) 的分享方 |
| [`#S-8`](../../../data/asset-model/v2/contract.md#s-8-资产记录) 资产记录、[`#S-9`](../../../data/asset-model/v2/contract.md#s-9-版本线) 版本线 | [S-11](#s-11-复制的收场)、[S-20](#s-20-发起复制) 的已发布版本 |
| [`#S-18`](../../../data/asset-model/v2/contract.md#s-18-资产持有) 资产持有（同一格同一能力标识至多一份；`shared` 只能 `current`） | [S-7](#s-7-两类待确认件共用的过期语义)、[S-11](#s-11-复制的收场)、[S-26](#s-26-确认分享) |
| [`#S-19`](../../../data/asset-model/v2/contract.md#s-19-使用权来路) 使用权来路（`shared` 与租户格的 `organization` 支） | [S-9](#s-9-分享此刻是否生效) 的匹配。`shared` 落组织格或租户格——组织内分享与本人型分享的被分享方是租户格（2026-09-24 第二轮那份契约已放开，原 [G-14](#十一已知缺口) 闭合） |
| [`#S-21`](../../../data/asset-model/v2/contract.md#s-21-复制血缘) 复制血缘、[`#S-22`](../../../data/asset-model/v2/contract.md#s-22-血缘号与分享号) 血缘号与分享号 | [S-10](#s-10-复制血缘怎么判怎么记)、[S-26](#s-26-确认分享) ④。血缘按 (源, 落进的层) 记，落在租户级的那一份所有者是租户（2026-09-24 第二轮那份契约已按本契约的矩阵改，原 [G-14](#十一已知缺口) 闭合） |

#### `capability.asset-governance` v2 侧

| 被消费的条款 | 用在哪 |
|---|---|
| [`#S-46`](../../asset-governance/v2/contract.md#s-46-组合入口资产流转的确认步骤) 组合入口：首次复制（`createDraft` 另收 `lineage`）、重复复制、分享取持有（`hold` 带 `sharing`、恒 `current`，组织格或租户格） | [S-18](#s-18-确认是一次提交同一落点的确认序列化) 的落地 |
| [`#S-24`](../../asset-governance/v2/contract.md#s-24-createdraft-创建草稿)、[`#S-25`](../../asset-governance/v2/contract.md#s-25-updatedraft-修订草稿)、[`#S-26`](../../asset-governance/v2/contract.md#s-26-publish-发布)、[`#S-30`](../../asset-governance/v2/contract.md#s-30-hold-加入持有)、[`#S-31`](../../asset-governance/v2/contract.md#s-31-unhold-移除持有) | 组合入口调用的那几个写面；[S-29](#s-29-移除收到的分享) 的 `unhold` |
| [`#S-27`](../../asset-governance/v2/contract.md#s-27-promotetoorganization-提升到组织) 提升（所有者由租户改为组织，至多一次、不可逆） | [S-52](#s-52-分享方删除资产或所有权易手分享随之结束)：那一次提交里分享方的全部 active 分享随之结束（原因 `ownerChanged`）；[S-8](#s-8-分享)：**提升不被分享挡住**（主线裁定 D-060 §三 R2-7，那份条款 ② 已写明「不看还有谁持有它」） |
| [`#S-28`](../../asset-governance/v2/contract.md#s-28-delete-删除一份资产记录) 删除（先告知、不级联；已发布版本作不可解引用的归档保留） | [S-52](#s-52-分享方删除资产或所有权易手分享随之结束)：那一次提交里以它为资产的全部 active 分享随之结束（原因 `sourceDeleted`）——那份条款 ④ 已把这一步列进写集合、⑧ 写明写不下去则整次失败（原 [G-15](#十一已知缺口) 闭合）；被分享方那份 `shared` 持有**不动**（不级联），读到「已删除」 |
| [`#S-64`](../../asset-governance/v2/contract.md#s-64-readasset-读一份资产记录) 读一份资产记录（已删除的只答「已删除」） | [S-30](#s-30-列出组织的分享) ⑤：资产已被删除的分享那一项 |
| [`#S-42`](../../asset-governance/v2/contract.md#s-42-listholdings-列出某范围的持有)、[`#S-43`](../../asset-governance/v2/contract.md#s-43-readholding-读一份持有) 读面 | [S-7](#s-7-两类待确认件共用的过期语义) 的存在性、[S-13](#s-13-发起者一侧的资产)、[S-14](#s-14-plugin-的复制与分享) 的告知清单 |
| [`#S-48`](../../asset-governance/v2/contract.md#s-48-事件都是通知) 事件都是通知（`AssetPublished`、`HoldingChanged`） | [S-33](#s-33-本版不发本契约自己的事件)：落地与持有变化由它们承载 |

---

## 二、概念、身份与必要状态

**本节的身份值一律引用 `data.identity-values` v1**：`OrganizationId`、`OrganizationKind`、`TenantId`、`ScopeLayerIdentity`；
**资产侧的值一律引用 `data.asset-model` v2**（[S-4](#s-4-依赖方向与被消费的面) 末表），**不复制定义**。
本契约自己铸的标识只有两个：`CopyNoticeId`、`SharingInvitationId`，**不透明、部署内唯一、由存储生成、不回收不复用**，
词法与相等按 `data.identity-values/v1#S-31`。**`SharingId` 的形状归 `data.asset-model`，铸它的是本契约**（[S-26](#s-26-确认分享) ④、[S-24](#s-24-发起分享) ④），同样不复用。

**「一层」**在本契约里一律是 `ScopeLayerIdentity`：`{organization: O}` 是组织 O 的组织级，`{tenant: T}` 是租户 T 的租户级。
**一层的所有者**：前者是 O，后者是 T（[PF-003 §4](../../../../product/PF-003-asset-transfer-and-sharing/design.md#承接-pf-001-与-pf-002)「在组织级」「在租户级」指它归谁）。

### S-5 复制通知

[复制通知](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-copy-notice--复制通知--copy-notice)是一次**组织型**[资产复制](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-asset-copy--资产复制--asset-copy)在确认之前的那份持久记录，由 `CopyNoticeId` 标识。它携带：

| 字段 | 含义 | 何时定、可变吗 |
|---|---|---|
| 发起者 | `TenantId`——**源组织的超级管理员** (源组织, 账号) | 发起时，不变 |
| 源 | `{ AssetRecordId, 版本号 }`——源组织**组织级**的那份资产与它的**某一个已发布版本** | 发起时，不变 |
| 目标 | `OrganizationId`——同一棵树上另一个团队组织；**落点恒是它的组织级** | 发起时，不变 |
| 指向的那份持有 | 发起时**所有者那一层**（源组织的组织级）持有源记录的那一份——[S-7](#s-7-两类待确认件共用的过期语义) 的存在性按它判；**它靠什么被指认待 [G-3](#十一已知缺口)** | 发起时，不变 |
| 发起是不是 agent 产出 | 布尔，取发起这次复制的那次调用的上下文（不是 [S-20](#s-20-发起复制) ① 的入参，发起者不能自报）；确认落地时照它写新记录的 `byAgent`（[S-11](#s-11-复制的收场)）；**上下文里缺这一项，发起即 `unavailable`、不写这份通知**（[S-20](#s-20-发起复制) ⑧） | 发起时，不变 |
| `OfferTiming` | `data.offer-expiry/v1#S-4`，两个时刻在发起的同一提交内定死（`#S-5`） | 发起时，不变 |
| 终结记录 | 至多一条：确认（带确认者 `TenantId`、确认时刻与 [S-11](#s-11-复制的收场) 的 `CopyOutcome`）或撤回（带撤回者与时刻） | 一经写下不改写 |

**它不是资产，也不是持有**：确认之前目标组织里什么都没有（[flows §3.1](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#31-一份复制来的资产在目标组织里)）。
**本人型复制不产生复制通知**：两侧都是他自己，发起就是两侧的同意（[PF-003 §4](../../../../product/PF-003-asset-transfer-and-sharing/design.md#资产复制)、[§6.14](../../../../product/PF-003-asset-transfer-and-sharing/design.md#614-待确认的复制通知与分享邀请会过期)），落地在发起那一次提交里（[S-20](#s-20-发起复制) ④）。

### S-6 分享邀请

[分享邀请](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-sharing-invitation--分享邀请--sharing-invitation)是一次要对方点头的[资产分享](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-asset-sharing--资产分享--asset-sharing)在确认之前的那份持久记录，由 `SharingInvitationId` 标识。它携带：

| 字段 | 含义 | 何时定、可变吗 |
|---|---|---|
| 发起者 | `TenantId`——**分享方**那侧发起这次分享的租户身份 | 发起时，不变 |
| 分享方 | 资产此刻的所有者（`data.asset-model` 的所有者：组织或租户） | 同上 |
| 被分享方 | `ScopeLayerIdentity`——**一个组织**（组织—组织、个人—个人）或**一个租户**（组织内分享）（[PF-003 §4 分享](../../../../product/PF-003-asset-transfer-and-sharing/design.md#分享)） | 同上 |
| 资产 | `AssetRecordId`——**不带版本**：确认之后跟随的是分享方当前发布的那一版（[S-8](#s-8-分享)） | 同上 |
| 指向的那份持有 | 同 [S-5](#s-5-复制通知)（所有者那一层持有它的那一份） | 同上 |
| `OfferTiming` | 同 [S-5](#s-5-复制通知) | 同上 |
| 终结记录 | 至多一条：确认（带确认者、时刻与因此成立或被认回的 `SharingId`）或撤回 | 一经写下不改写 |

**本人型分享不产生分享邀请**：被分享的租户就是发起者自己在另一个组织的那一个，发起即进入「分享中」（[flows §3.2](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#32-一段分享关系)），见 [S-24](#s-24-发起分享) ④。

> **两类待确认件各自有身份、各自一张表，只有过期规则相同。**
> [UL-offer](../../../../ubiquitous_language/terms/subjects-and-ownership.md#ul-offer--邀约--offer) 已写明这四样「不共享一套身份机制」；
> 本契约不为它们造一个共同的超类型，**两类的标识互不相等、不可混用**。
> 那个词条现写明四样**各是一个对象**（PF-003 rev 5 [decisions §二](../../../../product/PF-003-asset-transfer-and-sharing/decisions.md#二pm-推导)）；本契约给它们的可标识持久记录与之一致。

### S-7 两类待确认件共用的过期语义

**过期语义整块引用 `data.offer-expiry` v1，不复制、不改写**：派生状态四值（`#S-7`）、判定式（`#S-8`）、
读时派生且不回退（`#S-9`）、确认在同一提交内重判（`#S-10`）、到期不可确认（`#S-11`）、
过期与撤回收场相同（`#S-12`）、确认路径上三种来路同值（`#S-13`）、时长参数（`#S-14`）、同一时间源（`#S-16`）、
存在性读面归属与「不可用 ≠ 不存在」（`#S-19`、`#S-20`）。

**本契约只补它明文留给消费者的四格：**

1. **派生状态用 `OfferState`**（`data.offer-expiry` 的 `$defs/OfferState`）。**PF-003 说的「确认」就是它的 `accepted`**——
   不另起一个 `confirmed` 取值，那会是同一个状态的第二份定义。
2. **判定用的指向对象**（`data.offer-expiry/v1#S-2`、`#S-6`）：复制通知指**源那份资产**，分享邀请指**被分享的那份资产**。
   目标组织、被分享方、发起者**都不进判定式**。
3. **「那份资产还在」怎么判**——本契约提供的存在性读面：

   ```text
   存在(待确认件 x)  ≝  x 指向的资产记录存在
                        ∧ 它的所有者那一层此刻持有它
                        ∧ 那份持有就是 x 发起时的那一份（此后重新持有的不算）
   ```

   **第二个合取项来自原话**：「它指向的那份资产不存在了（**被移除**、被删除）」
   （[PF-003 §6.14](../../../../product/PF-003-asset-transfer-and-sharing/design.md#614-待确认的复制通知与分享邀请会过期)）——
   所有者把它从自己那一层[移除](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-asset-removal--资产移除--asset-removal)，记录还在，但对这份邀约而言它**已经不在了**。
   「所有者那一层」：所有者是租户 ⇒ 那个租户的租户级；所有者是组织 ⇒ 那个组织的组织级。
   **第三个合取项是 `data.offer-expiry/v1#S-9` 的「不回退」要的**：移除之后再持有同一份记录，若算「又在了」，
   一份已经 `expired`（派生状态）的邀约会翻回 `pending`。**它要求持有能区分「这一份」与「后来那一份」，而 `data.asset-model` 的持有形状目前没有实例身份**——
   [缺口 G-3](#十一已知缺口)。
4. **失败值的名字**（`#S-13`、`#S-14` 留给消费者取）：确认路径上三种来路同收 **`offerNoLongerValid`**，撤回路径上已终结（已确认或已过期）同收 **`alreadyConcluded`**——都与 `capability.organization-governance` v3 的同一收场同名（[S-19](#s-19-这一节每个操作写全九件事) 的总表；主线裁定，文首）；
   非法时长收 **`invalidInput`**（[S-16](#s-16-缺席时的默认答案)）。

**两类各有各的默认时长**，都是 `offer_ttl` 的一类默认值（部署配置，**本契约不填值**）；发起时可以指定这一份的（[S-20](#s-20-发起复制)、[S-24](#s-24-发起分享) ①）。
**指定值是这份数据的参数，不进作用域层**（`#S-14`）。**组织内分享的邀请就是分享邀请**，同一类默认值。

**确认之后没有期限，也没有暂停。**`data.offer-expiry` 只管确认之前那一段（`#S-3`）；
[确认之后的使用权不过期](../../../../product/PF-003-asset-transfer-and-sharing/design.md#610-分享给的是获权不是拥有)，复制下来的那一份是目标那一层自己的。

### S-8 分享

**分享**是**被分享方确认之后**（本人型：发起之后）那份获权的记录——一段[分享关系](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-sharing-relationship--分享关系--sharing-relationship)「分享中」与「结束」两段的持久形态，由 `SharingId` 标识。它携带：

| 字段 | 含义 |
|---|---|
| 分享方、被分享方、资产 | 分享方是资产在成立那一刻的所有者（组织或租户）；被分享方是 `ScopeLayerIdentity`；**三者不变** |
| 发起者、确认者、**确认时刻**、来自哪份分享邀请 | 审计要的「谁、何时、依据什么」（[PF-001 §6.8](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#68-管理结果)）。**本人型**：确认者就是发起者，确认时刻就是发起那一次提交的时刻，没有邀请。**确认时刻参与 [S-9](#s-9-分享此刻是否生效) 的判定** |
| 记录状态 | `active` / `revoked` / `removed` 三值；后两值一经写下不改写，并带写下者与时刻。**`revoked` 另带结束原因，闭合三值**：`sharerRevoked`（分享方撤销，[S-28](#s-28-撤销分享)）、`sourceDeleted`（分享方删除了那份资产）、`ownerChanged`（那份资产被提升、所有权易手）——后两个见 [S-52](#s-52-分享方删除资产或所有权易手分享随之结束) |

**四种分享，按被分享方与分享方分**（[PF-003 §4 分享](../../../../product/PF-003-asset-transfer-and-sharing/design.md#分享)、[§6.2](../../../../product/PF-003-asset-transfer-and-sharing/design.md#62-谁能流向谁)）：

| 种类 | 分享方 | 被分享方 | 谁点头 |
|---|---|---|---|
| 组织—组织 | 一个团队组织（它组织级的资产） | 同一棵树上另一个团队组织 | 对方组织的超级管理员 |
| 个人—个人 | 一个个人组织里的（它自己，或它唯一那个租户） | 另一个个人组织 | 对方账号本人（它是那个个人组织的超级管理员） |
| 组织内分享 | 一个租户（它租户级的资产） | 同一组织里另一个租户 | 那个租户本人 |
| 本人型 | 发起者本人的（个人组织里的，或团队里他租户级的） | 发起者自己在另一个组织里的那个租户 | **不需要**——两侧都是他 |

**它给的是[使用权](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-usage-right--使用权--usage-right)，不是[定义所有权](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-definition-ownership--定义所有权--definition-ownership)。**
资产记录的所有者、作者、版本一概不动；被分享方不能改内容（[§6.10](../../../../product/PF-003-asset-transfer-and-sharing/design.md#610-分享给的是获权不是拥有)）。

**它跟随的是「分享方当前发布的那一版」这个动态目标**，记录里**没有版本字段**——
[没有「钉在某一版」这个选项](../../../../product/PF-003-asset-transfer-and-sharing/design.md#611-分享的同步与自保)。
被分享方的自保手段是**收窄自己那一层的权限**或**移除**（[S-29](#s-29-移除收到的分享)）；前者归资产治理的配值面。

**提升不被分享挡住**（主线裁定 D-060 §三 R2-7）：分享方把一份仍有 active 分享的租户级资产提升到组织，提升照做；
**提升那一刻，他作为分享方的全部 active 分享随之结束**，记录写 `revoked`、原因 `ownerChanged`（[S-52](#s-52-分享方删除资产或所有权易手分享随之结束)）。
理由与分享方退出同一条（[S-32](#s-32-成员关系解除复制执行不了已确认的不动)、[PF-003 §6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后) 第三行）：分享方不再是那份资产的所有者，他给出的使用权没有了依托；
另一种读法——分享随资产归组织——要组织为一段它**没有点过头**的分享承担后果，不取。
资产治理的提升已照此写（`capability.asset-governance/v2#S-27` ②④：不看还有谁持有它，同一提交里结束这几段分享）。
**被分享来的不能被提升**：提升要求所有者是调用方本人（同一条），被分享方从来不是所有者（[§6.13](../../../../product/PF-003-asset-transfer-and-sharing/design.md#613-分享不可传递)）。

**同一 (资产, 被分享方) 至多一份此刻生效的分享**（[S-9](#s-9-分享此刻是否生效) 的「生效」）。已有时，再确认一份同对的分享邀请（或再发起一次同对的本人型分享）**认回那一份**，不新建（[S-26](#s-26-确认分享) ⑦）。
理由：两份同时生效时，被分享方[移除](#s-29-移除收到的分享)一份、另一份仍给着使用权——「我不要了」就不再是一个动作能说完的事。
**一份记录仍为 `active` 却已经不生效的**（关系断过，[S-9](#s-9-分享此刻是否生效)）永远不会再生效，所以**不算**「已有」——再分享是[新的一段](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)，新建一份记录。

### S-9 分享此刻是否生效

**`SharingState` 四值，三个是记录、一个是派生：**

| 值 | 是记录还是派生 | 含义 |
|---|---|---|
| `active` | 记录为 `active`，**且此刻**下面的另两个合取项都成立 | 生效中 |
| `dissolved` | **派生**：记录仍为 `active`，但让这段分享成立的那层关系**此刻不成立，或自确认以来断过** | [关系解除之后](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)的样子：隶属解除、任一端（是租户的那一端）的成员关系解除。**不是一个被写下的值**，而且**一经成立不再回到 `active`** |
| `revoked` | 记录 | 分享方撤销（[S-28](#s-28-撤销分享)，原因 `sharerRevoked`）；分享方删除了那份资产（原因 `sourceDeleted`）或把它提升到组织（原因 `ownerChanged`），[S-52](#s-52-分享方删除资产或所有权易手分享随之结束) |
| `removed` | 记录 | 被分享方移除（[S-29](#s-29-移除收到的分享)） |

```text
生效(s)  ≝  s 的记录状态 = active
          ∧ 关系此刻成立(s)
          ∧ 关系自确认以来未断过(s)

记 Os = 分享方所在的组织（分享方是组织即它自己，是租户即它所在的组织），Or = 被分享方所在的组织。

关系此刻成立(s)  ≝  ( Os = Or  ∨  分享边界(Os, Or) )                       \* 边界按 S-12
                  ∧ ( 分享方是租户   ⇒ 它此刻是有效成员 )
                  ∧ ( 被分享方是租户 ⇒ 它此刻是有效成员 )

关系自确认以来未断过(s)
                ≝  ( Os ≠ Or ∧ 两者都是团队组织
                       ⇒ 连接二者的每一条隶属关系，其隶属建立时刻 ≤ s 的确认时刻 )
                  ∧ ( 分享方是租户   ⇒ 它的成员关系生效时刻 ≤ s 的确认时刻 )
                  ∧ ( 被分享方是租户 ⇒ 它的成员关系生效时刻 ≤ s 的确认时刻 )
```

- **连接二者的隶属关系**：两条含自身的上级链（`data.identity-values/v1#S-14`）的**对称差**里，每个组织与它上级之间的那一条——
  也就是各自沿上级链走到**最近的共同上级**为止所经过的每一条。共同上级以上的隶属关系**不算**：集团再去隶属一个更大的集团，不动它下面两家子公司之间的分享。
- **隶属建立时刻**（无词条，`parentEstablishedAt`）：一个组织此刻的上级组织属性是在哪一刻写下的；**成员关系生效时刻**（无词条，`membershipEffectiveSince`）：一条成员关系记录最近一次成为有效的时刻。
  **两者都由 `capability.organization-governance` v3 持有**（它的 S-7、S-8）：隶属建立时刻由它的 S-22（读组织）带出，成员关系生效时刻由它的 S-59（列出组织成员）带出。
- **怎么读**（组输入的一方照此读，[S-30](#s-30-列出组织的分享) 求 `SharingState` 也照此读）：
  ① 先按 `capability.organization-governance/v3#S-34` 求两个组织的边界与上级链、按 `#S-26` 判租户那一端此刻有效——这就是第二个合取项；
  ② **再**为「连接二者的隶属关系」里的每个组织读 `#S-22` 的隶属建立时刻，为租户那一端读 `#S-59`（默认档，取它自己那一项；调用主体见下一条）的成员关系生效时刻。
  **② 在 ① 之后**：反过来读，一次「解除—重新接上」落在两读之间，旧的时刻就会配上新接上的关系，**分享复活**；按这个先后读，两读之间的任何断开只会让时刻变新、让上级对不上、或让那个租户不在默认档里——**一律按「断过」判**。
  `#S-22` 读到的上级不是 ① 那条链上的那一个（含此刻已没有上级），或 `#S-59` 以 `notAuthorized` 收场（以它自己的身份值代行读时，这就是它此刻已不是有效成员），都是「断过」，不是「读不到」。
  **单机下在一次可串行化的读里取齐 ① 与 ②，也就满足了这个先后**。
- **读这两个时刻的调用主体是运行时代行**：要读的是分享两端的组织与租户，不是发起这次操作的那位调用者，也没有哪一位租户在为这次读取发起调用——单机装配下由运行时代行，以被读的那个租户的 `TenantId` 为调用方身份值读 `#S-59` 默认档、按链逐个读 `#S-22`，可串行化读即满足（**装配给**；依据是组织治理 v2 [S-42](../../organization-governance/v3/contract.md#s-42-装配给的保证-vs-协议须给的保证)「调用方身份已经核实过」那一行：这批是能力间内部面，身份值由装配保证为真）；跨进程之后由一个获授权读这两个读面的服务身份兑现（**协议给**），做不到时按「读不到」收，分享不放行。
  这一句与 [`capability.organization-governance/v3` 第十二节](../../organization-governance/v3/contract.md#十二消费者核对)那一行同句；[S-34](#s-34-装配给的保证-vs-协议须给的保证) 记它的两列。
- **为什么这一项就是「不复活」**：关系断开之后要重新接上，**必然要写一条新的隶属关系或让成员关系重新生效**——
  单一上级的树里，断开的两部分只能靠新写下的那一条重新连起来，[重新加入回来的是同一个租户](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#退出之后再加入回来的是同一个租户)但生效时刻是新的——
  那一条的时刻一定晚于确认时刻，第三个合取项从此恒假。**它不依赖任何事件送达**：判定读的是两个持久的时刻，与 `capability.organization-governance/v3#S-40`、`data.identity-values` 的 [CS-4](../../../data/identity-values/v1/contract.md#cs-4-分享边界有共同上级)「不依赖任何事件送达」相容。
- **个人—个人那一种**：两个个人组织永远不在任何树上，它们的成员关系不会解除——两个合取项恒真，只有撤销、移除与 [S-52](#s-52-分享方删除资产或所有权易手分享随之结束) 那两种能结束它。
  **不必为它读时刻**：个人组织唯一的成员关系没有解除路径（`capability.organization-governance/v3#S-6` 的禁止 2），它的生效时刻就是个人组织建立的那一刻，早于任何一次分享。

**给求值的那一条判据**——`capability.asset-evaluation` 据以认一份 basis 为 shared 的持有（`data.asset-model` 的 `HoldingBasis`）：

> **一份 basis 为 shared 的持有（在组织格或租户格），在使用的那一刻可用，当且仅当存在一份分享 s，
> s 的资产就是这份持有的资产，s 的被分享方就是这份持有所在的那一层，且 生效(s)。**
> 求值读不到分享记录、读不到边界、**或读不到那两个时刻** ⇒ **以不可用失败**，不得当作可用，也不得当作「这份持有不存在」（`data.identity-values/v1#S-19`）。

**被分享方组织里的租户格以 `organization` 支持有同一份记录的那份**（`data.asset-model/v2#S-19`；主线裁定，文首）**随它所在组织那份 shared 持有一起判**：那份此刻不可用，这份也不可用；它不另立一条判据。

**为什么按 (资产, 被分享方) 对，而不按持有上记着的那个 `SharingId`**：
被分享方撤销后重新接受同一份资产的分享，它那层的持有与配值**原样还在**（本契约从不删对方的配值，[S-28](#s-28-撤销分享)），
按对判就不需要回头改那份持有的 basis；持有上记着的 `SharingId` 只作来路记录。
**同一对至多一份生效**（[S-8](#s-8-分享)），所以按对判不会有两个答案。

**为什么这条判据放在使用那一刻，而不放在写持有那一刻**：写持有时判一次，之后隶属一断、分享一撤，那份持有照样被当成可用——
这正是 [S-31](#s-31-隶属解除分享在使用时失效不靠事件) 要挡的。**使用时判，写入就不必判**，资产治理的写面因此不需要读本契约（[S-4](#s-4-依赖方向与被消费的面) 开头）。

### S-10 复制血缘怎么判、怎么记

**判首次还是重复，只看血缘，不看能力标识**（[§6.8](../../../../product/PF-003-asset-transfer-and-sharing/design.md#68-能力标识撞车但没有血缘)），
**而且只在落进的那一层里找**（[§4 复制血缘](../../../../product/PF-003-asset-transfer-and-sharing/design.md#复制血缘)、[§6.6](../../../../product/PF-003-asset-transfer-and-sharing/design.md#66-重复复制全量覆盖替换)）：

```text
重复(源记录 r, 落进的那一层 L)  ≝  对应(r, L) 存在
                                  ∧ 它指向的那份目标记录此刻存在，且此刻仍归 L 的所有者
```

「对应」是本契约私有的关系：**首次落地时铸一个 `LineageId`，记下 (源记录, 落进的那一层) ↔ `LineageId` 的对应，并把它写进新记录的 `CopyLineage`**。
**先定层，再在那一层里找**：每次复制的落点先按 [S-49](#s-49-方向与落点矩阵逐格) 定下来，判定只看那一层；那一层里没有，就是新增——**哪怕别的层里已经有一份**。

| 性质 | 写法 |
|---|---|
| **一条血缘由它挂着的那份目标侧资产确定** | 每个 (源记录, 落进的那一层) 至多一份带对应血缘的目标记录——[S-18](#s-18-确认是一次提交同一落点的确认序列化) 的序列化兑现，[模型检查](formal/README.md) |
| **同一个来源在一个组织里可以有两份** | 某人租户级一份、组织级一份，**各有各的血缘**，按层级求值各管各的范围（PF-003 §4 复制血缘「层与层各算各的」） |
| **`LineageId` 首次产生后不变** | 重复复制不改它（`data.asset-model` 的判定条款「血缘首次产生后不变」） |
| **不可反推源** | 血缘上，目标侧拿到的只有 `LineageId` 与下面四项，**拿不到源记录号、源侧的发起者租户身份**；(源记录, 层) ↔ `LineageId` 的对应**只在本契约内部**，不经任何读面返回给目标侧。**源组织**：本人型从不给目标侧；**组织型复制通知的目标侧投影带源组织的标识**（[S-23](#s-23-读复制通知)，主线裁定 D-060 §三 R2-6）——确认的超管要知道东西从哪来才能判，它在那份通知上，不在血缘上 |
| **目标侧看得见的四项** | 源版本号、送进来的租户身份、送进来的时刻、第几次送进来——`CopyLineage` 的 `sourceVersion`／`importedBy`／`importedAt`／`imports`。**每次落地都在同一提交里改写这四项**（`imports` 加一），`LineageId` 不动 |
| **不传递** | 复制下来的那份再被复制出去（本人型：它在我的租户级，是我的；组织型：它在组织级，是那个组织的），或被分享出去，都**不带**这条血缘——新落点得到一条新的 |

**`importedBy` 是落进那一层的那一侧的租户身份，不是源侧那个**：本人型是 (落点组织, 发起者账号)；组织型是**确认的那位超管**——
[把它带进目标组织的是点头的那位](../../../../product/PF-003-asset-transfer-and-sharing/design.md#65-首次复制)；记源侧的发起者，作者就不是目标组织里的一个租户（[§6.5](../../../../product/PF-003-asset-transfer-and-sharing/design.md#65-首次复制) 同一理由）。
**两侧账号恰好相同**（他在源、目标两个团队组织都是超管，组织型由他发起、由他确认）时，`importedBy` 与作者仍是 (目标组织, 他)——**按各自组织的租户身份署名**，这一次仍是组织型（[S-4](#s-4-依赖方向与被消费的面) 身份值侧 `#S-13` 那一行，主线裁定 D-060 §三 R2-3）。

> **「此后不变」与「四项每次改写」不矛盾**：本契约读「血缘首次产生后不变」为**那条对应关系（`LineageId`）不变**；
> 那四项答的是「由某租户在某时送进来第几版」，只记第一次就答错了。

**目标那一层的那份记录不再归它**——被删除（资产治理的删除面），或被[提升](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#67-创作与归属)到组织级（它从租户级离开了那一层）——对应还在也没有东西可更新：
**下一次落进这一层按首次处理**，铸新的 `LineageId` 并改指对应。这正是 [§6.6](../../../../product/PF-003-asset-transfer-and-sharing/design.md#66-重复复制全量覆盖替换) 那句「租户级那份被提升到组织级之后，原作者再复制一次，落的是他租户级新的一份，组织那份不动」。
**提升上去的那一份此后不再被任何一次复制更新**——它的血缘对应的是它当初落进的那一层，不是它现在所在的组织级；再往组织级复制一次，按组织级自己的对应判（**推导**，已报主线并接受（D-060 §七 N-18）确认）。

### S-11 复制的收场

**`CopyOutcome`** 两支，由系统判定、不由发起者选（[§4 资产复制](../../../../product/PF-003-asset-transfer-and-sharing/design.md#资产复制)）。
**落地的行为人**：本人型是发起者在落点组织的那个租户 (落点组织, 发起者账号)；组织型是**确认的那位超管**。

| 支 | 什么时候 | 写集合（全在落地那一次提交里：本人型是发起，组织型是确认） |
|---|---|---|
| **`created`**，带新记录的 `AssetRecordId`、「是否取得了持有」与「那一层此刻是否已有同一能力标识的另一份」 | [S-10](#s-10-复制血缘怎么判怎么记) 判为首次 | ① 新资产记录：**所有者 = 落进那一层的所有者**（租户级归那个租户，组织级归那个组织，[§6.5](../../../../product/PF-003-asset-transfer-and-sharing/design.md#65-首次复制)）、**作者 = 落地的行为人**、**`byAgent` = 发起这次复制的那次调用是不是 agent 产出**（取那次调用的上下文：本人型就是这一次提交，组织型取复制通知上发起时记下的那一项，[S-5](#s-5-复制通知)；确认者不改它）、来源 `customized`、能力标识与源相同、带新血缘；② 它的 **v1**，内容**整体等于**源那一版的内容；③ 那一层**此刻没有这个能力标识的持有** ⇒ 为它取得持有（basis `owned`），**已有** ⇒ **不动那份持有**，新记录不取得持有。那一层此刻已拥有或已持有同一能力标识的另一份时，返回里如实告知「同一能力标识下现在有两份」（[flows §二](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#二分支与异常)） |
| **`overwritten{newVersion}`** | 判为重复 | 在那份目标记录上**发布一个新版本**，内容整体等于源那一版的内容，版本号接着它自己的线往下数；**只改写血缘那四项**。**不碰任何持有、不碰任何属性配值**（包括标了 `immutable` 的） |

**三条逐字取自正文的边界**：

- **源侧什么都不动**——源记录、源的作者、源的版本线（[§4](../../../../product/PF-003-asset-transfer-and-sharing/design.md#资产复制)「源保留」）。
- **撞标识无血缘是新增，不是覆盖**：那一层自己那份同标识的资产**一个字节都不动**（[§6.8](../../../../product/PF-003-asset-transfer-and-sharing/design.md#68-能力标识撞车但没有血缘)）；同一标识下谁生效，由那一层自己按层级与替换规则决定。
- **覆盖的是内容，配置不动**（[§6.7](../../../../product/PF-003-asset-transfer-and-sharing/design.md#67-覆盖的范围内容覆盖配置不动)）：新版本删掉的属性项不参与求值、新增的走默认，这是求值的事，本契约不写配值。

**新版本「立即生效」**（[§6.6](../../../../product/PF-003-asset-transfer-and-sharing/design.md#66-重复复制全量覆盖替换)）的前提在求值那边：
那一层持有的是**记录**，追随当前版的持有求值取它**当前发布的那一版**——见[十二](#十二消费者核对)。

**`byAgent` 只在 `created` 那一支写**：它在记录上、不在版本上（`data.asset-model/v2#S-8`），`overwritten` 不建新记录也就不写它。取值规则是主线裁定 [D-060 §五 K38](../../../../record/decisions/mainline-self-rulings-2026-09/decision.md#五s25-第一轮修复波的主线裁定k1k502026-09-24-夜追加)；组织型要在复制通知上记下这一项（[S-5](#s-5-复制通知)），是本契约据它推出的——确认时发起那次调用已经不在；资产治理的组合入口照收、不另判（`capability.asset-governance/v2#S-46`）。
「调用上下文里有这一项」由装配如实给，与资产治理直接入口的 `byAgent` 同一来源（`capability.asset-governance/v2#S-50`）——**缺了不得默认为 `false`**：**本人型**那一次落地以 `unavailable` 收；**组织型**在发起时就收（[S-20](#s-20-发起复制) ⑧：不写通知），不等到确认——确认时发起那次调用已经不在，照发一份通知只会让它在确认时永远 `unavailable`（主线裁定，见 [D-060 §七 M27](../../../../record/decisions/mainline-self-rulings-2026-09/decision.md#七s25-第二轮独立复评之后的主线裁定m1m292026-09-25-追加)）。

**每个版本的发布者**（`AssetVersion.publishedBy`）记**落地的行为人**——这一版是那一刻由落进那一层的那一侧写下的；
送进来的人记在血缘的 `importedBy`，两者本版相同。**这一格正文没有原话，是推导**（[§6.6](../../../../product/PF-003-asset-transfer-and-sharing/design.md#66-重复复制全量覆盖替换)：「复制是要落进的那一层的管理者自己要的一次写入」）。

### S-12 流转边界：团队资产不出那棵树

**这是一条贯穿条款**，[PF-003 §6.1](../../../../product/PF-003-asset-transfer-and-sharing/design.md#61-一条不变量团队资产不出那棵树) 的不变量在本契约两条路径上的全部落点。
它只管**跨组织**的那一段；组织内分享不出组织，不求本式。

```text
复制边界(源组织 s, 落点组织 t)  ≝  s ≠ t
                                 ∧ t 存在且是团队组织
                                 ∧ ( s 是个人组织  ∨  shareAncestor(s, t) )

分享边界(分享方组织 o, 被分享方组织 t)
                              ≝  o ≠ t
                                 ∧ t 存在
                                 ∧ ( (o, t 都是个人组织)
                                   ∨ (o 是个人组织 ∧ t 是团队组织)
                                   ∨ (o, t 都是团队组织 ∧ shareAncestor(o, t)) )
```

「团队组织 → 任何个人组织」两式都不放行——那正是 §6.1 挡的那一路，**租户级的也一样**。
「个人组织 → 团队组织」两式都放行，**那一路到得了哪一层**由 [S-49](#s-49-方向与落点矩阵逐格) 定：复制可落我的租户级或（我是超管时）组织级，分享只落我的租户级。
两式的第一个合取项在操作 ① 就以 `invalidInput` 判掉（[S-16](#s-16-缺席时的默认答案)），写在这里只为定义完整；其余各项不成立收 `outsideTree`。
`shareAncestor` 的定义式归 `data.identity-values/v1#S-15`（**把各自算进自己的链再求交，即同一棵树**），
求值用 `capability.organization-governance/v3#S-34` 那一支，**不自己从上级链上算**。

**三个时点都判，缺一个就有一条绕过去的路**：

| 时点 | 在哪 | 为什么不能只判前一个 |
|---|---|---|
| **发起** | [S-20](#s-20-发起复制)、[S-24](#s-24-发起分享)（本人型的落地也在这一次提交里） | 早拒，不让一份注定落不了地的待确认件悬着 |
| **确认**（与落地同一提交） | [S-22](#s-22-确认复制)、[S-26](#s-26-确认分享) | 发起与确认之间隶属可能已解除；**不重判，团队资产就在树外落地了**——[模型给出过这条反例](formal/README.md) |
| **使用**（每一次） | [S-9](#s-9-分享此刻是否生效) | 确认之后隶属可能解除；**只对分享成立**——复制下来的那份已经是落点那一层自己的，[关系解除之后留着](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后) |

**「落点或被分享方组织不存在」收 `outsideTree`**：本版唯一会不存在的组织是[被清除的个人组织](../../organization-governance/v3/contract.md#s-53-清除未激活账号的个人组织)，它本就在所有边界之外。
**读不到 ≠ 不存在**：组织读面或上级链读不到 ⇒ `unavailable`，**不得把一条截断的链算出来的「不同树」当成越界拒绝交上去**（`data.identity-values/v1#S-19` 第 2 行）。

### S-13 发起者一侧的资产

**资产复制与分享都只能给出「自己的」**（[§6.4](../../../../product/PF-003-asset-transfer-and-sharing/design.md#64-可复制的对象)、[§6.10](../../../../product/PF-003-asset-transfer-and-sharing/design.md#610-分享给的是获权不是拥有)）。
「自己的」按所有者判（`AssetDefinition` 的所有者，[PF-001 §6.7 表](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#作者用租户身份标识)），**而所有者也就决定了这是哪一种**：

| 所有者 | 对**复制**而言 | 对**分享**而言 |
|---|---|---|
| 发起者这个租户（团队里他**租户级**的，或他个人组织里的租户级） | 他的 ⇒ **本人型** | 他的 ⇒ **组织内分享**或**本人型**（按被分享方，[S-49](#s-49-方向与落点矩阵逐格)）；个人组织里的还可以个人—个人 |
| 发起者的组织，**而它是个人组织** | 他的 ⇒ **本人型**——[「他个人组织里的」](../../../../product/PF-003-asset-transfer-and-sharing/design.md#64-可复制的对象)；个人组织只有他一个成员 | 他的 |
| 发起者的组织，**而它是团队组织** | 组织的 ⇒ **组织型**，**要发起者是该组织的超级管理员**，否则 `notPermitted`（[flows §二](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#二分支与异常)「发起者不是源组织的超级管理员 → 拒绝」） | 组织的 ⇒ **组织—组织**，同样要超管，否则 `notPermitted` |
| 平台（`origin = official`） | **`officialNotTransferable`** | **`officialNotTransferable`** |
| 别人（同组织的另一个租户、别的组织） | `sourceNotOwned`；**若发起者或发起者的组织是这份资产某次分享的被分享方 ⇒ `notTransitive`** | 同左 |

再加两条，缺一条都不算「他的现有资产」，收 **`sourceNotOwned`**：
**记录存在**；**所有者那一层此刻持有它**（与 [S-7](#s-7-两类待确认件共用的过期语义) 的存在性同一个判断——一份所有者自己都已移除的资产，发出去的邀约生来就是过期的）。

**判定次序固定**，同一输入同一答案：记录不存在 ⇒ `sourceNotOwned` → 官方件 ⇒ `officialNotTransferable` →
所有者是发起者所在的团队组织而发起者不是它的超管 ⇒ `notPermitted` →
所有者在发起者一侧 ⇒ 所有者那一层不持有它 ⇒ `sourceNotOwned`，持有则通过 →
其余：发起者或发起者的组织是这份资产某份分享（任何记录状态）的被分享方 ⇒ `notTransitive`，否则 `sourceNotOwned`。

**`sourceNotOwned` 不区分「不存在」「不归你」「你已移除」。**`AssetRecordId` 是不透明标识；
分开报会让调用方据失败值探出**别人的**租户级资产在不在——那是[他在这个组织里的私有部分](../../../../product/PF-003-asset-transfer-and-sharing/design.md#63-复制的通则同一自然人的两个租户身份)。
**`notTransitive` 可以分开报**：它说的是发起者自己（或他的组织）收到过的东西，**他本来就看得见**，没有存在性可泄漏。

**被分享来的，既不能再分享，也不能复制出去**（[§6.13](../../../../product/PF-003-asset-transfer-and-sharing/design.md#613-分享不可传递)）——**组织内被分享来的、本人型分享来的也一样**。
它从来不归被分享方，上表已经挡住；`notTransitive` 只是把这一支的**原因**说清楚。

### S-14 plugin 的复制与分享

**[plugin](../../../../ubiquitous_language/terms/capabilities-and-composition.md#ul-plugin--插件--plugin) 的内含成员随它一并过去，不取得独立的记录、血缘、分享或持有**（[§6.9](../../../../product/PF-003-asset-transfer-and-sharing/design.md#69-复制或分享一个-plugin)；
[PF-002 §4 Plugin](../../../../product/PF-002-assets-settings-and-permissions/design.md#plugin)：内含成员「随 Plugin 的版本与使用权一起治理」）。
本契约搬运与授权的**始终是 plugin 那一份记录的那一版内容**；成员在不在那份内容里，是 plugin 正文形状的事。

**plugin 里「引用」的能力标识不跟着走**，由落点那一侧自己求值（[PF-002 §6.3](../../../../product/PF-002-assets-settings-and-permissions/design.md#63-组合的引用指向能力标识)）。
**发起时就告知**哪些引用在落点那一侧**没有提供者**（[flows §二](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#二分支与异常)）：
[S-20](#s-20-发起复制)、[S-24](#s-24-发起分享) 的 ⑤ 在返回之外另带一份**告知清单**——
那一版内容引用的能力标识里，落点那一层**此刻求值能够到的各层**（组织级落点：那个组织的组织层与出厂默认层；租户级落点：再加那个租户的租户层）**都没有持有**的那些。
**它是告知，不是拒绝**：清单非空也照常发出（或照常落地）。
**「内含」与「引用」怎么从 plugin 正文里分出来**，取决于 `data.asset-model` 的 plugin 外壳；那份形状目前只列一种成员——[缺口 G-5](#十一已知缺口)。
在它闭合之前，**告知清单按「引用」一支为空处理，不得把内含成员当成引用去报缺提供者**。

### S-49 方向与落点：矩阵逐格

**复制的落点与分享的被分享方都是一层**（`ScopeLayerIdentity`）。**是哪一种、要谁点头，由「源归谁」与「落到哪一层」决定，不由发起者选**。
下面两张表是 [PF-003 §6.2](../../../../product/PF-003-asset-transfer-and-sharing/design.md#62-谁能流向谁) 三条规则与矩阵的逐格落点；**表里没有的组合一律拒绝**，不自行补一格（§6.2「表里没有的组合，回到产品设计确认」）。

**复制**（源的所有者按 [S-13](#s-13-发起者一侧的资产)；「落点组织」记 Ot，发起者 = (Os, a)）：

| 源 | 落点 | 结果 | 依据 |
|---|---|---|---|
| 他的（个人组织里的，或团队 Os 里他租户级的） | **他自己在 Ot 的租户级** (Ot, a) | **本人型**：发起即落地；(Ot, a) 须此刻是有效成员，否则 `notPermitted`；边界按 [S-12](#s-12-流转边界团队资产不出那棵树) 复制边界 | 规则 3；§6.3；[flows §1.1](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#11-把个人组织里的东西复制给团队)、[§1.3](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#13-把自己在-a-公司的私人工具带到-b-公司) |
| 他个人组织里的 | **团队 Ot 的组织级** | **本人型**：发起即落地；**(Ot, a) 须此刻是 Ot 的有效超管**，否则 `notPermitted` | §6.2「落在哪一层」：超管从个人组织复制进本团队可选组织级；普通成员落不了（[flows §二](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#二分支与异常)） |
| 团队 Os 里他租户级的 | 另一个组织的组织级 | **`layerNotAllowed`** | §6.3 表：「本人型只落我自己的租户级，组织型只从组织级出发」 |
| 团队 Os 组织级的 | **同树团队 Ot 的组织级** | **组织型**：产生复制通知，**Ot 的超管确认之后**落地（[S-22](#s-22-确认复制)）；发起者须是 Os 的超管 | 规则 2；§4 资产复制；[flows §1.9](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#19-集团把模板复制给子公司) |
| 团队 Os 组织级的 | 任何一个租户级 | **`layerNotAllowed`** | 规则 2：同树只有组织—组织；矩阵「T 的超管，动组织级的 → 同树 T′ 里我的租户级：不可以」 |
| 任何 | **另一个组织里别人的租户级** (Ot, x)，x ≠ a | **`targetLayerNotSelf`** | §6.3「跨组织为什么落不到别人的租户级」；[flows §二](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#二分支与异常)；acceptance §二 |
| 任何 | 发起者**自己的组织**里的任何一层 | `invalidInput` | 资产复制按定义在两个组织之间（§4）；本组织里给同事用走组织内分享，交给组织走提升 |

**分享**（记被分享方所在的组织 Or）：

| 源 | 被分享方 | 结果 | 依据 |
|---|---|---|---|
| 团队 Os 组织级的 | **同树团队 Or**（组织） | **组织—组织**：分享邀请，Or 的超管确认；发起者须是 Os 的超管 | 规则 2；[flows §1.4](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#14-集团给子公司分享标准组件) |
| 团队 Os 组织级的 | 本组织里的一个租户，或别的组织里的一个租户 | **`layerNotAllowed`**（别的组织里别人的，先收 `targetLayerNotSelf`） | 矩阵：本组织的「不需要分享：组织级资产谁能用是『谁可以使用它』」；别处我的「不可以（规则 2）」 |
| 他个人组织里的 | **另一个个人组织**（组织） | **个人—个人**：分享邀请，对方账号本人确认 | [flows §1.5](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#15-两个人之间分享) |
| 他个人组织里的 | 一个团队组织（组织） | **`layerNotAllowed`** | 「个人组织 → 团队的组织级只有复制，没有分享」（§6.2 怎么读这张表） |
| 他个人组织里的 | **他自己在团队 Or 的租户级** (Or, a) | **本人型**：发起即成立；(Or, a) 须此刻是有效成员，否则 `notPermitted` | 规则 3；矩阵「个人组织下的租户 → 我在 T 的租户级：复制和分享」 |
| 团队 Os 里他租户级的 | **本组织另一个成员的租户级** (Os, x)，x ≠ a | **组织内分享**：分享邀请，那个租户本人确认；(Os, x) 须此刻是有效成员，否则 `recipientNotMember` | 规则 1；[flows §1.10](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#110-把我租户级的工具分享给同事)；[flows §二](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#二分支与异常)「组织内分享的接收者不在本组织 → 拒绝」 |
| 团队 Os 里他租户级的 | **他自己在同树团队 Or 的租户级** (Or, a) | **本人型**：发起即成立；(Or, a) 须此刻是有效成员 | 规则 3 |
| 团队 Os 里他租户级的 | 另一个组织（组织） | **`layerNotAllowed`**（不同树、或是个人组织，先收 `outsideTree`） | 规则 2：同树只有组织—组织 |
| 任何 | **另一个组织里别人的租户级** | **`targetLayerNotSelf`** | 同复制那一行 |
| 任何 | 发起者自己的组织（组织级），或发起者自己这个租户 | `invalidInput` | 不是一次分享：组织级的东西谁能用归「谁可以使用它」，给自己不需要分享 |

**判定的先后**（各操作 ⑥ 照此排）：`invalidInput` → **`targetLayerNotSelf`**（纯值：被分享方或落点是租户、组织不是发起者的组织、账号不是发起者的账号——**不读任何记录**，与「目标即源组织」同一类先判）→
发起者成员资格 → [S-13](#s-13-发起者一侧的资产) → 版本 → **`outsideTree`**（[S-12](#s-12-流转边界团队资产不出那棵树)）→ **`layerNotAllowed`** → 落点那一侧的成员资格与角色（`recipientNotMember`、`notPermitted`）。
**边界先于层**：「我租户级的 → 另一棵树上一个组织的组织级」两条都不成立，答的是 `outsideTree`——不出树是那条系统级不变量，比「这一层到不了」更根本。

**两个新值为什么不并进已有的值**：
`targetLayerNotSelf` 与 `outsideTree` 不同——边界成立（同树），错的是**那一层归别人**；换一个自己的落点就成。
`layerNotAllowed` 与 `outsideTree` 不同——同一对组织之间有别的层走得通（组织级到组织级、我的租户级到我的租户级）。
`recipientNotMember` 与 `notPermitted` 不同——`notPermitted` 说的是**行为人**（发起者、确认者）自己的资格；组织内分享的接收者不是行为人，他不在本组织里，是这份邀请**没有对象**。
**它不泄漏什么**：本组织的有效成员名单对每一位有效成员可见（`capability.organization-governance/v3` 的 S-59 默认档），已解除的与从未加入的都收同一个值。

---

## 三、贯穿全部操作的四条规矩

### S-15 结构性禁止不是权限判定

`outsideTree`、`officialNotTransferable`、`notTransitive`、`targetLayerNotSelf`、`layerNotAllowed`、`recipientNotMember` 是**结构性禁止**：
答案由组织变体、隶属树、资产来源与所有者、落点那一层、接收者的成员资格决定，**与发起者的角色无关**——超级管理员来做也是同一个答案。
`notPermitted` 是**权限判定**：答案随行为人自己的成员资格与角色变化。**两类不合并**：
[flows §二](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#二分支与异常)把「跨树」「落到别人的租户级」与「普通成员试图落组织级」「发起者不是源组织的超管」写成不同的行，收场与该去做的事都不同。

**结构性禁止可以不发起操作就预先求出**：组织变体与上级链（`capability.organization-governance/v3#S-22`、`#S-34`）、
资产的来源与所有者（资产治理的读面）、本组织成员名单都有读面。界面据此不呈现「个人组织 → 团队组织级的分享」入口；操作侧仍以同一个值兜底，**两处必须同答**。

### S-16 缺席时的默认答案

**一律拒绝或明确失败，不放行、不空集、不回退、不填初值。**三类分开：

| 情形 | 结果 | 为什么不合并 |
|---|---|---|
| 判定得出「不该放行」 | 一个**具名拒绝值** | 成立的结论，重试不会改变答案 |
| 判定**做不出来**（存储、成员资格读面、组织读面、上级链、**隶属建立时刻与成员关系生效时刻**、时间源、资产治理读面任一读不到） | **`unavailable`** | 没有结论；按当时实际状态重试可能不同（`data.identity-values/v1#S-19`、`data.offer-expiry/v1#S-16`、`#S-20`） |
| 输入**根本不构成这个请求**：字段缺席、类型不对、标识不合 `data.identity-values/v1#S-31` 的词法、判别式不在闭合集合内（`#S-32`）、时长非正或不合形状；**以及复制的落点在发起者自己的组织里、分享给发起者自己的组织（组织级）或他自己这个租户** | **`invalidInput`**，在任何判定之前 | 表示层校验不是判定结果（`data.identity-values/v1#S-33`）；「错在这次调用本身」，重试一万次也不会成 |

**最后那一格要单独说**：它们只比身份值即可判出，不读任何记录。
它说的**不是「对象不存在」也不是「主体无资格」**，而是「这不是一次复制／分享」——资产复制按定义在**两个不同组织**之间，分享按定义给**另一方**。
**主线没有为它单列一个值，本契约收进 `invalidInput`**（整批对齐时已报主线并接受（D-060 §七 N-18））。

**`unavailable` 这个名字取自 `capability.organization-governance` v3 的同一收场**，与资产治理同名（主线裁定，文首）。
没有它，「判不出来」就只能被折进某个拒绝值——那正是本条要禁的。

**任何身份参数都没有默认值**：`TenantId`、`OrganizationId`、`ScopeLayerIdentity`、`AssetRecordId`、`CopyNoticeId`、`SharingInvitationId`、`SharingId`
缺席即 `invalidInput`，不得由当前租户身份、进程上下文或环境补齐（`data.identity-values/v1#S-17`、`#S-18`）。**落点与被分享方也一样**：普通成员复制进团队「只落他自己的租户级」是**判定的结果**，不是落点缺席时的默认值——不给落点就是 `invalidInput`。

**带默认值的非身份参数，逐一列出，这张表是穷举的**：

| 参数 | 在哪 | 缺席时 |
|---|---|---|
| 这一份的有效时长 | [S-20](#s-20-发起复制) ①、[S-24](#s-24-发起分享) ① | 该类的默认 `offer_ttl`（部署配置，`data.offer-expiry/v1#S-14`）。**缺席按默认，非法拒绝**——两件事。**只对会产生待确认件的那一支有意义**：本人型那一支不产生待确认件，给了合法的时长也不读它，返回里写明没有待确认件 |
| 列表的过滤开关 | [S-30](#s-30-列出组织的分享) ① | 只要此刻 `active` 的，写死在条款里，不是部署配置 |
| **尝试键** | [S-20](#s-20-发起复制) ① | **本次不去重**。它没有「默认值」——缺席就是一种取值（与 `capability.organization-governance/v3#S-21` 的创建键、`capability.asset-governance/v2#S-24` 的 `creationKey` 同型） |

### S-17 每道准入现读，确认时再判一遍

**成员资格、角色、隶属关系、资产的所有者与持有，在每一次准入时现读**（`data.identity-values/v1#S-27`）。
**确认是一道准入**：发起那一刻判过的条件，在确认的同一次提交里**再判一遍**，能变的那几条逐一列在 [S-22](#s-22-确认复制) ②、[S-26](#s-26-确认分享) ②。
**本人型没有确认**：它的全部判定与落地在发起的同一次提交里，没有「发起之后、落地之前」这段窗口。

**这条不是谨慎，是 [PF-003 §6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后) 的原话落点**：
成员退出之后「他**再也不能以那个租户的名义发起复制或分享**——那个租户随成员关系解除而不再有效」。
组织型复制与要点头的分享在**确认那一刻**才落地或成立；只在发起时判，一份他退出之前发出的通知就会在他退出之后以他代表的名义落地。

**确认时再判失败，待确认件保持原状**：不写终结记录，仍可被撤回、会照常过期；条件恢复（比如隶属重建）之后仍可再确认。

### S-18 确认是一次提交；同一落点的确认序列化

**落地（或成立）的全部效果在一次提交里同时成立**，没有中间态：

| 一起成立的 | 组织型复制（[S-22](#s-22-确认复制)） | 本人型复制（[S-20](#s-20-发起复制)） | 要点头的分享（[S-26](#s-26-确认分享)） | 本人型分享（[S-24](#s-24-发起分享)） |
|---|---|---|---|---|
| 过期重判（`data.offer-expiry/v1#S-10`，含 [S-7](#s-7-两类待确认件共用的过期语义) 的存在性） | ✓ | —（没有待确认件） | ✓ | — |
| [S-17](#s-17-每道准入现读确认时再判一遍) 的再判／发起时的全部判定 | ✓ | ✓ | ✓ | ✓ |
| 落地 | [S-10](#s-10-复制血缘怎么判怎么记) 的判定 ＋ [S-11](#s-11-复制的收场) 的写集合 | 同左 | 新建或认回分享 ＋（能取则）被分享方那一层的持有 | 同左 |
| 终结记录 `accepted` | ✓ | — | ✓ | — |

**落地的写集合落在资产治理的存储对象上**（资产记录、版本、持有），**终结记录与分享记录落在本契约的存储对象上**；
**两者由同一提供者在同一次提交内完成**（主线裁定 D-060 §一 PA-3，文首），经资产治理的组合入口（[`capability.asset-governance/v2#S-46`](../../asset-governance/v2/contract.md#s-46-组合入口资产流转的确认步骤)）写，**不另写一份写面**；单机由装配给（同一存储、同一事务，[S-34](#s-34-装配给的保证-vs-协议须给的保证)），
提供者设计必须指出这次事务覆盖的**全部存储对象**——少一个，就会留下「记录建了、通知还悬着」或「通知确认了、记录没建」的中间态。

**同一落点上的落地序列化**：

- 对同一 (源记录, 落进的那一层) 的两次落地——组织型的两次确认、本人型的两次发起，或一次确认与一次发起——**不得交错**：否则两次都读到「还没有带这条血缘的记录」、各建一份，下一次重复复制不知道该覆盖哪一份；
- 对同一 (资产, 被分享方) 的两次成立同理——否则各建一份生效的分享，违反 [S-8](#s-8-分享)。
- **带同一尝试键的两次发起**（同一 (发起者, 尝试键)，[S-20](#s-20-发起复制) ⑦）同理——否则两次都读到「这个键还没登记」、各落一次地，本人型就多发布一个版本。**同一 (发起者, 尝试键) 至多一条登记**，登记与那一次发起的写入同一次提交。

**前两条有模型反例撑着**：把落地拆成「读—写」两步，TLC 给出正是这两种局面（[formal 入口](formal/README.md)）；第三条的证据是场景（[S-40](#s-40-首次重复撞标识无血缘按层找) 的重放一支）。

**删除与提升那一次提交也一并结束分享**（[S-52](#s-52-分享方删除资产或所有权易手分享随之结束)）：那次提交由资产治理发起，本契约的分享记录与资产治理的记录同一提供者、同一事务写下，同样没有中间态。

---

## 四、操作

### S-19 这一节每个操作写全九件事

①输入 · ②前置与授权 · ③结构性禁止（[S-15](#s-15-结构性禁止不是权限判定)，不适用写「无」）· ④提交点与原子性 · ⑤成功返回 ·
⑥失败集合（**闭合枚举，没有「其他」；按判定次序排列**，同一输入同一答案）· ⑦幂等与重复 · ⑧缺席时的默认答案 · ⑨事件。

**每个操作的 ⑥ 都含 `invalidInput` 与 `unavailable`**，逐条列出、不省略。

**操作名是规格层名字（无词条）**：`issueCopyNotice`、`issueSharingInvitation` 的本人型那一支**不产生待确认件**、`listPendingForOrganization` 也列给租户的那一类——名字与含义的出入已报主线并接受（D-060 §七 N-18），**改名只动名字，不动本节的九件事**。

**失败值总表**（本契约的全部失败值，含义以这里为准）：

| 值 | 含义 | 类 |
|---|---|---|
| `invalidInput` | 输入不构成这个请求（[S-16](#s-16-缺席时的默认答案) 第三行） | 表示层 |
| `notPermitted` | **行为人**条件不成立：发起者／确认者／撤回者／撤销者／移除者的成员资格此刻无效、角色不够（动组织级的不是超管；本人型落组织级而他不是那个组织的超管）；**本人型落点那一侧他自己的成员资格无效**；**确认时再判发起者**也在这里（[S-17](#s-17-每道准入现读确认时再判一遍)） | 权限 |
| `outsideTree` | [S-12](#s-12-流转边界团队资产不出那棵树) 的边界不成立（含落点／被分享方组织不存在） | 结构 |
| `targetLayerNotSelf` | 落点或被分享方是**另一个组织里别人的租户级**（[S-49](#s-49-方向与落点矩阵逐格)） | 结构 |
| `layerNotAllowed` | 这一对组织之间**这一层**没有路：租户级落进另一个组织的组织级、组织级落进或分享到任何租户级、个人组织分享到团队组织级（[S-49](#s-49-方向与落点矩阵逐格)） | 结构 |
| `recipientNotMember` | 组织内分享的被分享租户此刻不是本组织的有效成员（[S-49](#s-49-方向与落点矩阵逐格)） | 结构 |
| `sourceNotOwned` | 不是发起者一侧的现有资产（[S-13](#s-13-发起者一侧的资产)），不区分原因 | 结构 |
| `versionNotPublished` | 复制：给的版本号不是那份记录的已发布版本（草稿不可复制）；分享：那份资产一个已发布版本都没有。与资产治理的同名值同义（主线裁定，文首） | 结构 |
| `officialNotTransferable` | 源是官方件 | 结构 |
| `notTransitive` | 源是发起者（或他的组织）**被分享来**的 | 结构 |
| `noticeNotFound` / `invitationNotFound` / `sharingNotFound` | 按标识找不到，**或调用方不是有权看见它的那几类人**（不泄漏存在性，同 `capability.organization-governance/v3` 按不透明标识定位的那一组） | 定位 |
| `offerNoLongerValid` | **确认路径**：这份待确认件已不可被确认——**过期、已撤回、已确认过三种来路给同一个值**（`data.offer-expiry/v1#S-13`） | 结论 |
| `alreadyConcluded` | **撤回路径**：它已被确认，或已按 `data.offer-expiry/v1#S-8` 过期——已有一条本操作不会再写的结论，撤不了，**不写终结记录** | 结论 |
| `unavailable` | 判定做不出来（[S-16](#s-16-缺席时的默认答案)） | 失败 |

> **`offerNoLongerValid` 与 `alreadyConcluded` 都取 `capability.organization-governance` v3 的同一收场的名字**（主线裁定，文首）：`data.offer-expiry/v1#S-13` 要求**确认路径上三种来路收同一个值**；
> 撤回路径上「已确认」与「已过期」对撤回者也只有一个后果：撤不了，也不必撤。**同一收场一个失败值**。
> **`targetLayerNotSelf`、`layerNotAllowed`、`recipientNotMember` 是 2026-09-24 修订新增**（本契约的惯例是 lowerCamel），**名字是主线裁定**（D-060 §三 R2-8；`layerNotAllowed` 另被资产治理借作「组织层不收凭据类项」的拒绝值，同一类失败同名）；
> 修订时举例的 `cross_tree` 就是已有的 `outsideTree`、`org_copy_requires_admin` 就是已有的 `notPermitted`——同一收场一个值，不另起。
> 原 `organizationAssetNotCopyable` **随 rev 5 取消**：组织级资产可以组织型地复制，它挡的那一格已不存在。

**谁能做**（逐格标来源）：

| 操作 | 谁 | 来源 |
|---|---|---|
| 发起复制 · 本人型 | 源侧租户本人（任一角色）；落他自己的租户级时他在落点组织是有效成员；**落组织级时他在落点组织是有效超管** | **原话**：[flows §四](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#四角色与操作)「本人型复制」一行；[decisions §一](../../../../product/PF-003-asset-transfer-and-sharing/decisions.md#一拍板记录) 2026-09-24「普通成员……不需要超管确认」「超管……可以选择是组织级别」 |
| 发起复制 · 组织型 | 源组织的超级管理员 | **原话**：flows §四「组织型复制：超管可；普通成员不可」 |
| 确认复制 | 目标组织的超级管理员 | **原话**：flows §四「确认收到的组织型复制通知：超管可；普通成员不可」 |
| 撤回复制通知 | 发起者本人；**另加**源组织的任一有效超级管理员 | 发起者是原话（「撤回自己发出、尚未被确认的通知」）；**另加那一格是推导**：组织型的源是组织级资产，组织的东西由组织的超管收回——与撤回分享邀请那一格同一条推导 |
| 发起分享 · 组织—组织 | 源组织的超级管理员 | **原话**：flows §四「跨组织分享：超管可」 |
| 发起分享 · 个人—个人、组织内分享、本人型 | 资产的所有者本人（任一角色）；本人型另要他在被分享组织是有效成员 | **原话**：flows §四「组织内分享」「本人型分享」「个人间分享」三行 |
| 确认分享、移除收到的分享 | 被分享方是组织 ⇒ 它的有效超级管理员（个人组织：那个账号本人）；被分享方是租户 ⇒ **那个租户本人** | **原话**：flows §四「谁能确认，谁就能移除」；§6.2「确认由谁做」 |
| 撤回分享邀请、撤销分享 | 发起者本人；资产此刻归组织所有时，**另加**该组织的任一有效超级管理员 | **推导**：原话「撤回／撤销自己发出的」——组织的东西由组织的超管收回，个人的东西只有本人收回。**分享方是租户而他已退出**：分享随之结束（[S-32](#s-32-成员关系解除复制执行不了已确认的不动)），不需要谁来撤销（原 G-7 闭合） |
| 读复制通知 | 发起者本人；源组织与目标组织的有效超级管理员 | **推导**（接收方要看得见才能决定，[flows §3.4](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#34-一份待确认的邀约复制通知与分享邀请同形)「接收方那边可见」；源组织的超管能撤回，就要看得见） |
| 读分享邀请 | 发起者本人；资产归组织时该组织的超管；被分享方那一侧能确认它的人 | 推导，同上 |
| 列出组织的分享 | 见 [S-30](#s-30-列出组织的分享) ② | 推导 |
| 列出收到的待确认件 | 那一层能确认它们的人：组织的有效超管，或那个租户本人 | 推导（同 [S-23](#s-23-读复制通知)／[S-27](#s-27-读分享邀请) ②） |

### S-20 发起复制

`issueCopyNotice`

| # | 内容 |
|---|---|
| ① | 发起者 `TenantId` (Os, a)（**源侧**）、源 `{ AssetRecordId, 版本号 }`、**落点 `ScopeLayerIdentity`**、**可选：这一份的有效时长**（缺席按复制通知这一类的默认值；本人型那一支不读它，[S-16](#s-16-缺席时的默认答案)）、**可选：尝试键** `attemptKey`——调用方生成的不透明去重标识，词法按 `data.identity-values/v1#S-31`；**缺席不是拒绝，是「本次不去重」**（[S-16](#s-16-缺席时的默认答案) 的表有它一行；主线裁定 D-060 §三 R2-5） |
| ② | 发起者源侧成员资格**有效**；源是**发起者一侧的现有资产**（[S-13](#s-13-发起者一侧的资产)，组织级的要他是超管）；版本号是它的**已发布版本**；[S-12](#s-12-流转边界团队资产不出那棵树) 复制边界成立；落点按 [S-49](#s-49-方向与落点矩阵逐格) 复制那张表有路；**本人型**：(落点组织, a) 此刻有效，落组织级时是那个组织的超管 |
| ③ | **有**：`targetLayerNotSelf`、`officialNotTransferable`、`notTransitive`、`outsideTree`、`layerNotAllowed` |
| ④ | **本人型——单次提交落地**（[S-18](#s-18-确认是一次提交同一落点的确认序列化)）：全部判定 ＋ [S-10](#s-10-复制血缘怎么判怎么记) 的首次／重复判定 ＋ [S-11](#s-11-复制的收场) 的写集合（经资产治理的组合入口，行为人是 (落点组织, a)），受同一 (源记录, 落点) 的序列化约束；**不写任何待确认件**。**组织型——单次提交**写一份复制通知，`OfferTiming` 在这次提交内定死（`data.offer-expiry/v1#S-5`）；**发起不求过期判定式**（`#S-20`），但②的「所有者那一层此刻持有它」在这次提交内现读。**两支都一样：带键时，尝试键登记 (发起者, 尝试键) → 这一次的结果，与这一次的写入同一次提交**（[S-18](#s-18-确认是一次提交同一落点的确认序列化) 第三条） |
| ⑤ | **本人型**：`landed{ CopyOutcome }`；**组织型**：`pending{ CopyNoticeId }`。**源是 plugin 时另带告知清单**（[S-14](#s-14-plugin-的复制与分享)），否则清单为空 |
| ⑥ | 按判定次序：`invalidInput`（含落点在发起者自己的组织里）→ `targetLayerNotSelf` → `notPermitted`（源侧成员资格）→ **（带键且键已登记 ⇒ 按 ⑦ 认回，不再往下判）** → `sourceNotOwned` · `officialNotTransferable` · `notPermitted`（组织级而他不是超管）· `notTransitive`（[S-13](#s-13-发起者一侧的资产) 的次序）→ `versionNotPublished` → `outsideTree` → `layerNotAllowed` → `notPermitted`（本人型：落点那一侧他自己的成员资格与角色）；**任一步读不到 ⇒ `unavailable`**。**失败集合不因尝试键增减** |
| ⑦ | **带键：同一 (发起者, 尝试键) 在保留期 `copy_attempt_key_retention`（部署配置，具名参数，本契约不填值）内重放 ⇒ 返回首次那一次的结果——本人型 `landed{ CopyOutcome }`、组织型 `pending{ CopyNoticeId }`——不写任何东西**：本人型**不多发布一个版本**，组织型不多出一份通知（主线裁定 D-060 §三 R2-5）。这是 [PF-001 §6.8](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#68-管理结果)「未知结果之后的重试认回同一逻辑操作」在本操作上的兑现处，形制与 `capability.organization-governance/v3#S-21` 的创建键、`capability.asset-governance/v2#S-24` 的 `creationKey` 相同。重放时其余输入与首次不同，**仍认回首次那一次**，以返回值为准；键的作用域是发起者这个租户身份，别人用同一个键互不相干；**首次那一次被拒或失败时什么都没登记**，重放按一次新的发起判；过了保留期同键 ⇒ 一次新的发起。**两支都认回，不是只认本人型**：走哪一支由系统按源与落点判定、不由发起者选（[S-49](#s-49-方向与落点矩阵逐格)），键若只在一支里起作用，调用方就得先知道自己走的是哪一支。**不带键 ⇒ 不去重**：组织型每次一份新的通知（过期与撤回是它们的收场，多几份不制造新状态；两份都被确认时第二份按血缘判为重复，[S-18](#s-18-确认是一次提交同一落点的确认序列化) 保证不建第二份记录）；本人型重放按血缘判为重复，**不会建出第二份记录**，但会再发布一个内容相同的新版本——**要认回，就带键** |
| ⑧ | 成员资格、资产治理读面、组织读面、上级链、**尝试键登记**任一读不到 ⇒ `unavailable`，**不得按「读不到就不是成员／不在树上／不是他的」拒绝**，**也不得在读不到键登记时当成「没见过这个键」去落地**——那正是回执丢失之后最常见的重复来路；**本人型的落地面在这次提交里失败 ⇒ 整次失败，什么都不写**（键也不登记）；**组织型：调用上下文里缺「这一次是不是 agent 产出」（`byAgent`）⇒ `unavailable`，不写通知**（[S-11](#s-11-复制的收场) 末段；主线裁定，见 [D-060 §七 M27](../../../../record/decisions/mainline-self-rulings-2026-09/decision.md#七s25-第二轮独立复评之后的主线裁定m1m292026-09-25-追加)）；身份参数缺席或不合形状、时长非正、**尝试键给了但不合形状** ⇒ `invalidInput` |
| ⑨ | 不发（[S-33](#s-33-本版不发本契约自己的事件)）；本人型落地的发布与持有变化由资产治理那一侧的事件承载 |

**先判纯值、再读记录**：落点在发起者自己的组织里、落点是另一个组织里别人的租户级，两条都在读任何记录之前判掉（[S-16](#s-16-缺席时的默认答案)、[S-49](#s-49-方向与落点矩阵逐格)）；源侧成员资格先于任何资产读面——一个此刻不在源组织里的人，拿不到关于那份资产的任何回答。

**本人型不需要第二个人**（[PF-003 §6.2「确认由谁做」](../../../../product/PF-003-asset-transfer-and-sharing/design.md#62-谁能流向谁)）：落进的那一层由发起的人自己管——他自己的租户级，或（他是超管时）那个组织的组织级。**普通成员落不了组织级**：`notPermitted`，说明组织级由超级管理员管。

### S-21 撤回复制通知

`withdrawCopyNotice`

| # | 内容 |
|---|---|
| ① | 撤回者 `TenantId`、`CopyNoticeId` |
| ② | 撤回者是这份通知的发起者，且在源组织成员资格**有效**；**或**是源组织的有效超级管理员（[S-19](#s-19-这一节每个操作写全九件事) 的「谁能做」，推导） |
| ③ | 无 |
| ④ | 单次提交，**先现读一次过期判定**（`data.offer-expiry/v1#S-8` 的反方向）：`pending` ⇒ 写终结记录 `withdrawn`（带撤回者与时刻）；其余不写 |
| ⑤ | `ok` |
| ⑥ | `invalidInput` → `noticeNotFound`（不存在，或撤回者不属于②那两类人）→ `notPermitted`（撤回者此刻不是源组织的有效成员）→ `alreadyConcluded`；读不到 ⇒ `unavailable` |
| ⑦ | **幂等到本操作自己写的那条记录**：已 `withdrawn` ⇒ `ok`，无二次效果。已 `accepted` 或已过期 ⇒ `alreadyConcluded`，**不写终结记录** |
| ⑧ | 通知读不到、时间源读不到、**存在性读面读不到**（`data.offer-expiry/v1#S-20`）⇒ `unavailable`，**不写终结记录**，**不得据读不到判成已过期**；缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | 不发 |

**只有组织型有复制通知可撤**；本人型发起即落地，要收回走资产治理的移除或删除——那是落点那一层自己的事，不是撤回。

### S-22 确认复制

`confirmCopy`

| # | 内容 |
|---|---|
| ① | 确认者 `TenantId`、`CopyNoticeId` |
| ② | 确认者的组织**就是**这份通知的目标组织，成员资格**有效**且是**超级管理员**；这份通知按 `data.offer-expiry/v1#S-8` 求值为 `pending`——**这次求值在落地的同一次提交内做**（`#S-10`）。**再判**（[S-17](#s-17-每道准入现读确认时再判一遍)）：发起者仍是源组织的**有效超级管理员**（**推导**：发起是源组织借他之手的决定，他已不代表源组织时这份决定不再有人担着；已报主线并接受（D-060 §七 N-18））；[S-12](#s-12-流转边界团队资产不出那棵树) 的复制边界仍成立 |
| ③ | **有**：`outsideTree`（发起后隶属解除） |
| ④ | **单次提交**（[S-18](#s-18-确认是一次提交同一落点的确认序列化)）：过期重判 ＋ 再判 ＋ [S-10](#s-10-复制血缘怎么判怎么记) 的首次／重复判定（落点是目标组织的组织级）＋ [S-11](#s-11-复制的收场) 的写集合（行为人是确认者）＋ 终结记录 `accepted`（带确认者、时刻与 `CopyOutcome`），**全部同时成立**；受同一 (源记录, 目标组织级) 的序列化约束 |
| ⑤ | `CopyOutcome`（[S-11](#s-11-复制的收场)） |
| ⑥ | `invalidInput` → `noticeNotFound`（不存在，或确认者的组织不是目标组织）→ `notPermitted`（确认者不是目标组织的有效超管）→ `offerNoLongerValid`（过期、已撤回、已确认，三路同值）→ `notPermitted`（发起者已不是源组织的有效超管）· `outsideTree`（再判）；读不到 ⇒ `unavailable` |
| ⑦ | **同一份通知再确认 ⇒ `offerNoLongerValid`**（`accepted` 是 `data.offer-expiry/v1#S-13` 的第三条来路），**不产生第二份效果**。**再判失败不写任何东西**，通知仍 `pending` |
| ⑧ | 过期判定读不到（时间源、存在性读面）⇒ `unavailable`，**不得放行，也不得判成已过期**（`#S-20`）；成员资格、组织读面、上级链、资产治理读面任一读不到 ⇒ `unavailable`，**不得在读不到的情况下落地，也不得把它说成越界**；缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | 本契约不发。落地的发布与持有变化由资产治理那一侧的事件承载（`AssetPublished`、`HoldingChanged`，名字归那份契约） |

**确认这一步点头的是「用源侧这一版整个盖掉我们这份」**（[flows §1.2](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#12-改好了再复制一次)）——
**它要在 [S-23](#s-23-读复制通知) 读得到那一版的内容与「这次是首次还是重复」之后做**，否则确认者无从知道自己点头的是什么。
**确认者就是这一份的作者**（[§6.5](../../../../product/PF-003-asset-transfer-and-sharing/design.md#65-首次复制)：组织型的作者是 (目标组织, 确认的那位超级管理员)）。

### S-23 读复制通知

`readCopyNotice`

| # | 内容 |
|---|---|
| ① | 读者 `TenantId`、`CopyNoticeId` |
| ② | **三类人之一**：发起者本人（源侧成员资格有效）；源组织的有效超级管理员；目标组织的有效超级管理员。**其余一律 `noticeNotFound`** |
| ③ | 无 |
| ④ | 只读，**派生状态在本次读取的时点求值**（`data.offer-expiry/v1#S-9`） |
| ⑤ | **按读者分两种投影**。**源侧**（发起者、源组织的超管）：通知的全部字段 ＋ 此刻的 `OfferState` ＋ 已确认时的 `CopyOutcome`。**目标侧**：`CopyNoticeId`、**源组织的 `OrganizationId`**（主线裁定 D-060 §三 R2-6：确认的超管要知道东西从哪来才能判）、能力标识、源版本号、**那一版的内容**、`OfferTiming`、此刻的 `OfferState`、**此刻确认会是首次还是重复**（按 [S-10](#s-10-复制血缘怎么判怎么记) 现判；重复时带被覆盖的那份目标记录的 `AssetRecordId`）、已确认时的 `CopyOutcome`——**不含源资产本身**：源记录号、它的其余版本与草稿，以及源侧的发起者租户身份 |
| ⑥ | `invalidInput` → `noticeNotFound`；读不到 ⇒ `unavailable` |
| ⑦ | 只读；**返回的派生状态与首次／重复判断都不得被缓存后复用** |
| ⑧ | 通知、时间源、存在性读面、成员资格任一读不到 ⇒ `unavailable`，**不得把派生状态填成 `pending`，不得据存在性读不到判成 `expired`**，也**不得把成员资格读不到收成 `noticeNotFound`**——那是把失败说成「没有这份」；缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | 不发 |

**目标侧那种投影为什么要去掉源资产本身**：[「能看到由某租户在某时送进来第几版，看不到源资产本身」](../../../../product/PF-003-asset-transfer-and-sharing/design.md#复制血缘)。
**源组织的标识却要给**（主线裁定 D-060 §三 R2-6）：组织型的两侧是同一棵树上的两个团队组织，确认的超管不知道东西是哪个组织送来的，就无从判断要不要收；
它说的是「从哪来」，不是「源那边还有什么」。**本契约把那条裁定的「不带源资产正文」读为「不带源资产本身」**——送进来的**那一版的内容**照给，确认点头的就是它（下一句）。
**而它必须带着内容与首次／重复**：目标侧超管据此决定要不要让这一版「整个盖掉」自己那一份——[那正是把判定交给系统、却把点头留给目标组织的原因](../../../../product/PF-003-asset-transfer-and-sharing/design.md#资产复制)。

### S-24 发起分享

`issueSharingInvitation`

| # | 内容 |
|---|---|
| ① | 发起者 `TenantId` (Os, a)、`AssetRecordId`、**被分享方 `ScopeLayerIdentity`**、**可选：这一份的有效时长**（缺席按分享邀请这一类的默认值；本人型那一支不读它） |
| ② | 发起者成员资格**有效**；资产是**分享方一侧的现有资产**（[S-13](#s-13-发起者一侧的资产) 的「分享」一列：归他本人，或归他的组织——团队组织要他是超管）；那份资产**至少有一个已发布版本**；跨组织时 [S-12](#s-12-流转边界团队资产不出那棵树) 分享边界成立；被分享方按 [S-49](#s-49-方向与落点矩阵逐格) 分享那张表有路；**组织内分享**：被分享的租户此刻是本组织的有效成员；**本人型**：他在被分享组织的那个租户此刻有效 |
| ③ | **有**：`targetLayerNotSelf`、`officialNotTransferable`、`notTransitive`、`outsideTree`、`layerNotAllowed`、`recipientNotMember` |
| ④ | **本人型——单次提交成立**（[S-18](#s-18-确认是一次提交同一落点的确认序列化)）：全部判定 ＋ **新建或认回**分享（确认者 = 发起者，确认时刻 = 本次提交时刻，没有邀请）＋ **被分享的那个租户层此刻没有这个能力标识的持有 ⇒ 为它取得持有**（basis `shared`，带这份分享的 `SharingId`，版本选用恒为 `current`——组合 `capability.asset-governance/v2#S-30` 带 `sharing`，行为人是被分享的那个租户，即他自己）；**已有 ⇒ 不动那份持有**；受同一 (资产, 被分享方) 的序列化约束。**其余三种——单次提交**写一份分享邀请，`OfferTiming` 在这次提交内定死 |
| ⑤ | **本人型**：`effective{ SharingId, 是否取得了持有 }`；**其余**：`pending{ SharingInvitationId }`；资产是 plugin 时另带告知清单（[S-14](#s-14-plugin-的复制与分享)） |
| ⑥ | `invalidInput`（含被分享方是发起者自己的组织或他自己这个租户）→ `targetLayerNotSelf` → `notPermitted`（成员资格）→ `sourceNotOwned` · `officialNotTransferable` · `notPermitted`（资产归团队组织而发起者不是超管）· `notTransitive` → `versionNotPublished` → `outsideTree` → `layerNotAllowed` → `recipientNotMember`（组织内分享）· `notPermitted`（本人型：被分享那一侧他自己的成员资格）；读不到 ⇒ `unavailable` |
| ⑦ | **要点头的三种不幂等**，理由同 [S-20](#s-20-发起复制) ⑦；同一对的第二份邀请被确认时认回已有的那份生效的分享（[S-26](#s-26-确认分享) ⑦）。**本人型幂等**：同一 (资产, 被分享方) 已有一份生效的 ⇒ 认回它，返回同一个 `SharingId`，不新建 |
| ⑧ | 同 [S-20](#s-20-发起复制) ⑧；本人型的持有写入在这次提交里失败 ⇒ 整次失败，不建分享 |
| ⑨ | 不发；本人型取得持有由资产治理的 `HoldingChanged` 承载 |

**分享不要求双方是同一个人**（[§6.3](../../../../product/PF-003-asset-transfer-and-sharing/design.md#63-复制的通则同一自然人的两个租户身份)）：要点头的那三种没有落点那一侧行为人的资格判定，被分享方在 [S-26](#s-26-确认分享) 自己点头。
**组织内分享要给几个人，就分享几次**——每一段是分享方与一个同事之间的事（[flows §1.10](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#110-把我租户级的工具分享给同事)）。

### S-25 撤回分享邀请

`withdrawSharingInvitation`

| # | 内容 |
|---|---|
| ① | 撤回者 `TenantId`、`SharingInvitationId` |
| ② | 撤回者是这份邀请的发起者（成员资格有效），**或**资产此刻归分享方组织所有而撤回者是该组织的有效超级管理员（[S-19](#s-19-这一节每个操作写全九件事) 的「谁能做」，推导） |
| ③ | 无 |
| ④ | 同 [S-21](#s-21-撤回复制通知) ④ |
| ⑤ | `ok` |
| ⑥ | `invalidInput` → `invitationNotFound`（不存在，或撤回者不属于②那两类人）→ `alreadyConcluded`；读不到 ⇒ `unavailable` |
| ⑦ | 同 [S-21](#s-21-撤回复制通知) ⑦ |
| ⑧ | 同 [S-21](#s-21-撤回复制通知) ⑧ |
| ⑨ | 不发 |

### S-26 确认分享

`confirmSharing`

| # | 内容 |
|---|---|
| ① | 确认者 `TenantId`、`SharingInvitationId` |
| ② | **被分享方是组织**：确认者的组织就是它，成员资格**有效**且是**超级管理员**；**被分享方是租户**：确认者**就是那个租户**，成员资格**有效**。邀请求值为 `pending`，**同提交重判**。**再判**：发起者仍有权分享这份资产（[S-24](#s-24-发起分享) ②，按资产**此刻**的所有者；归团队组织的要他仍是超管，归他本人的要他仍是有效成员）；跨组织时 [S-12](#s-12-流转边界团队资产不出那棵树) 的分享边界仍成立 |
| ③ | **有**：`outsideTree`（发起后隶属解除） |
| ④ | **单次提交**（[S-18](#s-18-确认是一次提交同一落点的确认序列化)）：过期重判 ＋ 再判 ＋ **新建或认回**分享（新建时确认时刻 = 本次提交时刻）＋ **被分享方那一层此刻没有这个能力标识的持有 ⇒ 为它取得持有**（basis `shared`，带这份分享的 `SharingId`，版本选用恒为 `current`——组合 `capability.asset-governance/v2#S-30` 带 `sharing`，组织格或租户格）；**已有 ⇒ 不动那份持有** ＋ 邀请写终结记录 `accepted`，全部同时成立；受同一 (资产, 被分享方) 的序列化约束 |
| ⑤ | `SharingId` ＋「是否取得了持有」 |
| ⑥ | `invalidInput` → `invitationNotFound`（不存在，或确认者不是被分享方那一侧能确认它的人）→ `notPermitted`（确认者成员资格无效，或被分享方是组织而他不是超管）→ `offerNoLongerValid`（三路同值）→ `notPermitted`（发起者已无权分享）· `sourceNotOwned` · `outsideTree`（再判）；读不到 ⇒ `unavailable` |
| ⑦ | **同一份邀请再确认 ⇒ `offerNoLongerValid`**，不产生第二份效果。**同一 (资产, 被分享方) 已有一份此刻生效的分享 ⇒ 认回那一份**：返回它的 `SharingId`，不新建；这份邀请照样写 `accepted`（[S-8](#s-8-分享)）。**已有的那份记录仍为 `active` 但已不生效**（关系断过）⇒ 不认回，**新建一份**——那是新的一段 |
| ⑧ | 同 [S-22](#s-22-确认复制) ⑧ |
| ⑨ | 本契约不发；取得持有由资产治理的 `HoldingChanged` 承载 |

**「已有同标识的持有就不动它」**与复制撞标识是同一条道理：[被分享方对自己的求值链有支配权](../../../../product/PF-003-asset-transfer-and-sharing/design.md#610-分享给的是获权不是拥有)，
确认一份分享**不得静默替换**它那层已经选用的东西。使用权照样建立；它要用这份，自己用资产治理的写面换上——
那份持有可用与否，按 [S-9](#s-9-分享此刻是否生效) 在使用时判，**不回头问本契约**。

### S-27 读分享邀请

`readSharingInvitation`

| # | 内容 |
|---|---|
| ① | 读者 `TenantId`、`SharingInvitationId` |
| ② | 发起者本人；资产此刻归分享方组织时该组织的有效超级管理员；被分享方那一侧能确认它的人（组织：它的有效超管；租户：那个租户本人）。其余 `invitationNotFound` |
| ③ | 无 |
| ④ | 只读，读时求值 |
| ⑤ | 邀请的全部字段 ＋ 此刻的 `OfferState` ＋ 已确认时的 `SharingId`；**两端看到的是同一个投影**——被分享方用的就是分享方那份记录，没有需要对它藏的源 |
| ⑥ | `invalidInput` → `invitationNotFound`；读不到 ⇒ `unavailable` |
| ⑦ | 只读，不得缓存复用 |
| ⑧ | 同 [S-23](#s-23-读复制通知) ⑧ |
| ⑨ | 不发 |

### S-28 撤销分享

`revokeSharing`

| # | 内容 |
|---|---|
| ① | 撤销者 `TenantId`、`SharingId` |
| ② | 撤销者是这份分享的发起者（成员资格有效），**或**资产此刻归分享方组织而撤销者是它的有效超级管理员 |
| ③ | 无 |
| ④ | 记录为 `active`（含派生为 `dissolved` 的）⇒ 写 `revoked`（带撤销者、时刻与原因 `sharerRevoked`）。单次提交。**不碰被分享方的任何持有与配值**——那是对方那一层的事实，分享方写不到那里 |
| ⑤ | `ok` |
| ⑥ | `invalidInput` → `sharingNotFound`（不存在，或撤销者不属于②那两类人）；读不到 ⇒ `unavailable` |
| ⑦ | **已结束**（`revoked` 或 `removed`）⇒ `ok`，**不改写已有的结束记录**：各种结束[效果相同](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#32-一段分享关系)，撤销者要的「对方不再有使用权」已经成立 |
| ⑧ | 读不到 ⇒ `unavailable`；缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | 不发 |

**撤销向后生效**：影响的是被分享方**下一次**使用（[S-9](#s-9-分享此刻是否生效)），[不强停正在运行的工作](#s-36-撤销不发出停止信号)。
被分享方那层的持有与配值留着、**不可用**；它愿意可以自己[移除](#s-29-移除收到的分享)。

### S-29 移除收到的分享

`removeShared`

| # | 内容 |
|---|---|
| ① | 移除者 `TenantId`、`SharingId` |
| ② | **被分享方是组织**：移除者的组织就是它，成员资格有效且是超级管理员；**被分享方是租户**：移除者就是那个租户，成员资格有效 |
| ③ | 无 |
| ④ | **单次提交**：记录为 `active` ⇒ 写 `removed`；**并且**被分享方那一层若以 basis `shared` 持有这份资产，**移除那份持有**（组合资产治理的 `unhold`，配值随之消失——[移除就是不再持有](../../../../ubiquitous_language/terms/circulation-and-entitlement.md#ul-asset-removal--资产移除--asset-removal)） |
| ⑤ | `ok` |
| ⑥ | `invalidInput` → `sharingNotFound`（不存在，或移除者不是被分享方那一侧能移除它的人）→ `notPermitted`（移除者成员资格无效，或被分享方是组织而他不是超管）；读不到 ⇒ `unavailable` |
| ⑦ | **已结束 ⇒ 不改写结束记录**；若那份 shared 持有还在，照样移除它，返回 `ok`——被分享方在对方撤销之后、或关系断过之后清掉自己那层的残留，走的就是这条 |
| ⑧ | 读不到 ⇒ `unavailable`；缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | 本契约不发；持有变化由资产治理的 `HoldingChanged` 承载 |

**谁确认，谁就能移除**（[flows §四](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#四角色与操作)）：分享给组织的，普通成员移除不了；分享给我这个租户的，只有我能移除。

### S-30 列出组织的分享

`listSharings`

| # | 内容 |
|---|---|
| ① | 调用方 `TenantId`、`OrganizationId`、**可选过滤**：只要此刻 `active` 的，还是全部（**默认只要此刻 `active` 的**） |
| ② | 调用方是该组织的有效成员。**看得见哪些**（一项满足任一条即可见）：被分享方是**该组织**的——任一有效成员可见，他们用的就是这些（推导）；被分享方是**该组织里某个租户**的——只有那个租户本人；分享方是**该组织**（资产归组织）的——只有超级管理员；分享方是**该组织里某个租户**的——只有那个租户本人。[团队里他租户级的是他的私有部分](../../../../product/PF-003-asset-transfer-and-sharing/design.md#63-复制的通则同一自然人的两个租户身份)，超管也看不到组织内分享 |
| ③ | 无 |
| ④ | 只读，**每一项的 `SharingState` 在本次读取的时点求值**（[S-9](#s-9-分享此刻是否生效)：`dissolved` 是这一刻算出来的） |
| ⑤ | 列表，每项：`SharingId`、分享方、被分享方、`AssetRecordId`、能力标识、确认时刻、此刻的 `SharingState`；**`revoked` 的那几项带结束原因**（`sharerRevoked`／`sourceDeleted`／`ownerChanged`，[S-8](#s-8-分享)）。资产已被删除的那几项，能力标识一栏答「已删除」——资产治理的读面对一份已删除的记录只答这一句（[`capability.asset-governance/v2#S-64`](../../asset-governance/v2/contract.md#s-64-readasset-读一份资产记录)）；`AssetRecordId` 照列，它不回收不复用（[S-52](#s-52-分享方删除资产或所有权易手分享随之结束)） |
| ⑥ | `invalidInput` → `notPermitted`（调用方不是该组织的有效成员）；读不到 ⇒ `unavailable` |
| ⑦ | 只读 |
| ⑧ | 分享记录、成员资格、组织读面、上级链、**隶属建立时刻与成员关系生效时刻**任一读不到 ⇒ `unavailable`，**不得返回空列表或少了几项的列表**，也**不得把求不出的那几项判成 `dissolved` 或 `active`**；过滤开关不在集合内 ⇒ `invalidInput` |
| ⑨ | 不发 |

**失败值是 `notPermitted`，不是 `sharingNotFound`**：本条按组织定位，调用方本来就拿着自己的 `TenantId`，没有存在性可泄漏。

### S-48 列出组织收到的待确认件

`listPendingForOrganization`（主线裁定，文首）

| # | 内容 |
|---|---|
| ① | 调用方 `TenantId`、**接收的那一层 `ScopeLayerIdentity`** |
| ② | 那一层是组织 ⇒ 调用方是该组织的**有效超级管理员**；那一层是租户 ⇒ 调用方**就是那个租户**，成员资格有效——**能确认它们的就是这一类人**（[S-22](#s-22-确认复制)、[S-26](#s-26-确认分享) ②） |
| ③ | 无 |
| ④ | 只读，**每一项的 `OfferState` 在本次读取的时点求值**（`data.offer-expiry/v1#S-9`） |
| ⑤ | 列表：接收方是组织时——目标是它、此刻 `pending` 的复制通知，与被分享方是它、此刻 `pending` 的分享邀请；接收方是租户时——被分享方是它、此刻 `pending` 的分享邀请（组织内分享）。每项只带**它是哪一类、它的标识与 `OfferTiming`**——内容、首次还是重复、谁送来的，按标识调 [S-23](#s-23-读复制通知)／[S-27](#s-27-读分享邀请) 读，投影规则只在那两条里。可以为空 |
| ⑥ | `invalidInput` → `notPermitted`（调用方不是②那一类人）；读不到 ⇒ `unavailable` |
| ⑦ | 只读；派生状态不得缓存后复用 |
| ⑧ | 待确认件、时间源、存在性读面、成员资格任一读不到 ⇒ `unavailable`，**不得返回空列表或少了几项的列表**，也**不得据存在性读不到把一项判成已过期而不列**；缺席或不合形状 ⇒ `invalidInput` |
| ⑨ | 不发 |

**只列收到的一侧，只列 `pending` 的**：发起的一方拿着自己发出的标识，按 [S-23](#s-23-读复制通知)／[S-27](#s-27-读分享邀请) 读得到；已终结的在各自的终结记录里，不是「等着人去点头」的那一类。
**本人型没有待确认件**，这里不会出现它。**失败值是 `notPermitted`**，理由同 [S-30](#s-30-列出组织的分享)：按层定位，没有存在性可泄漏。

---

## 五、关系变化之后

### S-31 隶属解除：分享在使用时失效，不靠事件

**隶属关系解除（`capability.organization-governance/v3#S-33`）之后，此前靠那条隶属关系成立的分享失效**
（[§6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)：组织—组织，或我在同树两个组织的租户之间的本人型）；**复制下来的留着**。

**失效的兑现点是 [S-9](#s-9-分享此刻是否生效) 的使用时判定，不是一个事件的反应。**
`capability.organization-governance/v3#S-40` 已写死 PF-003 的分享失效**不靠 `affiliation.dissolved`**，
`data.identity-values` 的 [CS-4](../../../data/identity-values/v1/contract.md#cs-4-分享边界有共同上级) 同一句话：「失效是这个求值条件的结果，不依赖任何事件送达」。
靠事件，漏一次通知就留下一份仍在生效的分享——[模型在去掉使用时判定时给出了这条反例](formal/README.md)。

**关系断了之后又接上——重新隶属——分享不复活**（产品负责人 2026-09-24 裁定，[§6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)、[flows §1.8](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#18-隶属关系解除之后)）。
**它同样由 [S-9](#s-9-分享此刻是否生效) 的使用时判定兑现**：第三个合取项读**连接二者的隶属关系的建立时刻**，重新隶属写下的那一条晚于确认时刻，那份分享从此恒不生效。
**本版因此不对 `affiliation.dissolved` 做任何写入反应**：`dissolved` 是读时算出来的，**没有一条被写下的「已解除」记录**；
写一条会让「发了事件的部署」与「没发的部署」对同一份分享给出不同的后续答案——那是两份不同的契约。
**它也不靠「第一次读到失效时写一条终态」**：两次读之间解除又重建，那一条就永远没机会写下，分享照样复活——判定必须只依赖持久的时刻，不依赖有没有人恰好在断开期间读过。

要用，**分享方再分享一次、被分享方再确认一次——那是新的一段**（[flows §3.2](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#32-一段分享关系)「结束是终点」）；旧的那份记录仍为 `active`、永远 `dissolved`，分享方可以撤销、被分享方可以移除，二者都写下终态记录。

**两个时刻由 `capability.organization-governance/v3` 持有并带出**（它的 S-7 `parentEstablishedAt`、S-8 `membershipEffectiveSince`；原 G-11 闭合），读面与读的先后在 [S-9](#s-9-分享此刻是否生效)。**读不到仍收不可用**——宁可用不上，不可复活。

### S-32 成员关系解除：复制执行不了，已确认的不动

| 情形 | 结果 | 依据 |
|---|---|---|
| 组织型复制通知悬着，发起者退出源组织或不再是它的超管 | 确认时 [S-17](#s-17-每道准入现读确认时再判一遍) 再判不过 ⇒ `notPermitted`，**不落地**；源组织的其他超管可以撤回（[S-21](#s-21-撤回复制通知)），否则等它过期 | [§6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)「他再也不能以那个租户的名义发起复制或分享」；推导：确认是一道准入 |
| 本人型复制、本人型分享 | **没有悬着的东西**：判定与落地在同一次提交里；他退出之后再也发起不了（源侧成员资格） | 同上 |
| 分享邀请悬着，发起者退出分享方组织 | 确认时再判不过 ⇒ `notPermitted`（[S-26](#s-26-确认分享) ②）；资产归组织时该组织的超管可以撤回，归他本人时没人撤得了，等它过期 | 同上 |
| 组织内分享邀请悬着，被分享的租户退出 | 他确认不了（确认者成员资格 ⇒ `notPermitted`）；邀请等它过期或被撤回 | 同上 |
| 他退出之前复制下来的那份 | **不动**：所有者是落进的那一层，作者记录照旧 | [PF-001 §6.7](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#67-创作与归属)；§6.12「任何一种复制——留着」 |
| 他退出，他的租户级资产（包括本人型复制进来的） | 不删、不迁（`capability.organization-governance/v3#S-38`、`data.identity-values/v1#S-26`），重新加入之后原样可用。**所以指着它的待确认件不因他退出而过期**——[S-7](#s-7-两类待确认件共用的过期语义) 的存在性看的是记录与持有，不是成员资格 | §6.12 末段 |
| **分享方是一个租户，他退出** | **这段分享结束**：[S-9](#s-9-分享此刻是否生效) 的第二个合取项转假，派生 `dissolved`；他**重新加入也不复活**（第三个合取项：他的成员关系生效时刻晚于确认时刻） | [§6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后) 第三行；「重新加入」一句 |
| **被分享方是一个租户，他退出** | **这段分享结束**，理由同上；重新加入不复活——要用，分享方再分享一次 | §6.12 第二行；[flows §1.10](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#110-把我租户级的工具分享给同事) |

**分享方退出之后谁来撤销**（原 G-7）不再是问题：那段分享已经结束，没有东西需要撤销；被分享方那层的持有留着、不可用，他自己可以[移除](#s-29-移除收到的分享)。

### S-52 分享方删除资产、或所有权易手：分享随之结束

**主线裁定（D-060 §三 R2-4、R2-7）**。两件事都由资产治理的写面发起，结束分享的写入是本契约的：

| 发生了什么 | 哪些分享 | 写下什么 | 依据 |
|---|---|---|---|
| **分享方删除了那份资产**（`capability.asset-governance/v2#S-28`） | 以它为资产、记录为 `active` 的全部分享（含派生为 `dissolved` 的） | `revoked`，原因 **`sourceDeleted`**；写下者是删除的那个人，时刻是那次提交的时刻 | 分享方删除已分享出去的资产，**等于分享方主动结束分享**——源没了，分享无物可指（原 G-9 闭合） |
| **分享方把那份租户级资产提升到组织**（`#S-27`，所有权易手） | 同上。它们的分享方都是这个租户：分享方是分享成立那一刻的所有者，而所有者至多变一次（`data.asset-model/v2#S-7`） | `revoked`，原因 **`ownerChanged`**；写下者是提升的那个人 | 分享方不再是所有者，他给出的使用权没有了依托——与[分享方退出即结束](#s-32-成员关系解除复制执行不了已确认的不动)同一个道理（[PF-003 §6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后) 第三行）；**提升不被分享挡住**（[S-8](#s-8-分享)） |

**在那一次删除或提升的提交里写下**，由同一提供者完成——与 [S-18](#s-18-确认是一次提交同一落点的确认序列化) 的落地是同一个安排、方向相反（[S-34](#s-34-装配给的保证-vs-协议须给的保证) 一行）。
删除或提升被拒，分享一条都不动；分享那一步写不下去，删除或提升整次失败。**已结束的（`revoked`、`removed`）不改写。**

**不动的东西**：
- **被分享方那一层的 `shared` 持有与配值留着**（不级联：[PF-003 flows §二](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#二分支与异常)「先告知受影响的一方，不默认级联」；分享结束之后持有留着，主线裁定，文首）——不可用：删除之后它读到的是「已删除」，提升之后按 [S-9](#s-9-分享此刻是否生效) 判不生效（记录已是 `revoked`）。被分享方要清掉残留，走[移除收到的分享](#s-29-移除收到的分享) ⑦。
- **删除之前的告知照旧**（主线裁定，文首）：被分享方就是资产治理那份告知里的持有方（`capability.asset-governance/v2#S-28` ②⑨）。本条不另发告知。
- **指向这份资产的待确认件不必写**：[S-7](#s-7-两类待确认件共用的过期语义) 的存在性已经为假——删除：记录不在；提升：所有者那一层换成了组织的组织级，那一层不持有发起时那一份——它们派生为 `expired`，确认收 `offerNoLongerValid`。

**为什么写成记录，而不只在读时算**：两件事都是永久的（标识不回收不复用，所有者至多变一次），读时算也不会复活；
但裁定要的是**记录上的结束**——审计读「谁、何时、因为什么结束」；而且**「分享方此刻仍是所有者」不在 [S-9](#s-9-分享此刻是否生效) 的三个合取项里**，不写下来，提升之后那段分享照旧生效、组织级的东西经原所有者的分享落在别人的租户级——[模型在去掉这一步写入时给出了这条反例](formal/README.md)。

**所有权易手之后要不要再给**，是组织的新决定：组织的超管按[方向矩阵](#s-49-方向与落点矩阵逐格)重新发起（或在本组织里经「谁可以使用它」给），本契约不替它把旧的续上。

**资产治理那一侧**：提升与删除都已把本条的写入列进各自那次提交（`capability.asset-governance/v2#S-27` ④、`#S-28` ④）。

---

## 六、事件

### S-33 本版不发本契约自己的事件

**本契约的操作 ⑨ 一律「不发」。**落地与持有的变化由资产治理那一侧的事件承载（`AssetPublished`、`HoldingChanged`，`capability.asset-governance/v2#S-48`；主线裁定，文首）；
**分享结束不通知**：被分享方经 `listSharings`（[S-30](#s-30-列出组织的分享)，过滤取全部）读结束原因（`ownerChanged`／`sourceDeleted`）；本契约与资产治理都不为它发事件（与 `capability.asset-governance/v2#S-27`、`#S-28` ⑨ 同句）；
待确认件与分享的送达面是**读面**（[S-23](#s-23-读复制通知)、[S-27](#s-27-读分享邀请)、[S-30](#s-30-列出组织的分享)、[S-48](#s-48-列出组织收到的待确认件)）——
[内核不提供可靠投递](../../../../foundation/cross-system-constraints/requirements.md#sys-deploy)，本契约的任何性质都不靠某个监听者收到了什么。

**注册表与审计的需要都由别处接住**：注册表按资产治理的事件与读时现读收窄（`capability.asset-registry` 的 `onAssetChange`），分享撤销、隶属解除与成员退出不产生持有变化、下一次使用时显现；审计读两类待确认件与分享的终结／结束记录。将来开本契约自己的事件，**只能是通知**：
任何参与放行判定的扩展点要么是同步前置、要么是逐个等待其结论的顺序派发，与 `capability.organization-governance` v3 同一口径。

---

## 七、性质与前提

性质的来源一律引 PF 小节；**本节行不编号，不是可外部引用的条款**。

### 不变量

| 性质 | 谁在何处保护 | 前提 | 来源 |
|---|---|---|---|
| **团队资产不出那棵树**：复制只在复制边界成立时落地；跨组织的分享只在分享边界此刻成立时被使用 | [S-12](#s-12-流转边界团队资产不出那棵树) 的三个时点：发起（本人型含落地）、确认同提交、使用时 [S-9](#s-9-分享此刻是否生效) | 组织读面与上级链读得到且与写入同源；求值按 [S-9](#s-9-分享此刻是否生效) 判 shared 持有（**求值 owner 的责任**）；其他出口的 owner 引用本条自证 | [§6.1](../../../../product/PF-003-asset-transfer-and-sharing/design.md#61-一条不变量团队资产不出那棵树)、[§5.2](../../../../product/PF-003-asset-transfer-and-sharing/design.md#52-边界是那棵隶属树不是单个组织)、[acceptance §二](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md#二绝不能发生的事) |
| **任何路径都不把资产写进别人的租户级**：复制只落发起者自己的租户级或组织级；租户级的分享只经那个租户本人点头（组织内），或就是发起者自己（本人型） | [S-49](#s-49-方向与落点矩阵逐格) 的发起判定（`targetLayerNotSelf`）；[S-26](#s-26-确认分享) ② 的确认者 | 被分享方与落点是不变的身份值（[S-6](#s-6-分享邀请)、[S-5](#s-5-复制通知)） | [§6.3](../../../../product/PF-003-asset-transfer-and-sharing/design.md#63-复制的通则同一自然人的两个租户身份)、[acceptance §二](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md#二绝不能发生的事) |
| **落进一个组织的组织级，只经那个组织的有效超管做出**：组织型由目标超管确认；本人型由身为目标超管的发起者自己 | [S-22](#s-22-确认复制) ②、[S-49](#s-49-方向与落点矩阵逐格)、[S-20](#s-20-发起复制) ② | 成员资格与角色现读 | [acceptance §二](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md#二绝不能发生的事)「组织型……没经目标组织的超级管理员确认就落下了」「普通成员带进来的东西，不经超级管理员就出现在组织级」 |
| **同一 (源记录, 落进的那一层) 至多一份带对应血缘的目标记录** | [S-18](#s-18-确认是一次提交同一落点的确认序列化) 的同提交与序列化 | 存储兑现序列化 | [§4 复制血缘](../../../../product/PF-003-asset-transfer-and-sharing/design.md#复制血缘)（「它只用来回答再复制一次该更新那一层里的哪一份」） |
| **同一 (资产, 被分享方) 至多一份生效的分享** | [S-26](#s-26-确认分享) ⑦、[S-24](#s-24-发起分享) ⑦ ＋ [S-18](#s-18-确认是一次提交同一落点的确认序列化) | 同上 | [flows §1.7](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#17-结束一段分享)（「移除」是一个动作） |
| **终结记录与结束记录一经写下不改写** | 各写操作 ④ 的「先读再写」与 ⑦ | 单次提交原子性 | [flows §3.4](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#34-一份待确认的邀约复制通知与分享邀请同形)「结束不可回到待确认」 |
| **复制下来的记录：所有者是落进那一层的所有者、作者是落地的行为人、来源 customized、自己的版本线；源侧一字节不动** | [S-11](#s-11-复制的收场) 的写集合 | 资产治理的组合入口照写 | [§6.5](../../../../product/PF-003-asset-transfer-and-sharing/design.md#65-首次复制)、[§6.4](../../../../product/PF-003-asset-transfer-and-sharing/design.md#64-可复制的对象) |
| **`LineageId` 一经产生不变，且目标侧拿不到源记录号** | [S-10](#s-10-复制血缘怎么判怎么记) | (源, 层) ↔ `LineageId` 的对应不出本契约 | [§4 复制血缘](../../../../product/PF-003-asset-transfer-and-sharing/design.md#复制血缘) |

### 安全性质（绝不能发生）

| 绝不能发生 | 谁在何处保护 | 前提 | 来源 |
|---|---|---|---|
| **一份过期、已撤回或已确认的待确认件被确认之后产生了效果** | [S-22](#s-22-确认复制)／[S-26](#s-26-确认分享) 的同提交重判，三路同收 `offerNoLongerValid` | 时间源同源可用；存在性读面可辨持有实例（[G-3](#十一已知缺口)） | [§6.14](../../../../product/PF-003-asset-transfer-and-sharing/design.md#614-待确认的复制通知与分享邀请会过期)、[acceptance §二](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md#二绝不能发生的事) |
| **一段已经结束的分享，在关系重新接上之后自己恢复了** | [S-9](#s-9-分享此刻是否生效) 的第三个合取项（使用时现读），[S-31](#s-31-隶属解除分享在使用时失效不靠事件)、[S-32](#s-32-成员关系解除复制执行不了已确认的不动) | 隶属建立时刻与成员关系生效时刻持久、与确认时刻同一时间源且在串行提交之间严格递增（`capability.organization-governance/v3#S-42` 末行、[S-34](#s-34-装配给的保证-vs-协议须给的保证)）；两读按 [S-9](#s-9-分享此刻是否生效) 的先后 | [acceptance §二](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md#二绝不能发生的事)、[§三「结束的分享不复活」](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md#三判据) |
| **一次复制冲掉了落点那一层配好的值（含 immutable）或它的持有** | [S-11](#s-11-复制的收场)：`overwritten` 的写集合不含持有与配值 | 资产治理的发布面只写版本 | [§6.7](../../../../product/PF-003-asset-transfer-and-sharing/design.md#67-覆盖的范围内容覆盖配置不动)、[acceptance §三](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md#三判据) |
| **一次复制冲掉了落点那一层自己做的同名组件** | [S-10](#s-10-复制血缘怎么判怎么记)：只看血缘；[S-11](#s-11-复制的收场)：撞标识不碰那一份、也不碰它的持有 | — | [§6.8](../../../../product/PF-003-asset-transfer-and-sharing/design.md#68-能力标识撞车但没有血缘) |
| **组织级的资产被普通成员复制或分享出去** | [S-13](#s-13-发起者一侧的资产) 的 `notPermitted` ＋ [S-22](#s-22-确认复制)／[S-26](#s-26-确认分享) 的再判 | 角色现读 | [acceptance §二](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md#二绝不能发生的事) |
| **被分享来的被再分享、复制出去或提升** | [S-13](#s-13-发起者一侧的资产)；提升由资产治理的所有者判定挡（[S-8](#s-8-分享)） | — | [§6.13](../../../../product/PF-003-asset-transfer-and-sharing/design.md#613-分享不可传递) |
| **隶属解除、或租户一端的成员关系解除之后，分享出去的还能用** | [S-9](#s-9-分享此刻是否生效)（使用时判）＋ [S-31](#s-31-隶属解除分享在使用时失效不靠事件)、[S-32](#s-32-成员关系解除复制执行不了已确认的不动) | **求值按 S-9 判 shared 持有**；上级链与成员资格读一致 | [acceptance §二](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md#二绝不能发生的事) |
| **关系解除之后复制过去的被收回** | 本契约没有任何写落点记录的路径，除了落地那一步 | — | 同上 |
| **一个已不是有效成员的租户身份被用来执行一次复制或让一段分享成立** | 本人型：发起的同一提交里判源侧与落点侧成员资格；组织型与要点头的分享：[S-22](#s-22-确认复制)、[S-26](#s-26-确认分享) 的再判 | 成员资格现读 | [§6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后) |
| **读不到被当成「不存在」「不在树上」「不是他的」「不是成员」「没断过」** | [S-16](#s-16-缺席时的默认答案) ＋ 各操作 ⑧ ＋ [S-9](#s-9-分享此刻是否生效) 末段 | 各读面以失败返回，不以空值返回 | `data.identity-values/v1#S-19` |
| **目标侧从任何读面拿到源记录号或源资产本身**（它的其余版本与草稿） | [S-23](#s-23-读复制通知) 的目标侧投影（带源组织标识与送进来的那一版的内容，不带源记录号与源资产本身）、[S-10](#s-10-复制血缘怎么判怎么记) | — | [§4 复制血缘](../../../../product/PF-003-asset-transfer-and-sharing/design.md#复制血缘)、主线裁定 D-060 §三 R2-6 |
| **分享方删除了资产、或资产所有权易手之后，那段分享仍生效** | [S-52](#s-52-分享方删除资产或所有权易手分享随之结束)：在删除或提升的同一次提交里写 `revoked` | 资产治理的删除与提升把本条的写入列进同一次提交（`capability.asset-governance/v2#S-27`、`#S-28` ④⑧，原 G-15 闭合；[S-34](#s-34-装配给的保证-vs-协议须给的保证)） | 主线裁定 D-060 §三 R2-4、R2-7；[§6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后) 第三行 |
| **一次本人型复制的重试多发布一个版本** | [S-20](#s-20-发起复制) ⑦ 的尝试键：同键重放返回第一次的结果 | 尝试键的登记与落地同一次提交；保留期内键不被回收（`copy_attempt_key_retention`） | [PF-001 §6.8](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#68-管理结果)、主线裁定 D-060 §三 R2-5 |
| **落地之后留下部分效果**（记录建了通知还悬着，或反之） | [S-18](#s-18-确认是一次提交同一落点的确认序列化) | 两个 owner 的写集合在同一次提交里（[S-34](#s-34-装配给的保证-vs-协议须给的保证) 第一行） | [PF-001 §6.8](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#68-管理结果) |

### 进展性质（全部有界）

| 性质 | 上界 | 前提 | 来源 |
|---|---|---|---|
| 未确认也未撤回的待确认件，**不迟于 `issuedAt + offer_ttl`** 进入不可确认 | `offer_ttl`，**不依赖定时器** | 时间源可用、同源、`now` 不后退（`data.offer-expiry/v1#S-17`） | [§6.14](../../../../product/PF-003-asset-transfer-and-sharing/design.md#614-待确认的复制通知与分享邀请会过期) |
| 指向的资产被移除或删除之后，**下一次**读即见派生状态 `expired`、确认即收 `offerNoLongerValid` | 下一次读／确认 | 存在性读面可辨持有实例（[G-3](#十一已知缺口)） | 同上 |
| 本人型发起成功返回、组织型确认成功返回之后，落点那一层**下一次**求值就用到落地的内容 | 下一次求值 | 求值取持有记录当前发布的那一版（[十二](#十二消费者核对)） | [§6.6](../../../../product/PF-003-asset-transfer-and-sharing/design.md#66-重复复制全量覆盖替换) |
| 分享方发布新版本之后，被分享方**下一次**求值就用到新版本 | 下一次求值 | 同上 | [§6.11](../../../../product/PF-003-asset-transfer-and-sharing/design.md#611-分享的同步与自保) |
| 撤销、移除成功返回之后，或隶属解除、成员退出提交之后，被分享方的**下一次**使用被拒 | 下一次使用 | 求值按 [S-9](#s-9-分享此刻是否生效) 现读，缓存写明失效条件 | [flows §1.7](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#17-结束一段分享)、[§6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后) |
| 被拒的操作**立即**返回一个具名值，且不留部分效果 | 该次返回 | 单次提交原子性 | [PF-001 §6.8](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#68-管理结果) |

---

## 八、装配给的保证 vs 协议须给的保证

### S-34 装配给的保证 vs 协议须给的保证

[SYS-DEPLOY](../../../../foundation/cross-system-constraints/requirements.md#sys-deploy)：右列是本契约已经记下的待兑现项（[G-8](#十一已知缺口)），不是「以后再说」。

| 保证 | 本版（单机）由谁给 | 跨进程之后谁重新兑现 | 做不到会怎样 |
|---|---|---|---|
| **落地的同提交**：过期重判、再判、落地、终结记录（[S-18](#s-18-确认是一次提交同一落点的确认序列化)；本人型是发起那一次提交） | **装配给**：本契约与资产治理的写集合落在同一存储的同一事务 | **协议给**：两个 owner 分属两个进程时，须有等价的原子提交协议；「同一个函数调用」不构成原子 | 记录建了、通知还悬着（下一次确认再建一份），或通知确认了、记录没建（目标组织以为收到了） |
| **同一落点的落地序列化**（血缘唯一、同对至多一份生效） | **装配给**：同一存储对同一键的写入序列化 | **协议给**：跨节点协调（单一写者或等价协议） | 同一 (源, 层) 出现两份带血缘的记录，重复复制不知道覆盖哪份；同一对两份生效，「移除」一次说不完 |
| **边界读一致性**：确认与使用时求的 `shareAncestor` 与刚提交的隶属变化同源 | **装配给**：同一存储读写同源 | **协议给**：须定义读一致性级别；陈旧读**不得放行**跨组织流转（`data.identity-values` 装配表同一行） | 隶属刚解除，陈旧读判成同树：一次复制落在树外，或一次使用越界 |
| **成员资格与角色的可见性** | **装配给**：写入即可被下一次读看到 | **协议给**：须定义传播时延上界并写进契约 | 刚退出的人的通知在上界内仍可能落地；刚退出的租户一端的分享在上界内仍可能被用 |
| **隶属建立时刻、成员关系生效时刻与确认时刻可比**：三者取自同一个时间源，且在**串行化的提交之间严格递增**（或用提交序号） | **装配给**：同一存储、同一时钟，由组织治理在写隶属与成员关系的那一次提交里一并写下（`capability.organization-governance/v3#S-7`、`#S-8`，它的 `#S-42` 末行） | **协议给**：跨节点时须有全序的提交时刻（或等价的版本号），读到的时刻不得早于最近一次提交的隶属与成员关系变更 | 重新隶属写下的时刻与旧的确认时刻相等或更早——**一段结束的分享复活** |
| **时刻与关系的两读先后**（[S-9](#s-9-分享此刻是否生效) 的 ① 在 ② 之前） | **装配给**：单机下在一次可串行化的读里取齐 | **协议给**：两读分属不同节点时，读 ② 的那一次不得早于读 ① 的那一次（读到的状态单调） | 一次「解除—重新接上」落在两读之间，旧的时刻配上新接上的关系——**分享复活** |
| **读两个时刻的调用主体**（[S-9](#s-9-分享此刻是否生效) ②：读的是分享两端的组织与租户，不是发起者） | **装配给**：运行时代行，以被读的那个租户的 `TenantId` 为调用方身份值读组织治理 v2 的 `#S-59` 默认档、按链读 `#S-22`；同一提供者、可串行化读即满足——**同一存储内一次可串行化读（含事务内直读）即满足，不要求经服务面代行**；依据是组织治理 v2 `#S-42`「调用方身份已经核实过」那一行 | **协议给**：一个获授权读这两个读面的服务身份；授权依据随调用携带、在接收边界重新验证（`data.identity-values/v1#S-30`） | 服务身份缺席或未获授权时，`#S-59` 的拒绝与「那个租户已不在默认档」（S-9 读作「断过」）分不开：把前者读成「断过」，一段未断的分享被判结束且不再回来；读成可用，结束的分享复活。**协议须让两者可分辨，前者按「读不到」收、以不可用失败**，不放行 |
| **删除与提升同提交结束分享**（[S-52](#s-52-分享方删除资产或所有权易手分享随之结束)） | **装配给**：资产治理的删除或提升与本契约的分享写入落在同一存储的同一事务，由同一提供者完成——与落地同提交是同一个安排、方向相反 | **协议给**：两个 owner 分属两个进程时，须有等价的原子提交协议 | 资产删了或易手了、分享仍为 `active`：提升之后组织级的东西经原所有者的分享落在别人的租户级；或分享结束了、删除却失败 |
| **尝试键的登记与这一次写入同提交**（[S-20](#s-20-发起复制) ④⑦） | **装配给**：登记与落地（或写通知）在同一事务；同一 (发起者, 尝试键) 的写入序列化 | **协议给**：跨节点时键的登记须与这一次写入原子、并对同一键序列化 | 登记了而落地没成（重放认回一次不存在的结果），或落地了而没登记（重放多发布一个版本） |
| **待确认件的时钟同源与存在性读数新鲜度** | 由 `data.offer-expiry/v1#S-17` 给 | 同左，本契约不重复承诺 | — |
| **边界判定与隶属变更的先后**（确认时的再判、使用时的 [S-9](#s-9-分享此刻是否生效)） | **装配给**：确认（与本人型发起）的提交与组织治理的隶属写入由同一把隶属哨兵串行（组织治理节点登记的外部依赖，实现映射阶段；主线裁定 [D-060 §一 PA-4](../../../../record/decisions/mainline-self-rulings-2026-09/decision.md#块-a-拆分提案报回的推荐-bcore-纯模块--治理与流转一个插件)） | **协议给**：跨节点时这把哨兵要有等价的协调；读到的上级链必须不早于最近一次提交的隶属变更 | 解除隶属与一次确认交错：确认按解除之前的上级链放行，**团队资产落在树外** |
| **调用方身份已经核实过**（全部操作） | **装配给**：本契约的面是能力间内部面；入口层先把登录状态换成当前租户身份，再带着身份值来调 | **协议给**：跨进程时携带授权依据，**在接收边界重新验证**（`data.identity-values/v1#S-30`） | 谁拿到一个 `TenantId` 就能以那个身份发起、确认、撤销；**本契约的面因此不得直接暴露成终端 API** |
| **(源, 层) ↔ `LineageId` 的对应不出本契约** | **装配给**：对应只存在本契约的存储里，没有读面返回它 | **协议给**：本契约的存储分到别的节点后，对应仍不得随任何发往目标那一侧的消息流出 | 目标组织据血缘反推源记录号与源组织——[那正是血缘被做浅的原因](../../../../product/PF-003-asset-transfer-and-sharing/design.md#复制血缘) |

---

## 九、交接、缺席与恢复

### S-35 依赖的提供者不可用

组织治理、资产治理的读面或时间源不可用时，依赖它的操作**以 `unavailable` 明确失败，不静默降级**：
不得跳过成员资格判定、不得把读不到当成「在同一棵树上」或「不在」、不得把读不到的存在性当成「在」或「不在」、**不得把读不到的建立时刻当成「没断过」**。
**资产治理的写面在落地那次提交里失败**，整次确认（或本人型的整次发起）失败、不写终结记录——[S-18](#s-18-确认是一次提交同一落点的确认序列化) 没有「先确认、落地稍后补」这一支。

### S-36 撤销不发出停止信号

撤销分享、移除分享、隶属解除、成员退出，**都只影响下一道尚未通过的准入**（[PF-001 §6.6](../../../../product/PF-001-identity-scope-and-agent-constraints/design.md#66-撤销不等于强制停止)、
[flows §二](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#二分支与异常)「资产在 agent 运行中被覆盖、撤销或移除——不影响已经开始的调用」）。
本契约**不发出任何停止、中断或取消信号**；已经开始的调用是否停止，归独立的运行控制。

### S-37 本能力自己被撤除、替换或重启

本契约拥有的事实——两类待确认件、分享记录、血缘对应、尝试键登记——**全在存储里**，没有一条只活在运行实例内：
没有定时器承担正确性（过期是读时求的，`data.offer-expiry/v1#S-18`；不复活是读时求的，[S-9](#s-9-分享此刻是否生效)），没有跨提交的在途工作（全部操作单次提交结算）。
**重启不改变任何判定结果，也没有在途工作需要交接。**
**这是一条可被推翻的承诺**：引入任何跨提交在途状态（例如「先确认、后台再落地」）都会使它失效，那时必须回到本节重写交接责任。

---

## 十、规范表达与验证义务

### S-38 本版选用哪些形式工件

| 性质 | 表达 | 理由 |
|---|---|---|
| [S-7](#s-7-两类待确认件共用的过期语义) 确认／撤回／过期互斥、[S-10](#s-10-复制血缘怎么判怎么记) 血缘唯一、[S-12](#s-12-流转边界团队资产不出那棵树) 复制落地的边界、[S-49](#s-49-方向与落点矩阵逐格) 不落别人的租户级与组织级只经目标超管 | **TLA+ 行为模型**（[`formal/Transfer.tla`](formal/Transfer.tla)），复制一组配置 [`Transfer.cfg`](formal/Transfer.cfg) | 每一条都是**交错**问题：确认的读与写之间、发起与确认之间，隶属、成员资格、时间与资产都在变 |
| [S-8](#s-8-分享) 同对至多一份生效、[S-9](#s-9-分享此刻是否生效)／[S-31](#s-31-隶属解除分享在使用时失效不靠事件)／[S-32](#s-32-成员关系解除复制执行不了已确认的不动) 使用时的三个合取项、**不复活**、[S-52](#s-52-分享方删除资产或所有权易手分享随之结束) 删除与提升结束分享 | 同一模型，分享一组配置 [`Transfer_Share.cfg`](formal/Transfer_Share.cfg) 与时序配置 [`Transfer_Revival.cfg`](formal/Transfer_Revival.cfg) | 确认与使用之间隶属与成员关系在变、资产会被删除或提升；**不复活是一条时序性质**（断过之后永不再生效），只有行为模型写得出一条会失败的断言 |
| **每处保护的有效性** | 十三个去保护配置（`Transfer_No*.cfg`），**预期给出反例** | 去掉哪一处保护，就给出哪一条性质的反例；**不登记为 formal task**，见 [formal 入口](formal/README.md) |
| 覆盖不碰配值、plugin 随行、失败值与读面、`unavailable`、落点矩阵的每一格、尝试键的认回、[S-9](#s-9-分享此刻是否生效) 两读的先后、删除与提升之后持有留着 | **规范场景**（[S-39](#s-39-两类待确认件的三种收场)～[S-47](#s-47-不可用时明确失败)、[S-50](#s-50-组织内分享与成员关系)、[S-51](#s-51-方向矩阵逐格)、[S-53](#s-53-分享方删除与提升分享随之结束)） | 写集合的约束在模型里写成 `UNCHANGED` 就被吸收了，**那不是证据**；失败值与投影要真跑才看得见。**模型把 [S-9](#s-9-分享此刻是否生效) 的判定写成一步原子读**，两读之间的交错被这一建模方式吸收——先后的证据只在场景里 |

**本版不附 JSON Schema、不建 Alloy。**数据形状归 `data.asset-model` 与 `data.offer-expiry`；
边界判据（`shareAncestor` 就是「同一棵隶属树」）的结构性质归 `capability.organization-governance`：它的 v1 Alloy 模型在给定规模内检查过（v2 [S-45](../../organization-governance/v3/contract.md#s-45-本版选用哪些形式工件) 声明沿用，**不含两个时刻**；范围、前提与尚未做的变异核对见那份契约的[验证入口](../../organization-governance/verification.md)），本契约引用判据不复述，也不把那几次检查算作本契约的证据。
执行状态与结果在[验证入口](../verification.md)，**不写进本版本目录**。

### 规范场景

#### S-39 两类待确认件的三种收场

对组织型复制通知与分享邀请（组织—组织、组织内各一份）**各**演练一遍：发出一份，分别让它 ① 被确认 ② 被撤回 ③ 放到过期（**关掉任何后台清理**），然后再确认；**同一次**再跑第四支：对①那份再确认一次。
**必须观察到**：① 产生约定的那一个效果；②③④ 确认被拒，值**逐字相同**（`offerNoLongerValid`），**且没有任何效果**；③ 显式给时长 `T`、在 `issuedAt + T` 之后确认。
**另跑两支**：不给时长的那份按该类默认值算出 `expiresAt`；给非正时长 ⇒ `invalidInput`、**不写入任何东西**。
撤回路径：撤回已确认的、撤回已过期的 ⇒ 同为 `alreadyConcluded`，**不写终结记录**；再撤回已撤回的 ⇒ `ok`。
**本人型那一支**：给合法时长发起本人型复制与分享 ⇒ 照常落地，返回里写明没有待确认件，[S-48](#s-48-列出组织收到的待确认件) 里什么都没多。

#### S-40 首次、重复、撞标识无血缘、按层找

普通成员 M 把个人组织里一个 skill 的 v1 本人型复制进团队 T 他自己的租户级（首次）→ 源侧发布 v2 再复制（重复）→ 团队 U 的超管 S 自己先在 U 的组织级建一个同能力标识的 skill，然后把同一源本人型复制进 U 的组织级 → S 再把同一源复制进他自己在 U 的租户级。
**必须观察到**：T 里 M 的租户级出现**一份**新记录，所有者 (T, M)、作者 (T, M)、v1、带血缘，**没有任何待确认件、没有任何人点头**；重复那次 T 那份出 v2、**记录号不变、血缘号不变**、`imports = 2`；
U 组织级那次返回 `created`、**U 自己那份一字节不动、它的持有不动**，新记录**未取得持有**，返回里告知同一标识下有两份；S 租户级那次**又是新增**——U 组织级那份不动（「血缘只在落进的那一层里找」，[acceptance §三](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md#三判据)）；**源侧什么都没变**。
**另跑组织型一支**：集团 G 的超管把 G 组织级的模板复制给同树的 C（`pending`），C 的超管读通知（目标侧投影**带 G 的 `OrganizationId`**、不含源记录号与源资产的其余版本）后确认 ⇒ C 组织级新增一份，**作者是 (C, 确认的那位超管)**；G 再发 v2、C 再确认 ⇒ 重复。
**再跑尝试键一支**（[S-20](#s-20-发起复制) ⑦）：M 带尝试键 k 把同一源再本人型复制一次（重复那一种），丢掉回执，再用 k 重放两次（第二次改一个无关输入）⇒ 三次返回**同一个** `overwritten`，T 那份记录**只多一个版本**；不带键重放一次 ⇒ `overwritten`、再多一个版本、记录不变；G 的超管带键 k′ 发起组织型、用 k′ 重放 ⇒ 同一个 `CopyNoticeId`、只有一份通知；**让键登记的读面不可用**再用 k 重放 ⇒ `unavailable`、什么都不写。

#### S-41 覆盖不碰配值

落点那一层为复制来的那份配一项权限并加锁、禁用它，再被重复复制一次（本人型与组织型各一次）。
**必须观察到**：新版本立即是那份记录当前发布的那一版；**那一项配值与锁照旧、禁用照旧、持有照旧**（[acceptance §三](../../../../product/PF-003-asset-transfer-and-sharing/acceptance.md#三判据)「覆盖不碰配置」）。

#### S-42 边界在每条路径上都挡住

构造：无共同上级的两个团队；团队 → 个人组织的复制与分享（含自己的个人组织）；被分享来的再分享与再复制；官方件复制；草稿版本复制。
**必须观察到**：各自拿到 [S-19](#s-19-这一节每个操作写全九件事) 总表里对应的那一个值，**发起者都是超级管理员**——结构性禁止不随角色变（[S-15](#s-15-结构性禁止不是权限判定)）。
**再跑一支**：同树时发出组织型复制通知，解除隶属后再确认 ⇒ `outsideTree`，**不落地**；重建隶属之后仍在有效期内的同一份通知可以确认（通知不是分享，没有「不复活」的问题）。

#### S-43 分享的建立、跟随与结束

集团把一个组件分享给同树的子公司并被确认 → 集团发布新版本 → 子公司为它配执行权限 → 集团撤销；另起一份分享，子公司移除；再起一份，确认前撤回。
**必须观察到**：确认之后子公司的下一次求值用到它、发布之后**不经任何操作**用到新版本；撤销之后下一次使用被拒、**子公司那层的持有与配值还在**；移除之后持有与配值**一起没了**；同一对第二份邀请被确认时**认回同一个 `SharingId`**。

#### S-44 隶属解除之后：分享失效，复制留着，不复活

A 同时把一份资产**分享**给 B、把另一份**复制**给 B（组织型），然后解除隶属，再重新建立隶属。
**必须观察到**：解除之后分享那份下一次使用被拒、`listSharings` 里它此刻是 `dissolved`；复制那份照常用、照常改；**重新隶属之后那份分享仍是 `dissolved`、仍用不上**，直到 A 再分享一次、B 再确认一次——那是一份**新的** `SharingId`；
**没有任何一步依赖 `affiliation.dissolved` 被谁收到**——把事件派发关掉重跑，结果相同；**也不依赖断开期间有没有人读过它**——解除与重新隶属之间不做任何读，结果相同。
**再跑读序一支**（[S-9](#s-9-分享此刻是否生效) 的 ① 在 ② 之前）：在读完 ① 之后、读 ② 之前注入一次「解除隶属—重新隶属」，再让求值判那份 shared 持有、`listSharings` 求它的状态 ⇒ **不可用、`dissolved`**，不是可用、`active`；**把两读的先后颠倒重跑，应当观察到复活**——那是这条先后在保护什么的证据，只在场景里有（[S-38](#s-38-本版选用哪些形式工件)：模型把两读写成一步）。

#### S-45 资产被移除即过期

发出一份组织型复制通知与一份分享邀请，确认之前让**所有者那一层移除**那份资产，然后确认。
**必须观察到**：读到派生状态 `expired`、确认被拒且值为 `offerNoLongerValid`，不是一个点头之后的当场失败。
**再跑一支**：移除之后**重新持有同一份记录**，那两份读到的仍是 `expired`（[G-3](#十一已知缺口) 闭合之前这一支可能失败，**失败要如实记**）。
**这条与 `data.offer-expiry/v1` 的 S-26 可一次执行两边兑现**，两边各自记结果。

#### S-46 plugin 随行与引用告知

分享（与复制）一个 plugin，它引用一个落点那一侧没有提供者的能力标识。
**必须观察到**：发起成功，⑤ 的告知清单列出那个能力标识；落地之后落点那一侧**只有 plugin 那一份**记录／分享／持有，成员没有各自的。**受阻于 [G-5](#十一已知缺口)**。

#### S-47 不可用时明确失败

分别让成员资格读面、组织读面、上级链、时间源、资产治理读面、**隶属建立时刻与成员关系生效时刻的读面**不可用（故障注入），调发起（两种）、确认、撤回、读与列表，并让求值按 [S-9](#s-9-分享此刻是否生效) 判一份 shared 持有。
**必须观察到**：一律 `unavailable`（求值：不可用）；**没有一次被收成 `notPermitted`、`outsideTree`、`sourceNotOwned`、`recipientNotMember`、`offerNoLongerValid`、`noticeNotFound`、`dissolved`、`active` 或空列表**，也没有任何写入。

#### S-50 组织内分享与成员关系

团队 T 的成员 A 把自己租户级的一个 tool 分享给同事 B（组织内分享），B 确认；A 发布新版本；B 退出 T 后重新加入；A 再分享一次、B 再确认；A 退出 T。
**必须观察到**：B 确认之前他的可用集合里没有它；确认之后 B 那层以 `shared` 持有、下一次求值用到它、A 发布之后**不经任何操作**用到新版本；**T 的超管读不到这段分享**（[S-30](#s-30-列出组织的分享) ②）；
B 退出后那段分享是 `dissolved`，**B 重新加入之后仍是 `dissolved`、仍用不上**；A 再分享、B 再确认 ⇒ **新的** `SharingId`，可用；A 退出之后它是 `dissolved`、B 用不上，A 的租户级资产原样还在；
B 试图把它再分享给同事 C、复制出去、提升 ⇒ `notTransitive`、`notTransitive`、`notOwner`（资产治理）。
**另跑两支**：A 分享给一个从未加入 T 的账号在 T 的租户身份 ⇒ `recipientNotMember`；A 分享给另一个组织里别人的租户 ⇒ `targetLayerNotSelf`，**不读任何记录**。
**租户格的 `shared` 持有已由 `data.asset-model` 第二轮修订放开**（原 [G-14](#十一已知缺口) 闭合，主线裁定 D-060 §三 R2-10）：「B 那层以 `shared` 持有」一步应写得进；写不进就是缺陷，不是已知限制。

#### S-51 方向矩阵逐格

按 [S-49](#s-49-方向与落点矩阵逐格) 两张表**每一行**构造一次：普通成员与超管各一遍（超管从个人组织复制进本团队选组织级、普通成员选组织级；T 的超管把组织级资产复制与分享给同树 T′、分享给本组织一个成员、复制到他自己在 T′ 的租户级；租户级资产复制到 T′ 组织级；个人组织资产分享到团队组织级；个人组织资产本人型分享到我在 T 的租户级；我 T 租户级的本人型复制与分享到我在 T′ 的租户级）。
**必须观察到**：放行的那几行各自是表里写的那一种（本人型不产生待确认件、组织型与组织内分享产生），被拒的那几行各自是表里写的那一个值；**普通成员选组织级 ⇒ `notPermitted`**，**超管选同一格 ⇒ 落组织级、没有待确认件**。

#### S-53 分享方删除与提升：分享随之结束

集团 G 把一份组织级资产分享给同树的 C 并被确认，C 为它配一项权限；另发一份指向它的组织型复制通知悬着。团队 T 的成员 A（有组织范围创作权）把自己租户级的一个 tool 分享给同事 B（组织内分享）并被确认，又把它本人型分享到自己在 T′ 的租户级。
然后 G 的超管经资产治理的告知删除那份资产；A 把那份 tool 提升到 T 的组织级。
**必须观察到**：删除那次提交之后，G→C 那份分享记录是 `revoked`、原因 `sourceDeleted`、写下者是删除的那位超管、时刻是删除的时刻；**C 那层的持有与配值还在**，求值读到「已删除」、不可用；那份复制通知派生为 `expired`、确认收 `offerNoLongerValid`。
**提升本身成功**，没有因为有分享而被拒；那次提交之后 A 作为分享方的两份分享都是 `revoked`、原因 `ownerChanged`；B 与 T′ 那两层的持有留着、用不上；`listSharings` 里它们各带自己的结束原因。
**另跑两支**：一份已被撤销（`sharerRevoked`）或已被移除的分享，删除之后记录**不改写**；让本契约的分享写入在删除（或提升）那次提交里失败（故障注入）⇒ 删除（或提升）**整次失败**，资产照旧、分享照旧。
曾受阻于 G-15（资产治理的删除）与 G-14（租户格的 `shared` 持有），两者已于 2026-09-24 第二轮闭合。

---

## 十一、已知缺口

**缺口不填默认值。**下列各项等具名 owner 裁决，实现不得据一个看起来合理的猜测推进。

| # | 缺口 | owner | 闭合条件 |
|---|---|---|---|
| G-1 | **已闭合（2026-09-24 整批对齐）**：接收方的发现面 `listPendingForOrganization`（[S-48](#s-48-列出组织收到的待确认件)；主线裁定，文首）。「列出我发出的」没有裁定，发起方按手上的标识读 | — | — |
| G-2 | **已闭合（2026-09-24，PF-003 rev 5）**：rev 4 角色表里「目标侧普通成员按被授予的权限确认复制」一格随 rev 5 消失——普通成员对组织级资产没有复制、分享或替组织收下的动作（[flows §四](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#四角色与操作)）。**编号保留不复用** | — | — |
| G-3 | **指向对象的身份**：[S-7](#s-7-两类待确认件共用的过期语义) 的存在性要求①资产记录号不回收不复用；②所有者那一层的持有能区分「发起时那一份」与「移除后再持有的那一份」。①已由 `data.asset-model/v2#S-4` 与 `capability.asset-governance/v2#S-5` 承诺；②仍缺——持有形状没有实例身份。**在它闭合之前**，移除后再持有同一份记录可能让一份已过期的待确认件读回 `pending` | `data.asset-model` / `capability.asset-governance`（对齐） | 形状给出持有的实例身份（或承诺同一键上先后两份持有的 `since` 严格递增），并承诺记录号不复用 |
| G-4 | **已闭合（2026-09-24）**：关系断了之后又接上，分享**不复活**（产品负责人裁定，[D-059](../../../../record/decisions/assets-runtimes-split-and-rulings/decision.md#资产的复制与分享-pf-003-rev-5)；[PF-003 §6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)）。落法是 [S-9](#s-9-分享此刻是否生效) 的第三个合取项，读时求值、不依赖解除事件；它要的两个时刻由 `capability.organization-governance` v3 给出（G-11 随之闭合）。`Transfer_Revival.cfg` 由反例改为正例。**编号保留不复用** | — | — |
| G-5 | **plugin 正文里「内含成员」与「引用」怎么分**：[S-14](#s-14-plugin-的复制与分享) 的告知清单只对「引用」一支；`data.asset-model` 的 plugin 外壳目前只列一种成员 | `data.asset-model` | plugin 外壳把两种关系分开；告知清单按它求值 |
| G-6 | **已闭合（2026-09-24 整批对齐）**：本契约不发自己的事件（[S-33](#s-33-本版不发本契约自己的事件)） | — | — |
| G-7 | **已闭合（2026-09-24，PF-003 rev 5）**：分享方是租户而他已不是有效成员时，那段分享**随之结束**（[§6.12](../../../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后) 第三行，[S-32](#s-32-成员关系解除复制执行不了已确认的不动)），不需要谁来撤销；悬着的邀请在确认时再判不过、等它过期。**编号保留不复用** | — | — |
| G-8 | **跨进程**：[S-34](#s-34-装配给的保证-vs-协议须给的保证) 右列——落地的原子提交协议、同落点序列化、边界读一致性、成员资格传播上界、三个时刻的全序、两读的先后、删除与提升同提交结束分享、尝试键登记的原子性、血缘对应的私有性 | 架构设计（本版单机不阻断） | 分布式演化启动时给出，**作为本契约的新版本发布** |
| G-9 | **已闭合（2026-09-24，主线裁定 D-060 §三 R2-4）**：分享方删除已分享出去的资产，那段分享在删除的同一次提交里写 `revoked`、原因 `sourceDeleted`（[S-52](#s-52-分享方删除资产或所有权易手分享随之结束)）；删除之前的告知（主线裁定，文首）不变。**编号保留不复用** | — | — |
| G-10 | **已闭合（2026-09-24 整批对齐）**：落地面就是资产治理的组合入口（`capability.asset-governance/v2#S-46`）。**编号保留不复用** | — | — |
| G-11 | **已闭合（2026-09-24，主线裁定 D-060 §三 R2-1、R2-2）**：`capability.organization-governance` v3 给上级组织属性加隶属建立时刻（`parentEstablishedAt`，它的 S-7）、给成员关系记录加成员关系生效时刻（`membershipEffectiveSince`，它的 S-8），与写入同一次提交写下、在串行提交之间严格递增（它的 S-42 末行），由读组织（S-22）与列出组织成员（S-59）带出；本契约整体钉 v2，[S-9](#s-9-分享此刻是否生效) 写明读哪一面、先读哪一个。**编号保留不复用** | — | — |
| G-12 | **已闭合（2026-09-24，主线裁定 D-060 §三 R2-5）**：[S-20](#s-20-发起复制) 带可选的尝试键 `attemptKey`，同一 (发起者, 键) 在保留期 `copy_attempt_key_retention` 内重放返回首次那一次的结果、不多发布版本；两支都认回。**编号保留不复用** | — | — |
| G-13 | **已闭合（2026-09-24，主线裁定 D-060 §三 R2-6）**：[S-23](#s-23-读复制通知) 的目标侧投影带源组织的 `OrganizationId`，不带源记录号与源资产本身。**编号保留不复用** | — | — |
| G-14 | **已闭合（2026-09-24 第二轮，主线裁定 D-060 §三 R2-10）**：`data.asset-model` v2 [`#S-19`](../../../data/asset-model/v2/contract.md#s-19-使用权来路) 把 `shared` 放开到租户格，[`#S-21`](../../../data/asset-model/v2/contract.md#s-21-复制血缘) 按本契约的矩阵改写血缘（按 (源, 落进的层) 记、落在租户级的那一份所有者是租户）；**流转语义以本契约为准，那份契约只承载形状**。本契约 [S-9](#s-9-分享此刻是否生效)、[S-11](#s-11-复制的收场) 不用改；按闭合条件，catalog 里对它消费的 clauses（`S-4`～`S-9`、`S-18`、`S-19`、`S-21`、`S-22`）于 2026-09-24 独立评审第一轮逐条对过 [S-4](#s-4-依赖方向与被消费的面) 那张表，一致。**编号保留不复用** | — | — |
| G-15 | **已闭合（2026-09-24 第二轮）**：`capability.asset-governance/v2#S-28` ④ 已把 [S-52](#s-52-分享方删除资产或所有权易手分享随之结束) 的写入（`revoked`／`sourceDeleted`）列进删除那次提交，⑧ 写明这一步写不下去则整次 `unavailable`、不删；提升那侧 `#S-27` ④⑧ 同样 | — | — |

---

## 十二、消费者核对

本节不新增承诺，只走一遍具名消费者的路径，核对本契约给的面够不够。

| 消费者 | 它要什么 | 本契约给什么 | 够不够 |
|---|---|---|---|
| **CLI/TUI：个人 → 团队的复制**（[flows §1.1](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#11-把个人组织里的东西复制给团队)～§1.3） | 选层、发起、看结果 | [S-20](#s-20-发起复制) 本人型一支：发起即落地，返回 `CopyOutcome` | **够**：普通成员落自己的租户级、不需要谁批；超管可选组织级 |
| **治理中心：组织型复制**（[flows §1.9](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#19-集团把模板复制给子公司)） | 发起；目标超管知道有一份在等、看清要盖掉什么、然后点头 | [S-20](#s-20-发起复制)、[S-48](#s-48-列出组织收到的待确认件)、[S-23](#s-23-读复制通知) 的目标侧投影、[S-22](#s-22-确认复制) | **够**：目标侧投影带源组织（主线裁定 D-060 §三 R2-6）；带尝试键的重放认回同一份通知 |
| **治理中心：组织间分享** | 发起、对方发现并确认、双方看现状、撤销与移除 | [S-24](#s-24-发起分享)～[S-30](#s-30-列出组织的分享)、[S-48](#s-48-列出组织收到的待确认件) | **够**；`revoked` 那几项带结束原因，分享方删除或提升之后双方看得见为什么结束 |
| **CLI/TUI：组织内分享**（[flows §1.10](../../../../product/PF-003-asset-transfer-and-sharing/flows.md#110-把我租户级的工具分享给同事)） | 我发起；同事发现、确认、移除；我撤销 | [S-24](#s-24-发起分享)、[S-48](#s-48-列出组织收到的待确认件)（租户那一类）、[S-26](#s-26-确认分享)、[S-29](#s-29-移除收到的分享)、[S-28](#s-28-撤销分享) | **够**；租户格的 `shared` 持有已由 `data.asset-model` 第二轮修订放开（原 G-14 闭合） |
| **`capability.asset-evaluation`：认 basis 为 shared 的持有** | 「这份持有此刻能不能用」 | [S-9](#s-9-分享此刻是否生效) 的判据 ＋ [S-30](#s-30-列出组织的分享) 的读面 | **判据够**；那份契约的前提 PRE-2 已对齐到三个合取项、租户格与这条读序（主线裁定 D-060 §三 R2-12）——**组输入的一方照 [S-9](#s-9-分享此刻是否生效) 的读序读两个时刻**（先关系、后时刻）。**这是那份契约对本条的前提依赖，不进 catalog**：登记会成环（本契约 → 资产治理 → 那份契约 S-23）；**本条（S-9）一改，须回头核对 `capability.asset-evaluation/v2` 的 PRE-2**。「持有记录取当前发布的那一版」已由形状给出：shared 持有恒为 `current`（`data.asset-model/v2#S-18` 第 6 条） |
| **`capability.asset-governance`：复制落地与取持有** | 被组合进落地的同一次提交 | [S-11](#s-11-复制的收场)、[S-24](#s-24-发起分享) ④、[S-26](#s-26-确认分享) ④ 列出的写集合 | **够**：`capability.asset-governance/v2#S-46` 的组合入口；落地的行为人就是作者，那一侧不再需要「作者 ≠ 调用方」；落地记录的 `byAgent` 由本契约 [S-11](#s-11-复制的收场) 的写集合给（取发起这次复制的那次调用的上下文），那一侧照收 |
| **`capability.asset-governance`：删除与提升** | 删除、提升一份有 active 分享的资产时，分享那一侧怎么收场 | [S-52](#s-52-分享方删除资产或所有权易手分享随之结束)：同一次提交里写 `revoked`（`sourceDeleted`／`ownerChanged`），持有不动 | **提升与删除都够**（那份 `#S-27`、`#S-28` ④⑧ 已列进，原 [G-15](#十一已知缺口) 闭合）。**这是那份契约替本条兑现的反向义务，不进 catalog**：登记会成环；**本条（S-52）一改，须回头核对 `capability.asset-governance/v2` 的 S-27、S-28 ④⑧**。分享结束不通知，被分享方经 [S-30](#s-30-列出组织的分享) 读结束原因（[S-33](#s-33-本版不发本契约自己的事件)） |
| **`capability.organization-governance` v3：两个时刻** | （提供者一侧的核对）本契约要读的两个时刻它给不给、从哪一面给 | [S-9](#s-9-分享此刻是否生效) 读它的 `#S-22`（隶属建立时刻）与 `#S-59`（成员关系生效时刻，默认档；调用主体是运行时代行，[S-9](#s-9-分享此刻是否生效) ②、[S-34](#s-34-装配给的保证-vs-协议须给的保证)） | **够**；它没有「按 `TenantId` 读一条成员关系」的面，`#S-26` 不带时刻，所以租户那一端的时刻经 `#S-59` 取——那一面要求调用方是有效成员，正好与 ① 的判定同向 |
| **`data.identity-values/v1` 的 CS-3**（前提核对，主线裁定 D-060 §三 R2-3） | 它把 `sameAccountDistinctTenants` 写成一切资产复制的前提 | 本契约只在本人型那一支用它；组织型两侧按各自组织的租户身份分别署名，账号相同不构成本人型（[S-4](#s-4-依赖方向与被消费的面) 身份值侧 `#S-13` 那一行、[S-10](#s-10-复制血缘怎么判怎么记)） | **够**：按这个读法 CS-3 成立，那份冻结契约不改、不开缺口 |
| **注册表：变化后重填** | 知道什么时候该重填 | 本版没有本契约的事件（[S-33](#s-33-本版不发本契约自己的事件)）；落地与持有变化走资产治理的事件；分享因撤销、解除或退出而不可用**不产生持有变化**，只能在下一次求值时显现 | **够**：正确性靠使用时判 |
| **审计** | 谁、何时、对什么、依据什么 | 两类待确认件的终结记录与分享的确认／结束记录都带行为人与时刻；本人型的分享记录带发起者与确认时刻 | **够**（读面） |
| **`data.offer-expiry/v1`**（[G-6](../../../data/offer-expiry/v1/contract.md#八已知缺口) 点名的五件事） | 非法时长的拒绝值、三路同收的那个值、派生状态读面、存在性读面、资产标识不复用 | `invalidInput`、`offerNoLongerValid`、[S-23](#s-23-读复制通知)／[S-27](#s-27-读分享邀请)、[S-7](#s-7-两类待确认件共用的过期语义) | **前四件够**；第五件已由 `data.asset-model/v2#S-4` 给出；持有实例身份仍在 [G-3](#十一已知缺口) |

---

## 十三、版本差异与规范工件

**本版是首版**，没有被采用的旧版本；候选期内的修订记在[验证入口](../verification.md)「变化的影响」。
**本版的规范工件**：本文件、[`examples.md`](examples.md)、[`formal/Transfer.tla`](formal/Transfer.tla) 与它的十六个检查配置（三个正例、十三个去保护配置），映射在 [`formal/README.md`](formal/README.md)。
接受状态、冻结记录与执行结果都在本版本目录之外维护，本文件不填进度、通过状态或哈希。
