from pathlib import Path
import hashlib
import json
import re

ROOT = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
OUT = ROOT / 'tmp/core-delivery/skill-v3-independent'
OUT.mkdir(parents=True, exist_ok=True)
source = ROOT / '.meta_harness/design/spec/data/skill-package/v3/examples.md'
section = source.read_text().split('### 6.1 完整映射图的键唯一性')[1].split('## 7.')[0]
cases = []
for index, line in enumerate(line for line in section.splitlines() if line.startswith('| `"')):
    columns = line.split('|')
    text = json.loads(columns[1].strip()[1:-1])
    expected = {'rejected': 'malformed', 'malformed': 'M16'}
    if columns[2].strip() == '成功':
        expected = {'manifest': {'name': 'x', 'description': 'd'},
                    'body': json.loads(columns[3].strip()[1:-1])}
    cases.append({'id': f'normative-text-{index + 1:02}', 'source': 'examples.md §6.1 row ' + str(index + 1),
                  'clauses': ['S-5', 'S-20', 'S-24/M16'], 'text': text,
                  'expected': expected, 'rationale': columns[4].strip()})
assert len(cases) == 14

def wrap(content, body='\n  $ARGUMENTS\n${CLAUDE_SKILL_DIR}\n!`never-run`\n\tend  \n'):
    return '---\nname: review\ndescription: independent routing description\n' + content + '\n---\n' + body

def add(name, content, rejection=True, body=None, expected_unknown=None):
    text = wrap(content) if body is None else wrap(content, body)
    expected = {'rejected': 'malformed', 'malformed': 'M16'} if rejection else {
        'manifest': {'name': 'review', 'description': 'independent routing description'},
        'body': text.split('\n---\n', 1)[1]}
    case = {'id': name, 'source': 'independently constructed from Skill3 S-5/S-20/S-24',
            'clauses': ['S-5', 'S-8', 'S-20', 'S-24/M16'], 'text': text, 'expected': expected}
    if expected_unknown is not None:
        case['expected_unknown'] = expected_unknown
    cases.append(case)

add('independent-unknown-different-spellings', '!tenant alpha: one\n!tenant beta: two')
add('independent-ignored-map-alias', 'unknown: &node\n  !tenant alpha: one\n  !tenant beta: two\ncopy: *node')
add('independent-recursive-sequence-ambiguity', '? &left [!tenant alpha, *left]\n: one\n? &right [!tenant beta, *right]\n: two')
add('independent-recursive-sequence-known-unequal', '? &left [!tenant alpha, left, *left]\n: one\n? &right [!tenant beta, right, *right]\n: two', False)
add('independent-complex-map-known-unequal-value', '? {id: left, opaque: !tenant alpha}\n: one\n? {id: right, opaque: !tenant beta}\n: two', False)
add('independent-complex-map-unknown-key-known-unequal-value', '? { !tenant alpha: left }\n: one\n? { !tenant beta: right }\n: two', False)
add('independent-unsupported-global-value', 'unknown: !!timestamp 2026-09-26', False, expected_unknown=[{'key': 'unknown', 'category': 'unknown'}])
add('independent-ordinary-external-and-unknown', 'version: 9.7.2\nuser-invocable: false\nunknown: !tenant ignored', False,
    expected_unknown=[{'key': 'version', 'category': 'unknown'}, {'key': 'user-invocable', 'category': 'external_attribute'}, {'key': 'unknown', 'category': 'unknown'}])
add('independent-alias-core-string', 'unknown: &node !!str yes\nlicense: *node', False)
cases[-1]['expected']['manifest']['license'] = 'yes'
add('independent-duplicate-known-key', 'unknown: {first: one, first: two}')
add('independent-invalid-core-tag-value', 'unknown: !!bool not-a-bool')
add('independent-lossless-number-distinct-key', '? 9007199254740992\n: one\n? 9007199254740993\n: two', False)
add('independent-lossless-number-equivalent-key', '? 0x10\n: one\n? 16\n: two')
add('independent-empty-body', 'version: ignored', False, '')
add('independent-known-unequal-tags', '!tenant alpha: one\n!another alpha: two', False)
add('independent-unsupported-global-key-ambiguity', '!!timestamp 2026-09-26: one\n!!timestamp 2026-09-27: two')

directory = []
def dir_case(name, text_case, entries, expected, source='S-21/S-24 independent combination'):
    directory.append({'id': name, 'source': source, 'clauses': ['S-21', 'S-24'],
                      'text_case': text_case, 'entries': entries, 'expected': expected})
reject = {'rejected': 'malformed', 'malformed': 'M16'}
dir_case('normative-directory-01', 'normative-text-01', [], reject, 'examples.md §10 row 9')
dir_case('normative-directory-02', 'normative-text-03', [{'kind': 'file', 'path': 'references/a.md'}], reject, 'examples.md §10 row 10')
dir_case('normative-directory-03', 'normative-text-11', [{'kind': 'file', 'path': 'references/a.md'}],
         {'manifest': {'name': 'x', 'description': 'd'}, 'body': '\r\nRun $ARGUMENTS\r\n', 'resources': [{'path': 'references/a.md'}]},
         'examples.md §10 row 11')
dir_case('directory-m16-and-dotdot', 'independent-unknown-different-spellings', [{'kind': 'file', 'path': '../outside'}], {'rejected': 'resource_escapes'})
dir_case('directory-m16-and-outside-link', 'independent-unknown-different-spellings', [{'kind': 'link', 'path': 'references/escape', 'resolution': 'outside'}], {'rejected': 'resource_escapes'})
dir_case('directory-m16-and-unsupported-definition', 'independent-unknown-different-spellings', [{'kind': 'file', 'path': '.omne/skill.json', 'text': '{"format":2}'}], {'rejected': 'definition_format_unsupported'})
dir_case('directory-m16-and-invalid-tool-reference', 'independent-unknown-different-spellings', [{'kind': 'file', 'path': '.omne/skill.json', 'text': '{"format":1,"tools":[{"category":"skill","name":"other"}]}'}], {'rejected': 'tool_ref_invalid'})
dir_case('directory-m16-and-unknown-layer', 'independent-unknown-different-spellings', [{'kind': 'file', 'path': '.omne/skill.json', 'text': '{"format":1,"environmentRequirement":{"bindingLayer":"unrecognized","facilities":[]}}'}], {'rejected': 'binding_layer_unknown'})
dir_case('directory-m16-and-unknown-setting-category', 'independent-unknown-different-spellings', [{'kind': 'file', 'path': '.omne/skill.json', 'text': '{"format":1,"settings":[{"item":"style","kind":"setting","category":"unrecognized","domain":{"kind":"open","schema":{"type":"string"}},"default":"plain"}]}'}], {'rejected': 'setting_category_unknown'})
dir_case('directory-m16-and-unresolved-link', 'independent-unknown-different-spellings', [{'kind': 'link', 'path': 'references/cycle', 'resolution': 'cycle'}], reject)

data = {'format': 1, 'authority': 'accepted data.skill-package/3 S-5/S-8/S-20/S-21/S-24 plus D069 provider adoption',
        'spec_examples_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'text_cases': cases, 'directory_cases': directory,
        'limits': ['entries are caller supplied; no actual filesystem link resolution is claimed',
                   'readers are pure; no real Skills runtime, authorization, scripts, transport, registration or storage is claimed']}
(OUT / 'fixtures.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'text_cases': len(cases), 'directory_cases': len(directory), 'normative_added_rows': 17}))
