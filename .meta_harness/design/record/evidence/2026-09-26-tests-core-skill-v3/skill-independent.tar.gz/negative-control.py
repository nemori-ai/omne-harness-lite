from pathlib import Path
import difflib
import hashlib
import json
import shutil
import subprocess

HUB = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
BASE = HUB / 'tmp/core-delivery/skill-v3-independent'
OUT = BASE / 'negative-control'
assert not OUT.exists(), 'Keep original runs; choose a new run directory explicitly for any retry'
OUT.mkdir()
SOURCE = HUB / 'packages/core/skill-package'
original_md = (SOURCE / 'dist/md.js').read_bytes()
sha = lambda data: hashlib.sha256(data).hexdigest()

def digest_tree(path):
    return {str(p.relative_to(path)): sha(p.read_bytes()) for p in sorted(path.rglob('*')) if p.is_file()}

def exact_target_failure(receipt):
    assertion = receipt.get('assertion', {})
    return (assertion.get('name') == 'AssertionError'
            and assertion.get('code') == 'ERR_ASSERTION'
            and 'D069 unknown scalar canonical ambiguity must be M16' in assertion.get('message', '')
            and assertion.get('expected') == {'rejected': 'malformed', 'malformed': 'M16'}
            and isinstance(assertion.get('actual'), dict)
            and 'ok' in assertion['actual']
            and assertion.get('actual') == receipt.get('observed'))

# The result classifier must reject unrelated process errors and other failed assertions.
wrong_module = {'assertion': {'name': 'Error', 'code': 'ERR_MODULE_NOT_FOUND'}}
wrong_assertion = {'assertion': {'name': 'AssertionError', 'code': 'ERR_ASSERTION',
                               'expected': 'another output', 'actual': {'ok': {}}}}
assert not exact_target_failure(wrong_module)
assert not exact_target_failure(wrong_assertion)
matcher_selfcheck = {'module_error_rejected': True, 'unrelated_assertion_rejected': True}

for name in ['clean', 'mutant']:
    package = OUT / name / 'package'
    package.mkdir(parents=True)
    for directory in ['dist', 'schema']:
        shutil.copytree(SOURCE / directory, package / directory)
    shutil.copy2(SOURCE / 'package.json', package / 'package.json')
    (OUT / name / 'copied-input-sha256.json').write_text(json.dumps(digest_tree(package), indent=2) + '\n')
    (package / 'node_modules').symlink_to(SOURCE / 'node_modules', target_is_directory=True)
    assert (package / 'dist/md.js').read_bytes() == original_md

md = original_md.decode()
predicate = 'keys.tags.size !== 0'
assert md.count(predicate) == 1, 'Confer with root if the final precise ambiguity branch differs'
branch = md[md.index(predicate):md.index(predicate) + 200]
assert 'return rejected()' in branch, 'Only mutate the current rejection predicate, never an arbitrary branch'
mutated = md.replace(predicate, 'false /* independent negative control: permit unknown key ambiguity */', 1)
mutant_path = OUT / 'mutant/package/dist/md.js'
mutant_path.write_text(mutated)
(OUT / 'mutation.diff').write_text(''.join(difflib.unified_diff(md.splitlines(keepends=True), mutated.splitlines(keepends=True), fromfile='clean/dist/md.js', tofile='mutant/dist/md.js')))
mutation = {'file': 'dist/md.js', 'clean_sha256': sha(original_md), 'mutant_sha256': sha(mutant_path.read_bytes()),
            'old_predicate': predicate, 'replacement': 'false',
            'scope': 'Only unknown scalar canonical ambiguity rejection is suppressed; known duplicate rejection remains enabled'}
(OUT / 'mutation.json').write_text(json.dumps(mutation, indent=2) + '\n')

commands = []
for name in ['clean', 'mutant']:
    receipt = OUT / name / 'observation.json'
    command = ['node', str(BASE / 'negative-probe.mjs'), str(OUT / name / 'package'), str(receipt)]
    run = subprocess.run(command, cwd=str(HUB), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (OUT / name / 'stdout.log').write_bytes(run.stdout)
    (OUT / name / 'stderr.log').write_bytes(run.stderr)
    commands.append({'name': name, 'argv': command, 'cwd': str(HUB), 'exit_code': run.returncode,
                     'stdout_sha256': sha(run.stdout), 'stderr_sha256': sha(run.stderr)})
    (OUT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert receipt.exists(), f'{name}: missing observation is a measurement failure, not successful negative control'
    observation = json.loads(receipt.read_text())
    if name == 'clean':
        assert run.returncode == 0, 'Clean copied build must pass the exact fixture'
        assert observation['observed'] == {'rejected': 'malformed', 'malformed': 'M16'}
        assert 'assertion' not in observation
    else:
        assert run.returncode == 1, 'Mutant must fail the target assertion'
        assert exact_target_failure(observation), 'Do not count an unrelated exception as target detection'

assert (SOURCE / 'dist/md.js').read_bytes() == original_md, 'The live HUB build must remain untouched'
receipt = {'status': 'pass', 'clean_exit': commands[0]['exit_code'], 'mutant_exit': commands[1]['exit_code'],
           'target_assertion_detected': True, 'live_md_unchanged': True, 'mutation': mutation,
           'matcher_selfcheck': matcher_selfcheck,
           'limits': ['Scratch copied compiled module only; no product source or HUB dist mutation',
                      'This control detects erroneous admission of the chosen unknown-tag ambiguity, not all reader defects']}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
