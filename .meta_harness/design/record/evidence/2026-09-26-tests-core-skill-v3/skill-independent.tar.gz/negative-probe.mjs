import assert from 'node:assert/strict'
import { readFileSync, writeFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

const base = '/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery/tmp/core-delivery/skill-v3-independent'
const packagePath = resolve(process.argv[2])
const outputPath = resolve(process.argv[3])
const fixture = JSON.parse(readFileSync(`${base}/fixtures.json`, 'utf8')).text_cases.find(
  test => test.id === 'independent-unknown-different-spellings',
)
const expected = { rejected: 'malformed', malformed: 'M16' }
const api = await import(pathToFileURL(`${packagePath}/dist/index.js`).href)
const observed = api.readSkillMd(fixture.text)
const receipt = { fixture_id: fixture.id, text: fixture.text, expected, observed }
writeFileSync(outputPath, JSON.stringify(receipt, null, 2) + '\n')
try {
  assert.deepEqual(observed, expected, 'D069 unknown scalar canonical ambiguity must be M16')
  process.stdout.write(JSON.stringify(receipt) + '\n')
} catch (error) {
  writeFileSync(outputPath, JSON.stringify({ ...receipt, assertion: {
    name: error.name, code: error.code, message: error.message,
    expected: error.expected, actual: error.actual,
  } }, null, 2) + '\n')
  throw error
}
