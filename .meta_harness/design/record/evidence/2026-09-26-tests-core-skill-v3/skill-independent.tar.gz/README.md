# W7 Skill3 independent verification

Status: independent verification completed on integrated source `06b85a14ab3439b35b4f51211adcb0731fea6908`. Final behavior run: **54 pass, 0 fail**. Strict type check passed. The target negative control detected the intended erroneous admission. This task has no acceptance authority. Detailed results and limits are in `report.md` and `receipt.json`.

Execution repository: `/data/qiwei/repos/omne-harness-lite`. Assigned HUB: `.worktrees/core-delivery`, branch `panqiwei/core-delivery`, initial inspected HEAD `f877aeb22924cae33abc884c35402a9732d0e177`.

The only writable area for this task is this temporary directory. Product sources, existing tests, schemas, design, Git index, locks and live build outputs are read-only. The source developer owns the separate Skill3 spoke; the root planner owns the integrated build and acceptance.

Inputs were actually read from the HUB: W7 delivery plan and realization brief; D069 decision, construction brief and acceptance; Skill3 normative contract, schema and examples; Skill provider design and verification; relevant current AM3/AE3/Slash2 public operations and AE3 C1 shape constraints. Earlier Skill2 status paragraphs retain their historical scope; D069's accepted adoption controls the current version.

The reviewed normative hashes match the acceptance:

| Resource | SHA256 |
| --- | --- |
| Skill3 contract | `9d314af4e4063c84303b79a5558adef6515580ccd4cdd2b40836bc300f01537b` |
| Skill3 schema | `8c4a5352cccb695d94072828c5881486e8cdd5474a2213a3a621b17e3fbc836b` |
| Skill3 examples | `304122a7b1e8301a468148d31702ff55ed5f7debf06b2e79e0b4df291fee6536` |

`prepare-fixtures.py` reads the accepted normative examples, then adds independently constructed scenarios. Its preparation was executed and produced `fixtures.json`: 30 text cases and 10 directory cases, including all 14 new normative text rows and all 3 new normative directory rows. No product module was imported during preparation.

`verify.mjs` observes actual public package entrypoints and compiled HUB modules. It compares manifests, exact body text, ignored-key diagnostics, exact rejection and malformed codes; tests directory violation precedence; compiles all five own definitions against the finite old2/current3 resource sets; compares complete public schema files with frozen normative bytes; tests actual AM3, AE3 and Slash2 consumers with own-version author references. It hashes all relevant sources, compiled outputs, schemas and lock inputs before and after the run. Input drift invalidates the run.

`public-types.mts` and `tsconfig.json` require strict checking with `skipLibCheck: false` and `noEmit`, no current third read-result alternative, and no old text or directory reader in the retained pure-value entrypoint.

`negative-control.py` creates clean and mutant copies inside this directory. It suppresses only the unknown canonical ambiguity rejection predicate in copied compiled `md.js`; it never changes the live HUB build. Both copies run `negative-probe.mjs` with the same independent fixture. Success requires clean exit 0 and mutant exit 1 specifically caused by `AssertionError` / `ERR_ASSERTION` with expected `{rejected:'malformed', malformed:'M16'}` and actual success. The classifier rejects unrelated module errors and other assertions. Original outputs, mutation diff and hashes are preserved.

Limits: directory entries are caller-supplied observations. These scenarios do not resolve actual links, execute scripts, register assets, contact external services, enforce runtime authorization, supply Connector behavior or verify production consumers. Compiling all five Skill definitions does not claim every AM2 definition has the same closed resource graph. Shared CS observations cover the core steps only; external obligations and human overall acceptance remain with their owners.

Successful actual commands (original stdout, stderr and exit codes are indexed in `commands.json`):

```sh
node tmp/core-delivery/skill-v3-independent/verify.mjs tmp/core-delivery/skill-v3-independent/run-r2
node packages/core/skill-package/node_modules/typescript/bin/tsc -p tmp/core-delivery/skill-v3-independent/tsconfig.json
python3 tmp/core-delivery/skill-v3-independent/negative-control.py
```

Original failures are preserved: behavior R1 rejected this task's incorrectly constructed Slash invocation span (`end: 21`); frozen Slash2 S14 specifies the `/name` span (`end: 7`), and only that fixture was corrected for R2. The root `pnpm exec tsc` command was unavailable (exit 254), so strict checking used the already installed Skill member's TypeScript binary. Neither event was a product defect or reclassified as a pass.

The before/after records bind 483 relevant source, declaration, compiled module, schema, registry and lock files. Every one remained unchanged through final behavior, strict type checking and the copied-module negative control. Raw original commands keep their historical absolute checkout paths. Reproduction needs the recorded source commit, locked dependencies and the declared tool versions; package links under this directory are environment setup, not archived dependency bytes.
