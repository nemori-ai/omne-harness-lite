import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { existsSync, readFileSync, readdirSync, writeFileSync, mkdirSync, symlinkSync } from 'node:fs'
import { resolve, relative, join } from 'node:path'
import { pathToFileURL } from 'node:url'

const hub = '/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery'
const base = resolve(hub, 'tmp/core-delivery/skill-v3-independent')
const resultDirectory = resolve(process.argv[2] ?? join(base, 'run'))
mkdirSync(resultDirectory, { recursive: true })
const names = ['skill-package', 'asset-model', 'asset-evaluation', 'slash-command', 'content-blocks', 'tool-definition', 'loop-extension', 'mcp-endpoint', 'identity-values', 'offer-expiry']
mkdirSync(join(base, 'node_modules/@omne-harness-lite'), { recursive: true })
for (const name of names) {
  const link = join(base, 'node_modules/@omne-harness-lite', name)
  if (!existsSync(link)) symlinkSync(resolve(hub, 'packages/core', name), link, 'dir')
}
const sha = input => createHash('sha256').update(input).digest('hex')
const json = path => JSON.parse(readFileSync(path, 'utf8'))
const fixtures = json(join(base, 'fixtures.json'))
function inputs() {
  const files = new Set(['pnpm-lock.yaml', 'pnpm-workspace.yaml'])
  function visit(directory) {
    for (const item of readdirSync(resolve(hub, directory), { withFileTypes: true })) {
      const path = join(directory, item.name)
      if (item.isDirectory()) visit(path)
      else if (item.isFile()) files.add(path)
    }
  }
  for (const name of names) {
    files.add(`packages/core/${name}/package.json`)
    for (const directory of ['src', 'dist', 'schema']) {
      const path = `packages/core/${name}/${directory}`
      if (existsSync(resolve(hub, path))) visit(path)
    }
  }
  const specDirectory = '.meta_harness/design/spec/data/skill-package'
  for (const version of ['v2', 'v3']) visit(`${specDirectory}/${version}`)
  files.add('.meta_harness/design/registry/catalog.json')
  files.add('.meta_harness/design/registry/frozen.json')
  files.add('.meta_harness/design/record/decisions/skill-yaml-key-resolution/acceptance.json')
  return {
    head: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: hub, encoding: 'utf8' }).trim(),
    files: Object.fromEntries([...files].sort().map(path => [path, sha(readFileSync(resolve(hub, path)))])),
    fixtures_sha256: sha(readFileSync(join(base, 'fixtures.json'))),
    runner_sha256: sha(readFileSync(new URL(import.meta.url))),
  }
}
const before = inputs()
writeFileSync(join(resultDirectory, 'inputs-before.json'), JSON.stringify(before, null, 2) + '\n')
const root = await import('@omne-harness-lite/skill-package')
const retained = await import('@omne-harness-lite/skill-package/v2')
const asset = await import('@omne-harness-lite/asset-model')
const evaluation = await import('@omne-harness-lite/asset-evaluation')
const slash = await import('@omne-harness-lite/slash-command')
const schemaRuntime = await import('@omne-harness-lite/content-blocks/schema-runtime')
const rootSchema = (await import('@omne-harness-lite/skill-package/schema', { with: { type: 'json' } })).default
const retainedSchema = (await import('@omne-harness-lite/skill-package/schema/v2', { with: { type: 'json' } })).default
const asset2 = (await import('@omne-harness-lite/asset-model/schema/v2', { with: { type: 'json' } })).default
const content2 = (await import('@omne-harness-lite/content-blocks/schema/v2', { with: { type: 'json' } })).default
const tool2 = (await import('@omne-harness-lite/tool-definition/schema/v2', { with: { type: 'json' } })).default
const records = []
function scenario(id, clauses, action, input = undefined) {
  try {
    const observed = action()
    records.push({ id, clauses, status: 'pass', ...(input === undefined ? {} : { input }), observed })
    process.stdout.write(JSON.stringify({ id, status: 'pass' }) + '\n')
  } catch (error) {
    records.push({ id, clauses, status: 'fail', ...(input === undefined ? {} : { input }),
      error: { name: error.name, code: error.code, message: error.message, actual: error.actual, expected: error.expected, stack: error.stack } })
    process.stdout.write(JSON.stringify({ id, status: 'fail', error: error.message }) + '\n')
  }
}
function checkRead(test, result, directory = false) {
  if (test.expected.rejected !== undefined) {
    assert.deepEqual(result, test.expected, `${test.id}: expected precise representation rejection`)
    return result
  }
  assert.ok(Object.hasOwn(result, 'ok'), `${test.id}: success required`)
  assert.deepEqual(Object.keys(result), ['ok'], `${test.id}: exactly the success alternative`)
  const value = directory ? result.ok.package : result.ok
  assert.deepEqual(value.manifest, test.expected.manifest, `${test.id}: unknown fields must not become manifest`)
  assert.equal(value.body, test.expected.body, `${test.id}: body must retain every character`)
  if (directory) assert.deepEqual(value.resources, test.expected.resources)
  assert.ok(result.ok.unknownKeys.length > 0, `${test.id}: ignored-key diagnostics must be visible`)
  for (const trace of result.ok.unknownKeys) {
    assert.equal(typeof trace.keySource, 'string')
    assert.ok(trace.keySource.length > 0, `${test.id}: trace preserves actual source spelling`)
    assert.ok(['external_attribute', 'unknown'].includes(trace.category))
  }
  if (test.expected_unknown !== undefined) {
    assert.deepEqual(result.ok.unknownKeys.map(({ key, category }) => ({ key, category })), test.expected_unknown)
  }
  return result
}
scenario('accepted-current-and-retained-resources', ['D069 acceptance', 'S-22'], () => {
  const acceptance = json(resolve(hub, '.meta_harness/design/record/decisions/skill-yaml-key-resolution/acceptance.json'))
  const catalog = json(resolve(hub, '.meta_harness/design/registry/catalog.json'))
  const frozen = json(resolve(hub, '.meta_harness/design/registry/frozen.json'))
  for (const version of [2, 3]) {
    const registration = catalog.contracts.find(entry => entry.coordinate.contract_id === 'data.skill-package' && entry.coordinate.version === version)
    assert.equal(registration.status, 'accepted')
    assert.deepEqual(registration.dependencies.map(entry => [entry.coordinate.contract_id, entry.coordinate.version]).sort(),
      [['data.asset-model', 2], ['data.content-blocks', 2], ['data.tool-definition', 2]])
    for (const resource of registration.resources) assert.equal(sha(readFileSync(resolve(hub, '.meta_harness/design', resource))), frozen.files[resource])
  }
  for (const [path, hash] of Object.entries(acceptance.accepts[0].resources)) {
    assert.equal(sha(readFileSync(resolve(hub, '.meta_harness/design', path))), hash)
  }
  const manifest = json(resolve(hub, 'packages/core/skill-package/package.json'))
  const locations = {
    './schema': '.meta_harness/design/spec/data/skill-package/v3/skill-package.schema.json',
    './schema/v2': '.meta_harness/design/spec/data/skill-package/v2/skill-package.schema.json',
  }
  for (const [exportName, spec] of Object.entries(locations)) {
    assert.equal(typeof manifest.exports[exportName], 'string')
    assert.deepEqual(readFileSync(resolve(hub, 'packages/core/skill-package', manifest.exports[exportName])), readFileSync(resolve(hub, spec)))
  }
  assert.equal(root.schemaId, rootSchema.$id)
  assert.equal(retained.schemaId, retainedSchema.$id)
  assert.equal(root.skillBodyContract.schema.$id, rootSchema.$id)
  assert.equal(retained.skillBodyContract.schema.$id, retainedSchema.$id)
  assert.equal(evaluation.defaultBodyContracts.skill.schema.$id, retainedSchema.$id)
  return { current: rootSchema.$id, retained: retainedSchema.$id, default_evaluation_skill: evaluation.defaultBodyContracts.skill.schema.$id }
})
scenario('finite-schema-binding-all-five-own-definitions', ['S-22', 'D069 provider resources'], () => {
  const definitions = {
    SkillName: { valid: 'review', invalid: 'review/name' },
    SkillManifest: { valid: { name: 'review', description: 'routing' }, invalid: { name: 'review', description: 42 } },
    ResourceEntry: { valid: { path: 'references/a.md' }, invalid: { path: '../outside' } },
    SkillDefinitionRecord: { valid: { format: 1 }, invalid: { format: 2 } },
    SkillPackage: { valid: { manifest: { name: 'review', description: 'routing' }, body: '', resources: [] }, invalid: { manifest: { name: 'review', description: 'routing' }, body: '' } },
  }
  const result = []
  for (const [version, port, schema, resources] of [[2, retained, retainedSchema, [retainedSchema, asset2, content2, tool2]], [3, root, rootSchema, [retainedSchema, asset2, content2, tool2, rootSchema]]]) {
    const runtime = schemaRuntime.createSchemaRuntime(resources)
    assert.deepEqual([...port.SCHEMA_DEF_NAMES].sort(), Object.keys(definitions).sort())
    for (const [name, data] of Object.entries(definitions)) {
      const validator = runtime.compile({ $ref: `${schema.$id}#/$defs/${name}` })
      assert.equal(validator.validate(data.valid), true)
      assert.equal(validator.validate(data.invalid), false)
      assert.deepEqual(port.validate(name, data.valid), { valid: true })
      assert.deepEqual(port.validate(name, data.invalid), { valid: false })
      result.push({ version, definition: name, valid: true, invalid: false })
    }
  }
  return result
})
for (const test of fixtures.text_cases) {
  scenario(test.id, test.clauses, () => checkRead(test, root.readSkillMd(test.text)), { text: test.text, expected: test.expected, source: test.source })
}
for (const test of fixtures.directory_cases) {
  const text = fixtures.text_cases.find(candidate => candidate.id === test.text_case).text
  const entries = [{ kind: 'file', path: 'SKILL.md', text }, ...test.entries]
  scenario(test.id, test.clauses, () => checkRead(test, root.readSkillPackage(entries), true), { entries, expected: test.expected, source: test.source })
}
scenario('directory-manifest-absence-precedes-escape', ['S-21', 'S-24'], () => {
  const entries = [{ kind: 'file', path: '../outside' }]
  const result = root.readSkillPackage(entries)
  assert.deepEqual(result, { rejected: 'manifest_missing' })
  return { entries, result }
})
scenario('v2-pure-entrypoint-has-no-readers', ['D069 provider adoption'], () => {
  for (const name of ['readSkillMd', 'readSkillPackage', 'SkillReadUndetermined']) assert.equal(Object.hasOwn(retained, name), false)
  for (const name of ['judgeSkillPackage', 'isSkillPackage', 'skillAttributeDeclarations', 'skillReferences', 'skillDependencies', 'skillScripts', 'skillBodyContract', 'schemaId', 'SCHEMA_DEF_NAMES', 'validate']) assert.ok(Object.hasOwn(retained, name), name)
  return Object.keys(retained).sort()
})
const makePackage = version => ({
  manifest: { name: 'review', description: 'independent routing description' },
  body: '\n  $ARGUMENTS\r\n${CLAUDE_SKILL_DIR}\n!`never-run`\n',
  resources: [],
  definition: { format: 1, settings: [{ item: 'style', kind: 'setting', category: 'preference',
    domain: { kind: 'open', schema: { $ref: `${version === 3 ? rootSchema.$id : retainedSchema.$id}#/$defs/SkillName` } }, default: 'plain' }] },
})
for (const version of [2, 3]) {
  const pkg = makePackage(version)
  scenario(`author-schema-own-ref-${version}`, ['S-15', 'S-24/M12', 'D069 version binding'], () => {
    const current = root.judgeSkillPackage(pkg)
    const old = retained.judgeSkillPackage(pkg)
    const currentBody = root.skillBodyContract.judge(pkg)
    const oldBody = retained.skillBodyContract.judge(pkg)
    assert.deepEqual(current, { ok: true })
    assert.deepEqual(currentBody, { ok: true })
    const oldExpected = version === 2 ? { ok: true } : { rejected: 'malformed', malformed: 'M12' }
    assert.deepEqual(old, oldExpected)
    assert.deepEqual(oldBody, oldExpected)
    assert.equal(retained.isSkillPackage(pkg), version === 2)
    assert.equal(root.isSkillPackage(pkg), true)
    return { pkg, current, old, currentBody, oldBody }
  }, pkg)
  scenario(`actual-AM3-consumer-own-ref-${version}`, ['Skill CS-1 core slice', 'AM3 S-10', 'D069'], () => {
    const judge = asset.createAssetModelJudge(evaluation.defaultBodyContracts)
    const result = judge.judgeAssetValue('AssetContent', { category: 'skill', body: pkg })
    assert.deepEqual(result, version === 2 ? { ok: true } : { rejected: 'malformed' })
    return { result }
  }, pkg)
  scenario(`actual-Slash2-consumer-own-ref-${version}`, ['Skill CS-5 core slice', 'S-8', 'D069'], () => {
    const invocation = { raw: '/review', name: 'review', argumentText: '', span: { start: 0, end: 7 } }
    const annotations = [{ id: 'independent-body', visibility: { toHuman: true, toModel: true } }]
    if (version === 3) {
      assert.throws(() => slash.expandSkill(invocation, 'review', pkg, annotations), { name: 'TypeError', message: 'valid invocation, selected SkillPackage and annotations required' })
      return { outcome: 'precise TypeError refusing invalid selected Skill2 package' }
    }
    const result = slash.expandSkill(invocation, 'review', pkg, annotations)
    assert.equal(result.length, 1)
    assert.equal(result[0].text, pkg.body)
    assert.deepEqual(result[0].origin, { kind: 'skill_body', command: 'review', skill: 'review' })
    return { result }
  }, pkg)
  scenario(`actual-AE3-consumer-own-ref-${version}`, ['AE3 C1', 'Skill CS-7 core slice', 'D069'], () => {
    const tenant = { organization: 'independent-org', account: 'independent-account' }
    const definition = { id: 'independent-skill', capability: { category: 'skill', name: 'review' }, origin: 'customized',
      owner: { kind: 'tenant', tenant }, author: tenant, byAgent: false, versions: [], draft: { category: 'skill', body: pkg } }
    const input = { tenant, standing: { standing: 'effective', role: 'member' }, holdings: [], definitions: [definition],
      root: { definition: { category: 'agent_definition', name: 'root' }, references: [] } }
    const result = evaluation.evaluate(input)
    if (version === 3) {
      assert.deepEqual(result, { invalidInput: { diagnostics: [{ condition: 'C1', message: 'AssetDefinition', rejected: 'malformed' }] } })
    } else {
      assert.ok(Object.hasOwn(result, 'ok'), 'valid old2 content must be admitted by actual evaluation entrypoint')
      assert.deepEqual(result.ok.composition, [])
    }
    return { input, result }
  }, pkg)
}
scenario('current-reader-to-retained-values-to-Slash-byteexact', ['Skill CS-3/CS-5/CS-6 core slices', 'S-8', 'S-20', 'D069'], () => {
  const test = fixtures.text_cases.find(candidate => candidate.id === 'normative-text-11')
  const result = root.readSkillPackage([{ kind: 'file', path: 'SKILL.md', text: test.text }])
  assert.ok(Object.hasOwn(result, 'ok'))
  assert.deepEqual(retained.judgeSkillPackage(result.ok.package), { ok: true })
  const invocation = { raw: '/review separate text', name: 'review', argumentText: 'separate text', span: { start: 0, end: 7 } }
  const blocks = slash.expandSkill(invocation, 'x', result.ok.package, [{ id: 'body', visibility: { toHuman: true, toModel: true } }, { id: 'args', visibility: { toHuman: true, toModel: true } }])
  assert.deepEqual(blocks.map(block => block.text), ['\r\nRun $ARGUMENTS\r\n', 'separate text'])
  return { read: result, blocks }
})
const after = inputs()
writeFileSync(join(resultDirectory, 'inputs-after.json'), JSON.stringify(after, null, 2) + '\n')
scenario('execution-inputs-remained-stable', ['evidence provenance'], () => {
  assert.deepEqual(after, before)
  return { head: before.head, file_count: Object.keys(before.files).length }
})
const report = { format: 1, node: process.version, platform: process.platform, architecture: process.arch,
  source: before.head, inputs_sha256: sha(JSON.stringify(before)), passed: records.filter(item => item.status === 'pass').length,
  failed: records.filter(item => item.status === 'fail').length, records,
  limits: [...fixtures.limits, 'finite resource graph compiles each Skill own definition; it does not compile all AM2 definitions',
    'whole external CS obligations, Connector, production consumers and human final acceptance remain outside this run'] }
writeFileSync(join(resultDirectory, 'observations.json'), JSON.stringify(report, null, 2) + '\n')
process.stdout.write(JSON.stringify({ passed: report.passed, failed: report.failed, source: report.source }) + '\n')
if (report.failed !== 0) process.exitCode = 1
