import type { SkillMdReadResult, SkillPackageReadResult } from '@omne-harness-lite/skill-package'
import * as retained from '@omne-harness-lite/skill-package/v2'

type HasNoUndetermined<T> = Extract<T, { readonly undetermined: unknown }> extends never
  ? true
  : false
const mdHasNoThirdAlternative: HasNoUndetermined<SkillMdReadResult> = true
const packageHasNoThirdAlternative: HasNoUndetermined<SkillPackageReadResult> = true

function currentReadResult(result: SkillMdReadResult | SkillPackageReadResult): unknown {
  return 'ok' in result ? result.ok : result.rejected
}

// The current source deliberately removed the old implementation-only type.
// @ts-expect-error No removed third-result type is part of the current public entrypoint.
type RemovedGap = import('@omne-harness-lite/skill-package').SkillReadUndetermined
// @ts-expect-error The retained entrypoint supplies data/body contracts only, not old text readers.
const oldTextReader = retained.readSkillMd
// @ts-expect-error The retained entrypoint supplies data/body contracts only, not old directory readers.
const oldDirectoryReader = retained.readSkillPackage

export { mdHasNoThirdAlternative, packageHasNoThirdAlternative, currentReadResult }
