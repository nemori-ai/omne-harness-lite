import datetime
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/core-delivery')
RUN = ROOT / 'tmp/core-delivery/W7-integrated-gates'
RUN.mkdir(parents=True, exist_ok=True)
commands = {
    'build': ['pnpm', 'run', 'build'],
    'types': ['pnpm', 'run', 'typecheck'],
    'format': ['pnpm', 'run', 'format:check'],
    'rules': ['pnpm', 'run', 'lint:rules'],
    'core-tests': ['pnpm', '-r', '--workspace-concurrency=1', '--filter', './packages/core/**',
        '--filter', './packages/util/**', '--filter', './tools/ts-checks',
        '--filter', './tools/core-verification', 'run', 'test'],
    'packed': ['pnpm', '--filter', '@omne-harness-lite/core-verification', 'run', 'verify:packed'],
}

def source_inputs():
    names = subprocess.check_output(['git', 'ls-files', '-z', 'packages', 'apps', 'tools', 'scripts',
        'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'tsconfig.base.json',
        '.meta_harness/design/spec/data/skill-package/v3', '.meta_harness/design/registry/frozen.json'], cwd=ROOT).decode().split('\0')
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
        for name in names if name and not name.endswith(('.md', '.png', '.svg')) and (ROOT / name).is_file()}

commands.update({'stream-types-after-coordinate-fix': ['pnpm', '--filter', '@omne-harness-lite/stream-assembly', 'run', 'typecheck'], 'stream-and-composition-after-coordinate-fix': ['pnpm', '-r', '--workspace-concurrency=1', '--filter', '@omne-harness-lite/stream-assembly', '--filter', '@omne-harness-lite/core-verification', 'run', 'test'], 'stream-format-after-coordinate-fix': ['./scripts/format.sh', 'check', 'packages/core/stream-assembly/tests/fixtures.spec.ts'], 'python-tests': ['make', 'test'], 'format-harness': ['pnpm', 'run', 'test:format'], 'readmes-a': ['.venv/bin/python', 'tmp/core-delivery/readmes-a-current/verify_examples.py'], 'readmes-util-infra': ['node', 'tmp/core-delivery/readmes-util-infra/verify.mjs']})

for name in sys.argv[1:]:
    argv = commands[name]
    record_path = RUN / (name + '.command.json')
    assert not record_path.exists(), 'Preserve original runs; choose a distinct retry label rather than overwrite.'
    before = source_inputs()
    (RUN / (name + '.inputs-before.json')).write_text(json.dumps(before, indent=2) + '\n')
    record = {'cwd': str(ROOT), 'argv': argv, 'source_head': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'Integrated current working-tree product/config inputs; community Markdown excluded from source guard, preserved separately.',
        'full_repository_test_claim': False}
    with (RUN / (name + '.stdout.log')).open('wb') as stdout, (RUN / (name + '.stderr.log')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
    after = source_inputs()
    (RUN / (name + '.inputs-after.json')).write_text(json.dumps(after, indent=2) + '\n')
    record.update({'exit': result.returncode, 'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'inputs_unchanged': before == after, 'source_input_count': len(before)})
    record_path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'gate': name, 'exit': result.returncode, 'inputs_unchanged': before == after}), flush=True)
    assert before == after, 'Source changed during integrated gate'
    if result.returncode:
        sys.exit(result.returncode)
