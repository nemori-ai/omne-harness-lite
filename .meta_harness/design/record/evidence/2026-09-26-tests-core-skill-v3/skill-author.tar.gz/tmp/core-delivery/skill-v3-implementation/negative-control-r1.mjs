import assert from 'node:assert/strict'
import { cpSync, readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { resolve } from 'node:path'
const evidence = 'tmp/core-delivery/skill-v3-implementation'
const source = 'packages/core/skill-package/dist/md.js'
const positive = readFileSync(source, 'utf8')
const target = 'if (keys.invalid || keys.tags.size !== 0)'
assert.equal(positive.split(target).length, 2, 'exact one rejection predicate')
cpSync('packages/core/skill-package/dist', evidence + '/mutant-dist', { recursive: true })
const mutant = positive.replace(target, 'if (keys.invalid)')
writeFileSync(evidence + '/mutant-dist/md.js', mutant)
const text = '---\nname: x\ndescription: d\n!opaque a: first\n!opaque b: second\n---\nbody'
const probe = path => `import assert from 'node:assert/strict'; import {readSkillMd} from ${JSON.stringify(path)}; assert.deepEqual(readSkillMd(${JSON.stringify(text)}), {rejected:'malformed',malformed:'M16'}, 'D069 unknown canonical key equality must refuse M16');\n`
const reports = []
for (const [name, path] of [['positive',resolve(source)], ['negative',resolve(evidence + '/mutant-dist/md.js')]]) {
  writeFileSync(evidence + '/' + name + '-probe.mjs', probe(path))
  const args = [evidence + '/' + name + '-probe.mjs']
  const result = spawnSync(process.execPath,args,{encoding:'utf8'})
  writeFileSync(evidence + '/' + name + '-probe.stdout.log', result.stdout)
  writeFileSync(evidence + '/' + name + '-probe.stderr.log', result.stderr)
  reports.push({name,executable:process.execPath,args,exit:result.status,signal:result.signal,error:result.error?.message ?? null})
  assert.equal(result.signal,null)
  assert.equal(result.error,undefined)
  assert.equal(result.status,name==='positive'?0:1)
  if(name==='negative') {
    assert.match(result.stderr,/AssertionError \[ERR_ASSERTION\]/)
    assert.match(result.stderr,/D069 unknown canonical key equality must refuse M16/)
    assert.match(result.stderr,/actual:/)
  }
}
const sha = value=>createHash('sha256').update(value).digest('hex')
writeFileSync(evidence + '/negative-control.json',JSON.stringify({target,source,positiveSha256:sha(positive),mutantSha256:sha(mutant),sourceAfterSha256:sha(readFileSync(source)),input:text,reports},null,2)+'\n')
assert.equal(sha(readFileSync(source)),sha(positive))
console.log(JSON.stringify({reports,sourceUnchanged:true,negative:'exact target AssertionError'}))
