import type { ResourceEntry, SkillPackage } from './types.ts';
/** Membership is an address predicate, never execution permission. */
export declare function skillScripts(pkg: SkillPackage): readonly ResourceEntry[];
//# sourceMappingURL=scripts.d.ts.map