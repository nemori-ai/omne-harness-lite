import type { SkillMdReadResult } from './types.ts';
export declare function readSkillMd(text: string): SkillMdReadResult;
//# sourceMappingURL=md.d.ts.map