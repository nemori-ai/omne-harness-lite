import type { BodyContract } from '@omne-harness-lite/asset-model';
import { type SkillSchemaBinding } from './schema.ts';
import type { SkillJudgeContext, SkillJudgment } from './types.ts';
export declare function createSkillBodyContract(binding: SkillSchemaBinding, judge: (body: unknown, context?: SkillJudgeContext) => SkillJudgment): BodyContract<'skill'>;
export declare const skillBodyContract: BodyContract<"skill">;
//# sourceMappingURL=body.d.ts.map