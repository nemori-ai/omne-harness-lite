from pathlib import Path
import json, shutil
root=Path.cwd(); p=root/'packages/core/skill-package'
shutil.copyfile(p/'schema/skill-package.schema.json',p/'schema/skill-package.v2.schema.json')
shutil.copyfile(root/'.meta_harness/design/spec/data/skill-package/v3/skill-package.schema.json',p/'schema/skill-package.schema.json')
manifest=json.loads((p/'package.json').read_text());manifest['description']='data.skill-package v3 pure values and readers; precise v2 value/body port'
manifest['exports']['./v2']={'types':'./dist/v2.d.ts','import':'./dist/v2.js'};manifest['exports']['./schema/v2']='./schema/skill-package.v2.schema.json'
(p/'package.json').write_text(json.dumps(manifest,indent=2)+'\n')
f=p/'src/types.ts';s=f.read_text();start=s.index('/** A technical read gap:');end=s.index('export type SkillMdReadResult',start);s=s[:start]+s[end:];s=s.replace('\n  | SkillReadUndetermined','');f.write_text(s)
f=p/'src/md.ts';s=f.read_text().replace('if (keys.invalid) return rejected()','if (keys.invalid || keys.tags.size !== 0) return rejected()');start=s.index('  if (keys.tags.size !== 0)\n');end=s.index('  return Object.freeze({\n    ok:',start);s=s[:start]+s[end:];f.write_text(s)
for name in ['packages/core/asset-evaluation/src/defaults.ts','packages/core/asset-evaluation/tests/body-domain.spec.ts','packages/core/slash-command/src/skill.ts','packages/core/slash-command/tests/projections.spec.ts','packages/core/slash-command/tests/walkthrough.spec.ts','packages/core/slash-command/tests/public.spec-d.ts']:
 f=root/name;f.write_text(f.read_text().replace("from '@omne-harness-lite/skill-package'","from '@omne-harness-lite/skill-package/v2'"))
f=root/'tools/core-verification/src/w6-asset-consumer.ts';s=f.read_text().replace("import { skillBodyContract, readSkillPackage } from '@omne-harness-lite/skill-package'","import { readSkillPackage, judgeSkillPackage, schemaId } from '@omne-harness-lite/skill-package'\nimport { skillBodyContract, judgeSkillPackage as judgeSkillPackageV2, schemaId as skillV2SchemaId } from '@omne-harness-lite/skill-package/v2'");f.write_text(s)
f=root/'tools/core-verification/src/w6-packed-consumer.ts';s=f.read_text().replace("'skill-package': ['.', './schema']","'skill-package': ['.', './schema', './v2', './schema/v2']");f.write_text(s)
