import type { JsonObject } from '@omne-harness-lite/content-blocks';
import { type SkillSchemaBinding } from './schema.ts';
import type { SkillJudgeContext, SkillJudgment, SkillPackage } from './types.ts';
export declare function pathEscapes(path: string): boolean;
/** Only independently established members participate; absent observations are never invented. */
export declare function knownSkillRejection(value: JsonObject, context?: SkillJudgeContext, observedEscape?: boolean): Extract<SkillJudgment, {
    readonly rejected: string;
}> | undefined;
/** S-24 ordered predicates precede the frozen Schema shape check. No repairs are made. */
export declare function createSkillJudge(binding: SkillSchemaBinding): (input: unknown, context?: SkillJudgeContext) => SkillJudgment;
export declare const judgeSkillPackage: (input: unknown, context?: SkillJudgeContext) => SkillJudgment;
export declare function isSkillPackage(value: unknown): value is SkillPackage;
//# sourceMappingURL=judge.d.ts.map