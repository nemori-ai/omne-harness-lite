export { SCHEMA_DEF_NAMES } from "./schema.js";
export { skillAttributeDeclarations, skillReferences } from "./declarations.js";
export { skillDependencies } from "./dependencies.js";
export { skillScripts } from "./scripts.js";
import { skillV2SchemaBinding } from "./schema.js";
import { createSkillJudge } from "./judge.js";
import { createSkillBodyContract } from "./body.js";
export const schemaId = skillV2SchemaBinding.schemaId;
export const validate = skillV2SchemaBinding.validate;
export const judgeSkillPackage = createSkillJudge(skillV2SchemaBinding);
export function isSkillPackage(value) {
    return 'ok' in judgeSkillPackage(value);
}
export const skillBodyContract = createSkillBodyContract(skillV2SchemaBinding, judgeSkillPackage);
//# sourceMappingURL=v2.js.map