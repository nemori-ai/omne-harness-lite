/** Exact Skill2 pure values/body for the currently adopted AM3/AE3/Slash2 contracts. */
export type { SkillName, SkillManifest, ResourceEntry, SkillSetting, ToolReference, SkillDefinitionRecord, SkillPackage, SkillRejection, MalformedCode, SkillJudgment, SkillJudgeContext, SkillDependency, } from './types.ts';
export { SCHEMA_DEF_NAMES, type SchemaDefName } from './schema.ts';
export { skillAttributeDeclarations, skillReferences } from './declarations.ts';
export { skillDependencies } from './dependencies.ts';
export { skillScripts } from './scripts.ts';
import type { SkillPackage } from './types.ts';
export declare const schemaId: string;
export declare const validate: (definition: import("./schema.ts").SchemaDefName, input: unknown) => {
    readonly valid: boolean;
};
export declare const judgeSkillPackage: (input: unknown, context?: import("./types.ts").SkillJudgeContext) => import("./types.ts").SkillJudgment;
export declare function isSkillPackage(value: unknown): value is SkillPackage;
export declare const skillBodyContract: import("@omne-harness-lite/asset-model").BodyContract<"skill">;
//# sourceMappingURL=v2.d.ts.map