import type { AttributeDeclaration } from '@omne-harness-lite/asset-model';
import type { CapabilityId } from '@omne-harness-lite/content-blocks';
import type { SkillPackage } from './types.ts';
/** S-17: the body contributes only its author declarations; asset-model owns reserved items. */
export declare function skillAttributeDeclarations(pkg: SkillPackage): readonly AttributeDeclaration[];
export declare function skillReferences(pkg: SkillPackage): readonly CapabilityId[];
//# sourceMappingURL=declarations.d.ts.map