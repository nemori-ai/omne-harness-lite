from pathlib import Path
import hashlib,json,tarfile,subprocess
root=Path.cwd();task=root/'tmp/core-delivery/skill-v3-implementation'
source=json.loads((task/'source-inputs.json').read_text())
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert commit=='06b85a14ab3439b35b4f51211adcb0731fea6908'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
for row in source['source_inputs']:
 assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
 assert subprocess.check_output(['git','show',commit+':'+row['path']])==(root/row['path']).read_bytes()
items=[]
for base in [task,root/'tmp/w6-core-verification']:
 for p in sorted(base.rglob('*')):
  if 'node_modules' in p.relative_to(base).parts or p.is_symlink() or not p.is_file():continue
  if p.name in ['evidence.tar.gz','seal-manifest.json']:continue
  items.append(p)
records=[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in items]
archive=task/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in items:t.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(items)
 for row in records:
  f=t.extractfile(row['path']);assert f is not None
  assert hashlib.sha256(f.read()).hexdigest()==row['sha256']
seal={'format':1,'source_commit':commit,'baseline':source['baseline'],'payload_files':len(records),'payload_bytes':sum(r['bytes'] for r in records),'archive':str(archive.relative_to(root)),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'records':records,'excluded':'rebuildable node_modules links/contents only; tracked source recovered from exact commit and checked changed-file manifest; no acceptance asserted','readback':'each archived payload hash checked after writing'}
(task/'seal-manifest.json').write_text(json.dumps(seal,ensure_ascii=False,indent=2)+'\n')
print({k:seal[k] for k in ['source_commit','payload_files','payload_bytes','archive','archive_sha256','readback']})
