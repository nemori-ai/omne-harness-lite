import { judgeSkillPackage } from "./judge.js";
import { skillAttributeDeclarations, skillReferences } from "./declarations.js";
import { SCHEMA_DEF_NAMES, skillSchemaBinding } from "./schema.js";
export function createSkillBodyContract(binding, judge) {
    function valid(body) {
        return 'ok' in judge(body);
    }
    function checked(body) {
        if (!valid(body))
            throw new TypeError('valid SkillPackage required');
        return body;
    }
    return Object.freeze({
        category: 'skill',
        schema: binding.schema,
        judge(body, context) {
            if (context?.definition !== undefined && context.definition !== 'SkillPackage') {
                const definition = SCHEMA_DEF_NAMES.find(name => name === context.definition);
                if (definition === undefined)
                    throw new TypeError('unknown Skill Schema definition');
                return binding.validate(definition, body).valid
                    ? Object.freeze({ ok: true })
                    : Object.freeze({ rejected: 'malformed' });
            }
            return judge(body, context);
        },
        deriveDeclarations(body) {
            return Object.freeze({ declarations: skillAttributeDeclarations(checked(body)) });
        },
        references(body) {
            return skillReferences(checked(body));
        },
    });
}
export const skillBodyContract = createSkillBodyContract(skillSchemaBinding, judgeSkillPackage);
//# sourceMappingURL=body.js.map