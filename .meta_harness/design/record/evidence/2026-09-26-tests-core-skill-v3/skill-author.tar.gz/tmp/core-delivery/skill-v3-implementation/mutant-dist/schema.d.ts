import type { SchemaDocument, SchemaRuntime } from '@omne-harness-lite/content-blocks/schema-runtime';
import type { JsonValue } from '@omne-harness-lite/content-blocks';
export declare const SCHEMA_DEF_NAMES: readonly ["SkillName", "SkillManifest", "ResourceEntry", "SkillDefinitionRecord", "SkillPackage"];
export type SchemaDefName = (typeof SCHEMA_DEF_NAMES)[number];
export interface SkillSchemaBinding {
    readonly schema: SchemaDocument;
    readonly schemaId: string;
    readonly createRuntime: () => SchemaRuntime;
    readonly validate: (definition: SchemaDefName, input: unknown) => {
        readonly valid: boolean;
    };
}
export declare const skillSchemaBinding: SkillSchemaBinding;
export declare const skillV2SchemaBinding: SkillSchemaBinding;
export declare const schemaId: string;
export declare const validate: (definition: SchemaDefName, input: unknown) => {
    readonly valid: boolean;
};
export declare function numericOne(value: JsonValue): boolean;
export declare function schemaDocument(value: JsonValue | undefined): value is SchemaDocument;
//# sourceMappingURL=schema.d.ts.map