from pathlib import Path
p=Path('packages/core/skill-package/src/judge.ts');s=p.read_text()
s=s.replace('import { createSkillSchemaRuntime, numericOne, schemaDocument, validate }', 'import { skillSchemaBinding, numericOne, schemaDocument, type SkillSchemaBinding }')
s=s.replace('function defaultFits(setting: JsonObject): boolean {','function defaultFits(setting: JsonObject, binding: SkillSchemaBinding): boolean {').replace('const runtime = createSkillSchemaRuntime()','const runtime = binding.createRuntime()')
start=s.index('/** S-24 ordered predicates');first=s.index('  const manifest =',start);last=s.index('\n  if (\n    manifest === undefined',first)
pred=s[first:last];pred=pred.replace('  const resources = array(value.resources)','  const resources = array(value.resources)').replace('    resources.some(','    observedEscape || resources.some(')
pred+='\n  return undefined\n}\n'
helper='''/** Only independently established members participate; absent observations are never invented. */
export function knownSkillRejection(
  value: JsonObject,
  context?: SkillJudgeContext,
  observedEscape = false,
): SkillJudgment | undefined {
'''+pred
pre='''/** S-24 ordered predicates precede the frozen Schema shape check. No repairs are made. */
export function createSkillJudge(binding: SkillSchemaBinding) {
return function judgeSkillPackage(input: unknown, context?: SkillJudgeContext): SkillJudgment {
  const value = copyJson(input)
  if (!object(value)) return malformed('M1')
  if (!Object.hasOwn(value, 'manifest')) return Object.freeze({ rejected: 'manifest_missing' })
  const known = knownSkillRejection(value, context)
  if (known !== undefined) return known
  const manifest = object(value.manifest) ? value.manifest : undefined
  const definition = object(value.definition) ? value.definition : undefined
  const resources = array(value.resources)
  const settings = array(definition?.settings)
  const environment = object(definition?.environmentRequirement) ? definition.environmentRequirement : undefined
'''
s=s[:start]+helper+pre+s[last:]
s=s.replace('!defaultFits(setting)','!defaultFits(setting, binding)').replace("!validate('","!binding.validate('")
pos=s.index('\nexport function isSkillPackage');s=s[:pos]+'\n}\nexport const judgeSkillPackage = createSkillJudge(skillSchemaBinding)\n'+s[pos:];p.write_text(s)
