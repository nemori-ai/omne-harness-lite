import schema from '@omne-harness-lite/skill-package/schema' with { type: 'json' };
import previousSchema from '@omne-harness-lite/skill-package/schema/v2' with { type: 'json' };
import contentSchema from '@omne-harness-lite/content-blocks/schema/v2' with { type: 'json' };
import assetSchema from '@omne-harness-lite/asset-model/schema/v2' with { type: 'json' };
import toolSchema from '@omne-harness-lite/tool-definition/schema/v2' with { type: 'json' };
import { createSchemaRuntime } from '@omne-harness-lite/content-blocks/schema-runtime';
import { copyJson, object } from "./json.js";
export const SCHEMA_DEF_NAMES = [
    'SkillName',
    'SkillManifest',
    'ResourceEntry',
    'SkillDefinitionRecord',
    'SkillPackage',
];
function bind(version) {
    const resource = version === 2 ? previousSchema : schema;
    const resources = [contentSchema, assetSchema, toolSchema, previousSchema];
    if (version === 3)
        resources.push(schema);
    const createRuntime = () => createSchemaRuntime(resources);
    const runtime = createRuntime();
    const validators = new Map(SCHEMA_DEF_NAMES.map(name => [
        name,
        runtime.compile({ $ref: `${resource.$id}#/$defs/${name}` }),
    ]));
    const captured = copyJson(resource);
    if (!object(captured))
        throw new Error('Skill Schema is not an object');
    return Object.freeze({
        schema: captured,
        schemaId: resource.$id,
        createRuntime,
        validate(definition, input) {
            const validator = validators.get(definition);
            if (validator === undefined)
                throw new TypeError(`unknown Skill Schema definition ${definition}`);
            const value = copyJson(input);
            return Object.freeze({ valid: value !== undefined && validator.validate(value) });
        },
    });
}
export const skillSchemaBinding = bind(3);
export const skillV2SchemaBinding = bind(2);
export const schemaId = skillSchemaBinding.schemaId;
export const validate = skillSchemaBinding.validate;
const one = skillSchemaBinding.createRuntime().compile({ const: 1 });
export function numericOne(value) {
    return one.validate(value);
}
export function schemaDocument(value) {
    return typeof value === 'boolean' || object(value);
}
//# sourceMappingURL=schema.js.map