import { spawnSync } from 'node:child_process'
import { writeFileSync, mkdirSync, readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
const [id, executable, ...args] = process.argv.slice(2)
const base = 'tmp/core-delivery/skill-v3-implementation/'
mkdirSync(base, { recursive: true })
const result = spawnSync(executable, args, { encoding: 'utf8', maxBuffer: 30_000_000 })
writeFileSync(base + id + '.stdout.log', result.stdout ?? '')
writeFileSync(base + id + '.stderr.log', result.stderr ?? '')
writeFileSync(base + id + '.command.json', JSON.stringify({ executable,args,cwd:process.cwd(),exit:result.status,signal:result.signal,error:result.error?.message ?? null,at:new Date().toISOString(), stdoutSha256:createHash('sha256').update(result.stdout ?? '').digest('hex'), stderrSha256:createHash('sha256').update(result.stderr ?? '').digest('hex') },null,2)+'\n')
console.log(JSON.stringify({ id,exit:result.status,signal:result.signal,stdout:(result.stdout ?? '').slice(-3000),stderr:(result.stderr ?? '').slice(-2000) }))
process.exit(result.status ?? 1)
