import type { JsonObject, JsonValue } from '@omne-harness-lite/content-blocks';
export declare function object(value: unknown): value is JsonObject;
export declare function copyJson(value: unknown): JsonValue | undefined;
//# sourceMappingURL=json.d.ts.map