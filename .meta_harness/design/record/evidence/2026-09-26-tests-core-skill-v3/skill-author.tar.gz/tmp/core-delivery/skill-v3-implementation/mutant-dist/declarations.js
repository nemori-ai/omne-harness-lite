/** Valid inputs contain only JSON containers and immutable lossless numeric atoms. */
function detached(value) {
    if (value === null || typeof value !== 'object')
        return value;
    if (Array.isArray(value))
        return Object.freeze(value.map((item) => detached(item)));
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null)
        return value;
    const copy = {};
    for (const [key, item] of Object.entries(value))
        Object.defineProperty(copy, key, { value: detached(item), enumerable: true });
    // Copying checked, typed JSON data preserves its shape; this assertion is not a validator.
    return Object.freeze(copy);
}
/** S-17: the body contributes only its author declarations; asset-model owns reserved items. */
export function skillAttributeDeclarations(pkg) {
    return detached(pkg.definition?.settings ?? []);
}
export function skillReferences(pkg) {
    return Object.freeze((pkg.definition?.tools ?? []).map(id => Object.freeze({ category: id.category, name: id.name })));
}
//# sourceMappingURL=declarations.js.map