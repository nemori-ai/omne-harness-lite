import type { SkillJudgeContext, SkillPackageEntry, SkillPackageReadResult } from './types.ts';
/** S-21 pure half: filesystem observation and UTF-8 decoding belong to the caller. */
export declare function readSkillPackage(entries: readonly SkillPackageEntry[], context?: SkillJudgeContext): SkillPackageReadResult;
//# sourceMappingURL=entries.d.ts.map