import type { SkillDependency, SkillPackage } from './types.ts';
export declare function skillDependencies(pkg: SkillPackage): readonly SkillDependency[];
//# sourceMappingURL=dependencies.d.ts.map