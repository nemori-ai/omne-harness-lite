import hashlib
import json
import subprocess
import tarfile
import time
from pathlib import Path

hub = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime')
spoke = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-p2-retry-delay-verification')
evidence = spoke / 'tmp/model-request-runtime/p2-retry-delay-verification'
output = hub / 'tmp/model-request-runtime/p2-retry-delay-root-acceptance'
started = time.monotonic()
archive = json.loads((evidence / 'archive.json').read_text())
manifest = json.loads((evidence / 'ARCHIVE-MANIFEST.json').read_text())
summary = json.loads((evidence / 'summary.json').read_text())
assert hashlib.sha256(Path(archive['path']).read_bytes()).hexdigest() == archive['sha256'] == '934e639cd3174959aa41ce4d4e581a1f8a9fc3a08eb4e9efedda91b36dffac07'
for name, key in [('ARCHIVE-MANIFEST.json', 'manifestSha256'), ('REPORT.md', 'REPORTsha256'), ('summary.json', 'summarySha256')]:
    assert hashlib.sha256((evidence / name).read_bytes()).hexdigest() == archive[key], name
expected = {record['path']: record for record in manifest['members']}
assert len(expected) == 49986
with tarfile.open(archive['path'], 'r:gz') as reader:
    members = reader.getmembers()
    index = {member.name: member for member in members}
    assert len(members) == len(index) == 49987
    assert set(index) == set(expected) | {'evidence/ARCHIVE-MANIFEST.json'}
    assert reader.extractfile('evidence/ARCHIVE-MANIFEST.json').read() == (evidence / 'ARCHIVE-MANIFEST.json').read_bytes()
    counts = {'files': 0, 'links': 0, 'dirs': 0}
    for name, record in expected.items():
        member = index[name]
        assert not name.startswith('/') and '..' not in name.split('/'), name
        if record['kind'] == 'file':
            assert member.isfile() and member.size == record['bytes'], name
            digest = hashlib.sha256()
            file = reader.extractfile(member)
            for block in iter(lambda: file.read(1024 * 1024), b''):
                digest.update(block)
            assert digest.hexdigest() == record['sha256'], name
            counts['files'] += 1
        elif record['kind'] == 'symlink':
            assert member.issym() and member.linkname == record['target'], name
            counts['links'] += 1
        elif record['kind'] == 'directory':
            assert member.isdir(), name
            counts['dirs'] += 1
        else:
            raise AssertionError(record)

    def resolve(name):
        parts = name.split('/')
        resolved = []
        seen = set()
        while parts:
            part = parts.pop(0)
            if part in ['', '.']:
                continue
            if part == '..':
                assert resolved, name
                resolved.pop()
                continue
            resolved.append(part)
            current = '/'.join(resolved)
            member = index.get(current)
            if member is not None and member.issym():
                state = (current, tuple(parts))
                assert state not in seen, name
                seen.add(state)
                assert not member.linkname.startswith('/'), name
                resolved.pop()
                parts = member.linkname.split('/') + parts
        result = '/'.join(resolved)
        assert result in index, (name, result)
        return result

    for name, member in index.items():
        if member.issym():
            resolve(name)
    assert counts == {'files': 43678, 'links': 1756, 'dirs': 4552}, counts

inputs = json.loads((evidence / 'input-hashes.json').read_text())
changes = []
private = []
for relative, digest in inputs.items():
    assert hashlib.sha256((spoke / relative).read_bytes()).hexdigest() == digest, relative
    if relative.startswith('tmp/'):
        private.append(relative)
        continue
    current = hub / relative
    assert current.exists(), relative
    actual = hashlib.sha256(current.read_bytes()).hexdigest()
    if actual != digest:
        changes.append({'path': relative, 'frozen': digest, 'current': actual})
assert len(inputs) == 1135
for name, digest in summary['packs'].items():
    assert hashlib.sha256((evidence / 'packs' / name).read_bytes()).hexdigest() == digest, name

commands = summary['commands']
assert len(commands) == 26
assert sum(command['exit'] == 0 for command in commands) == 24
assert sum(command['exit'] == 1 for command in commands) == 2
for command in commands:
    assert command['pid'] > 0 and command['actualWaitCompleted'] and not command.get('timedOut', False), command['label']
run = Path(summary['finalRun'])
for letter in ['B', 'C']:
    result = json.loads((run / (letter + '-numeric.json')).read_text())
    assert len(result['oracles']) == 2181
    assert all(oracle['result'] == 'pass' for oracle in result['oracles'])
    assert not result['forbiddenEffects'] and not result['deniedImports']
    for language in ['README', 'README_ZH']:
        result = json.loads((run / (letter + '-runtime-' + language + '-1.mjs.json')).read_text())
        facts = result['oracles'][0]['actual']
        tls, terminal = facts['tls'], facts['terminal']
        assert tls['requests'] == 1 and tls['outcome'] == 'complete' and tls['serverListening'] is False
        assert tls['sockets'] == tls['actualClientSockets'] == 0
        assert tls['socketsClosed'] == tls['actualClientClosed'] == 1
        assert not terminal['ownedTimers'] and all(timer['stopped'] for timer in terminal['actualTimerRecords'])
for control in summary['finalControls']:
    assert control['syntaxExit'] == 0 and control['oracleExit'] == 1 and control['actualWaitCompleted']
    assert control['firstFailure']['name'] == control['specifiedOracle']
    assert 'AssertionError' in control['firstFailure']['error']
    assert control['changedProductFiles'] == ['vendor/model-request-runtime/dist/retry-delay.js']
assert subprocess.check_output(['git', '-C', str(spoke), 'rev-parse', 'HEAD'], text=True).strip() == summary['head']
assert not subprocess.check_output(['git', '-C', str(spoke), 'status', '--porcelain'])
report = {
    'scope': 'root personally rechecked W16-b683351-r3 final evidence; no product test rerun claim',
    'archive_sha256': archive['sha256'],
    'all_archive_members_read_back': True,
    'counts': counts,
    'members': 49987,
    'all_symlinks_internal': True,
    'source_dist_inputs': len(inputs),
    'all_frozen_source_inputs_match': True,
    'packs_checked': len(summary['packs']),
    'maintained_hub_differences': changes,
    'private_spoke_inputs_not_hub_required': private,
    'final_commands': len(commands),
    'final_positive_exits_zero': 24,
    'specified_negative_exits_one': 2,
    'actual_waits_confirmed': True,
    'two_numeric_oracle_pass_counts': [2181, 2181],
    'four_actual_tls_resource_facts_checked': True,
    'original_measurement_issues_preserved': summary['issues'],
    'seconds': time.monotonic() - started,
    'acceptance_not_yet_written': True,
}
(output / 'root-verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False))
