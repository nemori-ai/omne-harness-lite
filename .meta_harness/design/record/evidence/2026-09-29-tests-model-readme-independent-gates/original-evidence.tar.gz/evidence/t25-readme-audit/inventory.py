from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path.cwd()
BASE = subprocess.check_output(['git', 'merge-base', 'origin/main', 'HEAD'], text=True).strip()
HEAD = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
changed = subprocess.check_output(['git', 'diff', '--name-only', f'{BASE}..HEAD', '--', 'packages', 'examples'], text=True).splitlines()
roots = sorted({Path(*p.split('/')[:3]) for p in changed if p.startswith('packages/') and len(p.split('/')) >= 4} | {Path(*p.split('/')[:2]) for p in changed if p.startswith('examples/') and len(p.split('/')) >= 3})
rows = []
for member in roots:
    docs = {}
    for name in ('README.md', 'README_ZH.md'):
        file = ROOT / member / name
        if not file.is_file():
            docs[name] = {'exists': False}
            continue
        raw = file.read_bytes()
        value = raw.decode('utf-8')
        docs[name] = {
            'exists': True,
            'sha256': hashlib.sha256(raw).hexdigest(),
            'lines': len(value.splitlines()),
            'codeFences': len(re.findall(r'^```(?:ts|typescript|js|javascript|sh|bash)\s*$', value, re.M)),
            'siblingLink': ('README_ZH.md' if name == 'README.md' else 'README.md') in value,
        }
    package_file = ROOT / member / 'package.json'
    package = json.loads(package_file.read_text()) if package_file.is_file() else {}
    rows.append({'member': str(member), 'name': package.get('name'), 'exports': sorted((package.get('exports') or {}).keys()), 'docs': docs})
result = {'baseline': BASE, 'head': HEAD, 'changedMembers': len(rows), 'rows': rows}
out = ROOT / 'tmp/model-request-runtime/t25-readme-audit/inventory.json'
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'head': HEAD, 'changedMembers': len(rows), 'missingPairs': [r['member'] for r in rows if not all(d['exists'] for d in r['docs'].values())], 'missingSiblingLinks': [r['member'] for r in rows if not all(d.get('siblingLink') for d in r['docs'].values())], 'noCodeFences': [r['member'] for r in rows if not all(d.get('codeFences', 0) > 0 for d in r['docs'].values())]}, ensure_ascii=False, indent=2))
