#!/usr/bin/env python3
"""Read-only P oracle for actual helper, public facts, plaintext residue and OS fault."""

import hashlib
import json
import pathlib
import re
import sys
from datetime import datetime

I3_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
BUILD_ID = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
CLI_BUILD_ID = "f38e46f1f169aea8993640c8ccf0ffc42545f2d64adf21f96b6658b2c83bb9f1"
CLI_SHA = "b8431b6cdb176af43fe9af2002bbc480f927fdbcf64c69c8553f6ceab08e471c"
HELPER_SHA = "71ba9f3c31b34c171dd2a4048d9e249af31f7948abcf66ee603da5ffb7d1b365"
DOCKER_SPEC_SHA = "3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223"
SNAPSHOT = re.compile(r"/var/lib/omne-tenancy/state/backups/\.quarantine/task-[0-9a-f]{32}/snapshot\.sqlite\Z")
CID = re.compile(r"[0-9a-f]{64}\Z")
SHA = re.compile(r"[0-9a-f]{64}\Z")
SQLITE_HEADER = b"SQLite format 3\0"
MARKER_CONTENT = b"omne-isolated/1\n"


def need(value, message):
    if not value:
        raise ValueError(message)


def json_one(data, label):
    need(data.endswith(b"\n") and data.count(b"\n") == 1,
         label + ": one complete JSON+LF required")
    result = json.loads(data)
    need(isinstance(result, dict), label + ": object required")
    return result


def evaluate(run):
    e = json.loads((run / "evidence.json").read_text())
    rows = e["commands"]
    by = {item["label"]: item for item in rows}
    need(len(by) == len(rows) and e["scenario"] == "P" and e["business_complete"] is True,
         "P business observation incomplete or duplicate command")
    need(e["artifact_manifest_sha256"] == I3_SHA
         and e["inputs"]["build_id"] == BUILD_ID
         and e["inputs"]["cli_build_id"] == CLI_BUILD_ID
         and e["inputs"]["sha256"]["i3_manifest"] == I3_SHA
         and e["inputs"]["sha256"]["cli_tar"] == CLI_SHA
         and e["inputs"]["sha256"]["helper"] == HELPER_SHA
         and e["inputs"]["sha256"]["docker_spec"] == DOCKER_SPEC_SHA
         and e["inputs"]["qa_gate_mode"] == "write-hold",
         "reviewed artifact/pilot identity differs")
    gate_path = run / "inputs/reviewed-gate.json"
    need(gate_path.is_file() and not gate_path.is_symlink(), "frozen root gate absent")
    gate = json.loads(gate_path.read_text())
    payload = json.dumps(e["inputs"], sort_keys=True, separators=(",", ":")).encode()
    need(gate.get("approved") is True and gate.get("reviewer") == "root"
         and gate.get("inputs_sha256") == hashlib.sha256(payload).hexdigest()
         and gate.get("driver_sha256") == e["inputs"]["sha256"]["driver"]
         and gate.get("oracle_sha256") == e["inputs"]["sha256"]["oracle"],
         "frozen root gate does not bind actual pilot inputs")
    for name, key in (("driver.py", "driver"), ("oracle.py", "oracle"),
                      ("base_driver.py", "base_driver"), ("io_driver.py", "io_driver"),
                      ("gate.mjs", "gate"), ("gate_availability.mjs", "gate_availability"),
                      ("inventory.mjs", "inventory"),
                      ("pid_signal.sh", "pid_signal"), ("cli.tar.gz", "cli_tar"),
                      ("i3-manifest.json", "i3_manifest")):
        path = run / "inputs" / name
        need(path.is_file() and not path.is_symlink() and
             hashlib.sha256(path.read_bytes()).hexdigest() ==
             e["inputs"]["sha256"][key], "frozen input differs: " + name)
    need(e["cleanup_complete"] is True and e["cleanup_errors"] == [],
         "fixture cleanup incomplete")

    def row(label, code=0):
        need(label in by, label + ": observation absent")
        item = by[label]
        need(item["returncode"] == code and item.get("observation_expired") is False,
             label + ": actual CLI exit/observation differs")
        return item

    def raw(label, stream="stdout"):
        item = by[label]
        path = run / item[stream]
        need(path.parent == run / "raw" and path.is_file(), label + ": raw stream absent")
        return path.read_bytes()

    def obj(label, code=0):
        row(label, code)
        return json_one(raw(label), label)

    def inspected(label, cid):
        row(label)
        data = json.loads(raw(label))
        need(isinstance(data, list) and len(data) == 1 and data[0].get("Id") == cid,
             label + ": actual exact center ID differs")
        return data[0]

    order = [item["label"] for item in rows]
    stages = ("p-validate", "p-start", "p-gate-ready", "p-center-initial",
              "p-cli-register", "p-cli-login", "p-cli-create-team",
              "p-cli-current-before", "p-cli-list-before", "p-prior-backup",
              "p-prior-backup-status", "p-arm-gate", "p-pending-backup", "p-gate-held",
              "p-held-fd-link", "p-before-find-snapshot", "p-before-snapshot-stat",
              "p-center-stable-first", "p-center-stable-last", "p-center-before-signal",
              "p-proc-cmdline", "p-proc-status", "p-proc-pid-namespace",
              "p-proc-stat", "p-proc-cgroup", "p-proc-build", "p-one-os-sigkill",
              "p-center-recovered", "p-status-recovered", "p-full-health-recovered",
              "p-backup-status-recovered", "p-cli-current-after", "p-cli-list-after",
              "p-after-snapshot-stat", "p-original-serve", "p-original-serve-inspect",
              "p-original-serve-logs", "p-probe-after-snapshot-stat", "p-center-logs",
              "p-center-events")
    need(all(label in by for label in stages)
         and [order.index(label) for label in stages] ==
             sorted(order.index(label) for label in stages), "P stage order changed")
    for label in stages:
        if label not in ("p-pending-backup", "p-original-serve"):
            row(label)
    need(obj("p-validate")["state"] == "deployment-structure-valid",
         "formal helper validate did not pass")
    start = obj("p-start")
    cid = start.get("containerId")
    need(isinstance(cid, str) and CID.fullmatch(cid)
         and cid == e["center_id"] and start.get("state") == "running"
         and start.get("health") == "healthy", "actual helper start was not healthy")
    initial = inspected("p-center-initial", cid)
    before = inspected("p-center-before-signal", cid)
    stable_first = inspected("p-center-stable-first", cid)
    stable_last = inspected("p-center-stable-last", cid)
    for value in (initial, stable_first, stable_last, before):
        need(value["State"]["Status"] == "running"
             and value["State"]["Health"]["Status"] == "healthy"
             and value["State"]["Running"] is True
             and value["HostConfig"]["RestartPolicy"]["Name"] == "unless-stopped"
             and value["RestartCount"] == initial["RestartCount"] == 0
             and value["State"]["StartedAt"] == initial["State"]["StartedAt"],
             "not one stable healthy auto-restart center before fault")
    need(stable_first["State"]["Pid"] == stable_last["State"]["Pid"] ==
         before["State"]["Pid"] and
         e["stable_finished_monotonic_ns"] - e["stable_started_monotonic_ns"] >=
         e["inputs"]["stable_seconds"] * 1_000_000_000 and
         (datetime.fromisoformat(by["p-center-stable-last"]["started_utc"]) -
          datetime.fromisoformat(by["p-center-stable-first"]["started_utc"])).total_seconds()
         >= e["inputs"]["stable_seconds"],
         "PID or stable pre-fault interval changed")

    original_inventory = obj("original-inventory")
    qa_inventory = obj("qa-inventory")
    need(original_inventory == qa_inventory and original_inventory["status"] == "verified"
         and original_inventory["buildId"] == BUILD_ID,
         "QA image altered packaged app files")
    original_image = inspected("inner-image-inspect", e["expected"]["inner_image_id"])
    qa_image = inspected("qa-image-inspect", e["qa_image_id"])
    original_config = original_image["Config"]
    qa_config = qa_image["Config"]
    need(qa_image["Config"]["Labels"]["ai.nemori.omne.qa-fixture"] ==
         "maintenance-gate/r5" and
         qa_config["Env"].count("NODE_OPTIONS=--import=/probe/gate.mjs") == 1
         and sorted(qa_config["Env"]) ==
             sorted([*original_config["Env"], "NODE_OPTIONS=--import=/probe/gate.mjs"])
         and all(qa_config[key] == original_config[key] for key in
                 ("Entrypoint", "Cmd", "WorkingDir"))
         and len(qa_image["RootFS"]["Layers"]) > len(original_image["RootFS"]["Layers"])
         and qa_image["RootFS"]["Layers"][:len(original_image["RootFS"]["Layers"])] ==
             original_image["RootFS"]["Layers"],
         "QA preload/image identity differs")
    need(obj("gate-availability")["status"] == "pass", "QA gate unavailable")
    need(obj("p-gate-ready")["mode"] == "write-hold", "first generation gate not armed")
    for suffix in ("before", "after"):
        row("p-generation-stat-" + suffix)
        row("p-generation-content-" + suffix)
        need(raw("p-generation-stat-" + suffix) == b"regular file:10001:10001:600:21\n"
             and raw("p-generation-content-" + suffix) == b"omne-qa-generation/1\n",
             "one protected QA generation claim not retained")

    def cli(label):
        report = obj(label)
        need(report.get("format") == "governance-client/1"
             and report.get("remote", {}).get("status") == "success"
             and report.get("defect") is None, label + ": public report not successful")
        return report

    def result(label):
        report = cli(label)
        value = report.get("remote", {}).get("reply", {}).get("reply", {}).get("result")
        need(value is not None, label + ": public fact absent")
        return value

    for label in ("p-cli-configure", "p-cli-register", "p-cli-login", "p-cli-switch"):
        cli(label)
    for label in ("p-cli-register", "p-cli-login"):
        argv = by[label]["argv"]
        need("--credential-file" in argv and "--login-identifier" in argv
             and not any("credential.secret" == arg for arg in argv),
             "public CLI credential not file-bound")
    personal = result("p-cli-personal-before")
    organization = result("p-cli-create-team")
    team = {"account": personal["account"], "organization": organization}
    current0 = result("p-cli-current-before")
    list0 = result("p-cli-list-before")
    current1 = result("p-cli-current-after")
    list1 = result("p-cli-list-after")
    need(current0 == current1 == team and list0 == list1
         and personal in list0 and team in list0,
         "public confirmed account/team/current facts changed after crash")
    health0 = cli("p-cli-health-before")["remote"]["health"]
    health1 = cli("p-cli-health-after")["remote"]["health"]
    full0 = obj("p-full-health-before")
    full1 = obj("p-full-health-recovered")
    for health in (full0, full1):
        need(all(health.get(key) is True for key in
                 ("reachable", "storageReachable", "clockSane", "deploymentKeyPresent",
                  "deploymentKeyComplete")) and health.get("defectCount") == 0,
             "full health not actually healthy")
    need(full0["centerId"] == full1["centerId"] == health0["centerId"] ==
         health1["centerId"] == cli("p-cli-current-before")["origin"]["centerId"] ==
         cli("p-cli-current-after")["origin"]["centerId"],
         "public governance center identity changed")

    prior = obj("p-prior-backup")
    need(prior.get("status") == "completed" and isinstance(prior.get("backup"), dict),
         "prior backup not actually completed")
    descriptor = prior["backup"]
    need(descriptor.get("metadata", {}).get("centerId") == full0["centerId"],
         "prior backup did not belong to confirmed center")
    for label in ("p-prior-backup-status", "p-backup-status-recovered"):
        status = obj(label)
        need(status.get("status") == "observed" and status.get("health") == "current"
             and status.get("latest") == descriptor and status.get("invalidCount") == 0,
             label + ": previously completed backup no longer confirmed")
    need(sum(1 for item in rows if item["argv"][:7] ==
             ["docker", "exec", "-e", "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock",
              e["expected"]["control"], "/usr/local/libexec/omne-center", "backup"]) == 2,
         "unknown backup was replayed or prior completed backup absent")
    pending = by["p-pending-backup"]
    need(pending["started_monotonic_ns"] < e["signal_sent_monotonic_ns"]
         and (pending["returncode"] is None or pending["returncode"] != 0)
         and not (raw("p-pending-backup").startswith(b'{"status":"completed"')),
         "lost in-flight backup misreported completed")
    need(obj("p-gate-held")["stage"] == "write", "real export FD was not held")
    held = obj("p-gate-held")
    need(held["pid"] == 1 and re.fullmatch(r"/state/backups/\.quarantine/export-[0-9a-f]{32}",
                                            held["path"]), "held export path/PID invalid")
    need(raw("p-held-fd-link").strip().decode() == held["path"],
         "held FD did not name the actual export")
    fd_stat = raw("p-held-fd-stat").decode().strip().split(":")
    need(len(fd_stat) == 5 and fd_stat[2:] == ["10001", "10001", "600"]
         and int(fd_stat[0]) == held["dev"] and int(fd_stat[1]) == held["ino"],
         "held FD not protected owned regular export")

    snapshot = e["snapshot_path"]
    need(isinstance(snapshot, str) and SNAPSHOT.fullmatch(snapshot)
         and raw("p-before-find-snapshot").decode().splitlines() == [snapshot],
         "not one real task snapshot.sqlite in fresh quarantine")
    for phase in ("p-before", "p-after", "p-probe-after"):
        for suffix in ("task-stat", "snapshot-stat", "snapshot-sha", "snapshot-header",
                       "marker-stat", "marker-content"):
            row(phase + "-" + suffix)
        need(raw(phase + "-snapshot-header") == SQLITE_HEADER,
             "actual plaintext SQLite snapshot header absent")
        need(raw(phase + "-marker-content") == MARKER_CONTENT,
             "permanent isolation marker content absent")
        need(raw(phase + "-snapshot-stat").startswith(b"regular file:")
             and raw(phase + "-snapshot-stat").decode().strip().split(":")[3:6] ==
                 ["10001", "10001", "600"]
             and int(raw(phase + "-snapshot-stat").decode().strip().split(":")[6]) > 16,
             "snapshot is not nonempty app-owned 0600 plaintext")
        need(raw(phase + "-task-stat").startswith(b"directory:")
             and raw(phase + "-task-stat").decode().strip().split(":")[3:] ==
                 ["10001", "10001", "700"],
             "snapshot task directory not app-owned private")
        sha_line = raw(phase + "-snapshot-sha").decode().strip().split("  ")
        need(len(sha_line) == 2 and SHA.fullmatch(sha_line[0]) and sha_line[1] == snapshot,
             "snapshot sha256 did not bind exact retained path")
        marker_parts = raw(phase + "-marker-stat").decode().strip().split(":")
        need(marker_parts[0] == "regular file" and marker_parts[3:] ==
             ["10001", "10001", "600", "16"], "marker owner/mode/length invalid")
    for suffix in ("task-stat", "snapshot-stat", "snapshot-sha", "snapshot-header",
                   "marker-stat", "marker-content"):
        need(raw("p-before-" + suffix) == raw("p-after-" + suffix) ==
             raw("p-probe-after-" + suffix),
             "protected snapshot/marker changed across actual process crash: " + suffix)
    serve = row("p-original-serve", 1)
    need(serve["observation_expired"] is False,
         "original host serve result not actually complete")
    probe = e["original_serve_probe"]
    storage_file = "/state" + snapshot[len("/var/lib/omne-tenancy/state"):]
    need(probe["storage_file"] == storage_file and
         re.fullmatch(r"omne-r5[a-z0-9]+-isolated-probe", probe["name"]),
         "original serve did not receive exact retained snapshot path")
    inspected_probe = inspected("p-original-serve-inspect", json.loads(
        raw("p-original-serve-inspect"))[0]["Id"])
    mount_list = inspected_probe["Mounts"]
    need(isinstance(mount_list, list) and len(mount_list) == 2
         and len({m["Destination"] for m in mount_list}) == 2,
         "original serve probe mount shape")
    mounts = {m["Destination"]: m for m in mount_list}
    env_lines = inspected_probe["Config"]["Env"]
    need(len(env_lines) == len({line.split("=", 1)[0] for line in env_lines})
         and all("=" in line for line in env_lines), "probe env duplicate/malformed")
    env = dict(line.split("=", 1) for line in env_lines)
    expected_pem = {
        "OMNE_TENANCY_ACTIVATION_SIGNING_KEY_PEM_FILE": "/secrets/activation-signing-key.pem",
        "OMNE_TENANCY_ACTIVATION_VERIFICATION_KEY_PEM_FILE": "/secrets/activation-verification-key.pem",
        "OMNE_TENANCY_PURGE_SIGNING_KEY_PEM_FILE": "/secrets/purge-signing-key.pem",
        "OMNE_TENANCY_PURGE_VERIFICATION_KEY_PEM_FILE": "/secrets/purge-verification-key.pem",
        "OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE": "/secrets/tls-chain.pem",
        "OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE": "/secrets/tls-private.pem",
    }
    need(inspected_probe["Name"] == "/" + probe["name"]
         and inspected_probe["Image"] == e["expected"]["inner_image_id"]
         and inspected_probe["State"]["Status"] == "exited"
         and inspected_probe["State"]["ExitCode"] == 1
         and inspected_probe["HostConfig"]["NetworkMode"] == "none"
         and inspected_probe["HostConfig"]["RestartPolicy"]["Name"] == "no"
         and not inspected_probe["HostConfig"].get("PortBindings")
         and set(mounts) == {"/state", "/secrets"}
         and mounts["/state"]["Type"] == mounts["/secrets"]["Type"] == "bind"
         and mounts["/state"]["Source"] == e["expected"]["state"]
         and mounts["/state"]["RW"] is True
         and mounts["/secrets"]["Source"] ==
             str(pathlib.PurePosixPath(e["expected"]["state"]).parent / "secrets")
         and mounts["/secrets"]["RW"] is False
         and inspected_probe["Config"]["User"] == "10001:10001"
         and inspected_probe["Config"]["Entrypoint"] ==
             ["node", "/opt/omne/app/dist/cli.js"]
         and inspected_probe["Config"]["Cmd"] == ["serve"]
         and inspected_probe["Path"] == "node"
         and inspected_probe["Args"] == ["/opt/omne/app/dist/cli.js", "serve"]
         and env.get("OMNE_TENANCY_STORAGE_DIALECT") == "sqlite"
         and env.get("OMNE_TENANCY_STORAGE_FILE") == storage_file
         and env.get("OMNE_TENANCY_BACKUP_DIR") == "/state/backups"
         and env.get("OMNE_TENANCY_OPS_SOCKET_DIR") == "/run/omne-tenancy"
         and env.get("OMNE_TENANCY_ENTRY_LISTEN") == "0.0.0.0:8443"
         and all(env.get(key) == value for key, value in expected_pem.items())
         and "NODE_OPTIONS" not in env
         and set(inspected_probe["HostConfig"].get("Tmpfs") or {}) ==
             {"/run/omne-tenancy"},
         "not original final host serve with exact retained snapshot/full state")
    logs = raw("p-original-serve-logs") + raw("p-original-serve-logs", "stderr")
    events = []
    for line in logs.splitlines():
        try:
            event = json.loads(line)
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        if isinstance(event, dict):
            events.append(event)
    need(any(event.get("event") == "startup-failed"
             and event.get("stage") == "storage-open"
             and "isolated maintenance data cannot be opened as production storage"
                 in event.get("message", "") for event in events)
         and not any(event.get("event") == "serving" for event in events),
         "original host publicly opened isolated plaintext or failed for other reason")

    preflight = e["signal_preflight"]
    pid = before["State"]["Pid"]
    need(type(pid) is int and pid > 1 and preflight["pid"] == pid,
         "unsafe or guessed process PID")
    cmd = raw("p-proc-cmdline")
    need(cmd.split(b"\0")[-4:] == [b"node", b"/opt/omne/app/dist/cli.js", b"serve", b""]
         or cmd.split(b"\0")[-4:] == [b"/usr/local/bin/node", b"/opt/omne/app/dist/cli.js",
                                      b"serve", b""],
         "ancestor process cmdline not exact serve")
    need(hashlib.sha256(cmd).hexdigest() == preflight["cmd_sha256"]
         and hashlib.sha256(raw("p-proc-cgroup")).hexdigest() ==
             preflight["cgroup_sha256"], "process identity hash changed")
    status_text = raw("p-proc-status")
    nspid_line = next((line for line in status_text.splitlines() if line.startswith(b"NSpid:")), None)
    need(nspid_line is not None and [int(x) for x in nspid_line.split()[1:]][0] == pid
         and [int(x) for x in nspid_line.split()[1:]][-1] == 1,
         "PID did not map from private DinD ancestor to center PID1")
    need(raw("p-proc-pid-namespace").strip().decode() == preflight["pid_namespace"]
         and raw("p-proc-pid-namespace") != raw("p-dind-pid-namespace")
         and raw("p-proc-build").strip().decode() == BUILD_ID,
         "PID namespace/root/build identity differs")
    stat = raw("p-proc-stat").rsplit(b") ", 1)[1].split()
    need(stat[19].decode() == preflight["start_ticks"], "PID start ticks changed")
    signal = row("p-one-os-sigkill")
    need(signal["argv"][:5] == ["docker", "exec", e["expected"]["dind"], "sh",
                                 "/opt/omne-pid-signal.sh"]
         and raw("p-one-os-sigkill") ==
             f"pid={pid} cid={cid} signal=SIGKILL\n".encode(),
         "not one guarded OS SIGKILL of exact private PID")
    need(sum(1 for item in rows if item["label"] == "p-one-os-sigkill") == 1
         and not any(item["argv"][:2] in (["docker", "kill"], ["docker", "start"],
                                             ["docker", "restart"]) for item in rows),
         "Engine manual lifecycle command contaminated unplanned fault")
    recovered = inspected("p-center-recovered", cid)
    need(recovered["State"]["Status"] == "running"
         and recovered["State"]["Health"]["Status"] == "healthy"
         and recovered["State"]["StartedAt"] != before["State"]["StartedAt"]
         and recovered["RestartCount"] >= before["RestartCount"] + 1
         and type(recovered["State"]["Pid"]) is int and recovered["State"]["Pid"] > 1
         and recovered["State"]["Pid"] != pid,
         "Engine did not automatically restart exact center with new PID")
    status_after = obj("p-status-recovered")
    need(status_after["state"] == "running" and status_after["health"] == "healthy"
         and status_after["containerId"] == cid
         and status_after["restartCount"] == recovered["RestartCount"],
         "formal status did not observe recovered exact center")
    observed = [label for label in order if label.startswith("p-recovered-observe-")]
    need(len(observed) >= 2 and observed[-1] == e["recovered_observation_last_label"]
         and e["recovered_observation_finished_monotonic_ns"] -
             e["recovered_observation_started_monotonic_ns"] >=
             e["inputs"]["restart_observe_seconds"] * 1_000_000_000,
         "finite post-restart observation incomplete")
    for label in observed:
        item = inspected(label, cid)
        need(item["State"]["Status"] == "running"
             and item["State"]["Health"]["Status"] == "healthy"
             and item["State"]["StartedAt"] == recovered["State"]["StartedAt"]
             and item["RestartCount"] == recovered["RestartCount"],
             "center changed during post-restart observation")
    started_first = datetime.fromisoformat(by[observed[0]]["started_utc"])
    started_last = datetime.fromisoformat(by[observed[-1]]["started_utc"])
    need((started_last - started_first).total_seconds() >=
         e["inputs"]["restart_observe_seconds"],
         "final inspect started before observation deadline")
    events = [json.loads(line) for line in raw("p-center-events").splitlines()]
    same_center = [item for item in events if item.get("Actor", {}).get("ID") == cid]
    actions = [item["Action"] for item in same_center]
    lifecycle = [item for item in same_center if item["Action"] in ("die", "start")]
    restart_delta = recovered["RestartCount"] - before["RestartCount"]
    need(len(lifecycle) == 2 * restart_delta
         and all(lifecycle[2 * index]["Action"] == "die"
                 and lifecycle[2 * index + 1]["Action"] == "start"
                 for index in range(restart_delta))
         and not any(action in ("kill", "stop", "destroy", "create") for action in actions),
         "Engine die/start pairs do not match same-CID restart count")
    need(lifecycle[0].get("Actor", {}).get("Attributes", {}).get("exitCode") == "137",
         "actual process death did not report SIGKILL exit")
    logs = [json.loads(line) for line in raw("p-center-logs", "stderr").splitlines()
            if line.startswith(b"{")]
    generation = [line.get("branch") for line in logs if line.get("event") == "qa-generation"]
    need(generation == ["armed"] + ["pass-through"] * restart_delta,
         "one-generation QA gate branches do not match actual restarts")
    print(json.dumps({"status": "limited_pass", "scenario": "P",
                      "containerId": cid, "oldPid": pid, "newPid": recovered["State"]["Pid"],
                      "snapshotSha256": raw("p-before-snapshot-sha").decode().split()[0],
                      "checks": 31}, sort_keys=True, indent=2))


if __name__ == "__main__":
    try:
        evaluate(pathlib.Path(sys.argv[1]).resolve())
    except BaseException as error:
        print(json.dumps({"status": "unverified",
                          "error": f"{type(error).__name__}: {error}"}, indent=2))
        raise SystemExit(1)
