#!/bin/sh
# Invoked once only inside the exact labelled private DinD PID namespace.
set -eu
pid=$1
cid=$2
cmd_sha=$3
start_ticks=$4
pid_namespace=$5
started_at=$6
restart_count=$7
build_id=$8
uid=$9
gid=${10}
cgroup_sha=${11}

case "$pid" in ''|*[!0-9]*) exit 31 ;; esac
[ "$pid" -gt 1 ] || exit 32
case "$cid" in *[!0-9a-f]*|'') exit 33 ;; esac
[ "${#cid}" -eq 64 ] || exit 34
[ -r "/proc/$pid/cmdline" ] && [ -r "/proc/$pid/stat" ] || exit 35

observed=$(docker --host unix:///opt/omne-private-docker/docker.sock inspect \
  --format '{{.Id}} {{.State.Pid}} {{.State.Running}} {{.State.StartedAt}} {{.RestartCount}}' "$cid")
[ "$observed" = "$cid $pid true $started_at $restart_count" ] || exit 36
[ "$(sha256sum "/proc/$pid/cmdline" | awk '{print $1}')" = "$cmd_sha" ] || exit 37
[ "$(sha256sum "/proc/$pid/cgroup" | awk '{print $1}')" = "$cgroup_sha" ] || exit 38
[ "$(awk '{print $22}' "/proc/$pid/stat")" = "$start_ticks" ] || exit 39
[ "$(readlink "/proc/$pid/ns/pid")" = "$pid_namespace" ] || exit 40
[ "$pid_namespace" != "$(readlink /proc/1/ns/pid)" ] || exit 41
awk -v pid="$pid" '/^NSpid:/ { found=1; if (NF < 3 || $2 != pid || $NF != 1) exit 1 }
  END { if (!found) exit 1 }' "/proc/$pid/status" || exit 42
[ "$(awk '/^Uid:/ {print $2}' "/proc/$pid/status")" = "$uid" ] || exit 43
[ "$(awk '/^Gid:/ {print $2}' "/proc/$pid/status")" = "$gid" ] || exit 44
[ "$(cat "/proc/$pid/root/opt/omne/app/BUILD_ID")" = "$build_id" ] || exit 45

# There is no Engine kill/start/stop call here. All identity tests above run in
# this one shell immediately before the only OS signal to the exact live PID.
kill -KILL "$pid"
printf 'pid=%s cid=%s signal=SIGKILL\n' "$pid" "$cid"
