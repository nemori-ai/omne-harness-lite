#!/usr/bin/env python3
"""Root-gated P pilot: one OS SIGKILL of a verified private center process."""

import argparse
import hashlib
import json
import pathlib
import re
import secrets
import shutil
import subprocess
import sys
import time

import base_driver as base
import io_driver

HERE = pathlib.Path(__file__).resolve().parent
CLI_SHA = "b8431b6cdb176af43fe9af2002bbc480f927fdbcf64c69c8553f6ceab08e471c"
CLI_BUILD_ID = "f38e46f1f169aea8993640c8ccf0ffc42545f2d64adf21f96b6658b2c83bb9f1"
SNAPSHOT = re.compile(r"/var/lib/omne-tenancy/state/backups/\.quarantine/task-[0-9a-f]{32}/snapshot\.sqlite\Z")
MARKER = base.STATE + "/backups/.quarantine/.omne-isolated"
BUILD_FILE = "/opt/omne/app/BUILD_ID"


def need(value, message):
    if not value:
        raise RuntimeError(message)


def one_json(data, label):
    return base.parse_json_line(data, label)


def checked_inputs(args):
    # Reuse the accepted IO private Linux fixture's fixed I3 checks. Its two
    # unused observation knobs are fixed here; P uses its own bounded budgets.
    io_args = argparse.Namespace(**vars(args))
    io_args.scenario = "write-hold"
    inputs = io_driver.checked_inputs(io_args)
    paths = {"io_driver": HERE / "io_driver.py",
             "pid_signal": HERE / "pid_signal.sh", "cli_tar": args.cli_tar,
             "storage_guard": args.helper_dir.parents[1] / "node_modules" /
             "@omne-harness-lite/storage-sql/dist/sqlite/protection.js"}
    for name, path in paths.items():
        inputs["paths"][name] = str(path.resolve())
        inputs["sha256"][name] = base.sha(path)
    manifest = json.loads(args.i3_manifest.read_text())
    need(inputs["sha256"]["cli_tar"] == CLI_SHA
         and manifest["archives"]["cli"]["buildId"] == CLI_BUILD_ID
         and args.cli_build_id == CLI_BUILD_ID, "final public CLI identity changed")
    need(args.scenario == "P" and args.uid == args.gid == 10001,
         "only private P pilot with reviewed application owner")
    need(args.stable_seconds >= 10 and args.restart_observe_seconds >= 10
         and args.observe_seconds >= 90, "reviewed observation budgets reduced")
    inputs.update({"scenario": "P", "qa_gate_mode": "write-hold",
                   "stable_seconds": args.stable_seconds,
                   "restart_observe_seconds": args.restart_observe_seconds,
                   "cli_build_id": args.cli_build_id})
    return inputs


class PilotRun(io_driver.IoRun):
    def __init__(self, args, inputs):
        super().__init__(args, inputs)
        for name in ("io_driver.py", "pid_signal.sh"):
            target = self.frozen / name
            shutil.copyfile(HERE / name, target)
            key = name.removesuffix(".py").removesuffix(".mjs").removesuffix(".sh")
            need(base.sha(target) == inputs["sha256"][key], "pilot support changed during freeze")
        self.cli_archive = self.frozen / "cli.tar.gz"
        shutil.copyfile(args.cli_tar, self.cli_archive)
        need(base.sha(self.cli_archive) == inputs["sha256"]["cli_tar"],
             "final CLI archive changed during freeze")
        self.evidence["scenario"] = "P"
        self.save()

    def prepare_paths(self):
        super().prepare_paths()
        policy = b'OMNE_TENANCY_CREDENTIAL_POLICY={"minLength":12}\n'
        self.outer("p-add-qa-credential-policy", "exec", "-i", self.control,
                   "sh", "-c", "cat >> " + base.SETTINGS, stdin=policy)
        self.control_exec("p-qa-policy-stat", "stat", "-c", "%F:%u:%g:%a", base.SETTINGS)
        self.control_exec("p-qa-policy-tail", "tail", "-n", "1", base.SETTINGS)

    def prepare_qa(self):
        # The reviewed QA hook is write-hold; P is the scenario, not a hook mode.
        scenario = self.args.scenario
        self.args.scenario = "write-hold"
        try:
            super().prepare_qa()
        finally:
            self.args.scenario = scenario

    def prepare_public_cli(self):
        dind = json.loads(self.outer("p-dind-network-inspect", "inspect", self.dind))[0]
        need(dind["Config"]["Labels"].get("omne.r5.helper-prep") == self.run_id,
             "not this private DinD")
        address = dind["NetworkSettings"]["Networks"][self.network]["IPAddress"]
        need(re.fullmatch(r"[0-9.]+", address), "private DinD IPv4 missing")
        self.publish_address = address
        self.evidence["private_dind_ip"] = address
        self.save()
        self.control_exec("p-generate-private-san-tls", "openssl", "req", "-x509",
                          "-newkey", "rsa:2048", "-sha256", "-nodes", "-days", "1",
                          "-subj", "/CN=localhost",
                          "-addext", f"subjectAltName=DNS:localhost,IP:127.0.0.1,IP:{address}",
                          "-keyout", base.SECRETS + "/tls-private.pem",
                          "-out", base.SECRETS + "/tls-chain.pem")
        self.control_exec("p-own-private-san-tls", "chown", "10001:10001",
                          base.SECRETS + "/tls-private.pem", base.SECRETS + "/tls-chain.pem")
        self.control_exec("p-mode-private-san-tls", "chmod", "0600",
                          base.SECRETS + "/tls-private.pem", base.SECRETS + "/tls-chain.pem")
        self.control_exec("p-mkdir-cli", "install", "-d", "-m", "0700",
                          "/opt/omne-recovery-cli", "/tmp/omne-recovery-cli")
        self.copy("p-copy-cli", self.cli_archive, "/opt/omne-recovery-cli.tar.gz")
        self.control_exec("p-extract-cli", "tar", "-xzf", "/opt/omne-recovery-cli.tar.gz",
                          "-C", "/opt/omne-recovery-cli")
        need(self.control_exec("p-cli-build-id", "cat", "/opt/omne-recovery-cli/app/BUILD_ID")
             .strip().decode() == CLI_BUILD_ID, "CLI BUILD_ID mismatch")
        need(self.control_exec("p-control-node-version", "node", "--version").strip()
             == b"v24.21.0", "private control Node version")

    def put_cli_file(self, label, name, content):
        need(re.fullmatch(r"[a-z0-9][a-z0-9.-]*", name) and ".." not in name,
             "unsafe private CLI file name")
        path = "/tmp/omne-recovery-cli/" + name
        self.outer(label, "exec", "-i", self.control, "sh", "-c",
                   "umask 077; cat > " + path, stdin=content)
        self.control_exec(label + "-stat", "stat", "-c", "%F:%u:%g:%a", path)
        return path

    def cli(self, label, action, *, payload=None, login=None, credential=None, refresh=False):
        actions = {"configure": ["center", "configure"], "health": ["center", "health"],
                   "register": ["register"], "login": ["login"],
                   "create": ["organization", "create"], "switch": ["tenant", "switch"],
                   "current": ["tenant", "current"], "list": ["tenant", "list"]}
        argv = ["docker", "exec", "-e", "HOME=/tmp/omne-recovery-cli", self.control,
                "node", "/opt/omne-recovery-cli/app/dist/main.js", "machine",
                *actions[action], "--state-dir", "/tmp/omne-recovery-cli/state"]
        if action == "configure":
            argv += ["--endpoint", f"https://{self.publish_address}:18443",
                     "--ca-file", base.SECRETS + "/tls-chain.pem"]
        else:
            if login is not None:
                argv += ["--login-identifier", login]
            if payload is not None:
                path = self.put_cli_file(label + "-payload", label + ".json",
                                         json.dumps(payload, sort_keys=True,
                                                    separators=(",", ":")).encode() + b"\n")
                argv += ["--payload-file", path]
            if credential is not None:
                argv += ["--credential-file", credential]
            if refresh:
                argv += ["--refresh"]
        report = one_json(self.call(label, argv, timeout=self.args.observe_seconds), label)
        need(report.get("format") == "governance-client/1" and report.get("defect") is None,
             label + ": invalid public CLI report")
        return report

    @staticmethod
    def cli_result(report, label):
        result = report.get("remote", {}).get("reply", {}).get("reply", {}).get("result")
        need(report.get("remote", {}).get("status") == "success" and result is not None,
             label + ": public fact unconfirmed")
        return result

    def public_facts_before(self):
        self.cli("p-cli-configure", "configure")
        self.cli("p-cli-health-before", "health")
        login = "qa" + self.project
        credential = self.put_cli_file("p-write-credential", "credential.secret",
                                       secrets.token_hex(18).encode())
        self.cli("p-cli-register", "register", login=login, credential=credential)
        self.cli("p-cli-login", "login", login=login, credential=credential)
        personal = self.cli_result(self.cli("p-cli-personal-before", "current",
                                            payload={}, refresh=True), "personal")
        organization = self.cli_result(self.cli("p-cli-create-team", "create",
                                                payload={"creationKey": "recovery-" + self.project}),
                                       "team creation")
        team = {"organization": organization, "account": personal["account"]}
        self.cli_result(self.cli("p-cli-switch", "switch",
                                 payload={"expectedTenant": personal,
                                          "targetTenant": team}), "tenant switch")
        self.cli("p-cli-current-before", "current", payload={}, refresh=True)
        self.cli("p-cli-list-before", "list", payload={}, refresh=True)

    def snapshot_observe(self, phase, path=None):
        if path is None:
            listing = self.control_exec(phase + "-find-snapshot", "find",
                                        base.STATE + "/backups/.quarantine", "-mindepth", "2",
                                        "-maxdepth", "2", "-name", "snapshot.sqlite", "-print")
            lines = listing.decode("utf8", "strict").splitlines()
            need(len(lines) == 1 and SNAPSHOT.fullmatch(lines[0]),
                 "one actual task snapshot.sqlite required")
            path = lines[0]
            self.evidence["snapshot_path"] = path
            self.save()
        need(SNAPSHOT.fullmatch(path), "snapshot path escaped fresh quarantine")
        task = str(pathlib.PurePosixPath(path).parent)
        self.control_exec(phase + "-task-stat", "stat", "-c", "%F:%d:%i:%u:%g:%a", task)
        self.control_exec(phase + "-snapshot-stat", "stat", "-c", "%F:%d:%i:%u:%g:%a:%s", path)
        self.control_exec(phase + "-snapshot-sha", "sha256sum", path)
        self.control_exec(phase + "-snapshot-header", "head", "-c", "16", path)
        self.control_exec(phase + "-marker-stat", "stat", "-c", "%F:%d:%i:%u:%g:%a:%s", MARKER)
        self.control_exec(phase + "-marker-content", "cat", MARKER)
        return path

    def proc_observe(self, pid):
        proc = f"/proc/{pid}"
        cmd = self.outer("p-proc-cmdline", "exec", self.dind, "cat", proc + "/cmdline")
        argv = cmd.split(b"\0")
        need(argv[-1] == b"" and len(argv) == 4
             and pathlib.PurePosixPath(argv[0].decode()).name == "node"
             and argv[1:] == [b"/opt/omne/app/dist/cli.js", b"serve", b""],
             "State.Pid does not identify the exact app serve process")
        status = self.outer("p-proc-status", "exec", self.dind, "cat", proc + "/status")
        lines = dict(line.split(b":", 1) for line in status.splitlines() if b":" in line)
        nspid = [int(x) for x in lines[b"NSpid"].split()]
        need(len(nspid) >= 2 and nspid[0] == pid and nspid[-1] == 1,
             "State.Pid is not this nested center PID1")
        namespace = self.outer("p-proc-pid-namespace", "exec", self.dind,
                               "readlink", proc + "/ns/pid").strip().decode()
        daemon_namespace = self.outer("p-dind-pid-namespace", "exec", self.dind,
                                      "readlink", "/proc/1/ns/pid").strip().decode()
        need(namespace != daemon_namespace and re.fullmatch(r"pid:\[[0-9]+\]", namespace),
             "target belongs to DinD daemon PID namespace")
        stat = self.outer("p-proc-stat", "exec", self.dind, "cat", proc + "/stat")
        start_ticks = stat.rsplit(b") ", 1)[1].split()[19].decode("ascii")
        cgroup = self.outer("p-proc-cgroup", "exec", self.dind, "cat", proc + "/cgroup")
        build = self.outer("p-proc-build", "exec", self.dind, "cat",
                           proc + "/root" + BUILD_FILE).strip().decode()
        need(build == io_driver.BUILD_ID, "PID root filesystem is not the final app")
        self.evidence["signal_preflight"] = {"pid": pid, "cmd_sha256": hashlib.sha256(cmd).hexdigest(),
                                            "cgroup_sha256": hashlib.sha256(cgroup).hexdigest(),
                                            "start_ticks": start_ticks, "pid_namespace": namespace}
        self.save()
        return self.evidence["signal_preflight"]

    def original_serve_rejection(self, snapshot):
        path = "/state" + snapshot[len(base.STATE):]
        need(re.fullmatch(r"/state/backups/\.quarantine/task-[0-9a-f]{32}/snapshot\.sqlite",
                          path), "probe source is not the retained exact plaintext")
        name = "omne-" + self.project + "-isolated-probe"
        flags = ["run", "--name", name, "--pull", "never", "--network", "none",
                 "--restart", "no", "--label", self.label,
                 "--label", "ai.nemori.omne.project=" + self.project,
                 "--user", "10001:10001",
                 "--mount", f"type=bind,source={base.STATE},target=/state",
                 "--mount", f"type=bind,source={base.SECRETS},target=/secrets,readonly",
                 "--tmpfs", "/run/omne-tenancy:mode=0700,uid=10001,gid=10001,nosuid,nodev,noexec",
                 "--env-file", base.SETTINGS, "-e", "OMNE_TENANCY_STORAGE_DIALECT=sqlite",
                 "-e", "OMNE_TENANCY_STORAGE_FILE=" + path,
                 "-e", "OMNE_TENANCY_BACKUP_DIR=/state/backups",
                 "-e", "OMNE_TENANCY_OPS_SOCKET_DIR=/run/omne-tenancy",
                 "-e", "OMNE_TENANCY_ENTRY_LISTEN=0.0.0.0:8443"]
        for key, file in (("ACTIVATION_SIGNING_KEY", "activation-signing-key"),
                          ("ACTIVATION_VERIFICATION_KEY", "activation-verification-key"),
                          ("PURGE_SIGNING_KEY", "purge-signing-key"),
                          ("PURGE_VERIFICATION_KEY", "purge-verification-key")):
            flags += ["-e", f"OMNE_TENANCY_{key}_PEM_FILE=/secrets/{file}.pem"]
        flags += ["-e", "OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE=/secrets/tls-chain.pem",
                  "-e", "OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE=/secrets/tls-private.pem",
                  self.evidence["expected"]["inner_image_id"]]
        self.inner("p-original-serve", *flags, expected=None, timeout=90)
        self.inner("p-original-serve-inspect", "inspect", name)
        self.inner("p-original-serve-logs", "logs", name)
        self.evidence["original_serve_probe"] = {"name": name, "storage_file": path}
        self.save()

    def scenario(self):
        common = ["--project", self.project]
        deployment = [*common, "--image", self.qa_id, "--state-dir", base.STATE,
                      "--secrets-dir", base.SECRETS, "--settings-file", base.SETTINGS,
                      "--publish-address", self.publish_address, "--publish-port", "18443",
                      "--uid", "10001", "--gid", "10001"]
        self.helper("p-validate", "validate", *deployment)
        started = one_json(self.helper("p-start", "start", *deployment,
                                       timeout=self.args.observe_seconds), "p-start")
        cid = started.get("containerId")
        need(isinstance(cid, str) and base.HEX64.fullmatch(cid), "helper start lacked exact CID")
        self.evidence["center_id"] = cid
        self.save()
        self.await_file("p-gate-ready", base.STATE + "/qa/ready")
        self.control_exec("p-generation-stat-before", "stat", "-c", "%F:%u:%g:%a:%s",
                          base.STATE + "/qa/generation")
        self.control_exec("p-generation-content-before", "cat", base.STATE + "/qa/generation")
        self.inner("p-center-initial", "inspect", cid)
        self.helper("p-full-health-before", "full-health", *common)
        self.public_facts_before()
        prior = one_json(self.helper("p-prior-backup", "backup", *common,
                                     timeout=self.args.observe_seconds), "p-prior-backup")
        need(prior.get("status") == "completed" and isinstance(prior.get("backup"), dict),
             "prior backup not confirmed completed")
        self.helper("p-prior-backup-status", "backup-status", *common)
        self.evidence["prior_backup"] = prior["backup"]
        self.save()
        self.control_exec("p-held-before-arm", "test", "!", "-e", base.STATE + "/qa/held")
        self.control_exec("p-arm-gate", "touch", base.STATE + "/qa/arm")
        backup_argv = ["docker", "exec", "-e", f"DOCKER_HOST={base.SOCKET}", self.control,
                       base.HELPER, "backup", *common]
        self.asynchronous("p-pending-backup", backup_argv)
        held = self.await_file("p-gate-held", base.STATE + "/qa/held")
        need(held.get("stage") == "write" and held.get("pid") == 1
             and type(held.get("fd")) is int and held["fd"] >= 0
             and io_driver.FD_PATH.fullmatch(held.get("path", "")),
             "QA did not hold the real export FileHandle")
        fd = f"/proc/1/fd/{held['fd']}"
        self.inner("p-held-fd-link", "exec", cid, "readlink", fd)
        self.inner("p-held-fd-stat", "exec", cid, "stat", "-Lc", "%d:%i:%u:%g:%a", fd)
        snapshot = self.snapshot_observe("p-before")
        self.inner("p-center-stable-first", "inspect", cid)
        self.evidence["stable_started_monotonic_ns"] = time.monotonic_ns()
        self.save()
        time.sleep(self.args.stable_seconds)
        self.inner("p-center-stable-last", "inspect", cid)
        self.evidence["stable_finished_monotonic_ns"] = time.monotonic_ns()
        self.save()
        need(self.async_clients["p-pending-backup"][1].poll() is None,
             "pending backup completed before fault")
        self.inner("p-center-before-signal", "inspect", cid)
        current = json.loads((self.run / "raw/p-center-before-signal.stdout").read_bytes())[0]
        pid = current["State"]["Pid"]
        need(current["Id"] == cid and current["State"]["Status"] == "running"
             and current["State"]["Health"]["Status"] == "healthy"
             and current["State"]["Running"] is True
             and current["HostConfig"]["RestartPolicy"]["Name"] == "unless-stopped"
             and type(pid) is int and pid > 1, "live center restart preconditions absent")
        identity = self.proc_observe(pid)
        self.copy("p-copy-pid-signal", self.frozen / "pid_signal.sh", "/opt/omne-pid-signal.sh")
        self.evidence["signal_event_since"] = base.utc()
        self.save()
        self.outer("p-one-os-sigkill", "exec", self.dind, "sh", "/opt/omne-pid-signal.sh",
                   str(pid), cid, identity["cmd_sha256"], identity["start_ticks"],
                   identity["pid_namespace"], current["State"]["StartedAt"],
                   str(current["RestartCount"]), io_driver.BUILD_ID, "10001", "10001",
                   identity["cgroup_sha256"])
        self.evidence["signal_sent_monotonic_ns"] = time.monotonic_ns()
        self.save()
        deadline = time.monotonic() + self.args.observe_seconds
        for attempt in range(1, 181):
            label = f"p-restart-poll-{attempt}"
            data = json.loads(self.inner(label, "inspect", cid))[0]
            need(data["Id"] == cid, "center identity changed after process crash")
            if (data["State"]["Status"] == "running"
                    and data["State"]["Health"]["Status"] == "healthy"
                    and data["State"]["StartedAt"] != current["State"]["StartedAt"]
                    and data["RestartCount"] >= current["RestartCount"] + 1
                    and type(data["State"]["Pid"]) is int and data["State"]["Pid"] > 1):
                self.evidence["recovered_poll"] = label
                self.save()
                break
            need(time.monotonic() < deadline, "automatic restart/health observation expired")
            time.sleep(1)
        else:
            raise RuntimeError("automatic restart/health observation expired")
        self.inner("p-center-recovered", "inspect", cid)
        self.helper("p-status-recovered", "status", *common)
        self.helper("p-full-health-recovered", "full-health", *common)
        self.helper("p-backup-status-recovered", "backup-status", *common)
        self.cli("p-cli-health-after", "health")
        self.cli("p-cli-current-after", "current", payload={}, refresh=True)
        self.cli("p-cli-list-after", "list", payload={}, refresh=True)
        recovered = json.loads((self.run / "raw/p-center-recovered.stdout").read_bytes())[0]
        first = json.loads(self.inner("p-recovered-observe-1", "inspect", cid))[0]
        self.evidence["recovered_observation_started_monotonic_ns"] = time.monotonic_ns()
        deadline_ns = (self.evidence["recovered_observation_started_monotonic_ns"] +
                       self.args.restart_observe_seconds * 1_000_000_000)
        index = 1
        while True:
            need(first["Id"] == cid and first["State"]["Status"] == "running"
                 and first["State"]["Health"]["Status"] == "healthy"
                 and first["State"]["StartedAt"] == recovered["State"]["StartedAt"]
                 and first["RestartCount"] == recovered["RestartCount"],
                 "recovered center changed during finite observation")
            if time.monotonic_ns() >= deadline_ns:
                index += 1
                first = json.loads(self.inner(f"p-recovered-observe-{index}",
                                              "inspect", cid))[0]
                break
            time.sleep(min(1, max(0, (deadline_ns - time.monotonic_ns()) / 1_000_000_000)))
            index += 1
            first = json.loads(self.inner(f"p-recovered-observe-{index}", "inspect", cid))[0]
        self.evidence["recovered_observation_last_label"] = f"p-recovered-observe-{index}"
        self.evidence["recovered_observation_finished_monotonic_ns"] = time.monotonic_ns()
        self.save()
        self.snapshot_observe("p-after", snapshot)
        self.control_exec("p-generation-stat-after", "stat", "-c", "%F:%u:%g:%a:%s",
                          base.STATE + "/qa/generation")
        self.control_exec("p-generation-content-after", "cat", base.STATE + "/qa/generation")
        self.original_serve_rejection(snapshot)
        self.snapshot_observe("p-probe-after", snapshot)
        self.inner("p-center-logs", "logs", cid)
        self.inner("p-center-events", "events", "--since", self.evidence["signal_event_since"],
                   "--until", base.utc(), "--filter", f"container={cid}",
                   "--format", "{{json .}}", timeout=20)
        try:
            self.finish_async("p-pending-backup", 30)
        except RuntimeError:
            item = self.async_clients["p-pending-backup"][0]
            need(item["observation_expired"] is True and item["returncode"] is None,
                 "pending backup client failed without an unknown observation")
            self.evidence["pending_client_outcome"] = "unknown-after-observation-budget"
            self.save()
        self.evidence["business_complete"] = True
        self.evidence["status"] = "observed-awaiting-oracle"
        self.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=("P",), required=True)
    parser.add_argument("--i3-manifest", type=pathlib.Path, required=True)
    parser.add_argument("--image-tar", type=pathlib.Path, required=True)
    parser.add_argument("--helper-dir", type=pathlib.Path, required=True)
    parser.add_argument("--cli-tar", type=pathlib.Path, required=True)
    parser.add_argument("--cli-build-id", required=True)
    parser.add_argument("--v0-dir", type=pathlib.Path, required=True)
    parser.add_argument("--design-root", type=pathlib.Path, required=True)
    parser.add_argument("--uid", type=int, default=10001)
    parser.add_argument("--gid", type=int, default=10001)
    parser.add_argument("--hold-seconds", type=float, default=31.5)
    parser.add_argument("--term-observe-seconds", type=float, default=15.0)
    parser.add_argument("--stable-seconds", type=int, default=12)
    parser.add_argument("--restart-observe-seconds", type=int, default=10)
    parser.add_argument("--observe-seconds", type=int, default=180)
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    inputs = checked_inputs(args)
    if args.print_inputs:
        print(json.dumps({"inputs": inputs, "inputs_sha256": io_driver.canonical_hash(inputs)},
                         sort_keys=True))
        return 0
    need(args.execute, "Docker execution requires --execute")
    io_driver.reviewed_inputs(args, inputs)
    args.image_id = io_driver.IMAGE_ID
    args.build_id = io_driver.BUILD_ID
    run = PilotRun(args, inputs)
    try:
        run.setup()
        run.import_image()
        run.prepare_paths()
        run.prepare_public_cli()
        run.prepare_qa()
        run.scenario()
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
        run.save()
    finally:
        run.cleanup()
    with (run.run / "oracle.stdout").open("xb") as stdout, \
            (run.run / "oracle.stderr").open("xb") as stderr:
        checked = subprocess.run([sys.executable, "-B", str(run.frozen / "oracle.py"),
                                  str(run.run)], stdout=stdout, stderr=stderr, check=False)
    run.evidence["oracle_exit"] = checked.returncode
    run.save()
    print(json.dumps({"run": str(run.run), "scenario": "P", "oracle_exit": checked.returncode,
                      "cleanup_complete": run.evidence["cleanup_complete"]}, sort_keys=True))
    return 0 if checked.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
