import assert from 'node:assert/strict'
import { promises as fs } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const root = await fs.mkdtemp(join(here, '.gate-selftest-'))
try {
  const source = await fs.readFile(join(here, 'gate.mjs'), 'utf8')
  const original = "const control = '/state/qa'"
  assert.equal(source.split(original).length, 2)
  const testModule = join(root, 'gate.mjs')
  await fs.writeFile(testModule, source.replace(original, `const control = ${JSON.stringify(root)}`))
  await fs.writeFile(join(root, 'mode'), 'write-hold\n', { mode: 0o600 })
  process.argv[1] = '/opt/omne/app/dist/cli.js'
  process.argv[2] = 'serve'
  const url = pathToFileURL(testModule).href
  await import(url + '?first')
  const sentinel = await fs.readFile(join(root, 'generation'), 'utf8')
  const ready = await fs.readFile(join(root, 'ready'), 'utf8')
  assert.equal(sentinel, 'omne-qa-generation/1\n')
  assert.equal(JSON.parse(ready).mode, 'write-hold')
  assert.equal((await fs.stat(join(root, 'generation'))).mode & 0o777, 0o600)
  await import(url + '?second')
  assert.equal(await fs.readFile(join(root, 'generation'), 'utf8'), sentinel)
  assert.equal(await fs.readFile(join(root, 'ready'), 'utf8'), ready)
  await fs.chmod(join(root, 'generation'), 0o644)
  await assert.rejects(import(url + '?bad'), /generation claim is not the protected original/)
  process.stdout.write(JSON.stringify({ status: 'pass', firstArm: true,
    secondPassThrough: true, invalidSentinelRejected: true }) + '\n')
} finally {
  await fs.rm(root, { recursive: true, force: true })
}
