// QA image only. Arm only after the real center has passed helper start/health.
import { promises as fs } from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'
import { setTimeout as delay } from 'node:timers/promises'

const control = '/state/qa'
const target = /^\/state\/backups\/\.quarantine\/export-[0-9a-f]{32}$/
const generation = `${control}/generation`

async function firstGeneration() {
  let claim
  try {
    claim = await fs.open(generation, 'wx', 0o600)
  } catch (error) {
    if (error?.code !== 'EEXIST') throw error
    const info = await fs.lstat(generation)
    if (!info.isFile() || info.uid !== process.getuid() ||
        (info.mode & 0o777) !== 0o600 ||
        (await fs.readFile(generation, 'utf8')) !== 'omne-qa-generation/1\n') {
      throw new Error('qa gate: generation claim is not the protected original')
    }
    process.stderr.write(JSON.stringify({ event: 'qa-generation', branch: 'pass-through',
      pid: process.pid }) + '\n')
    return false
  }
  try {
    await claim.writeFile('omne-qa-generation/1\n')
    await claim.sync()
  } finally {
    await claim.close()
  }
  process.stderr.write(JSON.stringify({ event: 'qa-generation', branch: 'armed',
    pid: process.pid }) + '\n')
  return true
}

async function installGate() {
  const mode = (await fs.readFile(`${control}/mode`, 'utf8')).trim()
  if (mode !== 'write-hold' && mode !== 'close-fail') throw new Error('qa gate: invalid mode')
  const originalOpen = fs.open.bind(fs)
  let attached = false

  async function held(stage, handle, path) {
    const info = await handle.stat()
    if (handle.fd < 0 || !info.isFile() || info.uid !== process.getuid() ||
        (info.mode & 0o777) !== 0o600) {
      throw new Error('qa gate: expected owned 0600 FileHandle')
    }
    await fs.writeFile(`${control}/held`, JSON.stringify({
      stage, path, fd: handle.fd, pid: process.pid, dev: info.dev, ino: info.ino,
    }) + '\n', { flag: 'wx', mode: 0o600 })
    for (;;) {
      try {
        await fs.stat(`${control}/release`)
        return
      } catch (error) {
        if (error?.code !== 'ENOENT') throw error
        await delay(50)
      }
    }
  }

  fs.open = async (...args) => {
    const handle = await originalOpen(...args)
    const path = String(args[0])
    if (attached || !target.test(path) || args[1] !== 'wx' || args[2] !== 0o600) return handle
    try {
      await fs.stat(`${control}/arm`)
    } catch (error) {
      if (error?.code === 'ENOENT') return handle
      throw error
    }
    attached = true
    if (mode === 'write-hold') {
      const originalWriteFile = handle.writeFile.bind(handle)
      let first = true
      handle.writeFile = async (...writeArgs) => {
        if (first) {
          first = false
          await held('write', handle, path)
        }
        return originalWriteFile(...writeArgs)
      }
    } else {
      let signalled = false
      handle.close = async () => {
        if (!signalled) {
          signalled = true
          await held('close', handle, path)
        }
        const failure = new Error('qa gate: injected FileHandle.close EIO')
        failure.code = 'EIO'
        throw failure
      }
    }
    return handle
  }
  syncBuiltinESMExports()
  await fs.writeFile(`${control}/ready`, JSON.stringify({
    stage: 'ready', mode, pid: process.pid, armed: false,
  }) + '\n', { flag: 'wx', mode: 0o600 })
}

if (process.argv[1] === '/opt/omne/app/dist/cli.js' && process.argv[2] === 'serve') {
  if (await firstGeneration()) await installGate()
}
