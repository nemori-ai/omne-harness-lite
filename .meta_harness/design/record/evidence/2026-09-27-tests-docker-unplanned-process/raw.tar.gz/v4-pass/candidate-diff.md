# P static candidate v3 → v4

Source: frozen v3 `static-manifest.json` SHA256 `dade2206b452ecbc2e7a7b4d7de57f76287aeca91063d49c827cdae60147bddc` (all 45 listed static files matched before copying). Its real run `runs/20260927T014125Z-2f6cf776` recorded `p-copy-pid-signal` exiting 0 with target `<control>:/opt/omne-pid-signal.sh`, followed by `p-one-os-sigkill` exiting 2 in `<dind>` with `sh: can't open '/opt/omne-pid-signal.sh'`. No target signal was sent; cleanup completed. The old run, gate and v3 files remain untouched.

V4 changes only this cross-container fixture transfer. `driver.py` copies the frozen `pid_signal.sh` explicitly to `<dind>:/opt/omne-pid-signal.sh`, runs `sha256sum` in that same DinD, and requires the exact frozen script SHA/path before invoking it. `oracle.py` requires both commands in order before the guarded OS signal, their exact argv/destination and read-back output. `self_test.py` retains both positives and all 21 prior rejection cases, then adds three focused wrong-container, wrong-reader and wrong-SHA mutations. All RootFS, public-fact, restart/event, residual and production-open checks are unchanged.

V4 has only static offline checks. `candidate-argv.json` remains an inert `--print-inputs` command; a new root-reviewed gate and separate run instruction are required before Docker or fault execution. Case D remains outside this candidate.
