#!/usr/bin/env python3
"""Synthetic P oracle counterexamples; never invokes Docker or signals a process."""

import copy
import contextlib
import hashlib
import io
import json
import pathlib
import shutil
import tempfile

import oracle

HERE = pathlib.Path(__file__).resolve().parent
DELIVERY = pathlib.Path("/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery/tmp/docker-delivery/i3-f8f286c9")
CID = "a" * 64
QA_IMAGE = "sha256:" + "b" * 64
ORIGINAL_IMAGE = "sha256:" + "c" * 64
CENTER = "d" * 32
CONTROL = "selftest-control"
DIND = "selftest-dind"
SNAPSHOT = "/var/lib/omne-tenancy/state/backups/.quarantine/task-" + "e" * 32 + "/snapshot.sqlite"
TASK = str(pathlib.PurePosixPath(SNAPSHOT).parent)
EXPORT = "/state/backups/.quarantine/export-" + "f" * 32
MARKER = b"regular file:2048:901:10001:10001:600:16\n"
STAT = b"regular file:2048:900:10001:10001:600:4096\n"
TASK_STAT = b"directory:2048:899:10001:10001:700\n"
SHA_LINE = ("1" * 64 + "  " + SNAPSHOT + "\n").encode()


def encoded(value):
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        return value.encode()
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def cli(result=None, *, health=False):
    report = {"format": "governance-client/1", "defect": None,
              "origin": {"centerId": CENTER}, "remote": {"status": "success"}}
    if health:
        report["remote"]["health"] = {"centerId": CENTER, "reachable": True}
    else:
        report["remote"]["reply"] = {"reply": {"result": result}}
    return report


def make_fixture(run):
    (run / "raw").mkdir()
    frozen = run / "inputs"
    frozen.mkdir()
    hashes = {}
    files = {name: HERE / name for name in
             ("driver.py", "oracle.py", "base_driver.py", "io_driver.py", "gate.mjs",
              "gate_availability.mjs", "inventory.mjs", "pid_signal.sh")}
    files["cli.tar.gz"] = DELIVERY / "cli.tar.gz"
    files["i3-manifest.json"] = DELIVERY / "manifest-delivery.json"
    for name, source in files.items():
        shutil.copyfile(source, frozen / name)
        key = {"cli.tar.gz": "cli_tar", "i3-manifest.json": "i3_manifest"}.get(
            name, name.removesuffix(".py").removesuffix(".mjs").removesuffix(".sh"))
        hashes[key] = hashlib.sha256((frozen / name).read_bytes()).hexdigest()
    hashes["helper"] = oracle.HELPER_SHA
    hashes["docker_spec"] = oracle.DOCKER_SPEC_SHA
    inputs = {"build_id": oracle.BUILD_ID, "cli_build_id": oracle.CLI_BUILD_ID,
              "qa_gate_mode": "write-hold", "stable_seconds": 12,
              "restart_observe_seconds": 10, "sha256": hashes}
    gate = {"approved": True, "reviewer": "root",
            "inputs_sha256": hashlib.sha256(json.dumps(inputs, sort_keys=True,
                separators=(",", ":")).encode()).hexdigest(),
            "driver_sha256": hashes["driver"], "oracle_sha256": hashes["oracle"]}
    (frozen / "reviewed-gate.json").write_text(json.dumps(gate) + "\n")
    rows = []

    def add(label, stdout=b"", stderr=b"", rc=0, argv=None, started_utc=None):
        out = "raw/" + label + ".stdout"
        err = "raw/" + label + ".stderr"
        (run / out).write_bytes(encoded(stdout))
        (run / err).write_bytes(encoded(stderr))
        rows.append({"label": label, "argv": argv or ["fixture", label], "stdout": out,
                     "stderr": err, "returncode": rc, "observation_expired": False,
                     "started_monotonic_ns": 100_000_000_000,
                     "started_utc": started_utc or "2026-09-27T00:00:00+00:00"})

    labels = {"ai.nemori.omne.qa-fixture": "maintenance-gate/r5"}
    original = {"Id": ORIGINAL_IMAGE, "Config": {"Env": ["NODE_ENV=production"],
                "Entrypoint": ["node", "/opt/omne/app/dist/cli.js"], "Cmd": ["serve"],
                "WorkingDir": "/opt/omne/app"},
                "RootFS": {"Layers": ["sha256:" + "3" * 64]}}
    qa = copy.deepcopy(original)
    qa["Id"] = QA_IMAGE
    qa["Config"]["Labels"] = labels
    qa["Config"]["Env"].append("NODE_OPTIONS=--import=/probe/gate.mjs")
    qa["RootFS"]["Layers"].extend("sha256:" + digit * 64 for digit in "456")
    inventory = {"status": "verified", "buildId": oracle.BUILD_ID, "files": 2851,
                 "links": 115, "manifestSha256": "5" * 64}
    add("inner-image-inspect", [original])
    add("qa-image-inspect", [qa])
    add("original-inventory", inventory)
    add("qa-inventory", inventory)
    add("gate-availability", {"status": "pass"})
    add("p-validate", {"state": "deployment-structure-valid"})
    add("p-start", {"state": "running", "containerId": CID, "health": "healthy"})
    add("p-gate-ready", {"mode": "write-hold"})
    for suffix in ("before",):
        add("p-generation-stat-" + suffix, "regular file:10001:10001:600:21\n")
        add("p-generation-content-" + suffix, "omne-qa-generation/1\n")
    before = {"Id": CID, "State": {"Status": "running", "Running": True,
              "Health": {"Status": "healthy"}, "Pid": 123,
              "StartedAt": "2026-09-27T00:00:00Z"},
              "HostConfig": {"RestartPolicy": {"Name": "unless-stopped"}},
              "RestartCount": 0}
    after = copy.deepcopy(before)
    after["State"]["Pid"] = 456
    after["State"]["StartedAt"] = "2026-09-27T00:01:00Z"
    after["RestartCount"] = 1
    add("p-center-initial", [before])
    full = {"centerId": CENTER, "reachable": True, "storageReachable": True,
            "clockSane": True, "deploymentKeyPresent": True,
            "deploymentKeyComplete": True, "defectCount": 0}
    add("p-full-health-before", full)
    add("p-cli-configure", cli({}))
    add("p-cli-health-before", cli(health=True))
    credential_argv = ["docker", "exec", CONTROL, "node", "machine", "register",
                       "--login-identifier", "qapilot", "--credential-file",
                       "/tmp/omne-recovery-cli/credential.secret"]
    add("p-cli-register", cli({}), argv=credential_argv)
    add("p-cli-login", cli({}), argv=[*credential_argv[:-3], "login", *credential_argv[-3:]])
    personal = {"account": "acct", "organization": "personal"}
    team = {"account": "acct", "organization": "team"}
    add("p-cli-personal-before", cli(personal))
    add("p-cli-create-team", cli("team"))
    add("p-cli-switch", cli(team))
    add("p-cli-current-before", cli(team))
    add("p-cli-list-before", cli([personal, team]))
    descriptor = {"fileName": "6" * 32 + ".omne-backup",
                  "metadata": {"centerId": CENTER}}
    backup_argv = ["docker", "exec", "-e",
                   "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock", CONTROL,
                   "/usr/local/libexec/omne-center", "backup", "--project", "pilot"]
    add("p-prior-backup", {"status": "completed", "backup": descriptor}, argv=backup_argv)
    status = {"status": "observed", "health": "current", "latest": descriptor,
              "invalidCount": 0}
    add("p-prior-backup-status", status)
    add("p-arm-gate")
    add("p-pending-backup", stderr="Docker exec ended after process death\n", rc=1,
        argv=backup_argv)
    held = {"stage": "write", "pid": 1, "fd": 17, "path": EXPORT,
            "dev": 2048, "ino": 902}
    add("p-gate-held", held)
    add("p-held-fd-link", EXPORT + "\n")
    add("p-held-fd-stat", "2048:902:10001:10001:600\n")
    add("p-before-find-snapshot", SNAPSHOT + "\n")
    for phase in ("p-before",):
        add(phase + "-task-stat", TASK_STAT)
        add(phase + "-snapshot-stat", STAT)
        add(phase + "-snapshot-sha", SHA_LINE)
        add(phase + "-snapshot-header", oracle.SQLITE_HEADER)
        add(phase + "-marker-stat", MARKER)
        add(phase + "-marker-content", oracle.MARKER_CONTENT)
    add("p-center-stable-first", [before], started_utc="2026-09-27T00:00:00+00:00")
    add("p-center-stable-last", [before], started_utc="2026-09-27T00:00:12+00:00")
    add("p-center-before-signal", [before])
    cmd = b"node\0/opt/omne/app/dist/cli.js\0serve\0"
    cgroup = b"0::/docker/" + CID.encode() + b"\n"
    stat_fields = [b"0"] * 30
    stat_fields[19] = b"777"
    proc_stat = b"123 (node) " + b" ".join(stat_fields) + b"\n"
    add("p-proc-cmdline", cmd)
    add("p-proc-status", b"Name:\tnode\nNSpid:\t123\t1\n")
    add("p-proc-pid-namespace", "pid:[111]\n")
    add("p-dind-pid-namespace", "pid:[222]\n")
    add("p-proc-stat", proc_stat)
    add("p-proc-cgroup", cgroup)
    add("p-proc-build", oracle.BUILD_ID + "\n")
    signal_script = "/opt/omne-pid-signal.sh"
    add("p-copy-pid-signal", argv=["docker", "cp", str(frozen / "pid_signal.sh"),
                                    f"{DIND}:{signal_script}"])
    add("p-dind-pid-signal-sha", hashes["pid_signal"] + "  " + signal_script + "\n",
        argv=["docker", "exec", DIND, "sha256sum", signal_script])
    add("p-one-os-sigkill", f"pid=123 cid={CID} signal=SIGKILL\n",
        argv=["docker", "exec", DIND, "sh", "/opt/omne-pid-signal.sh", "123", CID])
    add("p-restart-poll-1", [after])
    add("p-center-recovered", [after])
    add("p-status-recovered", {"state": "running", "health": "healthy",
         "containerId": CID, "restartCount": 1})
    add("p-full-health-recovered", full)
    add("p-backup-status-recovered", status)
    add("p-cli-health-after", cli(health=True))
    add("p-cli-current-after", cli(team))
    add("p-cli-list-after", cli([personal, team]))
    add("p-recovered-observe-1", [after], started_utc="2026-09-27T00:01:00+00:00")
    add("p-recovered-observe-2", [after], started_utc="2026-09-27T00:01:11+00:00")
    for phase in ("p-after",):
        add(phase + "-task-stat", TASK_STAT)
        add(phase + "-snapshot-stat", STAT)
        add(phase + "-snapshot-sha", SHA_LINE)
        add(phase + "-snapshot-header", oracle.SQLITE_HEADER)
        add(phase + "-marker-stat", MARKER)
        add(phase + "-marker-content", oracle.MARKER_CONTENT)
    add("p-generation-stat-after", "regular file:10001:10001:600:21\n")
    add("p-generation-content-after", "omne-qa-generation/1\n")
    probe_name = "omne-r5pilot-isolated-probe"
    probe_file = "/state" + SNAPSHOT[len("/var/lib/omne-tenancy/state"):]
    add("p-original-serve", rc=1)
    probe = {"Id": "7" * 64, "Name": "/" + probe_name, "Image": ORIGINAL_IMAGE,
             "State": {"Status": "exited", "ExitCode": 1},
             "HostConfig": {"NetworkMode": "none", "RestartPolicy": {"Name": "no"},
                            "PortBindings": {}, "Tmpfs": {"/run/omne-tenancy": "mode=0700"}},
             "Mounts": [{"Destination": "/state", "Type": "bind", "RW": True,
                         "Source": "/var/lib/omne-tenancy/state"},
                        {"Destination": "/secrets", "Type": "bind", "RW": False,
                         "Source": "/var/lib/omne-tenancy/secrets"}],
             "Config": {"User": "10001:10001",
                        "Entrypoint": ["node", "/opt/omne/app/dist/cli.js"],
                        "Cmd": ["serve"], "Env": [
                          "OMNE_TENANCY_STORAGE_DIALECT=sqlite",
                          "OMNE_TENANCY_STORAGE_FILE=" + probe_file,
                          "OMNE_TENANCY_BACKUP_DIR=/state/backups",
                          "OMNE_TENANCY_OPS_SOCKET_DIR=/run/omne-tenancy",
                          "OMNE_TENANCY_ENTRY_LISTEN=0.0.0.0:8443",
                          *["OMNE_TENANCY_" + key + "_PEM_FILE=/secrets/" + file + ".pem"
                            for key, file in (("ACTIVATION_SIGNING_KEY", "activation-signing-key"),
                                              ("ACTIVATION_VERIFICATION_KEY", "activation-verification-key"),
                                              ("PURGE_SIGNING_KEY", "purge-signing-key"),
                                              ("PURGE_VERIFICATION_KEY", "purge-verification-key"))]],
                        }, "Path": "node", "Args": ["/opt/omne/app/dist/cli.js", "serve"]}
    probe["Config"]["Env"] += [
        "OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE=/secrets/tls-chain.pem",
        "OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE=/secrets/tls-private.pem"]
    add("p-original-serve-inspect", [probe])
    add("p-original-serve-logs", stderr=json.dumps({"event": "startup-failed",
        "stage": "storage-open", "message": "isolated maintenance data cannot be opened as production storage"}) + "\n")
    for phase in ("p-probe-after",):
        add(phase + "-task-stat", TASK_STAT)
        add(phase + "-snapshot-stat", STAT)
        add(phase + "-snapshot-sha", SHA_LINE)
        add(phase + "-snapshot-header", oracle.SQLITE_HEADER)
        add(phase + "-marker-stat", MARKER)
        add(phase + "-marker-content", oracle.MARKER_CONTENT)
    add("p-center-logs", stderr=(json.dumps({"event": "qa-generation", "branch": "armed"}) + "\n" +
                                 json.dumps({"event": "qa-generation", "branch": "pass-through"}) + "\n"))
    add("p-center-events", ('{"Action":"die","Actor":{"ID":"' + CID +
                            '","Attributes":{"exitCode":"137"}}}\n' +
                            '{"Action":"start","Actor":{"ID":"' + CID + '"}}\n'))
    evidence = {"scenario": "P", "business_complete": True,
                "artifact_manifest_sha256": oracle.I3_SHA, "inputs": inputs,
                "commands": rows, "cleanup_complete": True, "cleanup_errors": [],
                "center_id": CID, "qa_image_id": QA_IMAGE,
                "expected": {"control": CONTROL, "dind": DIND,
                             "inner_image_id": ORIGINAL_IMAGE,
                             "state": "/var/lib/omne-tenancy/state"},
                "stable_started_monotonic_ns": 100_000_000_000,
                "stable_finished_monotonic_ns": 112_000_000_000,
                "snapshot_path": SNAPSHOT,
                "signal_sent_monotonic_ns": 120_000_000_000,
                "signal_preflight": {"pid": 123, "cmd_sha256": hashlib.sha256(cmd).hexdigest(),
                                     "cgroup_sha256": hashlib.sha256(cgroup).hexdigest(),
                                     "start_ticks": "777", "pid_namespace": "pid:[111]"},
                "recovered_observation_started_monotonic_ns": 200_000_000_000,
                "recovered_observation_finished_monotonic_ns": 211_000_000_000,
                "recovered_observation_last_label": "p-recovered-observe-2",
                "original_serve_probe": {"name": probe_name, "storage_file": probe_file}}
    (run / "evidence.json").write_text(json.dumps(evidence) + "\n")
    return evidence


def mutate_raw(label, change):
    def mutate(run, _evidence):
        p = run / "raw" / (label + ".stdout")
        p.write_bytes(encoded(change(p.read_bytes())))
    return mutate


def modify_json(label, change):
    def mutate(run, _evidence):
        p = run / "raw" / (label + ".stdout")
        value = json.loads(p.read_bytes())
        change(value)
        p.write_bytes(encoded(value))
    return mutate


def check(name, change=None, *, accept=False):
    with tempfile.TemporaryDirectory(dir=HERE, prefix=".selftest-") as directory:
        run = pathlib.Path(directory)
        evidence = make_fixture(run)
        if change is None or accept:
            if change is not None:
                change(run, evidence)
                (run / "evidence.json").write_text(json.dumps(evidence) + "\n")
            with contextlib.redirect_stdout(io.StringIO()):
                oracle.evaluate(run)
            return
        change(run, evidence)
        (run / "evidence.json").write_text(json.dumps(evidence) + "\n")
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                oracle.evaluate(run)
        except (ValueError, KeyError, IndexError, TypeError):
            return
        raise AssertionError(name + ": false success accepted")


def multi_attempt(run, evidence):
    for label in ("p-restart-poll-1", "p-center-recovered",
                  "p-recovered-observe-1", "p-recovered-observe-2"):
        modify_json(label, lambda x: (x[0].update(RestartCount=2),
                    x[0]["State"].update(Pid=789, StartedAt="2026-09-27T00:02:00Z")))(run, evidence)
    modify_json("p-status-recovered", lambda x: x.update(restartCount=2))(run, evidence)
    lifecycle = [{"Action": action, "Actor": {"ID": CID, "Attributes": attributes}}
                 for action, attributes in (("die", {"exitCode": "137"}),
                                            ("start", {}), ("die", {"exitCode": "1"}),
                                            ("start", {}))]
    (run / "raw/p-center-events.stdout").write_bytes(
        b"".join(encoded(event) for event in lifecycle))
    (run / "raw/p-center-logs.stderr").write_bytes(b"".join(encoded(
        {"event": "qa-generation", "branch": branch})
        for branch in ("armed", "pass-through", "pass-through")))
    for item in evidence["commands"]:
        if item["label"] == "p-recovered-observe-1":
            item["started_utc"] = "2026-09-27T00:02:00+00:00"
        elif item["label"] == "p-recovered-observe-2":
            item["started_utc"] = "2026-09-27T00:02:11+00:00"


def mismatched_restart_count(run, _evidence):
    path = run / "raw/p-center-events.stdout"
    path.write_bytes(path.read_bytes() + encoded({"Action": "die",
        "Actor": {"ID": CID, "Attributes": {"exitCode": "1"}}}) +
        encoded({"Action": "start", "Actor": {"ID": CID}}))


def wrong_signal_script_container(_run, evidence):
    copy_command = next(item for item in evidence["commands"]
                        if item["label"] == "p-copy-pid-signal")
    copy_command["argv"][-1] = CONTROL + ":/opt/omne-pid-signal.sh"


def main():
    check("positive")
    check("multi-attempt-stable-positive", multi_attempt, accept=True)
    cases = [
        ("event-count-exceeds-restart-delta", mismatched_restart_count),
        ("missing-plaintext-header", mutate_raw("p-before-snapshot-header", lambda _: b"")),
        ("snapshot-owner-changed", mutate_raw("p-after-snapshot-stat", lambda _:
            b"regular file:2048:900:0:0:600:4096\n")),
        ("snapshot-hash-changed", mutate_raw("p-after-snapshot-sha", lambda _:
            ("2" * 64 + "  " + SNAPSHOT + "\n").encode())),
        ("marker-removed", mutate_raw("p-after-marker-content", lambda _: b"")),
        ("same-pid-restart", modify_json("p-center-recovered", lambda x:
            x[0]["State"].update(Pid=123))),
        ("no-restart-count", modify_json("p-center-recovered", lambda x:
            x[0].update(RestartCount=0))),
        ("lost-center-event", mutate_raw("p-center-events", lambda _:
            ('{"Action":"die","Actor":{"ID":"' + CID +
             '","Attributes":{"exitCode":"137"}}}\n').encode())),
        ("wrong-current-fact", modify_json("p-cli-current-after", lambda x:
            x["remote"]["reply"]["reply"].update(result={"account": "acct", "organization": "other"}))),
        ("lost-prior-backup", modify_json("p-backup-status-recovered", lambda x:
            x.update(latest=None))),
        ("lost-pass-through-log", lambda run, _e: (run / "raw/p-center-logs.stderr").write_text(
            json.dumps({"event": "qa-generation", "branch": "armed"}) + "\n")),
        ("pending-false-completed", lambda run, e: (
            next(x for x in e["commands"] if x["label"] == "p-pending-backup").update(returncode=0),
            (run / "raw/p-pending-backup.stdout").write_text('{"status":"completed"}\n'))),
        ("unsafe-pid1", modify_json("p-center-before-signal", lambda x:
            x[0]["State"].update(Pid=1))),
        ("bad-cmdline", mutate_raw("p-proc-cmdline", lambda _: b"dockerd\0")),
        ("same-pid-namespace", mutate_raw("p-dind-pid-namespace", lambda _:
            b"pid:[111]\n")),
        ("engine-kill-substitution", lambda _r, e:
            next(x for x in e["commands"] if x["label"] == "p-one-os-sigkill").update(
                argv=["docker", "kill", CID])),
        ("signal-script-wrong-container", wrong_signal_script_container),
        ("signal-script-wrong-reader", lambda _r, e:
            next(x for x in e["commands"] if x["label"] == "p-dind-pid-signal-sha").update(
                argv=["docker", "exec", CONTROL, "sha256sum", "/opt/omne-pid-signal.sh"])),
        ("signal-script-wrong-sha", mutate_raw("p-dind-pid-signal-sha", lambda _:
            ("0" * 64 + "  /opt/omne-pid-signal.sh\n").encode())),
        ("probe-wrong-image", modify_json("p-original-serve-inspect", lambda x:
            x[0].update(Image=QA_IMAGE))),
        ("probe-missing-state", modify_json("p-original-serve-inspect", lambda x:
            x[0]["Mounts"].pop(0))),
        ("probe-wrong-failure", lambda run, _e: (run / "raw/p-original-serve-logs.stderr").write_text(
            json.dumps({"event": "startup-failed", "stage": "storage-open", "message": "other"}) + "\n")),
        ("short-recovery-observation", lambda _r, e: e.update(
            recovered_observation_finished_monotonic_ns=205_000_000_000)),
        ("stale-stdout-command-failed", lambda _r, e:
            next(x for x in e["commands"] if x["label"] == "p-after-snapshot-stat").update(
                returncode=1)),
    ]
    for name, change in cases:
        check(name, change)
    print(json.dumps({"status": "pass", "synthetic_positive": 2,
                      "rejected_mutations": len(cases), "docker_executed": False,
                      "cases": [name for name, _ in cases]}, sort_keys=True))


if __name__ == "__main__":
    main()
