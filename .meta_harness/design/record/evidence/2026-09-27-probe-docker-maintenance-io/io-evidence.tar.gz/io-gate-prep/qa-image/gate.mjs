// QA image only. Delay one real backup output operation or inject one close rejection.
import { promises as fs } from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'
import { setTimeout as delay } from 'node:timers/promises'

async function installGate() {
  const control = '/state/qa'
  const target = /^\/state\/backups\/\.quarantine\/export-[0-9a-f]{32}$/
  const mode = (await fs.readFile(`${control}/mode`, 'utf8')).trim()
  if (mode !== 'write-hold' && mode !== 'close-fail') {
    throw new Error(`qa gate: unsupported mode ${JSON.stringify(mode)}`)
  }

  const originalOpen = fs.open.bind(fs)
  let attached = false

  async function held(stage, handle, path) {
    const info = await handle.stat()
    if (
      handle.fd < 0 ||
      !info.isFile() ||
      info.uid !== process.getuid() ||
      (info.mode & 0o077) !== 0
    ) {
      throw new Error('qa gate: target FileHandle was not privately owned')
    }
    await fs.writeFile(
      `${control}/held`,
      JSON.stringify({ stage, path, fd: handle.fd, pid: process.pid, dev: info.dev, ino: info.ino }) +
        '\n',
      { flag: 'wx', mode: 0o600 },
    )
    for (;;) {
      try {
        await fs.stat(`${control}/release`)
        return
      } catch (error) {
        if (error?.code !== 'ENOENT') throw error
        await delay(50)
      }
    }
  }

  fs.open = async (...args) => {
    const handle = await originalOpen(...args)
    const path = String(args[0])
    if (attached || !target.test(path) || args[1] !== 'wx' || args[2] !== 0o600) return handle
    attached = true
    if (mode === 'write-hold') {
      const originalWriteFile = handle.writeFile.bind(handle)
      let first = true
      handle.writeFile = async (...writeArgs) => {
        if (first) {
          first = false
          await held('write', handle, path)
        }
        return originalWriteFile(...writeArgs)
      }
    } else {
      let signalled = false
      handle.close = async () => {
        if (!signalled) {
          signalled = true
          await held('close', handle, path)
        }
        const failure = new Error('qa gate: injected FileHandle.close EIO')
        failure.code = 'EIO'
        throw failure
      }
    }
    return handle
  }
  syncBuiltinESMExports()

  await fs.writeFile(
    `${control}/ready`,
    JSON.stringify({ stage: 'ready', mode, pid: process.pid }) + '\n',
    { flag: 'wx', mode: 0o600 },
  )
}

// Healthcheck, --version and maintenance clients execute their original code paths.
// A changed production entry path makes the oracle miss ready and fail closed.
if (process.argv[1] === '/opt/omne/app/dist/cli.js' && process.argv[2] === 'serve') {
  await installGate()
}
