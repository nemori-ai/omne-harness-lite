#!/usr/bin/env python3
"""Pure synthetic checks for the independent oracle; no Docker resources are created."""

import copy
import json
import pathlib
import sys
import tempfile
from datetime import datetime, timezone

sys.dont_write_bytecode = True
from oracle import EXPECTED_BUILD_ID, verdict  # noqa: E402

HERE = pathlib.Path(__file__).resolve().parent
OUTPUT = HERE / "oracle-self-test.json"


def sample():
    inventory = {"status": "verified", "buildId": EXPECTED_BUILD_ID, "files": 2841,
                 "links": 115, "manifestSha256": "a", "node": "v24.21.0"}
    original = {"Id": "sha256:original", "Config": {"Entrypoint": ["node"],
                "Env": [], "Labels": {}}}
    qa = {"Id": "sha256:qa", "Config": {"Entrypoint": ["node"],
          "Env": ["NODE_OPTIONS=--import=/probe/gate.mjs"],
          "Labels": {"ai.nemori.omne.qa-fixture": "maintenance-gate/1"}}}

    def center(status, exit_code, running, pid):
        return {"Id": "center-id", "Image": "sha256:qa", "State": {
            "Status": status, "ExitCode": exit_code, "Running": running, "Pid": pid}}

    def row(label, output="", error="", rc=0):
        return {"label": label, "stdout": output if isinstance(output, str) else json.dumps(output),
                "stderr": error, "returncode": rc, "timed_out": False}

    rows = [
        row("original-inventory", inventory), row("qa-inventory", inventory),
        row("inner-original-inspect", [original]), row("qa-image-inspect", [qa]),
        row("center-before-stop", [center("running", 0, True, 123)]),
        row("center-after-31s", [center("running", 0, True, 123)]),
        row("center-final", [center("exited", 0, False, 0)]),
        row("stop-normal-finish"),
        row("center-logs", error='{"event":"still-stopping"}\n'),
        row("gate-ready", {"stage": "ready", "mode": "write-hold", "pid": 1}),
        row("gate-held", {"stage": "write", "pid": 1, "fd": 8,
                          "path": "/state/backups/.quarantine/export-" + "a" * 32,
                          "dev": 17, "ino": 19}),
        row("fd-readlink", "/state/backups/.quarantine/export-" + "a" * 32 + "\n"),
        row("fd-stat", "17:19:10001:10001:600\n"),
        row("gate-release-present"),
        row("contender-final", [{"Image": "sha256:original", "State": {
            "Status": "exited", "ExitCode": 1}}]),
        row("contender-run", error='{"stage":"occupied"}\n', rc=1),
        row("backup-client-finish", error="tenancy-host: ops result unconfirmed\n", rc=1),
        row("cleanup-inner-absent-center", rc=1),
        row("cleanup-inner-absent-contender", rc=1),
    ]
    created = [("network", "net"), ("volume", "data"), ("volume", "socket"),
               ("volume", "daemon"), ("container", "control"), ("container", "dind")]
    events = {"status": "observations_recorded", "center_name": "center",
              "contender_name": "contender", "created": created,
              "stop_after_31s": {"elapsed_seconds": 31.5, "command_pending": True,
                                 "monotonic_seconds": 50},
              "release": {"monotonic_seconds": 51},
              "cleanup": [{"kind": kind, "name": name, "remove_returncode": 0,
                           "inspect_absent": True} for kind, name in created]}
    return rows, events


def measure(rows, events):
    with tempfile.TemporaryDirectory(prefix="oracle-self-test-", dir=HERE) as temporary:
        run_dir = pathlib.Path(temporary)
        (run_dir / "commands.jsonl").write_text(
            "".join(json.dumps(row) + "\n" for row in rows))
        (run_dir / "events.json").write_text(json.dumps(events) + "\n")
        return verdict(run_dir)


def main():
    if OUTPUT.exists():
        raise RuntimeError("refusing to overwrite oracle self-test evidence")
    base_rows, base_events = sample()
    cases = []

    def check(name, mutate, rejected_check):
        rows = copy.deepcopy(base_rows)
        events = copy.deepcopy(base_events)
        mutate(rows, events)
        result = measure(rows, events)
        rejected = result["status"] != "pass" and result["checks"].get(rejected_check) is False
        cases.append({"name": name, "expected_rejected_check": rejected_check,
                      "observed_status": result["status"], "detected": rejected})
        if not rejected:
            raise AssertionError(f"oracle missed {name}: {result}")

    baseline = measure(base_rows, base_events)
    if baseline["status"] != "pass":
        raise AssertionError(f"synthetic good record rejected: {baseline}")

    def find(rows, label):
        return next(row for row in rows if row["label"] == label)

    def zero_mid_pid(rows, _):
        record = find(rows, "center-after-31s")
        snapshot = json.loads(record["stdout"])
        snapshot[0]["State"]["Pid"] = 0
        record["stdout"] = json.dumps(snapshot)

    check("app_bytes_changed", lambda rows, _: find(rows, "qa-inventory").update(
        {"stdout": json.dumps({**json.loads(find(rows, "qa-inventory")["stdout"]),
                               "manifestSha256": "changed"})}), "app_inventory_exact")
    check("stop_was_not_pending", lambda _, events: events["stop_after_31s"].update(
        {"command_pending": False}), "normal_stop_waited")
    check("center_pid_zero", zero_mid_pid, "normal_stop_waited")
    check("fd_inode_mismatch", lambda rows, _: find(rows, "fd-stat").update(
        {"stdout": "17:20:10001:10001:600\n"}), "actual_owned_output_handle")
    check("second_owner_started", lambda rows, _: find(rows, "contender-run").update(
        {"returncode": 0}), "second_real_owner_rejected")
    check("client_claimed_success", lambda rows, _: find(rows, "backup-client-finish").update(
        {"returncode": 0, "stdout": '{"status":"completed"}\n', "stderr": ""}),
        "client_unknown_not_success")
    check("resource_remained", lambda _, events: events["cleanup"][0].update(
        {"inspect_absent": False}), "owned_resources_removed")

    OUTPUT.write_text(json.dumps({"status": "pass", "kind": "synthetic-oracle-self-test",
                                  "generated_utc": datetime.now(timezone.utc).isoformat(),
                                  "baseline_status": baseline["status"], "cases": cases},
                                 indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": "pass", "rejected_cases": len(cases)}))


if __name__ == "__main__":
    main()
