#!/usr/bin/env python3
"""Map I1 packaged JS gates to the exact I1 source commit, without extraction."""

import hashlib
import json
import pathlib
import subprocess
import tarfile

HERE = pathlib.Path(__file__).resolve().parent
ARCHIVE = pathlib.Path("/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery/tmp/docker-delivery/host-i1-sourcefinal.tar.gz")
REPO = pathlib.Path("/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery")
COMMIT = "4e5fa7eb7240763631722ae98d9f4a1234b239a8"
TARGETS = {
    "online_backup": ("packages/tenancy/governance-center-entry/src/maintenance/online.ts",
                      "/governance-center-entry/dist/maintenance/online.js",
                      ["withTemporaryOutput(", "output.handle.writeFile(metadataBytes", "await this.#active?.catch"]),
    "temporary_output": ("packages/tenancy/governance-center-entry/src/maintenance/publication.ts",
                         "/governance-center-entry/dist/maintenance/publication.js",
                         ["const handle = await open(path, 'wx', 0o600)",
                          "ownResourceAt(session, () => handle.close()", "maintenance-residual"]),
    "host_disposal": ("apps/tenancy-host/src/boot.ts", "app/dist/boot.js",
                      ["async function disposeInReverse", "still-stopping", "await item.fiber.dispose()"]),
    "storage_run": ("packages/infra/storage-sql/src/maintenance/engine.ts",
                    "/storage-sql/dist/maintenance/engine.js",
                    ["#active", "await this.#active?.catch", "this.#released = true"]),
    "sqlite_owner": ("packages/infra/storage-sql/src/sqlite/lock.ts",
                     "/storage-sql/dist/sqlite/lock.js",
                     ["BEGIN IMMEDIATE", "SqliteLockBusy"]),
    "signal_entry": ("apps/tenancy-host/src/main.ts", "app/dist/main.js",
                     ["SIGTERM", "await host.dispose()", "abort.abort()"]),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    output = HERE / "intercepts.json"
    if output.exists():
        raise RuntimeError("refusing to overwrite compiled/source mapping")
    with tarfile.open(ARCHIVE, "r:gz") as archive:
        manifest = json.load(archive.extractfile("app/build-info.json"))
        indexed = {item["path"]: item for item in manifest["files"]}
        members = [member for member in archive.getmembers() if member.isfile()]
        result = {}
        for label, (source_path, suffix, needles) in TARGETS.items():
            match = [member for member in members if member.name.endswith(suffix)]
            if len(match) != 1:
                raise ValueError(f"{label}: expected one packaged JS member, got {len(match)}")
            member = match[0]
            compiled = archive.extractfile(member).read()
            rel = member.name.removeprefix("app/")
            if indexed[rel]["kind"] != "file" or indexed[rel]["sha256"] != sha(compiled):
                raise ValueError(f"{label}: compiled byte hash differs from I1 build-info")
            lines = compiled.decode().splitlines()
            located = {needle: [index + 1 for index, line in enumerate(lines) if needle in line]
                       for needle in needles}
            if any(not hits for hits in located.values()):
                raise ValueError(f"{label}: a planned gate/owner line is absent: {located}")
            command = ["git", "-C", str(REPO), "show", f"{COMMIT}:{source_path}"]
            source = subprocess.run(command, capture_output=True, check=False)
            if source.returncode != 0:
                raise ValueError(f"{label}: source unavailable at I1 commit")
            result[label] = {"source": source_path, "source_commit": COMMIT,
                             "source_sha256": sha(source.stdout), "packaged_js": rel,
                             "packaged_sha256": sha(compiled), "line_hits": located}
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({key: value["line_hits"] for key, value in result.items()}, sort_keys=True))


if __name__ == "__main__":
    main()
