#!/usr/bin/env python3
"""Read-only audit of the exact I1 host/image inputs for QA fixture planning."""

import hashlib
import json
import pathlib
import posixpath
import subprocess
import tarfile
from datetime import datetime, timezone

HERE = pathlib.Path(__file__).resolve().parent
HUB = pathlib.Path("/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish")
I1 = HUB / "tmp/next-iteration/docker-i1"
SOURCE_REPO = pathlib.Path("/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-delivery")
EXPECTED_MANIFEST_SHA = "73adb2e1f104192668fcb37e1cb09047c388af3c99a95e35505bb55615b57a62"
EXPECTED_BUILD_ID = "de6c4c19658e1f15a95614e3c6a9bde0ba13ff3673c41704f99494edcbf01a83"
EXPECTED_IMAGE_ID = "sha256:86668009808654ebbf30258b8b1637432919a3d50bbf078947ed616f01ccc803"


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def assert_equal(label, observed, expected, checks):
    checks[label] = {"observed": observed, "expected": expected, "pass": observed == expected}
    if observed != expected:
        raise ValueError(f"{label}: observed {observed!r} differs from expected {expected!r}")


def main():
    output = HERE / "inputs-audit.json"
    if output.exists():
        raise RuntimeError("refusing to overwrite I1 input audit")
    checks = {}
    evidence = {"started_utc": datetime.now(timezone.utc).isoformat(), "status": "running",
                "commands": [], "checks": checks}
    try:
        manifest_path = I1 / "I1-manifest.json"
        assert_equal("manifest_sha256", sha(manifest_path), EXPECTED_MANIFEST_SHA, checks)
        manifest = json.loads(manifest_path.read_text())
        assert_equal("manifest_format", manifest["format"], "omne-tenancy-docker-i1-evidence/1", checks)
        assert_equal("source_commit", manifest["source"]["commit"],
                     "4e5fa7eb7240763631722ae98d9f4a1234b239a8", checks)
        assert_equal("host_build_id", manifest["host"]["buildId"], EXPECTED_BUILD_ID, checks)
        assert_equal("image_build_id", manifest["image"]["buildId"], EXPECTED_BUILD_ID, checks)
        assert_equal("image_id", manifest["image"]["imageId"], EXPECTED_IMAGE_ID, checks)

        host_path = pathlib.Path(manifest["host"]["path"])
        image_path = I1 / "tenancy-i1-sourcefinal-arm64.tar"
        assert_equal("host_archive_sha256", sha(host_path), manifest["host"]["sha256"], checks)
        assert_equal("image_archive_sha256", sha(image_path), manifest["image"]["sha256"], checks)
        evidence["archive_paths"] = {"host": str(host_path), "image": str(image_path)}

        source_hashes = {}
        for path, expected in manifest["source"]["files"].items():
            command = ["git", "-C", str(SOURCE_REPO), "show", f"{manifest['source']['commit']}:{path}"]
            result = subprocess.run(command, capture_output=True, check=False)
            evidence["commands"].append({"argv": command, "returncode": result.returncode,
                                         "stderr": result.stderr.decode("utf-8", "replace")})
            if result.returncode != 0:
                raise RuntimeError(f"source file unavailable at I1 commit: {path}")
            observed = hashlib.sha256(result.stdout).hexdigest()
            assert_equal(f"source:{path}", observed, expected, checks)
            source_hashes[path] = observed
        evidence["source_file_count"] = len(source_hashes)

        with tarfile.open(host_path, "r:gz") as archive:
            build_id = archive.extractfile("app/BUILD_ID").read().decode().strip()
            packaged = json.load(archive.extractfile("app/build-info.json"))
            assert_equal("packaged_BUILD_ID", build_id, EXPECTED_BUILD_ID, checks)
            assert_equal("packaged_build_info_id", packaged["buildId"], EXPECTED_BUILD_ID, checks)
            assert_equal("packaged_manifest_format", packaged["format"], manifest["host"]["manifestFormat"], checks)
            assert_equal("packaged_manifest_node", packaged["node"], manifest["host"]["manifestNode"], checks)
            assert_equal("packaged_manifest_pnpm", packaged["pnpm"], manifest["host"]["manifestPnpm"], checks)
            assert_equal("packaged_file_count", len(packaged["files"]), manifest["host"]["fileCount"], checks)
            listed = {}
            file_count = 0
            link_count = 0
            for item in packaged["files"]:
                rel = item["path"]
                if rel.startswith("/") or posixpath.normpath(rel).startswith("../") or rel in listed:
                    raise ValueError(f"unsafe or duplicate packaged path: {rel}")
                member = archive.getmember("app/" + rel)
                if item["kind"] == "file" and member.isfile():
                    observed = hashlib.sha256(archive.extractfile(member).read()).hexdigest()
                    if observed != item["sha256"]:
                        raise ValueError(f"packaged file digest mismatch: {rel}")
                    file_count += 1
                elif item["kind"] == "link" and member.issym():
                    if member.linkname != item["target"]:
                        raise ValueError(f"packaged link target mismatch: {rel}")
                    target = posixpath.normpath(posixpath.join(posixpath.dirname(rel), member.linkname))
                    if target.startswith("../") or target == ".." or target.startswith("/"):
                        raise ValueError(f"packaged link escapes app: {rel}")
                    link_count += 1
                else:
                    raise ValueError(f"packaged entry kind mismatch: {rel}")
                listed[rel] = True
            actual = {member.name.removeprefix("app/") for member in archive.getmembers()
                      if member.name.startswith("app/") and (member.isfile() or member.issym())
                      and member.name not in ("app/BUILD_ID", "app/build-info.json")}
            if actual != set(listed):
                raise ValueError(f"packaged inventory path set mismatch: missing {len(set(listed)-actual)}, extra {len(actual-set(listed))}")
            assert_equal("packaged_link_count", link_count, manifest["host"]["linkCount"], checks)
            evidence["packaged_inventory"] = {"files": file_count, "links": link_count,
                                               "build_info_sha256": hashlib.sha256(
                                                   archive.extractfile("app/build-info.json").read()).hexdigest()}

        with tarfile.open(image_path, "r:") as archive:
            saved = json.load(archive.extractfile("manifest.json"))[0]
            config_path = saved["Config"]
            config_bytes = archive.extractfile(config_path).read()
            config_hash = "sha256:" + hashlib.sha256(config_bytes).hexdigest()
            config = json.loads(config_bytes)
            assert_equal("image_tar_config_id", config_hash, EXPECTED_IMAGE_ID, checks)
            assert_equal("image_tar_os", config["os"], "linux", checks)
            assert_equal("image_tar_arch", config["architecture"], "arm64", checks)
            assert_equal("image_tar_labels", config["config"]["Labels"], manifest["image"]["labels"], checks)
            evidence["image_tar"] = {"config_path": config_path, "repo_tags": saved.get("RepoTags"),
                                     "rootfs_layers": config["rootfs"].get("diff_ids")}

        command = ["docker", "image", "inspect", EXPECTED_IMAGE_ID]
        result = subprocess.run(command, capture_output=True, check=False)
        evidence["commands"].append({"argv": command, "returncode": result.returncode,
                                     "stderr": result.stderr.decode("utf-8", "replace")})
        if result.returncode != 0:
            raise RuntimeError("retained I1 image ID unavailable in Docker cache")
        local = json.loads(result.stdout)[0]
        assert_equal("cached_image_id", local["Id"], EXPECTED_IMAGE_ID, checks)
        assert_equal("cached_image_os_arch", (local["Os"], local["Architecture"]), ("linux", "arm64"), checks)
        evidence["status"] = "pass"
    except BaseException as error:
        evidence["status"] = "fail"
        evidence["error"] = f"{type(error).__name__}: {error}"
    evidence["finished_utc"] = datetime.now(timezone.utc).isoformat()
    output.write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": evidence["status"], "error": evidence.get("error"),
                      "source_file_count": evidence.get("source_file_count"),
                      "packaged_inventory": evidence.get("packaged_inventory"),
                      "checks": len(checks)}, sort_keys=True))
    return 0 if evidence["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
