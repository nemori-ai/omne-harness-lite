#!/usr/bin/env python3
"""Independent, read-only oracle for one future fixed-QA close-fail pilot."""

import json
import pathlib
import re
import sys

EXPECTED_BUILD_ID = "de6c4c19658e1f15a95614e3c6a9bde0ba13ff3673c41704f99494edcbf01a83"
EXPECTED_GATE_SHA = "3a41976d06cfcd1b14e68cef3d2dedf96fc248d9efba3d619550392218927fc8"
OUTPUT = re.compile(r"^/state/backups/\.quarantine/export-[0-9a-f]{32}$")


def verdict(run_dir):
    rows = [json.loads(line) for line in (run_dir / "commands.jsonl").read_text().splitlines()]
    labels = {}
    for row in rows:
        labels.setdefault(row["label"], []).append(row)
    events = json.loads((run_dir / "events.json").read_text())
    checks = {}

    def one(label):
        found = labels.get(label, [])
        if len(found) != 1:
            raise ValueError(f"expected exactly one raw command {label}, found {len(found)}")
        return found[0]

    def parsed(label):
        row = one(label)
        if row.get("returncode") != 0 or row.get("timed_out"):
            raise ValueError(f"{label} command did not succeed")
        return json.loads(row["stdout"])

    def json_lines(text):
        values = []
        for line in text.splitlines():
            try:
                values.append(json.loads(line))
            except ValueError:
                pass
        return values

    try:
        original = parsed("original-inventory")
        qa = parsed("qa-inventory")
        checks["app_inventory_exact"] = (original == qa and original.get("status") == "verified" and
                                         original.get("buildId") == EXPECTED_BUILD_ID and
                                         original.get("files") == 2841 and original.get("links") == 115)
        original_image = parsed("inner-original-inspect")[0]
        qa_image = parsed("qa-image-inspect")[0]
        checks["qa_image_boundary"] = (
            original_image["Id"] != qa_image["Id"] and
            original_image["Config"]["Entrypoint"] == qa_image["Config"]["Entrypoint"] and
            "NODE_OPTIONS=--import=/probe/gate.mjs" not in original_image["Config"]["Env"] and
            "NODE_OPTIONS=--import=/probe/gate.mjs" in qa_image["Config"]["Env"] and
            qa_image["Config"]["Labels"].get("ai.nemori.omne.qa-fixture") == "maintenance-gate/1")
        gate_probe = parsed("qa-gate-availability")
        gate_directory = gate_probe.get("directory")
        gate_file = gate_probe.get("file")
        checks["qa_gate_readable_by_target_uid"] = (
            gate_probe.get("status") == "pass" and gate_probe.get("uid") == 10001 and
            gate_probe.get("gid") == 10001 and
            gate_probe.get("actualSha256") == EXPECTED_GATE_SHA and
            isinstance(gate_directory, dict) and gate_directory.get("mode") == "755" and
            isinstance(gate_file, dict) and gate_file.get("isFile") is True)

        before = parsed("center-before-stop")[0]
        mid = parsed("center-after-31s")[0]
        after = parsed("center-final")[0]
        checks["exact_center_identity"] = (
            before["Id"] == mid["Id"] == after["Id"] and
            before["Image"] == mid["Image"] == after["Image"] == qa_image["Id"])
        checks["normal_stop_waited"] = (
            before["State"]["Running"] is True and mid["State"]["Running"] is True and
            mid["State"]["Pid"] > 0 and
            mid["State"]["Pid"] == before["State"]["Pid"] and
            mid["State"]["StartedAt"] == before["State"]["StartedAt"] and
            events["stop_after_31s"]["elapsed_seconds"] > 31 and
            events["stop_after_31s"]["command_pending"] is True and
            one("stop-normal-finish")["returncode"] == 0 and
            one("stop-normal-finish").get("timed_out") is False)
        checks["center_exited_error_not_clean"] = (
            after["State"]["Status"] == "exited" and
            after["State"]["ExitCode"] == 1 and
            after["State"]["Running"] is False)
        checks["diagnostic_not_timeout"] = any(
            item.get("event") == "still-stopping" for item in
            json_lines(one("center-logs")["stderr"]) if isinstance(item, dict))

        ready = parsed("gate-ready")
        held = parsed("gate-held")
        fd_target = one("fd-readlink")
        fd_stat = one("fd-stat")
        descriptor = f"/proc/1/fd/{held['fd']}"
        stat_parts = fd_stat["stdout"].strip().split(":")
        checks["actual_owned_close_handle"] = (
            ready.get("stage") == "ready" and ready.get("mode") == "close-fail" and
            held.get("stage") == "close" and held.get("pid") == 1 and
            isinstance(held.get("fd"), int) and held["fd"] >= 0 and
            isinstance(held.get("path"), str) and OUTPUT.fullmatch(held["path"]) is not None and
            fd_target.get("returncode") == 0 and fd_target["argv"][-1] == descriptor and
            fd_target["stdout"].strip() == held["path"] and
            fd_stat.get("returncode") == 0 and fd_stat["argv"][-1] == descriptor and
            len(stat_parts) == 5 and
            int(stat_parts[0]) == held["dev"] and int(stat_parts[1]) == held["ino"] and
            stat_parts[2:4] == ["10001", "10001"] and stat_parts[4] == "600")
        held_later = one("fd-readlink-after-31s")
        held_later_stat = one("fd-stat-after-31s")
        later_parts = held_later_stat["stdout"].strip().split(":")
        checks["same_fd_still_owned_after_31s"] = (
            held_later.get("returncode") == 0 and
            held_later["argv"][-1] == descriptor and
            held_later["stdout"].strip() == held["path"] and
            held_later_stat.get("returncode") == 0 and
            held_later_stat["argv"][-1] == descriptor and len(later_parts) == 5 and
            int(later_parts[0]) == held["dev"] and int(later_parts[1]) == held["ino"] and
            later_parts[2:4] == ["10001", "10001"] and later_parts[4] == "600")
        residual = one("residual-stat")
        residual_parts = residual["stdout"].strip().split(":")
        checks["isolated_residual_retained"] = (
            residual.get("returncode") == 0 and not residual.get("timed_out") and
            residual["argv"][-1] == "/var/lib/omne-tenancy/state" + held["path"][len("/state"):] and
            len(residual_parts) == 5 and
            int(residual_parts[0]) == held["dev"] and
            int(residual_parts[1]) == held["ino"] and
            residual_parts[2:4] == ["10001", "10001"] and residual_parts[4] == "600")
        checks["release_was_later"] = (events["release"]["monotonic_seconds"] >
                                       events["stop_after_31s"]["monotonic_seconds"] and
                                       one("gate-release-present")["returncode"] == 0)

        contender = parsed("contender-final")[0]
        contender_run = one("contender-run")
        center_state_mount = next((item.get("Source") for item in before.get("Mounts", [])
                                   if item.get("Destination") == "/state"), None)
        contender_state_mount = next((item.get("Source") for item in contender.get("Mounts", [])
                                      if item.get("Destination") == "/state"), None)
        checks["second_real_owner_rejected"] = (
            contender["Image"] == original_image["Id"] and
            center_state_mount == contender_state_mount == "/var/lib/omne-tenancy/state" and
            contender["State"]["Status"] == "exited" and contender["State"]["ExitCode"] == 1 and
            contender_run["returncode"] == 1 and any(
                item.get("stage") == "occupied" for item in
                json_lines(contender_run["stderr"]) if isinstance(item, dict)))
        client = one("backup-client-finish")
        client_results = json_lines(client["stdout"])
        checks["client_not_success"] = (client["returncode"] == 1 and
            client.get("timed_out") is False and
            ((client["stdout"] == "" and "ops result unconfirmed" in client["stderr"]) or
             (len(client_results) == 1 and isinstance(client_results[0], dict) and
              client_results[0].get("status") in ("unavailable", "outcome-unknown"))))
        final_logs = one("center-logs-final")
        final_lines = [item for item in json_lines(final_logs["stderr"])
                       if isinstance(item, dict)]
        checks["close_failure_reported_not_clean"] = (
            final_logs["returncode"] == 0 and
            "maintenance-residual" in final_logs["stderr"] and
            held["path"] in final_logs["stderr"] and
            any(item.get("event") == "dispose-incomplete" and
                item.get("controller") == "error" and
                "governance-center-ops" in item.get("unfinished", []) for item in final_lines) and
            any(item.get("event") == "disposed" and item.get("complete") is False
                for item in final_lines) and
            not any(item.get("event") == "disposed" and item.get("complete") is True
                    for item in final_lines))
        cleanup = events["cleanup"]
        expected_owned = {(kind, name) for kind, name in events["created"]}
        observed_owned = [(item.get("kind"), item.get("name")) for item in cleanup]
        checks["owned_resources_removed"] = (
            len(expected_owned) == 6 and len(observed_owned) == 6 and
            set(observed_owned) == expected_owned and all(
                item.get("remove_returncode") == 0 and item.get("inspect_absent") is True
                for item in cleanup) and
            all(one("cleanup-inner-absent-" + name)["returncode"] not in (0, None)
                for name in (events["center_name"], events["contender_name"])))
    except (KeyError, TypeError, ValueError, IndexError, AttributeError) as error:
        return {"status": "unverified", "error": f"{type(error).__name__}: {error}",
                "checks": checks}
    return {"status": "pass" if all(checks.values()) else "fail", "checks": checks}


def main():
    if len(sys.argv) != 2:
        print("usage: oracle.py <run-directory>", file=sys.stderr)
        return 64
    run_dir = pathlib.Path(sys.argv[1])
    result = verdict(run_dir)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["status"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
