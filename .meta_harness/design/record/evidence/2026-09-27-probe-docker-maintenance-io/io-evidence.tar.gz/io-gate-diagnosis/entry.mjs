process.stdout.write(JSON.stringify({ stage: 'entry', argv: process.argv }) + '\n')
