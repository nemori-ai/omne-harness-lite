#!/usr/bin/env python3
"""Synthetic orchestration checks: fixed image is built only for the exact eligible branch."""

import importlib.util
import json
import pathlib
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("conditional_flow", ROOT / "pilot_conditional_dir.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def scenario(case):
    original_here = module.HERE
    with tempfile.TemporaryDirectory(prefix="conditional-flow-", dir=ROOT) as temporary:
        module.HERE = pathlib.Path(temporary)
        try:
            pilot = module.Pilot()
            pilot.original_tag = "original"
            pilot.qa_tag = "qa-original"
            pilot.qa_original_tag = "qa-original"
            pilot.qa_fixed_tag = "qa-fixed"
            pilot.events["outer_original_image"] = {"os": "linux", "architecture": "arm64",
                                                     "rootfs_layers": ["layer"]}
            pilot.context_tar = lambda: pathlib.Path(temporary) / "unused-original.tar"
            pilot.fixed_context_tar = lambda: pathlib.Path(temporary) / "unused-fixed.tar"
            labels = []
            expected = module.digest(ROOT.parent / "io-gate-prep/qa-image/gate.mjs")
            directory = {"isDirectory": True, "uid": 0, "gid": 0,
                         "mode": "755" if case == "other_failure" else "444"}
            target_bad = {"status": "fail", "uid": 10001, "gid": 10001,
                          "errorCode": "EACCES", "directory": directory}
            root_good = {"status": "pass", "uid": 0, "gid": 0,
                         "directory": directory, "file": {"isFile": True},
                         "actualSha256": expected}
            target_good = {"status": "pass", "uid": 10001, "gid": 10001,
                           "directory": {"isDirectory": True}, "file": {"isFile": True},
                           "actualSha256": expected}
            image_config = {"Entrypoint": ["node"], "Cmd": ["serve"],
                            "User": "10001:10001", "Env": ["NODE_OPTIONS=--import=/probe/gate.mjs"]}

            def inner(label, *_args, **_kwargs):
                labels.append(label)
                value = ""
                rc = 0
                if label == "inner-original-inspect":
                    value = json.dumps([{"Id": "original-id", "Os": "linux", "Architecture": "arm64",
                                         "RootFS": {"Layers": ["layer"]}, "Config": {
                                             "Labels": {"ai.nemori.omne.host-build-id":
                                                        "de6c4c19658e1f15a95614e3c6a9bde0ba13ff3673c41704f99494edcbf01a83"}}}])
                elif label == "qa-image-inspect":
                    value = json.dumps([{"Id": "qa-id", "Config": image_config}])
                elif label == "qa-fixed-image-inspect":
                    value = json.dumps([{"Id": "qa-fixed-id", "Config": image_config}])
                elif label.endswith("-inventory"):
                    value = json.dumps({"status": "verified", "buildId": "same"})
                elif label == "qa-original-gate-target":
                    if case == "original_pass":
                        value = json.dumps(target_good)
                    else:
                        value, rc = json.dumps(target_bad), 1
                elif label == "qa-original-gate-root-view":
                    value = json.dumps(root_good)
                elif label == "qa-fixed-gate-target":
                    value = json.dumps(target_good)
                return {"stdout": value, "stderr": "", "returncode": rc, "timed_out": False}

            pilot.inner = inner
            failed = False
            try:
                pilot.images()
            except RuntimeError:
                failed = True
            if case == "eligible":
                assert not failed and pilot.events["selected_qa"] == "fixed-explicit-probe-dir"
                assert pilot.qa_tag == "qa-fixed" and pilot.events["images"]["qa_fixed_id"] == "qa-fixed-id"
                assert "build-qa-fixed-image" in labels and "qa-fixed-inventory" in labels
            elif case == "other_failure":
                assert failed and "build-qa-fixed-image" not in labels
            else:
                assert not failed and pilot.events["selected_qa"] == "original"
                assert "qa-original-gate-root-view" not in labels and "build-qa-fixed-image" not in labels
            return {"case": case, "passed": True, "fixed_build_called": "build-qa-fixed-image" in labels,
                    "commands": len(labels)}
        finally:
            module.HERE = original_here


def main():
    results = [scenario(case) for case in ("eligible", "other_failure", "original_pass")]
    output = {"status": "pass", "docker_used": False, "cases": results}
    path = ROOT / "conditional-flow-self-test.json"
    if path.exists():
        raise RuntimeError("refusing to overwrite flow self-test evidence")
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps(output, sort_keys=True))


if __name__ == "__main__":
    main()
