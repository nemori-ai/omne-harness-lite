#!/usr/bin/env python3
"""Pure oracle checks for the proposed QA gate availability preflight."""

import importlib.util
import json
import pathlib
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("gate_check_candidate", ROOT / "pilot_with_gate_check.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def main():
    expected = module.digest(ROOT.parent / "io-gate-prep/qa-image/gate.mjs")
    valid = {"status": "pass", "uid": 10001, "gid": 10001, "actualSha256": expected,
             "directory": {"isDirectory": True, "mode": "755"},
             "file": {"isFile": True, "mode": "444"}}
    cases = []
    original_here = module.HERE
    try:
        with tempfile.TemporaryDirectory(prefix="gate-check-self-test-", dir=ROOT) as temporary:
            module.HERE = pathlib.Path(temporary)
            for name, result, should_pass in (
                ("valid_readable_gate", {"returncode": 0, "timed_out": False,
                                         "stdout": json.dumps(valid)}, True),
                ("directory_nontraversable", {"returncode": 1, "timed_out": False,
                                               "stdout": json.dumps({"status": "fail", "uid": 10001,
                                                                     "gid": 10001,
                                                                     "directory": {"mode": "444"},
                                                                     "errorCode": "EACCES"})}, False),
                ("wrong_gate_hash", {"returncode": 0, "timed_out": False,
                                     "stdout": json.dumps({**valid, "actualSha256": "0" * 64})}, False),
                ("malformed_result", {"returncode": 0, "timed_out": False,
                                      "stdout": "not json"}, False),
            ):
                pilot = module.Pilot()
                captured = []

                def fake_inner(label, *args, **kwargs):
                    captured.append({"label": label, "args": args, "kwargs": kwargs})
                    return result

                pilot.inner = fake_inner
                try:
                    pilot.verify_gate_availability()
                    passed = True
                except RuntimeError:
                    passed = False
                assert passed == should_pass, name
                assert len(captured) == 1 and captured[0]["label"] == "qa-gate-availability"
                args = captured[0]["args"]
                assert "--user" in args and "10001:10001" in args and "NODE_OPTIONS=" in args
                assert captured[0]["kwargs"]["stdin_path"] == ROOT / "gate_availability.mjs"
                cases.append({"name": name, "expected_pass": should_pass,
                              "observed_pass": passed})
    finally:
        module.HERE = original_here
    output = {"status": "pass", "docker_used": False, "cases": cases}
    path = ROOT / "gate-check-self-test.json"
    if path.exists():
        raise RuntimeError("refusing to overwrite gate-check self-test evidence")
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps(output, sort_keys=True))


if __name__ == "__main__":
    main()
