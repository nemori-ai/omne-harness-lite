#!/usr/bin/env python3
"""Synthetic negative controls for the close-fail oracle; no Docker run."""

import copy
import importlib.util
import json
import pathlib
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
PREP = ROOT.parent / "io-gate-prep"
sys.path.insert(0, str(PREP))
from oracle_self_test import sample  # noqa: E402

spec = importlib.util.spec_from_file_location("close_fail_oracle_candidate", ROOT / "close_fail_oracle.py")
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)


def fixture():
    rows, events = sample()
    by = {row["label"]: row for row in rows}
    by["gate-ready"]["stdout"] = json.dumps({"stage": "ready", "mode": "close-fail", "pid": 1})
    held = json.loads(by["gate-held"]["stdout"])
    held["stage"] = "close"
    by["gate-held"]["stdout"] = json.dumps(held)
    descriptor = f"/proc/1/fd/{held['fd']}"
    for label in ("fd-readlink", "fd-stat"):
        by[label]["argv"] = ["docker", "exec", "center", descriptor]
    for label in ("center-before-stop", "center-after-31s"):
        value = json.loads(by[label]["stdout"])
        value[0]["State"]["StartedAt"] = "same-start"
        value[0]["Mounts"] = [{"Destination": "/state",
                               "Source": "/var/lib/omne-tenancy/state"}]
        by[label]["stdout"] = json.dumps(value)
    final = json.loads(by["center-final"]["stdout"])
    final[0]["State"]["ExitCode"] = 1
    by["center-final"]["stdout"] = json.dumps(final)
    contender = json.loads(by["contender-final"]["stdout"])
    contender[0]["Mounts"] = [{"Destination": "/state",
                               "Source": "/var/lib/omne-tenancy/state"}]
    by["contender-final"]["stdout"] = json.dumps(contender)
    rows += [
        {"label": "qa-gate-availability", "stdout": json.dumps({
            "status": "pass", "uid": 10001, "gid": 10001,
            "actualSha256": oracle.EXPECTED_GATE_SHA,
            "directory": {"mode": "755"}, "file": {"isFile": True}}),
         "stderr": "", "returncode": 0, "timed_out": False},
        {"label": "fd-readlink-after-31s", "stdout": held["path"] + "\n",
         "stderr": "", "returncode": 0, "timed_out": False,
         "argv": ["docker", "exec", "center", descriptor]},
        {"label": "fd-stat-after-31s", "stdout": "17:19:10001:10001:600\n",
         "stderr": "", "returncode": 0, "timed_out": False,
         "argv": ["docker", "exec", "center", descriptor]},
        {"label": "residual-stat", "stdout": "17:19:10001:10001:600\n",
         "stderr": "", "returncode": 0, "timed_out": False,
         "argv": ["docker", "exec", "control", "stat",
                  "/var/lib/omne-tenancy/state" + held["path"][len("/state"):] ]},
        {"label": "center-logs-final", "stdout": "",
         "stderr": '\n'.join((
             json.dumps({"message": "maintenance-residual: " + held["path"]}),
             json.dumps({"event": "dispose-incomplete", "controller": "error",
                         "unfinished": ["governance-center-ops"]}),
             json.dumps({"event": "disposed", "complete": False}),
         )) + "\n", "returncode": 0, "timed_out": False},
    ]
    return rows, events


def measure(rows, events):
    with tempfile.TemporaryDirectory(prefix="close-oracle-self-test-", dir=ROOT) as temporary:
        directory = pathlib.Path(temporary)
        (directory / "commands.jsonl").write_text("".join(json.dumps(row) + "\n" for row in rows))
        (directory / "events.json").write_text(json.dumps(events) + "\n")
        return oracle.verdict(directory)


def main():
    base_rows, base_events = fixture()
    baseline = measure(base_rows, base_events)
    assert baseline["status"] == "pass", baseline
    cases = []

    def row(rows, label):
        return next(item for item in rows if item["label"] == label)

    def check(name, mutate, expected_check):
        rows, events = copy.deepcopy(base_rows), copy.deepcopy(base_events)
        mutate(rows, events)
        result = measure(rows, events)
        detected = result["status"] != "pass" and result["checks"].get(expected_check) is False
        assert detected, (name, result)
        cases.append({"name": name, "expected_check": expected_check, "detected": detected})

    def change_final_exit(rows, _):
        item = row(rows, "center-final")
        snapshot = json.loads(item["stdout"])
        snapshot[0]["State"]["ExitCode"] = 0
        item["stdout"] = json.dumps(snapshot)

    check("false_clean_exit", change_final_exit, "center_exited_error_not_clean")
    check("residual_inode_changed", lambda rows, _: row(rows, "residual-stat").update(
        {"stdout": "17:20:10001:10001:600\n"}), "isolated_residual_retained")
    check("fd_released_early", lambda rows, _: row(rows, "fd-stat-after-31s").update(
        {"returncode": 1}), "same_fd_still_owned_after_31s")
    check("clean_disposal_claim", lambda rows, _: row(rows, "center-logs-final").update(
        {"stderr": '{"event":"disposed","complete":true}\n'}),
        "close_failure_reported_not_clean")
    check("client_success_claim", lambda rows, _: row(rows, "backup-client-finish").update(
        {"returncode": 0, "stdout": '{"status":"completed"}\n', "stderr": ""}),
        "client_not_success")
    check("second_owner_started", lambda rows, _: row(rows, "contender-run").update(
        {"returncode": 0}), "second_real_owner_rejected")
    check("stop_not_waiting", lambda _, events: events["stop_after_31s"].update(
        {"command_pending": False}), "normal_stop_waited")

    output = {"status": "pass", "kind": "synthetic-close-fail-oracle-check/1",
              "docker_used": False, "baseline_status": baseline["status"], "cases": cases}
    path = ROOT / "close-fail-oracle-self-test-v2.json"
    if path.exists():
        raise RuntimeError("refusing to overwrite close-fail oracle self-test")
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": "pass", "rejected_cases": len(cases)}))


if __name__ == "__main__":
    main()
