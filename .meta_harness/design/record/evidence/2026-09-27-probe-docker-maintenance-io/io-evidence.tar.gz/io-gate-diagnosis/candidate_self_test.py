#!/usr/bin/env python3
"""Pure checks of diagnostic collection and startup failure ordering; no Docker calls."""

import importlib.util
import json
import pathlib
import sys
import tempfile
from types import SimpleNamespace

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
MODULE_PATH = ROOT / "pilot_with_diagnostics.py"
spec = importlib.util.spec_from_file_location("io_gate_diagnostic_candidate", MODULE_PATH)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_snapshot():
    with tempfile.TemporaryDirectory(prefix="candidate-self-test-", dir=ROOT) as temporary:
        original_here = module.HERE
        module.HERE = pathlib.Path(temporary)
        try:
            pilot = module.Pilot()
            calls = []

            def inner(label, *args, **_):
                calls.append([label, *args])
                # An exited center makes top/exec fail; inspect and logs must still run.
                return {"returncode": 1 if label.endswith(("-top", "-center-process")) else 0,
                        "timed_out": False}

            def call(label, argv, **_):
                calls.append([label, *argv])
                return {"returncode": 0, "timed_out": False}

            pilot.inner = inner
            pilot.call = call
            pilot.diagnostic_logs = lambda stage: {"returncode": 0, "timed_out": False}
            pilot.capture_startup_snapshot("synthetic")
            expected = {"state", "mounts", "entrypoint", "top", "center-process",
                        "control-state", "dind-state"}
            observed = {entry[0].removeprefix("diagnostic-synthetic-") for entry in calls}
            serialized = json.dumps(calls)
            assert expected == observed, (expected, observed)
            assert "Config.Env" not in serialized and "cat /secrets" not in serialized
            snapshots = pilot.events["diagnostic_snapshots"]
            assert len(snapshots) == 1 and snapshots[0]["stage"] == "synthetic"
            failed = {item["name"] for item in snapshots[0]["commands"]
                      if item.get("returncode") == 1}
            assert failed == {"top", "center-process"}, failed
            return len(calls)
        finally:
            module.HERE = original_here


def test_failure_capture():
    with tempfile.TemporaryDirectory(prefix="candidate-self-test-", dir=ROOT) as temporary:
        original_here = module.HERE
        module.HERE = pathlib.Path(temporary)
        try:
            pilot = module.Pilot()
            stages = []
            pilot.control_docker = lambda *_args, **_kwargs: {"returncode": 0}
            pilot.capture_startup_snapshot = lambda stage: stages.append(stage)

            def fail_ready(*_args, **_kwargs):
                raise RuntimeError("synthetic ready failure")

            pilot.await_file = fail_ready
            try:
                pilot.start_center()
            except RuntimeError as error:
                assert str(error) == "synthetic ready failure"
            else:
                raise AssertionError("startup error was swallowed")
            assert stages == ["after-create", "before-startup-exit"], stages
            return stages
        finally:
            module.HERE = original_here


def test_log_redaction():
    with tempfile.TemporaryDirectory(prefix="candidate-self-test-", dir=ROOT) as temporary:
        original_here = module.HERE
        original_run = module.subprocess.run
        module.HERE = pathlib.Path(temporary)
        try:
            pilot = module.Pilot()
            module.subprocess.run = lambda *_args, **_kwargs: SimpleNamespace(
                returncode=1,
                stdout=b"event=start\n-----BEGIN PRIVATE KEY-----\nDUMMYSECRET\n-----END PRIVATE KEY-----\n",
                stderr=b"TOKEN=SECRETSTRING\nError: boot failed\n",
            )
            result = pilot.diagnostic_logs("synthetic")
            encoded = json.dumps(result)
            assert "DUMMYSECRET" not in encoded and "SECRETSTRING" not in encoded
            assert "Error: boot failed" in encoded and "[redacted" in encoded
            return result["label"]
        finally:
            module.subprocess.run = original_run
            module.HERE = original_here


def main():
    collected = test_snapshot()
    stages = test_failure_capture()
    redacted = test_log_redaction()
    output = {"status": "pass", "docker_used": False, "snapshot_commands": collected,
              "failure_snapshot_stages": stages, "redacted_log_label": redacted}
    path = ROOT / "candidate-self-test-v4.json"
    if path.exists():
        raise RuntimeError("refusing to overwrite candidate self-test evidence")
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps(output, sort_keys=True))


if __name__ == "__main__":
    main()
