// Run in a disposable QA-image container as UID 10001 with NODE_OPTIONS cleared.
// Report only identity and permission metadata; never print gate or secret bytes.
import { createHash } from 'node:crypto'
import { lstat, readFile, stat } from 'node:fs/promises'

const expected = '3a41976d06cfcd1b14e68cef3d2dedf96fc248d9efba3d619550392218927fc8'
const result = { uid: process.getuid(), gid: process.getgid(), expectedSha256: expected }

try {
  const directory = await stat('/probe')
  result.directory = {
    isDirectory: directory.isDirectory(),
    uid: directory.uid,
    gid: directory.gid,
    mode: (directory.mode & 0o777).toString(8),
  }
  if (!directory.isDirectory()) throw new Error('/probe is not a directory')

  const file = await lstat('/probe/gate.mjs')
  result.file = {
    isFile: file.isFile(),
    uid: file.uid,
    gid: file.gid,
    mode: (file.mode & 0o777).toString(8),
  }
  if (!file.isFile()) throw new Error('/probe/gate.mjs is not a regular file')

  const bytes = await readFile('/probe/gate.mjs')
  result.actualSha256 = createHash('sha256').update(bytes).digest('hex')
  if (result.uid !== 10001 || result.gid !== 10001 || result.actualSha256 !== expected)
    throw new Error('QA gate identity or hash mismatch')
  result.status = 'pass'
} catch (error) {
  result.status = 'fail'
  result.errorName = error?.name ?? 'unknown'
  result.errorCode = error?.code ?? null
  result.errorMessage = error?.message ?? String(error)
  process.exitCode = 1
}

process.stdout.write(JSON.stringify(result) + '\n')
