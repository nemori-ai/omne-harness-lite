// Disposable root-view QA-image inspection; reports metadata and hash, never contents.
import { createHash } from 'node:crypto'
import { lstat, readFile, stat } from 'node:fs/promises'

const expected = '3a41976d06cfcd1b14e68cef3d2dedf96fc248d9efba3d619550392218927fc8'
const result = { uid: process.getuid(), gid: process.getgid(), expectedSha256: expected }

try {
  const directory = await stat('/probe')
  result.directory = {
    isDirectory: directory.isDirectory(),
    uid: directory.uid,
    gid: directory.gid,
    mode: (directory.mode & 0o777).toString(8),
  }
  if (!directory.isDirectory()) throw new Error('/probe is not a directory')

  const file = await lstat('/probe/gate.mjs')
  result.file = {
    isFile: file.isFile(),
    uid: file.uid,
    gid: file.gid,
    mode: (file.mode & 0o777).toString(8),
  }
  if (!file.isFile()) throw new Error('/probe/gate.mjs is not a regular file')

  result.actualSha256 = createHash('sha256').update(await readFile('/probe/gate.mjs')).digest('hex')
  if (result.uid !== 0 || result.actualSha256 !== expected)
    throw new Error('root-view identity or gate hash mismatch')
  result.status = 'pass'
} catch (error) {
  result.status = 'fail'
  result.errorName = error?.name ?? 'unknown'
  result.errorCode = error?.code ?? null
  result.errorMessage = error?.message ?? String(error)
  process.exitCode = 1
}

process.stdout.write(JSON.stringify(result) + '\n')
