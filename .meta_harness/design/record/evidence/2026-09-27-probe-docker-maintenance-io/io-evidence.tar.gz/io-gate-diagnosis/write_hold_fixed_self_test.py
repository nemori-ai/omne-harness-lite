#!/usr/bin/env python3
"""Pure checks for fixed-QA image gate and preservation of the reviewed IO oracle path."""

import ast
import importlib.util
import json
import pathlib
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
PREP = ROOT.parent / "io-gate-prep"
spec = importlib.util.spec_from_file_location("fixed_write_hold", ROOT / "pilot_write_hold_fixed.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def method(tree, name):
    return next(item for klass in tree.body if isinstance(klass, ast.ClassDef)
                for item in klass.body if isinstance(item, ast.FunctionDef) and item.name == name)


def image_case(case):
    original_here = module.HERE
    with tempfile.TemporaryDirectory(prefix="write-hold-fixed-self-test-", dir=ROOT) as temporary:
        module.HERE = pathlib.Path(temporary)
        try:
            pilot = module.Pilot()
            pilot.original_tag = "original"
            pilot.events["outer_original_image"] = {"os": "linux", "architecture": "arm64",
                                                     "rootfs_layers": ["same"]}
            pilot.context_tar = lambda: pathlib.Path(temporary) / "unused.tar"
            labels = []
            inventory = {"status": "verified", "buildId": "same"}
            gate = {"status": "pass", "uid": 10001, "gid": 10001,
                    "actualSha256": module.digest(PREP / "qa-image/gate.mjs"),
                    "directory": {"isDirectory": True, "mode": "755"},
                    "file": {"isFile": True}}
            if case == "wrong_mode":
                gate["directory"]["mode"] = "444"

            def inner(label, *_args, **_kwargs):
                labels.append(label)
                value = ""
                if label == "inner-original-inspect":
                    value = json.dumps([{"Id": "original-id", "Os": "linux", "Architecture": "arm64",
                                         "RootFS": {"Layers": ["same"]}, "Config": {
                                             "Labels": {"ai.nemori.omne.host-build-id":
                                                        "de6c4c19658e1f15a95614e3c6a9bde0ba13ff3673c41704f99494edcbf01a83"}}}])
                elif label == "qa-image-inspect":
                    value = json.dumps([{"Id": "fixed-id"}])
                elif label.endswith("-inventory"):
                    current = dict(inventory)
                    if case == "app_changed" and label == "qa-inventory":
                        current["buildId"] = "changed"
                    value = json.dumps(current)
                elif label == "qa-gate-availability":
                    value = json.dumps(gate)
                return {"stdout": value, "stderr": "", "returncode": 0,
                        "timed_out": False}

            pilot.inner = inner
            failed = False
            try:
                pilot.images()
            except RuntimeError:
                failed = True
            assert failed == (case != "valid"), case
            if case == "app_changed":
                assert "qa-gate-availability" not in labels
            if case == "valid":
                assert pilot.events["gate_availability"]["directory"]["mode"] == "755"
            return {"case": case, "rejected": failed, "gate_called":
                    "qa-gate-availability" in labels}
        finally:
            module.HERE = original_here


def main():
    old = ast.parse((PREP / "minimal_pilot.py").read_text())
    diagnostic = ast.parse((ROOT / "pilot_with_diagnostics.py").read_text())
    current = ast.parse((ROOT / "pilot_write_hold_fixed.py").read_text())
    preserved = {}
    for name, source in (("run_write_hold", old), ("cleanup", old),
                         ("diagnostic_logs", diagnostic),
                         ("capture_startup_snapshot", diagnostic),
                         ("start_center", diagnostic)):
        preserved[name] = (ast.dump(method(source, name), include_attributes=False) ==
                           ast.dump(method(current, name), include_attributes=False))
    assert all(preserved.values()), preserved
    cases = [image_case(name) for name in ("valid", "wrong_mode", "app_changed")]
    output = {"status": "pass", "docker_used": False, "preserved_methods": preserved,
              "image_cases": cases}
    path = ROOT / "write-hold-fixed-self-test.json"
    if path.exists():
        raise RuntimeError("refusing to overwrite write-hold self-test evidence")
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": "pass", "cases": len(cases),
                      "preserved_methods": len(preserved)}))


if __name__ == "__main__":
    main()
