#!/usr/bin/env python3
"""Candidate only: diagnose one I1 QA center startup. DO NOT run before root review."""

import hashlib
import io
import json
import pathlib
import re
import secrets
import signal
import subprocess
import tarfile
import time
from datetime import datetime, timezone

HERE = pathlib.Path(__file__).resolve().parent
PREP = HERE.parent / "io-gate-prep"
STATIC_MANIFEST_SHA = "1120df43c9f86d343fa315ed98e7659199f7303a161307ae47a49664ef3d718b"
HUB = pathlib.Path("/Users/pandazki/orca/workspaces/omne-harness-lite/flyingfish")
I1_MANIFEST = HUB / "tmp/next-iteration/docker-i1/I1-manifest.json"
I1_ARCHIVE = HUB / "tmp/next-iteration/docker-i1/tenancy-i1-sourcefinal-arm64.tar"
I1_SHA = "1474545aa6e6383e5ea2fbaecbb9ce2d01c847b25f17284f633a939f65f3dbd5"
I1_MANIFEST_SHA = "73adb2e1f104192668fcb37e1cb09047c388af3c99a95e35505bb55615b57a62"
I1_ID = "sha256:86668009808654ebbf30258b8b1637432919a3d50bbf078947ed616f01ccc803"
CONTROL_IMAGE = "omne-m0-v0-control-tools:20260926-fc30a6d4"
CONTROL_ID = "sha256:825773f9776113d54fb23a5de9511d5b6c7bc7550d891f7a3584bfe71c0795f6"
DIND_IMAGE = "docker:29.1.3-dind"
DIND_ID = "sha256:20cca7e2a7da287ded85087ce88d443a5347163eebf6a9ed0c27bc4cabe90ae7"
SOCKET = "unix:///opt/omne-private-docker/docker.sock"
ROOT = "/var/lib/omne-tenancy"
STATE = ROOT + "/state"
SECRETS = ROOT + "/secrets"
MODE = "write-hold"


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def decode(value):
    return value.decode("utf-8", "replace") if isinstance(value, bytes) else (value or "")


class Pilot:
    def __init__(self):
        self.run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(4)
        self.run_dir = HERE / "runs" / self.run_id
        self.run_dir.mkdir(parents=True, mode=0o700)
        self.prefix = "omne-m0-io-" + self.run_id.lower().replace("t", "-").replace("z", "")
        self.label = "omne.m0.io=" + self.run_id
        self.control = self.prefix + "-control"
        self.dind = self.prefix + "-dind"
        self.center = self.prefix + "-center"
        self.contender = self.prefix + "-contender"
        self.network = self.prefix + "-net"
        self.volumes = [self.prefix + "-" + name for name in ("data", "socket", "daemon-data")]
        self.qa_tag = "omne-m0-io-qa:" + self.run_id.lower().replace("t", "-").replace("z", "")
        self.created = []
        self.processes = {}
        self.events = {"run_id": self.run_id, "status": "preparing", "created": self.created,
                       "center_name": self.center, "contender_name": self.contender,
                       "cleanup": [], "started_utc": utc()}
        self.save()

    def save(self):
        (self.run_dir / "events.json").write_text(json.dumps(self.events, indent=2, sort_keys=True) + "\n")

    def record(self, item):
        with (self.run_dir / "commands.jsonl").open("a") as log:
            log.write(json.dumps(item, sort_keys=True) + "\n")

    def call(self, label, argv, timeout=60, stdin_path=None, expected=0):
        started = utc()
        source = stdin_path.open("rb") if stdin_path else None
        try:
            try:
                done = subprocess.run(argv, stdin=source, capture_output=True, timeout=timeout,
                                      check=False)
                item = {"label": label, "argv": argv, "started_utc": started,
                        "finished_utc": utc(), "returncode": done.returncode,
                        "timed_out": False, "stdout": decode(done.stdout), "stderr": decode(done.stderr)}
            except subprocess.TimeoutExpired as error:
                item = {"label": label, "argv": argv, "started_utc": started,
                        "finished_utc": utc(), "returncode": None, "timed_out": True,
                        "stdout": decode(error.stdout), "stderr": decode(error.stderr)}
        finally:
            if source:
                source.close()
        if stdin_path:
            item["stdin_path"] = str(stdin_path)
            item["stdin_sha256"] = digest(stdin_path)
        self.record(item)
        if expected is not None and item["returncode"] != expected:
            raise RuntimeError(f"{label}: rc={item['returncode']}, expected {expected}")
        return item

    def inner(self, label, *args, timeout=60, expected=0, stdin_path=None):
        argv = ["docker", "exec"] + (["-i"] if stdin_path else []) + [self.dind, "docker", "--host", SOCKET, *args]
        return self.call(label, argv, timeout, stdin_path, expected)

    def control_docker(self, label, *args, timeout=60, expected=0):
        return self.call(label, ["docker", "exec", self.control, "docker", "--host", SOCKET, *args],
                         timeout, expected=expected)

    def control_exec(self, label, *args, timeout=60, expected=0):
        return self.call(label, ["docker", "exec", self.control, *args], timeout, expected=expected)

    def diagnostic_logs(self, stage):
        label = f"diagnostic-{stage}-logs-redacted"
        argv = ["docker", "exec", self.dind, "docker", "--host", SOCKET,
                "logs", "--tail", "120", self.center]
        started = utc()
        try:
            done = subprocess.run(argv, capture_output=True, timeout=15, check=False)
            stdout, stderr = decode(done.stdout), decode(done.stderr)
            returncode, timed_out = done.returncode, False
        except subprocess.TimeoutExpired as error:
            stdout, stderr = decode(error.stdout), decode(error.stderr)
            returncode, timed_out = None, True

        def redact(value):
            value = re.sub(r"-----BEGIN [A-Z0-9 ]+-----.*?-----END [A-Z0-9 ]+-----",
                           "[redacted PEM]", value, flags=re.DOTALL)
            value = re.sub(r"(?im)^.*(?:_KEY=|PASSWORD=|SECRET=|TOKEN=).*$",
                           "[redacted config line]", value)
            return value[:32768] + ("\n[truncated]\n" if len(value) > 32768 else "")

        item = {"label": label, "argv": argv, "started_utc": started,
                "finished_utc": utc(), "returncode": returncode,
                "timed_out": timed_out, "stdout": redact(stdout), "stderr": redact(stderr),
                "redaction": "PEM blocks, config assignments, 32KiB per stream"}
        self.record(item)
        return item

    def capture_startup_snapshot(self, stage):
        # Bounded, selected Docker fields only: never dump Config.Env or secret files.
        commands = [
            ("state", ("container", "inspect", "--format", "{{json .State}}", self.center)),
            ("mounts", ("container", "inspect", "--format", "{{json .Mounts}}", self.center)),
            ("entrypoint", ("container", "inspect", "--format",
                            "{{json .Config.Entrypoint}}|{{json .Config.Cmd}}|{{json .Path}}|{{json .Args}}",
                            self.center)),
            ("top", ("top", self.center)),
            ("center-process", ("exec", self.center, "sh", "-c",
                                "id; readlink /proc/1/exe; printf 'NODE_OPTIONS=%s\\n' "
                                "\"$NODE_OPTIONS\"; stat -c '%d:%i:%u:%g:%a' "
                                "/state /state/qa /state/qa/mode /run/omne-tenancy "
                                "/probe/gate.mjs; sha256sum /probe/gate.mjs; "
                                "cat /state/qa/mode")),
        ]
        observed = []
        for name, args in commands:
            try:
                row = self.inner(f"diagnostic-{stage}-{name}", *args,
                                 timeout=12, expected=None)
                observed.append({"name": name, "returncode": row["returncode"],
                                 "timed_out": row["timed_out"]})
            except BaseException as error:
                observed.append({"name": name, "error": repr(error)})
        for name, argv in (
            ("control-state", ["docker", "exec", self.control, "stat", "-c",
                               "%d:%i:%u:%g:%a", STATE, STATE + "/qa", STATE + "/qa/mode"]),
            ("dind-state", ["docker", "exec", self.dind, "stat", "-c",
                            "%d:%i:%u:%g:%a", STATE, STATE + "/qa", STATE + "/qa/mode"]),
        ):
            try:
                row = self.call(f"diagnostic-{stage}-{name}", argv, timeout=12,
                                expected=None)
                observed.append({"name": name, "returncode": row["returncode"],
                                 "timed_out": row["timed_out"]})
            except BaseException as error:
                observed.append({"name": name, "error": repr(error)})
        try:
            row = self.diagnostic_logs(stage)
            observed.append({"name": "logs-redacted", "returncode": row["returncode"],
                             "timed_out": row["timed_out"]})
        except BaseException as error:
            observed.append({"name": "logs-redacted", "error": repr(error)})
        self.events.setdefault("diagnostic_snapshots", []).append({"stage": stage,
                                                                    "observed_utc": utc(),
                                                                    "commands": observed})
        self.save()

    def inspect_outer(self, label, name):
        return json.loads(self.call(label, ["docker", "container", "inspect", name])["stdout"])[0]

    def inspect_inner(self, label, name):
        return json.loads(self.inner(label, "container", "inspect", name)["stdout"])[0]

    def create(self, kind, name, argv, timeout=90):
        # Preflight proved absence; record before a possibly timed-out create.
        self.created.append([kind, name])
        self.save()
        self.call("create-" + name, argv, timeout)

    def await_file(self, label, path, seconds=30):
        deadline = time.monotonic() + seconds
        attempt = 0
        while time.monotonic() < deadline:
            attempt += 1
            observed = self.control_exec(f"{label}-poll-{attempt}", "test", "-f", path, expected=None)
            if observed["returncode"] == 0:
                return self.control_exec(label, "cat", path)["stdout"]
            time.sleep(0.2)
        raise RuntimeError(f"{label}: file did not appear")

    def start_async(self, label, argv):
        process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.processes[label] = {"process": process, "argv": argv, "started_utc": utc(),
                                 "started_monotonic": time.monotonic()}
        self.events[label + "_pid"] = process.pid
        self.save()
        return process

    def finish_async(self, label, timeout=30):
        running = self.processes.pop(label)
        process = running["process"]
        try:
            stdout, stderr = process.communicate(timeout=timeout)
            item = {"label": label + "-finish", "argv": running["argv"],
                    "started_utc": running["started_utc"], "finished_utc": utc(),
                    "returncode": process.returncode, "timed_out": False,
                    "stdout": decode(stdout), "stderr": decode(stderr)}
        except subprocess.TimeoutExpired:
            item = {"label": label + "-finish", "argv": running["argv"],
                    "started_utc": running["started_utc"], "finished_utc": utc(),
                    "returncode": None, "timed_out": True, "stdout": "", "stderr": ""}
            self.processes[label] = running
        self.record(item)
        return item

    def preflight(self):
        if digest(PREP / "static-manifest.json") != STATIC_MANIFEST_SHA:
            raise RuntimeError("reviewed static fixture manifest changed")
        static_manifest = json.loads((PREP / "static-manifest.json").read_text())
        if any(digest(PREP / item["path"]) != item["sha256"]
               for item in static_manifest["files"]):
            raise RuntimeError("reviewed static fixture file changed")
        audit = json.loads((PREP / "inputs-audit.json").read_text())
        if (audit.get("status") != "pass" or digest(I1_ARCHIVE) != I1_SHA or
                digest(I1_MANIFEST) != I1_MANIFEST_SHA):
            raise RuntimeError("I1 input audit or image archive digest changed")
        manifest = json.loads(I1_MANIFEST.read_text())
        if (manifest["image"]["imageId"] != I1_ID or
                manifest["host"]["buildId"] !=
                "de6c4c19658e1f15a95614e3c6a9bde0ba13ff3673c41704f99494edcbf01a83"):
            raise RuntimeError("I1 identity changed")
        self.original_tag = manifest["image"]["repoTags"][0]
        self.events["inputs"] = {"image_tar_sha256": I1_SHA, "source_image_id": I1_ID,
                                 "gate_sha256": digest(PREP / "qa-image/gate.mjs"),
                                 "dockerfile_sha256": digest(PREP / "qa-image/Dockerfile"),
                                 "inventory_sha256": digest(PREP / "inventory.mjs")}
        for kind, name in [("network", self.network), *(('volume', v) for v in self.volumes),
                           ("container", self.control), ("container", self.dind)]:
            item = self.call("absent-" + name, ["docker", kind, "inspect", name], expected=None)
            if item["returncode"] in (0, None):
                raise RuntimeError(f"resource already exists or absence unknown: {name}")
        for name, expected in ((CONTROL_IMAGE, CONTROL_ID), (DIND_IMAGE, DIND_ID),
                               (self.original_tag, I1_ID)):
            image = json.loads(self.call("input-image-" + name,
                                         ["docker", "image", "inspect", name])["stdout"])[0]
            if (image["Id"], image["Os"], image["Architecture"]) != (expected, "linux", "arm64"):
                raise RuntimeError(f"cached image identity differs: {name}")
            if name == self.original_tag:
                self.events["outer_original_image"] = {
                    "id": image["Id"], "os": image["Os"],
                    "architecture": image["Architecture"],
                    "rootfs_layers": image["RootFS"]["Layers"],
                }
        self.save()

    def setup_private_docker(self):
        self.create("network", self.network,
                    ["docker", "network", "create", "--label", self.label, self.network])
        for volume in self.volumes:
            self.create("volume", volume,
                        ["docker", "volume", "create", "--label", self.label, volume])
        self.create("container", self.control,
                    ["docker", "run", "-d", "--name", self.control, "--label", self.label,
                     "--network", self.network, "--privileged", "--cgroupns=private",
                     "--tmpfs", "/run", "--tmpfs", "/run/lock", "--tmpfs", "/tmp",
                     "-v", f"{self.volumes[0]}:{ROOT}",
                     "-v", f"{self.volumes[1]}:/opt/omne-private-docker", CONTROL_IMAGE])
        self.create("container", self.dind,
                    ["docker", "run", "-d", "--name", self.dind, "--label", self.label,
                     "--network", self.network, "--privileged", "-e", f"DOCKER_HOST={SOCKET}",
                     "-e", "DOCKER_TLS_CERTDIR=", "-v", f"{self.volumes[0]}:{ROOT}",
                     "-v", f"{self.volumes[1]}:/opt/omne-private-docker",
                     "-v", f"{self.volumes[2]}:/var/lib/docker", DIND_IMAGE,
                     "--host", SOCKET, "--tls=false"])
        deadline = time.monotonic() + 45
        attempt = 0
        while time.monotonic() < deadline:
            attempt += 1
            version = self.inner(f"dind-ready-{attempt}", "version", "--format", "{{json .}}",
                                 timeout=8, expected=None)
            if version["returncode"] == 0:
                parsed = json.loads(version["stdout"])
                if parsed["Server"]["Version"] == "29.1.3":
                    self.events["private_engine_version"] = parsed
                    break
            time.sleep(0.5)
        else:
            raise RuntimeError("isolated Docker Engine did not become ready")
        # The control image has no Docker CLI; copy the known binary from the fixed DinD image.
        cli_path = self.call("source-cli-path", ["docker", "exec", self.dind, "sh", "-c",
                                                 "command -v docker"])["stdout"].strip()
        if not cli_path.startswith("/"):
            raise RuntimeError("DinD Docker CLI path missing")
        local_cli = self.run_dir / "docker-cli"
        self.call("copy-cli-from-dind", ["docker", "cp", f"{self.dind}:{cli_path}", str(local_cli)])
        self.call("stream-cli-to-control",
                  ["docker", "exec", "-i", self.control, "sh", "-c",
                   "cat > /usr/local/bin/docker && chmod 0755 /usr/local/bin/docker"],
                  stdin_path=local_cli)
        self.events["inputs"]["linux_cli_sha256"] = digest(local_cli)
        version_row = self.control_docker("control-private-version", "version", "--format",
                                          "{{json .}}")
        version = json.loads(version_row["stdout"])
        if version["Client"]["Version"] != "29.1.3" or version["Server"]["Version"] != "29.1.3":
            raise RuntimeError("control CLI/private Engine mismatch")
        self.save()

    def context_tar(self):
        path = self.run_dir / "qa-context.tar"
        with tarfile.open(path, "w") as archive:
            for name in ("Dockerfile", "gate.mjs"):
                data = (PREP / "qa-image" / name).read_bytes()
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
        self.events["inputs"]["qa_context_sha256"] = digest(path)
        self.save()
        return path

    def images(self):
        self.inner("load-i1", "load", timeout=480, stdin_path=I1_ARCHIVE)
        original = json.loads(self.inner("inner-original-inspect", "image", "inspect",
                                         self.original_tag)["stdout"])[0]
        if (original["Os"], original["Architecture"],
                original["Config"]["Labels"].get("ai.nemori.omne.host-build-id")) != (
                "linux", "arm64", "de6c4c19658e1f15a95614e3c6a9bde0ba13ff3673c41704f99494edcbf01a83"):
            raise RuntimeError("inner I1 content identity differs")
        outer = self.events["outer_original_image"]
        if (original["Os"], original["Architecture"], original["RootFS"]["Layers"]) != (
                outer["os"], outer["architecture"], outer["rootfs_layers"]):
            raise RuntimeError("inner I1 platform or RootFS layers differ from cached I1 input")
        self.inner("build-qa-image", "build", "--pull=false", "--no-cache", "-t", self.qa_tag,
                   "-", timeout=600, stdin_path=self.context_tar())
        qa = json.loads(self.inner("qa-image-inspect", "image", "inspect", self.qa_tag)["stdout"])[0]
        self.events["images"] = {"original_id": original["Id"], "qa_id": qa["Id"]}
        for label, image in (("original-inventory", self.original_tag), ("qa-inventory", self.qa_tag)):
            item = self.inner(label, "run", "--rm", "-i", "--pull", "never", "--network", "none",
                              "--entrypoint", "node", "-e", "NODE_OPTIONS=", image,
                              "--input-type=module", "-", timeout=180, stdin_path=PREP / "inventory.mjs")
            if json.loads(item["stdout"])["status"] != "verified":
                raise RuntimeError(f"{label} did not verify app inventory")
        self.save()

    def prepare_state(self):
        command = ("set -eu; "
                   f"install -d -m 0700 -o 10001 -g 10001 {STATE} {STATE}/data "
                   f"{STATE}/backups {STATE}/qa {STATE}/offline-work {STATE}/restores {SECRETS}; "
                   f"printf '{MODE}\\n' > {STATE}/qa/mode; "
                   f"chown 10001:10001 {STATE}/qa/mode; chmod 0600 {STATE}/qa/mode")
        self.control_exec("prepare-private-state", "sh", "-c", command)
        cert = ("set -eu; openssl req -x509 -newkey rsa:2048 -sha256 -nodes -days 1 "
                "-subj '/CN=localhost' -addext 'subjectAltName=DNS:localhost,IP:127.0.0.1' "
                f"-keyout {SECRETS}/tls-private.pem -out {SECRETS}/tls-chain.pem; "
                f"chown 10001:10001 {SECRETS}/tls-private.pem {SECRETS}/tls-chain.pem; "
                f"chmod 0600 {SECRETS}/tls-private.pem {SECRETS}/tls-chain.pem")
        self.control_exec("generate-dummy-tls", "sh", "-c", cert)
        self.inner("keygen", "run", "--rm", "--pull", "never", "--network", "none",
                   "--user", "10001:10001", "-v", f"{SECRETS}:/secrets",
                   self.original_tag, "keygen", "/secrets", timeout=45)
        control_stat = self.control_exec("control-state-stat", "stat", "-c", "%i:%u:%g:%a", STATE)["stdout"]
        dind_stat = self.call("dind-state-stat", ["docker", "exec", self.dind, "stat", "-c",
                                                   "%i:%u:%g:%a", STATE])["stdout"]
        if control_stat != dind_stat or not control_stat.strip().endswith(":10001:10001:700"):
            raise RuntimeError("private state volume view differs")

    def center_env(self):
        values = {
            "OMNE_TENANCY_STORAGE_DIALECT": "sqlite",
            "OMNE_TENANCY_STORAGE_FILE": "/state/data/center.sqlite",
            "OMNE_TENANCY_BACKUP_DIR": "/state/backups",
            "OMNE_TENANCY_OPS_SOCKET_DIR": "/run/omne-tenancy",
            "OMNE_TENANCY_ENTRY_LISTEN": "0.0.0.0:8443",
            "OMNE_TENANCY_ACTIVATION_SIGNING_KEY_PEM_FILE": "/secrets/activation-signing-key.pem",
            "OMNE_TENANCY_ACTIVATION_VERIFICATION_KEY_PEM_FILE": "/secrets/activation-verification-key.pem",
            "OMNE_TENANCY_PURGE_SIGNING_KEY_PEM_FILE": "/secrets/purge-signing-key.pem",
            "OMNE_TENANCY_PURGE_VERIFICATION_KEY_PEM_FILE": "/secrets/purge-verification-key.pem",
            "OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE": "/secrets/tls-chain.pem",
            "OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE": "/secrets/tls-private.pem",
            "OMNE_TENANCY_UNACTIVATED_RETENTION": "P7D",
            "OMNE_TENANCY_INVITATION_TTL_DEFAULT": "P14D",
            "OMNE_TENANCY_AFFILIATION_REQUEST_TTL_DEFAULT": "P14D",
            "OMNE_TENANCY_COPY_NOTICE_TTL_DEFAULT": "P7D",
            "OMNE_TENANCY_SHARING_INVITATION_TTL_DEFAULT": "P7D",
            "OMNE_TENANCY_TEAM_CREATION_KEY_RETENTION": "P1D",
            "OMNE_TENANCY_CLOCK_READY_TIMEOUT": "15000",
        }
        return [part for key, value in values.items() for part in ("-e", f"{key}={value}")]

    def container_args(self, name, image):
        return ["--pull", "never", "--name", name, "--label", self.label, "--network", "none",
                "--user", "10001:10001", "--restart", "no", "--stop-timeout=-1",
                "-v", f"{STATE}:/state", "-v", f"{SECRETS}:/secrets:ro",
                "--tmpfs", "/run/omne-tenancy:rw,nosuid,nodev,noexec,uid=10001,gid=10001,mode=0700",
                *self.center_env(), image, "serve"]

    def start_center(self):
        try:
            self.control_docker("run-center", "run", "-d",
                                *self.container_args(self.center, self.qa_tag), timeout=90)
            self.capture_startup_snapshot("after-create")
            self.await_file("gate-ready", STATE + "/qa/ready", 30)
            deadline = time.monotonic() + 60
            attempt = 0
            while time.monotonic() < deadline:
                attempt += 1
                probe = self.inner(f"health-poll-{attempt}", "exec", self.center, "node",
                                   "/opt/omne/app/deploy/docker/health.mjs", expected=None,
                                   timeout=8)
                if probe["returncode"] == 0:
                    break
                time.sleep(1)
            else:
                raise RuntimeError("QA center did not become healthy")
            health = json.loads(self.inner("full-health", "exec", self.center, "node",
                                           "/opt/omne/app/dist/cli.js", "ops", "--socket-dir",
                                           "/run/omne-tenancy", "full-health")["stdout"])
            if not (health.get("reachable") is True and health.get("storageReachable") is True and
                    health.get("defectCount") == 0):
                raise RuntimeError("QA center full-health fields differ")
            center = self.inspect_inner("center-before-stop", self.center)
            if (center["Image"] != self.events["images"]["qa_id"] or
                    center["State"]["Running"] is not True):
                raise RuntimeError("QA center identity/running state differs")
        except BaseException:
            self.capture_startup_snapshot("before-startup-exit")
            raise

    def cleanup(self):
        # Release a held dummy gate first; never target a non-owned resource.
        if any(kind == "container" and name == self.control for kind, name in self.created):
            try:
                self.control_exec("cleanup-release", "touch", STATE + "/qa/release", expected=None)
            except BaseException as error:
                self.events["cleanup"].append({"step": "release", "error": repr(error)})
        for label, running in list(self.processes.items()):
            process = running["process"]
            try:
                process.communicate(timeout=8)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:
                    process.communicate(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.communicate(timeout=2)
            except BaseException as error:
                self.events["cleanup"].append({"step": "finish-async", "label": label,
                                                "error": repr(error)})
            self.processes.pop(label, None)
        if any(kind == "container" and name == self.dind for kind, name in self.created):
            for name in (self.contender, self.center):
                try:
                    self.inner("cleanup-inner-" + name, "rm", "-f", name, expected=None,
                               timeout=30)
                    self.inner("cleanup-inner-absent-" + name, "container", "inspect", name,
                               expected=None, timeout=15)
                except BaseException as error:
                    self.events["cleanup"].append({"step": "remove-inner", "name": name,
                                                    "error": repr(error)})
        for kind, name in reversed(self.created):
            remove = {"container": ["docker", "rm", "-f", name],
                      "volume": ["docker", "volume", "rm", name],
                      "network": ["docker", "network", "rm", name]}[kind]
            inspect = {"container": ["docker", "container", "inspect", name],
                       "volume": ["docker", "volume", "inspect", name],
                       "network": ["docker", "network", "inspect", name]}[kind]
            try:
                deleted = self.call("cleanup-remove-" + name, remove, timeout=90,
                                    expected=None)
                absent = self.call("cleanup-inspect-" + name, inspect, expected=None)
                self.events["cleanup"].append({"kind": kind, "name": name,
                                                "remove_returncode": deleted["returncode"],
                                                "inspect_absent": absent["returncode"] not in (0, None)})
            except BaseException as error:
                self.events["cleanup"].append({"kind": kind, "name": name,
                                                "error": repr(error)})
            self.save()

    def main(self):
        try:
            self.preflight()
            self.setup_private_docker()
            self.images()
            self.prepare_state()
            self.start_center()
            self.events["status"] = "startup_observations_recorded"
        except BaseException as error:
            self.events["status"] = "pilot_failed"
            self.events["error"] = f"{type(error).__name__}: {error}"
        finally:
            self.cleanup()
            self.events["finished_utc"] = utc()
            self.save()
        print(json.dumps({"run_dir": str(self.run_dir), "status": self.events["status"],
                          "error": self.events.get("error")}, sort_keys=True))
        return 0 if self.events["status"] == "startup_observations_recorded" else 1


def on_signal(signum, _frame):
    raise KeyboardInterrupt(f"signal {signum}")


if __name__ == "__main__":
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, on_signal)
    raise SystemExit(Pilot().main())
