#!/usr/bin/env python3
"""Pure decision-table checks for the single-run conditional QA-directory branch."""

import copy
import importlib.util
import json
import pathlib
import sys

sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("conditional_gate_candidate", ROOT / "pilot_conditional_dir.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def main():
    expected = module.digest(ROOT.parent / "io-gate-prep/qa-image/gate.mjs")
    directory = {"isDirectory": True, "uid": 0, "gid": 0, "mode": "444"}
    target = {"status": "fail", "uid": 10001, "gid": 10001, "errorCode": "EACCES",
              "directory": directory}
    root = {"status": "pass", "uid": 0, "gid": 0, "actualSha256": expected,
            "directory": directory, "file": {"isFile": True, "mode": "444"}}
    target_row = {"returncode": 1, "timed_out": False}
    root_row = {"returncode": 0, "timed_out": False}
    scenarios = []

    def check(name, target_change=None, root_change=None, row_change=None, expected_result=False):
        local_target = copy.deepcopy(target)
        local_root = copy.deepcopy(root)
        local_target_row = copy.deepcopy(target_row)
        if target_change:
            target_change(local_target)
        if root_change:
            root_change(local_root)
        if row_change:
            row_change(local_target_row)
        actual = module.eligible_for_directory_fix(local_target_row, local_target,
                                                    root_row, local_root, expected)
        assert actual is expected_result, (name, actual)
        scenarios.append({"name": name, "eligible": actual})

    check("nontraversable_parent_present_hashed_file", expected_result=True)
    check("traversable_parent", root_change=lambda r: r["directory"].update({"mode": "755"}))
    check("missing_file", root_change=lambda r: r.update({"file": None, "status": "fail"}))
    check("wrong_file_hash", root_change=lambda r: r.update({"actualSha256": "0" * 64}))
    check("root_directory_disagrees", root_change=lambda r: r["directory"].update({"uid": 7}))
    check("target_had_other_error", target_change=lambda t: t.update({"errorCode": "EIO"}))
    check("target_timed_out", row_change=lambda r: r.update({"timed_out": True}))

    output = {"status": "pass", "docker_used": False, "cases": scenarios}
    path = ROOT / "conditional-self-test.json"
    if path.exists():
        raise RuntimeError("refusing to overwrite conditional self-test evidence")
    path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": "pass", "cases": len(scenarios)}))


if __name__ == "__main__":
    main()
