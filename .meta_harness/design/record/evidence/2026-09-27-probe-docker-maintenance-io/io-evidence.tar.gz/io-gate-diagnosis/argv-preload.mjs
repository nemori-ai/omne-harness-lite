import { promises as fs } from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'

const originalOpen = (await import('node:fs/promises')).open
fs.open = async () => 'patched-open'
syncBuiltinESMExports()
const namedOpen = (await import('node:fs/promises')).open

process.stdout.write(
  JSON.stringify({
    stage: 'preload',
    argv: process.argv,
    nodeOptions: process.env.NODE_OPTIONS ?? null,
    namedOpenUpdated: namedOpen !== originalOpen,
    patchedValue: await namedOpen(),
  }) + '\n',
)
