import { getActiveResourcesInfo } from 'node:process';
import { pathToFileURL } from 'node:url';
const before=getActiveResourcesInfo();
await import(pathToFileURL(process.argv[2]).href);
await new Promise(resolve=>setImmediate(resolve));
console.log(JSON.stringify({before,after:getActiveResourcesInfo()}));
