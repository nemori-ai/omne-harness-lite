// QA image only: hold the first actual offline import write after open("wx", 0600).
import { promises as fs } from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'
import { setTimeout as delay } from 'node:timers/promises'

const control = '/state/qa'
const taskFile = /^\/state\/offline-work\/([a-z0-9][a-z0-9_-]{0,62})\/task-[0-9a-f]{32}\/snapshot\.sqlite$/

async function installGate() {
  const project = (await fs.readFile(`${control}/project`, 'utf8')).trim()
  if (!/^[a-z0-9][a-z0-9_-]{0,62}$/.test(project)) throw new Error('qa gate: invalid project')
  const originalOpen = fs.open.bind(fs)
  let attached = false
  fs.open = async (...args) => {
    const handle = await originalOpen(...args)
    const path = String(args[0])
    const match = taskFile.exec(path)
    if (attached || !match || match[1] !== project || args[1] !== 'wx' || args[2] !== 0o600) return handle
    attached = true
    const originalWriteFile = handle.writeFile.bind(handle)
    let first = true
    handle.writeFile = async (...writeArgs) => {
      if (first) {
        first = false
        const info = await handle.stat()
        if (handle.fd < 0 || !info.isFile() || info.uid !== process.getuid() ||
            (info.mode & 0o777) !== 0o600) throw new Error('qa gate: expected owned 0600 FileHandle')
        await fs.writeFile(`${control}/held`, JSON.stringify({
          stage: 'offline-import-write', path, fd: handle.fd, pid: process.pid,
          dev: info.dev, ino: info.ino,
        }) + '\n', { flag: 'wx', mode: 0o600 })
        for (;;) {
          try {
            await fs.stat(`${control}/release`)
            break
          } catch (error) {
            if (error?.code !== 'ENOENT') throw error
            await delay(50)
          }
        }
      }
      return originalWriteFile(...writeArgs)
    }
    return handle
  }
  syncBuiltinESMExports()
  await fs.writeFile(`${control}/ready`, JSON.stringify({
    stage: 'ready', project, pid: process.pid,
  }) + '\n', { flag: 'wx', mode: 0o600 })
}

if (process.argv[1] === '/opt/omne/app/dist/cli.js' && process.argv[2] === 'verify') {
  await installGate()
}
