#!/usr/bin/env python3
"""Independent raw-output oracle for one offline verify handled-TERM scenario."""

import hashlib
import json
import pathlib
import re
import sys

BUILD_ID = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
ORIGINAL = "sha256:27c0665146265afefe39012aaea26bdae7499784eaaeb74aea712a6fcdfc03f2"
I3_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
PRIVATE = "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock"
HELPER = "/usr/local/libexec/omne-center"
MARKER_CONTENT = b"omne-isolated/1\n"
HEX64 = re.compile(r"[0-9a-f]{64}\Z")


def demand(value, message):
    if not value:
        raise ValueError(message)


def one_json(data, label):
    demand(data.endswith(b"\n") and data.count(b"\n") == 1, label + ": one JSON+LF required")
    value = json.loads(data)
    demand(isinstance(value, dict), label + ": object required")
    return value


def stat_parts(data, label, count):
    parts = data.decode("ascii", "strict").strip().split(":")
    demand(len(parts) == count and all(x.isdigit() for x in parts), label + ": bad stat")
    return tuple(map(int, parts))


def evaluate_observation(e, raw):
    entries = e["commands"]
    rows = {item["label"]: item for item in entries}
    demand(len(rows) == len(entries), "duplicate command label")
    demand(e["scenario"] == "handled-term" and e["business_complete"] is True and
           e["status"] == "observed-awaiting-oracle", "business observation incomplete")
    demand(e["artifact_manifest_sha256"] == I3_SHA and e["inputs"]["build_id"] == BUILD_ID and
           e["inputs"]["image_id"] == ORIGINAL, "wrong I3 artifact input")
    ordered = [item["label"] for item in entries]
    stages = ["original-inventory", "qa-inventory", "gate-availability", "validate", "start",
              "backup", "source-stat", "source-hash-before", "stop-center", "center-final",
              "work-absent", "verify-helper", "offline-before", "gate-ready", "gate-held",
              "fd-readlink", "fd-stat", "marker-stat-held", "marker-content-held",
              "signal-helper", "offline-held", "fd-readlink-held", "fd-stat-held",
              "marker-stat-mid", "marker-content-mid", "offline-logs-held",
              "same-work-contender", "contender-final",
              "offline-after-contender", "fd-stat-after-contender",
              "release-gate", "offline-final", "offline-logs-final", "offline-status",
              "marker-stat-final", "marker-content-final", "import-file-absent",
              "source-hash-final"]
    demand(all(label in rows for label in stages) and
           [ordered.index(label) for label in stages] == sorted(ordered.index(label) for label in stages),
           "scenario order missing or wrong")

    def row(label, code=0):
        item = rows[label]
        demand(item["returncode"] == code and item.get("observation_expired") is False,
               label + ": wrong client rc or observation expired")
        return item

    def out(label, stream="stdout"):
        data = raw.get((label, stream))
        demand(isinstance(data, bytes), label + ": raw " + stream + " missing")
        return data

    def obj(label, code=0):
        row(label, code)
        return one_json(out(label), label)

    def inspect(label, cid):
        row(label)
        value = json.loads(out(label))
        demand(isinstance(value, list) and len(value) == 1 and value[0].get("Id") == cid,
               label + ": wrong exact CID")
        return value[0]

    original_inventory = obj("original-inventory")
    qa_inventory = obj("qa-inventory")
    demand(original_inventory == qa_inventory == {
        "status": "verified", "buildId": BUILD_ID, "files": 2851, "links": 115,
        "manifestSha256": e["inputs"]["host_manifest_sha256"], "node": "v24.21.0",
    }, "whole app file/link inventory changed")
    qa = inspect("qa-image-inspect", e["qa_image_id"])
    origin = inspect("inner-image-inspect", e["expected"]["inner_image_id"])
    outer = inspect("outer-product-image", ORIGINAL)
    demand(qa["Id"] != origin["Id"] and qa["RootFS"]["Layers"][:len(origin["RootFS"]["Layers"])] ==
           origin["RootFS"]["Layers"] and origin["RootFS"]["Layers"] == outer["RootFS"]["Layers"] and
           qa["Config"]["Labels"].get("ai.nemori.omne.qa-fixture") == "offline-cancel/r1" and
           qa["Config"]["User"] == "10001:10001" and
           "NODE_OPTIONS=--import=/probe/gate.mjs" in qa["Config"]["Env"] and
           "NODE_OPTIONS=--import=/probe/gate.mjs" not in origin["Config"]["Env"] and
           sorted(qa["Config"]["Env"]) == sorted([*origin["Config"]["Env"],
              "NODE_OPTIONS=--import=/probe/gate.mjs"]) and
           qa["Config"]["Entrypoint"] == origin["Config"]["Entrypoint"] and
           qa["Config"]["Cmd"] == origin["Config"]["Cmd"], "QA image exceeded preload boundary")
    gate = obj("gate-availability")
    demand(gate.get("status") == "pass" and gate.get("uid") == gate.get("gid") == 10001 and
           gate.get("directory", {}).get("mode") == "755" and gate.get("file", {}).get("mode") == "444" and
           gate.get("file", {}).get("uid") == gate.get("file", {}).get("gid") == 10001 and
           gate.get("actualSha256") == e["inputs"]["sha256"]["gate"],
           "QA preload unreadable or wrong byte identity")
    control = e["expected"]["control"]
    prefix = ["docker", "exec", "-e", PRIVATE, control, HELPER]
    for label, action in (("validate", "validate"), ("start", "start"),
                          ("backup", "backup"), ("stop-center", "stop"),
                          ("same-work-contender", "verify"),
                          ("offline-status", "maintenance-status")):
        demand(rows[label]["argv"][:len(prefix) + 1] == [*prefix, action],
               label + ": not the real helper in private control")
    demand(sum(1 for item in entries if item["argv"][:len(prefix) + 1] == [*prefix, "stop"]) == 1,
           "source center stop invoked more than once")
    center = e["center_id"]
    demand(HEX64.fullmatch(center), "source center CID malformed")
    start_result = obj("start")
    stop_result = obj("stop-center")
    center_final = inspect("center-final", center)
    demand(start_result.get("containerId") == center and
           start_result.get("imageId") == e["expected"]["inner_image_id"] and
           start_result.get("state") == "running" and start_result.get("health") == "healthy" and
           obj("backup").get("status") == "completed" and
           stop_result.get("containerId") == center and stop_result.get("clean") is True and
           stop_result.get("exitCode") == 0 and stop_result.get("state") == "stopped" and
           center_final["State"]["Status"] == "exited" and center_final["State"]["ExitCode"] == 0,
           "genuine source backup/center settlement absent")
    source = e["source"]
    demand(re.fullmatch(r"/var/lib/omne-tenancy/state/backups/[0-9a-f]{32}\.omne-backup", source),
           "source path not a completed backup")
    row("source-stat")
    source_stat = out("source-stat").decode().strip().split(":")
    demand(len(source_stat) == 5 and source_stat[0] == "regular file" and
           source_stat[1:4] == ["10001", "10001", "600"] and int(source_stat[4]) > 0,
           "source backup mode or size wrong")
    for label in ("source-hash-before", "source-hash-final"):
        row(label)
    demand(out("source-hash-before") == out("source-hash-final") and
           source.encode() in out("source-hash-final"), "source backup changed")
    row("work-absent")
    work = e["work"]
    demand(work == "/var/lib/omne-tenancy/state/offline-work/" + e["expected"]["project"],
           "wrong workRoot")
    cid = e["offline_id"]
    other = e["contender_id"]
    demand(HEX64.fullmatch(cid) and HEX64.fullmatch(other) and cid != other and cid != center,
           "offline/contender CIDs not distinct")
    created = re.findall(rb"maintenance-created name=([^\s]+) container=([0-9a-f]{64})",
                         out("verify-helper", "stderr"))
    demand(len(created) == 1 and created[0][1].decode() == cid and
           created[0][0].decode() == e["offline_name"], "helper created record absent/ambiguous")
    helper_stderr = out("verify-helper", "stderr")
    demand(helper_stderr.count(("maintenance-term-request container=" + cid).encode()) == 1 and
           helper_stderr.count(("maintenance-finished container=" + cid +
                                " exit=2 interrupted=true").encode()) == 1,
           "helper TERM/final settlement records absent or duplicated")
    wrapper = rows["verify-helper"]["argv"]
    expected_wrapper = ["docker", "exec", "-e", PRIVATE, control, "sh", "-c",
                        'printf "%s\\n" "$$" > "$1"; shift; exec "$@"', "sh"]
    demand(wrapper[:len(expected_wrapper)] == expected_wrapper and
           wrapper[len(expected_wrapper) + 1:len(expected_wrapper) + 3] == [HELPER, "verify"] and
           wrapper.count("--work-dir") == 1 and wrapper[wrapper.index("--work-dir") + 1] == work and
           wrapper.count("--source") == 1 and wrapper[wrapper.index("--source") + 1] == source and
           wrapper[wrapper.index("--image") + 1] == e["qa_image_id"],
           "verify wrapper did not exec real helper with exact inputs")
    ready = e["offline_ready"]
    demand(ready["cid"] == cid and ready["monotonic_ns"] < e["term_observation"]["monotonic_ns"],
           "maintenance-created used as false offline_ready proof")
    row(ready["ps_label"])
    row(ready["pid_label"])
    helper_pid = e["helper_pid"]
    demand(int(out(ready["pid_label"]).strip()) == helper_pid and helper_pid > 1,
           "pidfile does not name helper")
    ps_rows = []
    for line in out(ready["ps_label"]).decode().splitlines():
        parts = line.strip().split(None, 2)
        if len(parts) == 3 and parts[0].isdigit() and parts[1].isdigit():
            ps_rows.append((int(parts[0]), int(parts[1]), parts[2]))
    demand(any(pid == helper_pid and "bash " + HELPER + " verify " in args
               for pid, _, args in ps_rows), "signalled PID was not inner helper")
    demand(any(pid == e["wait_pid"] and ppid == helper_pid and args.endswith("docker wait " + cid)
               for pid, ppid, args in ps_rows), "exact CID docker wait child missing")
    row("signal-helper")
    demand(rows["signal-helper"]["argv"] == ["docker", "exec", control, "kill", "-TERM", str(helper_pid)] and
           sum(1 for item in entries if item["label"] == "signal-helper") == 1,
           "TERM was not sent exactly once to inner helper PID")
    before = inspect("offline-before", cid)
    middle = inspect("offline-held", cid)
    after_contender = inspect("offline-after-contender", cid)
    final = inspect("offline-final", cid)
    for item in (before, middle, after_contender, final):
        demand(item["Image"] == e["qa_image_id"] and item["Config"]["User"] == "10001:10001" and
               item["Config"]["StopSignal"] == "SIGTERM" and
               item["HostConfig"]["RestartPolicy"]["Name"] == "no" and
               item["HostConfig"]["NetworkMode"] == "none" and
               len(item["Mounts"]) == 1 and item["Mounts"][0]["Destination"] == "/state" and
               item["Mounts"][0]["Source"] == e["expected"]["state"],
               "offline task actual image/config/mount differs")
    demand(before["State"]["Status"] == middle["State"]["Status"] ==
           after_contender["State"]["Status"] == "running" and
           before["State"]["Pid"] == middle["State"]["Pid"] ==
           after_contender["State"]["Pid"] > 0 and
           before["State"]["StartedAt"] == middle["State"]["StartedAt"] ==
           after_contender["State"]["StartedAt"],
           "original offline owner changed or exited during hold")
    demand(final["State"]["Status"] == "exited" and final["State"]["ExitCode"] == 2,
           "original offline app did not really exit cancelled code 2")
    held = obj("gate-held")
    demand(obj("gate-ready") == {"stage": "ready", "project": e["expected"]["project"], "pid": 1} and
           held.get("stage") == "offline-import-write" and held.get("pid") == 1 and
           type(held.get("fd")) is int and held["fd"] >= 0 and
           held.get("path", "").startswith("/state/offline-work/" + e["expected"]["project"] + "/") and
           re.fullmatch(r"/state/offline-work/[a-z0-9_-]+/task-[0-9a-f]{32}/snapshot\.sqlite",
                        held["path"]), "wrong real FileHandle target")
    fd = f"/proc/1/fd/{held['fd']}"
    for label in ("fd-readlink", "fd-readlink-held"):
        row(label)
        demand(out(label).strip().decode() == held["path"], "real FD no longer points at import")
    for label in ("fd-stat", "fd-stat-held", "fd-stat-after-contender"):
        row(label)
        dev, ino, uid, gid, mode = stat_parts(out(label), label, 5)
        demand((dev, ino, uid, gid, mode) == (held["dev"], held["ino"], 10001, 10001, 600),
               "real FD identity/owner/mode changed")
    marker_stat = None
    for label in ("marker-stat-held", "marker-stat-mid", "marker-stat-final"):
        row(label)
        parts = out(label).decode().strip().split(":")
        demand(len(parts) == 7 and parts[0] == "regular file" and
               all(part.isdigit() for part in parts[1:]), "marker stat invalid")
        current = tuple(map(int, parts[1:]))
        demand(current[2:5] == (10001, 10001, 600) and current[5] == len(MARKER_CONTENT),
               "marker not private and durable")
        marker_stat = current if marker_stat is None else marker_stat
        demand(current == marker_stat, "marker inode changed")
    for label in ("marker-content-held", "marker-content-mid", "marker-content-final"):
        row(label)
        demand(out(label) == MARKER_CONTENT, "actual workRoot protection marker missing")
    row("lock-stat-held")
    lock_parts = out("lock-stat-held").decode("ascii", "strict").strip().split(":")
    demand(len(lock_parts) == 4 and lock_parts[0] in ("regular file", "regular empty file") and
           lock_parts[1:] == ["10001", "10001", "600"], "real private owner lock missing")
    term = e["term_observation"]
    demand(term["helper_pending"] is True and e["midpoint"]["helper_pending"] is True and
           e["midpoint"]["helper_stdout_bytes"] == 0 and
           e["midpoint"]["monotonic_ns"] - term["monotonic_ns"] >= 31_000_000_000 and
           e["release_monotonic_ns"] > e["midpoint"]["monotonic_ns"],
           "TERM-to-held interval under 31s or helper ended early")
    row(term["poll_label"])
    row("offline-logs-held")
    demand(out("offline-logs-held") == b"", "offline result visible before import release")
    row("offline-events")
    for label in (term["poll_label"], "offline-events"):
        events = [json.loads(line) for line in out(label).splitlines() if line.strip()]
        kills = [event for event in events if event.get("Action") == "kill"]
        demand(len(kills) == 1 and kills[0].get("Actor", {}).get("ID") == cid and
               kills[0].get("Actor", {}).get("Attributes", {}).get("signal") in ("15", "SIGTERM"),
               "one exact-CID SIGTERM Engine event absent in " + label)
    contender = inspect("contender-final", other)
    contender_argv = rows["same-work-contender"]["argv"]
    demand(contender_argv.count("--work-dir") == 1 and
           contender_argv[contender_argv.index("--work-dir") + 1] == work and
           contender_argv.count("--source") == 1 and
           contender_argv[contender_argv.index("--source") + 1] == source and
           contender_argv.count("--image") == 1 and
           contender_argv[contender_argv.index("--image") + 1] == e["expected"]["inner_image_id"],
           "contender did not really target same workRoot/source on original image")
    demand(contender["Image"] == e["expected"]["inner_image_id"] and
           contender["State"]["Status"] == "exited" and contender["State"]["ExitCode"] == 2,
           "same-work contender not a separate completed task")
    demand(obj("same-work-contender", 2) == {"status": "busy"} and
           len(re.findall(rb"maintenance-created name=[^\s]+ container=([0-9a-f]{64})",
                          out("same-work-contender", "stderr"))) == 1,
           "same workRoot did not reject second owner as busy")
    row("release-gate")
    row("verify-helper", 2)
    demand(obj("verify-helper", 2) == {"status": "cancelled"},
           "handled offline cancellation did not return original app result")
    demand(out("offline-logs-final") == out("verify-helper") and
           obj("offline-status") == {"containerId": cid, "imageId": e["qa_image_id"],
                                     "action": "verify", "state": "exited", "exitCode": 2,
                                     "outputText": out("verify-helper").decode().strip()},
           "maintenance-status did not report retained exact task/output")
    for label in ("import-file-absent", "source-hash-final"):
        row(label)
    demand(e.get("cleanup_complete") is True and not e.get("cleanup_errors") and
           not e.get("independent_host_errors"), "fixture cleanup incomplete")
    for kind in ("container", "network", "volume"):
        label = "independent-host-" + kind
        row(label)
        demand(out(label).strip() == b"", "host exact-label resources remain: " + kind)
    return {"status": "limited_pass", "scenario": "handled-term", "offline_id": cid,
            "term_to_midpoint_seconds": (e["midpoint"]["monotonic_ns"] - term["monotonic_ns"]) / 1e9}


def evaluate(run):
    e = json.loads((run / "evidence.json").read_text())
    for name in ("driver.py", "base_driver.py", "oracle.py", "gate.mjs", "inventory.mjs",
                 "gate_availability.mjs", "i3-manifest.json"):
        key = name.removesuffix(".py").removesuffix(".mjs")
        expected = I3_SHA if name == "i3-manifest.json" else e["inputs"]["sha256"][key]
        actual = hashlib.sha256((run / "inputs" / name).read_bytes()).hexdigest()
        demand(actual == expected, "frozen input changed: " + name)
    raw = {}
    for item in e["commands"]:
        for stream in ("stdout", "stderr"):
            path = run / item[stream]
            demand(path.is_file() and path.parent == run / "raw", "missing raw " + item["label"])
            raw[(item["label"], stream)] = path.read_bytes()
    return evaluate_observation(e, raw)


if __name__ == "__main__":
    try:
        print(json.dumps(evaluate(pathlib.Path(sys.argv[1])), sort_keys=True))
    except (KeyError, ValueError, TypeError, IndexError, OSError, UnicodeError, json.JSONDecodeError) as error:
        print(json.dumps({"status": "unverified", "error": f"{type(error).__name__}: {error}"}, sort_keys=True))
        raise SystemExit(1)
