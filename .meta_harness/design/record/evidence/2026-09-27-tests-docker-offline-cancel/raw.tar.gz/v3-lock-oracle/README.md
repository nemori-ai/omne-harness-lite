# DK-I10 handled offline TERM · static candidate v3

The reviewed v2 and its **single failed actual** remain byte-for-byte under
`../docker-offline-cancel-v2/`. Run `20260926T210533Z-631c1011` established
the actual helper PID, its exact-CID direct `docker wait` child via `/proc`, the
offline import FD/inode, marker and owner lock. Its next command, `docker exec
<control> kill -TERM <known PID>`, returned 127 because the fixed control
container has no external `kill` executable. The raw OCI error is in
`../docker-offline-cancel-v2/runs/20260926T210533Z-631c1011/raw/signal-helper.stdout`.
No helper TERM was sent, so the oracle correctly returned `unverified`.
The 278-file original result freeze is `../docker-offline-cancel-v2/actual-run-files.sha256.json`
(SHA256 `ec72e906c38ee318050d6037add5e8ba34bf48fb9201d499a73e058c27b02e58`).
The independent post-run host audit found no exact-label or six named private
resources. Cleanup does not prove normal product settlement.

This v3 is a minimal **static** fixture correction. It invokes the already
available control Node process with `signal_helper.mjs` as `-e` source and the
strictly known positive helper PID. The script calls synchronous
`process.kill(pid, 'SIGTERM')` once. Invalid PID, `ESRCH`, permission failure,
or any other exception exits nonzero; no error is swallowed or reclassified
as a handled cancellation. The oracle requires that exact reviewed source
SHA and exact PID argument, one helper TERM record and one Engine kill event
for the validated CID. The known-PID/direct-child `docker wait` proof remains
unchanged. The QA gate, product image/inventory, workRoot, source, FD/marker,
31-second hold, same-root busy contender, final app/status and cleanup
requirements also remain unchanged. `candidate.diff` shows the only changes
from v2; no product/helper code, control image, package install or policy is
changed. `run-argv-draft.json` is **not authorized** and there is no reviewed
gate in this directory.

The previously unexecuted portion of the scenario uses these external
commands. The control executable availability is grounded as follows:

| After the failed signal point | Executable evidence / remaining uncertainty |
| --- | --- |
| Node synchronous `process.kill` | Node 24 already executed the v2 `/proc` probe; the signal call itself needs its own actual result. |
| Private `docker events`, `inspect`, `exec`, `logs` | Docker CLI/Engine were exercised in v2 setup; exact event/log branches were exercised by prior R5 online IO runs. Offline cancellation semantics remain unobserved. |
| `stat`, `readlink`, `cat`, `test` | Used successfully in v2 before the failed signal. |
| `touch` for QA release | Used successfully by the prior private R5 IO fixture. |
| Official helper `verify` contender, `maintenance-status` | Same packaged helper and private Docker path used in v2; these offline branches have not run in this scenario. A failure is preserved, not retried. |
| `sha256sum` source recheck | The same command succeeded before the signal in v2; final post-release invocation remains unobserved. |

`print-inputs.json` freezes the exact I3 artifact and accepted design/source
inputs; `offline-self-test.json` reports one synthetic positive and 28
rejected counterexamples, including wrong signal PID/source and false success.
`manifest-static.json` hashes every static file other than itself. Root must
review a new exact input hash and issue a new one-shot gate before any actual
run. Helper SIGKILL/caller loss and different-workRoot coexistence are still
outside this scenario and require separate gates.
