// One synchronous SIGTERM to the already-proven helper PID in private control.
const pidText = process.argv[1]
if (!/^[1-9][0-9]*$/.test(pidText)) throw new Error('known positive helper PID required')
const pid = Number(pidText)
if (!Number.isSafeInteger(pid) || pid <= 1) throw new Error('unsafe helper PID')
if (process.kill(pid, 'SIGTERM') !== true) throw new Error('helper TERM was not sent')
