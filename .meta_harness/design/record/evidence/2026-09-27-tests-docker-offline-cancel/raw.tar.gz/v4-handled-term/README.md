# DK-I10 handled offline TERM · static candidate v4

The preceding v3 and its single actual run remain unchanged in
`../docker-offline-cancel-v3/`. That run `20260926T211021Z-0a5cae66`
observed the actual helper TERM, a 31.509434375-second pending interval,
same CID/PID/import FD/inode and marker, a separate same-workRoot `busy`
result, then original app `cancelled`/exit 2 and exact-CID
`maintenance-status` output. Its original oracle is **unverified** because
the file `.owner-lock` had actual `regular empty file:10001:10001:644`
while the oracle demanded `0600`. The original 326-file run freeze is
`../docker-offline-cancel-v3/actual-run-files.sha256.json` SHA256
`326a234330883d01b0f785c68875130731f23856e86e7abd048775c45a153c7c`.
Neither cleanup nor this v4 changes that original result.

Root re-read accepted `realization/packages/infra/storage-sql/maintenance.md`
§工作根 and ruled the `0600` lock-file claim was a measurement addition:
`.owner-lock` is a private empty coordination database, with access controlled
by its private workRoot. The accepted commitments are 0700 for the workRoot,
0600 for `.omne-isolated` and task plaintext, and cross-process exclusion.
The product source `acquireSqliteLock` does not choose a separate lock-file
mode. `candidate.diff` therefore removes only the lock-file `0600` assertion,
retaining actual regular/regular-empty type, exact UID/GID, and recorded mode.
It adds real workRoot `stat` at held and final, requiring `directory`,
UID/GID 10001, mode 0700, and the same device/inode. The existing marker
content/0600/inode, real import FD/0600/inode, direct-child known-CID wait,
one TERM, >31 seconds held, second owner `busy`, exact app/result/status,
and separate cleanup evidence remain. No product, helper, QA gate or private
Engine base code changed. Self-test has two synthetic positives (lock modes
0644/0600) and 32 rejected negatives, including wrong workRoot privacy and
inode.

`diagnostic-v3-copy/` is a byte-identical **copy** of the old run's raw and
input evidence; `diagnostic-v3-copy-files.sha256.json` freezes it.
`diagnostic-relaxed-v3-oracle.py` is the *old* oracle with only the disputed
lock-mode condition relaxed, run against that copy. It reached the old
oracle's `limited_pass` branch, so no further failure in its previously
observed checks was exposed. This is counterfactual diagnosis, **not** a v3
pass or v4 acceptance: v3 did not capture v4's new workRoot stat, and no v4
Docker run has occurred. Raw bytes in the original and diagnostic copy match.

`print-inputs.json`, `offline-self-test.json`, `candidate.diff`, and
`manifest-static.json` are the new review inputs. `run-argv-draft.json` has
no authority and no reviewed gate exists here. A separate root review and
one-shot gate are required before any v4 actual execution. Helper
SIGKILL/caller loss and distinct-workRoot coexistence remain separate DK-I10
scenarios.
