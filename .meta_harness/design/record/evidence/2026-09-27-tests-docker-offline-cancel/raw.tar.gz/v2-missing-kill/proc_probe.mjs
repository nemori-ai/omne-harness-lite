// Read only one known helper PID and its direct children in the private control PID namespace.
import { readFile } from 'node:fs/promises'

const pidText = process.argv[1]
if (!/^[1-9][0-9]*$/.test(pidText)) throw new Error('known positive helper PID required')
const pid = Number(pidText)
if (!Number.isSafeInteger(pid)) throw new Error('helper PID exceeds safe integer')

function argvFrom(raw) {
  if (raw.length === 0 || raw.at(-1) !== 0) throw new Error('process cmdline unavailable')
  return raw.subarray(0, -1).toString('utf8').split('\0')
}

const helperRaw = await readFile(`/proc/${pid}/cmdline`)
const childrenRaw = await readFile(`/proc/${pid}/task/${pid}/children`)
const childrenText = childrenRaw.toString('ascii').trim()
if (childrenText !== '' && !/^[1-9][0-9]*( [1-9][0-9]*)*$/.test(childrenText)) {
  throw new Error('children listing malformed')
}
const childPids = childrenText === '' ? [] : childrenText.split(' ').map(Number)
if (new Set(childPids).size !== childPids.length) throw new Error('duplicate child PID')
const children = []
for (const childPid of childPids) {
  const raw = await readFile(`/proc/${childPid}/cmdline`)
  children.push({ pid: childPid, cmdlineBase64: raw.toString('base64'), argv: argvFrom(raw) })
}
process.stdout.write(JSON.stringify({
  pid,
  helperCmdlineBase64: helperRaw.toString('base64'),
  helperArgv: argvFrom(helperRaw),
  childrenRawBase64: childrenRaw.toString('base64'),
  children,
}) + '\n')
