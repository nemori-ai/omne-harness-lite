# DK-I10 handled offline TERM · static candidate v2

This is a new ignored directory. The original candidate and its **single actual
failed run** remain unchanged under `../docker-offline-cancel/`. Its run
`20260926T205730Z-1836ef3e` stopped at `helper-process-1` rc127; the raw
stdout is `OCI runtime exec failed: ... exec: "ps": executable file not found
in $PATH`. No helper TERM was sent. Oracle returned `unverified`, and forced
fixture cleanup cannot settle the product outcome. The original 253-file
freeze is `../docker-offline-cancel/actual-run-files.sha256.json` (SHA256
`861d563b60b2e109359bac0b3faa915985d120bf67002f29e0dbf70978c8c0dd`).
All exact-label and six named private host resources were absent in the
independent post-run read-only audit.

Only the PID observation has changed. `proc_probe.mjs` is passed as Node 24
source to the **already available** control container. It reads precisely the
known helper PID's `/proc/<pid>/cmdline`,
`/proc/<pid>/task/<pid>/children`, and each listed direct child's cmdline.
It returns both the raw bytes (Base64) and parsed argv as one JSON line. The
driver requires the pidfile, actual Bash helper path/`verify` argv, and one
direct `docker wait <exact CID>` child before sending TERM to that helper PID.
The oracle re-decodes raw bytes, checks child-PID membership in the kernel
children file, the exact command, and the reviewed probe source hash. It
rejects `maintenance-created` alone as a known-ID checkpoint. No `ps`,
procps/apt install, control image rebuild, whole-process scan, or product
change is involved.

The QA image gate, inventory proof, unique private Engine fixture, source
backup generation, 0600 offline import FD/inode hold, workRoot marker and
owner lock, 31-second TERM anchor, same-root busy contender, real app exit,
retained output/status, and separate exact-label cleanup are unchanged.
The old gate and any old reviewed gate are invalid for this v2 input hash.
`candidate.diff` contains only driver/oracle/self-test and new probe source.
`print-inputs.json`, `offline-self-test.json`, and `manifest-static.json` are
the static review inputs; `run-argv-draft.json` is an **unapproved** command
array. The root reviewer must issue a new gate against its exact driver,
oracle and input hashes before a single actual invocation. No Docker/build
was run from this directory.

This remains only the handled `verify` TERM scenario. Helper SIGKILL/caller
loss and different-workRoot coexistence need distinct later scenarios and
authorization. Physical power loss, daemon shutdown races and all filesystem
faults are not covered.
