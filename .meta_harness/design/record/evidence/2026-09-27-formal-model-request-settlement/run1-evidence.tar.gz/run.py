"""Independent frozen-input execution. Writes only beside this script."""

from __future__ import annotations

import concurrent.futures
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time


OUT = Path(__file__).resolve().parent
HUB = OUT.parents[3]
AUTHOR = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-b1-runtime-spec')
JAVA = Path('/opt/java/jdk-21.0.12.1+1-jre/bin/java')
JAR = Path('/opt/tlaplus/tla2tools.jar')
TIMEOUT = 300
EXPECTED = {
    'manifest': '6e42d6508b34d3574bc15727e74e27cb029a568d024d9573a25fc6dfcb75b693',
    'registry': 'f9ac6a5ad2d8601b945cd6ce6887adfdf447aa6c40583b6d2cbc08776de9397c',
    'java': '999c141a6e620c71aa4230ccb62341a89162f37818753ff006d766bf935dcbe1',
    'jar': 'db131ddb48e7004d823bef4493df7b35694babe37505b9d9fa5685e7a331f1f1',
}
FORMAL = 'spec/capabilities/model-request-runtime/v4/formal'
MODEL = f'{FORMAL}/Settlement.tla'
NEGATIVES = {
    'NoCompare': 'LateCorrect',
    'PartialBatch': 'NoOrphanMessage',
    'PartialClaim': 'ClaimsWholeBatch',
    'UnknownAsAbsent': 'UnknownNotAbsence',
    'DropOwner': 'PendingOwned',
    'IgnoreOpened': 'NoSettlementThroughUnknownOpened',
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


def stamp() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def classify(kind: str, oracle: str | None, code: int, output: str, timeout: bool) -> bool:
    if timeout:
        return False
    if kind == 'sany':
        return code == 0 and 'Semantic processing of module Settlement' in output and not re.search(
            r'(?:fatal|semantic|parse|parsing) errors|Abort', output, re.I
        )
    if kind == 'positive':
        return code == 0 and 'Model checking completed. No error has been found.' in output and not re.search(
            r'^Error:', output, re.M
        ) and re.search(r'[\d,]+ states generated, [\d,]+ distinct states found, 0 states left on queue', output) is not None
    return code == 12 and f'Invariant {oracle} is violated.' in output and re.search(
        r'State 1: <Initial predicate>', output
    ) is not None and re.search(r'State 2:', output) is not None


def self_check() -> None:
    samples = [
        ('sany-semantic-success', 'sany', None, 0, 'Semantic processing of module Settlement', False, True),
        ('sany-zero-with-errors', 'sany', None, 0, 'Semantic processing of module Settlement\nSemantic errors:', False, False),
        ('positive-complete', 'positive', None, 0, 'Model checking completed. No error has been found.\n99 states generated, 30 distinct states found, 0 states left on queue', False, True),
        ('positive-zero-empty', 'positive', None, 0, '', False, False),
        ('positive-zero-incomplete', 'positive', None, 0, 'Model checking completed. No error has been found.\n99 states generated, 30 distinct states found, 1 states left on queue', False, False),
        ('negative-specific-trace', 'negative', 'LateCorrect', 12, 'Error: Invariant LateCorrect is violated.\nState 1: <Initial predicate>\nState 2: <Boundary>', False, True),
        ('negative-wrong-invariant', 'negative', 'LateCorrect', 12, 'Error: Invariant TypeOK is violated.\nState 1: <Initial predicate>\nState 2: <Boundary>', False, False),
        ('negative-no-trace', 'negative', 'LateCorrect', 12, 'Error: Invariant LateCorrect is violated.', False, False),
        ('negative-parser-exit', 'negative', 'LateCorrect', 12, 'Error: Parsing or semantic analysis failed', False, False),
        ('timeout-not-pass', 'negative', 'LateCorrect', 12, 'Error: Invariant LateCorrect is violated.\nState 1: <Initial predicate>\nState 2: <Boundary>', True, False),
    ]
    rows = []
    for name, kind, oracle, code, output, timed_out, expected in samples:
        actual = classify(kind, oracle, code, output, timed_out)
        rows.append({'name': name, 'expected': expected, 'actual': actual, 'matched': actual == expected})
    dump(OUT / 'classifier-self-check.json', rows)
    assert all(row['matched'] for row in rows)


def prepare() -> dict:
    manifest = AUTHOR / 'tmp/model-request-runtime/b1-runtime-spec/output-sha256.json'
    registry = AUTHOR / 'tmp/model-request-runtime/b1-runtime-spec/registry-candidate.json'
    assert sha(manifest) == EXPECTED['manifest']
    assert sha(registry) == EXPECTED['registry']
    assert sha(JAVA) == EXPECTED['java']
    assert sha(JAR) == EXPECTED['jar']
    snapshot = OUT / 'inputs'
    snapshot.mkdir(exist_ok=True)
    rows = []
    by_path = {}
    candidate = json.loads(manifest.read_text())['files']
    assert len(candidate) == 29
    frozen_path = AUTHOR / 'tmp/model-request-runtime/b1-runtime-spec/input-sha256.json'
    author_inputs = json.loads(frozen_path.read_text())
    frozen_registry = AUTHOR / '.meta_harness/design/registry/frozen.json'
    frozen = [
        {'path': f'.meta_harness/design/{path}', 'sha256': digest}
        for path, digest in json.loads(frozen_registry.read_text())['files'].items()
        if path.startswith('spec/capabilities/model-request-runtime/')
        or path.startswith('spec/capabilities/session-log/')
    ]
    assert len(frozen) == 64
    for group, entries in [('candidate', candidate), ('frozen', frozen), ('author-inputs', author_inputs)]:
        for row in entries:
            original = AUTHOR / row['path']
            if row['path'] == 'RT4-CONSTRUCTION-BRIEF.md':
                original = AUTHOR / 'tmp/model-request-runtime/b1-runtime-spec/inputs/RT4-CONSTRUCTION-BRIEF.md'
            actual = sha(original)
            assert actual == row['sha256'], (group, row['path'], actual)
            dest = snapshot / row['path']
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, dest)
            assert sha(dest) == actual
            by_path[row['path']] = actual
            rows.append({'group': group, 'path': row['path'], 'source': str(original), 'sha256': actual, 'bytes': original.stat().st_size})
    inherited_file = AUTHOR / 'tmp/model-request-runtime/b1-runtime-spec/unchanged-formal-resources.json'
    inherited = json.loads(inherited_file.read_text())
    assert len(inherited) == 13
    for row in inherited:
        assert sha(AUTHOR / row['source']) == sha(AUTHOR / row['target']) == row['sha256']
    for file in [manifest, registry, frozen_path, frozen_registry, inherited_file,
                 AUTHOR / 'tmp/model-request-runtime/b1-runtime-spec/rt3-to-rt4.diff',
                 AUTHOR / 'tmp/model-request-runtime/b1-runtime-spec/HANDOFF.md',
                 HUB / 'tmp/model-request-runtime/b1-late-coordination/RT4-INDEPENDENT-REVIEW-BRIEF.md',
                 HUB / 'tmp/model-request-runtime/b1-late-coordination/RT4-CONSTRUCTION-BRIEF.md']:
        rel = f'metadata/{file.name}'
        dest = snapshot / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(file, dest)
        rows.append({'group': 'metadata', 'path': rel, 'source': str(file), 'sha256': sha(file), 'bytes': file.stat().st_size})
    for rel in [
        '.meta_harness/design/realization/packages/model/model-request-runtime/v3-design.md',
        '.meta_harness/design/realization/packages/model/model-request-runtime/verification.md',
        '.meta_harness/design/realization/packages/session/session-log-jsonl/v3-design.md',
        '.meta_harness/design/realization/packages/session/session-log-jsonl/verification.md',
        '.meta_harness/design/record/decisions/session-log-tail-condition-adoption/decision.md',
        '.meta_harness/design/record/decisions/session-log-jsonl-v3-projection-adoption/decision.md',
        '.meta_harness/design/registry/catalog.json',
    ]:
        src = HUB / rel
        dest = snapshot / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dest)
        rows.append({'group': 'supplemental-hub', 'path': rel, 'source': str(src), 'sha256': sha(src), 'bytes': src.stat().st_size})
    dump(OUT / 'inputs-before.json', {'time': stamp(), 'candidate_count': 29, 'frozen_count': len(frozen), 'author_input_count': len(author_inputs), 'inherited_count': 13, 'rows': rows})
    return json.loads(registry.read_text())


def run_one(task: dict) -> dict:
    run_dir = OUT / 'runs' / task['id']
    run_dir.mkdir(parents=True)
    cwd = OUT / 'inputs/.meta_harness/design'
    argv = task['argv']
    start = stamp()
    clock_start = time.monotonic()
    meta = {'id': task['id'], 'kind': task['kind'], 'oracle': task.get('oracle'),
            'argv': argv, 'cwd': str(cwd), 'start': start, 'timeout_seconds': TIMEOUT,
            'java_sha256': sha(JAVA), 'jar_sha256': sha(JAR),
            'model_sha256': sha(cwd / MODEL)}
    if task.get('config'):
        meta['config_sha256'] = sha(cwd / task['config'])
    dump(run_dir / 'started.json', meta)
    timed_out = False
    with (run_dir / 'stdout.log').open('wb') as stdout, (run_dir / 'stderr.log').open('wb') as stderr:
        proc = subprocess.Popen(argv, cwd=cwd, stdout=stdout, stderr=stderr, start_new_session=True)
        meta['pid'] = proc.pid
        dump(run_dir / 'started.json', meta)
        try:
            code = proc.wait(timeout=TIMEOUT)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                code = proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                code = proc.wait()
    stdout_text = (run_dir / 'stdout.log').read_text(errors='replace')
    stderr_text = (run_dir / 'stderr.log').read_text(errors='replace')
    output = stdout_text + '\n' + stderr_text
    counts = re.findall(r'([\d,]+) states generated, ([\d,]+) distinct states found, ([\d,]+) states left on queue', output)
    state_numbers = re.findall(r'^State (\d+):', output, re.M)
    result = {**meta, 'end': stamp(), 'duration_seconds': time.monotonic() - clock_start,
              'exit_code': code, 'timed_out': timed_out, 'terminal': True,
              'machine_oracle_pass': classify(task['kind'], task.get('oracle'), code, output, timed_out),
              'state_counts': [{'generated': int(g.replace(',', '')), 'distinct': int(d.replace(',', '')), 'queued': int(q.replace(',', ''))} for g, d, q in counts],
              'trace_state_count': len(state_numbers),
              'stdout_sha256': sha(run_dir / 'stdout.log'), 'stderr_sha256': sha(run_dir / 'stderr.log')}
    if state_numbers:
        trace = output[output.index('State 1:'):]
        (run_dir / 'trace.txt').write_text(trace)
        result['trace_sha256'] = sha(run_dir / 'trace.txt')
    dump(run_dir / 'result.json', result)
    print(json.dumps({'id': task['id'], 'exit': code, 'timeout': timed_out,
                      'machine_oracle_pass': result['machine_oracle_pass'], 'state_counts': result['state_counts'][-1:]}, ensure_ascii=False), flush=True)
    return result


def after_check() -> None:
    before = json.loads((OUT / 'inputs-before.json').read_text())
    checks = []
    for row in before['rows']:
        source = Path(row['source']) if 'source' in row else AUTHOR / row['path']
        checks.append({'group': row['group'], 'path': row['path'], 'source_sha256': sha(source),
                       'snapshot_sha256': sha(OUT / 'inputs' / row['path']),
                       'expected_sha256': row['sha256'],
                       'matched': sha(source) == sha(OUT / 'inputs' / row['path']) == row['sha256']})
    dump(OUT / 'inputs-after.json', {'time': stamp(), 'checks': checks, 'all_matched': all(row['matched'] for row in checks)})
    assert all(row['matched'] for row in checks)


def main() -> None:
    self_check()
    registry = prepare()
    for name, argv in [('java-version', [str(JAVA), '-version']),
                       ('tlc-version', [str(JAVA), '-cp', str(JAR), 'tlc2.TLC', '-help'])]:
        run = subprocess.run(argv, capture_output=True, text=True, timeout=30, cwd=OUT)
        (OUT / f'{name}.stdout.log').write_text(run.stdout)
        (OUT / f'{name}.stderr.log').write_text(run.stderr)
        dump(OUT / f'{name}.json', {'argv': argv, 'cwd': str(OUT), 'exit_code': run.returncode})
        if name == 'java-version':
            assert run.returncode == 0 and '21.0.12.1' in run.stderr
        else:
            # This pinned TLC returns 1 for help; that is not a model result.
            assert run.returncode == 1 and 'Version 2026.09.12.025210' in run.stdout
    results = []
    sany = {'id': 'sany-settlement', 'kind': 'sany',
            'argv': [str(JAVA), '-cp', str(JAR), 'tla2sany.SANY', MODEL]}
    results.append(run_one(sany))
    if not results[-1]['machine_oracle_pass']:
        dump(OUT / 'results.json', results)
        after_check()
        raise RuntimeError('SANY did not satisfy the specified oracle; dependent runs stopped')
    positives = []
    for row in registry['formal_tasks_append']:
        if '-settlement' not in row['id']:
            continue
        argv = row['command'].copy()
        argv[0] = str(JAVA)
        argv[argv.index('-cp') + 1] = str(JAR)
        argv[argv.index('-metadir') + 1] = str(OUT / 'metadir' / row['id'])
        positives.append({'id': row['id'], 'kind': 'positive', 'argv': argv,
                          'config': argv[argv.index('-config') + 1],
                          'registry_timeout_seconds': row['timeout_seconds']})
    assert len(positives) == 3
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results.extend(pool.map(run_one, positives))
    dump(OUT / 'results.json', results)
    if not all(row['machine_oracle_pass'] for row in results):
        after_check()
        raise RuntimeError('Positive failure/timeout: candidate not modified; dependent runs stopped')
    negatives = []
    for mutation, oracle in NEGATIVES.items():
        task_id = f'settlement-negative-{mutation}'
        config = f'{FORMAL}/validity-check/Settlement_{mutation}.cfg'
        argv = [str(JAVA), '-cp', str(JAR), 'tlc2.TLC', '-metadir', str(OUT / 'metadir' / task_id),
                '-cleanup', '-noGenerateSpecTE', '-workers', '1', '-config', config, MODEL]
        negatives.append({'id': task_id, 'kind': 'negative', 'oracle': oracle, 'argv': argv, 'config': config})
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        results.extend(pool.map(run_one, negatives))
    dump(OUT / 'results.json', results)
    after_check()
    assert all(row['machine_oracle_pass'] for row in results)


if __name__ == '__main__':
    main()
