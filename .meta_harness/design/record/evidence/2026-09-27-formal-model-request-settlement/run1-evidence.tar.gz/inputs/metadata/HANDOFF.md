# RT4 candidate handoff

- Spoke: `/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-b1-runtime-spec`
- Branch/base: `panqiwei/model-request-runtime-b1-runtime-spec` / `976534bf17190bbfdaf9e3b87c5abbc2aa70b552`.
- Candidate: `.meta_harness/design/spec/capabilities/model-request-runtime/v4/`; 73 clauses, 13 unchanged service operations with nine items, 27 version resources plus 2 navigation inputs.
- Final contract SHA256: `27f547649025f9a7c94a499355ed25a94c72fed01e875a263e0a38cc0add8772`.
- Final `output-sha256.json` SHA256: `6e42d6508b34d3574bc15727e74e27cb029a568d024d9573a25fc6dfcb75b693`.
- `registry-candidate.json` SHA256: `f9ac6a5ad2d8601b945cd6ce6887adfdf447aa6c40583b6d2cbc08776de9397c`.
- `rt3-to-rt4.diff` SHA256: `a97e4e217707afa58345b1ca6305c25c66f91513785cd6e299a9acfe2147de79`.
- No acceptance, commit, push, TLC, paid call, actual registry change, source implementation or provider binding.

## Decisions consumed and author deductions

D081/D083 and the full RT4 brief own the fourth argument, actual-commit late, THIS-batch zero, whole-batch recognition, old-unknown gate, no hidden retry or new domain state, and all-writer propagation. S-68 derives explicit unconditional for ordinary/noRun writes from RT3's unchanged original predicate and identity obligations; S-72 derives each operation's unavailable/unfinished handling from RT3 S-17/S-29/S-30/S-31/S-33/S-36/S-49. Root confirmed both deductions in task messages. Named contention strategy stays abstract: caller/reply owner supplies identifiable replaceable policy, no new official system name, DTO or operation. Root corrected earlier policy clause citation from SL3 S-36 to S-35.

All 17 dependencies stay at RT3's exact coordinates except session-log 2→3; SL clauses add S-9 and S-32..37. Candidate registry contains one catalog entry, 55 reviewed=false covers, no new namespace, six positive formal tasks (three unchanged copied RT3 models and three new Settlement configurations). Central registry remains unchanged. S-54..S-67 byte equality and all 13 copied TLA/cfg byte equality are checked. `unchanged-formal-resources.json` lists source/target/hash.

## Actual checks

- `final-checks.json` binds argv/cwd/exit/output; candidate check, `check_design --gate internal --formal skip`, and `git diff --check`: all exit 0.
- `candidate-check.json`: 73 clauses, 13 nine-item operations, 930 local links, 27 resources, 17 dependencies, 55 covers, six positive task candidates; 64 frozen RT2/RT3/SL2/SL3 resources unchanged and 13 inherited formal files unchanged; errors empty.
- `sany-settlement-run-1.json` and raw `.log`: SANY exit 0, no parsing/semantic errors; exact Java and JAR hashes match root's supplied values. Settlement model SHA `345bec05910174cfd0e27509b0cb2f753b4ea218ebf6077724d8af9330fe5c86`.
- TLC not run. Three new positive and six negative configs await independent execution; specific oracle names and assumptions are in the formal README. No fairness/liveness claim. Actual StopOld, Run recognition, IO/auth/codec and all-operation implementation remain outside the finite model.
- Initial structural failure (new verification anchor not yet present) is preserved in `candidate-check-initial.json`; fixed by adding the permitted verification section. Intermediate manifest retained separately and is not the final review input.

## Scope and remaining owners

- G-28 production Run-end recognizer: original loop/Run facts owner. RAF2 booleans are not a same-prefix input; model_call_ended is not Run-ended.
- G-29 common identity/read/dedupe codec, shared physical log and actual old-writer stop/recovery evidence: runtime, external reply writers, log/provider, mainline.
- G-30 legal full-prefix read/authorization: access/host/log and actual settlement owners.
- G-31 multi-valued TransportFailure headers vs MR4 string-map: original runtime/response representation owner. No join/first/drop/array policy chosen.
- Other inherited RT3 gaps remain. No new product question, vocabulary or required name was invented.
- D084 postdates this spoke base; read-only supplemental decision snapshot is preserved separately. The candidate follows the stable JSONL node entry for current adoption and does not treat that adoption as real IO/Run/codec/stop verification. Root integration must retain D084 alongside this package; no source/provider files were changed here.

`consumer-impact.md` gives precise runtime/SL/reply/runner/application propagation and stop/switch order. This is ready for independent architecture/spec review and formal execution; still candidate and not accepted.
