# RT4 精确候选：独立评审与有限形式执行

作者已停止修改。只读候选在 `/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-b1-runtime-spec`，branch panqiwei/model-request-runtime-b1-runtime-spec，base976534bf。HUB6f4已包含D084；remote main最新edee5bb7、落后0，未带main未提交修改。

主线建设简报 `RT4-CONSTRUCTION-BRIEF.md`；作者交接 `tmp/model-request-runtime/b1-runtime-spec/HANDOFF.md`。候选完整27资源+2导航共29项，output-sha256 manifest SHA256 `6e42d6508b34d3574bc15727e74e27cb029a568d024d9573a25fc6dfcb75b693`；contract `27f547649025f9a7c94a499355ed25a94c72fed01e875a263e0a38cc0add8772`；registry candidate `f9ac6a5ad2d8601b945cd6ce6887adfdf447aa6c40583b6d2cbc08776de9397c`。新 Settlement TLA `345bec05910174cfd0e27509b0cb2f753b4ea218ebf6077724d8af9330fe5c86`。主线现场核29资源全匹配后才派发；中间manifest不使用。

## 判定对象与边界

D076 RT3及MS4/MR4/MP3、D081方向、D083 SL3为已接受输入；D084是日志实现投影采用，并未验证真实IO。读RT3→RT4 diff、全候选contract/examples/formal/consumer-impact与相关旧责任；全部13操作必须保持。仅17依赖中的SL2→SL3改变；新S68–73及G28–31，把全结算方、同次合法完整前缀与提交尾比较、THIS零写、未知完整批认回和争用策略责任落实到各操作。noRun/普通记录unconditional为主线确认的旧义推导，不凭这一确认免除逻辑/表达评审。

争用策略依SL3 S35，由消费者显式提供具名可替换策略，数值/算法/预算归该owner，无新官方默认名。G28生产Run认法、G29共同codec/物理组合及旧writer停止、G30合法完整读权、G31多值headers表示仍留原owner，不能用fixture/布尔或候选存在宣称已闭合。不改37范围/参数/模态、AR3、其他数据Schema或产品规则。v2/RT3/SL2/SL3 64冻结输入、13继承TLA/cfg须无漂移。

architecture-reviewer：读作为语义整体的消费者契约增量，检查性质承载/内核负面/边界与代价/反向性质对齐、全部结算方和unknown强门。不写/修/接受/运行形式。四组发现、精确依据、最强反方及改票条件；明确真IO/Run等范围不属于本次模型证明。

spec-reviewer：以已决定属性为前提，核13操作九件事、73本地条款、引用/版本/候选registry/消费者完整路径/例子/形式对应。检查普通/noRun与各操作失败映射表达一致，是否把未完成责任错误改成成功/释放/可重发；区分新义和旧继承。不写/修/接受，不用architecture评审代替表达判断。四组发现并列实际未检查范围。

两位reviewer仅只读所有文件，消息交回；不共同协商先统一判断、不写报告，主线标明摘要来源并保全。作者修订后再定向复核。

## verification-developer：独立真实形式执行

唯一写 HUB `tmp/model-request-runtime/b1-late-coordination/rt4-formal-run-1/**`（自己的运行/报告/工具脚本），不改任何候选、测试、registry、绑定、产品、源代码或旧证据，不接受/提交/push/付费。你不是唯一执行者，不回退他人。输入冻结并抄存29项及相关既有规范，先/后核hash。

构造顺序：验证工具及输入→先新 Settlement SANY→3正TLC→6指定负控TLC→亲读所有反例→核模型/配置和哈希→报告。旧13逐字复用形式文件仅核hash与范围，当前不重跑/不冒称新证据。

JAVA_BIN=/opt/java/jdk-21.0.12.1+1-jre/bin/java（SHA999c141a6e620c71aa4230ccb62341a89162f37818753ff006d766bf935dcbe1）；JAR=/opt/tlaplus/tla2tools.jar（SHAdb131ddb48e7004d823bef4493df7b35694babe37505b9d9fa5685e7a331f1f1）。工具路径/hash/版本现场核。各TLC `-workers 1`，3正使用候选registry argv/对应cfg，6负按formal README唯一cfg及断言；独立metadir不改模型常量/不变量/公平性。最多3进程并行；每任务测量期限300s，超时如实记录，不减scope/改cfg求绿，不因观察wait超时重启活进程。SANY期望解析/语义正常0，不能只核退出码。正TLC期望完成状态空间无反例0；负期望12且具体Assertion被违反和真实反例轨迹，不把解析/loader/其他异常算Pass。

六负对应：NoCompare→LateCorrect；PartialBatch→NoOrphanMessage；PartialClaim→ClaimsWholeBatch；UnknownAsAbsent→UnknownNotAbsence；DropOwner→PendingOwned（已提交尝试耗尽，不能初始取消假命中）；IgnoreOpened→NoSettlementThroughUnknownOpened。逐条保存stdout/stderr/argv/cwd/start/end/exit/timeout/statecounts/distinct/trace，并亲判交错、变化、指定oracle。新模型只有有限安全/责任，无公平性/无饥饿/生产Run/真实停止/实际IO/所有13ops实现证明。输出四态判定+逐入口表+未覆盖+测量器自检；发现反例/测量问题报告root，不自行改候选或重新定义oracle。
