# B1：模型 runtime 精确消费 SL3 的候选规格施工简报

本次责任是既有 model-request-runtime 的必要消费演进，非新能力拆分，不展开通用资产或完整 Agent Loop。用户授权先规格/投影、独立评审及主线技术采用，再实施；作者不得接受自己成果。执行spoke `model-request-runtime-b1-runtime-spec`，base HUB `976534bf17190bbfdaf9e3b87c5abbc2aa70b552`；不是唯一参与者，不回退他人。

## 输入与权威

- D076已接受RT3、MS4、MR4、MP3及相关13操作/独立函数/首内容门；从当前registry取精确资源与hash，不沿topic旧candidate文字判断接受。
- D081已选择实际提交点尾条件方向；现有proposal `late-coordination.md` 为候选比较及四表理由，不替代D083规范。
- D083已接受SL3全部37条/24精确资源；contract SHA `f327f1289e1d6c539dd959e8862b382869e3d303cf984b6a773fdd6a00e4bd26`。S32..37明确必填第四实参、same-commit优先级、完整前缀、THIS零写、unknown、有限进展和迁移。
- RT3 S8/S17/S29/S30/S31/S33/S36/S38/S49的全部结算方，runtime节点v3-design的L2/L3/L4/L5/L7、Q2/Q3和日志v2-design的G2-2/6/7是消费定位输入。只读审计已经确定RT3钉SL2，必须新RT版本；MS4/MR4/CA2不因condition自动升版。
- RAF2 S2/S5②/G3与run-attempt-facts-derived节点明确生产Run终结认法未定；model_call_ended不是Run终结。日志原payload不透明。既有37模型/参数/缓存和目录AR3依赖不在本次改票范围。

## 目标与可写边界

起草完整可审 `spec/capabilities/model-request-runtime/v4/`：contract、examples、formal入口与必要行为工件、consumer-impact；只在该topic README/verification追加候选入口。临时任务/manifest/hash/registration-candidate归本spoke tmp/model-request-runtime/b1-runtime-spec/**。不改冻结v2/v3、SL任何版本、其它data/capability/product/词表/registry/realization/实现/依赖锁；不提交/付费/push/接受。需要改变上述输入则停该依赖部分，向root报告具体语义归属，不填默认。

保留13服务操作、既有输入输出和失败词表、所有原先未受影响承诺；独立invokeModel仍无日志依赖。当前版本替换SL规范坐标与必要消费条款，并显式表达已接受组合的以下属性；不是只换catalog依赖。

## 必须表达的验收清单

1. 全部实际append写者必须显式condition，旧三参数不兼容。既有fence分类不变：两个锚点、intent/call-ended fenced；响应/账unfenced。与late无关的普通记录如何显式调用须从其已决定原义推导并标依据；若无法推导，登记owner缺口，不由作者补新业务政策。
2. 所有withRun响应提交方：普通失败/无回复中断、interrupt、host撤除、reconcile、settleReply vetoed/consumed和调用方persisted助手消息＋响应批。它们共同从合法同次完整前缀或owned密集前缀追补取得事实及tail，以原发出attempt和Run事实解释late，再以unfenced+tailEquals完整批提交；不能把RAF两个bool和另取tail拼起来。无run保持原late缺席承诺、唯一主体/完整批语义，不增加Run伪身份。
3. tailChanged是内部存储争用、本次批零写，不成为ModelResponse上游故障或模型重发许可；保留同ResponseId/MessageId、原binding/参数/收场/金额。未提交批可按新合法前缀重构late，已提交获胜批绝不改写。恢复/重交先认回既有完整批：部分撞键、另一次尾冲突、unknown回执均不证明旧批已/未提交。
4. 不新增领域状态或失败值。策略耗尽、取消、日志或合法前缀不可得时如实沿原unavailable/原未完成阶段返回，保留耐久锚点、稳定身份及原owner恢复责任；未完成不得报已结算/释放为可重发。reply_pending和其S49失败保持不改收场；其它操作按原失败/恢复时机表达，关键映射无法从原条款与D083确定时列gap停依赖，不挑便利结果。
5. 争用重试/退避/时间和资源预算由消费者具名显式配置、可替换策略拥有；无固定次数、默认值或无限紧循环。不得复用模型请求默认重试件当日志争用处理。进展前提是实际有可得提交机会；公平调度不等于无饥饿。策略具体数值不是本能力权威；配置缺失时无法开始相应推进，不偷填。
6. unknown opened强门原样保留并传播到所有结算方：旧网络、门回调、append和潜在unfenced结算写者必须实际停止/权威恢复，不能以Signal/outcome/fiber卸载/fence替代。恢复读完整事实，anchor未知时不能交内容、写普通response、交模型retry或重发。SL3后次确定拒绝只说明后次THIS零写。
7. 同一物理日志承担compare/wholebatch/durable、全写方共同codec/稳定identity/原值认回。能力只规定语义与键等价，不发明未定精确业务键编码；codec归provider/全部写方投影，G2-2未验保持。生产Run终结认法/合法读权缺口显式依赖原owner，fixture认法不变正式保证。S38/L/Q消费者义务不可只写日志实现自包通过。
8. G2-6 TransportFailure多值headers与MR4 string-map表示仍开放，不能拼接/取首/丢头/保存数组代其owner选择。本轮不借condition改MR/CA/MS Schema、不重新选存储、不加日志操作或业务回调。
9. 完整实例覆盖两种先后、两个结算方竞争同一ResponseId、persisted整批无孤消息、key碰撞不等于全批认回、无run、有旧unknown/物理writer、无关追加争用及策略耗尽，success/各failure/未知前提明确。不把程序化sample当生产Run认法。

## 构造、形式与交接

先保全必要input hash与本brief，列RT3→RT4语义delta/逐操作9项走查；定位每项承诺归属与旧未决。只修改当前delta，v4完整表达沿精确已接受输入展开，所有未改变依赖维持原精确坐标，SL3依赖clause列表与正文匹配。独立旧消费者runner3只读RT3 S24/S30/S50/S67关系保留，不能自动改采用。consumer-impact明确日志/runtime/回复/runner/验收应用实际版本传播和停止顺序。

已触发结算时序/唯一性行为模型，补实际TLA及正cfg/故意打破compare/wholebatch/unknown认回/耗尽职责的负cfg。真实Run识别、物理StopOld、文件IO和权限可作为明确前提，不宣称模型证明它们。现有Invocation/Adaptation/ContentGate/Validity若复用必须写范围、引用旧有限run且不冒称v4执行；新模型可引用SL3的行为权威，不能以其存在代runtime模型义务。这里只运行作者可完成的结构/解析检查，实测独立形式执行由root另派；实际发生输入、argv、原始失败保全tmp，不写进冻结候选规范。

语言中立，无capability JSON Schema（在线wire归composition）。登记候选放tmp，不动中央catalog/frozen/covers/formal-tasks；新S/G编号仅本包local采用既有namespace约定、不造系统身份。完整双语词条沿统一语言查名，无新概念自行取名。最终交付精确资源manifest、contract/hash/diff、逐验收覆盖、未定/停止清单、candidate registry与独立检查日志供root安排architecture/spec review。作者不接受、不扩大到完整P4或解除B1。
