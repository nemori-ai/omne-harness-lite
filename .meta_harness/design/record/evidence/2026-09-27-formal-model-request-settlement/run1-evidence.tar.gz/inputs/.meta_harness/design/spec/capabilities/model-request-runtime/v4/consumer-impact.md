# RT4 的精确消费者传播

本候选从 D-076 已接受 RT3/SL2 演进到 RT4/SL3；SL3 由 D-083 接受。此处说明采用者须做的变化，不将新规范、已采用投影与实现符合性合成一个状态。实际采用仍查各入口与 registry，推荐版本不自动升级消费者。

| 消费者/输入 | 本候选保持或改变的精确关系 | 负责产物及完成条件 |
|---|---|---|
| RT3 十三操作，独立 invokeModel/构件 | RT4 保留 S-24～S-34/S-49/S-50 与 S-53～S-67；纯函数零日志依赖；新增 S-68～S-73 不成为第十四个操作 | runtime spec/provider owner；逐操作九项复核、失败/未完成状态与函数独立消费场景 |
| session-log | 唯一升级的规范依赖是 SL2→SL3；原 S-6/8/10/13/14/17/19/22/23，加 S-9、S-32～S-37 | 日志三操作提供者；所有 append 调用显式第四参数；同一物理日志的比较/批次/持久与恢复证据，采用入口见 [JSONL 节点](../../../../realization/packages/session/session-log-jsonl/README.md) |
| runtime 提供者 | [v3-design](../../../../realization/packages/model/model-request-runtime/v3-design.md) L-2/L-3/L-4/L-5/L-7、Q-2/Q-3 的消费必须另立并采用 RT4/SL3 新投影；仅替换日志依赖名不够 | runtime/host owner；覆盖所有结算者、unknown opened 强门、真实停止、争用配置/耗尽与 S-33 对账时机 |
| 外部 persisted 回复写方 | MessageId+ResponseId 完整批同提交；withRun 同次完整前缀+tailEquals，noRun 显式 unconditional；全部写方共同键与原批认回 | loop/回复消费者 owner；消息与响应两种胜出顺序均无孤消息，无新模型请求；真实回复路径明确采用 |
| model-response v4 / messages v4 / call-accounts v2 | 原收场、late、身份/壳归属及回复完整批含义不变；condition 不要求数据升版 | 各 data owner；本轮不改 Schema；多值 headers 沿原 owner 缺口处理，不因日志可存数组而闭合 |
| 其余十六项 RT3 依赖 | 精确坐标和消费 clauses 保持；模型适配37条目录、参数/缓存政策、AR3 不改 | 原消费者继续采用原范围；没有整片资产扩展或自动模型认证 |
| run-attempt-facts v2 | 其独立读取的两个 bool 不足以充当 RT4 完整前缀；本契约不新增对 RAF2 的规范依赖、不改其旧消费者 | 原 Run/loop owner 补真实终结认法；G-28 及原 RAF2 G-3 保留，测试种子不等于生产认法 |
| loop-extension-runner v3 | 仍精确消费 RT3 的合法目标、发出守卫、S-67 默认件身份；没有自动采用 RT4 | runner owner 对 S-24/S-30/S-50/S-67 做反向核对并显式选版；其自己写日志仍须 SL3 第四参数，不得因 guard 兼容省掉 writer 迁移 |
| 验收应用/宿主 | 配置实际争用政策，具有合法完整读取，调用 S-33 两种既有恢复时机；Run fixture 范围明示 | 应用 owner；真实 JSONL/runtime/外部回复/runner 的组合场景及原失败原始证据，不以 mock 或模型代真 IO |

## 必须保持的停止与切换顺序

1. 先完成 RT4、提供者与全部实际写方的精确采用；检查共同业务键和读取键、消息/响应全批认回、显式 condition、owner 策略与失败传播。缺任何一项，不在同一日志根混用三参数和四参数消费面。
2. 关闭旧业务准入，实际停止旧网络读取、门回调、追加与潜在 unfenced 结算者；不能仅以取消、函数 outcome、运行时撤除或新 fence 认作停止。已有 durable 锚点/意图和未知责任保留；不补假响应。
3. 日志 owner 按被采用的生命周期协议关闭准入、排空旧任务、完成旧物理写者停止与资源/所有权交接，由新 owner 独占恢复真实日志。写入不可信时旧确认尾不能证明缺席；无法确认恢复条件保持 unavailable。
4. 在原 S-33 新尝试/重新承载时机权威读回；带 Run 时另确认共同日志新尝试的有效 fence。所有历史响应按稳定身份认回原批；未提交批才按新合法前缀重构 late。无 Run 保留独占重新承载与 late 缺席。
5. 所有应对账项收口后才按原守卫允许新的推进。接线变更不创造模型重发许可，不加载新模型版本重写旧绑定，也不把历史 JSON 记录升级成新业务值。

## 证据和停止边界

规范新有限模型只证明其已执行范围内的性质；作者交付时正式形式执行未开始。真实文件比较/持久、合法授权、共同 codec、生产 Run 认法、实际停止、TransportFailure 头表示仍分别由 G-28～G-31 和既有 owner 承担。模型 StopOld 只是明确的环境动作；无饥饿不在全尾争用承诺内。若合法前缀、共同日志或实际提交机会不能成立，沿 D-081 改票条件返回主线，不删除不变量以放行。
