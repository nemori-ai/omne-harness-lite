"""Seal and read back this completed run without executing any model again."""
from pathlib import Path
import datetime as dt
import gzip
import hashlib
import io
import json
import os
import re
import tarfile

out = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(name, obj):
    (out / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


manual = {
    'NoCompare': {'oracle': 'LateCorrect', 'valid_target_counterexample': True,
                  'interpretation': 'superseded precedes response, late false, expectedTail 1 vs actualTail 2',
                  'actions': ['Prepare(1)', 'Boundary', 'Submit(1)', 'Process(1)']},
    'PartialBatch': {'oracle': 'NoOrphanMessage', 'valid_target_counterexample': True,
                     'interpretation': 'message without response; actor 2 marks done',
                     'actions': ['Prepare(2)', 'Submit(2)', 'Process(2)']},
    'PartialClaim': {'oracle': 'ClaimsWholeBatch', 'valid_target_counterexample': True,
                     'interpretation': 'claim 2 while only message committed; no whole response batch',
                     'actions': ['Prepare(2)', 'Submit(2)', 'Process(2)']},
    'UnknownAsAbsent': {'oracle': 'UnknownNotAbsence', 'valid_target_counterexample': False,
                        'interpretation': 'Recover successor has unsafeAbsence null; old pending writer not stopped',
                        'actions': ['Prepare(1)', 'Submit(1)', 'LoseAck(1)', 'Recover(1)']},
    'DropOwner': {'oracle': 'PendingOwned', 'valid_target_counterexample': True,
                  'interpretation': 'spent 1 reaches Budget 1 after attempted submit, no response, Exhaust drops owner',
                  'actions': ['Prepare(1)', 'Boundary', 'Submit(1)', 'Process(1)', 'Exhaust(1)']},
    'IgnoreOpened': {'oracle': 'NoSettlementThroughUnknownOpened', 'valid_target_counterexample': True,
                     'interpretation': 'response committed while anchorKnown false and anchorPending true',
                     'actions': ['Prepare(1)', 'Submit(1)', 'Process(1)']},
}
for name, row in manual.items():
    rel = f'runs/settlement-negative-{name}/trace.txt'
    trace = (out / rel).read_text()
    actions = re.findall(r'^State \d+: <([^ ]+)', trace, re.M)[1:]
    assert actions == row['actions']
    row.update({'trace_path': rel, 'trace_sha256': sha(trace.encode()),
                'read_by': '/root/b1_rt4_formal_verification',
                'human_interpretation_recorded_by_verification_agent': True})
    if name == 'DropOwner':
        assert 'CancelPolicy' not in trace and '/\\ spent = <<1, 0>>' in trace
        assert '/\\ owner = <<FALSE, TRUE>>' in trace
    if name == 'UnknownAsAbsent':
        assert '/\\ unsafeAbsence = null' in trace and 'StopOld' not in trace
dump('trace-assessment.json', manual)
results = json.loads((out / 'results.json').read_text())
assert len(results) == 10
assert [r['exit_code'] for r in results] == [0, 0, 0, 0, 12, 12, 12, 75, 12, 12]
dump('terminal-process-check.json', {
    'checked_at': dt.datetime.now(dt.timezone.utc).isoformat(),
    'processes': [{'id': r['id'], 'pid': r['pid'], 'pid_exists': (Path('/proc') / str(r['pid'])).exists()} for r in results],
    'runner_exit_code_observed': 1,
    'runner_failure': 'assert all(row["machine_oracle_pass"] for row in results)',
    'runner_failure_source': 'Observed exec session 29403 terminal output; individual original logs are retained',
})
assert not any((Path('/proc') / str(r['pid'])).exists() for r in results)
excluded = {'evidence.tar.gz', 'archive.json', 'inventory.json'}
files = sorted(p for p in out.rglob('*') if p.is_file() and p.relative_to(out).as_posix() not in excluded)
inventory = [{'path': p.relative_to(out).as_posix(), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size} for p in files]
dump('inventory.json', {'files': inventory, 'count': len(inventory), 'notes': 'inventory excludes itself and external archive seal; all listed files are in tar'})
files.append(out / 'inventory.json')
archive = out / 'evidence.tar.gz'
assert not archive.exists(), 'Existing sealed archive must never be overwritten'
with archive.open('xb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tf:
            for p in sorted(files):
                data = p.read_bytes()
                info = tarfile.TarInfo(p.relative_to(out).as_posix())
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                tf.addfile(info, io.BytesIO(data))
verified = []
with tarfile.open(archive, 'r:gz') as tf:
    assert len(tf.getmembers()) == len(files)
    for row in inventory:
        data = tf.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        verified.append(row['path'])
    assert tf.extractfile('inventory.json').read() == (out / 'inventory.json').read_bytes()
dump('archive.json', {'archive': 'evidence.tar.gz', 'sha256': sha(archive.read_bytes()),
                     'bytes': archive.stat().st_size, 'archive_file_count': len(files),
                     'inventory_file_count': len(inventory), 'readback_verified_count': len(verified),
                     'inventory_sha256': sha((out / 'inventory.json').read_bytes()),
                     'status': 'Fail', 'reason': 'UnknownAsAbsent exits 75 with incompletely specified Recover successor; not an expected invariant violation',
                     'run_model_hash': '345bec05910174cfd0e27509b0cb2f753b4ea218ebf6077724d8af9330fe5c86',
                     'candidate_manifest_hash': '6e42d6508b34d3574bc15727e74e27cb029a568d024d9573a25fc6dfcb75b693'})
print((out / 'archive.json').read_text())
