"""Seal and read back this completed run without executing any model again."""
from pathlib import Path
import datetime as dt
import gzip
import hashlib
import io
import json
import os
import re
import tarfile

out = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(name, obj):
    (out / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')


manual = {
    'NoCompare': {'oracle': 'LateCorrect', 'valid_target_counterexample': True,
                  'interpretation': 'superseded precedes response, late false, expectedTail 1 vs actualTail 2',
                  'actions': ['Prepare(1)', 'Boundary', 'Submit(1)', 'Process(1)']},
    'PartialBatch': {'oracle': 'NoOrphanMessage', 'valid_target_counterexample': True,
                     'interpretation': 'message without response; actor 2 marks done',
                     'actions': ['Prepare(2)', 'Submit(2)', 'Process(2)']},
    'PartialClaim': {'oracle': 'ClaimsWholeBatch', 'valid_target_counterexample': True,
                     'interpretation': 'claim 2 while only message committed; no whole response batch',
                     'actions': ['Prepare(2)', 'Submit(2)', 'Process(2)']},
    'UnknownAsAbsent': {'oracle': 'UnknownNotAbsence', 'valid_target_counterexample': True,
                        'interpretation': 'Recover sets unsafeAbsence true while pending old writer is not stopped and no response exists',
                        'actions': ['Prepare(1)', 'Submit(1)', 'LoseAck(1)', 'Recover(1)']},
    'DropOwner': {'oracle': 'PendingOwned', 'valid_target_counterexample': True,
                  'interpretation': 'spent 1 reaches Budget 1 after attempted submit, no response, Exhaust drops owner',
                  'actions': ['Prepare(1)', 'Boundary', 'Submit(1)', 'Process(1)', 'Exhaust(1)']},
    'IgnoreOpened': {'oracle': 'NoSettlementThroughUnknownOpened', 'valid_target_counterexample': True,
                     'interpretation': 'response committed while anchorKnown false and anchorPending true',
                     'actions': ['Prepare(1)', 'Submit(1)', 'Process(1)']},
}
for name, row in manual.items():
    rel = f'runs/settlement-negative-{name}/trace.txt'
    trace = (out / rel).read_text()
    actions = re.findall(r'^State \d+: <([^ ]+)', trace, re.M)[1:]
    assert actions == row['actions']
    row.update({'trace_path': rel, 'trace_sha256': sha(trace.encode()),
                'read_by': '/root/b1_rt4_formal_verification',
                'human_interpretation_recorded_by_verification_agent': True})
    if name == 'DropOwner':
        assert 'CancelPolicy' not in trace and '/\\ spent = <<1, 0>>' in trace
        assert '/\\ owner = <<FALSE, TRUE>>' in trace
    if name == 'UnknownAsAbsent':
        assert '/\\ unsafeAbsence = TRUE' in trace and 'StopOld' not in trace
dump('trace-assessment.json', manual)
results = json.loads((out / 'results.json').read_text())
assert len(results) == 10
assert [r['exit_code'] for r in results] == [0, 0, 0, 0, 12, 12, 12, 12, 12, 12]
dump('terminal-process-check.json', {
    'checked_at': dt.datetime.now(dt.timezone.utc).isoformat(),
    'processes': [{'id': r['id'], 'pid': r['pid'], 'pid_exists': (Path('/proc') / str(r['pid'])).exists()} for r in results],
    'runner_exit_code_observed': 0,
    'runner_terminal_source': 'Observed exec session 91281 completed exit0; individual original logs are retained',
})
assert not any((Path('/proc') / str(r['pid'])).exists() for r in results)
import difflib
import platform
import subprocess
old_run = out.parent / 'rt4-formal-run-1'
old_inventory = json.loads((old_run / 'inventory.json').read_text())['files']
checks = [{'path': row['path'], 'expected': row['sha256'], 'actual': sha((old_run / row['path']).read_bytes())} for row in old_inventory]
assert all(row['expected'] == row['actual'] for row in checks)
assert sha((old_run / 'evidence.tar.gz').read_bytes()) == '7ec0da63cbb34d644d6318dc261f358be8dfa765cbdb08d1830956be551cebb8'
dump('run1-preservation-check.json', {'all_inventory_files_unchanged': True, 'inventory_count': len(checks), 'files': checks, 'old_archive_sha256': sha((old_run / 'evidence.tar.gz').read_bytes()), 'old_result_not_relabelled': True})
model_relative = 'inputs/.meta_harness/design/spec/capabilities/model-request-runtime/v4/formal/Settlement.tla'
(out / 'model-run1-to-run2.diff').write_text(''.join(difflib.unified_diff((old_run / model_relative).read_text().splitlines(keepends=True), (out / model_relative).read_text().splitlines(keepends=True), fromfile='run1-frozen-Settlement.tla', tofile='run2-frozen-Settlement.tla')))
hub = out.parents[3]
commands = []
for argv in [['git', 'branch', '--show-current'], ['git', 'rev-parse', 'HEAD'], ['git', 'status', '--short']]:
    result = subprocess.run(argv, cwd=hub, text=True, capture_output=True)
    commands.append({'argv': argv, 'cwd': str(hub), 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0
dump('environment-final.json', {'python': platform.python_version(), 'platform': platform.platform(), 'commands': commands, 'time': dt.datetime.now(dt.timezone.utc).isoformat()})

excluded = {'evidence.tar.gz', 'archive.json', 'inventory.json'}
files = sorted(p for p in out.rglob('*') if p.is_file() and p.relative_to(out).as_posix() not in excluded)
inventory = [{'path': p.relative_to(out).as_posix(), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size} for p in files]
dump('inventory.json', {'files': inventory, 'count': len(inventory), 'notes': 'inventory excludes itself and external archive seal; all listed files are in tar'})
files.append(out / 'inventory.json')
archive = out / 'evidence.tar.gz'
assert not archive.exists(), 'Existing sealed archive must never be overwritten'
with archive.open('xb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tf:
            for p in sorted(files):
                data = p.read_bytes()
                info = tarfile.TarInfo(p.relative_to(out).as_posix())
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                tf.addfile(info, io.BytesIO(data))
verified = []
with tarfile.open(archive, 'r:gz') as tf:
    assert len(tf.getmembers()) == len(files)
    for row in inventory:
        data = tf.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        verified.append(row['path'])
    assert tf.extractfile('inventory.json').read() == (out / 'inventory.json').read_bytes()
dump('archive.json', {'archive': 'evidence.tar.gz', 'sha256': sha(archive.read_bytes()),
                     'bytes': archive.stat().st_size, 'archive_file_count': len(files),
                     'inventory_file_count': len(inventory), 'readback_verified_count': len(verified),
                     'inventory_sha256': sha((out / 'inventory.json').read_bytes()),
                     'status': 'Pass-limited-model-only', 'reason': 'SANY and three positives complete; all six negatives violate exact designated invariants with inspected traces; contract body and product not accepted',
                     'run_model_hash': 'd7f25d31fa24a25560bf67d4bc9adf0ccb9b7a9f66606f9a56023f9e2e9049f5',
                     'candidate_manifest_hash': 'ce6c18d5884b24dbf81423becaa48f4672b7a45fd84a95ee5a474b8a1405bd64'})
print((out / 'archive.json').read_text())
