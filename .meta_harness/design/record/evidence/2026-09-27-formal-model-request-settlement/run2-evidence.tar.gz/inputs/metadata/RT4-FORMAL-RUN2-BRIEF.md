# RT4 Settlement 表达修订：独立 run2

承接 RT4-INDEPENDENT-REVIEW-BRIEF 的 verification 边界、全部oracle和工具条件；不改变目标或降低验收。run1 已完成 Fail，UnknownAsAbsent exit75，不覆盖任何旧输出。

本轮唯一写 HUB tmp/model-request-runtime/b1-late-coordination/rt4-formal-run-2/**。作者可能继续修正文，正式候选未接受。为避免漂移，新运行用 root 已逐hash冻结的只读副本：HUB tmp/model-request-runtime/b1-late-coordination/rt4-review-revision2/inputs/.meta_harness/design/spec/capabilities/model-request-runtime/v4/**，旁边output-sha256 manifest ce6c18d5884b24dbf81423becaa48f4672b7a45fd84a95ee5a474b8a1405bd64。29项中仅Settlement.tla改变，整体Boolean RHS增加括号；模型新hash d7f25d31fa24a25560bf67d4bc9adf0ccb9b7a9f66606f9a56023f9e2e9049f5，另28项/所有cfg/constants/oracles/旧13形式不变。旧contract27f5476仍有正文表达阻断，本轮模型成功不得提升整个契约状态。

独立抄存/核输入，新模型 SANY +3正+6负全执行，因整个模型hash改变而不沿旧3正/5负冒充当前结果。工具hash、1worker、最多3进程、300s测量期限、指定assertion/反例亲判、原始输出/真实终态与有限范围全沿原brief。其余64冻结资源和13继承形式可从作者spoke只读核，不从动态RT4正文取得当前model混入运行。修改初次命令cwd/模型路径及metadir只为冻结副本/新run，记录精确argv，不改模型。不要在run1目录追加/清理，不在作者spoke写入。

独立执行报告指出本轮仅模型表达修订，不验证正在修的正文或新的服务实现。实际模型行为/状态数和全部指定负控符合oracle后才交root有限核签，仍无真实IO/Run/全部操作证明。root不把未调度恢复的owner保留当进展保证。
