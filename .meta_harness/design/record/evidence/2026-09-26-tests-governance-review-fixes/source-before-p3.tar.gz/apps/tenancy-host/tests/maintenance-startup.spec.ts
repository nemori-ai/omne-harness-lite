import { openSnapshotInspection } from '@omne-harness-lite/storage-sql'
import { existsSync, promises as fs } from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'
import { join } from 'node:path'
import { afterEach, expect, it, vi } from 'vitest'
import { ENV } from '../src/config.ts'
import { deployment } from './support/deployment.ts'
import { Hosts } from './support/host.ts'

const hosts = new Hosts()
const roots: string[] = []
afterEach(async () => {
  vi.restoreAllMocks()
  syncBuiltinESMExports()
  await hosts.stopAll()
  for (const root of roots.splice(0)) await fs.rm(root, { recursive: true, force: true })
})

it('refuses parent fsync failure before creating any fiber, database or plaintext workspace', async () => {
  const d = await deployment('maintenance-parent-sync')
  roots.push(d.root)
  const parent = await fs.realpath(d.root)
  const original = fs.open
  let injected = 0
  vi.spyOn(fs, 'open').mockImplementation(async (...args) => {
    const handle = await original(...args)
    if (String(args[0]) === parent)
      vi.spyOn(handle, 'sync').mockImplementation(async () => {
        injected++
        throw Object.assign(new Error('injected directory fsync failure'), { code: 'EIO' })
      })
    return handle
  })
  syncBuiltinESMExports()
  const refusal = await hosts.refuse(d)
  expect(injected).toBe(1)
  expect(refusal.failure).toMatchObject({ stage: 'config', item: ENV.backupDirectory })
  expect(refusal.fibers).toHaveLength(0)
  expect(existsSync(d.file)).toBe(false)
  expect(existsSync(join(`${d.file}.backups`, '.quarantine'))).toBe(false)
})

it('rejects a directory used as the source before creating its default backup directory', async () => {
  const d = await deployment('maintenance-source-directory')
  roots.push(d.root)
  await fs.mkdir(d.file, { mode: 0o700 })
  const refusal = await hosts.refuse(d)
  expect(refusal.failure).toMatchObject({ stage: 'config' })
  expect(refusal.fibers).toHaveLength(0)
  expect(existsSync(`${d.file}.backups`)).toBe(false)
})

it.each(['missing-marker', 'wide-mode', 'busy', 'access-error'] as const)(
  'names the maintenance configuration for %s without claiming the precise cause',
  async fault => {
    const d = await deployment('maintenance-diagnostic')
    roots.push(d.root)
    const backup = await fs.realpath(d.root).then(parent => join(parent, 'center.sqlite.backups'))
    const work = join(backup, '.quarantine')
    await fs.mkdir(backup, { mode: 0o700 })
    const owner = await openSnapshotInspection(work)
    if (fault !== 'busy') await owner.close()
    try {
      if (fault === 'missing-marker') await fs.unlink(join(work, '.omne-isolated'))
      if (fault === 'wide-mode') await fs.chmod(work, 0o755)
      if (fault === 'access-error') {
        const original = fs.open
        vi.spyOn(fs, 'open').mockImplementation(async (...args) => {
          if (String(args[0]) === join(work, '.omne-isolated'))
            throw Object.assign(new Error('injected marker access denial'), { code: 'EACCES' })
          return original(...args)
        })
        syncBuiltinESMExports()
      }
      const refused = await hosts.refuse(d)
      expect(refused.failure).toMatchObject({ stage: 'storage-open', item: ENV.backupDirectory })
      expect(refused.failure.message).toContain('.quarantine')
      expect(refused.failure.message).toContain(fault === 'busy' ? ': busy;' : ': unavailable;')
      expect(refused.failure.message).toContain('check the directory')
      expect(JSON.stringify(refused.log.events('startup-failed'))).not.toContain(
        'injected marker access denial',
      )
    } finally {
      await owner.close()
    }
  },
)
