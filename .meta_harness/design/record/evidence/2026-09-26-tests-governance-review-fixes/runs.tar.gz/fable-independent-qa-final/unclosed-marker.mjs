// QA-only preload: keep the actual marker FileHandle open and reject close.
import { promises as fs } from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'
const originalOpen=fs.open
fs.open=async(...args)=>{
  const handle=await originalOpen(...args)
  if(String(args[0]).endsWith('/.quarantine/.omne-isolated')){
    handle.close=async()=>{
      process.stderr.write(JSON.stringify({qaFault:'marker-close-EIO',fdStillOpen:handle.fd>=0})+'\n')
      throw Object.assign(new Error('qa unclosed marker'),{code:'EIO'})
    }
  }
  return handle
}
syncBuiltinESMExports()
