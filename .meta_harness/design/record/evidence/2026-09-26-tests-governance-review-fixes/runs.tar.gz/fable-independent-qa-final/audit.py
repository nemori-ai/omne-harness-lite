import pathlib,json,hashlib,os,re
base=pathlib.Path('tmp/production-cli-onboarding/fable-independent-qa-final')
artifacts=json.loads(pathlib.Path('tmp/production-cli-onboarding/fable-artifacts-final.json').read_text())
expected={'host':('bba5d17f650011058f0592752f83dc88f68095bc1c4a0209f5925fe2921d554a','9b23209932a02438a80b7a173df7cee3cc2d89ec85cc26747c31028a35d574cd'),'cli':('19bf675a5f8cee4ba39dc64829d2a54589df7871973217692648941a5b841929','bb367e5706b00b831200a05797c1013a9d109e9016902e288f1767f5b2763ea8')}
sha=lambda b:hashlib.sha256(b).hexdigest()
banned=re.compile(r'^(?:vitest$|vite$|@vitest/|@vitejs/|rolldown$|@rolldown/|why-is-node-running$)')
records=[]
for artifact in artifacts:
 kind=artifact['kind'];archive=pathlib.Path(artifact['archive']);app=pathlib.Path(artifact['app']);assert sha(archive.read_bytes())==expected[kind][0]
 manifest=json.loads((app/'build-info.json').read_text());assert manifest['buildId']==expected[kind][1];assert (app/'BUILD_ID').read_text().strip()==manifest['buildId']
 entries={e['path']:e for e in manifest['files']};actual=set()
 for parent,dirs,files in os.walk(app,followlinks=False):
  for name in dirs+files:
   p=pathlib.Path(parent)/name
   if p.is_symlink() or p.is_file():actual.add(str(p.relative_to(app)))
 assert actual==set(entries)|{'build-info.json','BUILD_ID'}
 packages=[];js=0;links=0;files=0
 for rel,e in entries.items():
  p=app/rel
  if e['kind']=='link':assert p.is_symlink();assert os.readlink(p)==e['target'];links+=1;continue
  assert e['kind']=='file' and p.is_file() and not p.is_symlink();content=p.read_bytes();assert sha(content)==e['sha256'];files+=1
  if p.name=='package.json':
   try:pkg=json.loads(content)
   except:raise AssertionError(rel)
   name=pkg.get('name','');assert not banned.match(name),(rel,name)
   for section in ['dependencies','optionalDependencies']:
    assert not any(banned.match(x) for x in pkg.get(section,{})),(rel,section)
   if name:packages.append({'name':name,'version':pkg.get('version'),'path':rel})
  if p.suffix in ['.js','.mjs','.cjs']:
   js+=1
   text=content.decode('utf8')
   assert not re.search(r'''(?:from\s*|import\s*\(|require\s*\()\s*['"](?:vitest(?:['"/])|vite(?:['"/])|@vitest/|@vitejs/)''',text),rel
 records.append({'kind':kind,'verdict':'PASS','archiveSha256':expected[kind][0],'buildId':expected[kind][1],'files':files,'links':links,'javascriptFilesChecked':js,'installedPackages':packages,'testRuntimeAbsent':True})
(base/'inventory.json').write_text(json.dumps(records,indent=2)+'\n')
