import assert from 'node:assert/strict'
import {spawn} from 'node:child_process'
import {mkdtemp,readFile,writeFile,access,mkdir} from 'node:fs/promises'
import {join,resolve} from 'node:path'
process.env.OMNE_CROSS_HOST='/private/tmp/omne-host-d057-final-gv2n9joz/app'
const {makeCa,makeServerCertificate,keygen,freePort,opsDirectory,envOf,SETTINGS,CenterProcess}=await import('../maintenance-probe/deploy.ts')
const evidence=resolve('tmp/production-cli-onboarding/fable-independent-qa-final'),root=await mkdtemp('/private/tmp/omne-maint-qa-final-fault-'),fixtureNotes=[],log=x=>fixtureNotes.push(x),records=[]
const exists=p=>access(p).then(()=>true,()=>false)
const ca=makeCa(root,'ca',log),tls=makeServerCertificate(root,'leaf',ca,['DNS:localhost','IP:127.0.0.1'],log),ops=opsDirectory(root),db=join(root,'center.sqlite'),snapshot=db+'.upgrade-snapshot'
const env=envOf({dbFile:db,keys:await keygen(join(root,'keys'),log),tls,host:'127.0.0.1',port:await freePort(),opsDir:ops,settings:SETTINGS})
let child,normal
try{
  child=spawn(process.execPath,['--import',join(evidence,'unclosed-marker.mjs'),join(process.env.OMNE_CROSS_HOST,'dist/cli.js'),'serve'],{env:{PATH:process.env.PATH,...env},stdio:['ignore','pipe','pipe']});let stdout='',stderr='';child.stdout.on('data',x=>stdout+=x);child.stderr.on('data',x=>stderr+=x)
  const timer=setTimeout(()=>child.kill('SIGKILL'),15000)
  const result=await new Promise((done,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>done({code,signal}))});clearTimeout(timer);records.push({label:'faulted-first-start',...result,stdout,stderr});child=undefined
  assert.equal(result.code,1);assert.equal(result.signal,null);assert.equal(stdout,'');assert.ok(!stderr.includes('"event":"serving"'))
  const json=stderr.split('\n').filter(x=>x.startsWith('{')).map(x=>JSON.parse(x)),faults=json.filter(x=>x.qaFault==='marker-close-EIO');assert.ok(faults.length>=1);assert.ok(faults.every(x=>x.fdStillOpen===true))
  const failure=json.find(x=>x.event==='startup-failed');assert.ok(failure);assert.equal(failure.stage,'upgrade-unconfirmed');assert.equal(failure.snapshot,snapshot);assert.match(failure.message,/restoration is not confirmed/);assert.match(failure.message,/ownership is retained/);assert.ok(!failure.message.includes('restoring the upgrade snapshot failed'));assert.ok(await exists(snapshot));records.push({label:'upgrade-unconfirmed-message',failure,snapshotPresentBeforeRestart:true,faultCalls:faults.length,verdict:'PASS'})
  normal=CenterProcess.serve('normal-after-marker-close-fault',env,log);const health=await normal.ready(join(ops,'governance-center-ops.sock'));assert.ok(health);assert.ok(!await exists(snapshot));records.push({label:'normal-restart-after-actual-fault-process-exit',health,snapshotPresentAfterRestart:false,verdict:'PASS'})
  const terminated=await normal.terminate();assert.equal(terminated.code,0);records.push({label:'normal-stop',...terminated,verdict:'PASS'})
  await writeFile(join(evidence,'startup-probe-result.json'),JSON.stringify({verdict:'Pass',root,records},null,2)+'\n')
}catch(error){records.push({verdict:'FAIL',error:error.stack});await writeFile(join(evidence,'startup-probe-result.json'),JSON.stringify({verdict:'Fail',root,records},null,2)+'\n');throw error}
finally{if(child&&child.exitCode===null){child.kill('SIGKILL');await new Promise(done=>child.once('close',done))}if(normal){if(normal.running)await normal.terminate().catch(()=>normal.kill());await writeFile(join(evidence,'startup-probe-normal-center.json'),JSON.stringify({stdout:normal.stdout(),stderr:normal.stderr()},null,2)+'\n')}await writeFile(join(evidence,'startup-probe-fixture-notes.json'),JSON.stringify(fixtureNotes,null,2)+'\n')}
