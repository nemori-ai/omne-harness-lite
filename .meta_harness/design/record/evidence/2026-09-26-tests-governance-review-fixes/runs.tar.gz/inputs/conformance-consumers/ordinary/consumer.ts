import { type Storage, SnapshotFailure } from '@omne-harness-lite/storage'
const failure = new SnapshotFailure('unavailable')
export function observe(storage: Storage) { return [storage, failure] }
