import * as runner from 'vitest'
import { describeStorageConformance, describeAtomicStorageConformance } from '@omne-harness-lite/storage/conformance'
import type { StorageInstance, AtomicStorage } from '@omne-harness-lite/storage'
declare const make: () => Promise<StorageInstance & AtomicStorage>
describeStorageConformance('independent', make, runner)
describeAtomicStorageConformance('independent', make, runner)
