# D057 固定制品独立黑盒 QA

结论：**Pass**，限本次明确范围。47 项运行检查通过：原维护主旅程 38 项、新增帮助/凭据/启动诊断 6 项、同工作根真实进程排他与结束 3 项。独立完整制品清单及测试运行依赖排除检查通过，没有发现产品阻断。主线仍负责综合接受；本报告不替代尚未覆盖的故障验收或完整生产目标。

## 输入与实际环境

开始工作先核实分支为 `pandazki/add-tui-developer`。依据 D057 conformance-runner 采用决定及沿用的 D055/D056、EC3/HT3。没有构建、修改源码、既有测试或历史证据；本次脚本和记录均在本目录，临时中心使用新的私有 `/private/tmp/omne-maint-qa-*`，未接触他人的进程、端口或容器。

| 制品 | SHA256 | BUILD_ID |
|---|---|---|
| `omne-host-d057-r1.tar.gz` | `adc66ca5067fe6f94c16d23937415e4b7ac3cd91daa984488d79cf5c5d144ef5` | `0b844f7674c5d11cdde97892b7d905e1d5d9156e95dd03061d36d4da0bd99ee7` |
| `omne-cli-d057-r1.tar.gz` | `ced6559933ffb55301ba7058ce2e4bbc31abf9a98692d273d3fa635fbaa1fdb8` | `9d0146d97b1920cc8412fabedb04f0eaada219efdcef6d06af19333763dca8bf` |

实际运行目录分别为 `/private/tmp/omne-host-d057-r0hm5fzw/app` 与 `/private/tmp/omne-cli-d057-rnsl1eeq/app`。平台 macOS arm64 / Node 24.21.0，真实 TLS、Unix socket、多个独立进程。两中心正常关闭均实际 exit0；被故意破坏 marker 的启动进程按预期 exit1；全部自建进程已结束，没有创建容器。synthetic fixture 路径保留在 `run-3/fixture-location.txt`。

## 运行证据

原 38 项断言保持，切换为新固定 host+CLI。backup metadata 的 sourceBuildId 精确等于 D057 host BUILD_ID；verify metadata 与备份相等；restore 封装与原文件逐字节哈希相同且始终 businessOpen=false。员工 CLI 注册/登录/身份读取贯穿维护前后，已有身份不因维护改变。

新增秘密文件内容同时含前导 BOM、中文、空格与末尾 LF；完整内容注册成功，trim 后登录得到已确认远端凭据拒绝，原始完整内容随后登录成功。stdout/stderr 不出现该秘密。此组合观察证明输入没有整体 trim，不单独声称覆盖所有 Unicode 规范化情况。帮助实际说明 UTF-8、newline 和 trim 语义。

缺 marker 探针在中心实际停止后移除 synthetic `.quarantine/.omne-isolated`，新启动没有 serving，exit1；`startup-failed.stage=storage-open`、`item=OMNE_TENANCY_BACKUP_DIR`，稳定诊断指出 `.quarantine`、`unavailable` 和应检查目录。没有自动重新生成已存在根的 marker。

| # | 验收项 | 判定 | exit |
|---|---|---|---|
| 1 | initial-missing | Pass | 2 |
| 2 | employee-configure | Pass | 0 |
| 3 | employee-register | Pass | 0 |
| 4 | employee-login | Pass | 0 |
| 5 | employee-identity-before | Pass | 0 |
| 6 | online-backup | Pass | 0 |
| 7 | status-current | Pass | 0 |
| 8 | backup-not-due | Pass | 0 |
| 9 | employee-identity-after | Pass | 0 |
| 10 | offline-verify-no-env | Pass | 0 |
| 11 | offline-restore-no-env | Pass | 0 |
| 12 | verify-restored-envelope | Pass | 0 |
| 13 | restore-existing-target | Pass | 2 |
| 14 | restore-existing-empty-target | Pass | 2 |
| 15 | serve-restored-envelope-refused | Pass | 1 |
| 16 | corrupted-payload-refused | Pass | 2 |
| 17 | truncated-envelope-refused | Pass | 2 |
| 18 | trailing-byte-refused | Pass | 2 |
| 19 | source-symlink-refused | Pass | 1 |
| 20 | source-missing-unavailable | Pass | 1 |
| 21 | wide-work-root-refused | Pass | 1 |
| 22 | relative-source | Pass | 64 |
| 23 | relative-work | Pass | 64 |
| 24 | extra-argument | Pass | 64 |
| 25 | duplicate-flag | Pass | 64 |
| 26 | ops-relative | Pass | 64 |
| 27 | unknown-operation | Pass | 64 |
| 28 | catalog-types-and-corruption | Pass | 0 |
| 29 | foreign-center-backup | Pass | 0 |
| 30 | catalog-valid-foreign-filtered | Pass | 0 |
| 31 | catalog-foreign-future-filtered | Pass | 0 |
| 32 | own-future-unavailable | Pass | 1 |
| 33 | work-reusable-after-failures | Pass | 0 |
| 34 | employee-login-still-valid | Pass | 0 |
| 35 | cli-help-credential-semantics | Pass | 0 |
| 36 | secret-probe-configure | Pass | 0 |
| 37 | secret-full-utf8-register | Pass | 0 |
| 38 | secret-trimmed-login-rejected | Pass | 4 |
| 39 | secret-full-utf8-login | Pass | 0 |
| 40 | host-missing-quarantine-marker-diagnostic | Pass | 1 |
| 41 | offline-after-center-stopped | Pass | 0 |
| 42 | ops-stopped-center-unavailable | Pass | 1 |
| 43 | different-work-root-parallel-a | Pass | 0 |
| 44 | different-work-root-parallel-b | Pass | 0 |
| 45 | task 建立后原进程 SIGSTOP，同 work root 第二进程 | Pass | 2（busy） |
| 46 | 原进程 SIGCONT 后完成 | Pass | 0（verified） |
| 47 | 原进程实际退出后同 work root 再用 | Pass | 0（verified） |

证据：`run-3/commands.json`、编号命令文件、`checks.json`、`same-work-root-concurrency.json`。同根排他通过真实 OS 信号停住占用者，没有改产品运行逻辑。没有把 SIGSTOP/取消当作释放。

## 独立制品审计

`audit.py` 自行计算两归档 SHA256，核全部实际文件/软链集合与 build-info 清单完全一致，核每文件内容摘要、每软链目标与 BUILD_ID。对每份 package.json 的包名及 dependencies/optionalDependencies 排查测试运行依赖，对所有 JS/MJS/CJS 扫描 Vitest/Vite 静态/动态 import 与 require。devDependencies 中作为声明/测试消费者开发输入的 Vitest 不被误算为已安装生产运行闭包。

- host：2835 文件、115 软链，908 份 JavaScript、37 份具名 package.json；检查通过。
- cli：2833 文件、89 软链，907 份 JavaScript、37 份具名 package.json；检查通过。

没有安装 Vitest、Vite、@vitest、@vitejs、rolldown、@rolldown 或 why-is-node-running 包，没有上述生产依赖引用或 Vitest/Vite JS 导入。真实命令运行同时证实本次受测路径不需要这些测试运行器。机器清单含全部已安装包，见 `inventory.json`。不据此声称所有可能动态字符串加载都已形式证明。

## 原始失败尝试

所有失败保留，未覆盖旧结果：

1. `attempt-1-script.mjs`、`attempt-1.log`、`run-1/`：QA 新增凭据负例错误期待 exit2；冻结 CG2 S15 对已确认远端拒绝规定 exit4。修为明确 exit4，仍严格检查 identifier-or-credential-rejected。
2. `attempt-2-script.mjs`、`attempt-2.log`、`run-2/`：QA 把“点名配置”误当 stage=config；此失败在 storage 初始化，实际应为 storage-open，配置名称归 item。修为同时严格核 storage-open、OMNE_TENANCY_BACKUP_DIR、quarantine、unavailable 检查提示，未扩大允许集合。
3. `attempt-3.log`、`run-3/`：完整 44 项通过；`concurrency-1.log` 对应附加 3 项通过。

上述是附加 QA 判据修正，无产品代码修改；不把前两轮记录删除或表述为从未失败。

## 未覆盖与不能推论的内容

- workspace 初始化 FileHandle close 失败、协调库 PRAGMA/BEGIN/close 故障后的真实属主保留：本轮没有独立重做注入。主线十个真实子进程故障证据与只读评审由主线另行综合，不能算成本报告的黑盒通过项。
- 原位源变动精确 hash/fstat 阶段仍 **Unable to verify**；不重跑、不改写旧探针结果，也不因相同制品旅程成功将它改为通过。
- fsync/cleanup 注入、unknown 后持久重确认、全部生产打开 API × 残余矩阵、物理断电/整机灾备、20/24 小时真实时钟等待未在本轮独立覆盖。
- Linux/systemd、跨 OS、大库业务/clock 并行由主线执行；本报告不借其结果冒充自己执行。
- 本轮没有完整治理表单/TUI 重验，没有真实公司内网安装，也不改变 D054 终端限定覆盖。
- 没有新增安全再开放权限，恢复封装仍拒绝 serve。本报告不代替最终 fable review 或主线接受。

## 重跑

```sh
fnm exec --using 24 node tmp/production-cli-onboarding/fable-independent-qa-r1/run.mjs /absolute/new/evidence-directory
fnm exec --using 24 node tmp/production-cli-onboarding/fable-independent-qa-r1/concurrency.mjs /absolute/new/evidence-directory
```

`audit.py` 是独立审计入口；若重跑并保留历史，先把其中输出 base 指向新目录。所有测试只消费固定归档，不构建主树；附加脚本依赖主旅程保留的 synthetic fixture，不要提前删掉该目录。
