import pathlib,json,hashlib,os,re
base=pathlib.Path('tmp/production-cli-onboarding/fable-independent-qa-r1')
artifacts=json.loads(pathlib.Path('tmp/production-cli-onboarding/fable-artifacts-r1.json').read_text())
expected={'host':('adc66ca5067fe6f94c16d23937415e4b7ac3cd91daa984488d79cf5c5d144ef5','0b844f7674c5d11cdde97892b7d905e1d5d9156e95dd03061d36d4da0bd99ee7'),'cli':('ced6559933ffb55301ba7058ce2e4bbc31abf9a98692d273d3fa635fbaa1fdb8','9d0146d97b1920cc8412fabedb04f0eaada219efdcef6d06af19333763dca8bf')}
sha=lambda b:hashlib.sha256(b).hexdigest()
banned=re.compile(r'^(?:vitest$|vite$|@vitest/|@vitejs/|rolldown$|@rolldown/|why-is-node-running$)')
records=[]
for artifact in artifacts:
 kind=artifact['kind'];archive=pathlib.Path(artifact['archive']);app=pathlib.Path(artifact['app']);assert sha(archive.read_bytes())==expected[kind][0]
 manifest=json.loads((app/'build-info.json').read_text());assert manifest['buildId']==expected[kind][1];assert (app/'BUILD_ID').read_text().strip()==manifest['buildId']
 entries={e['path']:e for e in manifest['files']};actual=set()
 for parent,dirs,files in os.walk(app,followlinks=False):
  for name in dirs+files:
   p=pathlib.Path(parent)/name
   if p.is_symlink() or p.is_file():actual.add(str(p.relative_to(app)))
 assert actual==set(entries)|{'build-info.json','BUILD_ID'}
 packages=[];js=0;links=0;files=0
 for rel,e in entries.items():
  p=app/rel
  if e['kind']=='link':assert p.is_symlink();assert os.readlink(p)==e['target'];links+=1;continue
  assert e['kind']=='file' and p.is_file() and not p.is_symlink();content=p.read_bytes();assert sha(content)==e['sha256'];files+=1
  if p.name=='package.json':
   try:pkg=json.loads(content)
   except:raise AssertionError(rel)
   name=pkg.get('name','');assert not banned.match(name),(rel,name)
   for section in ['dependencies','optionalDependencies']:
    assert not any(banned.match(x) for x in pkg.get(section,{})),(rel,section)
   if name:packages.append({'name':name,'version':pkg.get('version'),'path':rel})
  if p.suffix in ['.js','.mjs','.cjs']:
   js+=1
   text=content.decode('utf8')
   assert not re.search(r'''(?:from\s*|import\s*\(|require\s*\()\s*['"](?:vitest(?:['"/])|vite(?:['"/])|@vitest/|@vitejs/)''',text),rel
 records.append({'kind':kind,'verdict':'PASS','archiveSha256':expected[kind][0],'buildId':expected[kind][1],'files':files,'links':links,'javascriptFilesChecked':js,'installedPackages':packages,'testRuntimeAbsent':True})
(base/'inventory.json').write_text(json.dumps(records,indent=2)+'\n')
