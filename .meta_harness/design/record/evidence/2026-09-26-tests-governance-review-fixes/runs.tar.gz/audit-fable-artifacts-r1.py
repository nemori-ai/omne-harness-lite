from pathlib import Path
import json,hashlib,os
root=Path('tmp/production-cli-onboarding');reports=[]
for item in json.loads((root/'fable-artifacts-r1.json').read_text()):
 app=Path(item['app']);manifest=json.loads((app/'build-info.json').read_text());files=manifest['files']
 assert hashlib.sha256(json.dumps(files,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==item['buildId']==manifest['buildId']
 expected={x['path'] for x in files};actual=set()
 for dir,dirs,names in os.walk(app,followlinks=False):
  for n in names+dirs:
   p=Path(dir)/n
   if not p.is_symlink() and p.is_dir():continue
   actual.add(p.relative_to(app).as_posix())
 assert actual==expected|{'BUILD_ID','build-info.json'},(actual-expected,expected-actual)
 for f in files:
  p=app/f['path']
  if f['kind']=='file':assert p.is_file() and not p.is_symlink() and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'],f
  else:assert p.is_symlink() and os.readlink(p)==f['target'] and p.resolve().is_relative_to(app),f
 if item['kind']=='host':
  assert 'deploy/omne-tenancy.service' in expected
  assert any(x.endswith('/maintenance/inspection-worker.js') for x in expected)
 reports.append({**item,'files':len(files),'inventory':'PASS','runtimeRequired':manifest['node']})
(root/'fable-artifacts-audit-r1.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports,indent=2))
