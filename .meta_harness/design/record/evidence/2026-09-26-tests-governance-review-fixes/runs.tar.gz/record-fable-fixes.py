from pathlib import Path
import json,hashlib,tarfile,subprocess,shutil
r=Path.cwd();t=r/'tmp/production-cli-onboarding';out=r/'.meta_harness/design/record/evidence/2026-09-26-tests-governance-review-fixes'
assert not out.exists(), 'append only'
assert (t/'fable-independent-qa-final/report.md').exists()
assert (t/'fable-review-report-r3.md').exists()
for case in ['d057-final-linux-center','d057-final-mac-center','d057-final-linux-amd64-old-cli']:
 assert json.loads((t/'cross-os'/case/'result.json').read_text())['status']=='PASS'
assert json.loads((t/'fable-systemd-product-final/result.json').read_text())['status']=='PASS'
out.mkdir()
source=sorted(set(subprocess.check_output(['git','ls-files','-co','--exclude-standard','--','packages','apps','tools','scripts','docs','package.json','pnpm-lock.yaml','pnpm-workspace.yaml','tsconfig.base.json','AGENTS.md'],text=True).splitlines()))
source=[n for n in source if (r/n).is_file()]
with tarfile.open(out/'source.tar.gz','w:gz') as a:
 for n in source:a.add(r/n,arcname=n,recursive=False)
(out/'source-sha256.json').write_text(json.dumps({n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in source},indent=2)+'\n')
runs={p for pattern in ['fable-*.log','fable-*.json','fable-initialization-review-r*.txt','cross-d057-*.log'] for p in t.glob(pattern) if 'review-result' not in p.name}
for name in ['fable-initialization-review-r3','fable-systemd-product-r1','fable-systemd-product-final','fable-independent-qa-r1','fable-independent-qa-final','cross-os/d057-linux-center-r1','cross-os/d057-mac-center-r1','cross-os/d057-linux-amd64-old-cli-r1','cross-os/d057-final-linux-center','cross-os/d057-final-mac-center','cross-os/d057-final-linux-amd64-old-cli']:
 for p in (t/name).rglob('*'):
  if p.is_file() and 'tls' not in p.relative_to(t/name).parts:runs.add(p)
for name in ['maintenance-probe/systemd-product.py','maintenance-probe/systemd-fixture.mjs','maintenance-probe/deploy.ts','cross-os/run.mjs','audit-fable-artifacts-r1.py','fable-package-clean-build-r1.py','fable-package-clean-build-r2.py','fable-package-clean-build-r3.py','audit-fable-artifacts-final.py','record-fable-fixes.py']:
 runs.add(t/name)
# Explicit inputs for strict independent TS consumers and the old-implementation negative control.
extras=[]
for label,directory in [('conformance-consumers',Path('/private/tmp/omne-conformance-consumers-4ov_jkk0')),('workspace-negative',Path('/private/tmp/omne-workspace-negative-xz29fq1z'))]:
 for p in directory.rglob('*'):
  if p.is_file() and not p.is_symlink() and 'node_modules' not in p.relative_to(directory).parts:
   extras.append((p,'inputs/'+label+'/'+str(p.relative_to(directory))))
with tarfile.open(out/'runs.tar.gz','w:gz') as a:
 for p in sorted(runs):
  assert p.suffix!='.jsonl', 'private model transcripts forbidden'
  a.add(p,arcname=str(p.relative_to(t)),recursive=False)
 for p,n in extras:a.add(p,arcname=n,recursive=False)
hashes={str(p.relative_to(t)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(runs)}
hashes.update({n:hashlib.sha256(p.read_bytes()).hexdigest() for p,n in extras})
(out/'runs-sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
for n in ['omne-host-d057-r1.tar.gz','omne-cli-d057-r1.tar.gz','omne-host-d057-r3.tar.gz','omne-cli-d057-r2.tar.gz']:shutil.copyfile(t/n,out/n)
shutil.copyfile(t/'fable-independent-qa-r1/report.md',out/'independent-qa-r1.txt')
shutil.copyfile(t/'fable-independent-qa-final/report.md',out/'independent-qa-final.txt')
summary={'date':'2026-09-26','sourceFiles':len(source),'runFiles':len(hashes),'workspace':json.loads((t/'fable-workspace-test-summary-final.json').read_text()),'artifacts':json.loads((t/'fable-artifacts-audit-final.json').read_text()),'node':'24.21.0','pnpm':'10.28.1','formal':'explicit skip; no changed domain contract/model','strictConsumers':json.loads((t/'fable-conformance-consumers-r3.json').read_text()),'initialization':'10 positive process scenarios; old FileHandle implementation negative 5 fail / 1 pass; PRAGMA case acquired source exclusion but no workspace transaction yet','crossOS':['macOS arm64','Linux Docker arm64','Linux Docker amd64 with prior D054 CLI'],'systemd':'252.39 nonroot service, actual packaged host, backup/verify/isolated restore, >31s stopping, timer refuses stopped center','boundaries':['no company deployment','no physical power loss','no independent backup location or safe business reopen','prior source mutation exact phase remains unverified','limited D054 TUI terminal profiles remain']}
# The r1 clean packaging source is the runtime input read by the second Fable review.
prior=Path(json.loads((t/'fable-package-clean-location-r1.json').read_text())['source'])
prior_files=[p for p in prior.rglob('*') if p.is_file() and not p.is_symlink() and not any(x in p.relative_to(prior).parts for x in ['node_modules','dist','__pycache__'])]
with tarfile.open(out/'source-before-p3.tar.gz','w:gz') as a:
 for p in sorted(prior_files):a.add(p,arcname=str(p.relative_to(prior)),recursive=False)
(out/'source-before-p3-sha256.json').write_text(json.dumps({str(p.relative_to(prior)):hashlib.sha256(p.read_bytes()).hexdigest() for p in prior_files},indent=2)+'\n')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'path':str(out),'sourceFiles':len(source),'runFiles':len(hashes)}))
