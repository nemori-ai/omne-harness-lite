#!/usr/bin/env python3
"""Root-gated D pilot: one private outer DinD SIGKILL and explicit same-DinD restore."""

import argparse
import hashlib
import json
import pathlib
import re
import secrets
import shutil
import subprocess
import sys
import time

import base_driver as base
import io_driver
import p_driver

HERE = pathlib.Path(__file__).resolve().parent
CLI_SHA = p_driver.CLI_SHA
CLI_BUILD_ID = p_driver.CLI_BUILD_ID


def need(value, message):
    if not value:
        raise RuntimeError(message)


def checked_inputs(args):
    io_args = argparse.Namespace(**vars(args))
    io_args.scenario = "write-hold"
    inputs = io_driver.checked_inputs(io_args)
    paths = {"p_driver": HERE / "p_driver.py", "cli_tar": args.cli_tar,
             "storage_guard": args.helper_dir.parents[1] / "node_modules" /
             "@omne-harness-lite/storage-sql/dist/sqlite/protection.js"}
    for name, path in paths.items():
        inputs["paths"][name] = str(path.resolve())
        inputs["sha256"][name] = base.sha(path)
    manifest = json.loads(args.i3_manifest.read_text())
    need(inputs["sha256"]["cli_tar"] == CLI_SHA
         and manifest["archives"]["cli"]["buildId"] == CLI_BUILD_ID
         and args.cli_build_id == CLI_BUILD_ID, "final public CLI identity changed")
    need(args.scenario == "D" and args.uid == args.gid == 10001,
         "only private D pilot with reviewed application owner")
    need(args.stable_seconds >= 10 and args.restart_observe_seconds >= 10
         and args.observe_seconds >= 90, "reviewed observation budgets reduced")
    inputs.update({"scenario": "D", "qa_gate_mode": "write-hold",
                   "stable_seconds": args.stable_seconds,
                   "restart_observe_seconds": args.restart_observe_seconds,
                   "cli_build_id": args.cli_build_id})
    return inputs


class DaemonRun(p_driver.PilotRun):
    def __init__(self, args, inputs):
        # P behavior is reused only for the verified public facts, held FD,
        # residual observations, and original-image production-open guard.
        io_driver.IoRun.__init__(self, args, inputs)
        target = self.frozen / "p_driver.py"
        shutil.copyfile(HERE / "p_driver.py", target)
        need(base.sha(target) == inputs["sha256"]["p_driver"],
             "frozen P measurement source changed")
        self.cli_archive = self.frozen / "cli.tar.gz"
        shutil.copyfile(args.cli_tar, self.cli_archive)
        need(base.sha(self.cli_archive) == inputs["sha256"]["cli_tar"],
             "final CLI archive changed during freeze")
        self.evidence["scenario"] = "D"
        self.save()

    def outer_identity(self, phase):
        label = f"d-outer-inspect-{phase}"
        found = json.loads(self.outer(label, "inspect", self.dind))[0]
        cid = found["Id"]
        need(base.HEX64.fullmatch(cid) and found["Name"] == "/" + self.dind
             and found["Image"] == base.DIND_ID
             and found["Config"]["Labels"].get("omne.r5.helper-prep") == self.run_id
             and found["HostConfig"]["NetworkMode"] == self.network
             and not found["HostConfig"].get("PortBindings"),
             "outer DinD identity or private network differs")
        mounts = found["Mounts"]
        by_destination = {mount["Destination"]: mount for mount in mounts}
        expected = {base.ROOT: self.volumes[0],
                    "/opt/omne-private-docker": self.volumes[1],
                    "/var/lib/docker": self.volumes[2]}
        need(len(mounts) == len(expected) == len(by_destination)
             and set(by_destination) == set(expected)
             and all(mount["Type"] == "volume" and mount["Name"] == expected[dest]
                     and mount["RW"] is True for dest, mount in by_destination.items()),
             "outer DinD whole private mounts differ")
        for index, volume in enumerate(self.volumes):
            inspected = json.loads(self.outer(f"d-volume-{phase}-{index}",
                                              "volume", "inspect", volume))[0]
            need(inspected["Name"] == volume
                 and inspected["Labels"].get("omne.r5.helper-prep") == self.run_id,
                 "private volume identity differs")
        return found

    def scenario(self):
        common = ["--project", self.project]
        deployment = [*common, "--image", self.qa_id, "--state-dir", base.STATE,
                      "--secrets-dir", base.SECRETS, "--settings-file", base.SETTINGS,
                      "--publish-address", self.publish_address, "--publish-port", "18443",
                      "--uid", "10001", "--gid", "10001"]
        self.helper("p-validate", "validate", *deployment)
        started = base.parse_json_line(self.helper("p-start", "start", *deployment,
                                                   timeout=self.args.observe_seconds), "p-start")
        cid = started.get("containerId")
        need(isinstance(cid, str) and base.HEX64.fullmatch(cid),
             "helper start lacked exact center CID")
        self.evidence["center_id"] = cid
        self.save()
        self.await_file("p-gate-ready", base.STATE + "/qa/ready")
        self.control_exec("p-generation-stat-before", "stat", "-c", "%F:%u:%g:%a:%s",
                          base.STATE + "/qa/generation")
        self.control_exec("p-generation-content-before", "cat", base.STATE + "/qa/generation")
        self.inner("p-center-initial", "inspect", cid)
        self.helper("p-full-health-before", "full-health", *common)
        self.public_facts_before()
        prior = base.parse_json_line(self.helper("p-prior-backup", "backup", *common,
                                                 timeout=self.args.observe_seconds),
                                         "p-prior-backup")
        need(prior.get("status") == "completed" and isinstance(prior.get("backup"), dict),
             "prior backup not confirmed completed")
        self.helper("p-prior-backup-status", "backup-status", *common)
        self.evidence["prior_backup"] = prior["backup"]
        self.save()
        self.control_exec("p-held-before-arm", "test", "!", "-e", base.STATE + "/qa/held")
        self.control_exec("p-arm-gate", "touch", base.STATE + "/qa/arm")
        backup_argv = ["docker", "exec", "-e", f"DOCKER_HOST={base.SOCKET}", self.control,
                       base.HELPER, "backup", *common]
        self.asynchronous("p-pending-backup", backup_argv)
        held = self.await_file("p-gate-held", base.STATE + "/qa/held")
        need(held.get("stage") == "write" and held.get("pid") == 1
             and type(held.get("fd")) is int and held["fd"] >= 0
             and io_driver.FD_PATH.fullmatch(held.get("path", "")),
             "QA did not hold the real export FileHandle")
        fd = f"/proc/1/fd/{held['fd']}"
        self.inner("p-held-fd-link", "exec", cid, "readlink", fd)
        self.inner("p-held-fd-stat", "exec", cid, "stat", "-Lc", "%d:%i:%u:%g:%a", fd)
        snapshot = self.snapshot_observe("p-before")
        self.inner("p-center-stable-first", "inspect", cid)
        self.evidence["stable_started_monotonic_ns"] = time.monotonic_ns()
        self.save()
        time.sleep(self.args.stable_seconds)
        self.inner("p-center-stable-last", "inspect", cid)
        self.evidence["stable_finished_monotonic_ns"] = time.monotonic_ns()
        self.save()
        need(self.async_clients["p-pending-backup"][1].poll() is None,
             "pending backup completed before fault")
        self.inner("d-center-before-fault", "inspect", cid)
        before = json.loads((self.run / "raw/d-center-before-fault.stdout").read_bytes())[0]
        need(before["Id"] == cid and before["State"]["Status"] == "running"
             and before["State"]["Health"]["Status"] == "healthy"
             and before["State"]["Running"] is True
             and before["HostConfig"]["RestartPolicy"]["Name"] == "unless-stopped"
             and type(before["State"]["Pid"]) is int and before["State"]["Pid"] > 0,
             "live center restart preconditions absent")
        outer_before = self.outer_identity("before")
        need(outer_before["State"]["Status"] == "running"
             and outer_before["State"]["Running"] is True
             and type(outer_before["State"]["Pid"]) is int
             and outer_before["State"]["Pid"] > 0,
             "outer DinD is not live before exact fault")
        namespace_before = self.outer("d-namespace-before", "exec", self.dind,
                                      "readlink", "/proc/1/ns/pid").strip().decode()
        need(re.fullmatch(r"pid:\[[0-9]+\]", namespace_before),
             "outer DinD PID namespace absent")
        self.evidence["outer_id"] = outer_before["Id"]
        self.evidence["fault_since_utc"] = base.utc()
        self.save()
        # This is the single deliberate fault; it targets only the labelled
        # outer DinD. The inner center is never explicitly killed or started.
        self.outer("d-one-outer-sigkill", "kill", "--signal=SIGKILL", outer_before["Id"])
        dead = json.loads(self.outer("d-outer-inspect-dead", "inspect", outer_before["Id"]))[0]
        need(dead["Id"] == outer_before["Id"] and dead["State"]["Status"] == "exited"
             and dead["State"]["ExitCode"] == 137,
             "exact outer DinD did not actually exit137")
        self.evidence["restore_since_utc"] = base.utc()
        self.save()
        self.outer("d-explicit-start-same-dind", "start", outer_before["Id"])
        outer_after = self.outer_identity("after")
        namespace_after = self.outer("d-namespace-after", "exec", self.dind,
                                     "readlink", "/proc/1/ns/pid").strip().decode()
        need(outer_after["Id"] == outer_before["Id"]
             and outer_after["State"]["Status"] == "running"
             and outer_after["State"]["Running"] is True
             and outer_after["State"]["StartedAt"] != outer_before["State"]["StartedAt"]
             and type(outer_after["State"]["Pid"]) is int
             and outer_after["State"]["Pid"] > 0
             and namespace_after != namespace_before
             and re.fullmatch(r"pid:\[[0-9]+\]", namespace_after),
             "same outer DinD did not enter a new live namespace")
        for attempt in range(1, 41):
            out = self.inner(f"d-engine-ready-{attempt}", "version", "--format",
                             "{{.Client.Version}} {{.Server.Version}}", expected=None)
            if self.evidence["commands"][-1]["returncode"] == 0 and out.strip() == b"29.1.3 29.1.3":
                break
            time.sleep(1)
        else:
            raise RuntimeError("restored private Engine unavailable")
        deadline = time.monotonic() + self.args.observe_seconds
        for attempt in range(1, 181):
            label = f"d-restart-poll-{attempt}"
            data = json.loads(self.inner(label, "inspect", cid))[0]
            need(data["Id"] == cid, "inner center identity changed after daemon loss")
            if (data["State"]["Status"] == "running"
                    and data["State"]["Health"]["Status"] == "healthy"
                    and data["State"]["StartedAt"] != before["State"]["StartedAt"]
                    and type(data["State"]["Pid"]) is int
                    and data["State"]["Pid"] > 0):
                self.evidence["recovered_poll"] = label
                self.save()
                break
            need(time.monotonic() < deadline, "automatic daemon recovery observation expired")
            time.sleep(1)
        else:
            raise RuntimeError("automatic daemon recovery observation expired")
        self.inner("p-center-recovered", "inspect", cid)
        self.helper("p-status-recovered", "status", *common)
        self.helper("p-full-health-recovered", "full-health", *common)
        self.helper("p-backup-status-recovered", "backup-status", *common)
        self.cli("p-cli-health-after", "health")
        self.cli("p-cli-current-after", "current", payload={}, refresh=True)
        self.cli("p-cli-list-after", "list", payload={}, refresh=True)
        recovered = json.loads((self.run / "raw/p-center-recovered.stdout").read_bytes())[0]
        first = json.loads(self.inner("p-recovered-observe-1", "inspect", cid))[0]
        self.evidence["recovered_observation_started_monotonic_ns"] = time.monotonic_ns()
        deadline_ns = (self.evidence["recovered_observation_started_monotonic_ns"] +
                       self.args.restart_observe_seconds * 1_000_000_000)
        index = 1
        while True:
            need(first["Id"] == cid and first["State"]["Status"] == "running"
                 and first["State"]["Health"]["Status"] == "healthy"
                 and first["State"]["StartedAt"] == recovered["State"]["StartedAt"]
                 and first["RestartCount"] == recovered["RestartCount"],
                 "recovered center changed during finite observation")
            if time.monotonic_ns() >= deadline_ns:
                index += 1
                first = json.loads(self.inner(f"p-recovered-observe-{index}", "inspect", cid))[0]
                break
            time.sleep(min(1, max(0, (deadline_ns - time.monotonic_ns()) / 1_000_000_000)))
            index += 1
            first = json.loads(self.inner(f"p-recovered-observe-{index}", "inspect", cid))[0]
        self.evidence["recovered_observation_last_label"] = f"p-recovered-observe-{index}"
        self.evidence["recovered_observation_finished_monotonic_ns"] = time.monotonic_ns()
        self.save()
        self.snapshot_observe("p-after", snapshot)
        self.control_exec("p-generation-stat-after", "stat", "-c", "%F:%u:%g:%a:%s",
                          base.STATE + "/qa/generation")
        self.control_exec("p-generation-content-after", "cat", base.STATE + "/qa/generation")
        self.original_serve_rejection(snapshot)
        self.snapshot_observe("p-probe-after", snapshot)
        self.inner("p-center-logs", "logs", cid)
        self.inner("d-center-events-new-engine", "events", "--since",
                   self.evidence["restore_since_utc"], "--until", base.utc(),
                   "--filter", f"container={cid}", "--format", "{{json .}}", timeout=20)
        self.outer("d-outer-events", "events", "--since", self.evidence["fault_since_utc"],
                   "--until", base.utc(), "--filter", f"container={outer_before['Id']}",
                   "--format", "{{json .}}", timeout=20)
        try:
            self.finish_async("p-pending-backup", 30)
        except RuntimeError:
            item = self.async_clients["p-pending-backup"][0]
            need(item["observation_expired"] is True and item["returncode"] is None,
                 "pending backup client failed without an unknown observation")
            self.evidence["pending_client_outcome"] = "unknown-after-observation-budget"
            self.save()
        self.evidence["business_complete"] = True
        self.evidence["status"] = "observed-awaiting-oracle"
        self.save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=("D",), required=True)
    parser.add_argument("--i3-manifest", type=pathlib.Path, required=True)
    parser.add_argument("--image-tar", type=pathlib.Path, required=True)
    parser.add_argument("--helper-dir", type=pathlib.Path, required=True)
    parser.add_argument("--cli-tar", type=pathlib.Path, required=True)
    parser.add_argument("--cli-build-id", required=True)
    parser.add_argument("--v0-dir", type=pathlib.Path, required=True)
    parser.add_argument("--design-root", type=pathlib.Path, required=True)
    parser.add_argument("--uid", type=int, default=10001)
    parser.add_argument("--gid", type=int, default=10001)
    parser.add_argument("--hold-seconds", type=float, default=31.5)
    parser.add_argument("--term-observe-seconds", type=float, default=15.0)
    parser.add_argument("--stable-seconds", type=int, default=12)
    parser.add_argument("--restart-observe-seconds", type=int, default=10)
    parser.add_argument("--observe-seconds", type=int, default=180)
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    inputs = checked_inputs(args)
    if args.print_inputs:
        print(json.dumps({"inputs": inputs, "inputs_sha256": io_driver.canonical_hash(inputs)},
                         sort_keys=True))
        return 0
    need(args.execute, "Docker execution requires --execute")
    io_driver.reviewed_inputs(args, inputs)
    args.image_id = io_driver.IMAGE_ID
    args.build_id = io_driver.BUILD_ID
    run = DaemonRun(args, inputs)
    try:
        run.setup()
        run.import_image()
        run.prepare_paths()
        run.prepare_public_cli()
        run.prepare_qa()
        run.scenario()
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
        run.save()
    finally:
        run.cleanup()
    with (run.run / "oracle.stdout").open("xb") as stdout, \
            (run.run / "oracle.stderr").open("xb") as stderr:
        checked = subprocess.run([sys.executable, "-B", str(run.frozen / "oracle.py"),
                                  str(run.run)], stdout=stdout, stderr=stderr, check=False)
    run.evidence["oracle_exit"] = checked.returncode
    run.save()
    print(json.dumps({"run": str(run.run), "scenario": "D", "oracle_exit": checked.returncode,
                      "cleanup_complete": run.evidence["cleanup_complete"]}, sort_keys=True))
    return 0 if checked.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
