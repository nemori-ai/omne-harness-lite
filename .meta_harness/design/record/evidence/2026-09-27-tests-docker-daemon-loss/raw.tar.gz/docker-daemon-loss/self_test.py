#!/usr/bin/env python3
"""Offline D oracle positives and representative false-success counterexamples."""

import contextlib
import copy
import hashlib
import io
import json
import pathlib
import shutil
import tempfile

import oracle
import p_self_test as p

HERE = pathlib.Path(__file__).resolve().parent
OUTER = "8" * 64
DIND = "omne-r5-selftest-dind"
NAMES = ["omne-r5-selftest-data", "omne-r5-selftest-socket",
         "omne-r5-selftest-daemon"]
DESTINATIONS = ["/var/lib/omne-tenancy", "/opt/omne-private-docker",
                "/var/lib/docker"]


def encode(value):
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        return value.encode()
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def fixture(run):
    evidence = p.make_fixture(run)
    frozen = run / "inputs"
    shutil.copyfile(HERE / "p_driver.py", frozen / "p_driver.py")
    evidence["inputs"]["sha256"]["p_driver"] = hashlib.sha256(
        (frozen / "p_driver.py").read_bytes()).hexdigest()
    evidence["scenario"] = "D"
    evidence["run_id"] = "selftest"
    evidence["outer_id"] = OUTER
    evidence["expected"]["dind"] = DIND
    prior = evidence["commands"]
    first = next(index for index, row in enumerate(prior)
                 if row["label"] == "p-center-before-signal")
    last = next(index for index, row in enumerate(prior)
                if row["label"] == "p-center-recovered")
    rows = prior[:first]

    def add(label, data=b"", *, stderr=b"", argv=None, started="2026-09-27T00:00:20+00:00"):
        stdout_path = "raw/" + label + ".stdout"
        stderr_path = "raw/" + label + ".stderr"
        (run / stdout_path).write_bytes(encode(data))
        (run / stderr_path).write_bytes(encode(stderr))
        rows.append({"label": label, "argv": argv or ["fixture", label],
                     "stdout": stdout_path, "stderr": stderr_path,
                     "returncode": 0, "observation_expired": False,
                     "started_utc": started})

    before = json.loads((run / "raw/p-center-before-signal.stdout").read_bytes())
    add("d-center-before-fault", before)
    mounts = [{"Destination": dest, "Name": name, "Type": "volume", "RW": True,
               "Source": "/var/lib/docker/volumes/" + name + "/_data",
               "Driver": "local", "Mode": "z", "Propagation": ""}
              for dest, name in zip(DESTINATIONS, NAMES)]
    outer = {"Id": OUTER, "Name": "/" + DIND,
             "Image": "sha256:20cca7e2a7da287ded85087ce88d443a5347163eebf6a9ed0c27bc4cabe90ae7",
             "Config": {"Labels": {"omne.r5.helper-prep": "selftest"}},
             "HostConfig": {"PortBindings": {}, "NetworkMode": "selftest-net"},
             "Mounts": mounts,
             "State": {"Status": "running", "Running": True, "Pid": 30,
                       "StartedAt": "2026-09-27T00:00:00Z"}}
    add("d-outer-inspect-before", [outer])
    for index, name in enumerate(NAMES):
        add(f"d-volume-before-{index}", [{"Name": name, "Driver": "local",
            "Mountpoint": "/var/lib/docker/volumes/" + name + "/_data",
            "Labels": {"omne.r5.helper-prep": "selftest"}}])
    add("d-namespace-before", "pid:[111]\n")
    add("d-one-outer-sigkill", OUTER + "\n",
        argv=["docker", "kill", "--signal=SIGKILL", OUTER])
    dead = copy.deepcopy(outer)
    dead["State"].update(Status="exited", Running=False, Pid=0, ExitCode=137)
    add("d-outer-inspect-dead", [dead])
    add("d-explicit-start-same-dind", OUTER + "\n",
        argv=["docker", "start", OUTER])
    restored = copy.deepcopy(outer)
    restored["State"].update(Pid=40, StartedAt="2026-09-27T00:00:30Z")
    restored["Mounts"].reverse()  # The oracle compares by Destination.
    add("d-outer-inspect-after", [restored])
    for index, name in enumerate(NAMES):
        add(f"d-volume-after-{index}", [{"Name": name, "Driver": "local",
            "Mountpoint": "/var/lib/docker/volumes/" + name + "/_data",
            "Labels": {"omne.r5.helper-prep": "selftest"}}])
    add("d-namespace-after", "pid:[222]\n")
    rows.extend(prior[last:-1])
    for label in ("p-center-recovered", "p-recovered-observe-1", "p-recovered-observe-2"):
        path = run / "raw" / (label + ".stdout")
        found = json.loads(path.read_bytes())
        found[0]["State"]["Pid"] = 123  # Same integer in a new namespace is valid.
        found[0]["RestartCount"] = 2  # No exact +1 assumption across daemon loss.
        path.write_bytes(encode(found))
    status_path = run / "raw/p-status-recovered.stdout"
    status = json.loads(status_path.read_bytes())
    status["restartCount"] = 2
    status_path.write_bytes(encode(status))
    add("d-center-events-new-engine", {"Action": "start", "Actor": {"ID": p.CID}})
    add("d-outer-events", b"".join(encode({"Action": action,
        "Actor": {"ID": OUTER, "Attributes": attrs}}) for action, attrs in (
            ("kill", {"signal": "9"}), ("die", {"exitCode": "137"}), ("start", {}))))
    evidence["commands"] = rows
    gate = {"approved": True, "reviewer": "root",
            "inputs_sha256": hashlib.sha256(json.dumps(evidence["inputs"], sort_keys=True,
                separators=(",", ":")).encode()).hexdigest(),
            "driver_sha256": evidence["inputs"]["sha256"]["driver"],
            "oracle_sha256": evidence["inputs"]["sha256"]["oracle"]}
    (frozen / "reviewed-gate.json").write_text(json.dumps(gate) + "\n")
    (run / "evidence.json").write_text(json.dumps(evidence) + "\n")
    return evidence


def modify_json(run, label, mutation):
    path = run / "raw" / (label + ".stdout")
    value = json.loads(path.read_bytes())
    mutation(value)
    path.write_bytes(encode(value))


def check(name, mutation=None, *, valid=False):
    with tempfile.TemporaryDirectory(dir=HERE, prefix=".d-selftest-") as directory:
        run = pathlib.Path(directory)
        evidence = fixture(run)
        if mutation is not None:
            mutation(run, evidence)
            (run / "evidence.json").write_text(json.dumps(evidence) + "\n")
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                oracle.evaluate(run)
        except (ValueError, KeyError, IndexError, TypeError) as error:
            if valid:
                raise AssertionError(name + ": positive fixture rejected") from error
            return
        if not valid:
            raise AssertionError(name + ": false success accepted")


def main():
    check("same-numeric-pid-new-namespace-and-reordered-mounts", valid=True)
    cases = [
        ("wrong-outer-target", lambda _r, e: next(row for row in e["commands"]
            if row["label"] == "d-one-outer-sigkill")["argv"].__setitem__(-1, p.CID)),
        ("outer-no-exit137", lambda r, _e: modify_json(r, "d-outer-inspect-dead",
            lambda value: value[0]["State"].update(ExitCode=0))),
        ("outer-event-no-die", lambda r, _e: (r / "raw/d-outer-events.stdout")
            .write_bytes(encode({"Action": "start", "Actor": {"ID": OUTER}}))),
        ("changed-mount-source", lambda r, _e: modify_json(r, "d-outer-inspect-after",
            lambda value: value[0]["Mounts"][0].update(Source="/unrelated"))),
        ("changed-volume-record", lambda r, _e: modify_json(r, "d-volume-after-2",
            lambda value: value[0].update(Mountpoint="/unrelated"))),
        ("same-namespace", lambda r, _e: (r / "raw/d-namespace-after.stdout")
            .write_text("pid:[111]\n")),
        ("manual-inner-start", lambda _r, e: e["commands"].insert(
            next(index for index, row in enumerate(e["commands"])
                 if row["label"] == "p-center-recovered"),
            {"label": "illicit", "argv": ["docker", "exec", p.CONTROL, "docker",
             "--host", "unix:///opt/omne-private-docker/docker.sock", "start", p.CID]})),
        ("no-new-engine-start-event", lambda r, _e:
            (r / "raw/d-center-events-new-engine.stdout").write_bytes(b"")),
        ("pending-backup-false-completion", lambda r, e: (
            (r / "raw/p-pending-backup.stdout").write_text('{"status":"completed"}\n'),
            next(row for row in e["commands"] if row["label"] == "p-pending-backup")
                .update(returncode=0))),
        ("lost-public-team", lambda r, _e: modify_json(r, "p-cli-current-after",
            lambda value: value["remote"]["reply"]["reply"].update(result={"other": True}))),
        ("changed-plaintext-hash", lambda r, _e:
            (r / "raw/p-after-snapshot-sha.stdout").write_bytes(
                ("0" * 64 + "  " + p.SNAPSHOT + "\n").encode())),
        ("probe-used-QA-image", lambda r, _e: modify_json(r, "p-original-serve-inspect",
            lambda value: value[0].update(Image=p.QA_IMAGE))),
        ("gate-rearmed", lambda r, _e: (r / "raw/p-center-logs.stderr").write_text(
            json.dumps({"event": "qa-generation", "branch": "armed"}) + "\n" +
            json.dumps({"event": "qa-generation", "branch": "armed"}) + "\n")),
    ]
    for name, mutation in cases:
        check(name, mutation)
    print(json.dumps({"status": "pass", "synthetic_positive": 1,
                      "rejected_mutations": len(cases), "docker_executed": False,
                      "cases": [name for name, _ in cases]}, sort_keys=True))


if __name__ == "__main__":
    main()
