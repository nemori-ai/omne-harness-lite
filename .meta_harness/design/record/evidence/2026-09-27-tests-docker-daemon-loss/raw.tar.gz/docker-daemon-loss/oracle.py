#!/usr/bin/env python3
"""Read-only D oracle for private daemon loss and preserved public facts."""

import hashlib
import json
import pathlib
import re
import sys
from datetime import datetime

I3_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
BUILD_ID = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
CLI_BUILD_ID = "f38e46f1f169aea8993640c8ccf0ffc42545f2d64adf21f96b6658b2c83bb9f1"
CLI_SHA = "b8431b6cdb176af43fe9af2002bbc480f927fdbcf64c69c8553f6ceab08e471c"
HELPER_SHA = "71ba9f3c31b34c171dd2a4048d9e249af31f7948abcf66ee603da5ffb7d1b365"
DOCKER_SPEC_SHA = "3720aebc99049832b794550f5892c540dacac2eac4018e120eda3be029de0223"
SNAPSHOT = re.compile(r"/var/lib/omne-tenancy/state/backups/\.quarantine/task-[0-9a-f]{32}/snapshot\.sqlite\Z")
CID = re.compile(r"[0-9a-f]{64}\Z")
SHA = re.compile(r"[0-9a-f]{64}\Z")
SQLITE_HEADER = b"SQLite format 3\0"
MARKER_CONTENT = b"omne-isolated/1\n"


def need(value, message):
    if not value:
        raise ValueError(message)


def json_one(data, label):
    need(data.endswith(b"\n") and data.count(b"\n") == 1,
         label + ": one complete JSON+LF required")
    result = json.loads(data)
    need(isinstance(result, dict), label + ": object required")
    return result


def evaluate(run):
    e = json.loads((run / "evidence.json").read_text())
    rows = e["commands"]
    by = {item["label"]: item for item in rows}
    need(len(by) == len(rows) and e["scenario"] == "D" and e["business_complete"] is True,
         "D business observation incomplete or duplicate command")
    need(e["artifact_manifest_sha256"] == I3_SHA
         and e["inputs"]["build_id"] == BUILD_ID
         and e["inputs"]["cli_build_id"] == CLI_BUILD_ID
         and e["inputs"]["sha256"]["i3_manifest"] == I3_SHA
         and e["inputs"]["sha256"]["cli_tar"] == CLI_SHA
         and e["inputs"]["sha256"]["helper"] == HELPER_SHA
         and e["inputs"]["sha256"]["docker_spec"] == DOCKER_SPEC_SHA
         and e["inputs"]["qa_gate_mode"] == "write-hold",
         "reviewed artifact/pilot identity differs")
    gate_path = run / "inputs/reviewed-gate.json"
    need(gate_path.is_file() and not gate_path.is_symlink(), "frozen root gate absent")
    gate = json.loads(gate_path.read_text())
    payload = json.dumps(e["inputs"], sort_keys=True, separators=(",", ":")).encode()
    need(gate.get("approved") is True and gate.get("reviewer") == "root"
         and gate.get("inputs_sha256") == hashlib.sha256(payload).hexdigest()
         and gate.get("driver_sha256") == e["inputs"]["sha256"]["driver"]
         and gate.get("oracle_sha256") == e["inputs"]["sha256"]["oracle"],
         "frozen root gate does not bind actual pilot inputs")
    for name, key in (("driver.py", "driver"), ("oracle.py", "oracle"),
                      ("base_driver.py", "base_driver"), ("io_driver.py", "io_driver"),
                      ("gate.mjs", "gate"), ("gate_availability.mjs", "gate_availability"),
                      ("inventory.mjs", "inventory"), ("p_driver.py", "p_driver"),
                      ("cli.tar.gz", "cli_tar"),
                      ("i3-manifest.json", "i3_manifest")):
        path = run / "inputs" / name
        need(path.is_file() and not path.is_symlink() and
             hashlib.sha256(path.read_bytes()).hexdigest() ==
             e["inputs"]["sha256"][key], "frozen input differs: " + name)
    need(e["cleanup_complete"] is True and e["cleanup_errors"] == [],
         "fixture cleanup incomplete")

    def row(label, code=0):
        need(label in by, label + ": observation absent")
        item = by[label]
        need(item["returncode"] == code and item.get("observation_expired") is False,
             label + ": actual CLI exit/observation differs")
        return item

    def raw(label, stream="stdout"):
        item = by[label]
        path = run / item[stream]
        need(path.parent == run / "raw" and path.is_file(), label + ": raw stream absent")
        return path.read_bytes()

    def obj(label, code=0):
        row(label, code)
        return json_one(raw(label), label)

    def inspected(label, cid):
        row(label)
        data = json.loads(raw(label))
        need(isinstance(data, list) and len(data) == 1 and data[0].get("Id") == cid,
             label + ": actual exact center ID differs")
        return data[0]

    order = [item["label"] for item in rows]
    stages = ("p-validate", "p-start", "p-gate-ready", "p-center-initial",
              "p-cli-register", "p-cli-login", "p-cli-create-team",
              "p-cli-current-before", "p-cli-list-before", "p-prior-backup",
              "p-prior-backup-status", "p-arm-gate", "p-pending-backup", "p-gate-held",
              "p-held-fd-link", "p-before-find-snapshot", "p-before-snapshot-stat",
              "p-center-stable-first", "p-center-stable-last", "d-center-before-fault",
              "d-outer-inspect-before", "d-volume-before-0", "d-volume-before-1",
              "d-volume-before-2", "d-namespace-before", "d-one-outer-sigkill",
              "d-outer-inspect-dead", "d-explicit-start-same-dind",
              "d-outer-inspect-after", "d-volume-after-0", "d-volume-after-1",
              "d-volume-after-2", "d-namespace-after",
              "p-center-recovered", "p-status-recovered", "p-full-health-recovered",
              "p-backup-status-recovered", "p-cli-current-after", "p-cli-list-after",
              "p-after-snapshot-stat", "p-original-serve", "p-original-serve-inspect",
              "p-original-serve-logs", "p-probe-after-snapshot-stat", "p-center-logs",
              "d-center-events-new-engine", "d-outer-events")
    need(all(label in by for label in stages)
         and [order.index(label) for label in stages] ==
             sorted(order.index(label) for label in stages), "D stage order changed")
    for label in stages:
        if label not in ("p-pending-backup", "p-original-serve"):
            row(label)
    need(obj("p-validate")["state"] == "deployment-structure-valid",
         "formal helper validate did not pass")
    start = obj("p-start")
    cid = start.get("containerId")
    need(isinstance(cid, str) and CID.fullmatch(cid)
         and cid == e["center_id"] and start.get("state") == "running"
         and start.get("health") == "healthy", "actual helper start was not healthy")
    initial = inspected("p-center-initial", cid)
    before = inspected("d-center-before-fault", cid)
    stable_first = inspected("p-center-stable-first", cid)
    stable_last = inspected("p-center-stable-last", cid)
    for value in (initial, stable_first, stable_last, before):
        need(value["State"]["Status"] == "running"
             and value["State"]["Health"]["Status"] == "healthy"
             and value["State"]["Running"] is True
             and value["HostConfig"]["RestartPolicy"]["Name"] == "unless-stopped"
             and value["RestartCount"] == initial["RestartCount"] == 0
             and value["State"]["StartedAt"] == initial["State"]["StartedAt"],
             "not one stable healthy auto-restart center before fault")
    need(stable_first["State"]["Pid"] == stable_last["State"]["Pid"] ==
         before["State"]["Pid"] and
         e["stable_finished_monotonic_ns"] - e["stable_started_monotonic_ns"] >=
         e["inputs"]["stable_seconds"] * 1_000_000_000 and
         (datetime.fromisoformat(by["p-center-stable-last"]["started_utc"]) -
          datetime.fromisoformat(by["p-center-stable-first"]["started_utc"])).total_seconds()
         >= e["inputs"]["stable_seconds"],
         "PID or stable pre-fault interval changed")

    original_inventory = obj("original-inventory")
    qa_inventory = obj("qa-inventory")
    need(original_inventory == qa_inventory and original_inventory["status"] == "verified"
         and original_inventory["buildId"] == BUILD_ID,
         "QA image altered packaged app files")
    original_image = inspected("inner-image-inspect", e["expected"]["inner_image_id"])
    qa_image = inspected("qa-image-inspect", e["qa_image_id"])
    original_config = original_image["Config"]
    qa_config = qa_image["Config"]
    need(qa_image["Config"]["Labels"]["ai.nemori.omne.qa-fixture"] ==
         "maintenance-gate/r5" and
         qa_config["Env"].count("NODE_OPTIONS=--import=/probe/gate.mjs") == 1
         and sorted(qa_config["Env"]) ==
             sorted([*original_config["Env"], "NODE_OPTIONS=--import=/probe/gate.mjs"])
         and all(qa_config[key] == original_config[key] for key in
                 ("Entrypoint", "Cmd", "WorkingDir"))
         and len(qa_image["RootFS"]["Layers"]) > len(original_image["RootFS"]["Layers"])
         and qa_image["RootFS"]["Layers"][:len(original_image["RootFS"]["Layers"])] ==
             original_image["RootFS"]["Layers"],
         "QA preload/image identity differs")
    need(obj("gate-availability")["status"] == "pass", "QA gate unavailable")
    need(obj("p-gate-ready")["mode"] == "write-hold", "first generation gate not armed")
    for suffix in ("before", "after"):
        row("p-generation-stat-" + suffix)
        row("p-generation-content-" + suffix)
        need(raw("p-generation-stat-" + suffix) == b"regular file:10001:10001:600:21\n"
             and raw("p-generation-content-" + suffix) == b"omne-qa-generation/1\n",
             "one protected QA generation claim not retained")

    def cli(label):
        report = obj(label)
        need(report.get("format") == "governance-client/1"
             and report.get("remote", {}).get("status") == "success"
             and report.get("defect") is None, label + ": public report not successful")
        return report

    def result(label):
        report = cli(label)
        value = report.get("remote", {}).get("reply", {}).get("reply", {}).get("result")
        need(value is not None, label + ": public fact absent")
        return value

    for label in ("p-cli-configure", "p-cli-register", "p-cli-login", "p-cli-switch"):
        cli(label)
    for label in ("p-cli-register", "p-cli-login"):
        argv = by[label]["argv"]
        need("--credential-file" in argv and "--login-identifier" in argv
             and not any("credential.secret" == arg for arg in argv),
             "public CLI credential not file-bound")
    personal = result("p-cli-personal-before")
    organization = result("p-cli-create-team")
    team = {"account": personal["account"], "organization": organization}
    current0 = result("p-cli-current-before")
    list0 = result("p-cli-list-before")
    current1 = result("p-cli-current-after")
    list1 = result("p-cli-list-after")
    need(current0 == current1 == team and list0 == list1
         and personal in list0 and team in list0,
         "public confirmed account/team/current facts changed after crash")
    health0 = cli("p-cli-health-before")["remote"]["health"]
    health1 = cli("p-cli-health-after")["remote"]["health"]
    full0 = obj("p-full-health-before")
    full1 = obj("p-full-health-recovered")
    for health in (full0, full1):
        need(all(health.get(key) is True for key in
                 ("reachable", "storageReachable", "clockSane", "deploymentKeyPresent",
                  "deploymentKeyComplete")) and health.get("defectCount") == 0,
             "full health not actually healthy")
    need(full0["centerId"] == full1["centerId"] == health0["centerId"] ==
         health1["centerId"] == cli("p-cli-current-before")["origin"]["centerId"] ==
         cli("p-cli-current-after")["origin"]["centerId"],
         "public governance center identity changed")

    prior = obj("p-prior-backup")
    need(prior.get("status") == "completed" and isinstance(prior.get("backup"), dict),
         "prior backup not actually completed")
    descriptor = prior["backup"]
    need(descriptor.get("metadata", {}).get("centerId") == full0["centerId"],
         "prior backup did not belong to confirmed center")
    for label in ("p-prior-backup-status", "p-backup-status-recovered"):
        status = obj(label)
        need(status.get("status") == "observed" and status.get("health") == "current"
             and status.get("latest") == descriptor and status.get("invalidCount") == 0,
             label + ": previously completed backup no longer confirmed")
    need(sum(1 for item in rows if item["argv"][:7] ==
             ["docker", "exec", "-e", "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock",
              e["expected"]["control"], "/usr/local/libexec/omne-center", "backup"]) == 2,
         "unknown backup was replayed or prior completed backup absent")
    pending = by["p-pending-backup"]
    need(datetime.fromisoformat(pending["started_utc"]) <
         datetime.fromisoformat(by["d-one-outer-sigkill"]["started_utc"])
         and raw("p-pending-backup") == b"",
         "lost in-flight backup acquired a result or was misreported completed")
    need(obj("p-gate-held")["stage"] == "write", "real export FD was not held")
    held = obj("p-gate-held")
    need(held["pid"] == 1 and re.fullmatch(r"/state/backups/\.quarantine/export-[0-9a-f]{32}",
                                            held["path"]), "held export path/PID invalid")
    need(raw("p-held-fd-link").strip().decode() == held["path"],
         "held FD did not name the actual export")
    fd_stat = raw("p-held-fd-stat").decode().strip().split(":")
    need(len(fd_stat) == 5 and fd_stat[2:] == ["10001", "10001", "600"]
         and int(fd_stat[0]) == held["dev"] and int(fd_stat[1]) == held["ino"],
         "held FD not protected owned regular export")

    snapshot = e["snapshot_path"]
    need(isinstance(snapshot, str) and SNAPSHOT.fullmatch(snapshot)
         and raw("p-before-find-snapshot").decode().splitlines() == [snapshot],
         "not one real task snapshot.sqlite in fresh quarantine")
    for phase in ("p-before", "p-after", "p-probe-after"):
        for suffix in ("task-stat", "snapshot-stat", "snapshot-sha", "snapshot-header",
                       "marker-stat", "marker-content"):
            row(phase + "-" + suffix)
        need(raw(phase + "-snapshot-header") == SQLITE_HEADER,
             "actual plaintext SQLite snapshot header absent")
        need(raw(phase + "-marker-content") == MARKER_CONTENT,
             "permanent isolation marker content absent")
        need(raw(phase + "-snapshot-stat").startswith(b"regular file:")
             and raw(phase + "-snapshot-stat").decode().strip().split(":")[3:6] ==
                 ["10001", "10001", "600"]
             and int(raw(phase + "-snapshot-stat").decode().strip().split(":")[6]) > 16,
             "snapshot is not nonempty app-owned 0600 plaintext")
        need(raw(phase + "-task-stat").startswith(b"directory:")
             and raw(phase + "-task-stat").decode().strip().split(":")[3:] ==
                 ["10001", "10001", "700"],
             "snapshot task directory not app-owned private")
        sha_line = raw(phase + "-snapshot-sha").decode().strip().split("  ")
        need(len(sha_line) == 2 and SHA.fullmatch(sha_line[0]) and sha_line[1] == snapshot,
             "snapshot sha256 did not bind exact retained path")
        marker_parts = raw(phase + "-marker-stat").decode().strip().split(":")
        need(marker_parts[0] == "regular file" and marker_parts[3:] ==
             ["10001", "10001", "600", "16"], "marker owner/mode/length invalid")
    for suffix in ("task-stat", "snapshot-stat", "snapshot-sha", "snapshot-header",
                   "marker-stat", "marker-content"):
        need(raw("p-before-" + suffix) == raw("p-after-" + suffix) ==
             raw("p-probe-after-" + suffix),
             "protected snapshot/marker changed across actual process crash: " + suffix)
    serve = row("p-original-serve", 1)
    need(serve["observation_expired"] is False,
         "original host serve result not actually complete")
    probe = e["original_serve_probe"]
    storage_file = "/state" + snapshot[len("/var/lib/omne-tenancy/state"):]
    need(probe["storage_file"] == storage_file and
         re.fullmatch(r"omne-r5[a-z0-9]+-isolated-probe", probe["name"]),
         "original serve did not receive exact retained snapshot path")
    inspected_probe = inspected("p-original-serve-inspect", json.loads(
        raw("p-original-serve-inspect"))[0]["Id"])
    mount_list = inspected_probe["Mounts"]
    need(isinstance(mount_list, list) and len(mount_list) == 2
         and len({m["Destination"] for m in mount_list}) == 2,
         "original serve probe mount shape")
    mounts = {m["Destination"]: m for m in mount_list}
    env_lines = inspected_probe["Config"]["Env"]
    need(len(env_lines) == len({line.split("=", 1)[0] for line in env_lines})
         and all("=" in line for line in env_lines), "probe env duplicate/malformed")
    env = dict(line.split("=", 1) for line in env_lines)
    expected_pem = {
        "OMNE_TENANCY_ACTIVATION_SIGNING_KEY_PEM_FILE": "/secrets/activation-signing-key.pem",
        "OMNE_TENANCY_ACTIVATION_VERIFICATION_KEY_PEM_FILE": "/secrets/activation-verification-key.pem",
        "OMNE_TENANCY_PURGE_SIGNING_KEY_PEM_FILE": "/secrets/purge-signing-key.pem",
        "OMNE_TENANCY_PURGE_VERIFICATION_KEY_PEM_FILE": "/secrets/purge-verification-key.pem",
        "OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE": "/secrets/tls-chain.pem",
        "OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE": "/secrets/tls-private.pem",
    }
    need(inspected_probe["Name"] == "/" + probe["name"]
         and inspected_probe["Image"] == e["expected"]["inner_image_id"]
         and inspected_probe["State"]["Status"] == "exited"
         and inspected_probe["State"]["ExitCode"] == 1
         and inspected_probe["HostConfig"]["NetworkMode"] == "none"
         and inspected_probe["HostConfig"]["RestartPolicy"]["Name"] == "no"
         and not inspected_probe["HostConfig"].get("PortBindings")
         and set(mounts) == {"/state", "/secrets"}
         and mounts["/state"]["Type"] == mounts["/secrets"]["Type"] == "bind"
         and mounts["/state"]["Source"] == e["expected"]["state"]
         and mounts["/state"]["RW"] is True
         and mounts["/secrets"]["Source"] ==
             str(pathlib.PurePosixPath(e["expected"]["state"]).parent / "secrets")
         and mounts["/secrets"]["RW"] is False
         and inspected_probe["Config"]["User"] == "10001:10001"
         and inspected_probe["Config"]["Entrypoint"] ==
             ["node", "/opt/omne/app/dist/cli.js"]
         and inspected_probe["Config"]["Cmd"] == ["serve"]
         and inspected_probe["Path"] == "node"
         and inspected_probe["Args"] == ["/opt/omne/app/dist/cli.js", "serve"]
         and env.get("OMNE_TENANCY_STORAGE_DIALECT") == "sqlite"
         and env.get("OMNE_TENANCY_STORAGE_FILE") == storage_file
         and env.get("OMNE_TENANCY_BACKUP_DIR") == "/state/backups"
         and env.get("OMNE_TENANCY_OPS_SOCKET_DIR") == "/run/omne-tenancy"
         and env.get("OMNE_TENANCY_ENTRY_LISTEN") == "0.0.0.0:8443"
         and all(env.get(key) == value for key, value in expected_pem.items())
         and "NODE_OPTIONS" not in env
         and set(inspected_probe["HostConfig"].get("Tmpfs") or {}) ==
             {"/run/omne-tenancy"},
         "not original final host serve with exact retained snapshot/full state")
    logs = raw("p-original-serve-logs") + raw("p-original-serve-logs", "stderr")
    events = []
    for line in logs.splitlines():
        try:
            event = json.loads(line)
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        if isinstance(event, dict):
            events.append(event)
    need(any(event.get("event") == "startup-failed"
             and event.get("stage") == "storage-open"
             and "isolated maintenance data cannot be opened as production storage"
                 in event.get("message", "") for event in events)
         and not any(event.get("event") == "serving" for event in events),
         "original host publicly opened isolated plaintext or failed for other reason")

    outer_id = e["outer_id"]
    need(isinstance(outer_id, str) and CID.fullmatch(outer_id),
         "outer DinD ID was not captured")
    outer_before = inspected("d-outer-inspect-before", outer_id)
    outer_dead = inspected("d-outer-inspect-dead", outer_id)
    outer_after = inspected("d-outer-inspect-after", outer_id)
    expected_mounts = {
        "/var/lib/omne-tenancy": 0,
        "/opt/omne-private-docker": 1,
        "/var/lib/docker": 2,
    }

    def mounts_by_destination(found):
        mounts = found["Mounts"]
        need(isinstance(mounts, list) and len(mounts) == 3
             and len({m["Destination"] for m in mounts}) == 3,
             "outer DinD has nonunique or missing mounts")
        return {m["Destination"]: m for m in mounts}

    old_mounts = mounts_by_destination(outer_before)
    new_mounts = mounts_by_destination(outer_after)
    need(old_mounts == new_mounts and set(old_mounts) == set(expected_mounts),
         "private DinD whole mount records changed")
    names = [old_mounts[dest]["Name"] for dest in expected_mounts]
    prefix = e["expected"]["dind"].removesuffix("-dind")
    need(e["expected"]["dind"] == prefix + "-dind"
         and names == [prefix + "-" + suffix for suffix in ("data", "socket", "daemon")],
         "private volume names do not belong to exact DinD")
    for dest, index in expected_mounts.items():
        mount = old_mounts[dest]
        need(mount["Type"] == "volume" and mount["RW"] is True
             and mount["Name"] == names[index], "unexpected private mount")
        old_volume = json.loads(raw(f"d-volume-before-{index}"))[0]
        new_volume = json.loads(raw(f"d-volume-after-{index}"))[0]
        need(old_volume == new_volume and old_volume["Name"] == names[index]
             and old_volume["Labels"].get("omne.r5.helper-prep") == e["run_id"],
             "private volume full record or run ownership changed")
    for found in (outer_before, outer_after):
        need(found["Name"] == "/" + e["expected"]["dind"]
             and found["Image"] == "sha256:20cca7e2a7da287ded85087ce88d443a5347163eebf6a9ed0c27bc4cabe90ae7"
             and found["Config"]["Labels"].get("omne.r5.helper-prep") == e["run_id"]
             and not found["HostConfig"].get("PortBindings"),
             "fault target was not this private labelled DinD")
    need(outer_before["State"]["Status"] == "running"
         and outer_before["State"]["Running"] is True
         and type(outer_before["State"]["Pid"]) is int
         and outer_before["State"]["Pid"] > 0
         and outer_dead["State"]["Status"] == "exited"
         and outer_dead["State"]["ExitCode"] == 137
         and outer_after["State"]["Status"] == "running"
         and outer_after["State"]["Running"] is True
         and type(outer_after["State"]["Pid"]) is int
         and outer_after["State"]["Pid"] > 0
         and outer_after["State"]["StartedAt"] != outer_before["State"]["StartedAt"],
         "one outer non-graceful exit and same-ID restart not observed")
    namespace_before = raw("d-namespace-before").strip().decode()
    namespace_after = raw("d-namespace-after").strip().decode()
    need(re.fullmatch(r"pid:\[[0-9]+\]", namespace_before)
         and re.fullmatch(r"pid:\[[0-9]+\]", namespace_after)
         and namespace_before != namespace_after,
         "restored DinD did not enter a new PID namespace")
    need(row("d-one-outer-sigkill")["argv"] ==
         ["docker", "kill", "--signal=SIGKILL", outer_id]
         and raw("d-one-outer-sigkill").strip().decode() == outer_id
         and row("d-explicit-start-same-dind")["argv"] ==
             ["docker", "start", outer_id]
         and raw("d-explicit-start-same-dind").strip().decode() == outer_id,
         "fault or fixture recovery command did not target exact outer DinD")
    outer_events = [json.loads(line) for line in raw("d-outer-events").splitlines()]
    same_outer = [event for event in outer_events
                  if event.get("Actor", {}).get("ID") == outer_id]
    outer_actions = [event.get("Action") for event in same_outer]
    need(outer_actions.count("kill") == outer_actions.count("die") ==
         outer_actions.count("start") == 1
         and outer_actions.index("kill") < outer_actions.index("die") <
             outer_actions.index("start")
         and next(event for event in same_outer if event["Action"] == "die")
             .get("Actor", {}).get("Attributes", {}).get("exitCode") == "137",
         "outer Engine did not record one SIGKILL death and start")
    fault_index = order.index("d-one-outer-sigkill")
    for item in rows[fault_index:]:
        argv = item["argv"]
        if argv[:2] in (["docker", "kill"], ["docker", "start"], ["docker", "restart"]):
            need(item["label"] in ("d-one-outer-sigkill", "d-explicit-start-same-dind"),
                 "unreviewed outer lifecycle mutation after fault")
        if "/usr/local/libexec/omne-center" in argv:
            action = argv[argv.index("/usr/local/libexec/omne-center") + 1]
            need(action not in ("start", "stop"),
                 "driver issued inner center lifecycle command after fault")
        if "--host" in argv and "unix:///opt/omne-private-docker/docker.sock" in argv:
            host_index = argv.index("unix:///opt/omne-private-docker/docker.sock")
            if host_index + 1 < len(argv):
                need(argv[host_index + 1] not in ("start", "stop", "restart", "kill"),
                     "driver issued inner Engine lifecycle command after fault")

    recovered = inspected("p-center-recovered", cid)
    need(recovered["State"]["Status"] == "running"
         and recovered["State"]["Health"]["Status"] == "healthy"
         and recovered["State"]["StartedAt"] != before["State"]["StartedAt"]
         and type(recovered["State"]["Pid"]) is int and recovered["State"]["Pid"] > 0,
         "same inner center did not return with new StartedAt and positive PID")
    status_after = obj("p-status-recovered")
    need(status_after["state"] == "running" and status_after["health"] == "healthy"
         and status_after["containerId"] == cid
         and status_after["restartCount"] == recovered["RestartCount"],
         "formal status did not observe recovered exact center")
    observed = [label for label in order if label.startswith("p-recovered-observe-")]
    need(len(observed) >= 2 and observed[-1] == e["recovered_observation_last_label"]
         and e["recovered_observation_finished_monotonic_ns"] -
             e["recovered_observation_started_monotonic_ns"] >=
             e["inputs"]["restart_observe_seconds"] * 1_000_000_000,
         "finite post-restart observation incomplete")
    for label in observed:
        item = inspected(label, cid)
        need(item["State"]["Status"] == "running"
             and item["State"]["Health"]["Status"] == "healthy"
             and item["State"]["StartedAt"] == recovered["State"]["StartedAt"]
             and item["RestartCount"] == recovered["RestartCount"],
             "center changed during post-restart observation")
    started_first = datetime.fromisoformat(by[observed[0]]["started_utc"])
    started_last = datetime.fromisoformat(by[observed[-1]]["started_utc"])
    need((started_last - started_first).total_seconds() >=
         e["inputs"]["restart_observe_seconds"],
         "final inspect started before observation deadline")
    events = [json.loads(line) for line in raw("d-center-events-new-engine").splitlines()]
    same_center = [item for item in events if item.get("Actor", {}).get("ID") == cid]
    need(any(item.get("Action") == "start" for item in same_center),
         "new private Engine did not record exact center start")
    logs = [json.loads(line) for line in raw("p-center-logs", "stderr").splitlines()
            if line.startswith(b"{")]
    generation = [line.get("branch") for line in logs if line.get("event") == "qa-generation"]
    need(len(generation) >= 2 and generation[0] == "armed"
         and generation.count("armed") == 1
         and all(branch == "pass-through" for branch in generation[1:]),
         "one-generation QA gate did not pass through recovered serve")
    print(json.dumps({"status": "limited_pass", "scenario": "D",
                      "containerId": cid, "oldPid": before["State"]["Pid"],
                      "newPid": recovered["State"]["Pid"],
                      "oldRestartCount": before["RestartCount"],
                      "newRestartCount": recovered["RestartCount"],
                      "outerId": outer_id,
                      "snapshotSha256": raw("p-before-snapshot-sha").decode().split()[0],
                      "checks": 32}, sort_keys=True, indent=2))


if __name__ == "__main__":
    try:
        evaluate(pathlib.Path(sys.argv[1]).resolve())
    except BaseException as error:
        print(json.dumps({"status": "unverified",
                          "error": f"{type(error).__name__}: {error}"}, indent=2))
        raise SystemExit(1)
