# D daemon-loss run: bounded source-check reassessment

This is a separate interpretation of completed run `20260927T023116Z-f00f3c2f`
on branch `pandazki/agent-work-loop-docker-recovery`, HEAD
`a91b889750d2cd819bf066b0e950bb9225fffdd4`. The original frozen oracle
still exits 1 with `unverified: frozen input differs: io_driver.py`; its stdout,
raw observations, and 446 run files were not edited. The new verdict is
`limited_pass_reassessment`, subject to root review and acceptance.

The sole measurement correction is the original oracle's impossible frozen
`io_driver.py` entry. The run has no `inputs/io_driver.py` and no
`evidence.inputs.sha256.io_driver`, while `static-manifest.json` binds candidate
`io_driver.py` SHA-256
`f1c4f815fa8d0e8d7260d59e0d49c08a7c60037f719880bed055f4f09ecfe646`.
The evaluator checks that exact candidate file, the root static source review,
approved gate, actual-start and actual-result records, postrun source index,
frozen driver/oracle/gate, and original exit 1. It then loads the **hash-bound
original frozen oracle** in memory with only that tuple deleted. Every other
source-input check and all behavioral assertions execute unchanged. No file
inside the original run is rewritten or copied into a repaired run.

Commands, run from the worktree root with Python 3.12.7:

```sh
PYTHONDONTWRITEBYTECODE=1 /Users/pandazki/.local/share/uv/python/cpython-3.12.7-macos-aarch64-none/bin/python3.12 -B tmp/docker-daemon-loss-reassessment/reassess.py > tmp/docker-daemon-loss-reassessment/reassessment.stdout
PYTHONDONTWRITEBYTECODE=1 /Users/pandazki/.local/share/uv/python/cpython-3.12.7-macos-aarch64-none/bin/python3.12 -B tmp/docker-daemon-loss-reassessment/self_test.py > tmp/docker-daemon-loss-reassessment/self-test.stdout
```

`verdict.json` contains the distinct verdict and the original behavioral
oracle's 32-check result. `original-run-before.sha256.json` and
`original-run-after.sha256.json` list all 446 original-run files; the maps are
identical. `self-test.stdout` records acceptance of the reviewed source bytes
and rejection of a one-byte tamper. `sha256.json` identifies this package's
files. The source-chain check deliberately retains the original absolute
worktree paths, so this reassessment does not claim that the evidence is
relocatable.

The bounded finding is same-schema private DinD loss: the labelled outer DinD
exited 137 after SIGKILL, the fixture explicitly started that same DinD, and
the same inner center CID recovered without a test-side inner start. Public
confirmed facts and the prior completed backup remained observable, the
pending backup stayed unknown without replay, and the protected SQLite
snapshot/marker survived while original-image serve refused that path.
RestartCount's exact increment and numeric PID inequality across namespaces
are not criteria. This read-only reassessment did not run Docker or inject a
new fault; it does not cover disk loss, physical power loss, schema migration,
or arbitrary Engine metadata loss.
