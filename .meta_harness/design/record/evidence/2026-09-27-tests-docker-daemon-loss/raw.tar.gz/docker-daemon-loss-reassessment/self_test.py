#!/usr/bin/env python3
"""One source-binding negative control for the bounded D reassessment."""

import pathlib
import tempfile

import reassess


source = reassess.validate_candidate_io(reassess.ROOT / "io_driver.py", reassess.IO_SHA)
with tempfile.TemporaryDirectory(dir=reassess.HERE) as scratch:
    tampered = pathlib.Path(scratch) / "io_driver.py"
    tampered.write_bytes(source[:-1] + bytes([source[-1] ^ 1]))
    try:
        reassess.validate_candidate_io(tampered, reassess.IO_SHA)
    except ValueError as error:
        assert "source hash differs" in str(error), error
    else:
        raise AssertionError("tampered io_driver.py was accepted")

print("PASS: original candidate io_driver.py accepted; one-byte tamper rejected")
