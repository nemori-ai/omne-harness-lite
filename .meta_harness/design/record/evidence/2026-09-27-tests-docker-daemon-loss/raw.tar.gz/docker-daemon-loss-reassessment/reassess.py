#!/usr/bin/env python3
"""Bounded, read-only reassessment of one completed D run.

The original frozen oracle is executed in memory with exactly one impossible
input-freeze tuple removed. Its other assertions and the original run stay intact.
"""

import contextlib
import hashlib
import io
import json
import pathlib
import sys
from datetime import datetime


HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent / "docker-daemon-loss"
RUN_ID = "20260927T023116Z-f00f3c2f"
RUN = ROOT / "runs" / RUN_ID
HEAD = "a91b889750d2cd819bf066b0e950bb9225fffdd4"
INPUTS_SHA = "2541134a12d629764c7afe59b7d1cf135bfe7ffc75e431ceb2f25d464d8fd65f"
IO_SHA = "f1c4f815fa8d0e8d7260d59e0d49c08a7c60037f719880bed055f4f09ecfe646"
ORACLE_SHA = "59f61d3d84e3acec05531058266935c9e3c069869920dc84bc1ca5b2acd5bad4"
STATIC_SHA = "0d8ff6d475a5327d86df13d3b5bd3ae93bb6c51c46f6020b3ef5fa97d95c5c82"
REVIEW_SHA = "06bce9b911cfcef533e0f9482ebf6f3fe5905a860585050e61053a450eca99e1"
GATE_SHA = "9c010786bd66e661a2f45d378d4acd8733981552c8734ae28db6862797b03bbb"
START_SHA = "c72dd960d74002bb6f24042118e7d845cd85528824b6ee2ec787df6c489b52a4"
RESULT_SHA = "998483d286f05fc5ebf997903a914ed0fcbfdd0cfd2059dc500599b3759e8537"
FILES_SHA = "4f34f0ae0f3e96c0ee70f772aca84b99bab3cbfb1bba6ddd5c22c84b89a9be90"
ARGV_SHA = "60cf21b33aa2d485e9c2473193fea10b92642086960d98e4931a269dc8a918f1"
ACTUAL_STDOUT_SHA = "d99b8920a1571ac6ad9588300486794bbd687c6f668f26abe7e5b09a59386d69"
EVIDENCE_SHA = "d683597ba7564de2a9407770d0f662e07c3508bd75e3ecee52489c45778241af"
ORIGINAL_STDOUT_SHA = "615a2f7573823f111e7aff1d376335b3a648427fb61ea590517548d66b859607"
REMOVED_TUPLE = '("base_driver.py", "base_driver"), ("io_driver.py", "io_driver"),'
REPLACED_TUPLE = '("base_driver.py", "base_driver"),'


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_bound(path, expected):
    require(path.is_file() and not path.is_symlink(), f"missing regular source: {path}")
    data = path.read_bytes()
    require(digest(data) == expected, f"source hash differs: {path}")
    return data


def read_json_bound(path, expected):
    return json.loads(read_bound(path, expected))


def run_snapshot():
    require(RUN.is_dir() and not RUN.is_symlink(), "original run directory absent")
    files = {}
    for path in sorted(RUN.rglob("*")):
        require(not path.is_symlink(), f"original run contains a symlink: {path}")
        if path.is_file():
            files[str(path.relative_to(RUN))] = digest(path.read_bytes())
    require(files, "original run has no files")
    return files


def validate_candidate_io(path, expected):
    return read_bound(path, expected)


def validate_chain():
    static = read_json_bound(ROOT / "static-manifest.json", STATIC_SHA)
    review = read_json_bound(ROOT / "root-static-review.json", REVIEW_SHA)
    gate = read_json_bound(ROOT / "reviewed-gate.json", GATE_SHA)
    start = read_json_bound(ROOT / "root-actual-start.json", START_SHA)
    result = read_json_bound(ROOT / "root-actual-result.json", RESULT_SHA)
    files = read_json_bound(ROOT / "root-actual-files.sha256.json", FILES_SHA)
    argv = read_json_bound(ROOT / "root-run-argv.json", ARGV_SHA)
    e = read_json_bound(RUN / "evidence.json", EVIDENCE_SHA)
    frozen_gate = json.loads(read_bound(RUN / "inputs/reviewed-gate.json", GATE_SHA))
    original_stdout = json.loads(read_bound(RUN / "oracle.stdout", ORIGINAL_STDOUT_SHA))

    require(static["head"] == HEAD and static["candidate_inputs_sha256"] == INPUTS_SHA,
            "static candidate identity differs")
    require(static["candidate_files_sha256"]["io_driver.py"] == IO_SHA,
            "static manifest did not bind io_driver.py")
    validate_candidate_io(ROOT / "io_driver.py", IO_SHA)
    require(review["reviewer"] == "root" and review["source_hashes_verified"] is True
            and review["inputs_sha256"] == INPUTS_SHA,
            "root static source review absent or different")
    require(len(review["checks"]) == 2
            and all(check["returncode"] == 0 for check in review["checks"]),
            "root static measurement-tool checks did not pass")
    require(gate == frozen_gate and gate["approved"] is True
            and gate["reviewer"] == "root" and gate["inputs_sha256"] == INPUTS_SHA,
            "root gate or frozen copy differs")
    require(start["executor"] == "root" and start["inputs_sha256"] == INPUTS_SHA
            and result["executor"] == "root" and result["returncode"] == 1
            and datetime.fromisoformat(start["at"]) < datetime.fromisoformat(result["at"]),
            "root actual start/result chain differs")
    require(original_stdout == {"status": "unverified",
                                "error": "ValueError: frozen input differs: io_driver.py"},
            "original oracle failure changed")
    require(e["run_id"] == RUN_ID and e["scenario"] == "D"
            and e["oracle_exit"] == 1 and e["business_complete"] is True
            and e["cleanup_complete"] is True and e["cleanup_errors"] == []
            and len(e["commands"]) == 192 and e["reviewed_gate_sha256"] == GATE_SHA,
            "original run identity/completion/failure differs")
    require("io_driver.py" not in {p.name for p in (RUN / "inputs").iterdir()}
            and "io_driver" not in e["inputs"]["sha256"],
            "original missing-frozen-input defect changed")
    canonical = json.dumps(e["inputs"], sort_keys=True, separators=(",", ":")).encode()
    require(digest(canonical) == INPUTS_SHA
            and gate["driver_sha256"] == e["inputs"]["sha256"]["driver"]
            and gate["oracle_sha256"] == e["inputs"]["sha256"]["oracle"] == ORACLE_SHA,
            "root gate does not bind frozen run inputs")
    require(argv[2] == str(ROOT / "driver.py") and argv[-1] == "--execute"
            and argv[-3:-1] == ["--reviewed-gate", str(ROOT / "reviewed-gate.json")],
            "actual invocation did not use gated D driver")
    indexed = files["files"]
    require(files["run_id"] == RUN_ID and files["source"] == str(ROOT),
            "root postrun source index differs")
    for relative, expected in {
        "io_driver.py": IO_SHA,
        "driver.py": e["inputs"]["sha256"]["driver"],
        "oracle.py": ORACLE_SHA,
        "reviewed-gate.json": GATE_SHA,
        "static-manifest.json": STATIC_SHA,
        f"runs/{RUN_ID}/inputs/driver.py": e["inputs"]["sha256"]["driver"],
        f"runs/{RUN_ID}/inputs/oracle.py": ORACLE_SHA,
        f"runs/{RUN_ID}/inputs/reviewed-gate.json": GATE_SHA,
        f"runs/{RUN_ID}/evidence.json": EVIDENCE_SHA,
        f"runs/{RUN_ID}/oracle.stdout": ORIGINAL_STDOUT_SHA,
    }.items():
        require(indexed[relative]["sha256"] == expected
                and digest((ROOT / relative).read_bytes()) == expected,
                f"root postrun source chain differs: {relative}")
    driver = read_bound(ROOT / "driver.py", e["inputs"]["sha256"]["driver"])
    require(b"import io_driver\n" in driver and b"io_driver.checked_inputs(io_args)" in driver
            and b"io_driver.IoRun.__init__(self, args, inputs)" in driver,
            "gated driver no longer consumes candidate io_driver")
    actual_stdout = read_json_bound(ROOT / "root-actual.stdout", ACTUAL_STDOUT_SHA)
    require(actual_stdout["run"] == str(RUN) and actual_stdout["scenario"] == "D"
            and actual_stdout["oracle_exit"] == 1
            and actual_stdout["cleanup_complete"] is True,
            "root actual command result differs")
    return e


def evaluate_original_with_one_corrected_source_check():
    source = read_bound(RUN / "inputs/oracle.py", ORACLE_SHA).decode()
    require(source.count(REMOVED_TUPLE) == 1, "original oracle repair point differs")
    corrected = source.replace(REMOVED_TUPLE, REPLACED_TUPLE, 1)
    require(corrected.replace(REPLACED_TUPLE, REMOVED_TUPLE, 1) == source,
            "oracle transformation changed more than the missing-source tuple")
    namespace = {"__name__": "bounded_original_oracle", "__file__": str(RUN / "inputs/oracle.py")}
    exec(compile(corrected, str(RUN / "inputs/oracle.py"), "exec"), namespace)
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        namespace["evaluate"](RUN)
    return json.loads(out.getvalue())


def main():
    before = run_snapshot()
    (HERE / "original-run-before.sha256.json").write_text(json.dumps(before, indent=2, sort_keys=True) + "\n")
    verdict = {"status": "unverified", "scenario": "D", "run_id": RUN_ID}
    try:
        validate_chain()
        original_checks = evaluate_original_with_one_corrected_source_check()
        require(original_checks["status"] == "limited_pass" and original_checks["scenario"] == "D",
                "unchanged behavioral assertions did not yield limited_pass")
        verdict.update({"status": "limited_pass_reassessment", "original_oracle_exit": 1,
                        "original_oracle_status": "unverified", "behavioral_oracle": original_checks,
                        "repair": "only io_driver.py frozen-input tuple replaced by static/source chain"})
    except Exception as error:
        verdict["error"] = f"{type(error).__name__}: {error}"
    after = run_snapshot()
    (HERE / "original-run-after.sha256.json").write_text(json.dumps(after, indent=2, sort_keys=True) + "\n")
    if before != after:
        verdict = {"status": "unverified", "scenario": "D", "run_id": RUN_ID,
                   "error": "original run changed during reassessment"}
    verdict["original_run_files"] = len(after)
    verdict["original_run_unchanged"] = before == after
    (HERE / "verdict.json").write_text(json.dumps(verdict, indent=2, sort_keys=True) + "\n")
    print(json.dumps(verdict, indent=2, sort_keys=True))
    return 0 if verdict["status"] == "limited_pass_reassessment" else 1


if __name__ == "__main__":
    raise SystemExit(main())
