#!/usr/bin/env python3
"""Independent raw-observation oracle for the reviewed DK-I5 arm64 fixture."""
import hashlib
import json
import pathlib
import re
import sys
import calendar
from datetime import datetime, timezone

HEX32 = re.compile(r"[0-9a-f]{32}\Z")
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
FILE = re.compile(r"[0-9a-f]{32}\.omne-backup\Z")
INSTANT = re.compile(r"(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)(?:\.(\d{1,3}))?Z\Z")
BUILD = "7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616"
CLI_BUILD = "f38e46f1f169aea8993640c8ccf0ffc42545f2d64adf21f96b6658b2c83bb9f1"
IMAGE = "sha256:27c0665146265afefe39012aaea26bdae7499784eaaeb74aea712a6fcdfc03f2"
MANIFEST_SHA = "c97c8584b0346c6c0051ca43d20737e425cb8908366fd6adcfddd6b3eda1b06e"
CLIENT = (
    "mac-configure-alice",
    "linux-configure-bob",
    "mac-health-before",
    "linux-health-before",
    "mac-register-alice",
    "linux-register-bob",
    "mac-login-alice",
    "linux-login-bob",
    "mac-current-personal",
    "linux-current-personal",
    "mac-create-team-a",
    "linux-create-team-b",
    "mac-list-before-backup",
    "linux-list-before-backup",
    "mac-switch-team-a",
    "mac-current-team-a",
    "mac-invite-bob",
    "linux-inbox-bob",
)


def need(value, reason):
    if not value:
        raise AssertionError(reason)


def one_json(data, label):
    need(data.endswith(b"\n") and data.count(b"\n") == 1, label + " not one JSON+LF")
    return json.loads(data[:-1].decode("utf-8", "strict"))


def commands_of(evidence):
    commands = evidence["commands"]
    labels = [item["label"] for item in commands]
    need(len(labels) == len(set(labels)), "duplicate command label")
    return {item["label"]: item for item in commands}


def raw(run, commands, label, stream="stdout", expected_rc=0):
    need(label in commands, "missing command " + label)
    item = commands[label]
    need(
        item["returncode"] is not None and item["observation_expired"] is False,
        label + " result unknown",
    )
    if expected_rc is not None:
        need(item["returncode"] == expected_rc, label + " exit status")
    relative = item[stream]
    need(relative == "raw/" + label + "." + stream, label + " wrong raw path")
    path = run / relative
    need(path.is_file(), label + " missing raw " + stream)
    return path.read_bytes()


def report(run, commands, label):
    body = one_json(raw(run, commands, label), label)
    need(body.get("format") == "governance-client/1", label + " CLI report format")
    need(
        body.get("defect") is None
        and body.get("admission", {}).get("status") == "admitted"
        and body.get("remote", {}).get("status") == "success"
        and body.get("view", {}).get("source") != "copy"
        and commands[label]["returncode"] == 0,
        label + " public operation not confirmed",
    )
    return body


def result(body):
    return body["remote"]["reply"]["reply"]["result"]


def check_clients(run, commands, evidence):
    for label in CLIENT:
        raw(run, commands, label, "stderr")
    reports = {label: report(run, commands, label) for label in CLIENT}
    anchor = evidence["anchors"]
    center = anchor["center_id"]
    need(HEX32.fullmatch(center), "center ID")
    for label in ("mac-health-before", "linux-health-before"):
        need(
            reports[label]["remote"]["health"]
            == {"reachable": True, "centerId": center, "version": "0.0.0"},
            label + " full public health",
        )
    for label, account, team in (
        ("mac-current-personal", "alice", "team_a"),
        ("linux-current-personal", "bob", "team_b"),
    ):
        need(
            reports[label]["origin"]["centerId"] == center
            and result(reports[label])["account"] == anchor[account],
            label + " identity",
        )
        need(
            anchor[team] != result(reports[label])["organization"],
            label + " team/personal distinction",
        )
    need(
        anchor["alice"] != anchor["bob"] and anchor["team_a"] != anchor["team_b"],
        "distinct account/team identities",
    )
    for label, key in (
        ("mac-create-team-a", "team_a"),
        ("linux-create-team-b", "team_b"),
    ):
        need(result(reports[label]) == anchor[key], label + " team creation")
    for label, account, own_team, foreign_team in (
        ("mac-list-before-backup", "alice", "team_a", "team_b"),
        ("linux-list-before-backup", "bob", "team_b", "team_a"),
    ):
        rows = result(reports[label])
        need(
            isinstance(rows, list)
            and any(
                row == {"organization": anchor[own_team], "account": anchor[account]}
                for row in rows
            )
            and all(
                row.get("account") == anchor[account]
                and row.get("organization") != anchor[foreign_team]
                for row in rows
            ),
            label + " pre-backup facts/isolation",
        )
    need(
        result(reports["mac-current-team-a"])
        == {"organization": anchor["team_a"], "account": anchor["alice"]},
        "Alice team selection",
    )
    invitation = result(reports["mac-invite-bob"])
    need(invitation == evidence["invitation"], "invitation write result")
    inbox = result(reports["linux-inbox-bob"])
    need(
        isinstance(inbox, list)
        and any(
            row.get("invitation") == invitation
            and row.get("issuerOrganization") == anchor["team_a"]
            and row.get("invitedAccount") == anchor["bob"]
            and row.get("offerState") == "pending"
            for row in inbox
        ),
        "Bob did not read the newly written invitation",
    )
    return center


def check_image(run, commands, evidence):
    expected = evidence["expected"]
    need(
        expected["image_id"] == IMAGE
        and expected["build_id"] == BUILD
        and expected["cli_build_id"] == CLI_BUILD
        and evidence["inputs"]["sha256"]["manifest"] == MANIFEST_SHA,
        "I3 artifact mismatch",
    )
    outer = json.loads(raw(run, commands, "outer-product-image"))[0]
    original = json.loads(raw(run, commands, "qa-original-inspect"))[0]
    qa = json.loads(raw(run, commands, "qa-image-inspect"))[0]
    need(
        outer["Id"] == IMAGE
        and original["Id"] == expected["original_inner_image_id"]
        and qa["Id"] == expected["qa_inner_image_id"]
        and original["RootFS"]["Layers"] == outer["RootFS"]["Layers"]
        and qa["RootFS"]["Layers"][: len(original["RootFS"]["Layers"])]
        == original["RootFS"]["Layers"]
        and qa["Config"]["Labels"].get("ai.nemori.omne.qa-fixture")
        == "business-backup-write-hold/1",
        "QA/original lineage",
    )
    for image in (outer, original, qa):
        need(
            image["Os"] == "linux"
            and image["Architecture"] == "arm64"
            and image["Config"]["Labels"]["ai.nemori.omne.host-build-id"] == BUILD
            and image["Config"]["User"] == "10001:10001"
            and image["Config"]["Entrypoint"] == ["node", "/opt/omne/app/dist/cli.js"]
            and image["Config"]["Cmd"] == ["serve"],
            "image identity or entrypoint",
        )
    for label in ("original", "qa"):
        inventory = one_json(raw(run, commands, "exec-inventory-" + label), label)
        need(
            inventory.get("status") == "verified"
            and inventory.get("buildId") == BUILD
            and inventory.get("manifestSha256")
            == evidence["inputs"]["sha256"]["host_file_manifest"]
            and inventory.get("node") == "v24.21.0",
            label + " full app inventory",
        )
    center = json.loads(raw(run, commands, "center-inspect-before"))[0]
    need(
        center["Id"] == expected["first_center_container"]
        and center["Image"] == qa["Id"]
        and center["State"]["Running"] is True
        and center["State"]["Health"]["Status"] == "healthy"
        and center["Config"]["User"] == "10001:10001",
        "actual QA serve center",
    )
    need(
        raw(run, commands, "center-exe-before") == b"/usr/local/bin/node\n"
        and raw(run, commands, "center-cmdline-before")
        == b"node\x00/opt/omne/app/dist/cli.js\x00serve\x00",
        "actual PID1",
    )
    for label in ("mac-cli-version", "linux-cli-version"):
        need(CLI_BUILD.encode() in raw(run, commands, label), label + " CLI build")
    need(
        raw(run, commands, "linux-node-version") == b"v24.21.0\n"
        and raw(run, commands, "mac-node-version") == b"v24.21.0\n",
        "Node version",
    )


def instant_ms(value, *, online):
    need(isinstance(value, str), "instant text")
    match = INSTANT.fullmatch(value)
    need(match is not None, "instant shape")
    fraction = match[2] or ""
    if online:
        need(
            (not fraction or (not fraction.endswith("0") and int(fraction) != 0)),
            "online instant must use HT3 minimal fraction",
        )
    date = datetime.strptime(match[1], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc)
    return calendar.timegm(date.utctimetuple()) * 1000 + int(
        fraction.ljust(3, "0") or "0"
    )


def observation_us(value):
    need(isinstance(value, str), "observation time text")
    observed = datetime.fromisoformat(
        value[:-1] + "+00:00" if value.endswith("Z") else value
    )
    need(observed.tzinfo is not None, "observation time has no timezone")
    utc = observed.astimezone(timezone.utc)
    return calendar.timegm(utc.utctimetuple()) * 1_000_000 + utc.microsecond


def metadata(value, center, *, online=False):
    need(
        set(value)
        == {
            "format",
            "centerId",
            "sourceBuildId",
            "migrationNames",
            "startedAt",
            "finishedAt",
            "byteLength",
            "sha256",
        },
        "metadata shape",
    )
    need(
        value["format"] == "omne-center-backup/1"
        and value["centerId"] == center
        and value["sourceBuildId"] == BUILD
        and HEX64.fullmatch(value["sha256"])
        and type(value["byteLength"]) is int
        and 0 < value["byteLength"] <= 1073741824
        and isinstance(value["migrationNames"], list)
        and value["migrationNames"]
        and len(set(value["migrationNames"])) == len(value["migrationNames"])
        and instant_ms(value["startedAt"], online=online)
        <= instant_ms(value["finishedAt"], online=online),
        "metadata identity/integrity",
    )


def same_metadata_timepoint(online, offline):
    need(set(online) == set(offline), "metadata members changed")
    need(
        all(
            online[key] == offline[key]
            for key in online
            if key not in ("startedAt", "finishedAt")
        )
        and all(
            instant_ms(online[key], online=True)
            == instant_ms(offline[key], online=False)
            for key in ("startedAt", "finishedAt")
        ),
        "metadata fields or precise timepoints changed",
    )


def check_overlap(run, commands, evidence, center):
    async_job = evidence["async_backup"]
    ready = one_json(raw(run, commands, "gate-ready"), "gate-ready")
    need(
        ready == {"stage": "ready", "mode": "write-hold", "pid": 1},
        "QA gate not installed in live serve PID1",
    )
    held = one_json(raw(run, commands, "gate-held"), "gate-held")
    need(
        held == async_job["held"]
        and held["stage"] == "write"
        and held["pid"] == 1
        and re.fullmatch(
            r"/state/backups/\.quarantine/export-[0-9a-f]{32}", held["path"]
        ),
        "real export write gate",
    )
    link = raw(run, commands, "gate-fd-link").decode().strip()
    stat = raw(run, commands, "gate-fd-stat").decode().strip().split(":")
    need(
        link == held["path"]
        and len(stat) == 5
        and (int(stat[0]), int(stat[1])) == (held["dev"], held["ino"])
        and stat[2:4] == ["10001", "10001"]
        and stat[4] == "600",
        "held actual private FD differs",
    )
    invite = commands["mac-invite-bob"]
    inbox = commands["linux-inbox-bob"]
    need(
        observation_us(async_job["started_utc"])
        < observation_us(async_job["held_observed_utc"])
        <= observation_us(invite["started_utc"])
        < observation_us(invite["finished_observation_utc"])
        <= observation_us(inbox["started_utc"])
        < observation_us(inbox["finished_observation_utc"])
        <= observation_us(async_job["business_read_completed_utc"])
        < observation_us(async_job["released_utc"])
        < observation_us(async_job["finished_utc"])
        and commands["gate-release"]["returncode"] == 0
        and async_job["returncode"] == 0,
        "business and backup did not overlap",
    )
    backup = one_json((run / async_job["stdout"]).read_bytes(), "async backup")
    need(
        backup == evidence["backup"]
        and set(backup) == {"status", "backup"}
        and backup["status"] == "completed"
        and FILE.fullmatch(backup["backup"]["fileName"]),
        "backup actual completion",
    )
    metadata(backup["backup"]["metadata"], center, online=True)
    status = one_json(raw(run, commands, "concurrent-backup-status"), "backup-status")
    need(
        status == evidence["backup_status"]
        and set(status) == {"status", "health", "latest", "invalidCount"}
        and status["status"] == "observed"
        and status["health"] == "current"
        and status["latest"] == backup["backup"]
        and status["invalidCount"] == 0,
        "backup-status did not independently confirm published output",
    )
    health = one_json(raw(run, commands, "full-health-after-backup"), "full-health")
    need(
        health["centerId"] == center
        and health["defectCount"] == 0
        and all(
            health[key] is True
            for key in (
                "reachable",
                "storageReachable",
                "deploymentKeyPresent",
                "deploymentKeyComplete",
                "clockSane",
            )
        ),
        "center not healthy after backup",
    )
    return backup["backup"]


def sha_line(data, expected_path):
    parts = data.decode().strip().split("  ")
    need(
        len(parts) == 2 and parts[1] == expected_path and HEX64.fullmatch(parts[0]),
        "envelope sha256sum",
    )
    return parts[0]


def inspect_offline(run, commands, action, evidence):
    label = "maintenance-" + action + "-inspect"
    found = json.loads(raw(run, commands, label))[0]
    expected = evidence["expected"]
    need(
        found["Id"] == evidence["maintenance_ids"][action]
        and found["Image"] == expected["original_inner_image_id"]
        and found["Config"]["User"] == "10001:10001"
        and found["Config"]["Labels"].get("ai.nemori.omne.action") == action
        and found["State"]["Status"] == "exited"
        and found["State"]["ExitCode"] == 0
        and found["HostConfig"]["NetworkMode"] == "none"
        and found["HostConfig"]["RestartPolicy"]["Name"] == "no"
        and len(found["Mounts"]) == 1
        and found["Mounts"][0]["Destination"] == "/state"
        and found["Mounts"][0]["Source"] == expected["state"]
        and not found["HostConfig"].get("PortBindings")
        and all("/secrets" not in str(m) for m in found["Mounts"])
        and all(
            not key.startswith("OMNE_TENANCY_")
            for key in (
                item.split("=", 1)[0] for item in found["Config"].get("Env", [])
            )
        ),
        action + " offline isolation/image",
    )


def check_offline(run, commands, evidence, descriptor, center):
    offline = evidence["offline"]
    source, target, work = (offline[key] for key in ("source", "target", "work"))
    need(
        source == evidence["expected"]["state"] + "/backups/" + descriptor["fileName"]
        and target
        == evidence["expected"]["state"]
        + "/restores/"
        + evidence["expected"]["project"]
        and work
        == evidence["expected"]["state"]
        + "/offline-work/"
        + evidence["expected"]["project"],
        "offline paths altered",
    )
    verify = one_json(raw(run, commands, "offline-verify"), "verify")
    restore = one_json(raw(run, commands, "offline-restore"), "restore")
    need(
        set(verify) == {"status", "metadata", "businessOpen"}
        and verify["status"] == "verified"
        and verify["businessOpen"] is False
        and set(restore) == {"status", "metadata", "targetLocation", "businessOpen"}
        and restore["status"] == "restored-isolated"
        and restore["businessOpen"] is False
        and restore["targetLocation"]
        == "/state/restores/" + evidence["expected"]["project"],
        "offline verify/restore contract",
    )
    same_metadata_timepoint(descriptor["metadata"], verify["metadata"])
    same_metadata_timepoint(descriptor["metadata"], restore["metadata"])
    need(
        verify["metadata"] == restore["metadata"],
        "offline metadata changed between calls",
    )
    metadata(verify["metadata"], center)
    for action in ("verify", "restore-isolated"):
        inspect_offline(run, commands, action, evidence)
    source_hash = sha_line(raw(run, commands, "source-envelope-sha"), source)
    target_file = target + "/data.omne-backup"
    target_hash = sha_line(raw(run, commands, "restore-envelope-sha"), target_file)
    source_stat = raw(run, commands, "source-envelope-stat").decode().strip().split(":")
    target_stat = (
        raw(run, commands, "restore-envelope-stat").decode().strip().split(":")
    )
    need(
        source_hash == target_hash
        and len(source_stat) == len(target_stat) == 5
        and source_stat[:4]
        == target_stat[:4]
        == ["regular file", "10001", "10001", "600"]
        and source_stat[4] == target_stat[4]
        and int(source_stat[4]) > 0,
        "restored envelope bytes/ownership",
    )
    need(
        raw(run, commands, "restore-target-stat").decode().strip()
        == "directory:10001:10001:700",
        "restored target is not a private directory",
    )
    marker = raw(run, commands, "work-marker-stat").decode().strip().split(":")
    need(
        len(marker) == 6
        and int(marker[0]) > 0
        and int(marker[1]) > 0
        and marker[2:] == ["10001", "10001", "600", "16"]
        and raw(run, commands, "work-marker-bytes") == b"omne-isolated/1\n",
        "tool-produced permanent marker identity/content",
    )
    return source_hash


def product_failure(logs, fragment):
    for line in logs.splitlines():
        try:
            event = json.loads(line)
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
        if event.get("event") == "startup-failed" and fragment in event.get(
            "message", ""
        ):
            return event
    return None


def check_serve_rejections(run, commands, evidence):
    helper = commands["restore-target-helper-start"]
    raw(run, commands, "restore-target-helper-start", expected_rc=1)
    need(
        helper["returncode"] == 1
        and helper["observation_expired"] is False
        and b"invalid-state-path"
        in raw(run, commands, "restore-target-helper-start", "stderr", expected_rc=None)
        and raw(run, commands, "restore-target-project-list") == b"",
        "restore target helper layout refusal/no service",
    )
    for label, phrase in (
        ("envelope", "file is not a database"),
        ("marker", "isolated maintenance data cannot be opened as production storage"),
    ):
        item = commands[label + "-serve"]
        raw(run, commands, label + "-serve", expected_rc=1)
        raw(run, commands, label + "-serve", "stderr", expected_rc=1)
        inspect = json.loads(raw(run, commands, label + "-inspect"))[0]
        probe = evidence["serve_probes"][label]
        project = evidence["expected"]["project"]
        expected_storage = (
            "/state/restores/" + project + "/data.omne-backup"
            if label == "envelope"
            else "/state/offline-work/" + project + "/probe.sqlite"
        )
        state_source = evidence["expected"]["state"]
        secrets_source = str(pathlib.PurePosixPath(state_source).parent / "secrets")
        mounts = {mount["Destination"]: mount for mount in inspect["Mounts"]}
        env_lines = inspect["Config"].get("Env", [])
        env = dict(line.split("=", 1) for line in env_lines)
        expected_pem = {
            "OMNE_TENANCY_ACTIVATION_SIGNING_KEY_PEM_FILE": "/secrets/activation-signing-key.pem",
            "OMNE_TENANCY_ACTIVATION_VERIFICATION_KEY_PEM_FILE": "/secrets/activation-verification-key.pem",
            "OMNE_TENANCY_PURGE_SIGNING_KEY_PEM_FILE": "/secrets/purge-signing-key.pem",
            "OMNE_TENANCY_PURGE_VERIFICATION_KEY_PEM_FILE": "/secrets/purge-verification-key.pem",
            "OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE": "/secrets/tls-chain.pem",
            "OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE": "/secrets/tls-private.pem",
        }
        need(
            item["returncode"] == 1
            and item["observation_expired"] is False
            and inspect["Name"] == "/" + probe["container_name"]
            and inspect["Image"] == evidence["expected"]["original_inner_image_id"]
            and probe["storage_file"] == expected_storage
            and inspect["State"]["Status"] == "exited"
            and inspect["State"]["ExitCode"] == 1
            and inspect["HostConfig"]["NetworkMode"] == "none"
            and inspect["HostConfig"]["RestartPolicy"]["Name"] == "no"
            and not inspect["HostConfig"].get("PortBindings")
            and len(inspect["Mounts"]) == 2
            and set(mounts) == {"/state", "/secrets"}
            and mounts["/state"]["Type"] == "bind"
            and mounts["/state"]["Source"] == state_source
            and mounts["/state"]["RW"] is True
            and mounts["/secrets"]["Type"] == "bind"
            and mounts["/secrets"]["Source"] == secrets_source
            and mounts["/secrets"]["RW"] is False
            and inspect["Config"]["User"] == "10001:10001"
            and inspect["Config"]["Entrypoint"] == ["node", "/opt/omne/app/dist/cli.js"]
            and inspect["Config"]["Cmd"] == ["serve"]
            and inspect["Path"] == "node"
            and inspect["Args"] == ["/opt/omne/app/dist/cli.js", "serve"]
            and len(env) == len(env_lines)
            and env.get("OMNE_TENANCY_STORAGE_DIALECT") == "sqlite"
            and env.get("OMNE_TENANCY_STORAGE_FILE") == expected_storage
            and env.get("OMNE_TENANCY_BACKUP_DIR") == "/state/backups"
            and env.get("OMNE_TENANCY_OPS_SOCKET_DIR") == "/run/omne-tenancy"
            and env.get("OMNE_TENANCY_ENTRY_LISTEN") == "0.0.0.0:8443"
            and all(env.get(key) == value for key, value in expected_pem.items())
            and not any(key.endswith("_PEM") for key in env)
            and "NODE_OPTIONS" not in env
            and set(inspect["HostConfig"].get("Tmpfs") or {}) == {"/run/omne-tenancy"},
            label + " original serve path",
        )
        logs = raw(run, commands, label + "-logs") + raw(
            run, commands, label + "-logs", "stderr"
        )
        failure = product_failure(logs, phrase)
        need(
            failure is not None
            and failure.get("stage") == "storage-open"
            and b'"event":"serving"' not in logs,
            label + " did not reject precise source",
        )
    offline = evidence["offline"]
    need(
        sha_line(
            raw(run, commands, "source-envelope-sha-after-probes"), offline["source"]
        )
        == sha_line(raw(run, commands, "source-envelope-sha"), offline["source"])
        and sha_line(
            raw(run, commands, "restore-envelope-sha-after-probes"),
            offline["target"] + "/data.omne-backup",
        )
        == sha_line(
            raw(run, commands, "restore-envelope-sha"),
            offline["target"] + "/data.omne-backup",
        )
        and raw(run, commands, "work-marker-stat-after-probes")
        == raw(run, commands, "work-marker-stat")
        and raw(run, commands, "work-marker-bytes-after-probes")
        == raw(run, commands, "work-marker-bytes"),
        "probes altered envelope/marker",
    )


def check_cleanup(run, evidence):
    need(
        evidence.get("cleanup_complete") is True
        and not evidence.get("cleanup_errors")
        and evidence.get("other_project_cleanup_complete") is True
        and evidence.get("target_project_cleanup_complete") is True,
        "fixture cleanup incomplete",
    )
    cleanup = {item["label"]: item for item in evidence["cleanup_commands"]}
    for label in (
        "cleanup-target-project-final-list",
        "cleanup-inner-project-final-list",
        "cleanup-inner-fixture-final-list",
        "cleanup-inner-all-final-list",
        "cleanup-final-list-container",
        "cleanup-final-list-network",
        "cleanup-final-list-volume",
    ):
        need(
            label in cleanup
            and cleanup[label]["returncode"] == 0
            and (run / cleanup[label]["stdout"]).read_bytes() == b"",
            label + " resources remain",
        )


def check_secrets(run):
    paths = (
        run / "private/mac-register-alice.secret",
        run / "private/bob-credential.secret",
    )
    secrets = [path.read_bytes() for path in paths]
    need(
        all(len(value) >= 16 for value in secrets),
        "ephemeral fixture credential absent",
    )
    for path in (run / "evidence.json", *(run / "raw").iterdir()):
        if path.is_file():
            data = path.read_bytes()
            need(
                all(secret not in data for secret in secrets),
                "fixture secret leaked in " + path.name,
            )


def check(run):
    evidence = json.loads((run / "evidence.json").read_text())
    need(
        evidence["status"] == "observed-awaiting-oracle"
        and evidence["business_complete"] is True
        and evidence["inputs"]["platform"] == "arm64"
        and evidence["host"]["system"] == "Darwin",
        "run incomplete/wrong OS",
    )
    commands = commands_of(evidence)
    for label in CLIENT:
        raw(run, commands, label)
        raw(run, commands, label, "stderr")
    check_image(run, commands, evidence)
    center = check_clients(run, commands, evidence)
    descriptor = check_overlap(run, commands, evidence, center)
    envelope_sha = check_offline(run, commands, evidence, descriptor, center)
    check_serve_rejections(run, commands, evidence)
    stopped = one_json(raw(run, commands, "stop"), "stop")
    before = json.loads(raw(run, commands, "stopped-center-inspect"))[0]
    need(
        stopped
        == {
            "state": "stopped",
            "containerId": before["Id"],
            "exitCode": 0,
            "clean": True,
        }
        and before["State"]["Status"] == "exited"
        and before["State"]["Running"] is False
        and before["State"]["ExitCode"] == 0,
        "center did not cleanly stop",
    )
    check_cleanup(run, evidence)
    check_secrets(run)
    return {
        "status": "PASS",
        "scope": "DK-I5 arm64 QA-gated online overlap and original-image offline/rejection",
        "centerId": center,
        "sourceEnvelopeSha256": envelope_sha,
        "commandCount": len(commands),
    }


def main():
    need(len(sys.argv) == 2, "usage: oracle.py RUN_DIRECTORY")
    print(json.dumps(check(pathlib.Path(sys.argv[1]).resolve()), sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"ORACLE FAIL: {type(error).__name__}: {error}", file=sys.stderr)
        raise SystemExit(1)
