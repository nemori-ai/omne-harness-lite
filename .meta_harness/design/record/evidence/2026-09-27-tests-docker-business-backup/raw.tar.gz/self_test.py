#!/usr/bin/env python3
"""Offline counterexamples for the DK-I5 oracle; no Docker or business operations."""
import copy
import json
import pathlib
import tempfile

import oracle


def rejected(call):
    try:
        call()
    except (AssertionError, KeyError, TypeError, ValueError):
        return True
    return False


def write(
    run,
    label,
    stdout=b"",
    stderr=b"",
    rc=0,
    start="2026-09-27T00:00:02+00:00",
    finish="2026-09-27T00:00:03+00:00",
):
    for stream, data in (("stdout", stdout), ("stderr", stderr)):
        (run / "raw" / f"{label}.{stream}").write_bytes(data)
    return {
        "label": label,
        "stdout": f"raw/{label}.stdout",
        "stderr": f"raw/{label}.stderr",
        "returncode": rc,
        "observation_expired": False,
        "started_utc": start,
        "finished_observation_utc": finish,
    }


def example():
    temp = tempfile.TemporaryDirectory()
    run = pathlib.Path(temp.name)
    (run / "raw").mkdir()
    path = "/state/backups/.quarantine/export-" + "a" * 32
    held = {"stage": "write", "path": path, "fd": 17, "pid": 1, "dev": 12, "ino": 34}
    meta = {
        "format": "omne-center-backup/1",
        "centerId": "b" * 32,
        "sourceBuildId": oracle.BUILD,
        "migrationNames": ["initial"],
        "startedAt": "2026-09-27T00:00:00Z",
        "finishedAt": "2026-09-27T00:00:08Z",
        "byteLength": 100,
        "sha256": "c" * 64,
    }
    descriptor = {"fileName": "d" * 32 + ".omne-backup", "metadata": meta}
    backup = {"status": "completed", "backup": descriptor}
    status = {
        "status": "observed",
        "health": "current",
        "latest": descriptor,
        "invalidCount": 0,
    }
    (run / "raw/concurrent-backup.stdout").write_bytes(
        json.dumps(backup).encode() + b"\n"
    )
    commands = {
        "gate-ready": write(
            run, "gate-ready", b'{"stage":"ready","mode":"write-hold","pid":1}\n'
        ),
        "gate-held": write(run, "gate-held", json.dumps(held).encode() + b"\n"),
        "gate-fd-link": write(run, "gate-fd-link", path.encode() + b"\n"),
        "gate-fd-stat": write(run, "gate-fd-stat", b"12:34:10001:10001:600\n"),
        "mac-invite-bob": write(
            run,
            "mac-invite-bob",
            start="2026-09-27T00:00:03+00:00",
            finish="2026-09-27T00:00:04+00:00",
        ),
        "linux-inbox-bob": write(
            run,
            "linux-inbox-bob",
            start="2026-09-27T00:00:05+00:00",
            finish="2026-09-27T00:00:06+00:00",
        ),
        "gate-release": write(run, "gate-release"),
        "concurrent-backup-status": write(
            run, "concurrent-backup-status", json.dumps(status).encode() + b"\n"
        ),
        "full-health-after-backup": write(
            run,
            "full-health-after-backup",
            json.dumps(
                {
                    "centerId": meta["centerId"],
                    "defectCount": 0,
                    "reachable": True,
                    "storageReachable": True,
                    "deploymentKeyPresent": True,
                    "deploymentKeyComplete": True,
                    "clockSane": True,
                }
            ).encode()
            + b"\n",
        ),
    }
    evidence = {
        "async_backup": {
            "held": held,
            "started_utc": "2026-09-27T00:00:00+00:00",
            "held_observed_utc": "2026-09-27T00:00:01+00:00",
            "business_read_completed_utc": "2026-09-27T00:00:06+00:00",
            "released_utc": "2026-09-27T00:00:07+00:00",
            "finished_utc": "2026-09-27T00:00:08+00:00",
            "returncode": 0,
            "stdout": "raw/concurrent-backup.stdout",
        },
        "backup": backup,
        "backup_status": status,
    }
    return temp, run, commands, evidence


def serve_example(run):
    state = "/var/lib/omne-tenancy/state"
    project = "r5sample"
    original = "sha256:" + "a" * 64
    source = state + "/backups/" + "d" * 32 + ".omne-backup"
    target = state + "/restores/" + project
    evidence = {
        "expected": {
            "project": project,
            "state": state,
            "original_inner_image_id": original,
        },
        "offline": {"source": source, "target": target},
        "serve_probes": {},
    }
    commands = {
        "restore-target-helper-start": write(
            run, "restore-target-helper-start", stderr=b"invalid-state-path\n", rc=1
        ),
        "restore-target-project-list": write(run, "restore-target-project-list"),
    }
    pem = {
        "OMNE_TENANCY_ACTIVATION_SIGNING_KEY_PEM_FILE": "/secrets/activation-signing-key.pem",
        "OMNE_TENANCY_ACTIVATION_VERIFICATION_KEY_PEM_FILE": "/secrets/activation-verification-key.pem",
        "OMNE_TENANCY_PURGE_SIGNING_KEY_PEM_FILE": "/secrets/purge-signing-key.pem",
        "OMNE_TENANCY_PURGE_VERIFICATION_KEY_PEM_FILE": "/secrets/purge-verification-key.pem",
        "OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE": "/secrets/tls-chain.pem",
        "OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE": "/secrets/tls-private.pem",
    }
    for label, storage, phrase in (
        (
            "envelope",
            "/state/restores/" + project + "/data.omne-backup",
            "file is not a database",
        ),
        (
            "marker",
            "/state/offline-work/" + project + "/probe.sqlite",
            "isolated maintenance data cannot be opened as production storage",
        ),
    ):
        name = "omne-" + project + "-" + label
        evidence["serve_probes"][label] = {
            "container_name": name,
            "storage_file": storage,
        }
        env = {
            "OMNE_TENANCY_STORAGE_DIALECT": "sqlite",
            "OMNE_TENANCY_STORAGE_FILE": storage,
            "OMNE_TENANCY_BACKUP_DIR": "/state/backups",
            "OMNE_TENANCY_OPS_SOCKET_DIR": "/run/omne-tenancy",
            "OMNE_TENANCY_ENTRY_LISTEN": "0.0.0.0:8443",
            **pem,
        }
        inspect = {
            "Name": "/" + name,
            "Image": original,
            "State": {"Status": "exited", "ExitCode": 1},
            "HostConfig": {
                "NetworkMode": "none",
                "RestartPolicy": {"Name": "no"},
                "PortBindings": {},
                "Tmpfs": {"/run/omne-tenancy": "mode=0700"},
            },
            "Mounts": [
                {"Destination": "/state", "Type": "bind", "Source": state, "RW": True},
                {
                    "Destination": "/secrets",
                    "Type": "bind",
                    "Source": "/var/lib/omne-tenancy/secrets",
                    "RW": False,
                },
            ],
            "Config": {
                "User": "10001:10001",
                "Entrypoint": ["node", "/opt/omne/app/dist/cli.js"],
                "Cmd": ["serve"],
                "Env": [key + "=" + value for key, value in env.items()],
            },
            "Path": "node",
            "Args": ["/opt/omne/app/dist/cli.js", "serve"],
        }
        commands[label + "-serve"] = write(run, label + "-serve", rc=1)
        commands[label + "-inspect"] = write(
            run, label + "-inspect", json.dumps([inspect]).encode() + b"\n"
        )
        commands[label + "-logs"] = write(
            run,
            label + "-logs",
            stderr=json.dumps(
                {"event": "startup-failed", "stage": "storage-open", "message": phrase}
            ).encode()
            + b"\n",
        )
    target_file = target + "/data.omne-backup"
    for label, path in (
        ("source-envelope-sha", source),
        ("source-envelope-sha-after-probes", source),
        ("restore-envelope-sha", target_file),
        ("restore-envelope-sha-after-probes", target_file),
    ):
        commands[label] = write(run, label, ("f" * 64 + "  " + path + "\n").encode())
    for label in ("work-marker-stat", "work-marker-stat-after-probes"):
        commands[label] = write(run, label, b"12:34:10001:10001:600:16\n")
    for label in ("work-marker-bytes", "work-marker-bytes-after-probes"):
        commands[label] = write(run, label, b"omne-isolated/1\n")
    return commands, evidence


def main():
    checks = {}
    temp, run, commands, evidence = example()
    try:
        oracle.check_overlap(run, commands, evidence, "b" * 32)
        checks["valid_synthetic_overlap"] = True
        variants = {
            "business_after_release": lambda c, e: c["linux-inbox-bob"].update(
                finished_observation_utc="2026-09-27T00:00:09+00:00"
            ),
            "missing_write_output": lambda c, e: c.pop("mac-invite-bob"),
            "wrong_fd_inode": lambda c, e: (
                run / "raw/gate-fd-stat.stdout"
            ).write_bytes(b"12:35:10001:10001:600\n"),
            "status_old_descriptor": lambda c, e: e["backup_status"]["latest"].update(
                fileName="e" * 32 + ".omne-backup"
            ),
            "wrong_center": lambda c, e: e["backup"]["backup"]["metadata"].update(
                centerId="f" * 32
            ),
            "backup_fake_exit": lambda c, e: e["async_backup"].update(returncode=1),
        }
        for name, mutate in variants.items():
            original_commands = copy.deepcopy(commands)
            original_evidence = copy.deepcopy(evidence)
            fd_bytes = (run / "raw/gate-fd-stat.stdout").read_bytes()
            mutate(original_commands, original_evidence)
            checks[name] = rejected(
                lambda c=original_commands, e=original_evidence: oracle.check_overlap(
                    run, c, e, "b" * 32
                )
            )
            (run / "raw/gate-fd-stat.stdout").write_bytes(fd_bytes)
        event = {
            "event": "startup-failed",
            "stage": "storage-open",
            "message": "file is not a database",
        }
        logs = json.dumps(event).encode() + b"\n"
        checks["specific_serve_rejection"] = (
            oracle.product_failure(logs, "file is not a database") == event
        )
        checks["unrelated_config_rejected"] = (
            oracle.product_failure(logs, "isolated maintenance data") is None
        )
        checks["missing_json_lf_rejected"] = rejected(
            lambda: oracle.one_json(b'{"status":"completed"}', "x")
        )
        checks["wrong_metadata_center_rejected"] = rejected(
            lambda: oracle.metadata(evidence["backup"]["backup"]["metadata"], "f" * 32)
        )
        online = copy.deepcopy(evidence["backup"]["backup"]["metadata"])
        online["finishedAt"] = "2026-09-27T00:00:08.4Z"
        offline = copy.deepcopy(online)
        offline["finishedAt"] = "2026-09-27T00:00:08.400Z"
        oracle.metadata(online, "b" * 32, online=True)
        oracle.same_metadata_timepoint(online, offline)
        checks["same_instant_different_precision"] = True
        changed = copy.deepcopy(offline)
        changed["finishedAt"] = "2026-09-27T00:00:08.401Z"
        checks["changed_millisecond_rejected"] = rejected(
            lambda: oracle.same_metadata_timepoint(online, changed)
        )
        changed = copy.deepcopy(offline)
        changed["centerId"] = "f" * 32
        checks["non_time_field_changed_rejected"] = rejected(
            lambda: oracle.same_metadata_timepoint(online, changed)
        )
        checks["nonminimal_online_rejected"] = rejected(
            lambda: oracle.metadata(offline, "b" * 32, online=True)
        )
        checks["submillisecond_rejected"] = rejected(
            lambda: oracle.instant_ms("2026-09-27T00:00:08.4001Z", online=False)
        )
        checks["offset_observation_equal"] = oracle.observation_us(
            "2026-09-27T08:00:00+08:00"
        ) == oracle.observation_us("2026-09-27T00:00:00Z")
        serve_commands, serve_evidence = serve_example(run)
        oracle.check_serve_rejections(run, serve_commands, serve_evidence)
        checks["valid_serve_rejections"] = True
        inspect_path = run / "raw/envelope-inspect.stdout"
        original_inspect = inspect_path.read_bytes()
        for name, mutate in (
            (
                "hidden_state_ancestor_rejected",
                lambda i: i[0]["Mounts"][0].update(Source="/state/restores"),
            ),
            (
                "wrong_storage_file_rejected",
                lambda i: i[0]["Config"]["Env"].__setitem__(
                    1, "OMNE_TENANCY_STORAGE_FILE=/state/data/center.sqlite"
                ),
            ),
            (
                "new_serve_entry_rejected",
                lambda i: i[0]["Config"].update(Entrypoint=["sh", "-c"]),
            ),
        ):
            inspected = json.loads(original_inspect)
            mutate(inspected)
            inspect_path.write_bytes(json.dumps(inspected).encode() + b"\n")
            checks[name] = rejected(
                lambda: oracle.check_serve_rejections(
                    run, serve_commands, serve_evidence
                )
            )
        inspect_path.write_bytes(original_inspect)
    finally:
        temp.cleanup()
    if not all(checks.values()):
        raise AssertionError(
            "offline negative failed: " + json.dumps(checks, sort_keys=True)
        )
    print(json.dumps({"status": "PASS", "checks": checks}, sort_keys=True))


if __name__ == "__main__":
    main()
