// Run inside original and QA images with NODE_OPTIONS cleared. No product writes.
import { createHash } from 'node:crypto'
import { lstat, readFile, readlink, readdir } from 'node:fs/promises'
import { dirname, join, relative, resolve, sep } from 'node:path'

const root = '/opt/omne/app'
const expectedBuildId = '7547343852a07540fc171c8914711aa81d16815e9b2d0df6facc955154fd5616'
const expectedManifestSha = 'c48e4ed8263b22542f9c93bac8beed8a2c39d1127455de68811cc07a52a27412'
const hash = bytes => createHash('sha256').update(bytes).digest('hex')

const manifestBytes = await readFile(join(root, 'build-info.json'))
if (hash(manifestBytes) !== expectedManifestSha) throw new Error('app build-info bytes changed')
const manifest = JSON.parse(manifestBytes.toString('utf8'))
if (manifest.format !== 'omne-tenancy-host-build/1' || manifest.buildId !== expectedBuildId)
  throw new Error('app build-info identity changed')
if ((await readFile(join(root, 'BUILD_ID'), 'utf8')).trim() !== expectedBuildId)
  throw new Error('app BUILD_ID changed')

const listed = new Set()
let files = 0
let links = 0
for (const item of manifest.files) {
  if (listed.has(item.path)) throw new Error(`duplicate manifest path: ${item.path}`)
  listed.add(item.path)
  const path = join(root, item.path)
  const info = await lstat(path)
  if (item.kind === 'file' && info.isFile()) {
    if (hash(await readFile(path)) !== item.sha256) throw new Error(`file hash changed: ${item.path}`)
    files++
  } else if (item.kind === 'link' && info.isSymbolicLink()) {
    const target = await readlink(path)
    if (target !== item.target) throw new Error(`symlink changed: ${item.path}`)
    const resolved = resolve(dirname(path), target)
    const inside = relative(root, resolved)
    if (inside === '..' || inside.startsWith(`..${sep}`) || inside.startsWith(sep))
      throw new Error(`symlink escapes app: ${item.path}`)
    links++
  } else {
    throw new Error(`kind changed: ${item.path}`)
  }
}

const actual = new Set()
async function walk(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const absolute = join(directory, entry.name)
    if (entry.isDirectory()) await walk(absolute)
    else if (entry.isFile() || entry.isSymbolicLink()) {
      const path = relative(root, absolute)
      if (path !== 'BUILD_ID' && path !== 'build-info.json') actual.add(path)
    } else throw new Error(`special object in app: ${absolute}`)
  }
}
await walk(root)
if (actual.size !== listed.size || [...actual].some(path => !listed.has(path)))
  throw new Error('app inventory path set changed')

process.stdout.write(JSON.stringify({ status: 'verified', buildId: expectedBuildId, files, links,
  manifestSha256: expectedManifestSha, node: process.version }) + '\n')
