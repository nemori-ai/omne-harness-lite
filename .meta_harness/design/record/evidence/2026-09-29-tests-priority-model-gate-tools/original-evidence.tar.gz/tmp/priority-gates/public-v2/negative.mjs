import assert from 'node:assert/strict'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { openLedger } from '../../../tools/model-probe/src/budget.mjs'
import {
  certificate,
  finish,
  fixture,
  sse,
} from '../../../packages/model/pi-ai-transport/tests/support.ts'
import {
  createTransport,
  definition,
  hash,
  planFor,
  publicCase,
  readFrozen,
  tool,
  validateScenario,
  verifySources,
} from './core.mjs'

if (
  process.argv.length !== 10 ||
  process.argv[2] !== '--scenario' ||
  process.argv[4] !== '--scenario-sha256' ||
  process.argv[6] !== '--case' ||
  process.argv[8] !== '--output-dir'
)
  throw new Error(
    'usage: negative.mjs --scenario PATH --scenario-sha256 SHA --case unknown_cost|wrong_tool_arguments --output-dir DIR',
  )
const scenario = validateScenario(await readFrozen(process.argv[3], process.argv[5]))
assert.equal(scenario.gate, 'tool_schema')
await verifySources(scenario)
const mode = process.argv[7]
assert.ok(['unknown_cost', 'wrong_tool_arguments'].includes(mode))
const outputDir = process.argv[9]
await mkdir(outputDir, { mode: 0o700, recursive: true })
const prices = {
  prompt: '0.000001',
  completion: '0.000001',
  input_cache_write_1h: '0.000001',
  request: '0',
}
const planner = createTransport(scenario)
let planned
try {
  ;({ planned } = await planFor(scenario, planner))
  assert.equal(hash(planned.serialized), scenario.publicWireSha256)
} finally {
  await planner.close()
}
const cert = certificate()
const ledgerPath = join(outputDir, 'fixture-ledger.json')
let host
try {
  host = await fixture(
    cert.tls,
    async response => {
      const state = JSON.parse(await readFile(ledgerPath, 'utf8'))
      assert.equal(state.entries[0]?.state, 'reserved')
      response.setHeader('x-request-id', 'local-safe-id')
      response.end(
        sse({
          choices: [
            {
              delta: {
                tool_calls: [
                  {
                    index: 0,
                    id: 'call_exact',
                    function: {
                      name: tool.name,
                      arguments:
                        mode === 'wrong_tool_arguments' ? '{"query":"WRONG"}' : '{"query":"CEDAR"}',
                    },
                  },
                ],
              },
            },
          ],
        }) +
          (mode === 'wrong_tool_arguments'
            ? sse({
                id: 'local-generation',
                model: scenario.modelId,
                provider: scenario.provider === 'openai' ? 'OpenAI' : 'Anthropic',
                choices: [],
                usage: { prompt_tokens: 20, completion_tokens: 2, cost: 0.0000117 },
              })
            : '') +
          finish('tool_calls'),
      )
    },
    {},
    undefined,
    [definition(scenario.modelId).value],
  )
  const ledger = await openLedger(ledgerPath, { limitUsd: '100', researchLimitUsd: '50' })
  try {
    await assert.rejects(
      publicCase({
        scenario,
        prices,
        ledger,
        outputDir,
        credential: 'local-secret-do-not-log',
        transportOptions: { baseUrl: host.options.baseUrl, tls: host.options.tls },
      }),
      mode === 'unknown_cost'
        ? /Actual cost unknown/
        : /complete parsed tool call|deepStrictEqual|Expected values/,
    )
    assert.equal(host.requests.length, 1)
    const state = ledger.snapshot()
    assert.equal(state.entries[0].state, mode === 'unknown_cost' ? 'unknown' : 'settled')
    if (mode === 'unknown_cost')
      await assert.rejects(
        ledger.reserve({
          model: scenario.modelId,
          provider: scenario.provider,
          stage: 'acceptance',
          estimateUsd: '0.1',
        }),
        /Unsettled request/,
      )
    const files = await (await import('node:fs/promises')).readdir(outputDir)
    const evidenceName = files.find(name => name.startsWith('public-'))
    assert.ok(evidenceName)
    const evidence = await readFile(join(outputDir, evidenceName), 'utf8')
    assert.ok(!evidence.includes('local-secret-do-not-log'))
    assert.ok(!evidence.includes('WRONG'), 'raw tool arguments leaked')
    assert.ok(evidence.includes('local-safe-id'))
    await writeFile(
      join(outputDir, 'negative-result.json'),
      JSON.stringify(
        {
          mode,
          outcome: 'expected failure',
          finalLedgerState: state.entries[0].state,
          requestCount: host.requests.length,
          secretAbsent: true,
          rawArgumentsAbsent: true,
          evidenceScope: 'local TLS fault injection only',
        },
        null,
        2,
      ) + '\n',
      { flag: 'wx', mode: 0o600 },
    )
  } finally {
    await ledger.close()
  }
} finally {
  await host?.close()
  cert.dispose()
}
process.stdout.write(`local negative pass ${mode}\n`)
