import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import {
  definition,
  hash,
  modelIds,
  profile,
  sourceCommit,
  sourcePaths,
} from '../public-v2/core.mjs'

export const serviceSourcePaths = Object.freeze([
  ...sourcePaths,
  'tmp/priority-gates/service-v3/common.mjs',
  'tmp/priority-gates/service-v3/service-evidence.mjs',
  'tmp/priority-gates/service-v3/service-core.mjs',
  'tmp/priority-gates/service-v3/prepare.mjs',
  'tmp/priority-gates/service-v3/review.mjs',
  'tmp/priority-gates/service-v3/paid.mjs',
  'tmp/priority-gates/service-v3/local.mjs',
  'packages/model/model-request-runtime/src/service-calibration.ts',
  'packages/model/model-request-runtime/src/service-calls.ts',
  'examples/model-invocation-minimal-demo/src/bootstrap.ts',
  'examples/model-invocation-minimal-demo/src/deployment.ts',
  'examples/model-invocation-minimal-demo/src/model-call-host.ts',
  'examples/model-invocation-minimal-demo/src/model-request-text.ts',
])

export async function serviceSources() {
  return Object.fromEntries(
    await Promise.all(serviceSourcePaths.map(async path => [path, hash(await readFile(path))])),
  )
}
export function validateServiceScenario(s) {
  assert.equal(s.format, 1)
  assert.equal(s.caseKind, 'service_three_turn')
  assert.ok(['pending', 'approved'].includes(s.reviewStatus))
  assert.ok(modelIds.includes(s.modelId))
  const { provider, value } = definition(s.modelId)
  assert.equal(s.provider, provider)
  assert.equal(s.definitionRevision, value.revision)
  assert.deepEqual(s.implementation, value.implementation)
  assert.equal(s.expectedEndpointTag, provider)
  assert.equal(s.reasoningEffort, 'low')
  assert.ok(
    Number.isSafeInteger(s.maxOutputTokens) &&
      s.maxOutputTokens > 0 &&
      s.maxOutputTokens <= value.capabilities.maxOutputTokens,
  )
  assert.deepEqual(s.turns, [
    'Remember CEDAR. Reply exactly OK.',
    'What is the codeword? Reply with one word.',
    'Repeat only the codeword.',
  ])
  assert.equal(s.serviceWireSha256, null, 'live service wire SHA is unavailable')
  assert.equal(s.sourceCommit, sourceCommit())
  assert.deepEqual(Object.keys(s.sourceSha256).sort(), [...serviceSourcePaths].sort())
  assert.match(s.profileSha256, /^[0-9a-f]{64}$/)
  return s
}
export async function verifyServiceSources(s) {
  assert.deepEqual(s.sourceSha256, await serviceSources())
  assert.equal(s.profileSha256, hash(JSON.stringify(profile(s.modelId))))
}
