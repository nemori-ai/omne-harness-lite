import assert from 'node:assert/strict'
import { lstat } from 'node:fs/promises'
import { resolve } from 'node:path'
import { readPrivateFile } from '../../../examples/model-invocation-minimal-demo/dist/demo.js'
import {
  openProductionLedger,
  privateOutputDirectory,
  writePrivateEvidence,
} from '../../../tools/model-probe/src/production-gate.mjs'
import {
  approvedLedger,
  budget,
  pricing,
  readFrozen,
  reservation,
  verifyCatalog,
} from '../public-v2/core.mjs'
import { validateServiceScenario, verifyServiceSources } from './common.mjs'
import { servicePaidCase } from './service-core.mjs'

function argumentsFor(argv) {
  const map = new Map()
  for (let index = 0; index < argv.length; index += 2) {
    const key = argv[index],
      value = argv[index + 1]
    if (!key?.startsWith('--') || value === undefined || map.has(key))
      throw new Error('distinct option/value required')
    map.set(key, value)
  }
  const required = [
    '--mode',
    '--model',
    '--scenario',
    '--scenario-sha256',
    '--catalog',
    '--catalog-sha256',
    '--catalog-max-age-ms',
    '--ledger',
    '--credential-file',
    '--output-dir',
  ]
  assert.deepEqual([...map.keys()].sort(), required.sort(), 'exact production option set required')
  assert.equal(map.get('--mode'), 'production', 'explicit production mode required')
  return Object.fromEntries([...map].map(([key, value]) => [key.slice(2), value]))
}
const args = argumentsFor(process.argv.slice(2))
assert.equal(resolve(args.ledger), approvedLedger, 'one approved HUB ledger required')
const scenario = validateServiceScenario(await readFrozen(args.scenario, args['scenario-sha256']))
assert.equal(args.model, scenario.modelId)
assert.equal(scenario.reviewStatus, 'approved', 'separate human approval required')
await verifyServiceSources(scenario)
const catalog = await readFrozen(args.catalog, args['catalog-sha256'])
await verifyCatalog(catalog, resolve(args.catalog), scenario)
const prices = pricing(catalog, scenario, Number(args['catalog-max-age-ms']))
const estimateUsd = reservation(prices, scenario)
const ledgerStat = await lstat(approvedLedger)
assert.ok(
  ledgerStat.isFile() && ledgerStat.uid === process.getuid() && (ledgerStat.mode & 0o777) === 0o600,
)
const outputDir = await privateOutputDirectory(args['output-dir'])
const ledger = await openProductionLedger(args.ledger, approvedLedger, budget)
let credentialBytes
try {
  const raw = await readPrivateFile(args['credential-file'])
  try {
    credentialBytes = Buffer.from(raw.subarray(0, raw.at(-1) === 10 ? raw.length - 1 : raw.length))
  } finally {
    raw.fill(0)
  }
  assert.ok(
    credentialBytes.length > 0 && credentialBytes.every(byte => byte >= 0x20 && byte <= 0x7e),
  )
  await writePrivateEvidence(
    `${outputDir}/manifest.json`,
    JSON.stringify(
      {
        modelId: scenario.modelId,
        caseKind: scenario.caseKind,
        scenarioSha256: args['scenario-sha256'],
        catalogSha256: args['catalog-sha256'],
        sourceCommit: scenario.sourceCommit,
        sourceSha256: scenario.sourceSha256,
        definitionRevision: scenario.definitionRevision,
        implementation: scenario.implementation,
        profileSha256: scenario.profileSha256,
        serviceLiveWireSha256: 'unavailable',
        estimateUsdPerRequest: estimateUsd,
        maximumPlannedRequests: 3,
        budget,
      },
      null,
      2,
    ) + '\n',
  )
  const results = await servicePaidCase({
    scenario,
    pricing: prices,
    ledger,
    outputDir,
    credentialBytes,
  })
  await writePrivateEvidence(
    `${outputDir}/summary.json`,
    JSON.stringify(
      {
        modelId: scenario.modelId,
        completed: results.map(value => ({
          entryId: value.entryId,
          outcome: value.outcome,
          typedRejection: value.typedRejection ?? null,
          usage: value.usage,
          cost: value.cost,
          durable: value.durable,
        })),
        expectedTurns: 3,
        serviceOwnerCloseEvidence: 'service-close-*.json',
        ledgerCloseFollowsSummaryWrite: true,
      },
      null,
      2,
    ) + '\n',
  )
} finally {
  credentialBytes?.fill(0)
  await ledger.close()
}
