import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { applicable, hash, modelIds, gates, sourceCommit } from './core.mjs'

if (process.argv.length !== 6 || process.argv[2] !== '--set' || process.argv[4] !== '--output-dir')
  throw new Error('usage: run-matrix.mjs --set first|all --output-dir NEW_DIR')
const selected =
  process.argv[3] === 'all'
    ? modelIds
    : process.argv[3] === 'first'
      ? modelIds.filter(
          id => id.startsWith('anthropic/') || /^openai\/gpt-5\.6-(sol|terra|luna)$/.test(id),
        )
      : null
assert.ok(selected)
const root = process.argv[5]
await mkdir(root, { mode: 0o700, recursive: false })
const rows = []
function run(args) {
  const done = spawnSync(process.execPath, args, {
    cwd: process.cwd(),
    env: process.env,
    encoding: 'utf8',
    maxBuffer: 4_000_000,
  })
  if (done.status !== 0) throw new Error(`${args.join(' ')}\n${done.stdout}\n${done.stderr}`)
  process.stdout.write(done.stdout)
}
for (const modelId of selected) {
  for (const gate of gates) {
    if (!applicable(modelId, gate)) continue
    const name = `${modelId.split('/')[1]}-${gate}`
    const directory = join(root, name)
    await mkdir(directory, { mode: 0o700 })
    const scenarioPath = join(directory, 'scenario.json')
    run([
      'tmp/priority-gates/public-v2/prepare.mjs',
      '--model',
      modelId,
      '--gate',
      gate,
      '--max-output-tokens',
      '256',
      '--output',
      scenarioPath,
    ])
    const digest = hash(await readFile(scenarioPath))
    run([
      '--experimental-transform-types',
      'tmp/priority-gates/public-v2/local.mjs',
      '--scenario',
      scenarioPath,
      '--scenario-sha256',
      digest,
      '--output-dir',
      join(directory, 'local'),
    ])
    const result = JSON.parse(await readFile(join(directory, 'local', 'local-result.json'), 'utf8'))
    rows.push({
      modelId,
      gate,
      scenarioPath,
      scenarioSha256: digest,
      wireSha256: result.wireSha256,
      requestCount: result.requestCount,
      ledgerState: JSON.parse(
        await readFile(join(directory, 'local', 'fixture-ledger.json'), 'utf8'),
      ).entries[0].state,
      localScope: result.evidenceScope,
    })
  }
}
await writeFile(
  join(root, 'matrix-result.json'),
  JSON.stringify(
    {
      sourceCommit: sourceCommit(),
      count: rows.length,
      expected: process.argv[3] === 'first' ? 25 : 44,
      paidRequests: 0,
      rows,
    },
    null,
    2,
  ) + '\n',
  { flag: 'wx', mode: 0o600 },
)
assert.equal(rows.length, process.argv[3] === 'first' ? 25 : 44)
process.stdout.write(`local matrix ${rows.length}/${rows.length} passed; paid=0\n`)
