import assert from 'node:assert/strict'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import { definition, hash, profile, sourceCommit } from '../public-v2/core.mjs'
import { serviceSources, validateServiceScenario } from './common.mjs'

if (
  process.argv.length !== 8 ||
  process.argv[2] !== '--model' ||
  process.argv[4] !== '--max-output-tokens' ||
  process.argv[6] !== '--output'
)
  throw new Error(
    'usage: service-v3/prepare.mjs --model EXACT --max-output-tokens N --output NEW_PATH',
  )
const modelId = process.argv[3]
const maxOutputTokens = Number(process.argv[5])
const { provider, value } = definition(modelId)
assert.ok(
  Number.isSafeInteger(maxOutputTokens) &&
    maxOutputTokens > 0 &&
    maxOutputTokens <= value.capabilities.maxOutputTokens,
)
const scenario = validateServiceScenario({
  format: 1,
  caseKind: 'service_three_turn',
  reviewStatus: 'pending',
  modelId,
  provider,
  definitionRevision: value.revision,
  implementation: value.implementation,
  expectedEndpointTag: provider,
  reasoningEffort: 'low',
  maxOutputTokens,
  turns: [
    'Remember CEDAR. Reply exactly OK.',
    'What is the codeword? Reply with one word.',
    'Repeat only the codeword.',
  ],
  serviceWireSha256: null,
  profileSha256: hash(JSON.stringify(profile(modelId))),
  sourceCommit: sourceCommit(),
  sourceSha256: await serviceSources(),
})
await mkdir(dirname(process.argv[7]), { mode: 0o700, recursive: true })
await writeFile(process.argv[7], JSON.stringify(scenario, null, 2) + '\n', {
  flag: 'wx',
  mode: 0o600,
})
process.stdout.write(`${modelId} service pending ${hash(await readFile(process.argv[7]))}\n`)
