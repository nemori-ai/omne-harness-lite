import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { usdString, usdUnits } from '../../../tools/model-probe/src/budget.mjs'
import {
  createTransport,
  hash,
  planFor,
  pricing,
  readFrozen,
  reservation,
  validateScenario,
  verifyCatalog,
  verifySources,
} from './core.mjs'

if (process.argv.length !== 7)
  throw new Error('usage: review.mjs SCENARIO SCENARIO_SHA CATALOG CATALOG_SHA MAX_AGE_MS')
const [scenarioPath, scenarioSha, catalogPath, catalogSha, maxAgeText] = process.argv.slice(2)
const scenario = validateScenario(await readFrozen(scenarioPath, scenarioSha))
await verifySources(scenario)
const transport = createTransport(scenario)
try {
  const { planned } = await planFor(scenario, transport)
  assert.equal(hash(planned.serialized), scenario.publicWireSha256)
} finally {
  await transport.close()
}
const catalog = await readFrozen(catalogPath, catalogSha)
await verifyCatalog(catalog, resolve(catalogPath), scenario)
const amount = reservation(pricing(catalog, scenario, Number(maxAgeText)), scenario)
process.stdout.write(
  JSON.stringify(
    {
      modelId: scenario.modelId,
      gate: scenario.gate,
      reviewStatus: scenario.reviewStatus,
      scenarioSha256: scenarioSha,
      catalogSha256: catalogSha,
      catalogObservedAt: catalog.observedAt,
      endpointTag: scenario.expectedEndpointTag,
      definitionRevision: scenario.definitionRevision,
      implementation: scenario.implementation,
      profileSha256: scenario.profileSha256,
      publicWireSha256: scenario.publicWireSha256,
      sourceCommit: scenario.sourceCommit,
      sourceSha256: scenario.sourceSha256,
      estimateUsdForOneRequest: amount,
      maximumPlannedRequests: 1,
      maximumPlannedReservationUsd: usdString(usdUnits(amount)),
      scope:
        'one production public invoke; no authenticated service claim; no remote send by review',
    },
    null,
    2,
  ) + '\n',
)
