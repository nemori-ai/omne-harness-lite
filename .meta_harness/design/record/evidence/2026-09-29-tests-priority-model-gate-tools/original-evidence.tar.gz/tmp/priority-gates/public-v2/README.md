# T16 public applicability successor

This private tool succeeds the frozen `tmp/priority-gates/` public package on
source commit `6fe9b1a4bd1f3b1bccf9099f2eb0b9eddc8757fe`. It uses the same
public `invokeModel`, production transport planner, original whole-context
reservation and production ledger gate. It changes the applicability table
only where the current definition and input meter now provide a local basis.
The root frozen package and its 105-file SHA inventory remain untouched.

| Gate            | Eligible exact bindings                       | Local count |
| --------------- | --------------------------------------------- | ----------: |
| `tool_schema`   | All 16                                        |          16 |
| `inline_image`  | Anthropic 4, GPT-5.6 base 3, GPT-6 Astra base |           8 |
| `effort_high`   | All 16, including GPT-6 Luna base             |          16 |
| `stop_sequence` | Anthropic 4                                   |           4 |

Total applicability is 44 local planner cases. The two additions are based on
the current OpenAI definitions/input meters: GPT-6 Luna revision 4 / `mp4-9`
with its declared high-effort domain, and GPT-6 Astra revision 3 / `mp4-10`
with its estimated image patch meter. The resulting request measurements are
`full/estimated`. The generated scenario fixes the exact definition,
implementation, profile/configuration hash, produced entry-point/source hashes,
image fixture hash where applicable, and public wire SHA. This is a local
applicability basis, not evidence that OpenRouter honors either feature. The
accepted semantic inputs remain RT10/MR9; the current provider mapping is
the [transport node](../../../.meta_harness/design/realization/packages/model/pi-ai-transport/README.md).

The two final controlled-TLS results each show one reserved-before-HTTP
request, one complete response, an original actual-cost receipt and a settled
local ledger. The local wire SHA equals the scenario's frozen planner bytes:

| Case                       | Scenario SHA256                                                    | Wire SHA256                                                        |
| -------------------------- | ------------------------------------------------------------------ | ------------------------------------------------------------------ |
| GPT-6 Luna `effort_high`   | `6ec2c3e1549f84d071475d2f2466c773b93963d8555df7de693723f1f3561fda` | `26008286e4c37895d15a4d81cf5667e8987f0ae95918b07a40be66e1560bd4bb` |
| GPT-6 Astra `inline_image` | `2e400347e26b475ce2b1a1a95fcb1964cee3ffd6d963682dbc464b01d7e301b2` | `694988fcf6389fd8bbc1e5261a7671b1668b4a78f4307bb14e8b98a614bf25d2` |

`preflight-luna-high` rejected five production-entry violations before key,
formal ledger or HTTP. `typed-rejection-result.json` uses the still-unsupported
GPT-6 Sol image path to verify a content-free planner refusal; Luna high effort
is no longer used as a negative. The targeted current-product transport tests
(`openai-encrypted-replay`, `openai-astra-images`, `openai-luna-completion`)
passed 36/36 on this source. No paid request was made.

## Reproduce and hand off

Run from the intended checkout with a fresh output directory. The matrix
driver supports `--set first|all`; `all` expects 44 cases, but this author run
executed only the two new cases. Root must copy the successor scripts into its
current HUB, rebuild, regenerate each scenario and review its new source,
binding, route, profile/configuration, public wire and fresh raw catalog SHA.
The scenarios in `generated/` are bound to this spoke commit and cannot be
used online on a different HUB source.

```sh
pnpm -r --filter '@omne-harness-lite/model-invocation-minimal-demo...' --workspace-concurrency=1 run build
node tmp/priority-gates/public-v2/prepare.mjs --model openai/gpt-6-luna --gate effort_high --max-output-tokens 256 --output tmp/priority-gates/public-v2/generated/NEW/scenario.json
sha256sum tmp/priority-gates/public-v2/generated/NEW/scenario.json
node --experimental-transform-types tmp/priority-gates/public-v2/local.mjs --scenario tmp/priority-gates/public-v2/generated/NEW/scenario.json --scenario-sha256 SHA --output-dir tmp/priority-gates/public-v2/results/NEW
node tmp/priority-gates/public-v2/preflight-negative.mjs --scenario tmp/priority-gates/public-v2/generated/NEW/scenario.json --scenario-sha256 SHA --output-dir tmp/priority-gates/public-v2/preflight-NEW
```

For Astra substitute `--model openai/gpt-6-astra --gate inline_image` and a
distinct output path. The root-only online flow uses the frozen public catalog
capture, then this directory's `review.mjs` and `paid.mjs` with an approved new
scenario and the one approved HUB ledger. `paid.mjs` checks exact source, plan,
profile, wire and catalog before key/ledger access; it permits one bounded
send. Unknown cost stays unknown and stops. The service path is separately
documented in `../service-v3/README.md`.

`SHA256SUMS` covers the successor scripts, README/manifest, two scenarios,
their top-level local results, the production preflight result and the typed
rejection result. It excludes local TLS private-key files. Retain the full
private results if the actual fixture resources need independent inspection.
