import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { approvedLedger, hash, readFrozen, validateScenario } from './core.mjs'

if (
  process.argv.length !== 8 ||
  process.argv[2] !== '--scenario' ||
  process.argv[4] !== '--scenario-sha256' ||
  process.argv[6] !== '--output-dir'
)
  throw new Error(
    'usage: preflight-negative.mjs --scenario PATH --scenario-sha256 SHA --output-dir NEW_DIR',
  )
const scenario = validateScenario(await readFrozen(process.argv[3], process.argv[5]))
const outputDir = process.argv[7]
await mkdir(outputDir, { mode: 0o700 })
const catalogPath = join(outputDir, 'fixture-catalog.json')
await writeFile(catalogPath, JSON.stringify({ format: 1, captureSource: 'fixture' }), {
  mode: 0o600,
})
const catalogSha = hash(await readFile(catalogPath))
function execute(name, value, ledger = approvedLedger, mode = 'production') {
  const path = join(outputDir, `${name}.json`)
  const bytes = Buffer.from(JSON.stringify(value))
  return writeFile(path, bytes, { mode: 0o600 }).then(() => {
    const result = spawnSync(
      process.execPath,
      [
        'tmp/priority-gates/public-v2/paid.mjs',
        '--mode',
        mode,
        '--model',
        scenario.modelId,
        '--scenario',
        path,
        '--scenario-sha256',
        hash(bytes),
        '--catalog',
        catalogPath,
        '--catalog-sha256',
        catalogSha,
        '--catalog-max-age-ms',
        '3600000',
        '--ledger',
        ledger,
        '--credential-file',
        join(outputDir, 'missing-key'),
        '--output-dir',
        join(outputDir, 'missing-output'),
      ],
      { encoding: 'utf8', maxBuffer: 2_000_000 },
    )
    return { status: result.status, stderr: result.stderr }
  })
}
const approved = { ...scenario, reviewStatus: 'approved' }
const cases = [
  ['wrong_mode', scenario, approvedLedger, 'fixture', /production mode must be explicit/],
  [
    'wrong_ledger',
    scenario,
    join(outputDir, 'other-ledger'),
    'production',
    /one approved HUB ledger/,
  ],
  ['pending', scenario, approvedLedger, 'production', /separate human scenario approval/],
  [
    'bad_source',
    {
      ...approved,
      sourceSha256: {
        ...approved.sourceSha256,
        'tmp/priority-gates/public-v2/core.mjs': '0'.repeat(64),
      },
    },
    approvedLedger,
    'production',
    /deepStrictEqual|Expected values/,
  ],
  ['fixture_catalog', approved, approvedLedger, 'production', /fixture catalog forbidden/],
]
const results = []
for (const [name, value, ledger, mode, pattern] of cases) {
  const result = await execute(name, value, ledger, mode)
  assert.notEqual(result.status, 0, `${name} incorrectly entered paid path`)
  assert.match(result.stderr, pattern, `${name} failed for the wrong reason`)
  results.push({ name, rejectedBeforeCredentialLedgerOrHttp: true })
}
await writeFile(
  join(outputDir, 'preflight-result.json'),
  JSON.stringify(
    {
      scenarioModel: scenario.modelId,
      cases: results,
      formalLedgerRead: false,
      credentialRead: false,
      httpRequests: 0,
      evidenceScope: 'entrypoint rejection based on inspected ordering and error oracle',
    },
    null,
    2,
  ) + '\n',
  { mode: 0o600 },
)
process.stdout.write(
  `production entry preflight negatives ${results.length}/${results.length} passed\n`,
)
