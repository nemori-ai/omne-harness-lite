import assert from 'node:assert/strict'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { openLedger } from '../../../tools/model-probe/src/budget.mjs'
import {
  certificate,
  content,
  finish,
  fixture,
  sse,
} from '../../../packages/model/pi-ai-transport/tests/support.ts'
import {
  createTransport,
  definition,
  hash,
  planFor,
  publicCase,
  readFrozen,
  reservation,
  tool,
  validateScenario,
  verifySources,
} from './core.mjs'

if (
  process.argv.length !== 8 ||
  process.argv[2] !== '--scenario' ||
  process.argv[4] !== '--scenario-sha256' ||
  process.argv[6] !== '--output-dir'
)
  throw new Error('usage: local.mjs --scenario PATH --scenario-sha256 SHA --output-dir DIR')
const scenario = validateScenario(await readFrozen(process.argv[3], process.argv[5]))
await verifySources(scenario)
const outputDir = process.argv[7]
await mkdir(outputDir, { mode: 0o700, recursive: true })
const prices = {
  prompt: '0.000001',
  completion: '0.000001',
  input_cache_write_1h: '0.000001',
  request: '0',
}
const plannedTransport = createTransport(scenario)
let planned
try {
  ;({ planned } = await planFor(scenario, plannedTransport))
  assert.equal(hash(planned.serialized), scenario.publicWireSha256)
} finally {
  await plannedTransport.close()
}
const cert = certificate()
let host
const ledgerPath = join(outputDir, 'fixture-ledger.json')
try {
  host = await fixture(
    cert.tls,
    async (response, request) => {
      const ledger = JSON.parse(await readFile(ledgerPath, 'utf8'))
      assert.equal(ledger.entries.length, 1, 'request reached HTTP without a prior reservation')
      assert.equal(ledger.entries[0].state, 'reserved', 'reservation not durable before HTTP')
      assert.equal(
        request.body,
        planned.serialized,
        'actual TLS body differs from frozen production plan',
      )
      assert.equal(request.path, '/api/v1/chat/completions')
      response.setHeader('x-request-id', 'local-gate-id')
      response.end(
        (scenario.gate === 'tool_schema'
          ? sse({
              choices: [
                {
                  delta: {
                    tool_calls: [
                      {
                        index: 0,
                        id: 'call_exact',
                        function: { name: tool.name, arguments: '{"query":"CEDAR"}' },
                      },
                    ],
                  },
                },
              ],
            })
          : content(
              scenario.gate === 'inline_image'
                ? 'RED'
                : scenario.gate === 'stop_sequence'
                  ? 'A'
                  : 'OK',
            )) +
          sse({
            id: 'local-generation',
            model: scenario.modelId,
            provider: scenario.provider === 'openai' ? 'OpenAI' : 'Anthropic',
            choices: [],
            usage: { prompt_tokens: 20, completion_tokens: 2, cost: 0.0000117 },
          }) +
          finish(scenario.gate === 'tool_schema' ? 'tool_calls' : 'stop'),
      )
    },
    {},
    undefined,
    [definition(scenario.modelId).value],
  )
  const ledger = await openLedger(ledgerPath, { limitUsd: '100', researchLimitUsd: '50' })
  try {
    const result = await publicCase({
      scenario,
      prices,
      ledger,
      outputDir,
      credential: 'local-synthetic',
      transportOptions: { baseUrl: host.options.baseUrl, tls: host.options.tls },
    })
    assert.equal(host.requests.length, 1)
    assert.equal(ledger.snapshot().entries[0].state, 'settled')
    await writeFile(
      join(outputDir, 'local-result.json'),
      JSON.stringify(
        {
          modelId: scenario.modelId,
          gate: scenario.gate,
          scenarioSha256: process.argv[5],
          wireSha256: scenario.publicWireSha256,
          reservationUsd: reservation(prices, scenario),
          result,
          requestCount: host.requests.length,
          transportClosedAfterBusiness: true,
          fixtureServerCloseFollowsEvidenceWrite: true,
          evidenceScope:
            'production public invoke via local TLS; synthetic upstream response; remote model behavior unproven',
        },
        null,
        2,
      ) + '\n',
      { flag: 'wx', mode: 0o600 },
    )
  } finally {
    await ledger.close()
  }
} finally {
  await host?.close()
  cert.dispose()
}
process.stdout.write(
  `local pass ${scenario.modelId} ${scenario.gate} ${scenario.publicWireSha256}\n`,
)
