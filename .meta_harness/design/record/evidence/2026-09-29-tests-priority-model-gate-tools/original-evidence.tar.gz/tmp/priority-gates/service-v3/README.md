# T16 authenticated service successor

This private service tool succeeds the frozen `service-v2` package without
changing its bytes or SHA inventory. It consumes the `public-v2` production
helper, current demo authentication, SQLite identity, real SL3 JSONL log,
call host and diagnostic assembly. Source commit is
`6fe9b1a4bd1f3b1bccf9099f2eb0b9eddc8757fe`; the adopted behavior is
[RT10](../../../.meta_harness/design/spec/capabilities/model-request-runtime/v10/contract.md)
S-17/S-54/S-68–S-75, [MR9](../../../.meta_harness/design/spec/data/model-response/v9/contract.md)
S-17/S-41–S-45 and [SL3](../../../.meta_harness/design/spec/capabilities/session-log/v3/contract.md)
S-13/S-17/S-32–S-37. Provider mapping is the runtime
[realization node](../../../.meta_harness/design/realization/packages/model/model-request-runtime/README.md)
and [transport v12 node](../../../.meta_harness/design/realization/packages/model/pi-ai-transport/README.md).

The successor fixes the v2 oracle after the current GPT-5.6 base encrypted
replay meter. A complete first-turn encrypted reasoning group is now valid:
the local TLS fixture supplies that upstream fact, the real service persists
the response, and turns two and three send the original group in their actual
request bodies. This case is `encrypted_three`, not the old v2 refusal. The
second-turn rejection case instead supplies a data-contract-valid user image
whose bytes are not PNG. The real current input meter cannot measure it; the
service returns `invalidInput/input_size_unavailable/maxInputTokens` before a
second HTTP request. The tool does not mock the planner or alter product
calibration. The source product's separate transport test checks an incomplete
same-source output group; that pure/public negative does not stand in for the
authenticated service run.

All six final `v2` local cases used the same pending scenario SHA
`d2e65e3ccb5073389ff8c78cb2bb7a0e3da7533f72020bb2cc61c6e4cb100da1`.
Each TLS handler read the on-disk ledger and required `reserved` before
responding. Every returned response was compared with an actual SL3 read.
The refusal receipt was saved before settlement. All cases recorded actual
business, diagnostic and host close success. The second and third encrypted
replay requests have local-only body SHA256 values
`7812b485bf1f8500ad9ea629cd8a70269202c720b5bb6c997e3e5d7d74ace71b`
and `7d77d2d43c20ad53fa90e3484e8e8d8a9477e0d53c17d79cff445da04c2b7971`;
each contains the source encrypted group once. No ciphertext appears in the
top-level receipts.

| Local case           | HTTP | Final ledger states | Observable result                                                                                   |
| -------------------- | ---: | ------------------- | --------------------------------------------------------------------------------------------------- |
| `positive`           |    3 | settled ×3          | Three complete durable responses                                                                    |
| `encrypted_three`    |    3 | settled ×3          | Complete encrypted group appears in later wire requests, three durable responses                    |
| `unsupported_second` |    1 | settled, unknown    | Valid first encrypted reply; unsupported second input rejected, typed receipt saved, no second send |
| `unknown_cost`       |    1 | unknown             | Missing original actual cost stops later turns; no zero substitution                                |
| `in_band_failure`    |    1 | unknown             | Durable failed response/status 503, original unknown cost, content-free private failure receipt     |
| `zero_http_refusal`  |    0 | unknown             | First service refusal leaves reserve unknown without trusted cost-disposition evidence              |

The positive, encrypted and in-band cases exercise RT10 S-17/S-75 with SL3
S-32–S-37. The unsupported and zero-HTTP cases exercise the RT10 S-74 input
gate; the unknown-cost case checks S-17 and call-accounts v2 S-19/S-20.
`preflight-v2` refused five invalid production entries before key, formal
ledger or HTTP. Targeted current-source transport tests passed 36/36 and demo
service tests passed 34/34. The transport set includes the product's
incomplete-group negative; it is not an authenticated service oracle.
The local tests use synthetic upstream content and make no paid request.

The generated scenario freezes 38 product/tool source or built-entry bytes,
definition revision 5 / `mp4-11`, profile/configuration SHA and exact model
identity. The service API does not expose the per-turn live transport bytes:
`serviceWireSha256` remains `null`, and `liveWireSha256` remains
`unavailable`. A profile or local TLS hash is not a live service wire SHA.
Root has advanced HUB beyond this spoke's `6fe9b1a4` baseline. It must
regenerate and review its own scenario; this spoke's scenario is invalid on
that different source commit. Root owns the real key,
formal ledger, fresh catalog and each bounded paid send.

## Reproduce locally without paid access

```sh
pnpm -r --filter '@omne-harness-lite/model-invocation-minimal-demo...' --workspace-concurrency=1 run build
node tmp/priority-gates/service-v3/prepare.mjs --model openai/gpt-5.6-luna --max-output-tokens 256 --output tmp/priority-gates/service-v3/generated/NEW/scenario.json
sha256sum tmp/priority-gates/service-v3/generated/NEW/scenario.json
node --experimental-transform-types tmp/priority-gates/service-v3/local.mjs --scenario tmp/priority-gates/service-v3/generated/NEW/scenario.json --scenario-sha256 SHA --case encrypted_three --output-dir tmp/priority-gates/service-v3/results/NEW-encrypted
node --experimental-transform-types tmp/priority-gates/service-v3/local.mjs --scenario tmp/priority-gates/service-v3/generated/NEW/scenario.json --scenario-sha256 SHA --case unsupported_second --output-dir tmp/priority-gates/service-v3/results/NEW-unsupported
node tmp/priority-gates/service-v3/preflight-negative.mjs --scenario tmp/priority-gates/service-v3/generated/NEW/scenario.json --scenario-sha256 SHA --output-dir tmp/priority-gates/service-v3/preflight-NEW
```

The same `local.mjs` accepts `positive`, `unknown_cost`, `in_band_failure` and
`zero_http_refusal`, each with a new result directory. For root's online
stage, regenerate the scenario on the current HUB, obtain a fresh raw public
catalog, separately approve the scenario, run `review.mjs`, then use
`paid.mjs` with its exact option/value CLI and the sole approved ledger.
The production path reserves independently for each of at most three turns;
unknown cost or failed outcome stops the next turn. A stopped run has original
receipts and ledger state, not a success summary.

`SHA256SUMS` covers the eight service scripts, README/manifest, final scenario,
six top-level local result sets and preflight result. It excludes generated
local credentials, SQLite and TLS private keys; retain those private result
directories while a reviewer needs to inspect physical resources.
