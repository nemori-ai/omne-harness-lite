import assert from 'node:assert/strict'
import { writeFile } from 'node:fs/promises'
import { typedRejection } from './evidence.mjs'
import { createTransport, profile, requestFor } from './core.mjs'

const original = {
  rejected: 'invalidInput',
  reason: 'input_size_unavailable',
  metrics: ['maxInputTokens'],
  request: 'private-message-body',
  opaque: 'private-encrypted-reasoning',
}
const service = {
  invalidInput: {
    reason: 'input_size_unavailable',
    metrics: ['maxInputTokens'],
    request: 'private-message-body',
  },
}
const publicResult = typedRejection(original)
const serviceResult = typedRejection(service)
assert.deepEqual(publicResult, {
  category: 'invalidInput',
  reason: 'input_size_unavailable',
  metrics: ['maxInputTokens'],
})
assert.deepEqual(serviceResult, publicResult)
assert.deepEqual(
  typedRejection({
    rejected: 'invalidInput',
    reason: 'input_limit_exceeded',
    basis: 'estimated',
    metric: 'maxInputTokens',
    estimatedTokens: 200,
    admissionTokens: 220,
    limit: 100,
    secret: 'private-message-body',
  }),
  {
    category: 'invalidInput',
    reason: 'input_limit_exceeded',
    basis: 'estimated',
    metric: 'maxInputTokens',
    estimatedTokens: '200',
    admissionTokens: '220',
    limit: '100',
  },
)
assert.deepEqual(
  typedRejection({
    rejected: 'invalidInput',
    reason: 'private-secret',
    metrics: ['maxInputTokens', 'private-secret'],
  }),
  { category: 'invalidInput' },
)
assert.equal(typedRejection({ rejected: 'private-secret' }), null)
// GPT-6 Sol still has no applicable inline-image meter. Luna high effort is now valid.
const unsupported = { modelId: 'openai/gpt-6-sol', gate: 'inline_image', maxOutputTokens: 256 }
const transport = createTransport(unsupported)
let actualPlannerProjection
try {
  const refusal = transport.plan(await requestFor(unsupported, profile(unsupported.modelId)))
  assert.ok('rejected' in refusal)
  actualPlannerProjection = typedRejection(refusal)
  assert.deepEqual(actualPlannerProjection, publicResult)
} finally {
  await transport.close()
}
const evidence = JSON.stringify({ publicResult, serviceResult })
assert.ok(!evidence.includes('private-'))
await writeFile(
  'tmp/priority-gates/public-v2/typed-rejection-result.json',
  JSON.stringify(
    {
      originalPublic: publicResult,
      serviceProjection: serviceResult,
      actualPlannerProjection,
      allowedEstimatedLimitFields: true,
      secretAbsent: true,
      evidenceScope:
        'pure sanitizer and service-shaped refusal projection; no real second service turn',
    },
    null,
    2,
  ) + '\n',
  { flag: 'wx', mode: 0o600 },
)
process.stdout.write('typed pre-send rejection sanitizer 5/5 passed\n')
