// Fixture-only preload: block only the original read-only Docker health process.
if (process.argv[1] === '/opt/omne/app/deploy/docker/health.mjs') {
  setInterval(() => {}, 60_000)
  await new Promise(() => {})
}
