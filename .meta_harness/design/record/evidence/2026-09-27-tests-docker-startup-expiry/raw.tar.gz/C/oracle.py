#!/usr/bin/env python3
"""Independent raw-evidence oracle for the finite DK-I9 QA health expiry run."""

import argparse
import json
import pathlib
import re

HEX = re.compile(r"[0-9a-f]{64}\Z")


def need(value, message):
    if not value:
        raise ValueError(message)


def raw(run, commands, label, stream="stdout"):
    item = commands[label]
    path = run / item[stream]
    need(path.parent == run / "raw" and path.is_file(), label + " raw missing")
    return path.read_bytes()


def success(commands, label):
    item = commands[label]
    need(item["returncode"] == 0 and item["observation_expired"] is False,
         label + " actual command failed/observation expired")


def one_json(data, label):
    need(data.endswith(b"\n") and data.count(b"\n") == 1,
         label + " must be one JSON+LF")
    value = json.loads(data[:-1].decode("utf-8", "strict"))
    need(isinstance(value, dict), label + " object required")
    return value


def one_inspect(run, commands, label, identity):
    success(commands, label)
    values = json.loads(raw(run, commands, label).decode("utf-8", "strict"))
    need(isinstance(values, list) and len(values) == 1 and values[0]["Id"] == identity,
         label + " exact inspect identity")
    return values[0]


def stat_line(run, commands, label):
    success(commands, label)
    value = raw(run, commands, label)
    need(value.endswith(b"\n") and value.count(b"\n") == 1,
         label + " stat line")
    return value.decode("utf-8", "strict").strip()


def evaluate(run):
    evidence = json.loads((run / "evidence.json").read_text())
    commands = {item["label"]: item for item in evidence["commands"]}
    need(len(commands) == len(evidence["commands"]), "duplicate measurement labels")
    need(evidence["scenario"] == "C-startup-observation-expiry"
         and evidence["status"] == "observed-awaiting-oracle"
         and evidence["business_complete"] is True, "C observation incomplete")
    expected = evidence["expected"]
    inputs = evidence["inputs"]
    cid = expected["center_id"]
    qa_id = expected["qa_image_id"]
    base_id = expected["base_image_id"]
    project = expected["project"]
    build = expected["build_id"]
    need(HEX.fullmatch(cid) and HEX.fullmatch(build)
         and base_id == expected["inner_image_id"] and qa_id != base_id,
         "expected center/image identity")
    need(inputs["scenario"] == evidence["scenario"] and
         inputs["image_id"] == expected["image_id"] and
         inputs["build_id"] == build, "frozen inputs/expectation mismatch")

    helper = ["docker", "exec", "-e",
              "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock",
              expected["control"], "/usr/local/libexec/omne-center"]
    for label, action in (("c-validate", "validate"), ("c-start", "start"),
                          ("c-status-after-start", "status")):
        need(commands[label]["argv"][:len(helper) + 1] == [*helper, action],
             label + " not real helper/private socket")
    for label in ("c-validate", "c-start"):
        argv = commands[label]["argv"]
        for key, value in (("--project", project), ("--image", qa_id),
                           ("--state-dir", expected["state"]),
                           ("--uid", str(expected["uid"])),
                           ("--gid", str(expected["gid"])),
                           ("--startup-wait", str(inputs["startup_wait"])),
                           ("--observation-interval", str(inputs["observation_interval"])),
                           ("--health-interval", inputs["health_interval"]),
                           ("--health-timeout", inputs["health_timeout"]),
                           ("--health-start-period", inputs["health_start_period"]),
                           ("--health-retries", str(inputs["health_retries"]))):
            need(argv.count(key) == 1 and argv[argv.index(key) + 1] == value,
                 label + " fixture/helper argument changed: " + key)
    success(commands, "c-validate")
    need(one_json(raw(run, commands, "c-validate"), "c-validate") ==
         {"state": "deployment-structure-valid"}, "validate structure")
    need(commands["c-build-qa-image"]["argv"][:8] ==
         ["docker", "exec", expected["control"], "env", "DOCKER_BUILDKIT=0",
          "docker", "--host", "unix:///opt/omne-private-docker/docker.sock"],
         "QA build must use private legacy Engine")
    build_argv = commands["c-build-qa-image"]["argv"]
    need("--pull=false" in build_argv and "--network=none" in build_argv
         and "BASE_IMAGE=" + base_id in build_argv,
         "QA build must use only pinned local base/no network")
    success(commands, "c-build-qa-image")
    outer = one_inspect(run, commands, "outer-product-image", expected["image_id"])
    base = one_inspect(run, commands, "c-base-image-inspect", base_id)
    qa = one_inspect(run, commands, "c-qa-image-inspect", qa_id)
    need(outer["RootFS"]["Layers"] == base["RootFS"]["Layers"]
         and outer["Os"] == base["Os"] == qa["Os"] == "linux"
         and outer["Architecture"] == base["Architecture"] == qa["Architecture"] == "arm64",
         "base import or QA platform mismatch")
    need(base["Config"]["Labels"] == qa["Config"]["Labels"]
         and qa["Config"]["Labels"]["ai.nemori.omne.host-build-id"] == build
         and qa["Config"]["Labels"]["ai.nemori.omne.distribution"] ==
         "tenancy-host-docker/1", "QA product labels/BUILD changed")
    need(base["Config"]["Healthcheck"] == qa["Config"]["Healthcheck"]
         and qa["Config"]["Healthcheck"]["Test"] ==
         ["CMD", "node", "/opt/omne/app/deploy/docker/health.mjs"],
         "QA image changed original health command")
    need(qa["Config"]["Env"] == base["Config"]["Env"] +
         ["NODE_OPTIONS=--import=/probe/qa-health-delay.mjs"],
         "QA preload must be sole env difference")
    for key in ("User", "Entrypoint", "Cmd", "WorkingDir"):
        need(base["Config"][key] == qa["Config"][key], "QA image config changed: " + key)
    success(commands, "c-probe-inventory")
    probe = one_json(raw(run, commands, "c-probe-inventory"), "c-probe-inventory")
    need(probe == {"file": True, "uid": 0, "gid": 0, "mode": 292,
                   "sha256": inputs["sha256"]["qa-context/qa-health-delay.mjs"]},
         "QA preload file bytes/mode/owner")
    for label in ("c-base-app-inventory", "c-qa-app-inventory"):
        success(commands, label)
    original = json.loads(raw(run, commands, "c-base-app-inventory"))
    delayed = json.loads(raw(run, commands, "c-qa-app-inventory"))
    need(isinstance(original, list) and original == delayed
         and len(original) == expected["app_inventory_entries"]
         and len([x for x in delayed if x["path"] == "BUILD_ID" and x["kind"] == "file"]) == 1,
         "production app files/links/BUILD_ID changed")

    started = commands["c-start"]
    need(started["returncode"] == 1 and started["observation_expired"] is False,
         "start must finish failed, not be caller timeout/success")
    need(raw(run, commands, "c-start") == b"", "failed start must not claim running stdout")
    stderr = raw(run, commands, "c-start", "stderr").decode("utf-8", "strict")
    start_event = f"center-start-request project={project} container={cid} image={qa_id}"
    expiry_event = f"startup-observation-expired project={project} container={cid}"
    term_event = f"term-request container={cid}"
    need(stderr.count(start_event) == stderr.count(expiry_event) ==
         stderr.count(term_event) == 1 and
         stderr.index(start_event) < stderr.index(expiry_event) < stderr.index(term_event)
         and "startup-process-failed" not in stderr,
         "wrong startup-expiry/normal-stop diagnostic sequence")
    stops = []
    for line in stderr.splitlines():
        if line.startswith("{"):
            stops.append(json.loads(line))
    need(stops == [{"state": "stopped", "containerId": cid,
                    "exitCode": 0, "clean": True}],
         "stderr lacks one confirmed same-ID application exit0")
    container = one_inspect(run, commands, "c-inspect-after-start", cid)
    state = container["State"]
    need(container["Image"] == qa_id
         and container["Config"]["Labels"]["ai.nemori.omne.project"] == project
         and container["Config"]["Labels"]["ai.nemori.omne.host-build-id"] == build
         and container["HostConfig"]["RestartPolicy"]["Name"] == "unless-stopped"
         and container["Config"]["StopSignal"] == "SIGTERM"
         and container["Config"]["StopTimeout"] == -1,
         "created QA center identity/normal-stop policy")
    need(state["Status"] == "exited" and state["Running"] is False
         and state["ExitCode"] == 0 and state["Restarting"] is False
         and container["RestartCount"] == 0 and state["StartedAt"] !=
         "0001-01-01T00:00:00Z" and state["FinishedAt"] !=
         "0001-01-01T00:00:00Z", "actual same-ID exit0 not established")
    health = state["Health"]
    need(health["Status"] != "healthy" and any(
         x["ExitCode"] == -1 and isinstance(x["Output"], str) and x["Output"]
         for x in health["Log"]), "read-only health process timeout not observed")
    status = one_json(raw(run, commands, "c-status-after-start"), "c-status-after-start")
    success(commands, "c-status-after-start")
    need(status["state"] == "exited" and status["containerId"] == cid
         and status["imageId"] == qa_id and status["buildId"] == build
         and status["exitCode"] == 0 and status["restartCount"] == 0,
         "helper status concealed actual stopped image/BUILD/ID")
    success(commands, "c-project-list")
    need(raw(run, commands, "c-project-list") == (cid + "\n").encode(),
         "failed start deleted/replaced/restarted center")
    success(commands, "c-events")
    events = [json.loads(line) for line in raw(run, commands, "c-events").splitlines()]
    need(events and all(x.get("Actor", {}).get("ID") == cid for x in events),
         "private Engine events missing/wrong ID")
    actions = [x.get("Action", x.get("status")) for x in events]
    kills = [x for x in events if x.get("Action", x.get("status")) == "kill"]
    need(actions.count("start") == actions.count("kill") == actions.count("die") == 1
         and len(kills) == 1
         and kills[0].get("Actor", {}).get("Attributes", {}).get("signal") in ("15", "SIGTERM")
         and actions.index("start") < actions.index("kill") < actions.index("die")
         and not any(x in ("restart", "unpause") for x in actions),
         "Engine did not observe exactly one normal TERM and exit")
    root = stat_line(run, commands, "c-state-root-stat")
    data = stat_line(run, commands, "c-state-data-stat")
    need(root == stat_line(run, commands, "c-state-root-before")
         and data == stat_line(run, commands, "c-state-data-before"),
         "startup failure changed/deleted state directory objects")
    uid, gid = expected["uid"], expected["gid"]
    need(root.startswith(f"directory:{uid}:{gid}:700:")
         and data.startswith(f"directory:{uid}:{gid}:700:"),
         "state root/data not retained private")
    success(commands, "c-state-db-stat")
    db = stat_line(run, commands, "c-state-db-stat")
    kind, owner, group, mode, size, inode = db.split(":")
    need(kind in ("regular file", "regular empty file")
         and (owner, group) == (str(uid), str(gid))
         and re.fullmatch(r"[0-7]{3,4}", mode)
         and int(size) > 0 and int(inode) > 0, "application state file not retained")

    need(evidence["cleanup_complete"] is True and evidence["cleanup_errors"] == [],
         "fixture cleanup incomplete")
    cleanup = {x["label"]: x for x in evidence["cleanup_commands"]}
    need(len(cleanup) == len(evidence["cleanup_commands"]), "duplicate cleanup command")
    for label in ("cleanup-final-list-container", "cleanup-final-list-volume",
                  "cleanup-final-list-network", "cleanup-inner-project-final-list",
                  "cleanup-inner-fixture-final-list", "cleanup-inner-all-final-list"):
        need(cleanup[label]["returncode"] == 0 and
             raw(run, cleanup, label) == b"", label + " resources remain")
    return {"status": "limited_pass", "scenario": "C-startup-observation-expiry",
            "center_id": cid}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=pathlib.Path)
    args = parser.parse_args()
    try:
        print(json.dumps(evaluate(args.run), sort_keys=True))
    except (ValueError, KeyError, TypeError, UnicodeError, OSError, json.JSONDecodeError) as error:
        print(json.dumps({"status": "fail", "reason": str(error)}, sort_keys=True))
        raise SystemExit(1)
