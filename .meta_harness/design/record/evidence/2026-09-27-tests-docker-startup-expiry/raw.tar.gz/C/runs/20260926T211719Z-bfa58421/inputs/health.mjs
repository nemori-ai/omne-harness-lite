import { execFileSync } from 'node:child_process'

export function fullHealthIsReady(text) {
  if (!text.endsWith('\n') || text.slice(0, -1).includes('\n')) return false
  let reply
  try {
    reply = JSON.parse(text)
  } catch {
    return false
  }
  return (
    reply !== null &&
    typeof reply === 'object' &&
    !Array.isArray(reply) &&
    reply.reachable === true &&
    reply.storageReachable === true &&
    reply.clockSane === true &&
    reply.deploymentKeyPresent === true &&
    reply.deploymentKeyComplete === true &&
    reply.defectCount === 0
  )
}

if (process.argv[1] === new URL(import.meta.url).pathname) {
  try {
    const result = execFileSync(
      process.execPath,
      ['/opt/omne/app/dist/cli.js', 'ops', '--socket-dir', '/run/omne-tenancy', 'full-health'],
      {
        encoding: 'utf8',
        timeout: 5_000,
        killSignal: 'SIGKILL',
        maxBuffer: 65_536,
        stdio: ['ignore', 'pipe', 'ignore'],
      },
    )
    if (!fullHealthIsReady(result)) process.exitCode = 1
  } catch {
    process.exitCode = 1
  }
}
