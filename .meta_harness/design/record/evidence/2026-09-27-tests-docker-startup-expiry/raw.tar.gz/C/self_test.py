#!/usr/bin/env python3
"""Offline mutation checks for the C raw-evidence oracle; no Docker calls."""

import json
import pathlib
import subprocess
import tempfile

import oracle

CID = "a" * 64
BASE = "sha256:" + "b" * 64
OUTER = "sha256:" + "c" * 64
QA = "sha256:" + "d" * 64
BUILD = "e" * 64
PROJECT = "r5static"
CONTROL = "static-control"
SOCKET = "unix:///opt/omne-private-docker/docker.sock"
STATE = "/var/lib/omne-tenancy/state"
INVENTORY = [{"path": ".", "kind": "directory", "mode": 493},
             {"path": "BUILD_ID", "kind": "file", "mode": 420, "size": 65,
              "sha256": "f" * 64}]


def encoded(value):
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def image(identity, qa=False):
    return {"Id": identity, "RootFS": {"Layers": ["sha256:" + "1" * 64]},
            "Os": "linux", "Architecture": "arm64", "Config": {
                "Labels": {"ai.nemori.omne.host-build-id": BUILD,
                           "ai.nemori.omne.distribution": "tenancy-host-docker/1"},
                "Healthcheck": {"Test": ["CMD", "node",
                                         "/opt/omne/app/deploy/docker/health.mjs"]},
                "User": "10001:10001", "Entrypoint": ["node", "/opt/omne/app/dist/cli.js"],
                "Cmd": ["serve"], "WorkingDir": "/opt/omne/app",
                "Env": (["PATH=/usr/bin", "NODE_OPTIONS=--import=/probe/qa-health-delay.mjs"]
                        if qa else ["PATH=/usr/bin"])}}


def fixture_run(root):
    run = root / "run"
    (run / "raw").mkdir(parents=True)
    records = []
    cleanup = []

    def add(label, output=b"", *, error=b"", code=0, argv=None, cleaned=False):
        (run / "raw" / (label + ".stdout")).write_bytes(output)
        (run / "raw" / (label + ".stderr")).write_bytes(error)
        entry = {"label": label, "stdout": "raw/" + label + ".stdout",
                 "stderr": "raw/" + label + ".stderr", "returncode": code,
                 "observation_expired": False, "argv": argv or []}
        (cleanup if cleaned else records).append(entry)

    base_helper = ["docker", "exec", "-e", "DOCKER_HOST=" + SOCKET, CONTROL,
                   "/usr/local/libexec/omne-center"]
    deployment = ["--project", PROJECT, "--image", QA, "--state-dir", STATE,
                  "--uid", "10023", "--gid", "10024", "--startup-wait", "12",
                  "--observation-interval", "1", "--health-interval", "1s",
                  "--health-timeout", "2s", "--health-start-period", "1s",
                  "--health-retries", "1"]
    add("c-validate", encoded({"state": "deployment-structure-valid"}),
        argv=base_helper + ["validate", *deployment])
    stderr = (f"omne-center: center-start-request project={PROJECT} container={CID} image={QA}\n"
              f"omne-center: startup-observation-expired project={PROJECT} container={CID}\n"
              f"omne-center: term-request container={CID}\n").encode() + encoded(
                  {"state": "stopped", "containerId": CID, "exitCode": 0, "clean": True})
    add("c-start", error=stderr, code=1, argv=base_helper + ["start", *deployment])
    add("c-status-after-start", encoded({"state": "exited", "containerId": CID,
                                         "imageId": QA, "buildId": BUILD,
                                         "exitCode": 0, "restartCount": 0}),
        argv=base_helper + ["status", "--project", PROJECT])
    add("c-build-qa-image", argv=["docker", "exec", CONTROL, "env", "DOCKER_BUILDKIT=0",
                                   "docker", "--host", SOCKET, "build", "--pull=false",
                                   "--network=none", "--build-arg", "BASE_IMAGE=" + BASE])
    add("outer-product-image", encoded([image(OUTER)]))
    add("c-base-image-inspect", encoded([image(BASE)]))
    add("c-qa-image-inspect", encoded([image(QA, qa=True)]))
    add("c-base-app-inventory", encoded(INVENTORY))
    add("c-qa-app-inventory", encoded(INVENTORY))
    add("c-probe-inventory", encoded({"file": True, "uid": 0, "gid": 0,
                                      "mode": 292, "sha256": "2" * 64}))
    container = {"Id": CID, "Image": QA, "Config": {
        "Labels": {"ai.nemori.omne.project": PROJECT,
                   "ai.nemori.omne.host-build-id": BUILD}, "StopSignal": "SIGTERM",
                   "StopTimeout": -1},
        "HostConfig": {"RestartPolicy": {"Name": "unless-stopped"}},
        "RestartCount": 0, "State": {"Status": "exited", "Running": False,
        "Restarting": False, "ExitCode": 0, "StartedAt": "2026-09-27T00:00:00Z",
        "FinishedAt": "2026-09-27T00:00:12Z", "Health": {"Status": "unhealthy",
        "Log": [{"ExitCode": -1, "Output": "Health check exceeded timeout (2s)"}]}}}
    add("c-inspect-after-start", encoded([container]))
    add("c-project-list", (CID + "\n").encode())
    events = [{"Action": action, "Actor": {"ID": CID,
               "Attributes": {"signal": "15"} if action == "kill" else {}}}
              for action in ("start", "kill", "die")]
    add("c-events", b"".join(encoded(x) for x in events))
    for label, value in (("c-state-root-before", "directory:10023:10024:700:12\n"),
                         ("c-state-data-before", "directory:10023:10024:700:13\n"),
                         ("c-state-root-stat", "directory:10023:10024:700:12\n"),
                         ("c-state-data-stat", "directory:10023:10024:700:13\n"),
                         ("c-state-db-stat", "regular file:10023:10024:644:4096:14\n")):
        add(label, value.encode())
    for label in ("cleanup-final-list-container", "cleanup-final-list-volume",
                  "cleanup-final-list-network", "cleanup-inner-project-final-list",
                  "cleanup-inner-fixture-final-list", "cleanup-inner-all-final-list"):
        add(label, cleaned=True)
    evidence = {"scenario": "C-startup-observation-expiry",
                "status": "observed-awaiting-oracle", "business_complete": True,
                "cleanup_complete": True, "cleanup_errors": [], "commands": records,
                "cleanup_commands": cleanup,
                "inputs": {"scenario": "C-startup-observation-expiry", "image_id": OUTER,
                           "build_id": BUILD, "startup_wait": 12, "observation_interval": 1,
                           "sha256": {"qa-context/qa-health-delay.mjs": "2" * 64},
                           "health_interval": "1s", "health_timeout": "2s",
                           "health_start_period": "1s", "health_retries": 1},
                "expected": {"center_id": CID, "qa_image_id": QA, "base_image_id": BASE,
                             "inner_image_id": BASE, "image_id": OUTER, "build_id": BUILD,
                             "project": PROJECT, "control": CONTROL, "state": STATE,
                             "uid": 10023, "gid": 10024, "app_inventory_entries": 2}}
    (run / "evidence.json").write_text(json.dumps(evidence))
    return run


def mutate_evidence(run, fn):
    path = run / "evidence.json"
    value = json.loads(path.read_text())
    fn(value)
    path.write_text(json.dumps(value))


def mutate_json(run, label, fn, *, stream="stdout"):
    path = run / "raw" / (label + "." + stream)
    value = json.loads(path.read_bytes())
    fn(value)
    path.write_bytes(encoded(value))


def cases():
    def empty_exit(run):
        mutate_evidence(run, lambda e: next(x for x in e["commands"]
                        if x["label"] == "c-start").update(returncode=None))

    def fake_success(run):
        mutate_evidence(run, lambda e: next(x for x in e["commands"]
                        if x["label"] == "c-start").update(returncode=0))

    def wrong_id(run):
        mutate_json(run, "c-inspect-after-start", lambda x: x[0].update(Id="9" * 64))

    def wrong_build(run):
        mutate_json(run, "c-status-after-start", lambda x: x.update(buildId="9" * 64))

    def healthy(run):
        mutate_json(run, "c-inspect-after-start",
                    lambda x: x[0]["State"]["Health"].update(Status="healthy"))

    def no_timeout(run):
        mutate_json(run, "c-inspect-after-start",
                    lambda x: x[0]["State"]["Health"].update(Log=[]))

    def no_term(run):
        path = run / "raw/c-start.stderr"
        path.write_bytes(path.read_bytes().replace(
            f"omne-center: term-request container={CID}\n".encode(), b""))

    def double_term(run):
        path = run / "raw/c-events.stdout"
        lines = path.read_bytes().splitlines(keepends=True)
        path.write_bytes(b"".join([lines[0], lines[1], lines[1], lines[2]]))

    def kill_instead(run):
        path = run / "raw/c-events.stdout"
        lines = path.read_bytes().splitlines(keepends=True)
        value = json.loads(lines[1])
        value["Actor"]["Attributes"]["signal"] = "9"
        path.write_bytes(lines[0] + encoded(value) + lines[2])

    def wrong_actual_exit(run):
        mutate_json(run, "c-inspect-after-start",
                    lambda x: x[0]["State"].update(ExitCode=137))

    def restarted(run):
        mutate_json(run, "c-inspect-after-start", lambda x: x[0].update(RestartCount=1))

    def altered_app(run):
        mutate_json(run, "c-qa-app-inventory", lambda x: x[1].update(sha256="9" * 64))

    def extra_env(run):
        mutate_json(run, "c-qa-image-inspect",
                    lambda x: x[0]["Config"]["Env"].append("UNEXPECTED=1"))

    def changed_entrypoint(run):
        mutate_json(run, "c-qa-image-inspect",
                    lambda x: x[0]["Config"].update(Entrypoint=["/bin/sh"]))

    def wrong_probe(run):
        mutate_json(run, "c-probe-inventory", lambda x: x.update(mode=420))

    def wrong_state_inode(run):
        (run / "raw/c-state-data-stat.stdout").write_bytes(
            b"directory:10023:10024:700:999\n")

    def no_db(run):
        (run / "raw/c-state-db-stat.stdout").write_bytes(b"")

    def stale_cleanup(run):
        (run / "raw/cleanup-final-list-container.stdout").write_bytes((CID + "\n").encode())

    return locals()


def main():
    with tempfile.TemporaryDirectory(prefix="omne-c-oracle-offline-") as temp:
        root = pathlib.Path(temp)
        positive = fixture_run(root / "positive")
        assert oracle.evaluate(positive)["status"] == "limited_pass"
        negative = {k: v for k, v in cases().items() if callable(v)}
        for name, change in negative.items():
            run = fixture_run(root / name)
            change(run)
            try:
                oracle.evaluate(run)
            except (ValueError, KeyError, TypeError, UnicodeError, OSError, json.JSONDecodeError):
                continue
            raise AssertionError(name + " false pass")
        preload = pathlib.Path(__file__).resolve().parent / "qa-context/qa-health-delay.mjs"
        ordinary = subprocess.run(["node", "--import=" + str(preload), "-e",
                                   "process.stdout.write('ordinary\\n')"],
                                  capture_output=True, timeout=5)
        assert ordinary.returncode == 0 and ordinary.stdout == b"ordinary\n"
        health = subprocess.Popen(["node", "--import=" + str(preload),
                                   "/opt/omne/app/deploy/docker/health.mjs"],
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            try:
                health.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                pass
            else:
                raise AssertionError("QA health process did not remain active")
        finally:
            health.kill()
            health.communicate(timeout=5)
        print(json.dumps({"positive": 1, "negative": len(negative),
                          "preload_branches": 2, "result": "pass"},
                         sort_keys=True))


if __name__ == "__main__":
    main()
