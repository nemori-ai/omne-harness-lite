from pathlib import Path
import json,subprocess,hashlib
r=Path.cwd();t=r/'tmp/production-cli-onboarding';source=Path(json.loads((t/'maintenance-package-clean-location-r1.json').read_text())['source']);p=source/'apps/tenancy-host/deploy/README.md';before=p.read_bytes();after=(r/'apps/tenancy-host/deploy/README.md').read_bytes()
report={'scope':'same independent build location and frozen implementation inputs; only deploy README differs; original source README restored afterward','source':str(source),'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(after).hexdigest()}
try:
 p.write_bytes(after)
 with (t/'maintenance-package-host-r3.log').open('w') as log:
  subprocess.run(['fnm','exec','--using','24','bash','scripts/package-tenancy-host.sh',str(t/'omne-host-d056-r3.tar.gz')],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
finally:
 p.write_bytes(before);assert hashlib.sha256(p.read_bytes()).hexdigest()==report['before']
 (t/'maintenance-package-doc-r3.json').write_text(json.dumps(report,indent=2)+'\n')
