import assert from 'node:assert/strict'
import {spawn} from 'node:child_process'
import {mkdtemp,mkdir,readFile,writeFile,chmod,cp,symlink,readdir,rm,stat} from 'node:fs/promises'
import {join,resolve} from 'node:path'
import {createHash} from 'node:crypto'
import {connect} from 'node:net'
process.env.OMNE_CROSS_HOST='/private/tmp/omne-host-d056-r3-xjc82oz2/app'
const {makeCa,makeServerCertificate,keygen,freePort,opsDirectory,envOf,SETTINGS,CenterProcess}=await import('../maintenance-probe/deploy.ts')
const host=process.env.OMNE_CROSS_HOST, cli='/private/tmp/omne-cli-d056-pm0ryito/app'
const evidence=resolve(process.argv[2]??'tmp/production-cli-onboarding/maintenance-independent-qa-r3/run-1')
await mkdir(evidence,{recursive:true})
const root=await mkdtemp('/private/tmp/omne-maint-qa-'), commands=[],checks=[],children=[],notes=[]
let count=0,failed=false
const sha=b=>createHash('sha256').update(b).digest('hex')
const save=(name,value)=>writeFile(join(evidence,name),typeof value==='string'?value:JSON.stringify(value,null,2)+'\n')
function start(app,args,env={}){const child=spawn(process.execPath,[join(app,'dist',app===host?'cli.js':'main.js'),...args],{env:{PATH:process.env.PATH,...env},stdio:['ignore','pipe','pipe']});let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);const result=new Promise((done,reject)=>{child.on('error',reject);child.on('close',(code,signal)=>done({code,signal,stdout,stderr}))});return {child,result}}
async function run(label,app,args,env={}){const x=start(app,args,env),timer=setTimeout(()=>x.child.kill('SIGKILL'),45000);const result=await x.result;clearTimeout(timer);await save(`${String(count++).padStart(3,'0')}-${label}.json`,{args,envNames:Object.keys(env),...result});commands.push({label,...result});return result}
const data=r=>JSON.parse(r.stdout)
async function expect(label,app,args,code,status,env={}){const r=await run(label,app,args,env);assert.equal(r.signal,null);assert.equal(r.code,code,JSON.stringify(r));const v=data(r);if(status)assert.equal(v.status,status,JSON.stringify(v));checks.push({label,status:'PASS',exit:r.code,result:v});return v}
async function center(label){const dir=join(root,label);await mkdir(dir,{mode:0o700});const log=x=>notes.push(x),ca=makeCa(dir,'ca',log),tls=makeServerCertificate(dir,'leaf',ca,['DNS:localhost','IP:127.0.0.1'],log),port=await freePort(),ops=opsDirectory(dir);const env=envOf({dbFile:join(dir,'center.sqlite'),keys:await keygen(join(dir,'keys'),log),tls,host:'127.0.0.1',port,opsDir:ops,settings:SETTINGS});const process=CenterProcess.serve(label,env,log);children.push(process);await process.ready(join(ops,'governance-center-ops.sock'));return{dir,ops,env,process,ca,port,backup:join(dir,'center.sqlite.backups')}}
const ops=(c,verb,...args)=>['ops','--socket-dir',c.ops,verb,...args]
const verify=(source,work)=>['verify','--source',source,'--work-dir',work]
const restore=(source,target,work)=>['restore-isolated','--source',source,'--target',target,'--work-dir',work]
async function employee(label,c,cmd,args=[]){const r=await run(label,cli,['machine',...cmd,'--state-dir',join(root,'employee'),...args]);assert.equal(r.code,0,JSON.stringify(r));const v=data(r);assert.equal(v.remote.status,'success',JSON.stringify(v));checks.push({label,status:'PASS',exit:r.code});return v}
try{
  assert.equal(process.version,'v24.21.0')
  for(const [path,hash]of [['tmp/production-cli-onboarding/omne-host-d056-r3.tar.gz','94e39d788f790db5f17d83bfdc1409d70d4376581862cbbe8a6a4ed635c9f181'],['tmp/production-cli-onboarding/omne-cli-d056-r1.tar.gz','803a4f5c7234ab7a0c0169e2c5dd4c66da669d0fc71ca633568999b739db618a']])assert.equal(sha(await readFile(path)),hash)
  await save('environment.json',{root,host,cli,platform:process.platform,arch:process.arch,node:process.version,hostBuild:(await readFile(join(host,'BUILD_ID'),'utf8')).trim(),cliBuild:(await readFile(join(cli,'BUILD_ID'),'utf8')).trim()})
  const a=await center('primary')
  const missing=await expect('initial-missing',host,ops(a,'backup-status'),2,'observed');assert.equal(missing.health,'missing');assert.equal(missing.latest,null)
  await employee('employee-configure',a,['center','configure'],['--endpoint',`https://localhost:${a.port}/`,'--ca-file',a.ca.certFile])
  const cred=join(root,'credential');await writeFile(cred,'qa-synthetic-credential-12345',{mode:0o600})
  await employee('employee-register',a,['register'],['--login-identifier','qaemployee','--credential-file',cred])
  await employee('employee-login',a,['login'],['--login-identifier','qaemployee','--credential-file',cred])
  const before=await employee('employee-identity-before',a,['tenant','current'],['--refresh'])
  const backup=await expect('online-backup',host,ops(a,'backup','--only-if-due'),0,'completed'),source=join(a.backup,backup.backup.fileName),original=await readFile(source)
  assert.equal(backup.backup.metadata.sourceBuildId,(await readFile(join(host,'BUILD_ID'),'utf8')).trim())
  const current=await expect('status-current',host,ops(a,'backup-status'),0,'observed');assert.equal(current.health,'current');assert.deepEqual(current.latest,backup.backup)
  const due=await expect('backup-not-due',host,ops(a,'backup','--only-if-due'),0,'not-due');assert.deepEqual(due.backup,backup.backup)
  const after=await employee('employee-identity-after',a,['tenant','current'],['--refresh']);assert.deepEqual(after.remote.reply,before.remote.reply)
  const work=join(root,'verify-work'),target=join(root,'restored')
  const verified=await expect('offline-verify-no-env',host,verify(source,work),0,'verified');assert.equal(verified.businessOpen,false);assert.deepEqual(verified.metadata,backup.backup.metadata)
  const restored=await expect('offline-restore-no-env',host,restore(source,target,join(root,'restore-work')),0,'restored-isolated');assert.equal(restored.businessOpen,false);assert.equal(restored.targetLocation,target);assert.equal(sha(await readFile(join(target,'data.omne-backup'))),sha(original))
  await expect('verify-restored-envelope',host,verify(join(target,'data.omne-backup'),work),0,'verified')
  await expect('restore-existing-target',host,restore(source,target,join(root,'restore-work')),2,'target-exists')
  const empty=join(root,'empty-target');await mkdir(empty,{mode:0o700});await expect('restore-existing-empty-target',host,restore(source,empty,join(root,'restore-work')),2,'target-exists');assert.deepEqual(await readdir(empty),[])
  const rejectedServe=await run('serve-restored-envelope-refused',host,['serve'],{...a.env,OMNE_TENANCY_STORAGE_FILE:join(target,'data.omne-backup'),OMNE_TENANCY_OPS_SOCKET_DIR:opsDirectory(root),OMNE_TENANCY_ENTRY_LISTEN:`127.0.0.1:${await freePort()}`});assert.equal(rejectedServe.code,1);assert.ok(!rejectedServe.stderr.includes('"event":"serving"'));assert.equal(sha(await readFile(join(target,'data.omne-backup'))),sha(original));checks.push({label:'serve-restored-envelope-refused',status:'PASS',exit:1})
  assert.equal(await readFile(join(work,'.omne-isolated'),'utf8'),'omne-isolated/1\n');assert.equal((await stat(work)).mode&0o777,0o700)
  const bad=join(root,'bad.omne-backup');const mutated=Buffer.from(original);mutated[mutated.length-1]^=1;await writeFile(bad,mutated,{mode:0o600});await expect('corrupted-payload-refused',host,verify(bad,work),2,'invalid-backup')
  const truncated=join(root,'truncated.omne-backup');await writeFile(truncated,original.subarray(0,original.length-1),{mode:0o600});await expect('truncated-envelope-refused',host,verify(truncated,work),2,'invalid-backup')
  const trailing=join(root,'trailing.omne-backup');await writeFile(trailing,Buffer.concat([original,Buffer.from('x')]),{mode:0o600});await expect('trailing-byte-refused',host,verify(trailing,work),2,'invalid-backup')
  const link=join(root,'linked.omne-backup');await symlink(source,link);await expect('source-symlink-refused',host,verify(link,work),1,'unavailable')
  await expect('source-missing-unavailable',host,verify(join(root,'missing'),work),1,'unavailable')
  const broad=join(root,'wide-work');await mkdir(broad,{mode:0o755});await chmod(broad,0o755);await expect('wide-work-root-refused',host,verify(source,broad),1,'unavailable')
  for(const [label,args]of [['relative-source',verify('relative',work)],['relative-work',verify(source,'relative')],['extra-argument',[...verify(source,work),'extra']],['duplicate-flag',[...verify(source,work),'--source',source]],['ops-relative',['ops','--socket-dir','relative','backup']],['unknown-operation',['ops','--socket-dir',a.ops,'verify']]]){const r=await run(label,host,args);assert.equal(r.code,64,JSON.stringify(r));checks.push({label,status:'PASS',exit:r.code})}
  const invalidNames=['1'.repeat(32)+'.omne-backup','2'.repeat(32)+'.omne-backup','3'.repeat(32)+'.omne-backup'];await writeFile(join(a.backup,invalidNames[0]),'bad',{mode:0o600});await mkdir(join(a.backup,invalidNames[1]),{mode:0o700});await symlink(source,join(a.backup,invalidNames[2]));await writeFile(join(a.backup,'ignored-name'),'bad')
  const invalidCatalog=await expect('catalog-types-and-corruption',host,ops(a,'backup-status'),0,'observed');assert.equal(invalidCatalog.invalidCount,3);assert.deepEqual(invalidCatalog.latest,backup.backup)
  const b=await center('foreign'), foreign=await expect('foreign-center-backup',host,ops(b,'backup'),0,'completed');const foreignFile=join(a.backup,'4'.repeat(32)+'.omne-backup');await cp(join(b.backup,foreign.backup.fileName),foreignFile);await chmod(foreignFile,0o600)
  const foreignStatus=await expect('catalog-valid-foreign-filtered',host,ops(a,'backup-status'),0,'observed');assert.equal(foreignStatus.invalidCount,4);assert.deepEqual(foreignStatus.latest,backup.backup)
  // Header timestamps are integrity metadata, not an authentication claim. Foreign payload remains a real second center snapshot.
  const rewrite=(buf,changes)=>{const magic=Buffer.from('OMNE-CENTER-BACKUP/1\n'),len=buf.readUInt32BE(magic.length),metadata=JSON.parse(buf.subarray(magic.length+4,magic.length+4+len));Object.assign(metadata,changes);const h=Buffer.from(JSON.stringify(metadata)),n=Buffer.alloc(4);n.writeUInt32BE(h.length);return Buffer.concat([magic,n,h,buf.subarray(magic.length+4+len)])}
  await writeFile(foreignFile,rewrite(await readFile(foreignFile),{startedAt:'2099-01-01T00:00:00Z',finishedAt:'2099-01-01T00:00:01Z'}),{mode:0o600})
  const futureForeign=await expect('catalog-foreign-future-filtered',host,ops(a,'backup-status'),0,'observed');assert.equal(futureForeign.invalidCount,4);assert.equal(futureForeign.health,'current')
  await writeFile(source,rewrite(original,{startedAt:'2099-01-01T00:00:00Z',finishedAt:'2099-01-01T00:00:01Z'}));await expect('own-future-unavailable',host,ops(a,'backup-status'),1,'unavailable');await writeFile(source,original)
  // Reusing work roots after declared failures must succeed without removal of the marker.
  await expect('work-reusable-after-failures',host,verify(source,work),0,'verified');assert.equal(sha(await readFile(source)),sha(original))
  for(const n of invalidNames)await rm(join(a.backup,n),{recursive:true,force:true});await rm(foreignFile);await rm(join(a.backup,'ignored-name'))
  await employee('employee-login-still-valid',a,['tenant','current'],['--refresh'])
  assert.equal((await a.process.terminate()).code,0);assert.equal((await b.process.terminate()).code,0)
  await expect('offline-after-center-stopped',host,verify(source,work),0,'verified')
  const stopped=await run('ops-stopped-center-unavailable',host,ops(a,'backup-status'));assert.equal(stopped.code,1);assert.equal(stopped.stdout,'');checks.push({label:'ops-stopped-center-unavailable',status:'PASS',exit:1})
  // Independent processes inspect one source concurrently, using separate work roots.
  const parallel=await Promise.all([expect('different-work-root-parallel-a',host,verify(source,join(root,'parallel-a')),0,'verified'),expect('different-work-root-parallel-b',host,verify(source,join(root,'parallel-b')),0,'verified')]);assert.equal(parallel.length,2)
  await save('result.json',{verdict:'Pass',checks,issues:[],uncovered:['Same-work-root concurrent process busy with deterministic gate','In-flight source replacement/mutation','Injected fsync failure/unknown persistence','All production opening paths and plaintext crash remnants','Linux/systemd/cross-OS/performance tested by separate mainline runs, not this QA','TUI unchanged D054 limited profile not repeated'],count:checks.length})
}catch(error){failed=true;await save('failure.txt',error.stack??String(error));throw error}
finally{for(const c of children){if(c.running)await c.terminate().catch(()=>c.kill());await save(`center-${c.label}.json`,{stdout:c.stdout(),stderr:c.stderr()})}await save('commands.json',commands);await save('checks.json',checks);await save('fixture-notes.json',notes);await save('fixture-location.txt',root+'\n');console.log(JSON.stringify({evidence,root,checks:checks.length,failed}));}
