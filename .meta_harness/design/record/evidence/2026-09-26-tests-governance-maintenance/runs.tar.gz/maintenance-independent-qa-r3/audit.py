import pathlib,json,hashlib,os,re,difflib
base=pathlib.Path('tmp/production-cli-onboarding/maintenance-independent-qa-r3')
old=pathlib.Path('/private/tmp/omne-host-d056-8zw0qh51/app');new=pathlib.Path('/private/tmp/omne-host-d056-r3-xjc82oz2/app')
sha=lambda b:hashlib.sha256(b).hexdigest()
archive=pathlib.Path('tmp/production-cli-onboarding/omne-host-d056-r3.tar.gz')
assert sha(archive.read_bytes())=='94e39d788f790db5f17d83bfdc1409d70d4376581862cbbe8a6a4ed635c9f181'
manifests=[]
for root in [old,new]:
 m=json.loads((root/'build-info.json').read_text());assert (root/'BUILD_ID').read_text().strip()==m['buildId'];entries={x['path']:x for x in m['files']}
 actual=set()
 for parent,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   p=pathlib.Path(parent)/name
   if p.is_symlink() or p.is_file():actual.add(str(p.relative_to(root)))
 assert actual==set(entries)|{'build-info.json','BUILD_ID'},(actual-set(entries),set(entries)-actual)
 for rel,x in entries.items():
  p=root/rel
  if x['kind']=='file':assert p.is_file() and not p.is_symlink();assert sha(p.read_bytes())==x['sha256'],rel
  elif x['kind']=='link':assert p.is_symlink();assert os.readlink(p)==x['target'],rel
  else:raise Exception(x)
 manifests.append((m,entries))
a,b=manifests[0][1],manifests[1][1];assert set(a)==set(b)
changes=[];diffs=[]
for p in sorted(a):
 assert a[p]['kind']==b[p]['kind']
 if a[p]==b[p]:continue
 assert a[p]['kind']=='file',p
 x=(old/p).read_text();y=(new/p).read_text();classification=None
 if p=='deploy/README.md':
  assert x.replace('whose parent already exists.','whose parent already exists, is owned by the same user and has mode `0700`.')==y
  classification='work parent owner/mode documentation'
 elif '/.bin/' in p:
  assert x.replace('.omne-host-package-0xwpcu/','.omne-host-package-glo6Rs/')==y
  for u,v in zip(x.splitlines(),y.splitlines()):
   if u!=v:assert u.startswith('  export NODE_PATH=') and v.startswith('  export NODE_PATH=')
  classification='pnpm NODE_PATH staging directory only'
 elif p=='node_modules/.modules.yaml':
  assert re.sub(r'^prunedAt: .*$', 'prunedAt: <timestamp>',x,flags=re.M)==re.sub(r'^prunedAt: .*$', 'prunedAt: <timestamp>',y,flags=re.M)
  classification='pnpm prunedAt only'
 elif p=='node_modules/.pnpm-workspace-state-v1.json':
  j,k=json.loads(x),json.loads(y);assert isinstance(j.pop('lastValidatedTimestamp'),int);assert isinstance(k.pop('lastValidatedTimestamp'),int);assert j==k
  classification='pnpm lastValidatedTimestamp only'
 else:raise Exception('UNEXPECTED DIFFERENCE '+p)
 changes.append({'path':p,'classification':classification})
 diffs.extend(difflib.unified_diff(x.splitlines(True),y.splitlines(True),fromfile='r1/'+p,tofile='r3/'+p))
assert len(changes)==23;assert sum(x['classification'].startswith('pnpm NODE_PATH') for x in changes)==20
assert manifests[1][0]['buildId']=='e8033f3bb8fda92287afe943cce5dab16994c95df0ed932b4bed932c7ca05566'
(base/'inventory-diff.patch').write_text(''.join(diffs))
(base/'audit.json').write_text(json.dumps({'verdict':'PASS','archiveSha256':sha(archive.read_bytes()),'oldBuildId':manifests[0][0]['buildId'],'buildId':manifests[1][0]['buildId'],'inventoryEntries':len(a),'unchangedEntries':len(a)-len(changes),'changedEntries':changes,'runtime':'all JS, declarations, source maps, package manifests, links and service units byte-identical','reproducibleBuildClaim':False},indent=2)+'\n')
