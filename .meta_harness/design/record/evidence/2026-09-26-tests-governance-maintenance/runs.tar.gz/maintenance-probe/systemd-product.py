"""Actual packaged host in isolated Docker systemd; generated test TLS only, no host mounts."""
import subprocess,json,time,pathlib,sys,socket
out=pathlib.Path(sys.argv[1]).resolve();out.mkdir()
archive=pathlib.Path(sys.argv[2]).resolve();name='omne-product-systemd-'+str(int(time.time()))
repo=pathlib.Path.cwd();events=[];client=None
s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
def call(args,check=True,timeout=50):
 r=subprocess.run(args,text=True,capture_output=True,timeout=timeout)
 events.append({'args':args,'code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 if check and r.returncode:raise RuntimeError(str(args)+' failed: '+r.stderr+' '+r.stdout)
 return r.stdout.strip()
def ex(*args,**kw):return call(['docker','exec',name,*args],**kw)
def put(path,text):
 r=subprocess.run(['docker','exec','-i',name,'sh','-c','cat > "$1"','sh',path],input=text,text=True,capture_output=True)
 assert r.returncode==0,r.stderr
 (out/pathlib.Path(path).name).write_text(text)
def cmd(*args,check=True):return call(['docker','exec','--user','omne',name,'node','/opt/omne/current/app/dist/cli.js',*args],check=check)
def poll(fn,timeout=45):
 start=time.monotonic()
 while not fn():
  if time.monotonic()-start>timeout:raise RuntimeError('poll timeout')
  time.sleep(.15)
try:
 call(['fnm','exec','--using','24','node','tmp/production-cli-onboarding/maintenance-probe/systemd-fixture.mjs',str(out/'tls')])
 call(['docker','run','--rm','-d','--name',name,'--privileged','--cgroupns=private','--tmpfs','/run','--tmpfs','/run/lock','--tmpfs','/tmp','-p',f'127.0.0.1:{port}:8443','omne-maintenance-systemd-probe:20260925'])
 poll(lambda:ex('systemctl','is-system-running',check=False) in ['running','degraded'])
 ex('useradd','--system','--home-dir','/var/lib/omne-tenancy','--shell','/usr/sbin/nologin','omne')
 ex('mkdir','-p','/var/lib/omne-tenancy','/etc/omne-tenancy','/opt/omne/releases/r1','/opt/probe')
 ex('chmod','0700','/var/lib/omne-tenancy','/etc/omne-tenancy')
 call(['docker','cp',str(archive),name+':/opt/omne/release.tar.gz'])
 ex('tar','-xzf','/opt/omne/release.tar.gz','-C','/opt/omne/releases/r1')
 ex('ln','-s','/opt/omne/releases/r1','/opt/omne/current')
 call(['docker','cp',str(out/'tls')+'/.',name+':/etc/omne-tenancy'])
 ex('chown','-R','omne:omne','/var/lib/omne-tenancy','/etc/omne-tenancy')
 keys=json.loads(cmd('keygen','/var/lib/omne-tenancy/keys'))['files']
 env={**keys,'OMNE_TENANCY_STORAGE_FILE':'/var/lib/omne-tenancy/center.sqlite','OMNE_TENANCY_ENTRY_LISTEN':'0.0.0.0:8443','OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE':'/etc/omne-tenancy/leaf.chain.pem','OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE':'/etc/omne-tenancy/leaf.key','OMNE_TENANCY_OPS_SOCKET_DIR':'/run/omne-tenancy','OMNE_TENANCY_UNACTIVATED_RETENTION':'P7D','OMNE_TENANCY_INVITATION_TTL_DEFAULT':'P14D','OMNE_TENANCY_AFFILIATION_REQUEST_TTL_DEFAULT':'P14D','OMNE_TENANCY_COPY_NOTICE_TTL_DEFAULT':'P7D','OMNE_TENANCY_SHARING_INVITATION_TTL_DEFAULT':'P7D','OMNE_TENANCY_TEAM_CREATION_KEY_RETENTION':'P1D','OMNE_TENANCY_CLOCK_READY_TIMEOUT':'15000','OMNE_TENANCY_CREDENTIAL_POLICY':'{"minLength":12}'}
 put('/etc/omne-tenancy/center.env',''.join(k+'='+json.dumps(v)+'\n' for k,v in env.items()))
 ex('chmod','0600','/etc/omne-tenancy/center.env');ex('chown','omne:omne','/etc/omne-tenancy/center.env')
 for f in ['omne-tenancy.service','omne-tenancy-backup.service','omne-tenancy-backup.timer']:
  text=(repo/'apps/tenancy-host/deploy'/f).read_text().replace('/opt/node-v24.21.0/bin/node','/usr/local/bin/node').replace('/opt/omne-tenancy/current','/opt/omne/current')
  put('/etc/systemd/system/'+f,text)
 ex('systemd-analyze','verify','/etc/systemd/system/omne-tenancy.service','/etc/systemd/system/omne-tenancy-backup.service','/etc/systemd/system/omne-tenancy-backup.timer')
 ex('systemctl','daemon-reload');ex('systemctl','start','omne-tenancy.service')
 poll(lambda:'"reachable":true' in cmd('ops','--socket-dir','/run/omne-tenancy','full-health',check=False))
 health=json.loads(cmd('ops','--socket-dir','/run/omne-tenancy','full-health'))
 public=call(['curl','--silent','--show-error','--cacert',str(out/'tls/ca.pem'),'-H','Content-Type: application/json','--data','{"operation":"composition.governance-center-entry/v1#S-18"}',f'https://localhost:{port}/'])
 ex('systemctl','start','omne-tenancy-backup.service')
 backupUnit=ex('systemctl','show','omne-tenancy-backup.service','--property=Result,ExecMainStatus')
 assert 'Result=success' in backupUnit and 'ExecMainStatus=0' in backupUnit,backupUnit
 status=json.loads(cmd('ops','--socket-dir','/run/omne-tenancy','backup-status'));assert status['health']=='current',status
 file='/var/lib/omne-tenancy/center.sqlite.backups/'+status['latest']['fileName']
 verified=json.loads(cmd('verify','--source',file,'--work-dir','/var/lib/omne-tenancy/verify-work'));assert verified['status']=='verified' and verified['businessOpen']==False,verified
 restored=json.loads(cmd('restore-isolated','--source',file,'--work-dir','/var/lib/omne-tenancy/restore-work','--target','/var/lib/omne-tenancy/restored'));assert restored['status']=='restored-isolated' and restored['businessOpen']==False,restored
 ex('cmp',file,'/var/lib/omne-tenancy/restored/data.omne-backup')
 # Stop normally, then use an isolated preload to hold a real backup input read across stop.
 ex('systemctl','stop','omne-tenancy.service')
 put('/opt/probe/read-gate.mjs',"""import { promises as fs } from 'node:fs'; import { syncBuiltinESMExports } from 'node:module'; import { setTimeout as delay } from 'node:timers/promises';
const open=fs.open;fs.open=async(...args)=>{const h=await open(...args);if(String(args[0]).endsWith('.omne-backup')){const read=h.read.bind(h);let first=true;h.read=async(...a)=>{if(first){first=false;await fs.writeFile('/var/lib/omne-tenancy/read-entered','ready');while(true){try{await fs.stat('/var/lib/omne-tenancy/release-read');break}catch(e){if(e.code!=='ENOENT')throw e}await delay(50)}}return read(...a)}}return h};syncBuiltinESMExports();
""")
 ex('mkdir','-p','/etc/systemd/system/omne-tenancy.service.d')
 put('/etc/systemd/system/omne-tenancy.service.d/probe.conf','[Service]\nEnvironment=NODE_OPTIONS=--import=/opt/probe/read-gate.mjs\n')
 ex('systemctl','daemon-reload');ex('systemctl','start','omne-tenancy.service')
 poll(lambda:'"reachable":true' in cmd('ops','--socket-dir','/run/omne-tenancy','full-health',check=False))
 client=subprocess.Popen(['docker','exec','--user','omne',name,'node','/opt/omne/current/app/dist/cli.js','ops','--socket-dir','/run/omne-tenancy','backup-status'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 poll(lambda:ex('test','-f','/var/lib/omne-tenancy/read-entered',check=False)=='' and ex('sh','-c','test -f /var/lib/omne-tenancy/read-entered && echo yes',check=False)=='yes')
 started=time.monotonic();ex('systemctl','stop','--no-block','omne-tenancy.service');time.sleep(31)
 mid=ex('systemctl','show','omne-tenancy.service','--property=ActiveState,SubState,MainPID')
 assert 'ActiveState=deactivating' in mid and 'MainPID=0\n' not in mid+'\n',mid
 contender=call(['docker','exec','--user','omne',name,'env',*[k+'='+v for k,v in env.items()],'node','/opt/omne/current/app/dist/cli.js','serve'],check=False)
 contenderEvent=events[-1];assert contenderEvent['code']==1 and '"stage":"occupied"' in contenderEvent['stderr'],contenderEvent
 ex('touch','/var/lib/omne-tenancy/release-read')
 poll(lambda:ex('systemctl','is-active','omne-tenancy.service',check=False)=='inactive')
 duration=time.monotonic()-started
 stdout,stderr=client.communicate(timeout=10);assert client.returncode==1 and 'ops result unconfirmed' in stderr,(stdout,stderr)
 (out/'interrupted-client.json').write_text(json.dumps({'code':client.returncode,'stdout':stdout,'stderr':stderr},indent=2))
 # Same shipped timer, accelerated ONLY by a test drop-in; preserve the production hourly unit.
 ex('mkdir','-p','/etc/systemd/system/omne-tenancy-backup.timer.d')
 put('/etc/systemd/system/omne-tenancy-backup.timer.d/probe.conf','[Timer]\nOnCalendar=\nOnActiveSec=1s\nAccuracySec=100ms\nPersistent=false\n')
 ex('systemctl','daemon-reload');ex('systemctl','start','omne-tenancy-backup.timer');time.sleep(2)
 final=ex('systemctl','show','omne-tenancy.service','--property=ActiveState,MainPID')
 failed=ex('systemctl','show','omne-tenancy-backup.service','--property=Result,ExecMainStatus')
 assert 'ActiveState=inactive' in final and 'MainPID=0' in final,final
 assert 'Result=exit-code' in failed and 'ExecMainStatus=1' in failed,failed
 version=cmd('--version')
 (out/'result.json').write_text(json.dumps({'status':'PASS','artifact':str(archive),'version':version,'health':health,'public':json.loads(public),'backupUnit':backupUnit,'backupStatus':status,'verify':verified,'restore':restored,'stopSeconds':duration,'after31s':mid,'afterTimer':final,'failedBackupUnit':failed,'scope':'actual artifact + systemd252 Linux arm64; private synthetic center; normal backup/verify/restore; actual FileHandle read held by test preload during stop; accelerated timer drop-in does not prove daily cadence, power loss or multi-host disaster recovery'},indent=2)+'\n')
finally:
 ex('journalctl','--no-pager','-u','omne-tenancy.service','-u','omne-tenancy-backup.service',check=False)
 if client and client.poll() is None: client.terminate();client.communicate(timeout=5)
 call(['docker','stop','--time','5',name],check=False,timeout=15)
 (out/'events.json').write_text(json.dumps(events,indent=2)+'\n')
