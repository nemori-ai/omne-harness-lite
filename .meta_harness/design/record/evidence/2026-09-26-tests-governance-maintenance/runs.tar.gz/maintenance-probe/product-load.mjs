import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { connect } from 'node:tls'
import { DatabaseSync } from 'node:sqlite'
import { mkdir,readFile,writeFile,chmod,stat } from 'node:fs/promises'
import { join,resolve } from 'node:path'
import { setTimeout as delay } from 'node:timers/promises'
const app=resolve(process.argv[2]),root=resolve(process.argv[3]),out=resolve(process.argv[4])
await mkdir(root,{recursive:true,mode:0o700});await chmod(root,0o700);await mkdir(out,{recursive:true})
const entry=join(app,'dist/cli.js'),file=join(root,'center.sqlite'),ops=join(root,'ops')
await mkdir(ops,{mode:0o700})
const ca=await readFile(join(root,'ca.pem'),'utf8'),port=18443
const observations=[];let hosts=[],host
function run(args,env={}){const child=spawn(process.execPath,[entry,...args],{env:{...process.env,...env},stdio:['ignore','pipe','pipe']});let stdout='',stderr='';child.stdout.on('data',x=>stdout+=x);child.stderr.on('data',x=>stderr+=x);const done=new Promise((yes,no)=>{child.once('error',no);child.once('close',(code,signal)=>yes({code,signal,stdout,stderr}))});return{child,done,stderr:()=>stderr}}
const keys=JSON.parse((await run(['keygen',join(root,'keys')]).done).stdout).files
const env={...keys,OMNE_TENANCY_STORAGE_FILE:file,OMNE_TENANCY_ENTRY_LISTEN:`127.0.0.1:${port}`,OMNE_TENANCY_ENTRY_TLS_CERT_CHAIN_PEM_FILE:join(root,'leaf.chain.pem'),OMNE_TENANCY_ENTRY_TLS_PRIVATE_KEY_PEM_FILE:join(root,'leaf.key'),OMNE_TENANCY_OPS_SOCKET_DIR:ops,OMNE_TENANCY_UNACTIVATED_RETENTION:'P7D',OMNE_TENANCY_INVITATION_TTL_DEFAULT:'P14D',OMNE_TENANCY_AFFILIATION_REQUEST_TTL_DEFAULT:'P14D',OMNE_TENANCY_COPY_NOTICE_TTL_DEFAULT:'P7D',OMNE_TENANCY_SHARING_INVITATION_TTL_DEFAULT:'P7D',OMNE_TENANCY_TEAM_CREATION_KEY_RETENTION:'P1D',OMNE_TENANCY_CLOCK_READY_TIMEOUT:'15000',OMNE_TENANCY_CREDENTIAL_POLICY:'{"minLength":12}'}
function request(body){return new Promise((yes,no)=>{const s=connect({host:'127.0.0.1',port,servername:'localhost',ca,minVersion:'TLSv1.3',maxVersion:'TLSv1.3'});const parts=[];s.on('error',no);s.setTimeout(5000,()=>s.destroy(Error('request-timeout')));s.on('data',b=>parts.push(b));s.on('secureConnect',()=>{const text=JSON.stringify(body);s.end(`POST / HTTP/1.1\r\nHost: localhost\r\nContent-Length: ${Buffer.byteLength(text)}\r\n\r\n${text}`)});s.on('end',()=>{try{const bytes=Buffer.concat(parts),i=bytes.indexOf('\r\n\r\n');assert.ok(i>0);yes(JSON.parse(bytes.subarray(i+4).toString()))}catch(e){no(e)}})})}
const ai=n=>`capability.account-identity/v3#S-${n}`,og=n=>`capability.organization-governance/v2#S-${n}`
let presentation
const call=(operation,payload={},authenticated=false)=>request({protocolVersion:'2',operation,payload,...(authenticated?{presentedLoginState:presentation}:{})})
async function start(){host=run(['serve'],env);hosts.push(host);for(let i=0;i<100;i++){const p=await run(['ops','--socket-dir',ops,'full-health']).done;if(p.code===0)return JSON.parse(p.stdout);if(host.child.exitCode!==null)throw Error(host.stderr());await delay(100)}throw Error('not-ready')}
async function stop(){host.child.kill('SIGTERM');assert.equal((await host.done).code,0)}
try {
 await start()
 assert.deepEqual(await call('composition.account-registration/v2#S-8',{loginIdentifier:'load-observer',credential:'synthetic-load-password-123'}),{result:'registered'})
 await stop()
 // Synthetic unactivated accounts with real-shaped credential material, current schema and indexes.
 // This is fixture construction while stopped, never a product import or a production workload claim.
 const db=new DatabaseSync(file);let rows=0
 const sample=db.prepare('SELECT credential_material,produced_at,retention_deadline FROM account LIMIT 1').get()
 const insert=db.prepare('INSERT INTO account(account_id,login_identifier,credential_material,activated,produced_at,retention_deadline,expired_at,credential_revision) VALUES(?,?,?,0,?,?,NULL,0)')
 const fixtureStart=performance.now()
 const size=()=>Number(db.prepare('PRAGMA page_count').get().page_count)*Number(db.prepare('PRAGMA page_size').get().page_size)
 while(size()<900*1024*1024){db.exec('BEGIN');for(let i=0;i<50000;i++){const id=(++rows).toString(16).padStart(32,'0');insert.run(id,'load-fixture-'+id,sample.credential_material,sample.produced_at,sample.retention_deadline)}db.exec('COMMIT')}
 db.exec('PRAGMA wal_checkpoint(TRUNCATE)');const bytes=size();db.close()
 console.log(JSON.stringify({stage:'fixture',rows,bytes,ms:performance.now()-fixtureStart}))
 assert.ok(bytes<1024**3)
 const health=await start();const login=await call(ai(15),{loginIdentifier:'load-observer',credential:'synthetic-load-password-123'});assert.ok(login.result?.loginState);presentation=login.result.loginState
 const physical=new DatabaseSync(file,{readOnly:true});const before=physical.prepare('SELECT lease_until,written_at FROM clock_lease').get()
 let active=true,seen=0,maxLatency=0
 const sampling=(async()=>{while(active){const started=performance.now();const r=await call(og(36),{},true);const elapsed=performance.now()-started;assert.ok('result' in r,JSON.stringify(r));maxLatency=Math.max(maxLatency,elapsed);seen++;observations.push({atMs:performance.now(),latencyMs:elapsed});await delay(100)}})()
 // Multiple full real jobs ensure observation spans at least one 10 s lease interval.
 const started=performance.now();let runs=0;const backups=[]
 while(performance.now()-started<12000||runs===0){const b=await run(['ops','--socket-dir',ops,'backup']).done;assert.equal(b.code,0,b.stderr+' '+b.stdout);const value=JSON.parse(b.stdout);assert.equal(value.status,'completed');backups.push(value.backup);runs++;if(runs>3)break}
 active=false;await sampling
 const after=physical.prepare('SELECT lease_until,written_at FROM clock_lease').get();physical.close()
 assert.ok(after.written_at>before.written_at,JSON.stringify({before,after}));assert.ok(seen>=10)
 const source=join(file+'.backups',backups[0].fileName)
 const checked=await run(['verify','--source',source,'--work-dir',join(root,'verify')]).done;assert.equal(checked.code,0,checked.stderr+' '+checked.stdout)
 const result={status:'PASS',platform:process.platform,arch:process.arch,node:process.version,buildId:(await readFile(join(app,'BUILD_ID'),'utf8')).trim(),rows,bytes,backupRuns:runs,elapsedMs:performance.now()-started,authenticatedBusinessSuccesses:seen,maxLatencyMs:maxLatency,clockBefore:before,clockAfter:after,verify:JSON.parse(checked.stdout),scope:'actual portable host, current SQLite schema populated with synthetic unactivated accounts while stopped; real TLS authenticated business requests during online backup; observed lease renewal, not an arbitrary latency SLA or physical durability proof'}
 await stop();await writeFile(join(out,'result.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result))
}finally{for(const h of hosts){if(h.child.exitCode===null&&h.child.signalCode===null){h.child.kill('SIGKILL');await h.done}}await writeFile(join(out,'host-logs.json'),JSON.stringify(await Promise.all(hosts.map(h=>h.done)),null,2));await writeFile(join(out,'observations.json'),JSON.stringify(observations,null,2))}
