import { mkdir } from 'node:fs/promises'
import { makeCa, makeServerCertificate } from './deploy.ts'
await mkdir(process.argv[2],{recursive:true,mode:0o700})
const ca=makeCa(process.argv[2],'ca',()=>{})
makeServerCertificate(process.argv[2],'leaf',ca,['DNS:localhost','IP:127.0.0.1'],()=>{})
