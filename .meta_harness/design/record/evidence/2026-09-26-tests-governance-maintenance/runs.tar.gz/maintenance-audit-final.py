from pathlib import Path
import json,hashlib,re,os
base=Path('tmp/production-cli-onboarding');old=json.loads((base/'maintenance-artifacts-r1.json').read_text())[0];d=json.loads((base/'maintenance-artifact-doc-delta-r3.json').read_text());a=Path(old['app']);b=Path(d['app']);manifest=json.loads((b/'build-info.json').read_text());files=manifest['files'];assert hashlib.sha256(json.dumps(files,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==d['buildId']
expected={x['path'] for x in files};actual=set()
for directory,dirs,names in os.walk(b,followlinks=False):
 for n in names+dirs:
  p=Path(directory)/n
  if p.is_file() or p.is_symlink():actual.add(p.relative_to(b).as_posix())
assert actual==expected|{'BUILD_ID','build-info.json'}
for f in files:
 p=b/f['path']
 if f['kind']=='file':assert not p.is_symlink() and hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'],f['path']
 else:assert p.is_symlink() and os.readlink(p)==f['target'] and p.resolve().is_relative_to(b),f['path']
classified=[]
for f in d['changedInventoryFiles']:
 x=(a/f).read_text();y=(b/f).read_text()
 if f=='deploy/README.md':
  assert x.replace('whose parent already exists','whose parent already exists, is owned by the same user and has mode `0700`')==y
  kind='only added the required private parent instruction'
 elif '/.bin/' in f:
  norm=lambda s:re.sub(r'\.omne-host-package-[a-zA-Z0-9]+/app/','.omne-host-package-STAGING/app/',s)
  assert norm(x)==norm(y),f
  kind='only pnpm generated staging directory in NODE_PATH; not a product executable entry'
 elif f=='node_modules/.modules.yaml':
  assert re.sub(r'^prunedAt:.*$','prunedAt: TIMESTAMP',x,flags=re.M)==re.sub(r'^prunedAt:.*$','prunedAt: TIMESTAMP',y,flags=re.M)
  kind='only pnpm pruning timestamp'
 elif f=='node_modules/.pnpm-workspace-state-v1.json':
  x=json.loads(x);y=json.loads(y);x.pop('lastValidatedTimestamp');y.pop('lastValidatedTimestamp');assert x==y
  kind='only pnpm validation timestamp'
 else:raise AssertionError(f)
 classified.append({'path':f,'difference':kind})
report={**d,'inventory':'PASS','files':len(files),'runtimeAndTemplates':'all application/dependency JS, declarations, source maps, links, package manifests and service unit bytes identical to r1; only listed README/pnpm generated entries differ','classifiedChanges':classified}
(base/'maintenance-artifacts-audit-r3.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','buildId':d['buildId'],'files':len(files),'classifiedChanges':len(classified)}))
