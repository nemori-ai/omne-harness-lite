import assert from 'node:assert/strict'
import {readFile,lstat,readlink,writeFile} from 'node:fs/promises'
import {join,resolve} from 'node:path'
import {createHash} from 'node:crypto'
const evidence=resolve(process.argv[2]),fixture=JSON.parse(await readFile(join(evidence,'environment.json'),'utf8')),events=[]
for(const app of [fixture.host,fixture.cli]){const manifest=JSON.parse(await readFile(join(app,'build-info.json'),'utf8'));let files=0,links=0;for(const entry of manifest.files){const p=join(app,entry.path),s=await lstat(p);if(entry.kind==='file'){assert.ok(s.isFile());assert.equal(createHash('sha256').update(await readFile(p)).digest('hex'),entry.sha256);files++}else if(entry.kind==='link'){assert.ok(s.isSymbolicLink());assert.equal(await readlink(p),entry.target);links++}else throw Error(`unknown manifest entry ${JSON.stringify(entry)}`)}assert.equal((await readFile(join(app,'BUILD_ID'),'utf8')).trim(),manifest.buildId);events.push({app,buildId:manifest.buildId,files,links,status:'PASS'})}
await writeFile(join(evidence,'inventory.json'),JSON.stringify(events,null,2)+'\n')
