import assert from 'node:assert/strict'
import {spawn} from 'node:child_process'
import {mkdtemp,mkdir,readFile,writeFile,readdir} from 'node:fs/promises'
import {join,resolve} from 'node:path'
const evidence=resolve(process.argv[2]), fixture=JSON.parse(await readFile(join(evidence,'environment.json'),'utf8')), source=join(fixture.root,'primary','center.sqlite.backups',(await readdir(join(fixture.root,'primary','center.sqlite.backups'))).find(n=>n.endsWith('.omne-backup'))),root=await mkdtemp('/private/tmp/omne-maint-qa-concurrency-'),work=join(root,'work'),host=fixture.host,events=[]
const save=()=>writeFile(join(evidence,'same-work-root-concurrency.json'),JSON.stringify({root,source,events},null,2)+'\n')
function start(){const child=spawn(process.execPath,[join(host,'dist/cli.js'),'verify','--source',source,'--work-dir',work],{env:{PATH:process.env.PATH},stdio:['ignore','pipe','pipe']});let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);const result=new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal,stdout,stderr}))});return{child,result}}
let p
try{
  p=start();let stopped=false
  for(let i=0;i<10000;i++){const names=await readdir(work).catch(()=>[]);if(names.some(n=>n!=='.owner-lock'&&n!=='.omne-isolated')){p.child.kill('SIGSTOP');events.push({event:'SIGSTOP-after-task-created',names});stopped=true;break}if(p.child.exitCode!==null)break;await new Promise(r=>setTimeout(r,1))}
  assert.ok(stopped,'Could not observe an active task; do not claim a busy oracle')
  const second=start(),secondResult=await second.result;events.push({event:'contender',...secondResult});assert.equal(secondResult.code,2);assert.deepEqual(JSON.parse(secondResult.stdout),{status:'busy'})
  p.child.kill('SIGCONT');const first=await p.result;events.push({event:'owner-resumed',...first});assert.equal(first.code,0);assert.equal(JSON.parse(first.stdout).status,'verified');p=undefined
  const again=await start().result;events.push({event:'work-root-reused-after-actual-owner-exit',...again});assert.equal(again.code,0);assert.equal(JSON.parse(again.stdout).status,'verified')
  events.push({status:'PASS'})
}catch(e){events.push({status:'FAIL',error:e.stack});throw e}
finally{if(p){p.child.kill('SIGCONT');await p.result}await save()}
