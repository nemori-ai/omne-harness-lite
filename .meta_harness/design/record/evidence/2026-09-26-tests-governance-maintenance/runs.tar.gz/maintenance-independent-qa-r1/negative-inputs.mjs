import assert from 'node:assert/strict'
import {spawn} from 'node:child_process'
import {mkdtemp,readFile,writeFile,readdir,rename,lstat,readlink} from 'node:fs/promises'
import {join,resolve} from 'node:path'
import {createHash} from 'node:crypto'
const evidence=resolve(process.argv[2]),fixture=JSON.parse(await readFile(join(evidence,'environment.json'),'utf8')),host=fixture.host,root=await mkdtemp('/private/tmp/omne-maint-qa-negative-'),events=[],work=join(root,'work')
const source=join(fixture.root,'primary','center.sqlite.backups',(await readdir(join(fixture.root,'primary','center.sqlite.backups'))).find(n=>n.endsWith('.omne-backup'))),original=await readFile(source)
function start(input){const child=spawn(process.execPath,[join(host,'dist/cli.js'),'verify','--source',input,'--work-dir',work],{env:{PATH:process.env.PATH},stdio:['ignore','pipe','pipe']});let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);const result=new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,signal)=>resolve({code,signal,stdout,stderr}))});return{child,result}}
const magic=Buffer.from('OMNE-CENTER-BACKUP/1\n'),len=original.readUInt32BE(magic.length),metadata=JSON.parse(original.subarray(magic.length+4,magic.length+4+len))
function rewrite(change){const header=Buffer.from(JSON.stringify({...metadata,...change})),n=Buffer.alloc(4);n.writeUInt32BE(header.length);return Buffer.concat([magic,n,header,original.subarray(magic.length+4+len)])}
let active
try{
  for(const [label,changes]of [['wrong-center-id',{centerId:'0'.repeat(32)}],['wrong-migration-prefix',{migrationNames:['0000_unknown']}],['inverted-time-interval',{startedAt:'2099-01-01T00:00:00Z',finishedAt:'2000-01-01T00:00:00Z'}],['unknown-metadata-property',{arbitrary:1}]]){const path=join(root,label);await writeFile(path,rewrite(changes),{mode:0o600});const result=await start(path).result;events.push({label,...result});assert.equal(result.code,2);assert.deepEqual(JSON.parse(result.stdout),{status:'invalid-backup'})}
  const changing=join(root,'changing');await writeFile(changing,original,{mode:0o600});active=start(changing);let stopped=false
  for(let i=0;i<10000;i++){const names=await readdir(work).catch(()=>[]);if(names.some(n=>n.startsWith('task-'))){active.child.kill('SIGSTOP');events.push({label:'source-mutation-gate',names});stopped=true;break}if(active.child.exitCode!==null)break;await new Promise(r=>setTimeout(r,1))}
  assert.ok(stopped,'No active input task observed')
  const changed=Buffer.from(original);changed[changed.length-1]^=1;await writeFile(changing,changed);active.child.kill('SIGCONT');const mutation=await active.result;active=undefined;events.push({label:'in-place-source-mutation-during-task',...mutation});assert.equal(mutation.code,1);assert.deepEqual(JSON.parse(mutation.stdout),{status:'unavailable'})
  // Verify every listed artifact entry, including symlink targets; do not repair anything.
  for(const app of [fixture.host,fixture.cli]){const manifest=JSON.parse(await readFile(join(app,'build-info.json'),'utf8'));let files=0,links=0;for(const entry of manifest.files){const p=join(app,entry.path),s=await lstat(p);if(entry.kind==='file'){assert.ok(s.isFile());assert.equal(createHash('sha256').update(await readFile(p)).digest('hex'),entry.sha256);files++}else if(entry.kind==='symlink'){assert.ok(s.isSymbolicLink());assert.equal(await readlink(p),entry.target);links++}else throw Error(`unknown manifest entry ${JSON.stringify(entry)}`)}events.push({label:'artifact-manifest',app,buildId:manifest.buildId,files,links,status:'PASS'})}
  events.push({status:'PASS'})
}catch(e){events.push({status:'FAIL',error:e.stack});throw e}
finally{if(active){active.child.kill('SIGCONT');await active.result}await writeFile(join(evidence,'negative-inputs.json'),JSON.stringify({root,events},null,2)+'\n')}
