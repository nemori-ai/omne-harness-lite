import { DatabaseSync } from 'node:sqlite'
import { isSqliteBusy } from './errors.ts'
import type { OwnerLock } from '../upgrade/owner.ts'

/** Strong references are necessary: GC must never end ownership. */
const heldLocks = new Set<DatabaseSync>()

export class SqliteLockBusy extends Error {
  override readonly name = 'SqliteLockBusy'
}

/** Private empty coordination database, never a production data connection. */
export function acquireSqliteLock(file: string): OwnerLock {
  const db = new DatabaseSync(file, { timeout: 0 })
  try {
    db.exec('PRAGMA journal_mode = MEMORY')
    db.exec('BEGIN IMMEDIATE')
  } catch (error) {
    db.close()
    if (isSqliteBusy(error)) throw new SqliteLockBusy('coordination lock is occupied')
    throw error
  }
  heldLocks.add(db)
  let released = false
  return {
    async release() {
      if (released) return
      try {
        if (db.isTransaction) db.exec('ROLLBACK')
      } finally {
        db.close()
        released = true
        heldLocks.delete(db)
      }
    },
  }
}
