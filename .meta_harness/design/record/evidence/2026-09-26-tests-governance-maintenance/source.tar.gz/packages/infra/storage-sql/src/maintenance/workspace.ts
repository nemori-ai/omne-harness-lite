import { constants } from 'node:fs'
import { randomBytes } from 'node:crypto'
import { lstat, mkdir, open, realpath, rm } from 'node:fs/promises'
import { basename, dirname, isAbsolute, join, resolve } from 'node:path'
import { SnapshotFailure } from '@omne-harness-lite/storage'
import { acquireSqliteLock, SqliteLockBusy } from '../sqlite/lock.ts'
import { ISOLATION_CONTENT, ISOLATION_MARKER } from '../sqlite/protection.ts'
import type { OwnerLock } from '../upgrade/owner.ts'
import { fsyncDirectory } from '../upgrade/files.ts'

function hasCode(error: unknown, code: string): boolean {
  return error instanceof Error && 'code' in error && error.code === code
}

async function privateDirectory(path: string): Promise<void> {
  const info = await lstat(path)
  if (
    !info.isDirectory() ||
    info.isSymbolicLink() ||
    (info.mode & 0o077) !== 0 ||
    process.getuid === undefined ||
    info.uid !== process.getuid()
  )
    throw new SnapshotFailure('unavailable')
}

/** No method removes the permanent root or its marker. */
export class SnapshotWorkspace {
  #closed = false
  private constructor(
    readonly root: string,
    private readonly lock: OwnerLock,
  ) {}

  static async open(path: string): Promise<SnapshotWorkspace> {
    if (!isAbsolute(path)) throw new SnapshotFailure('unavailable')
    const parent = await realpath(dirname(resolve(path)))
    await privateDirectory(parent)
    const root = join(parent, basename(resolve(path)))
    if (root === parent) throw new SnapshotFailure('unavailable')
    let created = false
    try {
      await mkdir(root, { mode: 0o700 })
      created = true
    } catch (error) {
      if (!hasCode(error, 'EEXIST')) throw error
    }
    await privateDirectory(root)
    let lock: OwnerLock
    try {
      lock = acquireSqliteLock(join(root, '.owner-lock'))
    } catch (error) {
      if (error instanceof SqliteLockBusy) throw new SnapshotFailure('busy')
      throw error
    }
    try {
      const marker = await open(
        join(root, ISOLATION_MARKER),
        constants.O_NOFOLLOW |
          (created ? constants.O_RDWR | constants.O_CREAT | constants.O_EXCL : constants.O_RDWR),
        0o600,
      )
      try {
        const info = await marker.stat()
        if (!info.isFile() || (info.mode & 0o077) !== 0 || info.uid !== process.getuid?.())
          throw new SnapshotFailure('unavailable')
        if (created) await marker.writeFile(ISOLATION_CONTENT)
        else if (
          info.size !== Buffer.byteLength(ISOLATION_CONTENT) ||
          (await marker.readFile('utf8')) !== ISOLATION_CONTENT
        )
          throw new SnapshotFailure('unavailable')
        await marker.sync()
      } finally {
        await marker.close()
      }
      await fsyncDirectory(root)
      await fsyncDirectory(parent)
      return new SnapshotWorkspace(root, lock)
    } catch (error) {
      await lock.release()
      if (error instanceof SnapshotFailure) throw error
      throw new SnapshotFailure('unavailable', { cause: error })
    }
  }

  async createTask(): Promise<string> {
    if (this.#closed) throw new SnapshotFailure('unavailable')
    const path = join(this.root, `task-${randomBytes(16).toString('hex')}`)
    await mkdir(path, { mode: 0o700 })
    return path
  }

  async removeTask(path: string): Promise<void> {
    if (dirname(path) !== this.root || !path.startsWith(join(this.root, 'task-')))
      throw new SnapshotFailure('unavailable')
    try {
      await rm(path, { recursive: true, force: false })
    } catch (error) {
      throw new SnapshotFailure('unavailable', { cause: error, residual: path })
    }
  }

  async close(): Promise<void> {
    this.#closed = true
    await this.lock.release()
  }
}
