# Linux service templates

These files are installation templates, not an installer. Replace the Node and artifact paths, service user/group, data directory, environment-file path and socket directory together before installing. The packaged Node requirement is 24.21.0. macOS can run the same host commands directly; these units require Linux systemd.

Create the dedicated non-root service account and its private data directory (`0700`). Keep code releases outside the data directory. Generate deployment keys once as that account, supply the TLS certificate/key and configure the variables listed in the artifact README. The environment file must be `0600`; all secret files must be readable by the service account and inaccessible to other users. For these templates set `OMNE_TENANCY_OPS_SOCKET_DIR=/run/omne-tenancy`. systemd creates this private runtime directory. `OMNE_TENANCY_BACKUP_DIR` is optional; its default is the canonical database filename plus `.backups`. An explicitly selected backup directory needs an existing parent.

Before installation, validate the edited files on the target machine:

```sh
systemd-analyze verify omne-tenancy.service omne-tenancy-backup.service omne-tenancy-backup.timer
```

Install the three edited units in `/etc/systemd/system`, then run these administrative commands:

```sh
systemctl daemon-reload
systemctl enable --now omne-tenancy.service
systemctl enable --now omne-tenancy-backup.timer
systemctl status omne-tenancy.service
journalctl -u omne-tenancy.service -u omne-tenancy-backup.service
```

Run the following commands as the service account, replacing executable paths consistently:

```sh
/opt/node-v24.21.0/bin/node /opt/omne-tenancy/current/app/dist/cli.js ops --socket-dir /run/omne-tenancy full-health
/opt/node-v24.21.0/bin/node /opt/omne-tenancy/current/app/dist/cli.js ops --socket-dir /run/omne-tenancy backup --only-if-due
/opt/node-v24.21.0/bin/node /opt/omne-tenancy/current/app/dist/cli.js ops --socket-dir /run/omne-tenancy backup-status
```

Inspect `backup-status` and the backup unit's journal daily. A timer firing is not a successful backup. The backup unit does not start a stopped center. An unsuccessful or unconfirmed invocation is recorded as a service failure; it has no automatic request retry. Keep enough free space and move completed backups to an independent protected location when available. Backups are not automatically deleted.

For local file checking and isolated restoration, select a separate private work directory whose parent already exists, is owned by the same user and has mode `0700`. Place the restore work directory on the target filesystem. The target must be a new directory, even an existing empty directory is refused:

```sh
node app/dist/cli.js verify --source /absolute/backup.omne-backup --work-dir /absolute/private/verify-work
node app/dist/cli.js restore-isolated --source /absolute/backup.omne-backup --target /absolute/private/new-restored --work-dir /absolute/private/restore-work
```

Restoration produces `data.omne-backup` and reports `businessOpen:false`; it is not a database to pass to `serve`. Keep the isolated work roots and their `.omne-isolated` markers intact. Same-machine backups do not cover destruction of that machine or disk.

For an upgrade, verify and extract the new artifact into a new release directory. Stop the service and wait until it is inactive before switching the `current` link. Start the service and check both public connectivity and full health. A `still-stopping` record means shutdown is still waiting; the service has no normal forced-kill deadline. Retaining old code does not authorize opening a migrated database with it. If startup fails, inspect the named failure and upgrade-snapshot location before another attempt.

Command exit codes: `0` for a successful operation or current backup status; `2` for missing/overdue status or a declared refusal; `1` for unavailable dependencies, uncertain results, internal/cleanup or output failure; `64` for syntax. A successful full-health command means the reply was received; inspect its individual health fields.
