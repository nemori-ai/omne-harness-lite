import { existsSync, promises as fs } from 'node:fs'
import { syncBuiltinESMExports } from 'node:module'
import { join } from 'node:path'
import { afterEach, expect, it, vi } from 'vitest'
import { ENV } from '../src/config.ts'
import { deployment } from './support/deployment.ts'
import { Hosts } from './support/host.ts'

const hosts = new Hosts()
const roots: string[] = []
afterEach(async () => {
  vi.restoreAllMocks()
  syncBuiltinESMExports()
  await hosts.stopAll()
  for (const root of roots.splice(0)) await fs.rm(root, { recursive: true, force: true })
})

it('refuses parent fsync failure before creating any fiber, database or plaintext workspace', async () => {
  const d = await deployment('maintenance-parent-sync')
  roots.push(d.root)
  const parent = await fs.realpath(d.root)
  const original = fs.open
  let injected = 0
  vi.spyOn(fs, 'open').mockImplementation(async (...args) => {
    const handle = await original(...args)
    if (String(args[0]) === parent)
      vi.spyOn(handle, 'sync').mockImplementation(async () => {
        injected++
        throw Object.assign(new Error('injected directory fsync failure'), { code: 'EIO' })
      })
    return handle
  })
  syncBuiltinESMExports()
  const refusal = await hosts.refuse(d)
  expect(injected).toBe(1)
  expect(refusal.failure).toMatchObject({ stage: 'config', item: ENV.backupDirectory })
  expect(refusal.fibers).toHaveLength(0)
  expect(existsSync(d.file)).toBe(false)
  expect(existsSync(join(`${d.file}.backups`, '.quarantine'))).toBe(false)
})

it('rejects a directory used as the source before creating its default backup directory', async () => {
  const d = await deployment('maintenance-source-directory')
  roots.push(d.root)
  await fs.mkdir(d.file, { mode: 0o700 })
  const refusal = await hosts.refuse(d)
  expect(refusal.failure).toMatchObject({ stage: 'config' })
  expect(refusal.fibers).toHaveLength(0)
  expect(existsSync(`${d.file}.backups`)).toBe(false)
})
