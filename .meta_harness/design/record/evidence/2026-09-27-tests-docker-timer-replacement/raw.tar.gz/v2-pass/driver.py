#!/usr/bin/env python3
"""Root-gated timer replacement pilot over the frozen recovery-B fixture."""

import hashlib
import importlib.util
import json
import pathlib
import re
import shutil
import sys

HERE = pathlib.Path(__file__).resolve().parent
RECOVERY = pathlib.Path(
    "/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-recovery/tmp/docker-recovery"
)
BASE_HASHES = {
    "driver.py": "521c952b2930460cb68d6e98294e86272d4f45f1f09af4f94c49901bb0de6926",
    "fixture.py": "42ada54c8a9c5248206fb2a3e6927e55303c1db59298393e23728e371e66a56c",
    "oracle.py": "2481d05268ae8a44e6a35664bc2aeb06cbc2fede9dcd08c196bef4050a8e53a4",
}


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


for filename, expected in BASE_HASHES.items():
    if sha(RECOVERY / filename) != expected:
        raise RuntimeError(f"recovery B source changed: {filename}")

sys.path.insert(0, str(RECOVERY))
import fixture  # noqa: E402  The checked recovery-B fixture owns the private environment.

spec = importlib.util.spec_from_file_location("recovery_b_driver", RECOVERY / "driver.py")
if spec is None or spec.loader is None:
    raise RuntimeError("recovery B driver cannot be loaded")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
fixture.HERE = HERE
base.HERE = HERE

QA_OVERRIDE = b"[Timer]\nOnCalendar=\nOnActiveSec=600s\nPersistent=false\n"
TIMER_PROPERTIES = (
    "ActiveState", "SubState", "FragmentPath", "DropInPaths", "Unit",
    "TimersCalendar", "TimersMonotonic", "Persistent", "LastTriggerUSec",
    "NextElapseUSecMonotonic",
)
SERVICE_PROPERTIES = (
    "ActiveState", "SubState", "Result", "ExecMainStartTimestampMonotonic",
    "InvocationID",
)


class TimerRun(base.RecoveryRun):
    def __init__(self, args, inputs):
        super().__init__(args, inputs)
        for source, target in (("driver.py", "recovery-b-driver.py"),
                               ("oracle.py", "recovery-b-oracle.py")):
            shutil.copyfile(RECOVERY / source, self.frozen / target)
            base.need(sha(self.frozen / target) == BASE_HASHES[source],
                      f"frozen recovery B {source} changed")

    def setup(self):
        super().setup()
        # Recovery B installs a 2s QA drop-in but never activates its timer.
        # Replace it before the first activation, keeping the production unit bytes.
        dropin = "/etc/systemd/system/omne-center-backup@.timer.d/r5-qa.conf"
        self.outer("t-write-qa-600s-dropin", "exec", "-i", self.control,
                   "tee", dropin, stdin=QA_OVERRIDE)
        self.control_exec("t-read-qa-600s-dropin", "cat", dropin)
        self.control_exec("t-reload-600s", "systemctl", "daemon-reload")
        for filename in ("omne-center-backup@.timer", "omne-center-backup@.service"):
            self.control_exec("t-installed-sha-" + filename, "sha256sum",
                              "/etc/systemd/system/" + filename)

    def show(self, label, unit, properties):
        output = self.control_exec(label, "systemctl", "show", "--all", unit,
                                   *("--property=" + name for name in properties))
        result = {}
        for line in output.decode("utf-8", "strict").splitlines():
            base.need("=" in line, label + " malformed systemd property")
            key, value = line.split("=", 1)
            base.need(key not in result, label + " duplicate systemd property")
            result[key] = value
        expected = set(properties)
        missing = expected - set(result)
        base.need(set(result) <= expected and missing <= {"TimersCalendar"},
                  label + " incomplete systemd state")
        if "TimersCalendar" in result:
            base.need(result["TimersCalendar"] == "", label + " unexpected calendar schedule")
        return result

    def timer_snapshot(self, label):
        timer = f"omne-center-backup@{self.project}.timer"
        service = f"omne-center-backup@{self.project}.service"
        return (self.show(label + "-timer", timer, TIMER_PROPERTIES),
                self.show(label + "-service", service, SERVICE_PROPERTIES))

    @staticmethod
    def require_timer(snapshot, active, baseline):
        timer, service = snapshot
        base.need(timer["ActiveState"] == ("active" if active else "inactive")
                  and (not active or timer["SubState"] == "waiting")
                  and timer["LastTriggerUSec"] == baseline[0]
                  and service["ExecMainStartTimestampMonotonic"] == baseline[1]
                  and service["InvocationID"] == baseline[2]
                  and service["ActiveState"] == "inactive",
                  "timer state or no-invocation condition changed")

    def require_replacement_ready(self):
        # These are already captured by recovery B. Read their raw facts before
        # authorizing timer resume, then let the independent oracle recheck them.
        records = {item["label"]: item for item in self.evidence["commands"]}

        def raw(label, stream="stdout"):
            return (self.run / records[label][stream]).read_bytes()

        def result(label):
            return self.cli_result(base.one_json(raw(label), label), label)

        old = base.one_json(raw("b-old-start"), "old start")
        new = base.one_json(raw("b-new-start"), "new start")
        health_old = base.one_json(raw("b-old-full-health"), "old health")
        health_new = base.one_json(raw("b-new-full-health"), "new health")
        before = result("b-cli-current-before")
        after = result("b-cli-current-after")
        list_before = result("b-cli-list-before")
        list_after = result("b-cli-list-after")
        cli_health_before = base.one_json(raw("b-cli-health-before"), "old public health")
        cli_health_after = base.one_json(raw("b-cli-health-after"), "new public health")
        base.need(old["containerId"] != new["containerId"]
                  and health_old["centerId"] == health_new["centerId"]
                  == cli_health_before["remote"]["health"]["centerId"]
                  == cli_health_after["remote"]["health"]["centerId"]
                  and health_new["defectCount"] == 0
                  and all(health_new.get(name) is True for name in
                          ("reachable", "storageReachable", "clockSane",
                           "deploymentKeyPresent", "deploymentKeyComplete"))
                  and before == after and list_before == list_after
                  and before in list_before,
                  "new health or prior public facts not confirmed before timer resume")
        export = raw("b-new-start", "stderr")
        match = re.search(rb"operations-exported container=([0-9a-f]{64}) directory=(\S+)",
                          export)
        metadata = json.loads(raw("b-export-content-metadata.json"))
        old_stopped = json.loads(raw("b-old-stop-inspect"))[0]
        base.need(match and match.group(1).decode() == old["containerId"]
                  and match.group(2).decode("ascii") == self.evidence["operations_directory"]
                  and b"center-start-request" in export
                  and match.end() < export.index(b"center-start-request")
                  and metadata["containerId"] == old["containerId"]
                  and metadata["imageId"] == self.evidence["expected"]["images"]["old"]["inner_image_id"]
                  and metadata["buildId"] == self.evidence["expected"]["images"]["old"]["build_id"]
                  and metadata["status"] == "exited" and metadata["exitCode"] == 0
                  and metadata["finishedAt"] == old_stopped["State"]["FinishedAt"]
                  and raw("b-export-content-stdout.log") == raw("b-old-logs")
                  and raw("b-export-content-stderr.log") == raw("b-old-logs", "stderr"),
                  "old operations not actually exported before timer resume")

    def normal_stop(self, label, cid):
        timer = f"omne-center-backup@{self.project}.timer"
        service = f"omne-center-backup@{self.project}.service"
        if label == "b-old-stop":
            # Recovery B has already confirmed old full-health and public current/list.
            self.control_exec("t-unit-cat", "systemctl", "cat", timer)
            initial = self.timer_snapshot("t-before-activation")
            self.timer_baseline = (initial[0]["LastTriggerUSec"],
                                   initial[1]["ExecMainStartTimestampMonotonic"],
                                   initial[1]["InvocationID"])
            self.require_timer(initial, False, self.timer_baseline)
            self.control_exec("t-start-old-timer", "systemctl", "start", timer)
            self.require_timer(self.timer_snapshot("t-old-active"), True,
                               self.timer_baseline)
            new = self.evidence["expected"]["images"]["new"]["inner_image_id"]
            self.helper("t-new-validate-before-stop", "validate", *self.deployment(new))
            self.inspect("t-old-inspect-after-validation", cid)
            self.status("t-old-status-after-validation")
            self.require_timer(self.timer_snapshot("t-after-validation"), True,
                               self.timer_baseline)
            self.control_exec("t-stop-old-timer", "systemctl", "stop", timer)
            self.require_timer(self.timer_snapshot("t-old-inactive"), False,
                               self.timer_baseline)
        elif label == "b-new-stop":
            # Recovery B has already read the exported operations and refreshed public facts.
            self.require_replacement_ready()
            self.require_timer(self.timer_snapshot("t-before-resume"), False,
                               self.timer_baseline)
            self.control_exec("t-resume-timer", "systemctl", "start", timer)
            self.require_timer(self.timer_snapshot("t-resumed"), True,
                               self.timer_baseline)
            self.control_exec("t-stop-final-timer", "systemctl", "stop", timer)
            self.require_timer(self.timer_snapshot("t-final-inactive"), False,
                               self.timer_baseline)
            journal = self.control_exec("t-service-journal", "journalctl", "-u", service,
                                        "--no-pager", "--output=cat")
            base.need(journal == b"", "timer service unexpectedly invoked")
        return super().normal_stop(label, cid)

    def cleanup(self):
        # Decide the complete product sequence while its exact private resources
        # still exist. The inherited cleanup is only fixture teardown.
        if self.evidence["status"] == "observed-awaiting-oracle":
            oracle_spec = importlib.util.spec_from_file_location(
                "timer_replacement_oracle", HERE / "oracle.py"
            )
            if oracle_spec is None or oracle_spec.loader is None:
                self.evidence["status"] = "observation-incomplete"
                self.evidence["error"] = "timer oracle cannot be loaded before cleanup"
            else:
                oracle = importlib.util.module_from_spec(oracle_spec)
                try:
                    oracle_spec.loader.exec_module(oracle)
                    self.evidence["business_verdict"] = oracle.evaluate_business(self.run)
                except (ValueError, KeyError, TypeError, UnicodeError, OSError,
                        IndexError, RuntimeError) as error:
                    self.evidence["status"] = "observation-incomplete"
                    self.evidence["error"] = f"precleanup business oracle: {error}"
            self.save()
        super().cleanup()


original_checked_inputs = base.checked_inputs


def checked_inputs(args):
    if args.scenario != "B":
        raise RuntimeError("timer replacement pilot only accepts recovery scenario B")
    inputs = original_checked_inputs(args)
    inputs["sha256"]["recovery_b_driver"] = BASE_HASHES["driver.py"]
    inputs["sha256"]["recovery_b_oracle"] = BASE_HASHES["oracle.py"]
    inputs["qa_timer_override_sha256"] = hashlib.sha256(QA_OVERRIDE).hexdigest()
    inputs["timer_pilot"] = "positive-replacement-600s"
    return inputs


base.checked_inputs = checked_inputs
base.RecoveryRun = TimerRun

if __name__ == "__main__":
    raise SystemExit(base.main())
