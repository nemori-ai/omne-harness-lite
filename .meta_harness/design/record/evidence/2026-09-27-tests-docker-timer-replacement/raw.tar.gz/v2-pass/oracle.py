#!/usr/bin/env python3
"""Fail-closed timer sequence oracle; recovery-B oracle retains the detailed B checks."""

import hashlib
import importlib.util
import json
import pathlib
import re
import sys

BASE_ORACLE_SHA = "2481d05268ae8a44e6a35664bc2aeb06cbc2fede9dcd08c196bef4050a8e53a4"
QA_OVERRIDE = b"[Timer]\nOnCalendar=\nOnActiveSec=600s\nPersistent=false\n"
HEX = re.compile(r"[0-9a-f]{64}\Z")


def need(value, message):
    if not value:
        raise ValueError(message)


def load_base(run):
    path = run / "inputs" / "recovery-b-oracle.py"
    need(path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == BASE_ORACLE_SHA,
         "frozen recovery-B oracle missing or changed")
    spec = importlib.util.spec_from_file_location("frozen_recovery_b_oracle", path)
    need(spec is not None and spec.loader is not None, "cannot load frozen B oracle")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def show(base, run, commands, label, unit, properties):
    item = commands[label]
    need(item["argv"] == ["docker", "exec", unit[0], "systemctl", "show", "--all", unit[1],
                          *("--property=" + key for key in properties)]
         and item["returncode"] == 0 and item["observation_expired"] is False,
         label + " real systemd show")
    lines = base.raw(run, commands, label).decode("utf-8", "strict").splitlines()
    result = {}
    for line in lines:
        need("=" in line, label + " malformed show line")
        key, value = line.split("=", 1)
        need(key not in result, label + " duplicate property")
        result[key] = value
    expected = set(properties)
    missing = expected - set(result)
    need(set(result) <= expected and missing <= {"TimersCalendar"},
         label + " missing/extra properties")
    if "TimersCalendar" in result:
        need(result["TimersCalendar"] == "", label + " unexpected calendar schedule")
    return result


TIMER_PROPERTIES = (
    "ActiveState", "SubState", "FragmentPath", "DropInPaths", "Unit",
    "TimersCalendar", "TimersMonotonic", "Persistent", "LastTriggerUSec",
    "NextElapseUSecMonotonic",
)
SERVICE_PROPERTIES = (
    "ActiveState", "SubState", "Result", "ExecMainStartTimestampMonotonic",
    "InvocationID",
)


def checked_command(base, run, commands, label, argv):
    item = commands[label]
    need(item["argv"] == argv and item["returncode"] == 0
         and item["observation_expired"] is False,
         label + " exact successful command")
    return base.raw(run, commands, label)


def evaluate_business(run):
    base = load_base(run)
    evidence = json.loads((run / "evidence.json").read_text())
    entries = evidence["commands"]
    commands = {item["label"]: item for item in entries}
    need(len(commands) == len(entries) and evidence["scenario"] == "B",
         "unique B command transcript required")
    expected = evidence["expected"]
    control, project = expected["control"], expected["project"]
    old, new = expected["images"]["old"], expected["images"]["new"]
    timer = f"omne-center-backup@{project}.timer"
    service = f"omne-center-backup@{project}.service"
    unit = (control, timer)
    service_unit = (control, service)
    order = [item["label"] for item in entries]
    milestones = (
        "b-cli-current-before", "b-cli-list-before", "t-before-activation-timer",
        "t-start-old-timer", "t-old-active-timer", "t-new-validate-before-stop",
        "t-old-inspect-after-validation", "t-after-validation-timer",
        "t-stop-old-timer", "t-old-inactive-timer", "b-old-stop", "b-old-stop-inspect",
        "b-new-start", "b-new-inspect", "b-new-full-health",
        "b-cli-current-after", "b-cli-list-after", "b-export-content-metadata.json",
        "t-before-resume-timer", "t-resume-timer", "t-resumed-timer",
        "t-stop-final-timer", "t-final-inactive-timer", "t-service-journal",
        "b-new-stop", "b-new-stop-inspect",
    )
    need(all(name in commands for name in milestones)
         and [order.index(name) for name in milestones] ==
         sorted(order.index(name) for name in milestones),
         "replacement/timer command order")
    checked_command(base, run, commands, "t-write-qa-600s-dropin",
                    ["docker", "exec", "-i", control, "tee",
                     "/etc/systemd/system/omne-center-backup@.timer.d/r5-qa.conf"])
    need(base.raw(run, commands, "t-read-qa-600s-dropin") == QA_OVERRIDE
         and evidence["inputs"]["qa_timer_override_sha256"] ==
         hashlib.sha256(QA_OVERRIDE).hexdigest(), "exact QA-only schedule bytes")
    checked_command(base, run, commands, "t-reload-600s",
                    ["docker", "exec", control, "systemctl", "daemon-reload"])
    for filename, key in (("omne-center-backup@.timer", "timer"),
                          ("omne-center-backup@.service", "service")):
        installed = "/etc/systemd/system/" + filename
        data = checked_command(base, run, commands, "t-installed-sha-" + filename,
                               ["docker", "exec", control, "sha256sum", installed])
        need(data == f'{evidence["inputs"]["sha256"][key]}  {installed}\n'.encode(),
             filename + " installed template bytes")
    unit_text = checked_command(base, run, commands, "t-unit-cat",
                                ["docker", "exec", control, "systemctl", "cat", timer])
    need(b"OnCalendar=hourly\n" in unit_text and QA_OVERRIDE in unit_text,
         "original timer and explicit QA drop-in not loaded")
    for label, action in (("t-start-old-timer", "start"),
                          ("t-stop-old-timer", "stop"),
                          ("t-resume-timer", "start"),
                          ("t-stop-final-timer", "stop")):
        checked_command(base, run, commands, label,
                        ["docker", "exec", control, "systemctl", action, timer])
    snapshots = ("t-before-activation", "t-old-active", "t-after-validation",
                 "t-old-inactive", "t-before-resume", "t-resumed", "t-final-inactive")
    timer_states = [show(base, run, commands, label + "-timer", unit,
                         TIMER_PROPERTIES) for label in snapshots]
    service_states = [show(base, run, commands, label + "-service", service_unit,
                           SERVICE_PROPERTIES) for label in snapshots]
    for state in timer_states:
        need(state["FragmentPath"] == "/etc/systemd/system/omne-center-backup@.timer"
             and state["DropInPaths"] ==
             "/etc/systemd/system/omne-center-backup@.timer.d/r5-qa.conf"
             and state["Unit"] == service
             and ("TimersCalendar" not in state or state["TimersCalendar"] == "")
             and "OnActiveUSec" in state["TimersMonotonic"]
             and any(value in state["TimersMonotonic"]
                     for value in ("600000000", "10min", "600s"))
             and state["Persistent"] in ("no", "false"),
             "effective 600s QA timer properties")
    for state in (timer_states[1], timer_states[2], timer_states[5]):
        need(state["ActiveState"] == "active" and state["SubState"] == "waiting"
             and state["NextElapseUSecMonotonic"] not in ("", "n/a", "0"),
             "timer was not actually active/waiting")
    for state in (timer_states[3], timer_states[4], timer_states[6]):
        need(state["ActiveState"] == "inactive", "timer was not inactive")
    baseline_trigger = timer_states[0]["LastTriggerUSec"]
    baseline_start = service_states[0]["ExecMainStartTimestampMonotonic"]
    baseline_invocation = service_states[0]["InvocationID"]
    need(baseline_trigger in ("", "n/a") and baseline_start in ("", "0")
         and baseline_invocation in ("", "00000000000000000000000000000000"),
         "fresh timer/service already invoked")
    need(all(state["LastTriggerUSec"] == baseline_trigger for state in timer_states)
         and all(state["ExecMainStartTimestampMonotonic"] == baseline_start
                 and state["InvocationID"] == baseline_invocation
                 and state["ActiveState"] == "inactive" for state in service_states),
         "timer triggered or service invoked during replacement")
    journal = checked_command(base, run, commands, "t-service-journal",
                              ["docker", "exec", control, "journalctl", "-u", service,
                               "--no-pager", "--output=cat"])
    need(journal == b"", "service journal has an invocation")
    helper = ["docker", "exec", "-e",
              "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock", control,
              "/usr/local/libexec/omne-center"]
    validate = commands["t-new-validate-before-stop"]
    need(validate["argv"][:len(helper) + 1] == [*helper, "validate"]
         and validate["argv"].count("--image") == 1
         and validate["argv"][validate["argv"].index("--image") + 1] ==
         new["inner_image_id"]
         and validate["argv"].count("--project") == 1
         and validate["argv"][validate["argv"].index("--project") + 1] == project
         and base.command(run, commands, "t-new-validate-before-stop") ==
         {"state": "deployment-structure-valid"},
         "new image not validated while old remained running")
    old_started = base.inspect(run, commands, "b-old-inspect-running",
                               base.command(run, commands, "b-old-start")["containerId"])
    cid = old_started["Id"]
    during = base.inspect(run, commands, "t-old-inspect-after-validation", cid)
    need(during["State"]["Running"] is True
         and during["State"]["Status"] == "running"
         and during["Image"] == old["inner_image_id"]
         and during["State"]["StartedAt"] == old_started["State"]["StartedAt"]
         and during["RestartCount"] == old_started["RestartCount"],
         "old center identity/process changed before timer stop")
    base.status(run, commands, "t-old-status-after-validation", cid,
                old["inner_image_id"], old["build_id"], "running")
    base.stop(run, commands, "b-old-stop", cid, old["inner_image_id"], old["build_id"])
    started = base.command(run, commands, "b-new-start")
    new_cid = started["containerId"]
    need(HEX.fullmatch(new_cid) and new_cid != cid
         and started == {"state": "running", "containerId": new_cid,
                         "imageId": new["inner_image_id"], "buildId": new["build_id"],
                         "health": "healthy"}, "new start identity/health")
    new_actual = base.inspect(run, commands, "b-new-inspect", new_cid)
    need(new_actual["Image"] == new["inner_image_id"]
         and new_actual["State"]["Status"] == "running", "new actual image")
    base.status(run, commands, "b-new-status", new_cid,
                new["inner_image_id"], new["build_id"], "running")
    health = base.command(run, commands, "b-new-full-health")
    need(health["centerId"] == base.command(run, commands, "b-old-full-health")["centerId"]
         and health["defectCount"] == 0
         and all(health.get(key) is True for key in
                 ("reachable", "storageReachable", "clockSane",
                  "deploymentKeyPresent", "deploymentKeyComplete")),
         "new center full-health/prior identity")
    old_current = base.result(base.cli_report(run, commands, "b-cli-current-before", control,
                                              ["tenant", "current"]))
    new_current = base.result(base.cli_report(run, commands, "b-cli-current-after", control,
                                              ["tenant", "current"]))
    old_list = base.result(base.cli_report(run, commands, "b-cli-list-before", control,
                                           ["tenant", "list"]))
    new_list = base.result(base.cli_report(run, commands, "b-cli-list-after", control,
                                           ["tenant", "list"]))
    created_team = base.result(base.cli_report(run, commands, "b-cli-create-team", control,
                                               ["organization", "create"]))
    personal = base.result(base.cli_report(run, commands, "b-cli-personal-before", control,
                                           ["tenant", "current"]))
    need(old_current == new_current ==
         {"organization": created_team, "account": personal["account"]}
         and old_list == new_list and old_current in old_list
         and "--refresh" in commands["b-cli-current-after"]["argv"]
         and "--refresh" in commands["b-cli-list-after"]["argv"],
         "public confirmed current/list facts changed")
    for label, action in (("b-cli-register", ["register"]),
                          ("b-cli-login", ["login"]),
                          ("b-cli-switch", ["tenant", "switch"])):
        base.cli_report(run, commands, label, control, action)
    before_health = base.cli_report(run, commands, "b-cli-health-before", control,
                                    ["center", "health"])
    after_health = base.cli_report(run, commands, "b-cli-health-after", control,
                                   ["center", "health"])
    need(before_health["remote"]["health"]["centerId"] ==
         after_health["remote"]["health"]["centerId"] == health["centerId"],
         "public center health changed")
    export_stderr = base.raw(run, commands, "b-new-start", "stderr")
    match = re.search(rb"operations-exported container=([0-9a-f]{64}) directory=(\S+)",
                      export_stderr)
    need(match and match.group(1).decode() == cid
         and b"center-start-request" in export_stderr
         and match.end() < export_stderr.index(b"center-start-request"),
         "original helper did not export old operations before new start")
    directory = match.group(2).decode("ascii", "strict")
    need(directory == evidence["operations_directory"]
         and directory.startswith(expected["state"] + "/operations/")
         and base.raw(run, commands, "b-operations-parent-stat") == b"directory:0:0:700\n"
         and base.raw(run, commands, "b-operations-dir-stat") == b"directory:0:0:700\n",
         "operations directory/path/ownership")
    for filename in ("stdout.log", "stderr.log", "metadata.json"):
        label = "b-export-stat-" + filename
        item = commands[label]
        need(item["argv"] == ["docker", "exec", control, "stat", "-c",
                              "%F:%u:%g:%a:%s", directory + "/" + filename]
             and item["returncode"] == 0, filename + " actual exported stat")
        content_label = "b-export-content-" + filename
        need(commands[content_label]["argv"] ==
             ["docker", "exec", control, "cat", directory + "/" + filename]
             and commands[content_label]["returncode"] == 0,
             filename + " actual exported content")
        content = base.raw(run, commands, content_label)
        fields = base.raw(run, commands, label).decode().strip().split(":")
        need(len(fields) == 5 and fields[0] in ("regular file", "regular empty file")
             and fields[1:4] == ["0", "0", "600"]
             and int(fields[4]) == len(content), filename + " export metadata")
    need(base.raw(run, commands, "b-export-content-stdout.log") ==
         base.raw(run, commands, "b-old-logs")
         and base.raw(run, commands, "b-export-content-stderr.log") ==
         base.raw(run, commands, "b-old-logs", "stderr"),
         "exported operation logs differ from old container")
    metadata = base.whole_json_object(
        base.raw(run, commands, "b-export-content-metadata.json"), "operations metadata"
    )
    stopped_old = base.inspect(run, commands, "b-old-stop-inspect", cid)
    need(metadata["containerId"] == cid
         and metadata["imageId"] == old["inner_image_id"]
         and metadata["buildId"] == old["build_id"]
         and metadata["status"] == "exited" and metadata["exitCode"] == 0
         and metadata["finishedAt"] == stopped_old["State"]["FinishedAt"],
         "exported old operation identity/exit metadata")
    base.stop(run, commands, "b-new-stop", new_cid,
              new["inner_image_id"], new["build_id"])
    return {"status": "business-pass-before-cleanup", "scenario": "timer-replacement"}


def evaluate(run):
    evidence = json.loads((run / "evidence.json").read_text())
    need(evidence.get("business_verdict") ==
         {"status": "business-pass-before-cleanup", "scenario": "timer-replacement"},
         "business verdict absent before cleanup")
    result = evaluate_business(run)
    base = load_base(run)
    base_result = base.evaluate(run)
    need(base_result == {"status": "limited_pass", "scenario": "B"},
         "recovery B oracle failed")
    return {"status": "limited_pass", "scenario": "timer-replacement",
            "base": base_result, "business": result}


if __name__ == "__main__":
    try:
        print(json.dumps(evaluate(pathlib.Path(sys.argv[1])), sort_keys=True))
    except (ValueError, KeyError, TypeError, UnicodeError, OSError,
            json.JSONDecodeError, IndexError) as error:
        print(json.dumps({"status": "fail", "reason": str(error)}, sort_keys=True))
        raise SystemExit(1)
