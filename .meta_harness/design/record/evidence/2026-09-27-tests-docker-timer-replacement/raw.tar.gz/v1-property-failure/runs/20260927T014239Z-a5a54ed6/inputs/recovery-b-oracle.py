#!/usr/bin/env python3
"""Independent fail-closed reader for a single DK-I7/I9 recovery fixture run."""

import argparse
import json
import pathlib
import re
from datetime import datetime

HEX = re.compile(r"[0-9a-f]{64}\Z")


def need(value, message):
    if not value:
        raise ValueError(message)


def raw(run, commands, label, stream="stdout"):
    item = commands[label]
    path = run / item[stream]
    need(path.parent == run / "raw" and path.is_file(), label + " raw missing")
    return path.read_bytes()


def one_json(data, label):
    need(data.endswith(b"\n") and data.count(b"\n") == 1,
         label + " needs exactly one JSON+LF")
    result = json.loads(data[:-1].decode("utf-8", "strict"))
    need(isinstance(result, dict), label + " object required")
    return result


def whole_json_object(data, label):
    need(data.endswith(b"\n"), label + " complete JSON file with final LF required")

    def unique_object(pairs):
        value = {}
        for key, item in pairs:
            need(key not in value, label + " duplicate JSON key")
            value[key] = item
        return value

    result = json.loads(data.decode("utf-8", "strict"), object_pairs_hook=unique_object)
    need(isinstance(result, dict), label + " object required")
    return result


def command(run, commands, label, code=0):
    item = commands[label]
    need(item["returncode"] == code and item["observation_expired"] is False,
         label + " actual exit or observation")
    return one_json(raw(run, commands, label), label)


def inspect(run, commands, label, cid):
    item = commands[label]
    need(item["returncode"] == 0 and item["observation_expired"] is False,
         label + " inspect failed")
    value = json.loads(raw(run, commands, label).decode("utf-8", "strict"))
    need(isinstance(value, list) and len(value) == 1 and value[0]["Id"] == cid,
         label + " exact ID")
    return value[0]


def status(run, commands, label, cid, image_id, build_id, expected_state):
    value = command(run, commands, label)
    need(value["containerId"] == cid and value["imageId"] == image_id
         and value["buildId"] == build_id and value["state"] == expected_state,
         label + " actual image/BUILD/ID/status")
    return value


def start(run, commands, prefix, image_id, build_id, control, project):
    helper = ["docker", "exec", "-e",
              "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock", control,
              "/usr/local/libexec/omne-center"]
    for label, action in ((prefix + "-validate", "validate"),
                          (prefix + "-start", "start"),
                          (prefix + "-full-health", "full-health"),
                          (prefix + "-status-running", "status")):
        need(commands[label]["argv"][:len(helper) + 1] == [*helper, action],
             label + " not final helper in private Linux control")
    need(command(run, commands, prefix + "-validate") ==
         {"state": "deployment-structure-valid"}, prefix + " validation")
    result = command(run, commands, prefix + "-start")
    cid = result["containerId"]
    need(isinstance(cid, str) and HEX.fullmatch(cid)
         and result == {"state": "running", "containerId": cid,
                        "imageId": image_id, "buildId": build_id, "health": "healthy"},
         prefix + " start result")
    item = inspect(run, commands, prefix + "-inspect-running", cid)
    need(item["Image"] == image_id and item["State"]["Status"] == "running"
         and item["State"]["Running"] is True and item["State"]["Pid"] > 0
         and item["Config"]["Labels"]["ai.nemori.omne.project"] == project
         and item["Config"]["Labels"]["ai.nemori.omne.host-build-id"] == build_id,
         prefix + " actual running identity")
    health = command(run, commands, prefix + "-full-health")
    need(all(health.get(key) is True for key in ("reachable", "storageReachable",
         "clockSane", "deploymentKeyPresent", "deploymentKeyComplete"))
         and health.get("defectCount") == 0 and health.get("centerId"),
         prefix + " full-health")
    status(run, commands, prefix + "-status-running", cid, image_id, build_id, "running")
    return cid, health["centerId"]


def stop(run, commands, prefix, cid, image_id, build_id):
    need(command(run, commands, prefix) ==
         {"state": "stopped", "containerId": cid, "exitCode": 0, "clean": True},
         prefix + " confirmed stop")
    item = inspect(run, commands, prefix + "-inspect", cid)
    need(item["State"]["Status"] == "exited" and item["State"]["ExitCode"] == 0
         and item["State"]["Running"] is False, prefix + " actual exited0")
    status(run, commands, prefix + "-status", cid, image_id, build_id, "exited")
    return item


def cli_report(run, commands, label, control, expected_action):
    value = command(run, commands, label)
    argv = commands[label]["argv"]
    prefix = ["docker", "exec", "-e", "HOME=/tmp/omne-recovery-cli", control,
              "node", "/opt/omne-recovery-cli/app/dist/main.js", "machine",
              *expected_action, "--state-dir", "/tmp/omne-recovery-cli/state"]
    need(argv[:len(prefix)] == prefix and value.get("format") == "governance-client/1"
         and value.get("defect") is None, label + " public CLI provenance/report")
    remote = value.get("remote", {})
    need(remote.get("status") == "success" and value.get("view", {}).get("source") != "copy",
         label + " public CLI must return live confirmed result")
    return value


def result(report):
    value = report["remote"].get("reply", {}).get("reply", {}).get("result")
    need(value is not None, "confirmed CLI result absent")
    return value


def evaluate(run):
    evidence = json.loads((run / "evidence.json").read_text())
    commands = {entry["label"]: entry for entry in evidence["commands"]}
    need(len(commands) == len(evidence["commands"]), "duplicate command label")
    need(evidence["business_complete"] is True and evidence["status"] ==
         "observed-awaiting-oracle", "scenario did not finish")
    scenario = evidence["scenario"]
    expected = evidence["expected"]
    new = expected["images"]["new"]
    control = expected["control"]
    project = expected["project"]
    need(scenario in ("A", "B") and HEX.fullmatch(new["build_id"]), "scenario/new identity")
    for role, image in expected["images"].items():
        outer = inspect(run, commands, role + "-outer-image-inspect",
                        image["outer_image_id"])
        inner = inspect(run, commands, role + "-inner-image-inspect",
                        image["inner_image_id"])
        identities = raw(run, commands, role + "-inner-image-list").decode("ascii", "strict").splitlines()
        need(commands[role + "-inner-image-list"]["returncode"] == 0
             and commands[role + "-inner-image-list"]["argv"][-1] ==
             "label=ai.nemori.omne.host-build-id=" + image["build_id"]
             and sorted(set(identities)) == [image["inner_image_id"]],
             role + " exact private BUILD selected one image")
        need(outer["RootFS"]["Layers"] == inner["RootFS"]["Layers"]
             and outer["Os"] == inner["Os"] == "linux"
             and outer["Architecture"] == inner["Architecture"] == "arm64"
             and outer["Config"]["Labels"]["ai.nemori.omne.host-build-id"] == image["build_id"]
             and inner["Config"]["Labels"]["ai.nemori.omne.host-build-id"] == image["build_id"]
             and outer["Config"]["Labels"]["org.opencontainers.image.version"] ==
                 inner["Config"]["Labels"]["org.opencontainers.image.version"],
             role + " image import identity/layers")
        need(commands[role + "-load-image"]["returncode"] == 0,
             role + " private image load failed")
    if scenario == "A":
        cid, _ = start(run, commands, "a", new["inner_image_id"], new["build_id"],
                       control, project)
        stopped = stop(run, commands, "a-stop", cid, new["inner_image_id"],
                       new["build_id"])
        before_values = json.loads(raw(run, commands, "a-dind-before"))
        need(isinstance(before_values, list) and len(before_values) == 1
             and before_values[0]["Config"]["Labels"].get("omne.r5.helper-prep") ==
             evidence["run_id"], "old private dind label")
        before = before_values[0]
        after = inspect(run, commands, "a-dind-after", before["Id"])
        need(before["Id"] == after["Id"] and before["Mounts"] == after["Mounts"],
             "private daemon ID/volumes changed")
        need(commands["a-restart-private-dind"]["argv"] ==
             ["docker", "restart", expected["dind"]]
             and commands["a-restart-private-dind"]["returncode"] == 0,
             "only exact private dind may restart")
        snapshots = ["a-inspect-after-engine", *(label for label in commands
                     if re.fullmatch(r"a-observe-[1-9][0-9]*", label))]
        need(len(snapshots) >= 3 and "a-status-after-engine" in commands,
             "finite post-restart observation missing")
        samples = [label for label in snapshots if label.startswith("a-observe-")]
        need(samples == [f"a-observe-{index}" for index in range(1, len(samples) + 1)],
             "observation sequence incomplete")
        first = datetime.fromisoformat(commands[samples[0]]["started_utc"])
        last = datetime.fromisoformat(commands[samples[-1]]["started_utc"])
        need((last - first).total_seconds() >=
             evidence["inputs"]["no_restart_observe_seconds"],
             "configured finite observation span not completed")
        for label in snapshots:
            item = inspect(run, commands, label, cid)
            need(item["State"]["Status"] == "exited"
                 and item["State"]["ExitCode"] == 0
                 and item["State"]["StartedAt"] == stopped["State"]["StartedAt"]
                 and item["RestartCount"] == stopped["RestartCount"],
                 label + " center revived or changed")
        status(run, commands, "a-status-after-engine", cid, new["inner_image_id"],
               new["build_id"], "exited")
        need(commands["a-events"]["returncode"] == 0, "event query failed")
        need(commands["a-events"]["argv"][:7] ==
             ["docker", "exec", control, "docker", "--host",
              "unix:///opt/omne-private-docker/docker.sock", "events"]
             and f"container={cid}" in commands["a-events"]["argv"],
             "event query private Engine/exact container")
        events = [json.loads(line) for line in raw(run, commands, "a-events").splitlines()]
        need(all(event.get("Actor", {}).get("ID") == cid for event in events)
             and not any(event.get("Action") == "start" for event in events),
             "center start event after private daemon restart")
    else:
        old = expected["images"]["old"]
        need(commands["b-add-qa-credential-policy"]["argv"] ==
             ["docker", "exec", "-i", control, "sh", "-c",
              "cat >> /var/lib/omne-tenancy/settings.env"]
             and commands["b-add-qa-credential-policy"]["returncode"] == 0
             and raw(run, commands, "b-add-qa-credential-policy") == b""
             and raw(run, commands, "b-qa-policy-stat") == b"regular file:0:0:600\n"
             and raw(run, commands, "b-qa-policy-tail") ==
             b'OMNE_TENANCY_CREDENTIAL_POLICY={"minLength":12}\n',
             "explicit private QA credential policy before registration")
        order = [item["label"] for item in evidence["commands"]]
        need(order.index("b-qa-policy-tail") < order.index("b-old-validate")
             < order.index("b-old-start") < order.index("b-cli-register"),
             "QA policy must precede old center start and public registration")
        cid, old_center = start(run, commands, "b-old", old["inner_image_id"],
                                old["build_id"], control, project)
        need(command(run, commands, "b-new-validate") ==
             {"state": "deployment-structure-valid"}, "new image validation")
        cli = lambda label, action: cli_report(run, commands, label, control, action)
        configured = command(run, commands, "b-cli-configure")
        configure_argv = commands["b-cli-configure"]["argv"]
        address = evidence["private_dind_ip"]
        need(configured.get("format") == "governance-client/1"
             and configure_argv[:8] ==
             ["docker", "exec", "-e", "HOME=/tmp/omne-recovery-cli", control,
              "node", "/opt/omne-recovery-cli/app/dist/main.js", "machine"]
             and configure_argv[-4:] ==
             ["--endpoint", f"https://{address}:18443", "--ca-file",
              "/var/lib/omne-tenancy/secrets/tls-chain.pem"],
             "private public-CLI configure")
        need(raw(run, commands, "b-cli-build-id").strip().decode() ==
             evidence["inputs"]["cli_build_id"]
             and raw(run, commands, "b-control-node-version").strip() == b"v24.21.0",
             "final CLI/control Node identity")
        health_before = cli("b-cli-health-before", ["center", "health"])
        personal = result(cli("b-cli-personal-before", ["tenant", "current"]))
        organization = result(cli("b-cli-create-team", ["organization", "create"]))
        need(isinstance(organization, str) and organization, "confirmed team ID")
        current_before = result(cli("b-cli-current-before", ["tenant", "current"]))
        list_before = result(cli("b-cli-list-before", ["tenant", "list"]))
        team = {"organization": organization, "account": personal["account"]}
        need(current_before == team and team in list_before,
             "confirmed selected tenant/fact before replacement")
        for label in ("b-cli-personal-before", "b-cli-current-before", "b-cli-list-before",
                      "b-cli-current-after", "b-cli-list-after"):
            need("--refresh" in commands[label]["argv"], label + " must be live refresh")
        for label in ("b-cli-register", "b-cli-login"):
            cli(label, [label.removeprefix("b-cli-")])
            need("--credential-file" in commands[label]["argv"]
                 and "--login-identifier" in commands[label]["argv"],
                 label + " credential-file public CLI")
        cli("b-cli-switch", ["tenant", "switch"])
        stopped_old = stop(run, commands, "b-old-stop", cid, old["inner_image_id"],
                           old["build_id"])
        need(commands["b-old-logs"]["returncode"] == 0
             and commands["b-old-logs"]["argv"][-2:] == ["logs", cid],
             "old actual logs provenance")
        started = command(run, commands, "b-new-start")
        new_cid = started["containerId"]
        need(HEX.fullmatch(new_cid) and new_cid != cid
             and started == {"state": "running", "containerId": new_cid,
                             "imageId": new["inner_image_id"], "buildId": new["build_id"],
                             "health": "healthy"}, "actual new image/BUILD/ID")
        new_item = inspect(run, commands, "b-new-inspect", new_cid)
        need(new_item["Image"] == new["inner_image_id"]
             and new_item["State"]["Status"] == "running", "new actual container")
        status(run, commands, "b-new-status", new_cid, new["inner_image_id"],
               new["build_id"], "running")
        new_health = command(run, commands, "b-new-full-health")
        need(new_health["centerId"] == old_center and new_health["defectCount"] == 0
             and all(new_health.get(key) is True for key in
                     ("reachable", "storageReachable", "clockSane",
                      "deploymentKeyPresent", "deploymentKeyComplete")),
             "centerId/health changed")
        health_after = cli("b-cli-health-after", ["center", "health"])
        current_after = result(cli("b-cli-current-after", ["tenant", "current"]))
        list_after = result(cli("b-cli-list-after", ["tenant", "list"]))
        need(health_before["remote"]["health"]["centerId"] ==
             health_after["remote"]["health"]["centerId"] == old_center
             and current_after == current_before and list_after == list_before,
             "public CLI confirmed center/tenant facts changed")
        directory = evidence["operations_directory"]
        export_stderr = raw(run, commands, "b-new-start", "stderr")
        match = re.search(rb"operations-exported container=([0-9a-f]{64}) directory=(\S+)",
                          export_stderr)
        need(match and match.group(1).decode() == cid
             and match.group(2).decode("ascii") == directory
             and b"center-start-request" in export_stderr
             and match.end() < export_stderr.index(b"center-start-request"),
             "operations path must come from the helper's actual export")
        need(directory.startswith(expected["state"] + "/operations/")
             and raw(run, commands, "b-operations-parent-stat") == b"directory:0:0:700\n"
             and raw(run, commands, "b-operations-dir-stat") == b"directory:0:0:700\n",
             "helper operations directory identity/mode")
        need(commands["b-operations-parent-stat"]["argv"] ==
             ["docker", "exec", control, "stat", "-c", "%F:%u:%g:%a",
              expected["state"] + "/operations"], "operations parent path")
        need(commands["b-operations-dir-stat"]["argv"] ==
             ["docker", "exec", control, "stat", "-c", "%F:%u:%g:%a", directory],
             "operations directory probe path")
        need(raw(run, commands, "b-write-credential-stat") == b"regular file:0:0:600\n",
             "private CLI credential file mode/owner")
        for name in ("stdout.log", "stderr.log", "metadata.json"):
            need(commands["b-export-stat-" + name]["argv"] ==
                 ["docker", "exec", control, "stat", "-c", "%F:%u:%g:%a:%s",
                  directory + "/" + name]
                 and commands["b-export-content-" + name]["argv"] ==
                 ["docker", "exec", control, "cat", directory + "/" + name],
                 name + " exact helper operations path")
            stat = raw(run, commands, "b-export-stat-" + name).decode().strip().split(":")
            content = raw(run, commands, "b-export-content-" + name)
            kind = stat[0] if stat else ""
            need(commands["b-export-stat-" + name]["returncode"] == 0
                 and len(stat) == 5
                 and kind in ("regular file", "regular empty file")
                 and stat[1:4] == ["0", "0", "600"]
                 and int(stat[4]) == len(content)
                 and (kind != "regular empty file" or len(content) == 0)
                 and (name != "metadata.json" or kind == "regular file"),
                 name + " private exported file")
        need(raw(run, commands, "b-export-content-stdout.log") ==
             raw(run, commands, "b-old-logs"), "product-exported stdout differs")
        need(raw(run, commands, "b-export-content-stderr.log") ==
             raw(run, commands, "b-old-logs", "stderr"),
             "product-exported stderr differs")
        metadata = whole_json_object(raw(run, commands, "b-export-content-metadata.json"),
                                     "operations metadata")
        need(set(metadata) == {"containerId", "imageId", "version", "buildId",
                               "status", "exitCode", "finishedAt"},
             "operations metadata exact fields")
        need(metadata["containerId"] == cid and metadata["imageId"] == old["inner_image_id"]
             and metadata["buildId"] == old["build_id"]
             and metadata["status"] == "exited" and metadata["exitCode"] == 0
             and metadata["finishedAt"] == stopped_old["State"]["FinishedAt"],
             "helper must export old actual identity/terminal metadata")
        stop(run, commands, "b-new-stop", new_cid, new["inner_image_id"],
             new["build_id"])
    need(evidence["cleanup_complete"] is True and evidence["cleanup_errors"] == [],
         "fixture cleanup incomplete")
    cleanup = {item["label"]: item for item in evidence["cleanup_commands"]}
    need(len(cleanup) == len(evidence["cleanup_commands"]), "duplicate cleanup labels")
    for suffix in ("container", "volume", "network"):
        label = "cleanup-final-list-" + suffix
        need(cleanup[label]["returncode"] == 0
             and (run / cleanup[label]["stdout"]).read_bytes() == b"",
             label + " exact-label resources remain")
    for label in ("cleanup-inner-project-final-list", "cleanup-inner-fixture-final-list",
                  "cleanup-inner-all-final-list"):
        need(cleanup[label]["returncode"] == 0
             and (run / cleanup[label]["stdout"]).read_bytes() == b"",
             label + " private Engine resources remain")
    return {"status": "limited_pass", "scenario": scenario}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=pathlib.Path)
    args = parser.parse_args()
    try:
        print(json.dumps(evaluate(args.run), sort_keys=True))
    except (ValueError, KeyError, TypeError, UnicodeError, OSError, json.JSONDecodeError) as error:
        print(json.dumps({"status": "fail", "reason": str(error)}, sort_keys=True))
        raise SystemExit(1)
