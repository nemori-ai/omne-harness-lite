#!/usr/bin/env python3
"""Root-gated, single-scenario recovery observation in an exact-label private DinD."""

import argparse
import hashlib
import json
import pathlib
import re
import secrets
import shutil
import subprocess
import sys
import time

import fixture

HERE = pathlib.Path(__file__).resolve().parent
IMAGE = re.compile(r"sha256:[0-9a-f]{64}\Z")
HEX = re.compile(r"[0-9a-f]{64}\Z")


def need(value, message):
    if not value:
        raise RuntimeError(message)


def one_json(data, label):
    return fixture.parse_json_line(data, label)


def safe_cli_name(name):
    return (isinstance(name, str)
            and re.fullmatch(r"[a-z0-9][a-z0-9.-]*", name) is not None
            and ".." not in name and not name.endswith("."))


class RecoveryRun(fixture.Run):
    def __init__(self, args, inputs):
        super().__init__(args, inputs)
        self.evidence["scenario"] = args.scenario
        for name in ("driver.py", "fixture.py"):
            shutil.copyfile(HERE / name, self.frozen / name)
            need(fixture.sha(self.frozen / name) == inputs["sha256"][name[:-3]],
                 name + " changed after review")
        if args.scenario == "B":
            self.cli_archive = self.frozen / "cli.tar.gz"
            shutil.copyfile(args.cli_tar, self.cli_archive)
            need(fixture.sha(self.cli_archive) == inputs["sha256"]["cli_tar"],
                 "frozen final CLI archive changed")
        self.publish_address = "127.0.0.1"
        self.save()

    def prepare_paths(self):
        super().prepare_paths()
        if self.args.scenario == "B":
            # Public CLI registration has a deployment-owned credential policy.
            # This QA-only value is explicit; the product's absent-policy behavior stays intact.
            setting = b'OMNE_TENANCY_CREDENTIAL_POLICY={"minLength":12}\n'
            self.outer("b-add-qa-credential-policy", "exec", "-i", self.control,
                       "sh", "-c", "cat >> " + fixture.SETTINGS, stdin=setting)
            self.control_exec("b-qa-policy-stat", "stat", "-c", "%F:%u:%g:%a",
                              fixture.SETTINGS)
            self.control_exec("b-qa-policy-tail", "tail", "-n", "1", fixture.SETTINGS)

    def import_images(self):
        images = [("new", self.args.new_image_tar, self.args.new_image_id,
                   self.args.new_build_id)]
        if self.args.scenario == "B":
            images.insert(0, ("old", self.args.old_image_tar, self.args.old_image_id,
                              self.args.old_build_id))
        expected = {}
        for role, tar, image_id, build_id in images:
            need(fixture.sha(tar) == self.evidence["inputs"]["sha256"][role + "_image_tar"],
                 role + " image tar changed")
            outer = json.loads(self.outer(role + "-outer-image-inspect", "image",
                                         "inspect", image_id))[0]
            need(outer["Id"] == image_id and outer["Os"] == "linux"
                 and outer["Architecture"] == "arm64", role + " outer identity/platform")
            self.outer(role + "-load-image", "exec", "-i", self.dind, "docker", "--host",
                       fixture.SOCKET, "load", stdin=tar, timeout=180)
            lines = sorted(set(self.inner(role + "-inner-image-list", "image", "ls", "-q",
                                          "--no-trunc", "--filter",
                                          f"label=ai.nemori.omne.host-build-id={build_id}")
                               .decode("ascii", "strict").splitlines()))
            need(len(lines) == 1 and IMAGE.fullmatch(lines[0]),
                 role + " private BUILD identity ambiguous")
            inner_id = lines[0]
            inner = json.loads(self.inner(role + "-inner-image-inspect", "image", "inspect",
                                         inner_id))[0]
            need(inner["Id"] == inner_id
                 and inner["RootFS"]["Layers"] == outer["RootFS"]["Layers"]
                 and inner["Os"] == "linux" and inner["Architecture"] == "arm64",
                 role + " private image identity/layers/platform")
            for item in (outer, inner):
                labels = item["Config"]["Labels"]
                need(labels["ai.nemori.omne.host-build-id"] == build_id
                     and labels["ai.nemori.omne.distribution"] == "tenancy-host-docker/1",
                     role + " image labels")
            need(inner["Config"]["Labels"]["org.opencontainers.image.version"] ==
                 outer["Config"]["Labels"]["org.opencontainers.image.version"],
                 role + " imported version label changed")
            expected[role] = {"outer_image_id": image_id, "inner_image_id": inner_id,
                              "build_id": build_id}
        self.evidence["expected"] = {"images": expected, "project": self.project,
                                     "control": self.control, "dind": self.dind,
                                     "state": fixture.STATE, "uid": self.args.uid,
                                     "gid": self.args.gid}
        self.image_id = expected["old" if self.args.scenario == "B" else "new"]["inner_image_id"]
        self.save()

    def deployment(self, image_id, **extra):
        values = ["--project", self.project, "--image", image_id,
                  "--state-dir", fixture.STATE, "--secrets-dir", fixture.SECRETS,
                  "--settings-file", fixture.SETTINGS, "--publish-address", self.publish_address,
                  "--publish-port", "18443", "--uid", str(self.args.uid),
                  "--gid", str(self.args.gid)]
        for key, value in extra.items():
            values += ["--" + key.replace("_", "-"), str(value)]
        return values

    def start(self, label, image_id, **extra):
        return one_json(self.helper(label, "start", *self.deployment(image_id, **extra),
                                    timeout=self.args.observe_seconds), label)

    def status(self, label):
        return one_json(self.helper(label, "status", "--project", self.project), label)

    def inspect(self, label, cid):
        values = json.loads(self.inner(label, "inspect", cid))
        need(isinstance(values, list) and len(values) == 1 and values[0]["Id"] == cid,
             label + " wrong ID")
        return values[0]

    def common_start(self, image_id, prefix):
        self.helper(prefix + "-validate", "validate", *self.deployment(image_id))
        started = self.start(prefix + "-start", image_id)
        cid = started["containerId"]
        need(HEX.fullmatch(cid), prefix + " start ID")
        self.inspect(prefix + "-inspect-running", cid)
        self.helper(prefix + "-full-health", "full-health", "--project", self.project)
        self.status(prefix + "-status-running")
        return cid

    def normal_stop(self, label, cid):
        result = one_json(self.helper(label, "stop", "--project", self.project,
                                      timeout=self.args.observe_seconds), label)
        need(result == {"state": "stopped", "containerId": cid,
                        "exitCode": 0, "clean": True}, label + " not confirmed clean")
        stopped = self.inspect(label + "-inspect", cid)
        need(stopped["State"]["Status"] == "exited"
             and stopped["State"]["ExitCode"] == 0, label + " actual state")
        self.status(label + "-status")
        return stopped

    def scenario_a(self):
        image_id = self.evidence["expected"]["images"]["new"]["inner_image_id"]
        cid = self.common_start(image_id, "a")
        stopped = self.normal_stop("a-stop", cid)
        prior = {"started_at": stopped["State"]["StartedAt"],
                 "restart_count": stopped["RestartCount"]}
        dind_before = json.loads(self.outer("a-dind-before", "inspect", self.dind))[0]
        need(dind_before["Id"] and dind_before["Config"]["Labels"].get(
            "omne.r5.helper-prep") == self.run_id, "private daemon identity")
        event_since = fixture.utc()
        self.outer("a-restart-private-dind", "restart", self.dind, timeout=120)
        dind_after = json.loads(self.outer("a-dind-after", "inspect", self.dind))[0]
        need(dind_after["Id"] == dind_before["Id"]
             and dind_after["Mounts"] == dind_before["Mounts"],
             "private daemon metadata/volume changed")
        for attempt in range(1, 61):
            data = self.inner(f"a-engine-ready-{attempt}", "version", "--format",
                              "{{.Client.Version}} {{.Server.Version}}", expected=None)
            if self.evidence["commands"][-1]["returncode"] == 0 and data.strip() == b"29.1.3 29.1.3":
                break
            time.sleep(1)
        else:
            raise RuntimeError("private Engine recovery unconfirmed")
        self.inspect("a-inspect-after-engine", cid)
        self.status("a-status-after-engine")
        current = self.inspect("a-observe-1", cid)
        deadline = time.monotonic() + self.args.no_restart_observe_seconds
        index = 1
        while True:
            need(current["State"]["Status"] == "exited"
                 and current["State"]["StartedAt"] == prior["started_at"]
                 and current["RestartCount"] == prior["restart_count"],
                 "center restarted during finite observation")
            if time.monotonic() >= deadline:
                # An earlier inspect can straddle the deadline. Start one final
                # observation after it so the raw start timestamps cover the budget.
                index += 1
                current = self.inspect(f"a-observe-{index}", cid)
                need(current["State"]["Status"] == "exited"
                     and current["State"]["StartedAt"] == prior["started_at"]
                     and current["RestartCount"] == prior["restart_count"],
                     "center restarted at final observation")
                break
            time.sleep(min(1, max(0, deadline - time.monotonic())))
            index += 1
            current = self.inspect(f"a-observe-{index}", cid)
        self.inner("a-events", "events", "--since", event_since,
                   "--until", fixture.utc(), "--filter", f"container={cid}",
                   "--format", "{{json .}}", timeout=20)
        self.evidence["business_complete"] = True
        self.save()

    def prepare_b_cli(self):
        dind = json.loads(self.outer("b-dind-network-inspect", "inspect", self.dind))[0]
        address = dind["NetworkSettings"]["Networks"][self.network]["IPAddress"]
        need(re.fullmatch(r"[0-9.]+", address), "private DinD IPv4 missing")
        self.publish_address = address
        self.evidence["private_dind_ip"] = address
        self.save()
        self.control_exec("b-generate-private-san-tls", "openssl", "req", "-x509",
                          "-newkey", "rsa:2048", "-sha256", "-nodes", "-days", "1",
                          "-subj", "/CN=localhost",
                          "-addext", f"subjectAltName=DNS:localhost,IP:127.0.0.1,IP:{address}",
                          "-keyout", fixture.SECRETS + "/tls-private.pem",
                          "-out", fixture.SECRETS + "/tls-chain.pem")
        self.control_exec("b-own-private-san-tls", "chown",
                          f"{self.args.uid}:{self.args.gid}",
                          fixture.SECRETS + "/tls-private.pem",
                          fixture.SECRETS + "/tls-chain.pem")
        self.control_exec("b-mode-private-san-tls", "chmod", "0600",
                          fixture.SECRETS + "/tls-private.pem",
                          fixture.SECRETS + "/tls-chain.pem")
        need(fixture.sha(self.cli_archive) == self.evidence["inputs"]["sha256"]["cli_tar"],
             "final CLI tar changed")
        self.control_exec("b-mkdir-cli", "install", "-d", "-m", "0700",
                          "/opt/omne-recovery-cli", "/tmp/omne-recovery-cli")
        self.copy("b-copy-cli", self.cli_archive, "/opt/omne-recovery-cli.tar.gz")
        self.control_exec("b-extract-cli", "tar", "-xzf",
                          "/opt/omne-recovery-cli.tar.gz", "-C", "/opt/omne-recovery-cli")
        need(self.control_exec("b-cli-build-id", "cat",
                               "/opt/omne-recovery-cli/app/BUILD_ID").strip().decode()
             == self.args.cli_build_id, "CLI BUILD_ID mismatch")
        need(self.control_exec("b-control-node-version", "node", "--version").strip()
             == b"v24.21.0", "private control Node version")

    def put_cli_file(self, label, name, data):
        need(safe_cli_name(name), "private CLI file name")
        path = "/tmp/omne-recovery-cli/" + name
        self.outer(label, "exec", "-i", self.control, "sh", "-c",
                   "umask 077; cat > " + path, stdin=data)
        self.control_exec(label + "-stat", "stat", "-c", "%F:%u:%g:%a", path)
        return path

    def cli(self, label, action, *, payload=None, login=None, credential=None, refresh=False):
        commands = {"configure": ["center", "configure"], "health": ["center", "health"],
                    "register": ["register"], "login": ["login"],
                    "create": ["organization", "create"],
                    "switch": ["tenant", "switch"],
                    "current": ["tenant", "current"], "list": ["tenant", "list"]}
        argv = ["docker", "exec", "-e", "HOME=/tmp/omne-recovery-cli", self.control,
                "node", "/opt/omne-recovery-cli/app/dist/main.js", "machine",
                *commands[action], "--state-dir", "/tmp/omne-recovery-cli/state"]
        if action == "configure":
            argv += ["--endpoint", f"https://{self.publish_address}:18443",
                     "--ca-file", fixture.SECRETS + "/tls-chain.pem"]
        else:
            if login is not None:
                argv += ["--login-identifier", login]
            if payload is not None:
                path = self.put_cli_file(label + "-payload", label + ".json",
                                         json.dumps(payload, sort_keys=True,
                                                    separators=(",", ":")).encode() + b"\n")
                argv += ["--payload-file", path]
            if credential is not None:
                argv += ["--credential-file", credential]
            if refresh:
                argv += ["--refresh"]
        report = one_json(self.call(label, argv, timeout=self.args.observe_seconds), label)
        need(report.get("format") == "governance-client/1"
             and report.get("defect") is None, label + " CLI report")
        return report

    @staticmethod
    def cli_result(report, label):
        result = report.get("remote", {}).get("reply", {}).get("reply", {}).get("result")
        need(report.get("remote", {}).get("status") == "success" and result is not None,
             label + " unconfirmed")
        return result

    def scenario_b(self):
        old = self.evidence["expected"]["images"]["old"]["inner_image_id"]
        new = self.evidence["expected"]["images"]["new"]["inner_image_id"]
        self.prepare_b_cli()
        cid = self.common_start(old, "b-old")
        self.cli("b-cli-configure", "configure")
        self.cli("b-cli-health-before", "health")
        login = "qa" + self.project
        secret = secrets.token_hex(18).encode()
        credential = self.put_cli_file("b-write-credential", "credential.secret", secret)
        self.cli("b-cli-register", "register", login=login, credential=credential)
        self.cli("b-cli-login", "login", login=login, credential=credential)
        personal = self.cli_result(self.cli("b-cli-personal-before", "current",
                                            payload={}, refresh=True),
                                   "personal tenant")
        organization = self.cli_result(self.cli("b-cli-create-team", "create",
                                                payload={"creationKey": "recovery-" + self.project}),
                                       "team creation")
        team = {"organization": organization, "account": personal["account"]}
        self.cli_result(self.cli("b-cli-switch", "switch",
                                 payload={"expectedTenant": personal,
                                          "targetTenant": team}), "tenant switch")
        self.cli("b-cli-current-before", "current", payload={}, refresh=True)
        self.cli("b-cli-list-before", "list", payload={}, refresh=True)
        self.normal_stop("b-old-stop", cid)
        self.inner("b-old-logs", "logs", cid)
        self.image_id = new
        self.helper("b-new-validate", "validate", *self.deployment(new))
        next_started = self.start("b-new-start", new)
        need(next_started["containerId"] != cid, "replacement did not change exact ID")
        new_cid = next_started["containerId"]
        self.inspect("b-new-inspect", new_cid)
        self.status("b-new-status")
        self.helper("b-new-full-health", "full-health", "--project", self.project)
        self.cli("b-cli-health-after", "health")
        self.cli("b-cli-current-after", "current", payload={}, refresh=True)
        self.cli("b-cli-list-after", "list", payload={}, refresh=True)
        stderr = (self.run / next(item["stderr"] for item in self.evidence["commands"]
                                  if item["label"] == "b-new-start")).read_bytes()
        match = re.search(rb"operations-exported container=([0-9a-f]{64}) directory=(\S+)", stderr)
        need(match and match.group(1).decode() == cid, "helper operations export missing")
        directory = match.group(2).decode("ascii", "strict")
        need(directory.startswith(fixture.STATE + "/operations/"), "export outside operations")
        self.evidence["operations_directory"] = directory
        self.save()
        self.control_exec("b-operations-parent-stat", "stat", "-c", "%F:%u:%g:%a",
                          fixture.STATE + "/operations")
        self.control_exec("b-operations-dir-stat", "stat", "-c", "%F:%u:%g:%a", directory)
        for name in ("stdout.log", "stderr.log", "metadata.json"):
            self.control_exec("b-export-stat-" + name, "stat", "-c", "%F:%u:%g:%a:%s",
                              directory + "/" + name)
            self.control_exec("b-export-content-" + name, "cat", directory + "/" + name)
        for item in self.evidence["commands"]:
            need(secret not in (self.run / item["stdout"]).read_bytes()
                 and secret not in (self.run / item["stderr"]).read_bytes(),
                 "generated credential leaked to recorded output")
        self.normal_stop("b-new-stop", new_cid)
        self.evidence["business_complete"] = True
        self.save()


def checked_inputs(args):
    paths = {"helper": args.helper_dir / "omne-center",
             "compose": args.helper_dir / "compose.yaml",
             "maintenance_compose": args.helper_dir / "compose.maintenance.yaml",
             "health": args.helper_dir / "health.mjs",
             "service": args.helper_dir / "omne-center-backup@.service",
             "timer": args.helper_dir / "omne-center-backup@.timer",
             "driver": HERE / "driver.py", "fixture": HERE / "fixture.py",
             "oracle": HERE / "oracle.py",
             "compose_binary": fixture.V0 / "docker-compose-linux-aarch64",
             "docker_cli": fixture.V0 / "extracted-bin/docker",
             "new_image_tar": args.new_image_tar,
             "new_manifest": args.new_manifest}
    if args.scenario == "B":
        need(args.cli_tar is not None and args.old_image_tar is not None
             and args.old_manifest is not None,
             "B requires frozen final CLI and old image")
        paths.update(old_image_tar=args.old_image_tar, old_manifest=args.old_manifest,
                     cli_tar=args.cli_tar)
    actual = {name: fixture.sha(path) for name, path in paths.items()}
    required = ["helper", "compose", "maintenance_compose", "health", "service",
                "timer", "new_image_tar", "new_manifest"]
    if args.scenario == "B":
        required += ["old_image_tar", "old_manifest", "cli_tar"]
    for name in required:
        need(actual[name] == getattr(args, name + "_sha256"), name + " SHA changed")
    need(actual["compose_binary"] == fixture.COMPOSE_SHA
         and actual["docker_cli"] == fixture.CLI_SHA, "fixed fixture tool changed")
    need(IMAGE.fullmatch(args.new_image_id) and HEX.fullmatch(args.new_build_id), "new image identity")
    new_manifest = json.loads(args.new_manifest.read_text())
    need(new_manifest["images"]["arm64"]["imageId"] == args.new_image_id
         and new_manifest["archives"]["host"]["buildId"] == args.new_build_id,
         "new image/BUILD not in frozen manifest")
    if args.scenario == "B":
        need(IMAGE.fullmatch(args.old_image_id) and HEX.fullmatch(args.old_build_id)
             and HEX.fullmatch(args.cli_build_id)
             and args.old_image_id != args.new_image_id,
             "old/new artifact identities must be distinct")
        old_manifest = json.loads(args.old_manifest.read_text())
        need(old_manifest["images"]["arm64"]["imageId"] == args.old_image_id
             and old_manifest["archives"]["host"]["buildId"] == args.old_build_id
             and new_manifest["archives"]["cli"]["buildId"] == args.cli_build_id,
             "old image or final CLI not in frozen manifests")
    need(args.uid > 0 and args.gid > 0 and args.observe_seconds > 0
         and args.no_restart_observe_seconds > 0, "positive policies")
    return {"scenario": args.scenario,
            "paths": {key: str(value.resolve()) for key, value in paths.items()},
            "sha256": actual, "new_image_id": args.new_image_id,
            "new_build_id": args.new_build_id, "old_image_id": args.old_image_id,
            "old_build_id": args.old_build_id, "cli_build_id": args.cli_build_id,
            "uid": args.uid, "gid": args.gid,
            "observe_seconds": args.observe_seconds,
            "no_restart_observe_seconds": args.no_restart_observe_seconds}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=("A", "B"), required=True)
    parser.add_argument("--helper-dir", type=pathlib.Path, required=True)
    parser.add_argument("--new-image-tar", type=pathlib.Path, required=True)
    parser.add_argument("--new-manifest", type=pathlib.Path, required=True)
    parser.add_argument("--new-image-id", required=True)
    parser.add_argument("--new-build-id", required=True)
    parser.add_argument("--old-image-tar", type=pathlib.Path)
    parser.add_argument("--old-manifest", type=pathlib.Path)
    parser.add_argument("--old-image-id")
    parser.add_argument("--old-build-id")
    parser.add_argument("--cli-tar", type=pathlib.Path)
    parser.add_argument("--cli-build-id")
    for name in ("helper", "compose", "maintenance_compose", "health", "service", "timer",
                 "new_image_tar", "new_manifest", "old_image_tar", "old_manifest", "cli_tar"):
        parser.add_argument("--" + name.replace("_", "-") + "-sha256")
    parser.add_argument("--uid", type=int, default=10023)
    parser.add_argument("--gid", type=int, default=10024)
    parser.add_argument("--observe-seconds", type=int, default=600)
    parser.add_argument("--no-restart-observe-seconds", type=int, default=10)
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    inputs = checked_inputs(args)
    payload = json.dumps(inputs, sort_keys=True, separators=(",", ":")).encode()
    digest = hashlib.sha256(payload).hexdigest()
    if args.print_inputs:
        print(json.dumps({"inputs": inputs, "inputs_sha256": digest}, sort_keys=True))
        return 0
    need(args.execute and args.reviewed_gate is not None,
         "explicit execute and root-reviewed gate required")
    gate = json.loads(args.reviewed_gate.read_text())
    need(gate.get("approved") is True and gate.get("reviewer") == "root"
         and gate.get("inputs_sha256") == digest
         and gate.get("driver_sha256") == inputs["sha256"]["driver"]
         and gate.get("fixture_sha256") == inputs["sha256"]["fixture"]
         and gate.get("oracle_sha256") == inputs["sha256"]["oracle"], "stale or missing gate")
    run = RecoveryRun(args, inputs)
    try:
        run.setup()
        run.import_images()
        run.prepare_paths()
        if args.scenario == "A":
            run.scenario_a()
        else:
            run.scenario_b()
        run.evidence["status"] = "observed-awaiting-oracle"
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
    finally:
        run.save()
        run.cleanup()
    with (run.run / "oracle.stdout").open("xb") as out, (
            run.run / "oracle.stderr").open("xb") as err:
        checked = subprocess.run([sys.executable, str(run.frozen / "oracle.py"), str(run.run)],
                                 stdout=out, stderr=err)
    print(json.dumps({"run": str(run.run), "status": run.evidence["status"],
                      "cleanup_complete": run.evidence["cleanup_complete"],
                      "oracle_exit": checked.returncode}, sort_keys=True))
    return 0 if checked.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
