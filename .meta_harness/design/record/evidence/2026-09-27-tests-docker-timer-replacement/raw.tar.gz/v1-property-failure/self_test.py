#!/usr/bin/env python3
"""Offline oracle controls using B's accepted raw facts plus synthetic timer records."""

import copy
import hashlib
import json
import pathlib
import tempfile
from types import SimpleNamespace

import oracle
import driver

HERE = pathlib.Path(__file__).resolve().parent
SOURCE = pathlib.Path(
    "/Users/pandazki/Codes/omne-harness-lite/.worktrees/agent-work-loop-docker-recovery/tmp/docker-recovery"
)
ACTUAL = SOURCE / "runs/20260926T205742Z-45affc19"


def need(value, message):
    if not value:
        raise RuntimeError(message)


def main():
    original = json.loads((ACTUAL / "evidence.json").read_text())
    need(original["scenario"] == "B" and original["business_complete"] is True,
         "accepted recovery B raw fixture missing")
    with tempfile.TemporaryDirectory(prefix="self-test-", dir=HERE) as temporary:
        run = pathlib.Path(temporary)
        raw = run / "raw"
        frozen = run / "inputs"
        raw.mkdir()
        frozen.mkdir()
        (frozen / "recovery-b-oracle.py").symlink_to(SOURCE / "oracle.py")
        for source in (ACTUAL / "raw").iterdir():
            (raw / source.name).symlink_to(source)
        evidence = copy.deepcopy(original)
        evidence["inputs"]["qa_timer_override_sha256"] = hashlib.sha256(
            oracle.QA_OVERRIDE
        ).hexdigest()
        control = evidence["expected"]["control"]
        project = evidence["expected"]["project"]
        timer = f"omne-center-backup@{project}.timer"
        service = f"omne-center-backup@{project}.service"

        def record(label, argv, data=b""):
            out = raw / (label + ".stdout")
            err = raw / (label + ".stderr")
            out.write_bytes(data)
            err.write_bytes(b"")
            return {"label": label, "argv": argv, "stdout": "raw/" + out.name,
                    "stderr": "raw/" + err.name, "returncode": 0,
                    "observation_expired": False}

        def systemctl(label, verb, unit=timer):
            return record(label, ["docker", "exec", control, "systemctl", verb, unit])

        def show(label, unit, properties, data):
            return record(label, ["docker", "exec", control, "systemctl", "show",
                                  "--all", unit,
                                  *("--property=" + name for name in properties)],
                          "".join(f"{key}={data[key]}\n" for key in properties).encode())

        def snapshot(prefix, active):
            timer_data = {
                "ActiveState": "active" if active else "inactive",
                "SubState": "waiting" if active else "dead",
                "FragmentPath": "/etc/systemd/system/omne-center-backup@.timer",
                "DropInPaths": "/etc/systemd/system/omne-center-backup@.timer.d/r5-qa.conf",
                "Unit": service,
                "TimersCalendar": "",
                "TimersMonotonic": "{ OnActiveUSec=10min ; next_elapse=n/a }",
                "Persistent": "no",
                "LastTriggerUSec": "n/a",
                "NextElapseUSecMonotonic": "10min" if active else "n/a",
            }
            service_data = {"ActiveState": "inactive", "SubState": "dead",
                            "Result": "success", "ExecMainStartTimestampMonotonic": "0",
                            "InvocationID": ""}
            return [show(prefix + "-timer", timer, oracle.TIMER_PROPERTIES, timer_data),
                    show(prefix + "-service", service, oracle.SERVICE_PROPERTIES,
                         service_data)]

        def clone(label, old_label):
            source = next(item for item in original["commands"] if item["label"] == old_label)
            argv = source["argv"][:]
            (raw / (label + ".stdout")).symlink_to(ACTUAL / source["stdout"])
            (raw / (label + ".stderr")).symlink_to(ACTUAL / source["stderr"])
            return {**source, "label": label, "argv": argv,
                    "stdout": "raw/" + label + ".stdout",
                    "stderr": "raw/" + label + ".stderr"}

        dropin = "/etc/systemd/system/omne-center-backup@.timer.d/r5-qa.conf"
        setup = [record("t-write-qa-600s-dropin", ["docker", "exec", "-i", control,
                                                  "tee", dropin], oracle.QA_OVERRIDE),
                 record("t-read-qa-600s-dropin", ["docker", "exec", control, "cat",
                                                 dropin], oracle.QA_OVERRIDE),
                 record("t-reload-600s", ["docker", "exec", control, "systemctl",
                                          "daemon-reload"])]
        for filename, key in (("omne-center-backup@.timer", "timer"),
                              ("omne-center-backup@.service", "service")):
            installed = "/etc/systemd/system/" + filename
            setup.append(record("t-installed-sha-" + filename,
                                ["docker", "exec", control, "sha256sum", installed],
                                f'{evidence["inputs"]["sha256"][key]}  {installed}\n'.encode()))
        unit_text = b"# original\n" + (SOURCE / "runs/20260926T205742Z-45affc19/inputs/omne-center-backup@.timer").read_bytes()
        unit_text += b"# override\n" + oracle.QA_OVERRIDE
        old = [record("t-unit-cat", ["docker", "exec", control, "systemctl", "cat",
                                      timer], unit_text),
               *snapshot("t-before-activation", False),
               systemctl("t-start-old-timer", "start"),
               *snapshot("t-old-active", True),
               clone("t-new-validate-before-stop", "b-new-validate"),
               clone("t-old-inspect-after-validation", "b-old-inspect-running"),
               clone("t-old-status-after-validation", "b-old-status-running"),
               *snapshot("t-after-validation", True),
               systemctl("t-stop-old-timer", "stop"),
               *snapshot("t-old-inactive", False)]
        final = [*snapshot("t-before-resume", False),
                 systemctl("t-resume-timer", "start"),
                 *snapshot("t-resumed", True),
                 systemctl("t-stop-final-timer", "stop"),
                 *snapshot("t-final-inactive", False),
                 record("t-service-journal", ["docker", "exec", control, "journalctl",
                                               "-u", service, "--no-pager", "--output=cat"])]
        entries = []
        for item in original["commands"]:
            if item["label"] == "b-old-validate":
                entries.extend(setup)
            if item["label"] == "b-old-stop":
                entries.extend(old)
            if item["label"] == "b-new-stop":
                entries.extend(final)
            entries.append(item)
        evidence["commands"] = entries

        def check(candidate):
            (run / "evidence.json").write_text(json.dumps(candidate))
            return oracle.evaluate_business(run)

        verdict = check(evidence)
        need(verdict["status"] == "business-pass-before-cleanup",
             "synthetic positive timer transcript rejected")
        evidence["business_verdict"] = verdict
        (run / "evidence.json").write_text(json.dumps(evidence))
        need(oracle.evaluate(run)["status"] == "limited_pass",
             "combined B/timer oracle rejected synthetic positive")
        replay = SimpleNamespace(run=run, evidence=evidence,
                                 cli_result=driver.TimerRun.cli_result)
        driver.TimerRun.require_replacement_ready(replay)
        rejected = []

        def mutation(name, change):
            candidate = copy.deepcopy(evidence)
            restore = change(candidate)
            try:
                check(candidate)
            except (ValueError, KeyError, IndexError):
                rejected.append(name)
            else:
                raise RuntimeError(name + " false pass")
            finally:
                if restore is not None:
                    restore()

        def wrong_order(candidate):
            entries = candidate["commands"]
            at = next(i for i, item in enumerate(entries)
                      if item["label"] == "t-new-validate-before-stop")
            value = entries.pop(at)
            after_stop = next(i for i, item in enumerate(entries)
                              if item["label"] == "t-stop-old-timer")
            entries.insert(after_stop + 1, value)

        def wrong_image(candidate):
            item = next(x for x in candidate["commands"]
                        if x["label"] == "t-new-validate-before-stop")
            item["argv"][item["argv"].index("--image") + 1] = (
                candidate["expected"]["images"]["old"]["inner_image_id"]
            )

        def replace_raw(label, original_bytes, changed):
            path = raw / (label + ".stdout")
            path.write_bytes(changed)
            return lambda: path.write_bytes(original_bytes)

        mutation("validate-after-timer-stop", wrong_order)
        mutation("wrong-new-image", wrong_image)
        active_path = raw / "t-old-active-timer.stdout"
        active_bytes = active_path.read_bytes()
        mutation("not-active", lambda _: replace_raw(
            "t-old-active-timer", active_bytes,
            active_bytes.replace(b"ActiveState=active", b"ActiveState=inactive")))
        resumed_path = raw / "t-resumed-timer.stdout"
        resumed_bytes = resumed_path.read_bytes()
        mutation("timer-triggered", lambda _: replace_raw(
            "t-resumed-timer", resumed_bytes,
            resumed_bytes.replace(b"LastTriggerUSec=n/a", b"LastTriggerUSec=123")))
        mutation("service-invoked", lambda _: replace_raw(
            "t-service-journal", b"", b"service ran\n"))
        health_path = raw / "b-new-full-health.stdout"
        health_source = health_path.resolve()
        health_path.unlink()
        bad_health = json.loads(health_source.read_text())
        bad_health["defectCount"] = 1
        health_path.write_text(json.dumps(bad_health) + "\n")
        try:
            driver.TimerRun.require_replacement_ready(replay)
        except RuntimeError:
            rejected.append("premature-resume-with-unhealthy-center")
        else:
            raise RuntimeError("unhealthy pre-resume false pass")
        finally:
            health_path.unlink()
            health_path.symlink_to(health_source)
        need(len(rejected) == 6, "negative controls incomplete")
        return {"status": "offline_pass", "synthetic_positive": 1,
                "mutants_rejected": rejected, "docker_executed": False}


if __name__ == "__main__":
    print(json.dumps(main(), sort_keys=True))
