#!/usr/bin/env python3
"""Root-gated DK-I8 timer failure while this run's private Engine is offline."""

import argparse
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import sys
import time

import fixture

HERE = pathlib.Path(__file__).resolve().parent
HEX = re.compile(r"[0-9a-f]{64}\Z")
IMAGE = re.compile(r"sha256:[0-9a-f]{64}\Z")


def need(value, message):
    if not value:
        raise RuntimeError(message)


def one_json(data, name):
    return fixture.parse_json_line(data, name)


class OfflineTimerRun(fixture.Run):
    def __init__(self, args, inputs):
        super().__init__(args, inputs)
        for name, key in (("driver.py", "driver"), ("fixture.py", "fixture")):
            shutil.copyfile(HERE / name, self.frozen / name)
            need(fixture.sha(self.frozen / name) == inputs["sha256"][key],
                 "frozen tool changed: " + name)
        self.evidence["scenario"] = "DK-I8-private-engine-offline-timer"
        self.dind_offline = False
        self.timer_started = False
        self.save()

    def deployment(self):
        return ["--project", self.project, "--image", self.image_id,
                "--state-dir", fixture.STATE, "--secrets-dir", fixture.SECRETS,
                "--settings-file", fixture.SETTINGS, "--publish-address", "127.0.0.1",
                "--publish-port", "18443", "--uid", str(self.args.uid),
                "--gid", str(self.args.gid)]

    def inspect(self, label, cid):
        values = json.loads(self.inner(label, "inspect", cid))
        need(isinstance(values, list) and len(values) == 1 and values[0]["Id"] == cid,
             label + " exact center inspect")
        return values[0]

    def systemd_state(self, label, unit, properties):
        data = self.control_exec(label, "systemctl", "show", unit,
                                 *("--property=" + name for name in properties))
        lines = data.decode("utf-8", "strict").splitlines()
        need(all("=" in line for line in lines), label + " malformed systemd state")
        values = dict(line.split("=", 1) for line in lines)
        need(len(values) == len(lines), label + " duplicate property")
        return values

    def wait_engine_ready(self, prefix):
        for attempt in range(1, 61):
            data = self.inner(f"{prefix}-{attempt}", "version", "--format",
                              "{{.Client.Version}} {{.Server.Version}}", expected=None)
            if (self.evidence["commands"][-1]["returncode"] == 0 and
                    data.strip() == b"29.1.3 29.1.3"):
                return
            time.sleep(1)
        raise RuntimeError("private Engine did not recover for fixture inspection/cleanup")

    def restart_private_for_cleanup(self):
        if not self.dind_offline:
            return
        before = self.evidence["expected"]["dind_id"]
        self.outer("fixture-explicit-start-private-dind", "start", self.dind, timeout=120)
        self.dind_offline = False
        after = json.loads(self.outer("fixture-dind-after-explicit-start", "inspect", self.dind))[0]
        need(after["Id"] == before and after["State"]["Status"] == "running"
             and after["Config"]["Labels"].get("omne.r5.helper-prep") == self.run_id,
             "fixture started wrong private Engine")
        self.wait_engine_ready("fixture-engine-ready")

    def timer_observation(self):
        timer = f"omne-center-backup@{self.project}.timer"
        service = f"omne-center-backup@{self.project}.service"
        self.control_exec("t-stop-old-timer", "systemctl", "stop", timer)
        prior_timer = self.systemd_state("t-timer-before", timer, ("LastTriggerUSec",))
        prior_service = self.systemd_state("t-service-before", service,
                                           ("ExecMainStartTimestampMonotonic",))
        self.control_exec("t-installed-service-file", "cat",
                          "/etc/systemd/system/omne-center-backup@.service")
        self.control_exec("t-installed-timer-file", "cat",
                          "/etc/systemd/system/omne-center-backup@.timer")
        self.control_exec("t-qa-timer-dropin", "cat",
                          "/etc/systemd/system/omne-center-backup@.timer.d/r5-qa.conf")
        self.systemd_state("t-service-dependencies", service,
                           ("Wants", "Requires", "BindsTo", "After"))
        self.control_exec("t-start-timer", "systemctl", "start", timer)
        self.timer_started = True
        deadline = time.monotonic() + self.args.timer_observe_seconds
        for attempt in range(1, self.args.timer_observe_seconds * 2 + 2):
            timer_state = self.systemd_state(f"t-timer-poll-{attempt}", timer,
                                             ("LastTriggerUSec",))
            service_state = self.systemd_state(f"t-service-poll-{attempt}", service,
                                               ("ExecMainStartTimestampMonotonic", "ActiveState"))
            if (timer_state.get("LastTriggerUSec", "n/a") not in ("", "n/a")
                    and timer_state["LastTriggerUSec"] != prior_timer.get("LastTriggerUSec")
                    and service_state.get("ExecMainStartTimestampMonotonic", "0") !=
                    prior_service.get("ExecMainStartTimestampMonotonic", "0")
                    and service_state.get("ActiveState") in ("inactive", "failed")):
                break
            if time.monotonic() >= deadline:
                raise RuntimeError("private Engine offline timer observation expired")
            time.sleep(0.5)
        else:
            raise RuntimeError("private Engine offline timer observation expired")
        # Snapshot completed service while the active timer still keeps its unit loaded.
        final = self.systemd_state("t-service-final", service,
                                   ("Result", "ExecMainStatus", "ActiveState",
                                    "ExecMainStartTimestampMonotonic",
                                    "ExecMainExitTimestampMonotonic"))
        self.systemd_state("t-timer-final", timer, ("LastTriggerUSec",))
        self.control_exec("t-service-journal", "journalctl", "-u", service,
                          "--no-pager", "--output=cat")
        self.control_exec("t-stop-timer", "systemctl", "stop", timer)
        self.timer_started = False
        need(final.get("Result") == "exit-code" and
             final.get("ExecMainStatus", "0").isdigit() and
             int(final["ExecMainStatus"]) > 0,
             "timer service did not visibly fail")

    def scenario(self):
        self.helper("t-validate", "validate", *self.deployment())
        started = one_json(self.helper("t-start-center", "start", *self.deployment(),
                                       timeout=self.args.observe_seconds), "t-start-center")
        cid = started["containerId"]
        need(HEX.fullmatch(cid) and started["state"] == "running"
             and started["imageId"] == self.image_id, "center startup identity")
        self.inspect("t-inspect-running", cid)
        self.helper("t-full-health", "full-health", "--project", self.project)
        self.helper("t-status-running", "status", "--project", self.project)
        stopped = one_json(self.helper("t-stop-center", "stop", "--project", self.project,
                                       timeout=self.args.observe_seconds), "t-stop-center")
        need(stopped == {"state": "stopped", "containerId": cid,
                         "exitCode": 0, "clean": True}, "supported stop unconfirmed")
        before = self.inspect("t-center-before-engine-stop", cid)
        need(before["State"]["Status"] == "exited" and before["State"]["ExitCode"] == 0,
             "center not actually exited0")
        self.helper("t-status-exited", "status", "--project", self.project)
        dind = json.loads(self.outer("t-dind-before-stop", "inspect", self.dind))[0]
        need(dind["Config"]["Labels"].get("omne.r5.helper-prep") == self.run_id
             and dind["State"]["Status"] == "running", "private DinD identity")
        self.evidence["expected"].update({"center_id": cid, "dind_id": dind["Id"],
                                          "center_started_at": before["State"]["StartedAt"],
                                          "center_restart_count": before["RestartCount"],
                                          "dind_started_at": dind["State"]["StartedAt"]})
        self.save()
        since = fixture.utc()
        self.evidence["offline_event_since"] = since
        self.save()
        self.outer("t-stop-private-dind", "stop", self.dind, timeout=120)
        self.dind_offline = True
        off = json.loads(self.outer("t-dind-offline-initial", "inspect", self.dind))[0]
        need(off["Id"] == dind["Id"] and off["State"]["Status"] == "exited"
             and off["State"]["StartedAt"] == dind["State"]["StartedAt"],
             "private DinD did not remain same exited instance")
        self.timer_observation()
        after = json.loads(self.outer("t-dind-offline-after-timer", "inspect", self.dind))[0]
        need(after["Id"] == dind["Id"] and after["State"]["Status"] == "exited"
             and after["State"]["StartedAt"] == dind["State"]["StartedAt"],
             "timer restarted private DinD")
        self.outer("t-control-after-timer", "inspect", self.control)
        self.outer("t-outer-private-container-list", "ps", "-aq", "--no-trunc",
                   "--filter", "label=" + self.label)
        self.outer("t-dind-offline-events", "events", "--since", since,
                   "--until", fixture.utc(), "--filter", "container=" + dind["Id"],
                   "--format", "{{json .}}", timeout=30)
        # A deliberate fixture action occurs only after all offline evidence is captured.
        self.restart_private_for_cleanup()
        current = self.inspect("t-center-after-explicit-recovery", cid)
        need(current["State"]["Status"] == "exited" and current["State"]["ExitCode"] == 0
             and current["State"]["StartedAt"] == before["State"]["StartedAt"]
             and current["RestartCount"] == before["RestartCount"],
             "explicit fixture Engine recovery changed stopped center")
        self.helper("t-status-after-explicit-recovery", "status", "--project", self.project)
        self.evidence["business_complete"] = True
        self.save()

    def settle_before_cleanup(self):
        if self.timer_started:
            timer = f"omne-center-backup@{self.project}.timer"
            service = f"omne-center-backup@{self.project}.service"
            try:
                self.systemd_state("fixture-timer-failure-state", timer,
                                   ("LastTriggerUSec", "ActiveState"))
                self.systemd_state("fixture-service-failure-state", service,
                                   ("Result", "ExecMainStatus", "ActiveState"))
                self.control_exec("fixture-service-failure-journal", "journalctl", "-u",
                                  service, "--no-pager", "--output=cat")
            except (RuntimeError, OSError, ValueError) as error:
                self.evidence["fixture_timer_diagnostic_error"] = str(error)
                self.save()
            try:
                self.control_exec("fixture-stop-timer-after-failure", "systemctl", "stop", timer)
                self.timer_started = False
            except (RuntimeError, OSError, ValueError) as error:
                self.evidence["fixture_timer_stop_error"] = str(error)
                self.save()
        if self.timer_started:
            # Reopening the private Engine could let an active timer retry a write.
            # Outer exact-label teardown remains available but outcome is unknown.
            self.evidence["fixture_engine_recovery_skipped"] = "timer not confirmed stopped"
            self.save()
            return
        if self.dind_offline:
            try:
                self.restart_private_for_cleanup()
            except (RuntimeError, OSError, ValueError) as error:
                self.evidence["fixture_engine_recovery_error"] = str(error)
                self.save()


def checked_inputs(args):
    paths = {"helper": args.helper_dir / "omne-center",
             "compose": args.helper_dir / "compose.yaml",
             "maintenance_compose": args.helper_dir / "compose.maintenance.yaml",
             "health": args.helper_dir / "health.mjs",
             "service": args.helper_dir / "omne-center-backup@.service",
             "timer": args.helper_dir / "omne-center-backup@.timer",
             "image_tar": args.image_tar, "manifest": args.manifest,
             "driver": HERE / "driver.py", "fixture": HERE / "fixture.py",
             "oracle": HERE / "oracle.py",
             "compose_binary": fixture.V0 / "docker-compose-linux-aarch64",
             "docker_cli": fixture.V0 / "extracted-bin/docker"}
    actual = {name: fixture.sha(path) for name, path in paths.items()}
    for name in ("helper", "compose", "maintenance_compose", "health", "service", "timer",
                 "image_tar", "manifest"):
        need(actual[name] == getattr(args, name + "_sha256"), name + " SHA changed")
    need(actual["compose_binary"] == fixture.COMPOSE_SHA
         and actual["docker_cli"] == fixture.CLI_SHA, "private fixture binary changed")
    need(IMAGE.fullmatch(args.image_id) and HEX.fullmatch(args.build_id), "image/build identity")
    manifest = json.loads(args.manifest.read_text())
    need(manifest["images"]["arm64"]["imageId"] == args.image_id
         and manifest["archives"]["host"]["buildId"] == args.build_id,
         "image/build absent from frozen manifest")
    need(args.uid > 0 and args.gid > 0 and args.timer_observe_seconds >= 90
         and args.observe_seconds > 0, "positive fixture observations")
    return {"scenario": "DK-I8-private-engine-offline-timer",
            "paths": {key: str(value.resolve()) for key, value in paths.items()},
            "sha256": actual, "image_id": args.image_id, "build_id": args.build_id,
            "uid": args.uid, "gid": args.gid,
            "timer_observe_seconds": args.timer_observe_seconds,
            "observe_seconds": args.observe_seconds}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--helper-dir", type=pathlib.Path, required=True)
    parser.add_argument("--image-tar", type=pathlib.Path, required=True)
    parser.add_argument("--manifest", type=pathlib.Path, required=True)
    parser.add_argument("--image-id", required=True)
    parser.add_argument("--build-id", required=True)
    for name in ("helper", "compose", "maintenance_compose", "health", "service", "timer",
                 "image_tar", "manifest"):
        parser.add_argument("--" + name.replace("_", "-") + "-sha256", required=True)
    parser.add_argument("--uid", type=int, default=10023)
    parser.add_argument("--gid", type=int, default=10024)
    parser.add_argument("--timer-observe-seconds", type=int, default=90)
    parser.add_argument("--observe-seconds", type=int, default=600)
    parser.add_argument("--reviewed-gate", type=pathlib.Path)
    parser.add_argument("--print-inputs", action="store_true")
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    inputs = checked_inputs(args)
    digest = hashlib.sha256(json.dumps(inputs, sort_keys=True,
                                       separators=(",", ":")).encode()).hexdigest()
    if args.print_inputs:
        print(json.dumps({"inputs": inputs, "inputs_sha256": digest}, sort_keys=True))
        return 0
    need(args.execute and args.reviewed_gate is not None,
         "explicit execute and root-reviewed gate required")
    gate = json.loads(args.reviewed_gate.read_text())
    need(gate.get("approved") is True and gate.get("reviewer") == "root"
         and gate.get("inputs_sha256") == digest
         and all(gate.get(key + "_sha256") == inputs["sha256"][key]
                 for key in ("driver", "fixture", "oracle")), "missing/stale review gate")
    run = OfflineTimerRun(args, inputs)
    try:
        run.setup()
        run.import_image()
        run.prepare_paths()
        run.scenario()
        run.evidence["status"] = "observed-awaiting-oracle"
    except BaseException as error:
        run.evidence["status"] = "observation-incomplete"
        run.evidence["error"] = f"{type(error).__name__}: {error}"
    finally:
        run.save()
        run.settle_before_cleanup()
        run.cleanup()
    with (run.run / "oracle.stdout").open("xb") as out, (
            run.run / "oracle.stderr").open("xb") as err:
        checked = subprocess.run([sys.executable, str(run.frozen / "oracle.py"), str(run.run)],
                                 stdout=out, stderr=err)
    print(json.dumps({"run": str(run.run), "status": run.evidence["status"],
                      "cleanup_complete": run.evidence["cleanup_complete"],
                      "oracle_exit": checked.returncode}, sort_keys=True))
    return 0 if checked.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
