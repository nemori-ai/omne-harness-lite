#!/usr/bin/env python3
"""Offline positive and mutation checks for the DK-I8 timer raw oracle."""

import json
import pathlib
import tempfile

import oracle

HERE = pathlib.Path(__file__).resolve().parent
CID = "a" * 64
DIND = "b" * 64
CONTROL_ID = "c" * 64
IMAGE = "sha256:" + "d" * 64
OUTER_IMAGE = "sha256:" + "e" * 64
BUILD = "f" * 64
CONTROL = "static-control"
DIND_NAME = "static-dind"
PROJECT = "r5static"
SOCKET = "unix:///opt/omne-private-docker/docker.sock"
RUN_ID = "static-offline-timer"


def encoded(value):
    return (json.dumps(value, separators=(",", ":")) + "\n").encode()


def make_run(parent):
    run = parent / "run"
    (run / "raw").mkdir(parents=True)
    (run / "inputs").mkdir()
    source = pathlib.Path("apps/tenancy-host/deploy/docker")
    for name in ("omne-center-backup@.service", "omne-center-backup@.timer"):
        (run / "inputs" / name).write_bytes((source / name).read_bytes())
    records, cleanup = [], []

    def add(label, stdout=b"", *, stderr=b"", rc=0, argv=None, cleaned=False):
        (run / "raw" / (label + ".stdout")).write_bytes(stdout)
        (run / "raw" / (label + ".stderr")).write_bytes(stderr)
        item = {"label": label, "stdout": "raw/" + label + ".stdout",
                "stderr": "raw/" + label + ".stderr", "returncode": rc,
                "observation_expired": False, "argv": argv or []}
        (cleanup if cleaned else records).append(item)

    helper = ["docker", "exec", "-e", "DOCKER_HOST=" + SOCKET, CONTROL,
              "/usr/local/libexec/omne-center"]
    add("t-validate", encoded({"state": "deployment-structure-valid"}),
        argv=helper + ["validate"])
    add("t-start-center", encoded({"state": "running", "containerId": CID,
                                   "imageId": IMAGE, "buildId": BUILD, "health": "healthy"}),
        argv=helper + ["start"])
    running = {"Id": CID, "Image": IMAGE,
               "Config": {"Labels": {"ai.nemori.omne.project": PROJECT,
                                      "ai.nemori.omne.host-build-id": BUILD}},
               "State": {"Status": "running", "Running": True, "Pid": 77,
                         "StartedAt": "2026-09-27T00:00:00Z", "ExitCode": 0},
               "RestartCount": 0}
    stopped = {**running, "State": {**running["State"], "Status": "exited",
                                        "Running": False, "Pid": 0, "ExitCode": 0}}
    add("t-inspect-running", encoded([running]))
    add("t-full-health", encoded({"reachable": True, "storageReachable": True,
                                  "clockSane": True, "deploymentKeyPresent": True,
                                  "deploymentKeyComplete": True, "defectCount": 0,
                                  "centerId": "center-static"}), argv=helper + ["full-health"])
    add("t-status-running", encoded({"state": "running", "containerId": CID,
                                     "imageId": IMAGE, "buildId": BUILD}),
        argv=helper + ["status"])
    add("t-stop-center", encoded({"state": "stopped", "containerId": CID,
                                  "exitCode": 0, "clean": True}), argv=helper + ["stop"])
    add("t-center-before-engine-stop", encoded([stopped]))
    exited_status = {"state": "exited", "containerId": CID, "imageId": IMAGE,
                     "buildId": BUILD, "exitCode": 0, "restartCount": 0}
    add("t-status-exited", encoded(exited_status), argv=helper + ["status"])
    mounts = [{"Type": "volume", "Name": "private-daemon"}]
    dind_running = {"Id": DIND, "Mounts": mounts,
                    "Config": {"Labels": {"omne.r5.helper-prep": RUN_ID}},
                    "State": {"Status": "running", "Running": True,
                              "StartedAt": "2026-09-27T00:00:00Z"}}
    dind_off = {**dind_running, "State": {**dind_running["State"],
                                           "Status": "exited", "Running": False}}
    dind_recovered = {**dind_running, "State": {**dind_running["State"],
                                                 "StartedAt": "2026-09-27T00:02:00Z"}}
    add("t-dind-before-stop", encoded([dind_running]))
    add("t-stop-private-dind", (DIND_NAME + "\n").encode(),
        argv=["docker", "stop", DIND_NAME])
    add("t-dind-offline-initial", encoded([dind_off]))
    add("t-stop-old-timer", argv=["docker", "exec", CONTROL, "systemctl", "stop",
                                  f"omne-center-backup@{PROJECT}.timer"])
    add("t-timer-before", b"LastTriggerUSec=n/a\n")
    add("t-service-before", b"ExecMainStartTimestampMonotonic=0\n")
    add("t-installed-service-file", (run / "inputs/omne-center-backup@.service").read_bytes())
    add("t-installed-timer-file", (run / "inputs/omne-center-backup@.timer").read_bytes())
    add("t-qa-timer-dropin", b"[Timer]\nOnCalendar=\nOnActiveSec=2s\nPersistent=false\n")
    add("t-service-dependencies", b"Wants=\nRequires=sysinit.target\nBindsTo=\nAfter=basic.target\n")
    add("t-start-timer", argv=["docker", "exec", CONTROL, "systemctl", "start",
                               f"omne-center-backup@{PROJECT}.timer"])
    add("t-service-final", b"Result=exit-code\nExecMainStatus=1\nActiveState=failed\n"
                           b"ExecMainStartTimestampMonotonic=500\n"
                           b"ExecMainExitTimestampMonotonic=600\n")
    add("t-timer-final", b"LastTriggerUSec=Sun 2026-09-27 00:01:00 UTC\n")
    add("t-service-journal", b"Starting backup\nomne-center: engine-unavailable\n"
        b"service: Failed with result 'exit-code'.\n")
    add("t-stop-timer", argv=["docker", "exec", CONTROL, "systemctl", "stop",
                              f"omne-center-backup@{PROJECT}.timer"])
    add("t-dind-offline-after-timer", encoded([dind_off]))
    add("t-control-after-timer", encoded([{"Id": CONTROL_ID,
        "Config": {"Labels": {"omne.r5.helper-prep": RUN_ID}},
        "State": {"Status": "running"}}]))
    add("t-outer-private-container-list", (CONTROL_ID + "\n" + DIND + "\n").encode())
    add("t-dind-offline-events", encoded({"Action": "die", "Actor": {"ID": DIND}}))
    add("fixture-explicit-start-private-dind", (DIND_NAME + "\n").encode(),
        argv=["docker", "start", DIND_NAME])
    add("fixture-dind-after-explicit-start", encoded([dind_recovered]))
    add("t-center-after-explicit-recovery", encoded([stopped]))
    add("t-status-after-explicit-recovery", encoded(exited_status),
        argv=helper + ["status"])
    add("outer-inspect-" + CONTROL, encoded([{"Id": CONTROL_ID,
        "State": {"Status": "running"}}]))
    for label in ("cleanup-final-list-container", "cleanup-final-list-volume",
                  "cleanup-final-list-network", "cleanup-inner-project-final-list",
                  "cleanup-inner-fixture-final-list", "cleanup-inner-all-final-list"):
        add(label, cleaned=True)
    evidence = {"run_id": RUN_ID, "scenario": "DK-I8-private-engine-offline-timer",
                "status": "observed-awaiting-oracle", "business_complete": True,
                "cleanup_complete": True, "cleanup_errors": [],
                "commands": records, "cleanup_commands": cleanup,
                "inputs": {"scenario": "DK-I8-private-engine-offline-timer",
                           "image_id": OUTER_IMAGE, "build_id": BUILD},
                "expected": {"project": PROJECT, "control": CONTROL,
                             "center_id": CID, "dind_id": DIND, "dind": DIND_NAME,
                             "image_id": OUTER_IMAGE, "inner_image_id": IMAGE,
                             "build_id": BUILD, "center_started_at": "2026-09-27T00:00:00Z",
                             "center_restart_count": 0,
                             "dind_started_at": "2026-09-27T00:00:00Z"}}
    (run / "evidence.json").write_text(json.dumps(evidence))
    return run


def mutate_json(run, label, change):
    path = run / "raw" / (label + ".stdout")
    value = json.loads(path.read_bytes())
    change(value)
    path.write_bytes(encoded(value))


def mutate_evidence(run, change):
    path = run / "evidence.json"
    value = json.loads(path.read_text())
    change(value)
    path.write_text(json.dumps(value))


def cases():
    def fake_stop(run):
        mutate_json(run, "t-stop-center", lambda x: x.update(exitCode=1, clean=False))

    def no_actual_exit(run):
        mutate_json(run, "t-center-before-engine-stop",
                    lambda x: x[0]["State"].update(Status="running", Running=True))

    def wrong_dind(run):
        mutate_json(run, "t-dind-offline-initial", lambda x: x[0].update(Id="9" * 64))

    def daemon_started(run):
        mutate_json(run, "t-dind-offline-after-timer",
                    lambda x: x[0]["State"].update(Status="running", Running=True))

    def daemon_started_event(run):
        path = run / "raw/t-dind-offline-events.stdout"
        path.write_bytes(path.read_bytes() + encoded(
            {"Action": "start", "Actor": {"ID": DIND}}))

    def no_timer_trigger(run):
        (run / "raw/t-timer-final.stdout").write_bytes(b"LastTriggerUSec=n/a\n")

    def stale_service_start(run):
        path = run / "raw/t-service-final.stdout"
        path.write_bytes(path.read_bytes().replace(
            b"ExecMainStartTimestampMonotonic=500", b"ExecMainStartTimestampMonotonic=0"))

    def service_success(run):
        path = run / "raw/t-service-final.stdout"
        path.write_bytes(path.read_bytes().replace(b"Result=exit-code", b"Result=success"))

    def service_zero(run):
        path = run / "raw/t-service-final.stdout"
        path.write_bytes(path.read_bytes().replace(b"ExecMainStatus=1", b"ExecMainStatus=0"))

    def journal_no_engine_fault(run):
        (run / "raw/t-service-journal.stdout").write_bytes(
            b"service: Failed with result 'exit-code'.\n")

    def duplicate_engine_fault(run):
        path = run / "raw/t-service-journal.stdout"
        path.write_bytes(path.read_bytes() + b"omne-center: engine-unavailable\n")

    def forbidden_unit_dependency(run):
        (run / "raw/t-service-dependencies.stdout").write_bytes(
            b"Wants=docker.service\nRequires=\nBindsTo=\nAfter=basic.target\n")

    def swapped_unit(run):
        (run / "raw/t-installed-service-file.stdout").write_bytes(b"[Unit]\nDescription=Fake\n")

    def early_fixture_recovery(run):
        mutate_evidence(run, lambda x: x["commands"].insert(
            next(i for i, y in enumerate(x["commands"]) if y["label"] == "t-start-timer"),
            x["commands"].pop(next(i for i, y in enumerate(x["commands"])
                                   if y["label"] == "fixture-explicit-start-private-dind"))))

    def center_revived(run):
        mutate_json(run, "t-center-after-explicit-recovery",
                    lambda x: x[0]["State"].update(Status="running", Running=True))

    def reset_failed(run):
        mutate_evidence(run, lambda x: next(y for y in x["commands"]
                    if y["label"] == "t-stop-timer")["argv"].append("reset-failed"))

    def cleanup_leftover(run):
        (run / "raw/cleanup-final-list-volume.stdout").write_bytes(b"old-volume\n")

    return {key: value for key, value in locals().items() if callable(value)}


def main():
    with tempfile.TemporaryDirectory(prefix="omne-timer-offline-oracle-") as temp:
        root = pathlib.Path(temp)
        assert oracle.evaluate(make_run(root / "positive"))["status"] == "limited_pass"
        negative = cases()
        for label, change in negative.items():
            run = make_run(root / label)
            change(run)
            try:
                oracle.evaluate(run)
            except (ValueError, KeyError, TypeError, OSError, UnicodeError, json.JSONDecodeError):
                continue
            raise AssertionError(label + " false pass")
        print(json.dumps({"positive": 1, "negative": len(negative),
                          "result": "pass"}, sort_keys=True))


if __name__ == "__main__":
    main()
