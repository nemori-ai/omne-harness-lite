#!/usr/bin/env python3
"""Fail-closed raw oracle for DK-I8 private Engine-offline systemd timer."""

import argparse
import json
import pathlib
import re

HEX = re.compile(r"[0-9a-f]{64}\Z")


def need(value, message):
    if not value:
        raise ValueError(message)


def raw(run, commands, label, stream="stdout"):
    item = commands[label]
    path = run / item[stream]
    need(path.parent == run / "raw" and path.is_file(), label + " raw missing")
    return path.read_bytes()


def success(commands, label):
    item = commands[label]
    need(item["returncode"] == 0 and item["observation_expired"] is False,
         label + " actual command failed/observation expired")


def one_json(data, label):
    need(data.endswith(b"\n") and data.count(b"\n") == 1,
         label + " needs exactly one JSON+LF")
    value = json.loads(data[:-1].decode("utf-8", "strict"))
    need(isinstance(value, dict), label + " object required")
    return value


def inspect(run, commands, label, identity):
    success(commands, label)
    values = json.loads(raw(run, commands, label).decode("utf-8", "strict"))
    need(isinstance(values, list) and len(values) == 1 and values[0]["Id"] == identity,
         label + " exact inspect identity")
    return values[0]


def show(run, commands, label):
    success(commands, label)
    lines = raw(run, commands, label).decode("utf-8", "strict").splitlines()
    need(lines and all("=" in line for line in lines), label + " malformed systemd show")
    values = dict(line.split("=", 1) for line in lines)
    need(len(values) == len(lines), label + " duplicate systemd property")
    return values


def status(run, commands, label, cid, image, build, state):
    success(commands, label)
    value = one_json(raw(run, commands, label), label)
    need(value["containerId"] == cid and value["imageId"] == image
         and value["buildId"] == build and value["state"] == state,
         label + " wrong center state/image/BUILD/ID")
    return value


def evaluate(run):
    evidence = json.loads((run / "evidence.json").read_text())
    commands = {x["label"]: x for x in evidence["commands"]}
    need(len(commands) == len(evidence["commands"]), "duplicate command labels")
    need(evidence["scenario"] == "DK-I8-private-engine-offline-timer"
         and evidence["status"] == "observed-awaiting-oracle"
         and evidence["business_complete"] is True, "offline timer observation incomplete")
    expected = evidence["expected"]
    inputs = evidence["inputs"]
    project = expected["project"]
    cid = expected["center_id"]
    dind = expected["dind_id"]
    image = expected["inner_image_id"]
    build = expected["build_id"]
    control = expected["control"]
    need(HEX.fullmatch(cid) and HEX.fullmatch(dind) and HEX.fullmatch(build)
         and inputs["scenario"] == evidence["scenario"]
         and inputs["image_id"] == expected["image_id"]
         and inputs["build_id"] == build, "frozen identities")
    order = [x["label"] for x in evidence["commands"]]
    chain = ["t-validate", "t-start-center", "t-inspect-running", "t-full-health",
             "t-stop-center", "t-center-before-engine-stop", "t-status-exited",
             "t-dind-before-stop", "t-stop-private-dind", "t-dind-offline-initial",
             "t-timer-before", "t-service-before", "t-start-timer", "t-service-final",
             "t-timer-final", "t-service-journal", "t-stop-timer",
             "t-dind-offline-after-timer", "t-control-after-timer",
             "t-dind-offline-events",
             "fixture-explicit-start-private-dind", "t-center-after-explicit-recovery"]
    need(all(x in commands for x in chain)
         and [order.index(x) for x in chain] == sorted(order.index(x) for x in chain),
         "normal stop/offline timer/explicit recovery order")
    need(not any("reset-failed" in x["argv"] for x in evidence["commands"]),
         "forbidden systemd reset-failed/retry")
    helper = ["docker", "exec", "-e",
              "DOCKER_HOST=unix:///opt/omne-private-docker/docker.sock", control,
              "/usr/local/libexec/omne-center"]
    for label, action in (("t-validate", "validate"), ("t-start-center", "start"),
                          ("t-full-health", "full-health"),
                          ("t-status-running", "status"),
                          ("t-stop-center", "stop"),
                          ("t-status-exited", "status"),
                          ("t-status-after-explicit-recovery", "status")):
        need(commands[label]["argv"][:len(helper) + 1] == [*helper, action],
             label + " not final helper on private socket")
    success(commands, "t-validate")
    need(one_json(raw(run, commands, "t-validate"), "t-validate") ==
         {"state": "deployment-structure-valid"}, "validate result")
    success(commands, "t-start-center")
    need(one_json(raw(run, commands, "t-start-center"), "t-start-center") ==
         {"state": "running", "containerId": cid, "imageId": image,
          "buildId": build, "health": "healthy"}, "center startup result")
    running = inspect(run, commands, "t-inspect-running", cid)
    need(running["Image"] == image and running["State"]["Status"] == "running"
         and running["State"]["Running"] is True
         and running["State"]["Pid"] > 0
         and running["Config"]["Labels"]["ai.nemori.omne.project"] == project
         and running["Config"]["Labels"]["ai.nemori.omne.host-build-id"] == build,
         "center not actually running with selected image")
    success(commands, "t-full-health")
    health = one_json(raw(run, commands, "t-full-health"), "t-full-health")
    need(all(health.get(k) is True for k in
             ("reachable", "storageReachable", "clockSane",
              "deploymentKeyPresent", "deploymentKeyComplete"))
         and health.get("defectCount") == 0 and health.get("centerId"),
         "real full health not confirmed")
    status(run, commands, "t-status-running", cid, image, build, "running")
    success(commands, "t-stop-center")
    need(one_json(raw(run, commands, "t-stop-center"), "t-stop-center") ==
         {"state": "stopped", "containerId": cid, "exitCode": 0, "clean": True},
         "supported normal stop incomplete")
    stopped = inspect(run, commands, "t-center-before-engine-stop", cid)
    need(stopped["State"]["Status"] == "exited" and stopped["State"]["Running"] is False
         and stopped["State"]["ExitCode"] == 0
         and stopped["State"]["StartedAt"] == expected["center_started_at"]
         and stopped["RestartCount"] == expected["center_restart_count"],
         "center not independently exited0 before Engine shutdown")
    stopped_status = status(run, commands, "t-status-exited", cid, image, build, "exited")
    need(stopped_status["exitCode"] == 0 and stopped_status["restartCount"] ==
         expected["center_restart_count"], "stopped center status")
    dind_before = inspect(run, commands, "t-dind-before-stop", dind)
    need(dind_before["State"]["Status"] == "running"
         and dind_before["State"]["StartedAt"] == expected["dind_started_at"]
         and dind_before["Config"]["Labels"].get("omne.r5.helper-prep") ==
         evidence["run_id"], "private DinD before identity")
    need(commands["t-stop-private-dind"]["argv"] == ["docker", "stop", expected["dind"]],
         "only exact private DinD may be stopped")
    success(commands, "t-stop-private-dind")
    initial = inspect(run, commands, "t-dind-offline-initial", dind)
    final = inspect(run, commands, "t-dind-offline-after-timer", dind)
    for item in (initial, final):
        need(item["State"]["Status"] == "exited" and item["State"]["Running"] is False
             and item["State"]["StartedAt"] == dind_before["State"]["StartedAt"]
             and item["Mounts"] == dind_before["Mounts"],
             "private DinD resurrected or lost state volume during timer")
    need(raw(run, commands, "t-installed-service-file") ==
         (run / "inputs/omne-center-backup@.service").read_bytes()
         and raw(run, commands, "t-installed-timer-file") ==
         (run / "inputs/omne-center-backup@.timer").read_bytes()
         and raw(run, commands, "t-qa-timer-dropin") ==
         b"[Timer]\nOnCalendar=\nOnActiveSec=2s\nPersistent=false\n",
         "installed real units/QA schedule changed")
    for label in ("t-installed-service-file", "t-installed-timer-file", "t-qa-timer-dropin"):
        success(commands, label)
    deps = show(run, commands, "t-service-dependencies")
    need(all("docker.service" not in deps.get(key, "")
             and "containerd.service" not in deps.get(key, "")
             and "omne-center@" not in deps.get(key, "")
             for key in ("Wants", "Requires", "BindsTo", "After")),
         "timer service acquired Engine/center start dependency")
    need(commands["t-start-timer"]["argv"] ==
         ["docker", "exec", control, "systemctl", "start",
          f"omne-center-backup@{project}.timer"], "real timer was not started")
    success(commands, "t-start-timer")
    before_timer = show(run, commands, "t-timer-before")
    after_timer = show(run, commands, "t-timer-final")
    before_service = show(run, commands, "t-service-before")
    after_service = show(run, commands, "t-service-final")
    trigger = after_timer.get("LastTriggerUSec")
    need(trigger not in (None, "", "n/a")
         and trigger != before_timer.get("LastTriggerUSec"), "no new timer trigger")
    start = int(after_service["ExecMainStartTimestampMonotonic"])
    end = int(after_service["ExecMainExitTimestampMonotonic"])
    previous = int(before_service["ExecMainStartTimestampMonotonic"])
    need(start > previous and start > 0 and end >= start
         and after_service["ActiveState"] in ("inactive", "failed")
         and after_service["Result"] == "exit-code"
         and int(after_service["ExecMainStatus"]) > 0,
         "timer service did not actually start and fail")
    success(commands, "t-service-journal")
    journal = raw(run, commands, "t-service-journal").decode("utf-8", "strict")
    need(journal.count("omne-center: engine-unavailable") == 1
         and "Failed with result 'exit-code'" in journal
         and "ops-request" not in journal
         and '"status":"completed"' not in journal,
         "journal lacks Engine-unavailable diagnostic or claims backup work")
    success(commands, "t-stop-timer")
    success(commands, "t-outer-private-container-list")
    listed = set(raw(run, commands, "t-outer-private-container-list")
                 .decode("ascii", "strict").splitlines())
    success(commands, "outer-inspect-" + control)
    control_before = json.loads(raw(run, commands, "outer-inspect-" + control))[0]
    control_inspect = inspect(run, commands, "t-control-after-timer", control_before["Id"])
    need(listed == {dind, control_inspect["Id"]} and
         control_inspect["State"]["Status"] == "running"
         and control_inspect["Config"]["Labels"].get("omne.r5.helper-prep") ==
         evidence["run_id"],
         "another fixture Engine/control container appeared")
    success(commands, "t-dind-offline-events")
    events = [json.loads(x) for x in raw(run, commands,
                                         "t-dind-offline-events").splitlines()]
    need(events and all(x.get("Actor", {}).get("ID") == dind for x in events),
         "private DinD event gap/wrong ID")
    actions = [x.get("Action", x.get("status")) for x in events]
    need("die" in actions and "start" not in actions and "restart" not in actions,
         "private DinD was restarted during timer observation")
    need(commands["fixture-explicit-start-private-dind"]["argv"] ==
         ["docker", "start", expected["dind"]],
         "fixture recovery must start exact private DinD after observation")
    success(commands, "fixture-explicit-start-private-dind")
    recovery = inspect(run, commands, "fixture-dind-after-explicit-start", dind)
    need(recovery["State"]["Status"] == "running"
         and recovery["State"]["StartedAt"] != final["State"]["StartedAt"]
         and recovery["Mounts"] == final["Mounts"],
         "explicit private Engine recovery identity/volumes")
    center_after = inspect(run, commands, "t-center-after-explicit-recovery", cid)
    need(center_after["State"]["Status"] == "exited"
         and center_after["State"]["ExitCode"] == 0
         and center_after["State"]["StartedAt"] == stopped["State"]["StartedAt"]
         and center_after["RestartCount"] == stopped["RestartCount"],
         "stopped center changed after explicit private Engine recovery")
    status_after = status(run, commands, "t-status-after-explicit-recovery", cid,
                          image, build, "exited")
    need(status_after["exitCode"] == 0, "post-recovery stopped center status")
    need(evidence["cleanup_complete"] is True and evidence["cleanup_errors"] == [],
         "fixture cleanup incomplete")
    cleanup = {x["label"]: x for x in evidence["cleanup_commands"]}
    need(len(cleanup) == len(evidence["cleanup_commands"]), "duplicate cleanup label")
    for label in ("cleanup-final-list-container", "cleanup-final-list-volume",
                  "cleanup-final-list-network", "cleanup-inner-project-final-list",
                  "cleanup-inner-fixture-final-list", "cleanup-inner-all-final-list"):
        need(cleanup[label]["returncode"] == 0 and raw(run, cleanup, label) == b"",
             label + " fixture resources remain")
    return {"status": "limited_pass", "scenario": evidence["scenario"],
            "center_id": cid, "private_dind_id": dind}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=pathlib.Path)
    args = parser.parse_args()
    try:
        print(json.dumps(evaluate(args.run), sort_keys=True))
    except (ValueError, KeyError, TypeError, UnicodeError, OSError, json.JSONDecodeError) as error:
        print(json.dumps({"status": "fail", "reason": str(error)}, sort_keys=True))
        raise SystemExit(1)
