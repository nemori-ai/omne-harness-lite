from pathlib import Path
import hashlib
import io
import json
import tarfile

root = Path.cwd()
task = root / 'tmp/model-request-runtime/b1-session-log-projection'
destination = root / '.meta_harness/design/record/proposals/model-request-adaptation/reviews'
destination.mkdir(exist_ok=True)
archive = destination / 'session-log-jsonl-2026-09-27.tar.gz'
manifest_file = destination / 'session-log-jsonl-2026-09-27.json'
assert not archive.exists() and not manifest_file.exists()
inputs = json.loads((task / 'revision2/inputs-and-checks.json').read_text())
files = {}
observations = []

def capture(path, name, expected=None):
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if expected is not None:
        assert digest == expected, path
    assert name not in files
    files[name] = data
    return digest

capture(task / 'review-snapshot-6dd4.md', 'reviewed/candidate-1.md',
        '6dd4ac87b116f31f8dc0d010d2eb31e6beb6f1885be932fa8d9da1fc64adbc11')
capture(task / 'revision2/candidate-a3cd9847.md', 'reviewed/candidate-2.md',
        'a3cd98478faf5d158a8b09dd8e1491db568b4cc93091b0dc560b6e74a20ffbb6')
for name in ['architecture-review-6dd4.md', 'spec-review-6dd4.md',
             'architecture-review-a3cd.md', 'spec-review-a3cd.md']:
    capture(task / name, 'reviews/' + name)
for row in inputs['normativeResourceHashChecks'] + inputs['providerAdoptionHashChecks']:
    path = '.meta_harness/design/' + row['path']
    name = 'inputs/' + path
    if name not in files:
        capture(root / path, name, row['sha256'])
for path, expected in inputs['sources'].items():
    name = 'inputs/' + path
    data = (root / path).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    observations.append({'path': path, 'recordedSha256': expected,
                         'observedSha256': digest, 'matches': digest == expected})
    if name not in files:
        capture(root / path, name)
capture(task / 'revision2/inputs-and-checks.json', 'provenance/inputs-and-checks.json')
capture(task / 'revision2/revision-provenance.json', 'provenance/revision-provenance.json')
capture(Path(__file__), 'provenance/archive-reviews.py')
with tarfile.open(archive, 'w:gz') as target:
    for name, data in sorted(files.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o600
        entry.mtime = 0
        target.addfile(entry, io.BytesIO(data))
manifest = {
    'format': 1, 'candidateStatus': 'not accepted',
    'architectureBlocking': ['AR-B1-1/G2-7'],
    'otherOwnerGap': ['G2-6'],
    'expressionFindingsResolvedAtCandidate2': True,
    'reviewerActions': 'read-only; no tests, formal execution, or acceptance',
    'frozenResourcesChecked': len(inputs['normativeResourceHashChecks']),
    'adoptedProviderDesignsChecked': len(inputs['providerAdoptionHashChecks']),
    'archiveSha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'files': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())},
    'inputObservations': observations,
}
manifest_file.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'archive': str(archive.relative_to(root)),
                  'files': len(files), 'inputDrift': sum(not row['matches'] for row in observations),
                  'sha256': manifest['archiveSha256']}))
