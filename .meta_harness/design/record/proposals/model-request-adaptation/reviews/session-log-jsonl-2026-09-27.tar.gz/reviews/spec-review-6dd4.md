评审对象：[session-log-jsonl/v2-design.md](/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime/.meta_harness/design/realization/packages/session/session-log-jsonl/v2-design.md)，SHA-256：

`6dd4ac87b116f31f8dc0d010d2eb31e6beb6f1885be932fa8d9da1fc64adbc11`

已完成本次定向表达、依赖与消费者路径核对。全程只读，未运行测试或形式工具。

**阻断**

1. **跨契约一致／归属越界：重复响应头数组被直接算入 MR4 合法响应。**

   - **位置**：候选第 63 行「provider 的读结果交付」及第 156 行 V2-1。
   - **依据**：`data.model-response/v4` Schema 的 `$defs.RawResponse.properties.headers.additionalProperties` 仅为 `string`（第 418–422 行）；公开 `core/model-response` 的 `RawResponse` 同样是 `Record<string, string>`。`TransportFailure.headers` 才允许 `string | readonly string[]`，属于另一公开值面。MR4 S-20 明确不规定同名多值的合并方式。
   - **触发**：依 V2-1 构造 `raw.headers: {"x-example":["a","b"]}`，同时要求往返前后通过 MR4 Schema。
   - **后果**：两项要求不能同时满足；实施者只能自行改变 Schema、改写响应头或削弱验收。
   - **需明确**：将“任意合法 JSON 数组的日志保真”与“符合 MR4 的响应往返”分开表达。TransportFailure 到 MR4 的持久化投影若尚未决定，交还其 owner；本节点不能据传输值面扩张 MR4。

2. **表达歧义／可实施性：写入不可信分支的新栅栏与恢复顺序不清。**

   - **位置**：候选第 108–111 行，「unknown opened、排空与权威恢复」步骤 2～5。
   - **依据**：原 provider `design.md`「状态、并发与失败映射」规定写入不可信后追加一律 `unavailable`，重启后恢复；RT3 S-33、runtime v3-design Q-2/Q-3 要求的是恢复消费前满足实际静止、有效栅栏及权威读取前提。
   - **触发**：带 run 的 opened 写入错误且截回失败。按编号顺序执行步骤 2，需先在不可写的旧实例确认新 attempt，步骤 3～4 的重启却在其后。
   - **后果**：消费者无法确定应等待不可能成功的旧追加，还是先完成重启；两种实现的恢复行为不同。
   - **需明确**：把栅栏确认表述为步骤 5 前的条件，并明确写入不可信时先完成原定关闭／重启，再确认新尝试。现有待应用澄清 patch 已针对这一点，但不计入本次快照。

**非阻断**

1. **表达歧义：公开无损载体与一般 class 实例需要明确区分。**

   - **位置**：候选第 61–64 行。
   - **依据**：`core/content-blocks` 的 `LosslessNumber` 和 `OpaqueJsonValue` 都是 class；已采用公开编解码及 `copyJsonValue` 明确支持这些表示。其 realization「中性 JSON 表示复制入口」还说明：复制可移除 `OpaqueJson` 包装，不保留领域品牌。
   - **触发**：追加经过公开判定器构造、含大数或 opaque 的合法领域值。
   - **后果**：“class 实例”若被实施者扩读成一律拒绝，会排斥指定公开表示；读回值也可能被误认为已经恢复领域类型。
   - **需明确**：接受公开无损 JSON 载体，拒绝其他非 JSON 对象；日志保真的是交换表示，领域类型由读方权威接收入口恢复。原文禁止“静默剥掉”并非明确的一律拒绝，故列为非阻断澄清。

**范围外待裁决**

- TransportFailure 多值头怎样进入 MR4 历史记录，由 runtime／response 投影 owner 与主线决定；本评审不选择合并、另存或版本演化方案。
- `unfenced` 结算的 `late` 与实际提交顺序怎样一致，属于正在进行的架构核对。候选目前仍把判断归写方，不能把 SL2 三操作理解为新增了提交点业务回调。

**未覆盖**

- 未验证文件 IO、实际排空、锁交接、Cordis 时序及 unknown-ack 运行行为；V2-1～V2-10 仍是待执行义务。
- 未重新审计既有 TLA+ 模型内部断言或全库登记。已核对相关 catalog 采用、Schema 版本闭包、产品 rev、既有形式任务定位及空 bindings；本稿没有把形式检查当成本提供者证据。
- 共同键 codec 尚未确定，G2-2 已显式保留 owner 与阻断范围，未以默认编码补齐。

其余已查边界表达一致：SL2 三操作和失败集合沿用原契约；provider 只检查壳与合法 JSON，业务载荷由写方及读方校验；新旧依赖并存有明确依据；回执未知路径保留原追加任务所有权、隔离普通结算，并禁止以旧确认尾空读证明未开口。

表达修订归候选作者；投影政策与 `late` 协调归主线及对应架构 owner；真实组合证据归 provider、runtime、宿主与验收应用 owner。
