### UL-asset · 资产 · Asset

> **中**：**约束 agent 由什么组装而成、从哪里被触达、以及推进时在哪些位置插手**的那一类对象。
> 它是三样东西里**唯一独立存在的对象**；
> [设置](#ul-setting--设置--setting)与[权限](#ul-permission--权限--permission)是它的**两种属性**。
> **恰有[八类](#八类资产)，这八类是穷尽的。**
>
> **EN**: The class of objects that **constrains what an agent is assembled from**,
> **through which channels it can be reached**, and **where things may be inserted as
> its loop advances**. It is the only one of the three that exists as an object in
> its own right; settings and permissions are two kinds of **attribute on** it.
> **There are exactly eight kinds, and the list is exhaustive.**

- **形态**：对象
- **出处**：[PF-001 §4 设置、权限、资产](../../product/PF-001-identity-scope-and-agent-constraints/design.md#设置权限资产)（rev 22） · [资产的种类](../../product/PF-001-identity-scope-and-agent-constraints/design.md#资产的种类)（rev 22）
- **别混**：知识、经验、报告、附件与文件**都不是资产**——它们是 agent **读写的对象**，**不参与组装**
- **注意 ①**：判据是**它在 agent definition 里被声明、被持有、被授权、按层级求值**——**这四件事**，不是「它提供动作」
- **注意 ②**：**规格里的「资产记录」指的是同一个[能力标识](scope-and-resolution.md#ul-capability-identifier--能力标识--capability-identifier)下的一份具体资产**——所有者、来源、草稿与版本线都挂在它身上；它是本条身份的下层（[对象条目](../../domain_objects/objects.md#ul-asset--资产)），**不另立词条**。**草稿是它身上还没发布的那份内容**，[不是版本](#ul-asset-version--资产版本--asset-version)，也不另立


### UL-setting · 设置 · Setting

> **中**：[资产](#ul-asset--资产--asset)的一种属性，约束 agent **以什么配置、什么参数去做**。
> **资产定形状**（有哪些项、什么含义、取值域是什么），**持有它的各层配值**，
> 运行时按[覆盖](scope-and-resolution.md#ul-scope-composition-semantics--作用域合成语义--scope-composition-semantics)求值。
>
> **EN**: A kind of attribute on an asset, constraining **with what configuration and
> parameters** the agent acts. **The asset defines the shape** (which entries exist,
> what they mean, what values they admit), **each layer holding it supplies values**,
> and at run time they resolve by **override**.

- **形态**：属性
- **出处**：[PF-001 §4 设置、权限、资产](../../product/PF-001-identity-scope-and-agent-constraints/design.md#设置权限资产)（rev 22） · [PF-002 §5.2](../../product/PF-002-assets-settings-and-permissions/design.md#52-设置与权限是资产的两种属性)（rev 25）
- **注意 ①**：配值的资格来自**持有**——**没有这个工具，就配不了它的执行权限**。
  配下的那一格叫[属性配值](scope-and-resolution.md#ul-attribute-assignment--属性配值--attribute-assignment)，
  **挂在那份持有上**
- **注意 ②**：**配值的不只组织与租户**——[工作区](scope-and-resolution.md#ul-workspace--工作区--workspace)那一级也配得了，
  且[它配的值压过租户](../../product/PF-002-assets-settings-and-permissions/design.md#58-三条层序各答一个问题)，
  **除非上层加了 `immutable`**
- **注意 ③**：[禁用](circulation-and-entitlement.md#ul-asset-disable--资产禁用--asset-disable)是一项**特殊的布尔设置**——
  **任一层为真即为真**，那等价于「覆盖 ＋ 真即 `immutable`」
- **注意 ④**：**每一项设置带一个[设置项类别](#ul-setting-category--设置项类别--setting-category)**，
  类别决定这项值能从哪些层来——**落点与身份类不从工作区来**
- **注意 ⑤**：**同标识替换之后，设置按资产取值**——外层给原来那一份配的值（连锁住的在内）不落到替换它的那一份上（[PF-002 §5.5](../../product/PF-002-assets-settings-and-permissions/design.md#替换是一条路径不是一扇后门)）；与[权限](#ul-permission--权限--permission)相反


### UL-permission · 权限 · Permission

> **中**：[资产](#ul-asset--资产--asset)的一种属性，约束 agent **能执行什么动作、边界在哪**。
> 每一层对它能做两件事之一：**锁下一个允许集合**（一道界），或**不锁、只挑一个值**。
> 各层的界按[收窄](scope-and-resolution.md#ul-scope-composition-semantics--作用域合成语义--scope-composition-semantics)取交集，
> **更外层锁下的界，更具体的一层突破不了**；界内取哪一个，由最具体的、挑在界内的那一层定。
> **配成「禁止」的，锁不锁都是界。**
>
> **EN**: A kind of attribute on an asset, constraining **which actions the agent may
> perform and where the boundary lies**. Each layer may do one of two things with it:
> **lock a set of permitted values** (a bound), or **pick a single value without locking**.
> Bounds combine by **narrowing** — their intersection across layers — so **a bound locked
> further out cannot be broken by a more specific layer**; within the bound, the value is
> the one picked by the most specific layer whose pick falls inside it. **Setting "forbid"
> is a bound whether locked or not.**

- **形态**：属性
- **出处**：[PF-001 §4 设置、权限、资产](../../product/PF-001-identity-scope-and-agent-constraints/design.md#设置权限资产)（rev 22） · [§6.2](../../product/PF-001-identity-scope-and-agent-constraints/design.md#62-三种合成语义)（rev 22） · [PF-002 §5.3](../../product/PF-002-assets-settings-and-permissions/design.md#53-两个例子两种合成)（rev 25）
- **别混**：**不是[租户角色](subjects-and-ownership.md#ul-tenant-role--租户角色--tenant-role)**——角色是**身份**的属性，权限是**资产**的属性
- **注意 ①**：**一次运行之内，权限变了，[动作空间](#ul-action-space--动作空间--action-space)不变**；运行之间也只有[「谁可以使用它」](circulation-and-entitlement.md#ul-usable-by--谁可以使用它--usable-by)会让下一次运行的构成变小——它改的是装不装进来
- **注意 ②**：**不锁的配值不是界**——组织配「问一下」而不锁，成员挑「自动」就生效；组织要守的边界必须锁（「禁止」除外）
- **注意 ③**：**同标识替换之后，外层为这个身份锁下的界照样管着替换它的那一份**；那一份少声明了锁住的某一项，那一项按最严算（[PF-002 §5.5](../../product/PF-002-assets-settings-and-permissions/design.md#替换是一条路径不是一扇后门)）
- **注意 ④**：**权限项有哪几项由资产的类别定，作者不能自加**；[「谁可以使用它」](../../product/PF-002-assets-settings-and-permissions/design.md#谁可以使用它是各类资产共用的一项权限)是各类共用的一项

## 八类资产


### UL-mcp · MCP · MCP

> **中**：**一个外部工具来源的接入点。**接进来之后，它提供的动作可被 agent 使用。
> **接入点本身是资产，它带来的那些动作不单独成为资产**——随它一起被持有、授权与治理。
> **对端的可用性与版本不由本系统掌握**：它提供的动作可能今天有明天没有，**而这不是故障**。
> **对端的每一个动作在动作空间里是一个工具条目**——不常驻、经取用入口发现；
> 动作集**每一次[执行尝试](agent-runtime-loop.md#ul-run-attempt--执行尝试--run-attempt)开始前与可用性一起重算，一次尝试之内不变**。
>
> **EN**: **An access point to an external source of tools.** Once connected, the
> actions it offers become usable by the agent. **The access point is the asset; the
> actions it brings are not assets of their own** — they are held, authorized and
> governed along with it. **Availability and versioning on the far side lie outside
> this system's control**, so an action present today may be gone tomorrow — **and
> that is not a fault**. **Each action on the far side is one tool entry in the action
> space** — not resident, found through the discovery entry; the action set is
> **recomputed before each run attempt together with availability and does not change within an attempt**.

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-001 §4 资产的种类](../../product/PF-001-identity-scope-and-agent-constraints/design.md#资产的种类)（rev 22） · [PF-002 §4 MCP](../../product/PF-002-assets-settings-and-permissions/design.md#mcp)（rev 25） · [PF-006 §6.13](../../product/PF-006-tools-and-skills/design.md#613-mcp-接入点带来的动作)（rev 20）
- **别混**：Tool 是**一个动作**，MCP 是**一批动作的来源**——**MCP 本身不可被调用**
- **注意**：它连对端用的是 [MCP 凭据](#ul-mcp-credential--mcp-凭据--mcp-credential)，挂在持有上，不是[模型凭据](#ul-model-credential--模型凭据--model-credential)
- **能组合**：**不组合任何资产**


### UL-connector · 连接件 · Connector

> **中**：**一个外部消息来源的接入件**，把外部的消息送进来。
> **八类里只有它回答「agent 从哪里被触达」**——另外六类回答「agent 能做什么、怎么做」，
> [拓展件](#ul-loop-extension--拓展件--loop-extension)回答「推进的时候在哪些位置插手」。
> **只能送消息进来**——没有数据读取面，也没有管理面。
> **它带身份鉴权**：接对面服务的哪个账号（鉴权绑定），是持有上的一项[落点与身份类设置](#ul-setting-category--设置项类别--setting-category)，
> **只在租户那一层配**，随租户身份不同而不同。它的权限只有一项：**能不能安装**。
> **它声明一份事件目录**——它会送进来的每一种[连接件事件类型](#ul-connector-event-type--连接件事件类型--connector-event-type)；每条送进来的消息恰属其中一种，持有上以[事件订阅](#ul-event-subscription--事件订阅--event-subscription)选其中哪几种真的送进来，目录外与未订阅的受理时拒绝、看得见。
> **外部的事进到会话里有两种投递方式，动作主体不同**：① **已有的会话开口接收**——它这一侧的配置是[投递目标](interaction-and-dispatch.md#ul-inbound-target--投递目标--inbound-target)（送进哪一个已有的会话）；② **它送来的事件经受理开出一个新会话**——它这一侧的配置是**触发会话的默认运行模式**（持有上必配的一项[治理类设置](#ul-setting-category--设置项类别--setting-category)，哪一层都没给过的开不出新会话，作者默认不算），新会话怎么建归会话那一块。
> **送进来的消息以谁的身份处理，不是权限，是一条固定规则**：按它落进的那个会话创建那一刻捕获的租户身份，对面那个账号只作来源留在消息上；两种投递方式都照这一条。**外部内容只说得出自己是目录里的哪一种**，进哪个会话、开不开新会话、以谁的身份、按什么运行模式它一样都选不了。
>
> **EN**: **An inbound attachment for an external message source**, delivering outside
> messages into the system. **Of the eight, only this one answers how the agent can
> be reached**: six answer what an agent can do and how, and a loop extension answers
> where to intervene as the agent proceeds. It can **only deliver messages inward** — it
> exposes no data-read surface and no management surface. **It carries identity
> authentication**: which account on the far side it binds to (the authentication binding) is a
> placement-and-identity setting on the holding, **configured at the tenant layer only**, differing
> per tenant identity. Its one permission is **whether it may be installed**. **It declares an event
> catalog** — every connector event type it can deliver; each delivered message belongs to exactly one,
> the holding's event subscription picks which of them are actually delivered, and anything outside the
> catalog or unsubscribed is refused at intake, visibly. **There are two delivery modes, with different
> acting subjects**: ① **an existing session opens itself to receive** — the connector-side configuration
> is the inbound target (which existing session); ② **an event it delivers opens a new session through
> intake** — the connector-side configuration is the **default run mode for triggered sessions** (a
> governance setting the holding must supply; a connector no layer has ever given it to cannot open a
> session, and the author's default does not count), while how that session is created belongs to the
> session topic. **Whose identity an incoming message is handled under is not a permission but a fixed
> rule**: the tenant identity the receiving session captured at creation; the far-side account is kept on
> the message as its source only; both modes follow it. **External content can only say which catalog
> type it is** — never which session, whether to open one, under whose identity or in which run mode.

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-001 §4 资产的种类](../../product/PF-001-identity-scope-and-agent-constraints/design.md#资产的种类)（rev 22） · [PF-002 §4 Connector](../../product/PF-002-assets-settings-and-permissions/design.md#connector) · [两种投递方式](../../product/PF-002-assets-settings-and-permissions/design.md#两种投递方式动作主体不同) · [触发会话的默认运行模式](../../product/PF-002-assets-settings-and-permissions/design.md#触发会话的默认运行模式)（rev 25）
- **注意 ①**：**一人多账户不立新对象**——同一租户身份要接同一服务的两个账号，就是两份 name 不同的连接件
- **注意 ②**：「能不能安装」的取值与其余「谁可以……」[同一种](circulation-and-entitlement.md#ul-usable-by--谁可以使用它--usable-by)：一组租户角色，外加一个「自己」
- **别混**：MCP 是**我出去调它**，Connector 是**它进来找我**
- **能组合**：**不组合任何资产**
- **注意 ③**：**事件目录不是它的身份**——身份仍是 name，换一份实现目录可以不同；消息包整份随信封进来（厚信封），只送一个标识回头去拉本版不支持
- **注意 ④**：**② 那一路本 topic 只定它存在与它这一侧的配置**——受理怎么开新会话、同一件事来两次怎么办归 [PF-014](../../product/PF-014-inbound-intake-and-queueing/design.md#57-穷举一什么会让队列从空变成非空)（rev 8）；新会话以哪个 agent definition、哪个租户身份建归 PF-015；同一份连接件的一条事件走哪一路由什么决定，PF-002 记为待裁（D-6）
- **注意 ⑤**：触发会话的默认运行模式**只管此后开出来的新会话**，与 ① 那一路无关；租户可调，组织的值与锁照默认与强制那一套管着；工作区配不了


### UL-plugin · 插件 · Plugin

> **中**：**把若干资产打包在一起分发与启用的单元。**装一个 plugin，等于一次性获得
> 它里面的全部东西；停用它，那些东西一起退场。
> **内含成员不取得独立的顶层生命周期**——不能单独卸载 plugin 里的某一个 skill。
>
> **EN**: **A unit for distributing and enabling a bundle of assets together.**
> Installing one grants everything inside at once; disabling it withdraws them all.
> **Its members have no independent top-level lifecycle** — one cannot uninstall a
> single skill out of a plugin.

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-001 §4 资产的种类](../../product/PF-001-identity-scope-and-agent-constraints/design.md#资产的种类)（rev 22） · [PF-002 §4 Plugin](../../product/PF-002-assets-settings-and-permissions/design.md#plugin)（rev 25）
- **别混 ①**：**不是 Cordis plugin**——那是运行时的代码装载单元，属技术设计。指它时**必须写全 `Cordis plugin`**
- **别混 ②**：Plugin 组合出来的**还是资产**，可以继续被组合；[Agent Definition](#ul-agent-definition--agent-定义--agent-definition) 组合出来的是**一个能跑的 agent**
- **能组合**：Skill、Tool、Slash Command、MCP、Connector、[拓展件](#ul-loop-extension--拓展件--loop-extension)，以及 Rules 这类声明性成员


### UL-agent-definition · Agent 定义 · Agent Definition

> **中**：**一个 agent 的静态定义**——它由什么组装而成、以什么面貌工作。
> **它不是会话，也不是[agent runtime](agent-runtime-loop.md#ul-agent-runtime--agent-runtime--agent-runtime)**：
> 改定义**不会**改变已经在跑的那个 agent，一个定义可以同时有很多个 agent runtime，
> **定义与实例分别演进**。sub-agent 的定义**也属于这一类**。
>
> **EN**: **The static definition of an agent** — what it is assembled from and how it
> presents itself at work. **It is neither a session nor an agent runtime**:
> editing a definition **does not** change an agent already running, one definition
> may have many agent runtimes going at once, and **the definition and the running
> thing evolve separately**. A sub-agent's definition **is one of these too**.

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-001 §4 资产的种类](../../product/PF-001-identity-scope-and-agent-constraints/design.md#资产的种类)（rev 22） · [PF-002 §4 Agent Definition](../../product/PF-002-assets-settings-and-permissions/design.md#agent-definition)（rev 25）
- **注意**：混为一谈会出现「**我改了配置，正在跑的任务突然换了行为**」这种事故
- **能组合**：**全部八类**（含其他 Agent Definition 作为 sub-agent）——**它是唯一能组合全部八类的**


### UL-definition-ownership · 定义所有权 · Definition Ownership

> **中**：**这个定义是谁的。**获得[使用权](#ul-usage-right--使用权--usage-right)或
> [选用](#ul-version-selection--版本选用--version-selection)**都不转移**它，
> [资产组合](capabilities-and-composition.md#ul-asset-composition--资产组合--asset-composition)也不转移它。
> **自己拥有的定义可直接作为权利依据**，无须伪造一份向自己授予的外部授权。
>
> **EN**: **Whose definition this is.** Neither obtaining a usage right nor selecting
> a version **transfers** it, and neither does composition. **A definition one owns
> serves directly as the basis of entitlement** — no fabricated self-grant is needed.

- **形态**：属性
- **出处**：[PF-001 §4 拥有、获权、选用](../../product/PF-001-identity-scope-and-agent-constraints/design.md#拥有获权选用)（rev 22）
- **注意**：**实际作者与定义所有者分别记录**；作者用**租户身份**标识

