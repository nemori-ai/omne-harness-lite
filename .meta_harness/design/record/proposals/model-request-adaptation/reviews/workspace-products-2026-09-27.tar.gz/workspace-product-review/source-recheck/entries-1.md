### UL-intervention-power · 干预力 · Intervention Power

> **中**：**收到一条瞬态条目的那一方——在 loop 里就是一件[拓展件](capabilities-and-composition.md#ul-loop-extension--拓展件--loop-extension)——能对正在发生的事做到什么。**恰三档：
> **只观察**（看，不改）· **可改写**（追加一条，或决定下一条还没落盘的东西长什么样）·
> **可否决**（拦住它站的那个状态点，不让它发生；也能落一张卡片，让运行停下来等人）。**没有「放宽」这一档。**
> 只有「成为条目之前」那一刻才谈得上干预——已经写下的条目不干预任何事。
>
> **EN**: **What the receiver of a transient entry — in the loop, an extension — can do to what is
> happening.** Exactly three grades: **observe only** (look, change nothing); **may rewrite** (append an
> entry, or decide the shape of the next one not yet written); **may veto** (stop the state point it stands
> at from happening, including by posting a card and making the run wait for a person). **There is no
> "loosen" grade.** Intervention exists only at the moment before something becomes an entry — an entry
> already written intervenes in nothing.

- **形态**：属性
- **出处**：[PF-000 §4 干预力](../../product/PF-000-occurrences-and-record-entries/design.md#干预力--intervention-power) ·
  [§5.3](../../product/PF-000-occurrences-and-record-entries/design.md#53-干预力只长在瞬态这一半上)（rev 1） ·
  [PF-012 §5.8 干预力三档](../../product/PF-012-agent-loop-and-run/design.md#干预力三档直接用-pf-000-的) ·
  [没有「放宽」这一档](../../product/PF-012-agent-loop-and-run/design.md#没有放宽这一档)（rev 15） ·
  [PF-002 §4 Loop Extension](../../product/PF-002-assets-settings-and-permissions/design.md#loop-extension)（rev 24）
- **注意 ①**：**在拓展件上它是一项[权限](capabilities-and-composition.md#ul-permission--权限--permission)，不是设置**——各层按收窄合成，组织锁在「只观察」，租户就放不宽
- **注意 ②**：**三档挂了的后果相反**——只观察那一档不影响正在发生的事；可改写那一档不影响，但留一笔「它没跑成」；可否决那一档报错默认当作否决。**「不可用」不是报错**，另有定法
- **注意 ③**：**否决只在「之前」的位置上有意义**；可否决那一档站在「之后」，多出来的只有等人


### UL-extension-unavailability-policy · 拓展件不可用处置 · Extension Unavailability Policy

> **中**：**一件[拓展件](capabilities-and-composition.md#ul-loop-extension--拓展件--loop-extension)此刻不在（依赖的服务用不了、它自己起不来）时，它站的那个位置这一次怎么办。**
> 恰三种：**跳过**（视作已卸载，瀑布里没有它）· **否决**（拦住它站的那个状态点）· **替换为指定挂件**（另一件预先声明的拓展件顶上；正文叫「指定挂件」，不与 UL-stand-in 的「替换件」混用）。
> **租户挂上的拓展件默认跳过，注册时可以从前两种里声明一种；替换为指定挂件只有系统自带的拓展件能用**，
> 且指定挂件在系统层面预先声明。**它不是[报错时的处置](#ul-intervention-power--干预力--intervention-power)**：不可用是「没跑」，报错是「跑了出错」。
>
> **EN**: **What happens, this one time, at the position an extension occupies when that extension is
> absent** — its dependencies are down or it failed to start. Exactly three: **skip** (treated as unloaded,
> the waterfall runs without it), **veto** (block the state point it stands at), or **replace with a
> declared fallback extension** (another extension, declared in advance, takes its place). **Tenant-installed
> extensions default to skip and may declare either of the first two at registration; the fallback form is
> reserved for system-provided extensions**, whose fallback is declared at the system level. **It is not the
> error policy**: unavailable means it never ran; an error means it ran and failed.

- **形态**：属性（一件拓展件登记上的一项；系统自带的那几件由系统预先给定）
- **出处**：[PF-012 §5.8 拓展件是可插拔的服务](../../product/PF-012-agent-loop-and-run/design.md#拓展件是可插拔的服务不可用即卸载报错按策略) · [系统自带的几件](../../product/PF-012-agent-loop-and-run/design.md#系统自带的几件不可用时各有定法)（rev 15） · [PF-002 §4 不可用处置是这一件自己的声明](../../product/PF-002-assets-settings-and-permissions/design.md#不可用处置是这一件自己的声明)（rev 24）
- **⚠️ 别混**：与[干预力](#ul-intervention-power--干预力--intervention-power)里「报错默认当作否决」那条是两回事——那条管跑了出错，这条管根本没跑
- **注意 ①**：**「此刻不在」无论按哪种处置，都必须看得见**——日志里有一笔「这一件此刻不在、按 X 处置」
- **注意 ②**：系统自带的[放行判断](../../product/PF-008-human-in-the-loop/design.md#52-那个判断函数)的指定挂件是**全拒件**——它不在时，需要判断的动作一律拒绝，不放行、也不出卡问人
- **注意 ③**：**它是拓展件自己的一项声明，不是设置，也不是权限**——持有它的各层不给它配值、也收窄不了它（PF-002 D-5 已裁）；本条只定取值与谁能用哪一种。声明了否决，也要干预力求出来是可否决才算数——被收窄到另两档的，不在时照跳过办


### UL-extension-point-pass · 一次经过 · Extension-Point Pass

> **中**：**loop 走到某个 [Loop 拓展点](#ul-loop-extension-point--loop-拓展点--loop-extension-point)的一次**——从到了那个状态点，到越过它。
> 这一次里，挂在那里的各件按顺序各跑一轮。**同一个位置，同一次经过只跑一轮**：
> 「调模型之前」有挂件改了日志，就重新组装一次，**但不再回到这个位置**。
>
> **EN**: **One arrival of the loop at a given loop extension point** — from reaching that state point to
> moving past it. Within one pass the extensions hung there each run once, in order. **A position runs only
> one round per pass**: if an extension at "before model call" changes the log, the request is assembled
> again, **but that position is not visited again**.

- **形态**：过程
- **出处**：[PF-012 §5.8 改了日志就重新组装，同一位置同一次经过只跑一轮](../../product/PF-012-agent-loop-and-run/design.md#改了日志就重新组装同一位置同一次经过只跑一轮)（rev 15）
- **注意 ①**：**与压缩那一圈同构**——压完再量一次，还超就上交，不再压一轮；不定这条，一个爱改日志的挂件就能把自己无限触发下去
- **注意 ②**：同一个位置上几件的先后，[就是它们在装配清单里的顺序](../../product/PF-002-assets-settings-and-permissions/design.md#loop-extension)（PF-002 rev 24），后一件看得到前一件的结论


### UL-agent-assembly · Agent 装配 · Agent Assembly

> **中**：**把一份定义，在某个作用域下，求值成一份[装配清单](#ul-assembly-manifest--装配清单--assembly-manifest)的动作。**
> 它回答：这一次**装哪些工具、带哪些技能、需要哪几类执行环境、系统提示词由哪些成分构成**。
> **有确定的发生时刻，不是一个持续的过程**；输入是两样——依据的**定义版本**，
> 加上当时该作用域的**[求值](scope-and-resolution.md#ul-scope-evaluation--作用域求值--scope-evaluation)结果**。
>
> **EN**: **The act of evaluating a definition, under a given scope, into an assembly
> manifest.** It settles which tools are loaded, which skills are carried, which
> classes of execution environment are needed, and what the system prompt is made of.
> **It happens at a definite moment; it is not an ongoing process.** Its inputs are
> two: the **definition version** it follows, and the **evaluation result** for that
> scope at that time.

- **形态**：过程
- **出处**：[PF-004 §4 装配](../../product/PF-004-agent-definition-and-assembly/design.md#装配)（rev 13） ·
  [PF-002 §5.6](../../product/PF-002-assets-settings-and-permissions/design.md#56-四步资产求值--组装--投影--层级计算)（rev 24）
- **别混 ①**：**裸写「装配 / assembly」在跨领域的文字里不作数**——它专指把 agent 定义求值成清单的这个动作
- **别混 ②**：**它的产物不是一个活物**——
  **2026-09-20 之前本条写的是「变成一个运行实例」，那个说法已退役**，见 [UL-D-3](../decisions.md#ul-d-3--runtime-与活体--2026-09-20)
- **注意**：**求值必须在装配之前**——**组装只能从「可用的」里面装**


### UL-setting · 设置 · Setting

> **中**：[资产](#ul-asset--资产--asset)的一种属性，约束 agent **以什么配置、什么参数去做**。
> **资产定形状**（有哪些项、什么含义、取值域是什么），**持有它的各层配值**，
> 运行时按[覆盖](scope-and-resolution.md#ul-scope-composition-semantics--作用域合成语义--scope-composition-semantics)求值。
>
> **EN**: A kind of attribute on an asset, constraining **with what configuration and
> parameters** the agent acts. **The asset defines the shape** (which entries exist,
> what they mean, what values they admit), **each layer holding it supplies values**,
> and at run time they resolve by **override**.

- **形态**：属性
- **出处**：[PF-001 §4 设置、权限、资产](../../product/PF-001-identity-scope-and-agent-constraints/design.md#设置权限资产)（rev 22） · [PF-002 §5.2](../../product/PF-002-assets-settings-and-permissions/design.md#52-设置与权限是资产的两种属性)（rev 24）
- **注意 ①**：配值的资格来自**持有**——**没有这个工具，就配不了它的执行权限**。
  配下的那一格叫[属性配值](scope-and-resolution.md#ul-attribute-assignment--属性配值--attribute-assignment)，
  **挂在那份持有上**
- **注意 ②**：**配值的不只组织与租户**——[工作区](scope-and-resolution.md#ul-workspace--工作区--workspace)那一级也配得了，
  且[它配的值压过租户](../../product/PF-002-assets-settings-and-permissions/design.md#58-三条层序各答一个问题)，
  **除非上层加了 `immutable`**
- **注意 ③**：[禁用](circulation-and-entitlement.md#ul-asset-disable--资产禁用--asset-disable)是一项**特殊的布尔设置**——
  **任一层为真即为真**，那等价于「覆盖 ＋ 真即 `immutable`」
- **注意 ④**：**每一项设置带一个[设置项类别](#ul-setting-category--设置项类别--setting-category)**，
  类别决定这项值能从哪些层来——**落点与身份类不从工作区来**
- **注意 ⑤**：**同标识替换之后，设置按资产取值**——外层给原来那一份配的值（连锁住的在内）不落到替换它的那一份上（[PF-002 §5.5](../../product/PF-002-assets-settings-and-permissions/design.md#替换是一条路径不是一扇后门)）；与[权限](#ul-permission--权限--permission)相反


### UL-setting-category · 设置项类别 · Setting Category

> **中**：[资产](#ul-asset--资产--asset)声明一项[设置](#ul-setting--设置--setting)时**必须标上的那个类别**，
> 取值恰为四个：**偏好**（改错顶多难用）、**绑定**（指向本系统内另一份资产或一个位置）、
> **落点与身份**（东西在哪执行、连到哪、送到哪、以谁的名义、用哪把凭据）、**治理**（管别的设置与权限怎么起作用：禁用、`immutable`、连接件的触发会话的默认运行模式）。
> 它决定**这项值能从哪些归属层来**：落点与身份类、以及治理类里除禁用之外的项，
> [工作区](scope-and-resolution.md#ul-workspace--工作区--workspace)那一级一概配不了，加载时与权限一起滤掉。
> 判一项归哪类问两句：**改了会不会换掉这次运行要过的那道权限门、或改变一道已放行的权限实际放出去的是什么——会，就是落点与身份**；
> **改的若是那道门自己怎么判**（锁不锁得住、「本该问人」的那一刻是拒、是算、还是放）**——就是治理**。
>
> **EN**: The class an asset **must assign to each setting entry it declares**, drawn from
> exactly four values: **preference** (a wrong value is at worst inconvenient), **binding**
> (points at another asset or a position inside this system), **placement and identity**
> (where something runs, connects or delivers, on whose behalf, with which credential), and
> **governance** (how other settings and permissions take effect: disable, `immutable`, a
> connector's default run mode for triggered sessions). It decides **from which ownership
> layers a value may come**: placement-and-identity entries and every governance entry other
> than disable can never be set by the workspace level; they are filtered at load time together
> with permissions. Two tests classify an entry: **would changing it change which permission
> gate this run passes through, or what an already-granted permission actually lets out — if so,
> placement and identity**; **does it change how that gate itself decides** (whether a lock
> holds, what happens at the moment a person should be asked) **— if so, governance**.

- **形态**：属性
- **出处**：[PF-002 §5.2 设置项分四类](../../product/PF-002-assets-settings-and-permissions/design.md#设置项分四类资产声明每一项时必须标类别)（rev 24）
- **别混**：与[能力标识](scope-and-resolution.md#ul-capability-identifier--能力标识--capability-identifier)里的「类别」不是一回事——
  那是**资产**的八类之一，这是**设置项**的四类之一；正文里裸写「类别」指前者
- **注意**：工作区**自己带来的**资产，其落点类设置随资产一起来——这条限定挡的是**改别人资产的落点**


### UL-permission · 权限 · Permission

> **中**：[资产](#ul-asset--资产--asset)的一种属性，约束 agent **能执行什么动作、边界在哪**。
> 每一层对它能做两件事之一：**锁下一个允许集合**（一道界），或**不锁、只挑一个值**。
> 各层的界按[收窄](scope-and-resolution.md#ul-scope-composition-semantics--作用域合成语义--scope-composition-semantics)取交集，
> **更外层锁下的界，更具体的一层突破不了**；界内取哪一个，由最具体的、挑在界内的那一层定。
> **配成「禁止」的，锁不锁都是界。**
>
> **EN**: A kind of attribute on an asset, constraining **which actions the agent may
> perform and where the boundary lies**. Each layer may do one of two things with it:
> **lock a set of permitted values** (a bound), or **pick a single value without locking**.
> Bounds combine by **narrowing** — their intersection across layers — so **a bound locked
> further out cannot be broken by a more specific layer**; within the bound, the value is
> the one picked by the most specific layer whose pick falls inside it. **Setting "forbid"
> is a bound whether locked or not.**

- **形态**：属性
- **出处**：[PF-001 §4 设置、权限、资产](../../product/PF-001-identity-scope-and-agent-constraints/design.md#设置权限资产)（rev 22） · [§6.2](../../product/PF-001-identity-scope-and-agent-constraints/design.md#62-三种合成语义)（rev 22） · [PF-002 §5.3](../../product/PF-002-assets-settings-and-permissions/design.md#53-两个例子两种合成)（rev 24）
- **别混**：**不是[租户角色](subjects-and-ownership.md#ul-tenant-role--租户角色--tenant-role)**——角色是**身份**的属性，权限是**资产**的属性
- **注意 ①**：**一次运行之内，权限变了，[动作空间](#ul-action-space--动作空间--action-space)不变**；运行之间也只有[「谁可以使用它」](circulation-and-entitlement.md#ul-usable-by--谁可以使用它--usable-by)会让下一次运行的构成变小——它改的是装不装进来
- **注意 ②**：**不锁的配值不是界**——组织配「问一下」而不锁，成员挑「自动」就生效；组织要守的边界必须锁（「禁止」除外）
- **注意 ③**：**同标识替换之后，外层为这个身份锁下的界照样管着替换它的那一份**；那一份少声明了锁住的某一项，那一项按最严算（[PF-002 §5.5](../../product/PF-002-assets-settings-and-permissions/design.md#替换是一条路径不是一扇后门)）
- **注意 ④**：**权限项有哪几项由资产的类别定，作者不能自加**；[「谁可以使用它」](../../product/PF-002-assets-settings-and-permissions/design.md#谁可以使用它是各类资产共用的一项权限)是各类共用的一项

## 八类资产


### UL-skill · 技能 · Skill

> **中**：**一段可复用的工作方法**——告诉 agent「遇到这类事情该怎么做」。
> 主体是**可读的指引正文**，可以带上所需的资源文件。
> **读取一个 skill 不等于运行它带的脚本**，也不自动装载它的全部附件。
>
> **EN**: **A reusable way of working** — telling the agent how to handle a class of
> situations. Its substance is **readable guidance text**, optionally accompanied by
> resource files. **Reading a skill is not running the scripts it carries**, nor does
> it automatically load all of its attachments.

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-002 §4 Skill](../../product/PF-002-assets-settings-and-permissions/design.md#skill)（rev 24） · [PF-006 §4 技能的说明](../../product/PF-006-tools-and-skills/design.md#技能的说明)（rev 20）
- **别混**：Skill 说**怎么做**，[Tool](#ul-tool--工具--tool) 是**做的那个动作**。「代码审查该看哪些地方」是 skill，「读文件」是 tool
- **注意**：它的**说明**是触发与路由的依据——[常驻](reach-and-availability.md#ul-residency--常驻--residency)时进系统提示词的是 name 与说明，`Skills().search` 按它找，替换件换掉的也是它；正文与资源按需取
- **能组合**：Tool

