### UL-tool · 工具 · Tool

> **中**：**一个可被调用的动作。**它的身份是**这一类里的那个 name**；参数形状、说明、返回形状
> 与实现都跟着实现走，**所以同一个 name 下可以有平台、组织、租户各自的一份，彼此替代**。
> 一个 tool 可以是**多命令**的，而**整套命令在组装时只占一个[槽位](#ul-prompt-slot--提示词槽位--prompt-slot)**。
>
> **EN**: **One invocable action.** Its identity is **its name within this kind**; the argument
> shape, description, result shape and implementation all travel with the implementation, so
> **one name may have a platform, an organization and a tenant version, each standing in for
> the others**. A tool may be **multi-command**, and **the whole command set occupies a single
> slot** at assembly time.

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-002 §4 Tool](../../product/PF-002-assets-settings-and-permissions/design.md#tool)（rev 24）
- **别混**：**子命令是 tool 的内部结构，不是独立资产**——随这个 tool 一起被持有、配置与授权
- **⚠️ 别混**：**「工具」这个词指三样东西，寿命各不相同**——
  [工具定义](execution-and-outcome.md#ul-tool-definition--工具定义--tool-definition)（数据，长期）、
  动作空间里的那个条目（构成，绑 agent runtime）、
  [工具执行](execution-and-outcome.md#ul-tool-execution--工具执行--tool-execution)（计算资源，**绑会话**）。
  **本条说的是它作为一类资产**
- **注意**：本系统把 Tool 定为**顶层资产**，与前身 `omne-next` 把它归为「组件」**有意相反**
- **能组合**：Skill


### UL-mcp · MCP · MCP

> **中**：**一个外部工具来源的接入点。**接进来之后，它提供的动作可被 agent 使用。
> **接入点本身是资产，它带来的那些动作不单独成为资产**——随它一起被持有、授权与治理。
> **对端的可用性与版本不由本系统掌握**：它提供的动作可能今天有明天没有，**而这不是故障**。
> **对端的每一个动作在动作空间里是一个工具条目**——不常驻、经取用入口发现；
> 动作集**每一次[执行尝试](agent-runtime-loop.md#ul-run-attempt--执行尝试--run-attempt)开始前与可用性一起重算，一次尝试之内不变**。
>
> **EN**: **An access point to an external source of tools.** Once connected, the
> actions it offers become usable by the agent. **The access point is the asset; the
> actions it brings are not assets of their own** — they are held, authorized and
> governed along with it. **Availability and versioning on the far side lie outside
> this system's control**, so an action present today may be gone tomorrow — **and
> that is not a fault**. **Each action on the far side is one tool entry in the action
> space** — not resident, found through the discovery entry; the action set is
> **recomputed before each run attempt together with availability and does not change within an attempt**.

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-001 §4 资产的种类](../../product/PF-001-identity-scope-and-agent-constraints/design.md#资产的种类)（rev 22） · [PF-002 §4 MCP](../../product/PF-002-assets-settings-and-permissions/design.md#mcp)（rev 24） · [PF-006 §6.13](../../product/PF-006-tools-and-skills/design.md#613-mcp-接入点带来的动作)（rev 20）
- **别混**：Tool 是**一个动作**，MCP 是**一批动作的来源**——**MCP 本身不可被调用**
- **注意**：它连对端用的是 [MCP 凭据](#ul-mcp-credential--mcp-凭据--mcp-credential)，挂在持有上，不是[模型凭据](#ul-model-credential--模型凭据--model-credential)
- **能组合**：**不组合任何资产**


### UL-connection-target · 连接目标 · Connection Target

> **中**：**[MCP](#ul-mcp--mcp--mcp) 接入点的一项[落点与身份类](#ul-setting-category--设置项类别--setting-category)设置：这个接入点连到对端的哪里。**
> 它与 [MCP 凭据](#ul-mcp-credential--mcp-凭据--mcp-credential)一起决定这个接入点接的是哪一处、以哪个账号进门；
> 各层按持有配值，**工作区那一级配不了它**。**它不是接入点的身份**——身份是接入点的 name。
>
> **EN**: **A placement-and-identity setting on an MCP access point: where on the far side the access
> point connects.** Together with the MCP credential it decides which endpoint the access point reaches
> and under which account it gets in; layers assign it through their holdings, and **the workspace level
> cannot set it**. **It is not the access point's identity** — that is the access point's name.

- **形态**：属性
- **出处**：[PF-002 §4 MCP](../../product/PF-002-assets-settings-and-permissions/design.md#mcp) ·
  [§5.2 设置项分四类](../../product/PF-002-assets-settings-and-permissions/design.md#设置项分四类资产声明每一项时必须标类别)（rev 24）
- **别混**：**不是[投递目标](interaction-and-dispatch.md#ul-inbound-target--投递目标--inbound-target)**——那是连接件把外面的消息送进哪个会话，方向相反
- **注意**：连不上（含凭据还没取或已失效），这个接入点带来的动作[一律不可用](../../product/PF-006-tools-and-skills/design.md#接入点连不上它的动作就是不可用)（PF-006 rev 20）


### UL-connector · 连接件 · Connector

> **中**：**一个外部消息来源的接入件**，把外部的消息送进来。
> **八类里只有它回答「agent 从哪里被触达」**——另外六类回答「agent 能做什么、怎么做」，
> [拓展件](#ul-loop-extension--拓展件--loop-extension)回答「推进的时候在哪些位置插手」。
> **只能送消息进来**——没有数据读取面，也没有管理面。
> **它带身份鉴权**：接对面服务的哪个账号（鉴权绑定），是持有上的一项[落点与身份类设置](#ul-setting-category--设置项类别--setting-category)，
> **只在租户那一层配**，随租户身份不同而不同。它的权限只有一项：**能不能安装**。
> **它声明一份事件目录**——它会送进来的每一种[连接件事件类型](#ul-connector-event-type--连接件事件类型--connector-event-type)；每条送进来的消息恰属其中一种，持有上以[事件订阅](#ul-event-subscription--事件订阅--event-subscription)选其中哪几种真的送进来，目录外与未订阅的受理时拒绝、看得见。
> **外部的事进到会话里有两种投递方式，动作主体不同**：① **已有的会话开口接收**——它这一侧的配置是[投递目标](interaction-and-dispatch.md#ul-inbound-target--投递目标--inbound-target)（送进哪一个已有的会话）；② **它送来的事件经受理开出一个新会话**——它这一侧的配置是**触发会话的默认运行模式**（持有上必配的一项[治理类设置](#ul-setting-category--设置项类别--setting-category)，哪一层都没给过的开不出新会话，作者默认不算），新会话怎么建归会话那一块。
> **送进来的消息以谁的身份处理，不是权限，是一条固定规则**：按它落进的那个会话创建那一刻捕获的租户身份，对面那个账号只作来源留在消息上；两种投递方式都照这一条。**外部内容只说得出自己是目录里的哪一种**，进哪个会话、开不开新会话、以谁的身份、按什么运行模式它一样都选不了。
>
> **EN**: **An inbound attachment for an external message source**, delivering outside
> messages into the system. **Of the eight, only this one answers how the agent can
> be reached**: six answer what an agent can do and how, and a loop extension answers
> where to intervene as the agent proceeds. It can **only deliver messages inward** — it
> exposes no data-read surface and no management surface. **It carries identity
> authentication**: which account on the far side it binds to (the authentication binding) is a
> placement-and-identity setting on the holding, **configured at the tenant layer only**, differing
> per tenant identity. Its one permission is **whether it may be installed**. **It declares an event
> catalog** — every connector event type it can deliver; each delivered message belongs to exactly one,
> the holding's event subscription picks which of them are actually delivered, and anything outside the
> catalog or unsubscribed is refused at intake, visibly. **There are two delivery modes, with different
> acting subjects**: ① **an existing session opens itself to receive** — the connector-side configuration
> is the inbound target (which existing session); ② **an event it delivers opens a new session through
> intake** — the connector-side configuration is the **default run mode for triggered sessions** (a
> governance setting the holding must supply; a connector no layer has ever given it to cannot open a
> session, and the author's default does not count), while how that session is created belongs to the
> session topic. **Whose identity an incoming message is handled under is not a permission but a fixed
> rule**: the tenant identity the receiving session captured at creation; the far-side account is kept on
> the message as its source only; both modes follow it. **External content can only say which catalog
> type it is** — never which session, whether to open one, under whose identity or in which run mode.

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-001 §4 资产的种类](../../product/PF-001-identity-scope-and-agent-constraints/design.md#资产的种类)（rev 22） · [PF-002 §4 Connector](../../product/PF-002-assets-settings-and-permissions/design.md#connector) · [两种投递方式](../../product/PF-002-assets-settings-and-permissions/design.md#两种投递方式动作主体不同) · [触发会话的默认运行模式](../../product/PF-002-assets-settings-and-permissions/design.md#触发会话的默认运行模式)（rev 24）
- **注意 ①**：**一人多账户不立新对象**——同一租户身份要接同一服务的两个账号，就是两份 name 不同的连接件
- **注意 ②**：「能不能安装」的取值与其余「谁可以……」[同一种](circulation-and-entitlement.md#ul-usable-by--谁可以使用它--usable-by)：一组租户角色，外加一个「自己」
- **别混**：MCP 是**我出去调它**，Connector 是**它进来找我**
- **能组合**：**不组合任何资产**
- **注意 ③**：**事件目录不是它的身份**——身份仍是 name，换一份实现目录可以不同；消息包整份随信封进来（厚信封），只送一个标识回头去拉本版不支持
- **注意 ④**：**② 那一路本 topic 只定它存在与它这一侧的配置**——受理怎么开新会话、同一件事来两次怎么办归 [PF-014](../../product/PF-014-inbound-intake-and-queueing/design.md#57-穷举一什么会让队列从空变成非空)（rev 8）；新会话以哪个 agent definition、哪个租户身份建归 PF-015；同一份连接件的一条事件走哪一路由什么决定，PF-002 记为待裁（D-6）
- **注意 ⑤**：触发会话的默认运行模式**只管此后开出来的新会话**，与 ① 那一路无关；租户可调，组织的值与锁照默认与强制那一套管着；工作区配不了


### UL-connector-event-type · 连接件事件类型 · Connector Event Type

> **中**：**一份[连接件](#ul-connector--连接件--connector)在正文里声明的、它会送进来的一种外部事件：一个类型名、一段说明、一个消息包形状。**
> 目录由作者定、随正文走；**每条送进来的外部消息恰属于其中一种**，不在目录里的类型受理时拒绝。
> 说明是给模型读的：被订阅的那几种，说明进组合了这份连接件的 agent 的上下文。
>
> **EN**: **One kind of external event a connector declares in its body that it can deliver: a type name,
> a description and a payload shape.** The catalog is authored and travels with the body; **every
> delivered message belongs to exactly one declared type**, and an undeclared type is refused at intake.
> The description is for the model: for the subscribed types it enters the context of any agent that
> composes this connector.

- **形态**：属性（连接件正文的一项声明；与工具定义里的命令表同一种东西）
- **出处**：[PF-002 §4 事件目录与事件订阅](../../product/PF-002-assets-settings-and-permissions/design.md#事件目录与事件订阅)（rev 24）
- **别混**：不是[入站到达](interaction-and-dispatch.md#ul-inbound-arrival--入站到达--inbound-arrival)——到达是一次事实，类型是它属于哪一类
- **注意 ①**：消息包**整份随信封进来**（厚信封）；连接件没有读取面，接收方无处回拉
- **注意 ②**：**目录不是连接件的身份**——换一份实现，目录可以不同；目录是结构化的，说明给模型读、形状给受理对


### UL-event-subscription · 事件订阅 · Event Subscription

> **中**：**一份连接件持有上的一项设置：目录里哪几种[连接件事件类型](#ul-connector-event-type--连接件事件类型--connector-event-type)真的送进来。**
> 取值是目录的子集；作者可给默认，组织层与租户层各配各的，**只在持有那一侧求值**——工作区与会话那两级没有它的值；**agent 不在运行时改它**——它是持有它的那几层配的值，不是 agent 的动作。
> 类别是**偏好**。
>
> **EN**: **A setting on a connector holding: which of the declared connector event types are actually
> delivered.** Its value is a subset of the catalog; the author may give a default, and the organization
> and tenant layers each configure their own, **evaluated on the holding side only** — the workspace and
> session levels carry no value for it. **An agent never changes it at run time** — it is a value assigned
> by the layers holding the connector, not an agent action. Its category is **preference**.

- **形态**：属性（一项[设置](#ul-setting--设置--setting)）
- **出处**：[PF-002 §4 事件目录与事件订阅](../../product/PF-002-assets-settings-and-permissions/design.md#事件目录与事件订阅) · [§5.2 设置项分四类](../../product/PF-002-assets-settings-and-permissions/design.md#设置项分四类资产声明每一项时必须标类别)（rev 24）
- **注意 ①**：未订阅的类型送来，受理拒绝，不是静默丢弃
- **注意 ②**：组合了这份连接件的 agent，上下文里**只带被订阅的那几种**的说明——怎么带归 PF-010


### UL-loop-extension · 拓展件 · Loop Extension

> **中**：挂在某个 [Loop 拓展点](agent-runtime-loop.md#ul-loop-extension-point--loop-拓展点--loop-extension-point)上的**一段判断或动作**。
> 它声明自己**挂在哪个位置**、**管哪些情形**，以及自己的**[干预力](agent-runtime-loop.md#ul-intervention-power--干预力--intervention-power)**——
> 只观察 / 可改写 / 可否决——**没有「放宽」一档**，拓展件不能把「问一下」变成放行。
> **可否决那一档含「落一张[决策卡片](interaction-and-dispatch.md#ul-decision-card--决策卡片--decision-card)等人」**：拓展件用的是 loop 自己等外部应答的那个原语，与主流程共用。
> **它是 opt-in 的可插拔服务**：不可用（它依赖的服务用不了、它自己起不来）时，**按它的[拓展件不可用处置](agent-runtime-loop.md#ul-extension-unavailability-policy--拓展件不可用处置--extension-unavailability-policy)办**——
> 租户挂上的默认跳过（视作已卸载，这一次这个位置没有它），注册时可声明为否决；系统自带的由预先声明的指定挂件顶上；哪一种都在日志里看得见。
> 可用却运行时报错，按它那一类的处置策略办，「可否决挂了当否决」是可否决一档的默认策略。
> **同一个位置可以挂多个拓展件，各干各的；先后就是它们在装配清单里的顺序。**
>
> **EN**: **A piece of judgement or action** attached to one loop extension point. It
> declares **which position it sits at**, **which cases it covers**, and its own
> **intervention power** — observe, rewrite, or veto; **there is no "relax" level**, an
> extension cannot turn "ask" into "allow". **Veto includes "drop a decision card and wait
> for a person"**: the extension uses the loop's own primitive for awaiting an external
> reply, shared with the main flow. **It is an opt-in pluggable service**: when unavailable
> (a service it depends on is down, or it fails to start) **its extension unavailability policy
> applies** — tenant-installed ones default to skip (treated as unloaded, absent from that position
> this time) and may declare veto at registration; system-provided ones are replaced by a
> pre-declared fallback extension; either way it is visible in the log. When available but failing
> at run time, it is handled by the policy for its kind, "a failed veto-capable extension counts as
> a veto" being that level's default. **Several extensions may sit at the same position, each doing
> its own thing; their order is their order in the assembly manifest.**

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-002 §4 Loop Extension](../../product/PF-002-assets-settings-and-permissions/design.md#loop-extension) · [不可用处置是这一件自己的声明](../../product/PF-002-assets-settings-and-permissions/design.md#不可用处置是这一件自己的声明)（rev 24） ·
  [PF-012 §4 拓展件](../../product/PF-012-agent-loop-and-run/design.md#拓展件) · [§5.8](../../product/PF-012-agent-loop-and-run/design.md#58-loop-拓展点)（rev 15）
- **注意 ④**：**不可用处置是这一件自己的一项声明，不是设置，也不是权限**——持有它的各层不给它配值、也收窄不了它；取值与谁能用哪一种归 PF-012。声明了否决，也要干预力求出来是可否决才算数
- **注意 ③**：**外来 hook**（Claude Code / Codex 格式）导入为拓展件时按其声明的输出能力定档；**工作区带来的一律只观察**
- **⚠️ 别混**：**它不是[拓展点](agent-runtime-loop.md#ul-loop-extension-point--loop-拓展点--loop-extension-point)**——
  **拓展点是位置，拓展件是挂上去的东西**。位置由[状态点](../../product/PF-012-agent-loop-and-run/design.md#53-改日志的动作与纯派生的动作)推出、数目有限；**挂什么没有上限**
- **注意 ①**：**干预力是它的[权限](#ul-permission--权限--permission)，不是[设置](#ul-setting--设置--setting)**——
  **装一个拓展件、却只给它「只观察」，是成立的配法**
- **注意 ②**：**它只能靠改[会话日志](record-and-context.md#ul-session-log--会话日志--session-log)起作用**，不能不留痕地改变下一步
- **能组合**：**不组合任何资产**（同 [MCP](#ul-mcp--mcp--mcp) 与[连接件](#ul-connector--连接件--connector)）


### UL-slash-command · 斜杠命令 · Slash Command

> **中**：**人主动发起某件事的入口**，人在交付面敲 `/什么` 触发；**只由交付面识别、只对人**，模型不调用它。
> 它**绑定**要做的事，**绑定目标恰有三种**：**一段自定义提示词**；**装配的一个 skill**（其正文直接成为消息里的一个内容块）；
> **一条系统业务流程**（命令服务或查询服务的某一个动作，不进队列、不成为消息）。
> **命令本身不是做事的东西，它是指路牌**。**不含键盘控制或 shell 命令。**
>
> **EN**: **An entry point through which a person initiates something**, triggered by
> typing `/something` on a delivery surface; **recognized only by the delivery surface and
> only for people** — the model never invokes it. It **binds** to the thing to be done, and
> **the binding target is exactly one of three**: **a custom prompt**; **an assembled skill**
> (whose text becomes one content block of the message); or **a system business flow** (one
> action of a command or query service, which enters no queue and becomes no message).
> **The command is not the doing; it is a signpost.** It covers **no keyboard control and no
> shell commands.**

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-002 §4 Slash Command](../../product/PF-002-assets-settings-and-permissions/design.md#slash-command)（rev 24）
- **别混**：Skill 是方法本身，Slash Command 是**发起它的入口**。绑定是**多对多**——一个 skill 可以有多个入口，也可以完全没有
- **注意 ①**：**名字**——交付面自己的动作名与系统业务流程型命令名是**系统保留名**，**一律在 `omne-official` 前缀下**；前两种绑定的命令**不得使用这个前缀**；同能力标识按资产替换规则
- **注意 ②**：**为什么单独是一类资产**：为将来的可编程性留口子——出处同上
- **注意 ③**：一个会话认得哪些，是它的[会话斜杠命令集](#ul-session-slash-command-set--会话斜杠命令集--session-slash-command-set)——**没有权限用的，对这个会话就不存在**
- **注意 ④**：**绑定目标与[参数声明](#ul-command-parameter-declaration--命令参数声明--command-parameter-declaration)是这条命令本身，不是设置**——各层配不出不同的值；想改一条命令展开什么，换一份同名的
- **能组合**：Skill（绑定）

