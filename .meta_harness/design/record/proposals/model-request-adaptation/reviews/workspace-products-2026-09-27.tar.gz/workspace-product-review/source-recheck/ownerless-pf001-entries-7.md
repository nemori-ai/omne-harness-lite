### UL-organization · 组织

- **宿主**：—
- **身份**：正文未述
- **生灭**：由已激活账号创建，创建者同时成为超管、其租户同时产生，一次提交，不存在无管理员的中间态 → 存续；**团队组织本版无终结路径**（不要求解散）；**个人组织唯一的消失路径是随未激活[账号](#ul-account--账号)到期清除**——它在注册第 2 步随账号记录一并建起，账号记录到期被清时随之消失
- **依据**：[PF-001 §4 组织](../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)（rev 22）；[PF-001 §4 个人组织](../product/PF-001-identity-scope-and-agent-constraints/design.md#个人组织)（rev 22）；[PF-001 §4 未激活的账号记录不会永久占着那个名字](../product/PF-001-identity-scope-and-agent-constraints/design.md#未激活的账号记录不会永久占着那个名字)（rev 22）；[PF-001 flows §1.4](../product/PF-001-identity-scope-and-agent-constraints/flows.md#14-创建组织)（rev 22）


### UL-invitation · 邀请

- **宿主**：[组织](#ul-organization--组织)——**发出它的那个组织**：它不存在了，这份邀请随即自动过期。它指向一个账号，但那个账号在接受之前对它没有任何持有；个人组织发不出邀请
- **身份**：正文未述
- **生灭**：发出，**带一个到期时刻** → 被接受（成员关系建立，[租户](#ul-tenant--租户)随之产生）；接受之前可以被撤回，也会过期——邀请这一类有默认时长、发出时发起者可指定这一份的，发出它的组织不存在了则自动过期（**这一分支本版无触发源**：[没有任何邀请指向个人组织——个人组织发不出邀请，而团队组织无终结路径](#ul-organization--组织)）；撤回、过期或接收账号拒绝都不产生成员关系；若再合作须另发一份
- **依据**：[PF-001 flows §1.5](../product/PF-001-identity-scope-and-agent-constraints/flows.md#15-邀请与加入)（rev 22）；[PF-001 flows §2](../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常)（rev 22）；[PF-001 §4 两种邀约都会过期](../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)（rev 22）

- **本轮依据复核**：[PF-001 接收方拒绝](../product/PF-001-identity-scope-and-agent-constraints/design.md#接收方可以明确拒绝待处理邀约)（rev 22）增加终结分支；宿主、身份与接受结果不变，不新增对象。


### UL-affiliation-request · 隶属请求

- **宿主**：正文未述。由一个[组织](#ul-organization--组织)的超级管理员发出、指向另一个组织；个人组织不参与隶属关系，既发不出也收不到
- **身份**：正文未述
- **生灭**：发起，**带一个到期时刻** → 被接受（下级组织的「上级组织」属性有了值，**不产生租户**）；接受之前可以被撤回，也会过期——隶属请求这一类有默认时长、发出时发起者可指定这一份的，它指向的组织不存在了则自动过期（**这一分支本版无触发源**：[没有任何隶属请求指向个人组织——个人组织不参与隶属关系，而团队组织无终结路径](#ul-organization--组织)）；撤回、过期或接收组织超管拒绝都不建立隶属；若再合作须另发一份
- **依据**：[PF-001 §4 隶属关系怎么建立与解除](../product/PF-001-identity-scope-and-agent-constraints/design.md#隶属关系怎么建立与解除)（rev 22）；[PF-001 §4 两种邀约都会过期](../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)（rev 22）；[PF-001 flows §1.7](../product/PF-001-identity-scope-and-agent-constraints/flows.md#17-建立与解除组织隶属)（rev 22）；[PF-001 flows §2](../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常)（rev 22）
- **未裁**：**宿主是发起方组织还是接收方组织**。两端都是组织，而正文只写了「它**指向的**那个组织不存在了则自动过期」——发起方组织没了它怎么样，正文没说。归 PF-001 的 owner，[已记入该 topic 的「已知的来源问题」](../product/PF-001-identity-scope-and-agent-constraints/decisions.md#四已知的来源问题)

- **本轮依据复核**：[PF-001 接收方拒绝](../product/PF-001-identity-scope-and-agent-constraints/design.md#接收方可以明确拒绝待处理邀约)（rev 22）增加终结分支；宿主、身份与接受结果不变，不新增对象。


### UL-tenant · 租户

- **宿主**：—（身份由[组织](#ul-organization--组织)与[账号](#ul-account--账号)共同确定）
- **身份**：（组织, 账号）二元组；不含角色。同一账号在两个组织里是两个租户
- **生灭**：账号加入组织即产生（注册时随个人组织产生第一个；创建组织时创建者的随之产生；接受邀请时产生）→ 加入到退出之间有效，角色可调 → 解除后不再有效，其租户级私有部分不可达但不销毁，历史记录照旧引用它 → 再次被邀请加入同一组织即重新有效，**回来的是同一个租户**，私有部分原样可用。身份由（组织, 账号）确定，不因断续而变；**已激活账号的租户本版无销毁路径**；**从未激活的账号到期清除时，随账号一起产生的第一个租户随之消失**
- **依据**：[PF-001 §4 租户](../product/PF-001-identity-scope-and-agent-constraints/design.md#租户)（rev 22）；[PF-001 §4 退出之后再加入，回来的是同一个租户](../product/PF-001-identity-scope-and-agent-constraints/design.md#退出之后再加入回来的是同一个租户)（rev 22）；[PF-001 §4 未激活的账号记录不会永久占着那个名字](../product/PF-001-identity-scope-and-agent-constraints/design.md#未激活的账号记录不会永久占着那个名字)（rev 22）；[PF-001 flows §3.3](../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)（rev 22）
- **并入**：「成员关系」——design 只定义租户，flows 却把「无 → 成员 → 无」的状态机挂在成员关系名下；二者同一身份，成员关系是租户「此刻有没有效」那一面。**分界：身份是值，有效性是记录**——(组织, 账号) 这一组合不生不灭、被显式携带；「此刻有没有效」才有状态、有写路径、有并发约束。**这不改变它是一个对象**，只是提醒不要把整体当成有状态的东西


### UL-asset · 资产

- **宿主**：—
- **身份**：两级——上层是[能力标识，即「类别 ＋ name」](../product/PF-002-assets-settings-and-permissions/design.md#身份是类别--name其余归实现)，求值的产出是「每个能力标识一个生效资产」；下层是具体资产，同一标识下可并存 official、组织自定义、租户自定义、复制进来的多份。具体资产自身靠什么标识，正文未述
- **生灭**：创作出草稿 → 修订 → 发布（该版本自此不可变）→ 再改成新版本；从租户范围提升到组织范围不可逆，**只换所有者、不动任何一份持有**；删除被分享出去的须先告知受影响方，不默认级联。删除之后如何，正文未述
- **依据**：[PF-002 §4 八类资产](../product/PF-002-assets-settings-and-permissions/design.md#八类资产)（rev 25）；[PF-002 §4 身份是「类别 ＋ name」](../product/PF-002-assets-settings-and-permissions/design.md#身份是类别--name其余归实现)（rev 25）；[PF-001 §4 资产的种类](../product/PF-001-identity-scope-and-agent-constraints/design.md#资产的种类)（rev 22）；[PF-001 §6.7](../product/PF-001-identity-scope-and-agent-constraints/design.md#67-创作与归属)（rev 22）；[PF-002 flows §3.3](../product/PF-002-assets-settings-and-permissions/flows.md#33-一个资产定义的版本)（rev 25）


### 使用成本明细

- **现象**：PF-001 要求「一次调用花掉的成本必须能算到发起它的那个租户头上，并能逐条列出来」，同时明说成本怎么算、明细怎么归集与呈现「目前没有对应的产品设计」
- **牵涉**：[PF-001 §6.4](../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)（rev 22）
- **谁来裁**：产品负责人——「观测与计量」这一块还没有 topic
- **闭合条件**：有 topic 认领计量，并说明一条明细是什么

