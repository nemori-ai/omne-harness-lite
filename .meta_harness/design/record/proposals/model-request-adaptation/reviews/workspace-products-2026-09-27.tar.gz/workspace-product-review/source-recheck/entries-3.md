### UL-command-parameter-declaration · 命令参数声明 · Command Parameter Declaration

> **中**：**一条[斜杠命令](#ul-slash-command--斜杠命令--slash-command)可选带的那份参数说明，每个参数配一句给人看的提示。**
> 它是这条命令本身的一部分，**不是设置**——不随持有它的那一层配出不同的值。
> **声明了的，按声明解析**，解析不通过就当场明说哪里不对、不发送；**没声明的，命令名之后的整段文本作一个自由参数**。三种绑定目标一条规则。
>
> **EN**: **The optional description of a slash command's parameters, each carrying a short hint for
> the person typing it.** It is part of the command itself, **not a setting** — no holding layer can give
> it a different value. **Where declared, input is parsed against it**, and a failed parse is reported on
> the spot, saying what is wrong, and nothing is sent; **where not, everything after the command name is
> one free-form argument**. The same rule holds for all three binding targets.

- **形态**：属性
- **出处**：[PF-002 §4 Slash Command](../../product/PF-002-assets-settings-and-permissions/design.md#slash-command)（rev 24） ·
  [PF-016 §5.7 人要做的事分三族](../../product/PF-016-cli-tui-delivery-surface/design.md#57-人要做的事分三族)（rev 10）
- **别混**：**不是工具调用的参数**——那是模型给出、按工具定义收齐之后才解析的；这里解析的是人敲进交付面的那一行
- **注意**：② 型命令里，人附带的参数**另成一个内容块**，不拼进 skill 的正文


### UL-plugin · 插件 · Plugin

> **中**：**把若干资产打包在一起分发与启用的单元。**装一个 plugin，等于一次性获得
> 它里面的全部东西；停用它，那些东西一起退场。
> **内含成员不取得独立的顶层生命周期**——不能单独卸载 plugin 里的某一个 skill。
>
> **EN**: **A unit for distributing and enabling a bundle of assets together.**
> Installing one grants everything inside at once; disabling it withdraws them all.
> **Its members have no independent top-level lifecycle** — one cannot uninstall a
> single skill out of a plugin.

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-001 §4 资产的种类](../../product/PF-001-identity-scope-and-agent-constraints/design.md#资产的种类)（rev 22） · [PF-002 §4 Plugin](../../product/PF-002-assets-settings-and-permissions/design.md#plugin)（rev 24）
- **别混 ①**：**不是 Cordis plugin**——那是运行时的代码装载单元，属技术设计。指它时**必须写全 `Cordis plugin`**
- **别混 ②**：Plugin 组合出来的**还是资产**，可以继续被组合；[Agent Definition](#ul-agent-definition--agent-定义--agent-definition) 组合出来的是**一个能跑的 agent**
- **能组合**：Skill、Tool、Slash Command、MCP、Connector、[拓展件](#ul-loop-extension--拓展件--loop-extension)，以及 Rules 这类声明性成员


### UL-agent-definition · Agent 定义 · Agent Definition

> **中**：**一个 agent 的静态定义**——它由什么组装而成、以什么面貌工作。
> **它不是会话，也不是[agent runtime](agent-runtime-loop.md#ul-agent-runtime--agent-runtime--agent-runtime)**：
> 改定义**不会**改变已经在跑的那个 agent，一个定义可以同时有很多个 agent runtime，
> **定义与实例分别演进**。sub-agent 的定义**也属于这一类**。
>
> **EN**: **The static definition of an agent** — what it is assembled from and how it
> presents itself at work. **It is neither a session nor an agent runtime**:
> editing a definition **does not** change an agent already running, one definition
> may have many agent runtimes going at once, and **the definition and the running
> thing evolve separately**. A sub-agent's definition **is one of these too**.

- **形态**：变体（父：[资产](#ul-asset--资产--asset)）
- **出处**：[PF-001 §4 资产的种类](../../product/PF-001-identity-scope-and-agent-constraints/design.md#资产的种类)（rev 22） · [PF-002 §4 Agent Definition](../../product/PF-002-assets-settings-and-permissions/design.md#agent-definition)（rev 24）
- **注意**：混为一谈会出现「**我改了配置，正在跑的任务突然换了行为**」这种事故
- **能组合**：**全部八类**（含其他 Agent Definition 作为 sub-agent）——**它是唯一能组合全部八类的**


### UL-asset-version · 资产版本 · Asset Version

> **中**：**一个[资产](#ul-asset--资产--asset)在某一次发布时定下的那一份内容。**
> **已发布的版本不可变**——要改，只能在它之上再发一个新的。
> 每一份资产有**自己独立的一条版本线**，从 v1 起各数各的：
> 一份[复制](circulation-and-entitlement.md#ul-asset-copy--资产复制--asset-copy)过去的资产
> **落在目标侧自己的线上**，源侧的 v7 在那边可能是 v2。
>
> **EN**: **The content of an asset as fixed by one release of it.** **A published
> version is immutable**: changing anything means publishing a new one on top of it.
> Every asset has **a version line of its own**, counted from v1 independently of
> everyone else's — an asset copied elsewhere **lands on the receiving side's own
> line**, so the source's v7 may be v2 over there.

- **形态**：对象
- **出处**：[PF-002 flows §3.3 一个资产定义的版本](../../product/PF-002-assets-settings-and-permissions/flows.md#33-一个资产定义的版本)（rev 24） ·
  [PF-003 §6.4 可复制的对象](../../product/PF-003-asset-transfer-and-sharing/design.md#64-可复制的对象)（rev 6）
- **别混 ①**：**不是[版本选用](circulation-and-entitlement.md#ul-version-selection--版本选用--version-selection)**——
  那说的是**某个范围当前选了哪一个**，是一条关系；这一条说的是**被选的那个东西**
- **别混 ②**：**草稿不是版本**——它还在变，**复制与分享都只认已发布的**
- **注意**：**发现有新版本不静默替换已选用的那个**——选哪一版是消费方的决定；持有选了「追随当前版」的，新版一发布就用上，那是持有上写明的选择，不算静默替换

## 构成关系


### UL-asset-composition · 资产组合 · Asset Composition

> **中**：资产之间、资产与 agent 之间、属性与资产之间的**同一种关系**，不是几种。
> 三条规则：**引用指向[能力标识](scope-and-resolution.md#ul-capability-identifier--能力标识--capability-identifier)**、
> **组合图不得成环**、**组合不转移[定义所有权](circulation-and-entitlement.md#ul-definition-ownership--定义所有权--definition-ownership)**。
>
> **EN**: **One and the same relation** holding between assets, between assets and an
> agent, and between attributes and assets — not several mechanisms. Three rules:
> **references point at capability identifiers**, **the composition graph must be
> acyclic**, and **composition transfers no definition ownership**.

- **形态**：属性
- **出处**：[PF-002 §5.1](../../product/PF-002-assets-settings-and-permissions/design.md#51-组合是一种关系不是几种)（rev 24）
- **别混**：与[作用域合成语义](scope-and-resolution.md#ul-scope-composition-semantics--作用域合成语义--scope-composition-semantics)不是一回事——**裸写「组合」不作数**
- **注意 ①**：这一节在 PF-002 里标着「**PM 推导，待产品负责人确认**」
- **注意 ②**：**「环」指沿引用展开会回到自己、展开不完的那一种**；[Skill 与 Tool 互相引用不算](../../product/PF-002-assets-settings-and-permissions/design.md#谁能组合谁)——两边各装一份就完


### UL-session-slash-command-set · 会话斜杠命令集 · Session Slash-Command Set

> **中**：**一个会话此刻认得的那批[斜杠命令](#ul-slash-command--斜杠命令--slash-command)**：
> 这个会话[装配](agent-runtime-loop.md#ul-agent-assembly--agent-装配--agent-assembly)时从求值结果里取出、
> 会话所属的那个人有权使用的那些，再去掉此后被收回了权限的。
> 交付面只按它识别命令——**不在里面的名字，对这个会话就是不存在**，
> 不论那条命令在别处有没有、这个人为什么用不了。
> 它住在会话的一张注册表里；资产的增删与禁用不会让它自己变，**要等人发对应的 reload 热更新那张注册表**（③ 型失败后系统自动刷新；一次完整的重新装配也会重填它）。
>
> **EN**: **The slash commands a session recognizes right now**: those taken from the
> evaluation result when the session is assembled and that the person the session belongs
> to is permitted to use, less any whose permission has been withdrawn since. The delivery
> surface recognizes commands against this set alone — **a name outside it does not exist
> for this session**, whether or not such a command exists elsewhere and whatever the
> reason the person cannot use it. Adding, removing or disabling assets does not change it
> by itself; it lives in a session registry and **changes only when the matching reload hot-updates that registry** (refreshed automatically after a type-③ failure; a full re-assembly refills it too).

- **形态**：视图
- **出处**：[PF-002 §4 会话认得哪些命令，什么时候变](../../product/PF-002-assets-settings-and-permissions/design.md#会话认得哪些命令什么时候变)（rev 24）
- **别混**：[动作空间](#ul-action-space--动作空间--action-space)在权限变了时**不变**，agent 因此知道「存在，只是不许」；
  会话斜杠命令集**恰好相反**——无权使用的**就不在里面**，人得到的回答是「没有这个命令」
- **注意**：**收窄即时，放宽要等 reload**——权限一收回，那条命令此刻起就不在；
  会话进行中新得到权限的，要等下一次 reload 或重新装配才进来


### UL-mcp-credential · MCP 凭据 · MCP Credential

> **中**：一个 [MCP](#ul-mcp--mcp--mcp) 接入点**连对端时出示的那一份凭据**，
> 是这个接入点**挂在[租户](subjects-and-ownership.md#ul-tenant--租户--tenant)那一层**的一份[持有](circulation-and-entitlement.md#ul-asset-holding--资产持有--asset-holding)上的一项
> [落点与身份类](#ul-setting-category--设置项类别--setting-category)[设置](#ul-setting--设置--setting)：**一份持有一份值**，
> 决定对端**以哪个账号**认这个接入点。**组织那一层不持有它**——组织接入的接入点，由每个成员在自己的租户层取；工作区那一级取不了。
> 值有两种来路——**直接配上的一个静态值**，
> 或**经 OAuth、由人到对端点同意后取得的那一份**；两种来路是同一项设置。
> 经 OAuth 取得的那一份**续期不算换值**，续出来的仍归同一份持有。
>
> **EN**: The credential an **MCP** access point presents to its far side — a
> placement-and-identity **setting** on one **holding** of that access point **at the tenant
> layer**, **one value per holding**, deciding **which far-side account** the access point is
> recognised as. **The organization layer holds none** — for an access point the organization
> connected, each member obtains one at their own tenant layer; the workspace level cannot obtain
> one. The value arrives by one of two routes: **a static value set directly**, or **one
> obtained through OAuth after a person consents on the far side**; both are the same
> setting. Renewing an OAuth-obtained value **is not a change of value**, and what it
> renews into stays with the same holding.

- **形态**：属性
- **出处**：[PF-002 §4 MCP](../../product/PF-002-assets-settings-and-permissions/design.md#mcp) ·
  [MCP 凭据：一份持有一份](../../product/PF-002-assets-settings-and-permissions/design.md#mcp-凭据一份持有一份静态的或经-oauth-取得的) ·
  [§5.2 设置项分四类](../../product/PF-002-assets-settings-and-permissions/design.md#设置项分四类资产声明每一项时必须标类别)（rev 24）
- **⚠️ 别混**：**不是[模型凭据](#ul-model-credential--模型凭据--model-credential)**——模型凭据挂在**租户身上**、一租户一把、不是设置；
  MCP 凭据挂在**接入点的持有**上、一份持有一份、是一项设置。**两者同一条路：组织那一层都不持有**
- **别混 ②**：[连接件](#ul-connector--连接件--connector)的**鉴权绑定**方向相反（对面进来找我），不是这一项；它同样只在租户那一层配
- **注意**：经 OAuth 取得的那一步，正文**不裸写「授权」**（撞使用权与[授权表达](interaction-and-dispatch.md#ul-authorization-expression--授权表达--authorization-expression)），
  也不写「OAuth 登录」（撞[登录状态](subjects-and-ownership.md#ul-login-state--登录状态--login-state)）；写「经 OAuth 取得」


### UL-version-selection · 版本选用 · Version Selection

> **中**：**某个范围当前实际选了它的哪个版本。**
>
> **EN**: **Which version of it a given scope currently has selected.**

- **形态**：属性
- **出处**：[PF-001 §4 拥有、获权、选用](../../product/PF-001-identity-scope-and-agent-constraints/design.md#拥有获权选用)（rev 22）
- **别混**：**裸写「选用 / selection」不作数**——它专指**选哪个版本**
- **注意**：它记在[持有](#ul-asset-holding--资产持有--asset-holding)上，**有两种：钉在某一版，或追随当前版**；不另说时追随当前版，而那是持有上写明、看得见的选择——新版一发布就用上，不算静默替换（[PF-002 flows §3.3](../../product/PF-002-assets-settings-and-permissions/flows.md#33-一个资产定义的版本)）

