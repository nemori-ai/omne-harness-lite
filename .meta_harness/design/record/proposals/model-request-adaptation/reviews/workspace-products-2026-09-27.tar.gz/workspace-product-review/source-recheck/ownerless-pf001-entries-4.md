### UL-immutable-marker · 不可覆盖标记 · Immutable Marker

> **中**：一层给出某个值时可以附加的标记，表示这个值**不可再被上层覆盖**。
> 不加即「**默认**这样」，加了即「**必须**这样」。**一个标记同时管三处**：
> 设置的字段值、权限的取值、资产的替换。
>
> **EN**: A marker a layer may attach to a value it supplies, meaning the value
> **cannot be overridden by any higher layer**. Without it the layer says
> "**by default** this"; with it, "**it must be** this". **One marker covers three
> cases**: a setting's field value, a permission's value, and an asset substitution.

- **形态**：属性
- **出处**：[PF-001 §6.2 默认与强制](../../product/PF-001-identity-scope-and-agent-constraints/design.md#默认与强制immutable)（rev 22） · [PF-002 §5.4](../../product/PF-002-assets-settings-and-permissions/design.md#54-默认与强制一个机制三处适用)（rev 25）
- **注意 ①**：对权限而言，`immutable(v)` 就是把允许集合**收窄到单元素** `{v}`——**强制是收窄的特例**；权限上**带它的配值是界、不带的只是挑选**，唯独配成「禁止」的不带也是界
- **注意 ③**：锁资产替换时**不问被锁的是 official 还是自定义**——组织或租户在自己那层把某份 official 的持有标上它，
  下面就换不掉；[工作区](#ul-workspace--工作区--workspace)那一级**配不了它**
- **注意 ②**：[禁用](circulation-and-entitlement.md#ul-asset-disable--资产禁用--asset-disable)的析取语义
  **等价于「布尔设置 ＋ 真即 immutable」**——**不是第四处，也不是另一套机制**
- **注意 ③**：**[工作区](#ul-workspace--工作区--workspace)那一级同样压不动锁住的项**——
  它在设置这一维虽然[压过租户](../../product/PF-002-assets-settings-and-permissions/design.md#58-三条层序各答一个问题)，
  覆盖也只发生在**没被锁死**的项上


### UL-attribute-projection · 属性投影 · Attribute Projection

> **中**：某一层的设置或权限，是**它持有的资产各自属性**在这一层上的投影——
> **是视图，不是对象**，不需要维护，**是持有关系的函数**。
> 真正可被读写的最小单位是[属性配值](#ul-attribute-assignment--属性配值--attribute-assignment)。
>
> **EN**: A layer's settings or permissions are a **projection** of the attributes of
> the assets it holds. It is a **view, not an object**: nothing to maintain, being a
> **function of the holding relation**. The smallest read-write unit is the
> **attribute assignment**.

- **形态**：视图
- **出处**：[PF-001 §4 设置、权限、资产](../../product/PF-001-identity-scope-and-agent-constraints/design.md#设置权限资产)（rev 22） · [PF-002 §5.2](../../product/PF-002-assets-settings-and-permissions/design.md#组织的设置是视图不是对象)（rev 25）
- **注意**：**没有「组织的设置」这个对象。**把它当对象实现，就会出现一份**独立于资产的字段表**，两者各自演化，最终对不上


### UL-permission-bound · 权限界 · Permission Bound

> **中**：**一层在一项[权限](capabilities-and-composition.md#ul-permission--权限--permission)上锁下的允许集合**——带[不可覆盖标记](#ul-immutable-marker--不可覆盖标记--immutable-marker)的那一条[配值](#ul-attribute-assignment--属性配值--attribute-assignment)，锁成一个值是它的特例；
> **执行权限配成「禁止」的，锁不锁都算界**。各层的界**取交集**：更具体的一层只能在外层的界里再收，突破不了；
> 界锁成空集，每一次调用都被拒。
>
> **EN**: **The set of allowed values a layer locks down on one permission** — an assignment carrying the
> immutable marker, locking to a single value being the special case; **an execution permission set to
> "deny" counts as a bound whether locked or not**. The bounds of all layers **intersect**: a more specific
> layer can only narrow within the outer bound, never break out of it; a bound locked to the empty set
> rejects every call.

- **形态**：属性
- **出处**：[PF-002 §5.3 两个例子，两种合成](../../product/PF-002-assets-settings-and-permissions/design.md#53-两个例子两种合成) ·
  [§5.5 替换是一条路径](../../product/PF-002-assets-settings-and-permissions/design.md#替换是一条路径不是一扇后门)（rev 25） ·
  [PF-001 §6.2 三种合成语义](../../product/PF-001-identity-scope-and-agent-constraints/design.md#62-三种合成语义)（rev 22）
- **别混**：**不锁的配值不是界**——那是[权限挑选](#ul-permission-pick--权限挑选--permission-pick)；组织说「默认问一下」而不锁，是在说「没人另挑就用它」，不是「只许问一下」
- **注意**：**界跟着[能力标识](#ul-capability-identifier--能力标识--capability-identifier)走**——同标识替换之后，外层为这个标识锁下的界照样管着替换它的那一份；替换件的声明里少了被锁的那一项，那一项按最严算
- **注意 ②**：**裸写「界」不作数**——单字，到处都是


### UL-permission-pick · 权限挑选 · Permission Pick

> **中**：**一层在一项[权限](capabilities-and-composition.md#ul-permission--权限--permission)上配下、但没有锁的那个值**：它不划范围，只在[界](#ul-permission-bound--权限界--permission-bound)里挑一个。
> 求值时**从最具体的一层往外，取第一个落在界内的挑选**；作者声明的默认值是最外面那一个挑选；挑到界外的不生效。
> **谁都没挑到界内的，取界内离最具体的那个挑选最近的一档，一样近取严的。**
>
> **EN**: **A value a layer sets on a permission without locking it**: it draws no boundary, it only
> picks within the bound. Evaluation takes, **from the most specific layer outward, the first pick that
> falls inside the bound**; the author's declared default is the outermost pick; a pick outside the bound
> has no effect. **If no pick falls inside, the result is the level within the bound closest to the most
> specific pick, the stricter one on a tie.**

- **形态**：属性
- **出处**：[PF-002 §5.3 两个例子，两种合成](../../product/PF-002-assets-settings-and-permissions/design.md#53-两个例子两种合成)（rev 25） ·
  [PF-001 §6.2 三种合成语义](../../product/PF-001-identity-scope-and-agent-constraints/design.md#62-三种合成语义)（rev 22）
- **别混**：**「设成自动」看着像放宽，其实是在界内挑一个**——界不空，分档的权限（执行权限、干预力）求出来就恰好是一档
- **注意**：**执行权限配成「禁止」的不是挑选，是界**——任何一层的「禁止」都不能被更具体的一层挑掉


### UL-runtime-context · 运行时 context · Runtime Context

> **中**：**会话推进中，在 [agent loop](agent-runtime-loop.md#ul-agent-loop--agent-loop--agent-loop) 内
> 被模型、工具、拓展点之一消费的、[消息](record-and-context.md#ul-message--消息--message)之外的那些上下文。**
> **它是一块一块的**：每块是一份数据，多数是一张**就地更新**的表单，也有实时算出来的；
> **每块都有生产者**（会话本身，或会话外的某个东西）**和消费者**（那三个角色的一个或多个）。
> [协作范围 context](#ul-collaboration-scope-context--协作范围-context--collaboration-scope-context)
> 与[个人 context](#ul-personal-context--个人-context--personal-context) 都是其中的块。
>
> **EN**: The context **outside the messages** that is consumed, within the agent loop, by
> one of three roles — **the model, tools, extension points**. It comes **in blocks**: each
> block is a piece of data, mostly a form **updated in place**, sometimes computed on the
> spot; each has **a producer** (the session itself, or something outside it) and **consumers**
> (one or more of those three roles). Collaboration-scope context and personal context are
> among its blocks.

- **形态**：总称
- **出处**：[PF-015 §4 runtime context](../../product/PF-015-session-lifecycle-and-ownership/design.md#runtime-context)（rev 13）；块的两类来源沿用 [PF-001 §4 Context](../../product/PF-001-identity-scope-and-agent-constraints/design.md#contextagent-运行时可感知的上下文信息)（rev 22）
- **弃用说法**：~~会话上下文感知域~~——**同一个概念**，正文统一写 runtime context
- **别混 ①**：**不是 Cordis 的 `Context`**——那是依赖注入与生命周期的容器，属技术设计。指它时**必须写全 `Cordis Context`**
- **别混 ②**：**不是[给模型看的上下文](../index.md#记录与上下文)**。**裸写「上下文 / context」在跨 topic 的文字里一律不作数**，[已记为冲突](../conflicts.md#现有冲突)
- **⚠️ 别混 ③**：**不是[会话日志](record-and-context.md#ul-session-log--会话日志--session-log)。**
  日志**只追加**、历史全都在、自己会说话；它**就地更新**、只回答「现在是什么」、
  **变了要专门通知**。**一个答「发生过什么」，一个答「现在是什么」**
- **注意 ①**：**判它进不进来只看一条**——**在 agent loop 内被那三个角色之一消费（依赖）**。
  不看形态、不看归谁维护、不看重不重要
- **注意 ②**：**「会话要维护的状态」是另一个圈，两者有交集不重合**——
  [模态投影](../../product/PF-013-model-profiles-and-invocation/design.md#模态投影)是会话要维护的，
  但那是**提供给会话外的服务用的**，会话内没人消费，**因此不是它**。
  那一类的正名是[会话日志投影](record-and-context.md#ul-session-log-projection--会话日志投影--session-log-projection)
- **注意 ③**：**[当下可用性](reach-and-availability.md#ul-current-availability--当下可用性--current-availability)也不是**——
  **消费它的是 runtime 本身**，它在组装那一步就被用掉了
- **注意 ④**：**工具和拓展点也读它。**它**从来不只是「给模型的上下文」**
- **⚠️ 注意 ⑤**：**变更怎么被会话感知，有推与拉两条**——
  **推**由那一块的生产者发起，**只在这个会话还有[运行](agent-runtime-loop.md#ul-run--运行--run)没闭合时才进得来**，
  **会话空闲时推来的一律丢弃，不落日志**；**拉**由 [agent runtime](agent-runtime-loop.md#ul-agent-runtime--agent-runtime--agent-runtime) 自己做，
  [每一次执行尝试起来时取一次当前快照](../../product/PF-012-agent-loop-and-run/design.md#每一次尝试开始都要做四件事)。
  **因此[因果链记的是这个会话感知到的变化，不是世界上发生过的每一步](../../product/PF-014-inbound-intake-and-queueing/design.md#610-注入的上下文变了没有运行在跑时什么都不做)**
- **⚠️ 注意 ⑥**：**除了实时算的那些，每一块都要能恢复**——
  [会话被重新加载、归档被撤销之后，它们必须还在](../../product/PF-015-session-lifecycle-and-ownership/design.md#58-存储要守住的两件事)。
  **实时算的那些没有「恢复」这回事**


### UL-collaboration-scope-context · 协作范围 context · Collaboration-Scope Context

> **中**：「**我现在在哪个组织、以什么租户身份、什么角色**」。由组织与租户承载。
> 它一换，**能用的资产、能做的事、怎么做全都变**。
> 四个[作用域层](#ul-scope-layer--作用域层--scope-layer)是**它内部**的层次。
>
> **EN**: **Which organization I am in, under which tenant identity, in which role.**
> Carried by the organization and the tenant. When it changes, **the assets
> available, the actions allowed and the way they are performed all change.** The
> four scope layers are the layers **inside it**.

- **形态**：视图
- **出处**：[PF-001 §4 Context](../../product/PF-001-identity-scope-and-agent-constraints/design.md#contextagent-运行时可感知的上下文信息)（rev 22）
- **别混**：**不是[当前租户身份](subjects-and-ownership.md#ul-current-tenant-identity--当前租户身份--current-tenant-identity)。**那一条只是「**此刻以哪个租户身份行事**」那**一项选择**；这一条是由它算出来的**整块信息**——在哪个组织、什么租户身份、什么角色


### UL-personal-context · 个人 context · Personal Context

> **中**：**属于这个人本身的偏好**——界面语言、时区、通知方式一类。由账号承载，
> **跟着人走，在所有组织里都一样**。它**不是范围化对象**，**不参与任何层的合成**。
>
> **EN**: **Preferences belonging to the person themself** — interface language, time
> zone, notification channel and the like. Carried by the account, it **follows the
> person and is identical across all organizations**. It is **not a scoped object**
> and **takes part in no layer composition**.

- **形态**：属性
- **出处**：[PF-001 §4 Context](../../product/PF-001-identity-scope-and-agent-constraints/design.md#contextagent-运行时可感知的上下文信息)（rev 22）
- **注意**：「**正交**」的意思是两者**独立变化**——切换组织不改界面语言，改界面语言也不影响自己在哪个组织。因此**不能用同一套层次去合成**

返回[统一语言入口](../README.md) · [全部词条索引](../index.md)

### UL-account · 账号 · Account

> **中**：一个自然人在本系统中的产品身份，只承担**标识、鉴权、聚合**三件事。
> 它先于任何组织存在，**不持有任何[范围化对象](scope-and-resolution.md#ul-scoped-object--范围化对象--scoped-object)**。
>
> **EN**: A natural person's product identity in the system, carrying exactly three
> duties — **identify, authenticate, aggregate** that person's tenants into one
> place for viewing and switching. It exists prior to any organization and **holds
> no scoped objects**.

- **形态**：对象
- **出处**：[PF-001 §4 账号](../../product/PF-001-identity-scope-and-agent-constraints/design.md#账号)（rev 22）
- **别混**：账号回答「你是谁」，[租户](#ul-tenant--租户--tenant)回答「你的东西归哪儿」。**一个账号对应多个租户**
- **注意 ①**：一个现实中的人可以持有多个账号；系统**不核验、不关联、也不记录**它们属于同一人。**账号是一个自然人全部 context 的最大边界**，两个账号之间没有任何通路
- **注意 ②**：**未激活的那条记录有留存期限。**[注册第 1 步](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#11-注册)建立的账号处于未激活状态并占住[登录标识](#ul-login-identifier--登录标识--login-identifier)；期限**按部署配置**，[期限内用同一标识、同一凭据重来认回的是同一条记录，到期则记录清除、登录标识随之释放，连同为它建的个人组织与第一个租户一起消失](../../product/PF-001-identity-scope-and-agent-constraints/design.md#未激活的账号记录不会永久占着那个名字)。**这不是账号终止**——被清掉的是一条从未成为可用账号的记录，那三样从未承载过任何东西；**已激活的账号本版没有任何消失路径**

