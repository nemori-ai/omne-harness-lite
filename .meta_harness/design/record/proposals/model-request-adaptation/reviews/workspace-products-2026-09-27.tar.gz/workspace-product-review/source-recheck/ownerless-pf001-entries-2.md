### UL-usage-right · 使用权 · Usage Right

> **中**：**一个范围对一份[资产](capabilities-and-composition.md#ul-asset--资产--asset)有没有使用它的权利。**
> 定义者对自己的资产直接有；被[分享](#ul-asset-sharing--资产分享--asset-sharing)的一方（一个组织，或一个租户）从确认起有，
> 直到自己移除、分享方撤销、两个组织的隶属关系解除，或**分享的任一方是一个租户时，它的成员关系解除**。
> 它**不蕴含**所有权，也**不证明**节点已安装、agent 已激活或某次动作已获准。**个人与多个组织的使用权不自动叠加或相互借用。**
>
> **EN**: **Whether a scope is permitted to use an asset.** The definer has it outright;
> a recipient of sharing — an organization or a tenant — has it from confirmation until it removes the share, the sharer
> revokes it, the affiliation between the two organizations ends, or, **where either party to the share is a tenant,
> that tenant's membership ends**. It **entails no
> ownership**, and **proves nothing** about whether a node has installed it, an agent has
> been activated, or a particular action has been approved. **Usage rights held
> personally and through several organizations neither stack nor lend themselves to one
> another.**

- **形态**：属性
- **出处**：[PF-001 §4 拥有、获权、选用](../../product/PF-001-identity-scope-and-agent-constraints/design.md#拥有获权选用) · [§6.4](../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)（rev 22） · [PF-003 §6.10](../../product/PF-003-asset-transfer-and-sharing/design.md#610-分享给的是获权不是拥有) · [§6.12](../../product/PF-003-asset-transfer-and-sharing/design.md#612-关系解除之后)（rev 6）
- **别混**：**论域只有资产。**[模型档案](capabilities-and-composition.md#ul-model-profile--模型档案--model-profile)不是资产，一个范围允不允许某条档案由设置与权限的求值决定，不叫使用权
- **注意 ①**：**没有暂停，没有到期**——它只有「有」与「没有」（[C-15 的裁决](../conflicts.md#现有冲突)）
- **注意 ②**：**结束了就不复活**——关系断了又接上（重新隶属、重新加入），它不自己回来；要用，再分享一次，那是[新的一段分享关系](#ul-sharing-relationship--分享关系--sharing-relationship)


### UL-version-selection · 版本选用 · Version Selection

> **中**：**某个范围当前实际选了它的哪个版本。**
>
> **EN**: **Which version of it a given scope currently has selected.**

- **形态**：属性
- **出处**：[PF-001 §4 拥有、获权、选用](../../product/PF-001-identity-scope-and-agent-constraints/design.md#拥有获权选用)（rev 22）
- **别混**：**裸写「选用 / selection」不作数**——它专指**选哪个版本**
- **注意**：它记在[持有](#ul-asset-holding--资产持有--asset-holding)上，**有两种：钉在某一版，或追随当前版**；不另说时追随当前版，而那是持有上写明、看得见的选择——新版一发布就用上，不算静默替换（[PF-002 flows §3.3](../../product/PF-002-assets-settings-and-permissions/flows.md#33-一个资产定义的版本)）


### UL-revocation-is-not-stop · 撤销不等于强制停止 · Revocation Is Not a Stop

> **中**：角色变更、退出、登录到期、主动更换凭据引起的登录失效、撤权、撤销分享，影响的是**下一道尚未通过的准入**。
> **旧菜单、缓存与历史成功不能继续当作授权**；而**已经开始的调用是否停止，
> 由独立的运行控制决定**。
>
> **EN**: A role change, a departure, login expiry, login invalidation after a credential change, a revocation, a share being withdrawn
> — each affects **the next admission not yet granted**. **Stale menus, caches and
> past successes do not continue to serve as authorization**; and **whether a call
> already under way is stopped is decided by run control, separately.**

- **形态**：规则
- **出处**：[PF-001 §6.6](../../product/PF-001-identity-scope-and-agent-constraints/design.md#66-撤销不等于强制停止)（rev 22）
- **别混**：与[强制停止](agent-runtime-loop.md#ul-forced-stop--强制停止--forced-stop)**不是一件事**

## 一个范围手上有什么


### UL-asset-holding · 资产持有 · Asset Holding

> **中**：**一个范围与一份[资产](capabilities-and-composition.md#ul-asset--资产--asset)之间的持有关系，带一个启用/[禁用](#ul-asset-disable--资产禁用--asset-disable)标记**；
> 范围指组织、租户或[工作区](scope-and-resolution.md#ul-workspace--工作区--workspace)。
> 它是**配值资格的来源**——一层要为某资产配[设置](capabilities-and-composition.md#ul-setting--设置--setting)或
> [权限](capabilities-and-composition.md#ul-permission--权限--permission)，前提是它持有该资产；
> 它同时是那一层的设置与权限作为[属性投影](scope-and-resolution.md#ul-attribute-projection--属性投影--attribute-projection)算出来时的定义域。
> **这一级为它配下的每一个值，就挂在这份持有上**（[属性配值](scope-and-resolution.md#ul-attribute-assignment--属性配值--attribute-assignment)）。
> **资格本身来自[拥有那个定义](#ul-definition-ownership--定义所有权--definition-ownership)或[获得使用权](#ul-usage-right--使用权--usage-right)**；
> 加入即产生，[移除](#ul-asset-removal--资产移除--asset-removal)即消失，**禁用不使它消失**。
>
> **EN**: The relation between a scope — an organization, a tenant or a workspace — and an
> asset it **holds**, **carrying an enabled/disabled flag**. It is **where the right to
> configure comes from**: a layer may set an asset's settings or permissions only if it holds
> that asset, and it is likewise the domain over which that layer's settings and permissions
> are projected. **Every value that level supplies hangs on this holding** (an attribute
> assignment). **The entitlement behind it comes from owning the definition or from a granted
> usage right.** It begins when the asset is added and ends when the asset is removed;
> **disabling does not end it.**

- **形态**：属性
- **出处**：[PF-002 §5.2 三方分工](../../product/PF-002-assets-settings-and-permissions/design.md#三方分工资产定形状各层配值运行时求值) · [PF-002 §6.4](../../product/PF-002-assets-settings-and-permissions/design.md#64-移除与禁用是两个动作) · [PF-002 flows §3.1 一个资产在某个范围里](../../product/PF-002-assets-settings-and-permissions/flows.md#31-一个资产在某个范围里)（rev 25） · [PF-001 §6.1 层次](../../product/PF-001-identity-scope-and-agent-constraints/design.md#61-层次)（rev 22）
- **别混**：与[定义所有权](#ul-definition-ownership--定义所有权--definition-ownership)不是一回事——**持有的不一定是自己的**，[被分享来的](#ul-asset-sharing--资产分享--asset-sharing)照样持有。**裸写「持有」不作数**：正文也用它说「持有使用权」「持有待处理消息队列」
- **注意 ①**：正文**未述它靠什么标识**；工作区那一级持有的资产算不算[自定义件](#ul-customized-asset--自定义件--customized-asset)，正文没说。
  **工作区那一级照样配得了[禁用](#ul-asset-disable--资产禁用--asset-disable)**，
  **但只对它自己提供的那批资产生效**——这一条已经裁过了
- **注意 ②**：**配值跟着持有走。**移除，这份持有没了，挂在它上面的
  [属性配值](scope-and-resolution.md#ul-attribute-assignment--属性配值--attribute-assignment)**一起消失**；
  禁用，持有还在，**配的值一个不丢**
- **注意 ③**：**一层对一个[能力标识](scope-and-resolution.md#ul-capability-identifier--能力标识--capability-identifier)至多持有一份**——同一层可以有好几份同标识的资产，替代发生在持有上；
  持有上还记着[版本选用](#ul-version-selection--版本选用--version-selection)：钉在某一版，或追随当前版
- **注意 ④**：**把资产从租户范围提升到组织范围，只换所有者，不动任何一份持有**
  （[PF-001 §6.7](../../product/PF-001-identity-scope-and-agent-constraints/design.md#67-创作与归属)）
- **注意 ⑤**：**形态是「属性」说的是它的所指，不是它的存储**——它是范围与资产之间的一层关系，
  [C-17](../conflicts.md#现有冲突) 已由产品负责人裁为属性；**它存不存成一条独立的记录、怎么标识，归系统架构设计**，不因此改变形态


### UL-asset-origin · 资产来源 · Asset Origin

> **中**：一个资产是 **official** 还是 **customized**。
> **它不是独立于[作用域层](scope-and-resolution.md#ul-scope-layer--作用域层--scope-layer)的第三个维度，而是层次的体现**：
> 两者的关系就是**出厂默认层与其上各层在资产合成中的关系**，不需要另一套规则。
>
> **EN**: Whether an asset is **official** or **customized**. **It is not a third
> dimension alongside scope layers but an expression of them**: the relation between
> the two is simply that between the factory-default layer and the layers above it in
> asset composition — no separate rule set is needed.

- **形态**：属性
- **出处**：[PF-001 §4 来源](../../product/PF-001-identity-scope-and-agent-constraints/design.md#来源official-与-customized)（rev 22）
- **别混**：**裸写「来源」不作数**——它专指 official / customized 这个二分
- **注意**：来源**不能靠任意请求自报来冒充**


### UL-official-asset · 官方件 · Official Asset

> **中**：位于**出厂默认层**的资产，**是组装出一个 agent 的最小必需**。
> 它**不需要授权**，也**不可被禁用**——组织的超级管理员同样没有「不允许成员使用它」这项权力；
> **这不是一条可调整的权限设置，是结构性的。**
> 它可以被**同[能力标识](scope-and-resolution.md#ul-capability-identifier--能力标识--capability-identifier)的 customized 替代，但替代不是移除**。
>
> **EN**: An asset at the **factory-default layer**, constituting **the minimum
> required to assemble an agent at all**. It **requires no authorization** and
> **cannot be disabled** — not even by an organization's super administrator; **this
> is structural, not an adjustable permission setting.** It may be **substituted** by
> a customized asset bearing the same capability identifier, **but substitution is
> not removal**.

- **形态**：变体（父：[资产](capabilities-and-composition.md#ul-asset--资产--asset)）
- **出处**：[PF-001 §4 来源](../../product/PF-001-identity-scope-and-agent-constraints/design.md#来源official-与-customized)（rev 22）
- **别混**：它**不是**「一批可以申请使用的官方资源」，**它是底座**——没有它，agent 组装不出来
- **注意**：资产求值的**下界**：每个 official 能力标识下都必须有东西，**任何层都不能把它清空**


### UL-customized-asset · 自定义件 · Customized Asset

> **中**：自定义来源的资产，位于组织级或租户级。它对 official **只有一种关系：替代**——
> 当两者能力标识相同时。它**需要授权**，**可以被禁用**。
>
> **EN**: An asset from a customized origin, at the organization or tenant layer. Its
> only relation to an official asset is **substitution**, and only when the two share
> a capability identifier. It **requires authorization** and **can be disabled**.

- **形态**：变体（父：[资产](capabilities-and-composition.md#ul-asset--资产--asset)）
- **出处**：[PF-001 §4 来源](../../product/PF-001-identity-scope-and-agent-constraints/design.md#来源official-与-customized)（rev 22）
- **注意**：自定义来源**不会**因为被 agent 使用就给作者或该 agent 额外的行动权限——**资产决定组装，权限决定行动，两者不互相转化**

## 两个动作

> **你要不要让对方在关系结束之后还能用，决定了你该复制还是该分享。**


### UL-call-account · 调用账目 · Call Account

> **中**：一次[模型调用](#ul-model-call--一次模型调用--model-call)或一次[工具执行](#ul-tool-execution--工具执行--tool-execution)**身上的一项属性**：
> **它花了什么、产出了多少的账**——用量、费用、砍掉了多少增量、落在哪、跑了多久。
> **每一次调用或执行各留一份，进[会话日志](record-and-context.md#ul-session-log--会话日志--session-log)、不进给模型看的上下文**；
> **费用拿不到记「未知」，不记零**，拿到了再补一条；按尝试记明细、按运行汇总。
>
> **EN**: An attribute of one **model call** or one **tool execution**: **the account of
> what it consumed and produced** — usage, cost, how many increments were trimmed, where it
> ran, how long it took. **One per call or execution, written to the session log and never
> into the model-facing context**; **a cost that cannot be obtained is recorded as
> "unknown", never as zero**, and corrected by a later entry when it arrives; itemised per
> attempt, summed per run.

- **形态**：属性
- **出处**：[PF-006 §5.4 每一次执行都留一份账](../../product/PF-006-tools-and-skills/design.md#每一次执行都留一份账)（rev 20） ·
  [PF-009 §5.5](../../product/PF-009-context-message-types/design.md#到达的过程有它自己的语法)（rev 8） ·
  [PF-012 成本两层](../../product/PF-012-agent-loop-and-run/design.md#成本两层缺哪一层都会算错)（rev 15） ·
  [PF-013 §5.13](../../product/PF-013-model-profiles-and-invocation/design.md#513-模型请求的运行时可以被单独控制而它停了看首-token)（rev 13） ·
  [PF-001 §6.4](../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)（rev 22）
- **别混**：**不是[工具产出](#ul-tool-output--工具产出--tool-output)**——产出是给读者的东西，账是关于这次的事实
- **注意**：工具内部调外部服务产生的费用也记在这里，一次执行可以有多笔
- **注意 ②**：**一次模型调用「已经开口」也是它账目里的一笔**——第一份内容交到任何人眼前之前落进日志，
  带着开口的时刻；[停机之后靠它判断能不能重发](../../product/PF-013-model-profiles-and-invocation/design.md#已经开口说话了优先于其余各类)
- **注意 ③**：**运行终结之后才到的账照样落、归那个运行，并标明是迟到的**——
  [I-11](../../product/PF-012-agent-loop-and-run/design.md#617-run-这一层的七条不变式) 只禁止终结之后再发起新动作，不禁止补记已发起的那些

