### UL-workspace · 工作区 · Workspace

> **中**：带有自身身份和治理归属、跨会话持续的完整资源聚合包。它有一个治理所有者租户，也可以通过[租户—工作区关系](subjects-and-ownership.md#ul-tenant-workspace-relation--租户工作区关系--tenantworkspace-relation)授权其他租户参与。
> 它可以聚合文件、代码、数据、知识和自定义资产，访问它的 agent 类型可以不同；它不绑定一个固定目标，
> 也不是会话、agent、本地目录或执行环境边界。工作区可以有多个[工作区地址](#ul-workspace-address--工作区地址--workspace-address)，
> 并在部署节点上被装载为多个[工作区实例](#ul-workspace-instance--工作区实例--workspace-instance)。
> 工作区实例中的资产进入 PF-002 定义的工作区资产层：设置和资产可以按层求值，权限、落点与身份类及治理类例外
> 不从工作区放宽。

> **EN**: An identity-bearing, governed, persistent resource aggregate that spans sessions. It has one tenant with governance ownership and may authorize other tenants to participate. It may contain files, code, data, knowledge, and custom assets; it has no fixed goal and is neither a session, agent, local directory, nor execution boundary. A workspace may have multiple addresses and multiple materialized instances. Assets from its instance enter the PF-002 workspace asset layer, while permissions and placement/identity governance cannot be widened from the workspace.

- **形态**：对象
- **出处**：[PF-020](../../product/PF-020-workspace/design.md)（rev 21） · [PF-002 工作区资产层](../../product/PF-002-assets-settings-and-permissions/design.md#工作区)（rev 25）
- **别混**：地址和实例是它的访问与装载关系，不是另一个工作区；目录只是一个可能的地址/本地承载。
- **资产层规则**：工作区提供的自定义资产仍遵循 PF-002 的设置覆盖、同标识替换、权限过滤和禁用规则。
- **内容来源**：实例下的[共享目录](#ul-workspace-shared-directory--工作区共享目录--workspace-shared-directory)与[本地目录](#ul-workspace-local-directory--工作区本地目录--workspace-local-directory)是同一工作区层的两个来源，不是两份工作区。组织的[参与限制](#ul-workspace-participation-restriction--工作区参与限制--workspace-participation-restriction)与工作区访问授权分别成立。


### UL-workspace-instance · 工作区实例 · Workspace Instance

> **中**：一个工作区在某个部署节点上被装载或物化后、供会话和 agent 读写资源的具体工作入口。实例不固定归属于一个租户，可被多个租户的会话使用，关系与治理条件在各会话装配时按其租户身份求值。
> 实例也可在用户显式选择后，从已有的本地目录登记并接入，不要求由 Omne 下载资源后才产生。一个工作区可以有多个实例；实例独立于会话存活，可以先于会话存在，会话结束不自动卸载实例，实例卸载不等于工作区消失；不用时可不再附着，中心存储中的工作区销毁不连带清理本地实例。精确身份与状态转换仍待定义。

> **EN**: A materialized realization of a workspace on a deployment node through which a session and agent read and write resources. It is not bound to one tenant: sessions of multiple tenants may use it, with relations and governance evaluated for each session tenant during assembly. An instance may also be adopted from an existing local directory after an explicit user choice, without requiring Omne to download its resources. One workspace may have multiple instances. An instance has a lifecycle independent of sessions: it may exist before a session, and ending a session does not automatically unload it. Unloading an instance does not delete the workspace. An unused local instance need not be attached again, and destroying the centrally stored workspace does not trigger cleanup of local instances. Exact identity and state transitions remain open.

- **形态**：对象
- **出处**：[PF-020 工作区实例](../../product/PF-020-workspace/design.md)（rev 21）
- **未定**：实例的精确身份、并发和终止状态由 PF-020 后续修订决定。


### UL-workspace-address · 工作区地址 · Workspace Address

> **中**：找到或访问工作区或工作区实例的地址，可以是本地文件系统路径、GitHub 地址、Obsidian vault、Office 365 资源地址、云端存储地址或其他未来地址。
> 地址带有提供者类型，用途沿相应资源管理机制表达；统一工作区层不另设跨地址的权威来源或自动同步规则。它不是工作区身份，也不是访问凭据。同一工作区可以有多个地址，地址不可达不自动删除工作区。

> **EN**: A location or access address for a workspace or workspace instance, such as a local filesystem path, GitHub URL, Obsidian vault, Office 365 resource, or cloud storage address. It carries a provider type, with usage expressed by the underlying resource-management mechanism. The common workspace layer adds no cross-address authority or automatic synchronization rules. An address is neither the workspace identity nor a credential, and a workspace may have multiple addresses.

- **形态**：属性
- **出处**：[PF-020 工作区地址](../../product/PF-020-workspace/design.md)（rev 21）
- **别混**：地址不是工作区实例本身；知道地址不能绕过租户授权。


### UL-workspace-category · 工作区类别 · Workspace Category

> **中**：描述工作区资源与治理语义的属性，不等于地址提供者类型。当前保留 Omne 原生、外部资源和未来组合三个可扩展类别。

> **EN**: An attribute describing a workspace's resource and governance semantics, distinct from its address provider type. Current categories are Omne-native, external-resource, and a future composite category.

- **形态**：属性
- **出处**：[PF-020 工作区类别](../../product/PF-020-workspace/design.md)（rev 21）
- **别混**：GitHub、Obsidian、Office 365 等是地址提供者类型，不直接决定工作区类别。


### UL-workspace-management-type · 工作区管理类型 · Workspace Management Type

> **中**：工作区采用哪一种资源管理方式的属性，用于区分其持久保存、版本管理与实例同步所遵循的模型。租户创建 Omne Host 工作区时选择该属性，首版仅提供 Git；它不同于资源与治理意义上的工作区类别，也不同于地址提供者。

> **EN**: A workspace attribute identifying the model used to persist, version, and synchronize its resources with instances. A tenant selects it when creating an Omne Host workspace; the first release offers Git only. It is distinct from workspace category and address provider.

- **形态**：属性
- **出处**：[PF-020 工作区管理类型](../../product/PF-020-workspace/design.md#工作区管理类型)（rev 21）


### UL-git-workspace · Git 工作区 · Git Workspace

> **中**：工作区抽象（`Workspace`）中管理类型为 Git 的特化，类型记法为 `GitBasedWorkspace`。其共享资源以 Git 仓库管理，装载出的工作区实例使用相应 Git 工作副本；首版 Omne Host 仅提供此类型。它沿用工作区的逻辑身份与生命周期，Git 仓库地址、分支和提交版本不替代工作区身份。

> **EN**: The Git specialization of Workspace, denoted `GitBasedWorkspace`: shared resources are managed in a Git repository and instances use corresponding Git working copies. It is the only type offered by Omne Host in the first release. It retains the workspace's logical identity and lifecycle; repository addresses, branches, and commits do not replace that identity.

- **形态**：变体（父：[工作区](#ul-workspace--工作区--workspace)）
- **出处**：[PF-020 Omne Host 的首版范围](../../product/PF-020-workspace/design.md#omne-host-的首版范围)（rev 21）


### UL-workspace-address-provider · 工作区地址提供者 · Workspace Address Provider

> **中**：提供一个工作区地址的外部系统或宿主类型，例如 `omne-host`、`github`、`obsidian`、`office365` 和本地文件系统。
> 它描述地址的访问方式与可用能力，不是工作区身份、租户所有者或访问授权。

> **EN**: The external system or host type that provides a workspace address, such as `omne-host`, `github`, `obsidian`, `office365`, or a local filesystem. It describes access and capabilities, not workspace identity, tenant ownership, or authorization.

- **形态**：属性
- **出处**：[PF-020 工作区地址](../../product/PF-020-workspace/design.md)（rev 21）


### UL-workspace-shared-directory · 工作区共享目录 · Workspace Shared Directory

> **中**：工作区实例目录下约定名为 `.omne` 的子目录，用于自动发现和加载工作区共享的资产、配置与规范；变更属于向云端同步并与获准访问的其他租户共享的内容。
> 它与工作区本地目录使用相同结构，不是另一份工作区或独立授权来源。

> **EN**: The conventional `.omne` subdirectory of a workspace instance, used to discover and load shared assets, configuration, and instructions. Its changes belong to the content synchronized to cloud storage and shared with authorized tenants. It has the same structure as the workspace local directory and grants no authority itself.

- **形态**：位置
- **出处**：[PF-020 两个约定目录](../../product/PF-020-workspace/design.md#两个约定目录)（rev 21）


### UL-workspace-local-directory · 工作区本地目录 · Workspace Local Directory

> **中**：工作区实例目录下约定名为 `.omne.local` 的子目录，用于该实例的本地资产、配置与规范；实例可跨租户共用，各会话按自己的租户身份分别求值。其结构与 `.omne` 相同，内容不进入工作区共享同步，但不保证共用同一物理实例的租户之间不可见；同能力标识的可用资产优先于共享目录中的资产。
> 可以只为共享资产提供设置覆盖而不复制资产；若选用同名本地资产，则完整使用该本地实现，不叠加针对共享资产的设置覆盖。本地目录不是租户级资产层，也不因是本地内容而获得权限配值资格。

> **EN**: The conventional `.omne.local` subdirectory of a workspace instance, containing instance-local assets, configuration, and instructions. Multiple tenants may share the instance, with each session evaluating this source under its own tenant identity. It has the same structure as `.omne`, stays out of shared workspace synchronization without guaranteeing privacy between tenants using the same physical instance, and takes precedence for eligible assets with the same capability identifier. It may supply settings for a shared asset without copying the asset. When a same-identity local asset is selected, that local implementation is used as a whole, without applying settings intended to override the shared implementation. It is not the tenant asset layer and grants no permission-setting authority.

- **形态**：位置
- **出处**：[PF-020 两个约定目录](../../product/PF-020-workspace/design.md#两个约定目录) · [目录的合并与作用域](../../product/PF-020-workspace/design.md#目录的合并与作用域)（rev 21）


### UL-workspace-participation-restriction · 工作区参与限制 · Workspace Participation Restriction

> **中**：组织针对本组织租户以工作区身份参与开发、维护与写入设定的限制。配置可为不启用、仅本组织或仅同一组织隶属树，默认不启用；首版不提供逐租户或逐工作区的例外豁免。该限制不拦只读访问，也不代替工作区自身的访问授权；仅在会话装配时按当时的策略和组织树判定，运行中不热同步变更或逐次操作重判；当前不覆盖将项目作为普通本地目录使用的路径。

> **EN**: An organization's restriction on its tenants participating in development, maintenance, or writing through recognized workspace relations. It may be disabled, limited to the same organization, or limited to the same affiliation tree, and is disabled by default. The first release offers no per-tenant or per-workspace exemptions. It does not block read-only access or grant workspace access rights. It is evaluated only during session assembly using the policy and organization tree at that time, with no live policy synchronization or per-operation reevaluation. Using a project as an ordinary local directory is outside its current coverage.

- **形态**：规则
- **出处**：[PF-020 组织对参与范围的限制](../../product/PF-020-workspace/design.md#组织对参与范围的限制)（rev 21）


### UL-tenant-workspace-relation · 租户—工作区关系 · Tenant–Workspace Relation

> **中**：记录一个[租户](#ul-tenant--租户--tenant)与一个[工作区](scope-and-resolution.md#ul-workspace--工作区--workspace)之间当前关系的对象。
> 它区分治理所有者与被授权参与者，另带有效能力、来源和状态；治理中心用有效关系列出该租户当前可感知的工作区。
> 公开地址的发现不会自动产生这条关系。解除关系即删除该关系条目，中心托管工作区确认销毁后删除指向它的全部租户关系；在未重新显式登记前，该租户的会话使用原本地目录时，只按普通目录处理，不从其中加载工作区装配来源。

> **EN**: A durable object recording the current relationship between a tenant and a workspace. It distinguishes governance ownership from authorized participation and carries effective capabilities, origin, and status. A governance center lists a tenant's workspaces from its active relations; discovering a public address does not create one automatically. Unlinking deletes this relation entry; confirmed destruction of the centrally hosted workspace deletes all tenant relations pointing to it. Until explicitly registered again, subsequent sessions of that tenant treat the former local directory as an ordinary directory, without loading workspace assembly sources from it.

- **形态**：对象
- **出处**：[PF-020 租户—工作区关系](../../product/PF-020-workspace/design.md#租户工作区关系)（rev 21）
- **别混**：不是工作区实例，也不是一次会话的选择；实例是关系生效后在部署节点上的装载结果。
- **参与边界**：有效关系不替代所属组织的[工作区参与限制](scope-and-resolution.md#ul-workspace-participation-restriction--工作区参与限制--workspace-participation-restriction)；该限制针对开发、维护与写入，不拦原有资格下的只读访问。


### UL-workspace-super-administrator · 工作区超级管理员 · Workspace Super Administrator

> **中**：由某个工作区的创建者租户明确授予该工作区超管级别权限的租户。它是该租户相对于此工作区的授权角色，具有销毁该工作区、解除参与租户关系以及退出自身参与关系的资格；退出后失去该工作区的授权。它不是组织超级管理员身份，也不因获授权限而变更工作区的治理归属。创建者自身具有销毁资格，不要求先给自己授予此角色。仅创建者可以授予或撤回该角色，工作区超管不能转授；撤回角色保留参与关系，其余权限依已有授权。

> **EN**: A tenant explicitly granted super-administrator privileges for a particular workspace by that workspace's creator tenant. This workspace-scoped authorization role permits destruction of that workspace, removal of participant relations, and withdrawal of its own participation. Withdrawal ends its authorization for that workspace. It is distinct from an organization super administrator and does not change the workspace's governance ownership. The creator may destroy the workspace without a separate self-grant. Only the creator may grant or revoke this role; its holder cannot delegate it. Revocation preserves the participation relation and other independently granted permissions.

- **形态**：属性
- **出处**：[PF-020 治理关系解除与中心销毁](../../product/PF-020-workspace/design.md#治理关系解除与中心销毁)（rev 21）
- **边界**：不能单独删除仍存在的工作区的唯一治理所有者关系；本版不提供所有权移交。仅创建者授予和撤回，工作区超管不可转授；其余管理能力沿既有授权，不因名称推定全平台权限。


### UL-tenant-workspace-relation · 租户—工作区关系

- **宿主**：关联一个租户与一个工作区；独立宿主及租户端终止时的处理正文未述；中心托管工作区确认销毁后删除其全部租户关系，地址不可达不自动表示关系失效
- **身份**：记录某租户对某工作区的治理所有权或参与授权；精确标识与唯一性约束正文未述
- **生灭**：正文列明创建、邀请、导入或公开资源登记等来源，关系存在时可为有效、暂停等状态；解除关系即删除条目。在未重新显式登记前，该租户的会话使用原本地目录时按普通目录处理，目录中的工作区来源不参与装配，不连带删除其他租户关系。中心托管工作区确认销毁后删除全部关联租户关系。普通参与租户及工作区超管可退出自身参与关系，创建者或工作区超管可移除参与租户；普通参与者不能移除他人。创建者可撤回超管权限但保留参与关系，工作区超管不可转授。工作区存在时唯一治理所有者关系不可单独删除，本版不提供所有权移交。公开地址被发现不自动建立关系；关系有效也不代替组织参与限制
- **依据**：[PF-020 租户—工作区关系](../product/PF-020-workspace/design.md#租户工作区关系)（rev 21）

## 作用域与求值


### UL-workspace · 工作区

- **宿主**：[租户](#ul-tenant--租户)——工作区有一个治理所有者，也可通过租户—工作区关系授权其他租户参与
- **身份**：工作区自身的持久逻辑身份；具体格式和命名尚未由正文确定。工作区地址不是身份，工作区实例是它在部署节点上的装载对象
- **生灭**：跨会话和实例持续存在；中心托管工作区仅可由创建者或其明确授予工作区超管权限的租户销毁；确认销毁后全部租户关系删除，本地实例内容保留。一次实例卸载或地址不可达不等于工作区消失
- **依据**：[PF-020 工作区](../product/PF-020-workspace/design.md)（rev 21）；[PF-020 工作区实例](../product/PF-020-workspace/design.md)（rev 21）；[PF-020 工作区地址](../product/PF-020-workspace/design.md)（rev 21）；[PF-002 工作区资产层](../product/PF-002-assets-settings-and-permissions/design.md#工作区)（rev 25）


### UL-workspace-instance · 工作区实例

- **宿主**：部署节点上的一次工作区装载，可接入用户已有的本地目录；它代表一个工作区，但不拥有工作区
- **身份**：与工作区和部署节点关联的具体实例，不固定绑定一个租户，可被多个租户的会话共用；关系与治理条件按各会话装配时的租户身份求值。精确身份形式正文未述
- **生灭**：装载/物化后可供会话与 agent 使用，也可由用户显式选择已有目录首次登记并附着而接入；可先于会话独立存在；也可指定本地路径先装载再创建会话。会话结束不自动卸载实例，卸载不删除逻辑工作区。不用时不再附着即可；中心销毁不连带清理本地实例，不要求治理中心另设本地清理流程。精确状态规则正文未述。实例目录下承载 `.omne` 与实例本地 `.omne.local`，共用实例不保证该物理目录跨租户私有。Git worktree 创建不自动建立实例关联，显式作为工作区使用时再关联；同一会话可以组织多个 worktree 供 subagent 并行
- **依据**：[PF-020 工作区实例](../product/PF-020-workspace/design.md)（rev 21）

## 能力与构成

