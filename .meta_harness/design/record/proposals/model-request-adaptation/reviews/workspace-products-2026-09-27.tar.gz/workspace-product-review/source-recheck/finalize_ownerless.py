"""Verify final source text and record the actual audit/check results."""
import ast
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / '.meta_harness/tooling/src'))
from design_validation import github_anchor
namespace = {'github_anchor':github_anchor,'re':re}
helper = next(node for node in ast.parse((OUT/'prepare_ownerless.py').read_text()).body if isinstance(node,ast.FunctionDef) and node.name=='section')
exec(compile(ast.Module(body=[helper],type_ignores=[]),'reviewed-section-helper','exec'),namespace)
section = namespace['section']
digest = lambda text: hashlib.sha256(text.encode()).hexdigest()
inputs = json.loads((OUT/'ownerless-inputs.json').read_text())
record = json.loads((OUT/'ownerless-ruling-recheck.json').read_text())
for key,value in inputs['sections'].items():
    path,_,anchor = key.partition('#')
    assert section((ROOT/path).read_text(),anchor) == value['after'], key

for entry in record['entries']:
    source = (ROOT/entry['path']).read_text()
    heading = next(candidate for candidate in inputs['entries'] if candidate['path']==entry['path'] and candidate['id']==entry['id'])['title']
    blocks = list(re.finditer(r'^###\s+(.+?)\s*$',source,re.M))
    match_index = next(i for i,match in enumerate(blocks) if match[1]==heading)
    start = blocks[match_index].start()
    end = blocks[match_index+1].start() if match_index+1<len(blocks) else len(source)
    body = source[start:end]
    entry['current_entry_sha256'] = digest(body)
    entry['known_unknowns_after_review'] = [line for line in body.splitlines() if re.search(r'未裁|未定|未述|待确认|尚未|待定义|待裁',line)]
    new_refs = []
    old_keys = {(ref['path'],ref['anchor']) for ref in entry['references']}
    for match in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)',body):
        label,link = match.groups()
        topic = next((key for key in inputs['topic_revisions'] if key in link),None)
        if not topic:
            continue
        file,_,anchor = link.partition('#')
        relative = ((ROOT/entry['path']).parent/file).resolve().relative_to(ROOT).as_posix()
        current = section((ROOT/relative).read_text(),anchor)
        key = f'{relative}#{anchor}'
        assert key in inputs['sections'], key
        is_new = (relative,anchor) not in old_keys
        ref = {'topic':topic[:6],'from_revision':inputs['topic_revisions'][topic][0], 'to_revision':inputs['topic_revisions'][topic][1], 'label':label,'path':relative,'anchor':anchor, 'baseline_section_sha256':digest(inputs['sections'][key]['before']), 'current_section_sha256':digest(current), 'section_changed':inputs['sections'][key]['changed'], 'reference_added_for_scope_evidence':is_new}
        if is_new:
            assert entry['kind']=='domain_object' and entry['id']=='UL-tenant-workspace-relation' and anchor in ('治理关系解除与中心销毁','组织对参与范围的限制')
            ref['judgment']='补入已全文读取章节，直接支持新正文的 Host 删除权限范围及外仓装配限制；不新增产品判定。'
        new_refs.append(ref)
    entry['references'] = new_refs
    entry['scope_evidence_references_added'] = sum(ref['reference_added_for_scope_evidence'] for ref in new_refs)

record['scope_evidence_references_added'] = sum(entry['scope_evidence_references_added'] for entry in record['entries'])
record['projection_changes'] = [
 {'path':'.meta_harness/design/ubiquitous_language/index.md','scope':'四个受影响词条摘要随明确定义归位；保留上一轮 local 摘要修正。'},
 {'path':'.meta_harness/design/ubiquitous_language/conflicts.md','scope':'只追加 C37 新裁决接续，保留此前未知的真实历史。'},
 {'path':'.meta_harness/design/views/domain-object-map.md','scope':'官方工具生成，不手工编辑。'},
]
record['validation'] = {
 'final_referenced_source_consistency':'83 个引用章节全部与人工阅读输入逐字相同；无待复核 source drift。',
 'write':{'command':'.venv/bin/python .meta_harness/tooling/src/domain_objects.py --root .meta_harness/design --write','exit_code':0,'stdout':'ownerless-domain-object-write.stdout','stderr':'ownerless-domain-object-write.stderr'},
 'default_check':{'command':'.venv/bin/python .meta_harness/tooling/src/domain_objects.py --root .meta_harness/design','exit_code':0,'stdout':'ownerless-domain-object-check.stdout','stderr':'ownerless-domain-object-check.stderr'},
 'counts':{'terms':241,'objects':44,'pending':8},
 'scope_diff_check':{'command':'git diff --check -- .meta_harness/design/ubiquitous_language .meta_harness/design/domain_objects .meta_harness/design/views/domain-object-map.md','exit_code':0},
 'limits':'工具仅验证对应、版本和生成视图，不证明领域语义或产品实现；语义判断来自逐条 source review。',
}
record['final_file_sha256'] = {path:hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in sorted(set(record['changed_paths'])|{row['path'] for row in record['projection_changes']})}
(OUT/'ownerless-ruling-recheck.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'audit_sha256':hashlib.sha256((OUT/'ownerless-ruling-recheck.json').read_bytes()).hexdigest(),'prior_review_sha256':hashlib.sha256((OUT/'review.json').read_bytes()).hexdigest(),'map_sha256':hashlib.sha256((ROOT/'.meta_harness/design/views/domain-object-map.md').read_bytes()).hexdigest(),'references_added':record['scope_evidence_references_added'],'counts':record['validation']['counts']},ensure_ascii=False))
