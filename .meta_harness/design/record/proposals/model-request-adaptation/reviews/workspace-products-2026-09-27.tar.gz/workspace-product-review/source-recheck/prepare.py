import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / '.meta_harness/tooling/src'))
from design_validation import github_anchor

TARGET = 'PF-002-assets-settings-and-permissions'
OUT = Path(__file__).resolve().parent

def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()

def section(text, anchor):
    if not anchor:
        return text
    lines = text.splitlines(keepends=True)
    headings = []
    counts = {}
    for index, line in enumerate(lines):
        match = re.match(r'^(#{1,6})\s+(.+?)\s*$', line)
        if not match:
            continue
        slug = github_anchor(match[2])
        count = counts.get(slug, 0)
        counts[slug] = count + 1
        if count:
            slug += f'-{count}'
        headings.append((index, len(match[1]), slug))
    for position, (start, level, slug) in enumerate(headings):
        if slug != anchor:
            continue
        end = next((index for index, later_level, _ in headings[position + 1:] if later_level <= level), len(lines))
        return ''.join(lines[start:end])
    raise ValueError(f'Unresolved anchor: {anchor}')

paths = sorted((ROOT / '.meta_harness/design/ubiquitous_language/terms').glob('*.md'))
paths += [ROOT / '.meta_harness/design/domain_objects/objects.md', ROOT / '.meta_harness/design/domain_objects/pending.md']
entries = []
sections = {}
for path in paths:
    source = path.read_text()
    blocks = list(re.finditer(r'^###\s+(.+?)\s*$', source, re.M))
    for index, heading in enumerate(blocks):
        end = blocks[index + 1].start() if index + 1 < len(blocks) else len(source)
        body = source[heading.start():end]
        if TARGET not in body:
            continue
        refs = []
        for match in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)', body):
            label, link = match.groups()
            if TARGET not in link:
                continue
            file, _, anchor = link.partition('#')
            target = (path.parent / file).resolve()
            relative = target.relative_to(ROOT).as_posix()
            before = subprocess.check_output(['git', 'show', f'd87f2df9:{relative}'], cwd=ROOT, text=True)
            after = target.read_text()
            old_section = section(before, anchor)
            new_section = section(after, anchor)
            key = f'{relative}#{anchor}'
            sections[key] = {'before': old_section, 'after': new_section, 'changed': old_section != new_section}
            refs.append({'label': label, 'path': relative, 'anchor': anchor, 'baseline_section_sha256': digest(old_section), 'current_section_sha256': digest(new_section), 'section_changed': old_section != new_section})
        entries.append({'id': heading[1].split(' · ')[0], 'title': heading[1], 'path': path.relative_to(ROOT).as_posix(), 'entry_text': body, 'baseline_entry_sha256': digest(body), 'references': refs})

(OUT / 'inputs.json').write_text(json.dumps({'baseline': 'd87f2df9c5cfcae82e5367c5521b360ba8d79d99', 'topic': 'PF-002', 'from_revision': 24, 'to_revision': 25, 'entries': entries, 'sections': sections}, ensure_ascii=False, indent=2) + '\n')
for index in range(0, len(entries), 8):
    (OUT / f'entries-{index // 8 + 1}.md').write_text('\n'.join(entry['entry_text'] for entry in entries[index:index + 8]))
parts = []
for key, content in sections.items():
    parts.append(f'## SOURCE {key}\n\nBaseline equals current: {not content["changed"]}\n\n{content["after"]}')
(OUT / 'referenced-sections.md').write_text('\n\n'.join(parts))
print(json.dumps({'entries': len(entries), 'sections': len(sections), 'changed_sections': [key for key, value in sections.items() if value['changed']], 'out': str(OUT)}, ensure_ascii=False))
