### UL-affiliation-request · 隶属请求 · Affiliation Request

> **中**：**一个组织的超级管理员向另一个组织发出的建立隶属邀约**：请对方成为自己的
> [上级组织](#ul-parent-organization--上级组织--parent-organization)，或请对方成为自己的下级。
> 它**要另一方的超级管理员接受才生效**：接受即给下级组织的上级组织属性填上值，
> **不产生[租户](#ul-tenant--租户--tenant)**。被接受之前它可以**被撤回**，也会**过期**——
> **隶属请求这一类有自己的默认时长，而发出时发起者可以指定这一份的**；
> **它指向的那个组织不存在了，它随即自动过期**；接收组织的当前超级管理员也可拒绝尚待处理的请求；撤回、过期、拒绝都不建立关系，需要时另发一份。**[个人组织](#ul-personal-organization--个人组织--personal-organization)不参与隶属关系**，
> 因此既发不出也收不到。
>
> **EN**: **An offer to establish affiliation between two organizations**, issued by one
> organization's super administrator to another — asking the other to become its parent, or to
> become its child. It takes effect only when **the other organization's super administrator
> accepts**: acceptance fills in the child organization's parent-organization attribute and
> **brings no tenant into being**. Before acceptance it may be **withdrawn**, and it **expires** —
> **affiliation requests carry their own default period, and the issuer may set the period for
> that one request when issuing it**; it also expires **at once if an organization it points to
> ceases to exist**. The receiving organization’s current super administrator may also decline a pending request. Withdrawal, expiry and decline establish no affiliation; a new request is required. **A personal organization takes no part in
> affiliation**, and so neither issues nor receives one.

- **形态**：对象
- **出处**：[PF-001 §4 隶属关系怎么建立与解除](../../product/PF-001-identity-scope-and-agent-constraints/design.md#隶属关系怎么建立与解除) · [§4 两种邀约都会过期](../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期) · [PF-001 flows §1.7 建立与解除组织隶属](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#17-建立与解除组织隶属)（rev 22）
- **别混**：与[邀请](#ul-invitation--邀请--invitation)是**两种对象**——[那一个是组织对账号发的，接受产生租户；这一个是组织对组织发的，接受填上一个属性](../../product/PF-001-identity-scope-and-agent-constraints/design.md#隶属关系怎么建立与解除)。**关系主体不同，结果也不同；两者共享过期与接收方可拒绝的终结规则，处理者与结果不同**
- **注意 ①**：**正文未述它靠什么标识**
- **注意 ②**：**解除隶属不走这条路**——建立要两边各做一次动作，[解除则任一方单方面即可](../../product/PF-001-identity-scope-and-agent-constraints/design.md#隶属关系怎么建立与解除)，不需要一份请求

- **拒绝的出处**：[PF-001 接收方可以明确拒绝待处理邀约](../../product/PF-001-identity-scope-and-agent-constraints/design.md#接收方可以明确拒绝待处理邀约)（rev 22）。此处拒绝是已有对象的动作/终结，不是新身份。


### UL-tenant · 租户 · Tenant

> **中**：**(组织, 账号) 这一组合所确定的身份**，是**数据归属与隔离的单位**。
> 同一组织内的两个成员是两个租户；同一账号在两个组织中也是两个租户。
> **租户身份不含[租户角色](#ul-tenant-role--租户角色--tenant-role)。**
>
> **EN**: The identity determined by the pair **(organization, account)**; the unit
> of **data ownership and isolation**. Two members of the same organization are two
> distinct tenants, as is one account across two organizations. **A tenant identity
> does not carry a role.**

- **形态**：对象
- **出处**：[PF-001 §4 租户](../../product/PF-001-identity-scope-and-agent-constraints/design.md#租户)（rev 22）
- **别混**：不是组织，也不是账号，**是两者的组合**
- **注意 ①**：跨租户访问**默认拒绝**；**使用成本按租户归属**，且**不随派发层级漂移**
- **注意 ②**：**身份由那一组合确定，不因成员关系断续而变**——退出组织之后再被邀请加入，[回来的是同一个租户](../../product/PF-001-identity-scope-and-agent-constraints/design.md#租户)；解除期间它的租户级私有部分**不可达，但不销毁**


### UL-membership-standing · 成员资格效力 · Membership Standing

> **中**：**一个[租户](#ul-tenant--租户--tenant)此刻算不算数。**恰有两个取值：
> **有效**——成员关系成立，这个租户在其组织内持有[恰好一个租户角色](#ul-tenant-role--租户角色--tenant-role)；
> **无效**——从未建立或已被解除，这个身份在那个组织里什么也看不到、什么也做不了，
> 而[它的租户级私有部分不可达、但不销毁](../../product/PF-001-identity-scope-and-agent-constraints/design.md#退出之后再加入回来的是同一个租户)。
> **成员关系的断与续改变的是它**，**不改变这个租户是哪一个**；[角色调整两样都不改](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)。
>
> **EN**: **Whether a tenant counts at this moment.** It takes exactly two values. **In force** —
> membership holds, and the tenant carries **exactly one tenant role** in that organization.
> **Not in force** — membership was never established or has been dissolved, so that identity
> can see nothing and do nothing there, while **its tenant-level private holdings stay
> unreachable but are not destroyed**. **Breaking and resuming membership changes this**, never
> **which** tenant it is; a change of role changes neither.

- **形态**：属性
- **出处**：[PF-001 §4 退出之后再加入，回来的是同一个租户](../../product/PF-001-identity-scope-and-agent-constraints/design.md#退出之后再加入回来的是同一个租户) · [§6.4 隔离](../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离) · [PF-001 flows §3.3 成员关系](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)（rev 22）
- **别混 ①**：**不是[租户角色](#ul-tenant-role--租户角色--tenant-role)。**角色答「这个身份**能做什么**」，效力答「这个身份**此刻算不算数**」。有效时两样同时成立，[角色调整不改变效力](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)
- **别混 ②**：**不是[租户](#ul-tenant--租户--tenant)本身。**租户身份是 (组织, 账号) 这一组合**确定的值，不生不灭**；**有效性才是有状态、有写路径、有并发约束的那一面**
- **别混 ③**：**[PF-001 flows §3.3 把这件事叫作「成员关系」](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)**，那一节画的「无 → 成员 → 无」正是这两个取值。
  [领域对象那边已把「成员关系」并入租户](../../domain_objects/objects.md#ul-tenant--租户)，分界是**身份是值、有效性是记录**；**本词条就是「有效性」那一面的正式名**，不是第二个对象
- **⚠️ 注意 ①**：**「目标范围不可用」不是它的第三个取值。**[§6.4 把「目标范围不可用」与「成员失权」并列](../../product/PF-001-identity-scope-and-agent-constraints/design.md#64-隔离)，
  两者**收场相同**——**明确失败，不静默回退到个人范围**；但**前者是这一次判不出来，后者是判出来的结果是无效**。
  把不可用读成无效，写出来的就是「那就降级到个人范围」这类静默回退
- **注意 ②**：**无效不抹掉已经发生的事。**[作者记录与归属照旧指着这个租户](../../product/PF-001-identity-scope-and-agent-constraints/design.md#退出之后再加入回来的是同一个租户)，
  [解除不强停正在进行的工作](../../product/PF-001-identity-scope-and-agent-constraints/design.md#66-撤销不等于强制停止)；重新加入**不是一次恢复动作**，没有东西被删过


### UL-current-tenant-identity · 当前租户身份 · Current Tenant Identity

> **中**：**一个账号此刻以哪一个[租户](#ul-tenant--租户--tenant)身份行事**——
> 挂在一次[登录状态](#ul-login-state--登录状态--login-state)上的**一项选择**。
> 登录之后它初始指向该账号[个人组织](#ul-personal-organization--个人组织--personal-organization)里的那个租户，
> **切换当前组织就是改它**。**在某个租户身份下创建出来的对象，持有的是创建那一刻的这个值**；
> 此后这项选择被改成别的，已经创建的那些一概不跟着变。
>
> **EN**: **Which tenant identity an account is acting as at this moment** — a **selection**
> carried on one login state. It initially points at the tenant in that account's personal
> organization, and **switching the current organization is what changes it**. **Anything
> created under a tenant identity holds the value captured at the moment of creation**;
> later changes to this selection leave what was already created untouched.

- **形态**：属性
- **出处**：[PF-001 §4 当前租户身份](../../product/PF-001-identity-scope-and-agent-constraints/design.md#当前租户身份) · [PF-001 flows §1.8 切换当前组织](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#18-切换当前组织)（rev 22）
- **别混 ①**：**不是[协作范围 context](scope-and-resolution.md#ul-collaboration-scope-context--协作范围-context--collaboration-scope-context)。**那一块是 agent 运行时感知到的「我在哪个组织、什么租户身份、什么角色」**整块信息**；这一条只是**其中那个租户身份从哪儿来**的那项选择
- **别混 ②**：**不是租户本身**，是一项**指向**租户的选择。租户的身份由 (组织, 账号) 确定，与此刻谁选了它无关
- **注意 ①**：它**不是[范围化对象](scope-and-resolution.md#ul-scoped-object--范围化对象--scoped-object)**——不参与任何一层的求值，也不被任何一层配值。它只决定**这一次动作以谁的身份开始**
- **注意 ②**：**它随登录状态走**：那次登录失效，它随之不存在；重新登录得到的是**重新从个人组织起算**的一项新选择


### UL-tenant-role · 租户角色 · Tenant Role

> **中**：[租户](#ul-tenant--租户--tenant)在其所属组织内的属性，决定这个身份**当前能做什么**。
> 一个租户在其组织内**只持一个**；本版只有两种：**超级管理员**与**普通成员**（Member）。
> **可变**，变更只影响**此后**的准入判定，不改变已发生的归属与既有事实。
>
> **EN**: An attribute of a tenant **within its organization**, determining what that
> identity **can currently do**. A tenant holds **exactly one**; this version defines
> two — **Super Administrator** and **Member**. It is **mutable**, and a change
> affects only **subsequent** admission decisions, never ownership already
> established or facts already recorded.

- **形态**：属性
- **出处**：[PF-001 §4 角色](../../product/PF-001-identity-scope-and-agent-constraints/design.md#角色)（rev 22）
- **别混 ①**：**不是[权限](capabilities-and-composition.md#ul-permission--权限--permission)**——角色是**身份**的属性，权限是**资产**的属性
- **别混 ②**：**与消息里的 role 字段（user / assistant / system）毫无关系**。**裸写「角色」在跨 topic 的文字里一律不作数**


### UL-super-administrator · 超级管理员 · Super Administrator

> **中**：**一个组织内**的最高治理角色，可分配与收回本组织的角色（包括把这个角色给他人）。
> **它的作用域恰是该组织**：不因此取得平台全局权限、官方件的编辑权、其他组织的管理权，
> 或成员个人范围的访问权。**任何组织在任何时刻至少有一位有效的超级管理员。**
>
> **EN**: The highest governance role **within one organization**, able to grant and
> revoke roles there, including granting this role to others. **Its scope is exactly
> that organization** — it confers no platform-wide authority, no right to edit
> official assets, no control over other organizations, and no access to a member's
> personal scope. **Every organization always has at least one.**

- **形态**：状态
- **出处**：[PF-001 §4 角色](../../product/PF-001-identity-scope-and-agent-constraints/design.md#角色) · [PF-001 flows §3.3 成员关系](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)（rev 22）
- **别混**：**不是平台管理员。**这是最容易读错的一条，读错会把组织级治理当成全局治理
- **注意**：**本版管理类动作一律只归它**——[邀请新成员、调整他人角色、管理组织的设置权限资产、建立或解除隶属，以及看本组织发出的邀约、收到的隶属请求与已解除的成员，普通成员一概不可](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)。**本版没有「可被授予的管理资格」这样东西**
- **注意**：**本组织的有效成员名单不在管理类之内**——[它对本组织的每一位有效成员可见](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)，看得见名单不等于持有这个角色；**[成员资格已失效](#ul-membership-standing--成员资格效力--membership-standing)的那些另算，[只有它看得见](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#四角色与操作)**
- **注意**：「至少一位」是一条**任何时刻都成立的事实**，不是每次动作各自检查一遍的前置条件——[两位超管同时移除或降级对方时，先成的一方成功、后成的一方被拒](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#33-成员关系)，两次动作各自合法、合起来把超管清空这种结果不允许存在


### UL-account · 账号

- **宿主**：—
- **身份**：登录标识，整个部署内唯一，注册时确定
- **生灭**：（不存在）→ 未激活（标识已占用）→ 已激活（前置：个人组织已存在；不可逆）。未激活那一条**有留存期限**（按部署配置）：期限内同标识同凭据重来认回的是它，**到期记录清除、登录标识释放，连同为它建的[个人组织](#ul-organization--组织)与[第一个租户](#ul-tenant--租户)一起消失**，回到（不存在）。**已激活之后本版无注销、终止、恢复**
- **依据**：[PF-001 §4 账号](../product/PF-001-identity-scope-and-agent-constraints/design.md#账号)（rev 22）；[PF-001 §4 未激活的账号记录不会永久占着那个名字](../product/PF-001-identity-scope-and-agent-constraints/design.md#未激活的账号记录不会永久占着那个名字)（rev 22）；[PF-001 flows §3.1](../product/PF-001-identity-scope-and-agent-constraints/flows.md#31-账号)（rev 22）


### UL-login-state · 登录状态

- **宿主**：[账号](#ul-account--账号)——它是以这个账号的身份通过鉴权的一次登录。账号本版无注销，「账号没了它怎么办」正文无从谈起
- **身份**：正文未述靠什么标识；只写明彼此分得出——重新登录是新的一个，多处登录各是一个，退出只失效被退出的那一个。**属于签发它的那个[治理中心](#ul-governance-center--治理中心)**，那是它身份的一部分（[PF-016 §4 治理中心](../product/PF-016-cli-tui-delivery-surface/design.md#治理中心)，rev 10）。**同账号的有效登录状态能被逐个列出（每一个带签发时间）并逐个指定撤销**，可分辨到这个程度
- **生灭**：（无）→ 有效（登录；前置：账号已激活、凭据正确）→ 已失效（退出、被撤销、达到最长或空闲时限，或本账号主动更换凭据成功；不可逆，重启不重算期限，恢复不能使其重新可用）。独立撤销动作仍逐个
- **依据**：[PF-001 §4 登录状态](../product/PF-001-identity-scope-and-agent-constraints/design.md#登录状态)（rev 22）；[PF-001 flows §3.2](../product/PF-001-identity-scope-and-agent-constraints/flows.md#32-登录状态)（rev 22）；[PF-001 flows §1.2](../product/PF-001-identity-scope-and-agent-constraints/flows.md#12-登录)（rev 22）

