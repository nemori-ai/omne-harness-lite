### UL-asset-holding · 资产持有 · Asset Holding

> **中**：**一个范围与一份[资产](capabilities-and-composition.md#ul-asset--资产--asset)之间的持有关系，带一个启用/[禁用](#ul-asset-disable--资产禁用--asset-disable)标记**；
> 范围指组织、租户或[工作区](scope-and-resolution.md#ul-workspace--工作区--workspace)。
> 它是**配值资格的来源**——一层要为某资产配[设置](capabilities-and-composition.md#ul-setting--设置--setting)或
> [权限](capabilities-and-composition.md#ul-permission--权限--permission)，前提是它持有该资产；
> 它同时是那一层的设置与权限作为[属性投影](scope-and-resolution.md#ul-attribute-projection--属性投影--attribute-projection)算出来时的定义域。
> **这一级为它配下的每一个值，就挂在这份持有上**（[属性配值](scope-and-resolution.md#ul-attribute-assignment--属性配值--attribute-assignment)）。
> **资格本身来自[拥有那个定义](#ul-definition-ownership--定义所有权--definition-ownership)或[获得使用权](#ul-usage-right--使用权--usage-right)**；
> 加入即产生，[移除](#ul-asset-removal--资产移除--asset-removal)即消失，**禁用不使它消失**。
>
> **EN**: The relation between a scope — an organization, a tenant or a workspace — and an
> asset it **holds**, **carrying an enabled/disabled flag**. It is **where the right to
> configure comes from**: a layer may set an asset's settings or permissions only if it holds
> that asset, and it is likewise the domain over which that layer's settings and permissions
> are projected. **Every value that level supplies hangs on this holding** (an attribute
> assignment). **The entitlement behind it comes from owning the definition or from a granted
> usage right.** It begins when the asset is added and ends when the asset is removed;
> **disabling does not end it.**

- **形态**：属性
- **出处**：[PF-002 §5.2 三方分工](../../product/PF-002-assets-settings-and-permissions/design.md#三方分工资产定形状各层配值运行时求值) · [PF-002 §6.4](../../product/PF-002-assets-settings-and-permissions/design.md#64-移除与禁用是两个动作) · [PF-002 flows §3.1 一个资产在某个范围里](../../product/PF-002-assets-settings-and-permissions/flows.md#31-一个资产在某个范围里)（rev 24） · [PF-001 §6.1 层次](../../product/PF-001-identity-scope-and-agent-constraints/design.md#61-层次)（rev 22）
- **别混**：与[定义所有权](#ul-definition-ownership--定义所有权--definition-ownership)不是一回事——**持有的不一定是自己的**，[被分享来的](#ul-asset-sharing--资产分享--asset-sharing)照样持有。**裸写「持有」不作数**：正文也用它说「持有使用权」「持有待处理消息队列」
- **注意 ①**：正文**未述它靠什么标识**；工作区那一级持有的资产算不算[自定义件](#ul-customized-asset--自定义件--customized-asset)，正文没说。
  **工作区那一级照样配得了[禁用](#ul-asset-disable--资产禁用--asset-disable)**，
  **但只对它自己提供的那批资产生效**——这一条已经裁过了
- **注意 ②**：**配值跟着持有走。**移除，这份持有没了，挂在它上面的
  [属性配值](scope-and-resolution.md#ul-attribute-assignment--属性配值--attribute-assignment)**一起消失**；
  禁用，持有还在，**配的值一个不丢**
- **注意 ③**：**一层对一个[能力标识](scope-and-resolution.md#ul-capability-identifier--能力标识--capability-identifier)至多持有一份**——同一层可以有好几份同标识的资产，替代发生在持有上；
  持有上还记着[版本选用](#ul-version-selection--版本选用--version-selection)：钉在某一版，或追随当前版
- **注意 ④**：**把资产从租户范围提升到组织范围，只换所有者，不动任何一份持有**
  （[PF-001 §6.7](../../product/PF-001-identity-scope-and-agent-constraints/design.md#67-创作与归属)）
- **注意 ⑤**：**形态是「属性」说的是它的所指，不是它的存储**——它是范围与资产之间的一层关系，
  [C-17](../conflicts.md#现有冲突) 已由产品负责人裁为属性；**它存不存成一条独立的记录、怎么标识，归系统架构设计**，不因此改变形态


### UL-usable-by · 谁可以使用它 · Usable By

> **中**：**每一类资产都有、而且是同一项的那一项[权限](capabilities-and-composition.md#ul-permission--权限--permission)：这份资产，哪些人够得着。**
> 取值是**一组[租户角色](subjects-and-ownership.md#ul-tenant-role--租户角色--tenant-role)，外加一个「自己」**；作者不另说时**只有「自己」**。
> 它与[禁用](#ul-asset-disable--资产禁用--asset-disable)一样挂在每一份[持有](#ul-asset-holding--资产持有--asset-holding)上。
> Skill 的「谁可以使用它」、Slash Command 的「谁可以用这个入口」，说的都是它。
>
> **EN**: **The one permission every asset category carries — the same one in each: who can reach this
> asset.** Its value is **a set of tenant roles plus "self"**; left unspecified by the author, it is
> **"self" alone**. Like disabling, it hangs on every holding. A skill's "who may use it" and a slash
> command's "who may use this entry point" are both this.

- **形态**：属性
- **出处**：[PF-002 §5.2「谁可以使用它」是各类资产共用的一项权限](../../product/PF-002-assets-settings-and-permissions/design.md#谁可以使用它是各类资产共用的一项权限) ·
  [§4 Slash Command](../../product/PF-002-assets-settings-and-permissions/design.md#slash-command) ·
  [§5.6 第 1 步](../../product/PF-002-assets-settings-and-permissions/design.md#56-四步资产求值--组装--投影--层级计算)（rev 24） ·
  [PF-007 §6.2](../../product/PF-007-meta-capabilities/design.md#62-skills通向任意技能)（rev 19）
- **别混**：**不是[使用权](#ul-usage-right--使用权--usage-right)**——使用权说的是**一个范围**对一份资产有没有使用的权利（定义者直接有、被分享方确认后有）；
  这一项是那份持有上配的「**这个范围里哪些人**能用」
- **注意 ①**：**「自己」在组织、租户持有的资产上指作者本人**；在工作区自带的资产上，指挂上那份工作区的租户本人
- **注意 ②**：**判下来这个人不能用的那一份，不装进他的会话**——它在替换次序上视为不存在，同标识退回下一层（资产求值第 1 步，与禁用同一段）；
  **official 那一份不受它管**。会话进行中被收回，**已经开始的运行不变，自下一次运行起不再装入**；斜杠命令是人的入口，此刻起就不存在
- **注意 ③**：**② 型斜杠命令展开的那个 skill，照样要过它自己的这一项**——入口的权限不替 skill 放权
- **注意 ④**：**权限项只有各类别列出的那些，作者不能另加**——没有哪一道关口去看的权限，只会让人以为有人守

## 来源


### UL-asset-removal · 资产移除 · Asset Removal

> **中**：让**该资产不再被这个范围[持有](#ul-asset-holding--资产持有--asset-holding)**，
> **为它配的值随之消失**。agent 装不上，**也不知道有这回事**——
> 成员问起，它只能说做不到，**说不出为什么**。
>
> **EN**: Making an asset **no longer held by this scope**, **discarding the values
> configured for it**. The agent cannot assemble it **and does not know it exists** —
> asked about it, the agent can only say it cannot, **without being able to say why**.

- **形态**：过程
- **出处**：[PF-002 §6.4](../../product/PF-002-assets-settings-and-permissions/design.md#64-移除与禁用是两个动作)（rev 24）
- **别混**：与[资产禁用](#ul-asset-disable--资产禁用--asset-disable)**在 agent 那一侧看不出差别**，差的是**配置还在不在、还能不能开回来**
- **注意**：**这个范围往后不要这份资产了 → 用这个**


### UL-asset-disable · 资产禁用 · Asset Disable

> **中**：**每份[持有](#ul-asset-holding--资产持有--asset-holding)的资产上的一项布尔设置**，
> 每个归属层各配各的；为真则这份资产在[装配](agent-runtime-loop.md#ul-agent-assembly--agent-装配--agent-assembly)时
> **对这个范围不可见**，**而持有不解除、配的值原样保留**。
> **合成语义是析取：任一层为真即为真**，本层改回假只去得掉本层那一个真，
> **下层开不回上层禁的**。**[工作区](scope-and-resolution.md#ul-workspace--工作区--workspace)那一级是个例外：
> 它配的值只对它自己提供的那批资产生效**，别的层提供的资产，它的值不参与析取。
>
> **EN**: **A boolean setting on each held asset**, configured independently at every
> ownership layer. When true, the asset is **invisible to that scope at assembly time**,
> **without releasing the holding and leaving its configured values untouched**. **The layers
> compose by disjunction: true at any layer makes it true**; setting it back to false only
> clears that layer's own true, and **a lower layer cannot re-enable what a higher one
> disabled**. **The workspace layer is the one exception: the value it sets applies only to the
> assets the workspace itself provides**, and does not enter the disjunction for assets provided
> by any other layer.

- **形态**：属性
- **出处**：[PF-002 §6.4](../../product/PF-002-assets-settings-and-permissions/design.md#64-移除与禁用是两个动作) · [§6.4 禁用是逐层配的布尔设置](../../product/PF-002-assets-settings-and-permissions/design.md#禁用是逐层配的布尔设置任一层为真即不可见)（rev 24）
- **注意**：被禁的那份持有**在替换次序上视为不存在，同标识退回下一层**——
  工作区借「同名替换再禁用」藏不掉租户的资产
- **别混**：与[当下可用性](reach-and-availability.md#ul-current-availability--当下可用性--current-availability)不是一回事——
  **禁用是不可见，不可用是可见但用了一定失败**
- **注意**：**只是这一阵不让用、将来还要开回来 → 用这个**。成员据以知道去申请的是**设置页**，不是 agent 的回答

返回[统一语言入口](../README.md) · [全部词条索引](../index.md)

### UL-tool-definition · 工具定义 · Tool Definition

> **中**：**一个[工具](capabilities-and-composition.md#ul-tool--工具--tool)在数据与治理层面的
> 身份与表示**——叫什么、干什么的说明、收什么参数（每个参数各带说明）、返回什么，以及它的可选声明（能不能后台、需要什么设施等）；
> **工具说明与每个参数的说明必填**，缺了就不是一份完整的定义。
> 其中**目标环境与转后台阈值两项声明的是[设置项](capabilities-and-composition.md#ul-setting--设置--setting)的形状与默认值**，各层配值；
> 声明之外，**前台上限与并发上限两项偏好类设置的默认值也由它给**。
> **多命令工具在模型面前只有一种样子——一份一行一命令的紧凑命令清单**：每个命令那一行说明必填；
> 作者带不带各命令的完整参数由他定，带了只供系统校验与 `inspect`/`help` 答用法，**不进模型面前**。
> **它可以自带实现，直到自带一份完整的实现 package**。
> **它是数据，长期存在**，谁持有它就归谁。
>
> **EN**: **A tool's identity and representation at the data and governance level** — its
> name, a description of what it does, the arguments it takes (each with its own description),
> what it returns, plus its optional declarations (whether it may run in the background, which
> facilities it needs, and so on); **the tool description and every argument's description are
> required** — without them the definition is incomplete. Of the declarations, **target
> environment and the background-conversion threshold declare the shape and default of a
> setting entry**, whose values the layers assign; beyond the declarations, **it also gives
> the defaults of two preference settings, the foreground limit and the concurrency limit**.
> **A multi-command tool has exactly one shape in front of the model — a compact one-line-per-command
> list**: each command's line of description is required; whether the author includes each command's
> full arguments is the author's call, and if included they serve only validation and `inspect`/`help`,
> **never reaching the model**.
> **It may carry its own implementation, up to a complete implementation package**. **It is
> data and long-lived**, belonging to whoever holds it.

- **形态**：属性
- **出处**：[PF-006 §5.2](../../product/PF-006-tools-and-skills/design.md#52-工具这个词指三样东西寿命各不相同) · [§5.3](../../product/PF-006-tools-and-skills/design.md#53-一份工具定义长什么样) ·
  [工具说明与每个参数的说明，必填](../../product/PF-006-tools-and-skills/design.md#工具说明与每个参数的说明必填) ·
  [多命令工具的定义里带多少](../../product/PF-006-tools-and-skills/design.md#多命令工具的定义里带多少是工具作者的权衡)（rev 20） · [PF-002 §4 Tool](../../product/PF-002-assets-settings-and-permissions/design.md#tool)（rev 24）
- **别混**：与[工具](capabilities-and-composition.md#ul-tool--工具--tool)不是一回事——
  工具是那一类资产，**工具定义是它在数据与治理层面的那一份表示**；
  **同一个身份下可以有平台、组织、租户各自的一份**
- **注意 ①**：**有三样刻意不在定义里**——[等待态](#ul-tool-wait-state--工具等待态--tool-wait-state)、[发帧](#ul-frame-emission--发帧--frame-emission)，
  以及[这一次的结果要不要卸载](#ul-result-offloading--结果卸载--result-offloading)。
  **三样都取决于这一次跑成什么样**，而定义里写的是这个工具跟参数无关的固有属性
- **注意 ②**：**两种写法的多命令工具在模型面前一模一样**——agent 对不熟的命令动手前仍要先经 `Tools().inspect` 或 `help` 问一次详细用法


### UL-foreground-time-limit · 前台上限 · Foreground Time Limit

> **中**：**工具的一项偏好类[设置](capabilities-and-composition.md#ul-setting--设置--setting)：一次执行在前台最多跑多久。**
> 停在[等待态](#ul-tool-wait-state--工具等待态--tool-wait-state)上的时间不算，转了后台之后也不再算。
> 到了上限，**允许后台的转后台；不允许的被中断**，[占位原因](record-and-context.md#ul-placeholder-reason--占位原因--placeholder-reason)写「前台超时」——**这不是失败**。
> 定义给默认值，持有它的各层可以改；**不设就没有这一项限制**。
>
> **EN**: **A preference setting on a tool: how long one execution may run in the foreground.**
> Time spent in a wait state does not count, nor does anything after the execution moves to the
> background. At the limit, **a tool that permits background execution moves there; one that does not
> is interrupted**, with the placeholder reason "foreground timeout" — **which is not a failure**. The
> definition supplies the default and each holding layer may change it; **left unset, there is no such
> limit**.

- **形态**：属性
- **出处**：[PF-006 §6.6 前台上限与并发上限](../../product/PF-006-tools-and-skills/design.md#前台上限与并发上限)（rev 20） ·
  [PF-002 §4 Tool](../../product/PF-002-assets-settings-and-permissions/design.md#tool)（rev 24）
- **别混**：**不是「前台跑多久自动转后台」那一项**——那是允许后台的工具[另一项偏好设置](../../product/PF-006-tools-and-skills/design.md#其中两项声明的是设置项)；前台上限对不许后台的工具同样起作用，到点被中断
- **注意**：**等人的时间不算，是有意的**——[`Ask()`](../../product/PF-007-meta-capabilities/design.md#611-ask通向人) 停在前台等人永不过期，把等人算进来，它就成了一个替人签字的到点


### UL-tool-concurrency-limit · 工具并发上限 · Tool Concurrency Limit

> **中**：**工具的一项偏好类[设置](capabilities-and-composition.md#ul-setting--设置--setting)：同一个会话里，同一个工具同时在执行的最多几次**，前台后台一起算。
> **超出的排队，按发起的先后轮到，不拒绝。**定义给默认值，持有它的各层可以改；**不设就没有这一项限制**。
>
> **EN**: **A preference setting on a tool: at most how many executions of that same tool may run at
> once within one session**, foreground and background counted together. **Executions beyond it queue
> and proceed in order of launch; none is refused.** The definition supplies the default and each
> holding layer may change it; **left unset, there is no such limit**.

- **形态**：属性
- **出处**：[PF-006 §6.6 前台上限与并发上限](../../product/PF-006-tools-and-skills/design.md#前台上限与并发上限)（rev 20） ·
  [PF-002 §4 Tool](../../product/PF-002-assets-settings-and-permissions/design.md#tool)（rev 24）
- **别混**：**裸写「并发上限」不作数**——它只数同一个会话里的同一个工具，不是会话、租户或整个系统的并发


### UL-target-environment · 目标环境 · Target Environment

> **中**：**工具的一项[落点与身份类](capabilities-and-composition.md#ul-setting-category--设置项类别--setting-category)设置：这个工具的执行需要一个什么样的[执行环境](#ul-execution-environment--执行环境--execution-environment)**，
> 形状是「绑定在哪一层 × 要哪几种[设施](#ul-environment-facility--环境设施--environment-facility)」。
> 默认值是工具作者的判断；持有它的组织、租户可以在自己那一层改，**工作区改不了**。
> **求值出来的那一份就是这次执行的要求**，运行时按它自动匹配；**满足不了，这个工具就不可用——绝不降级满足**。
>
> **EN**: **A placement-and-identity setting on a tool: what kind of execution environment its executions
> require**, shaped as "bound at which level × needing which facilities". The default is the tool author's
> judgement; holding organizations and tenants may change it at their own level, **the workspace may not**.
> **The evaluated value is this execution's requirement**, matched automatically at run time; **if it cannot
> be met, the tool is unavailable — never satisfied by a lesser environment**.

- **形态**：属性
- **出处**：[PF-006 §6.8 工具怎么提执行环境的要求](../../product/PF-006-tools-and-skills/design.md#68-工具怎么提执行环境的要求) ·
  [§5.3 其中两项声明的是设置项](../../product/PF-006-tools-and-skills/design.md#其中两项声明的是设置项)（rev 20） ·
  [PF-002 §4 Tool](../../product/PF-002-assets-settings-and-permissions/design.md#tool)（rev 24）
- **别混**：**它说的是「要什么」**；[执行环境权限](#ul-execution-environment-permission--执行环境权限--execution-environment-permission)说的是「许落在哪」；
  这次执行实际落在哪，是按两者**每次现算**出来的——执行环境权限改了，下一次执行按新值现算，不必重建任何东西
- **注意**：**不声明就是没有特殊要求**——它是工具定义里那项「需要什么样的执行环境」声明落成的设置

