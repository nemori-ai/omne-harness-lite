import hashlib
import json
from pathlib import Path
import re
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / '.meta_harness/tooling/src'))
from design_validation import github_anchor

TOPICS = {
    'PF-001-identity-scope-and-agent-constraints': (22, 23),
    'PF-002-assets-settings-and-permissions': (25, 26),
    'PF-020-workspace': (21, 22),
}

def section(text, anchor):
    if not anchor:
        return text
    lines = text.splitlines(keepends=True)
    headings = []
    counts = {}
    for index, line in enumerate(lines):
        match = re.match(r'^(#{1,6})\s+(.+?)\s*$', line)
        if not match:
            continue
        slug = github_anchor(match[2])
        count = counts.get(slug, 0)
        counts[slug] = count + 1
        if count:
            slug += f'-{count}'
        headings.append((index, len(match[1]), slug))
    for position, (start, level, slug) in enumerate(headings):
        if slug == anchor:
            end = next((index for index, later_level, _ in headings[position + 1:] if later_level <= level), len(lines))
            return ''.join(lines[start:end])
    raise ValueError(anchor)

def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()

baseline = {}
archive = ROOT / 'tmp/model-request-runtime/origin-main-update-2844/product-formal-before-external-participant-ruling.tar.gz'
with tarfile.open(archive) as bundle:
    for member in bundle.getmembers():
        if member.isfile():
            baseline[member.name] = bundle.extractfile(member).read().decode()

paths = sorted((ROOT / '.meta_harness/design/ubiquitous_language/terms').glob('*.md'))
paths += [ROOT / '.meta_harness/design/domain_objects/objects.md', ROOT / '.meta_harness/design/domain_objects/pending.md']
entries = []
sections = {}
for path in paths:
    source = path.read_text()
    blocks = list(re.finditer(r'^###\s+(.+?)\s*$', source, re.M))
    for index, heading in enumerate(blocks):
        end = blocks[index + 1].start() if index + 1 < len(blocks) else len(source)
        body = source[heading.start():end]
        refs = []
        for match in re.finditer(r'\[([^\]]+)\]\(([^)]+)\)', body):
            label, link = match.groups()
            topic = next((topic for topic in TOPICS if topic in link), None)
            if not topic:
                continue
            file, _, anchor = link.partition('#')
            target = (path.parent / file).resolve()
            relative = target.relative_to(ROOT).as_posix()
            old_section = section(baseline[relative], anchor)
            new_section = section(target.read_text(), anchor)
            key = f'{relative}#{anchor}'
            sections[key] = {'before': old_section, 'after': new_section, 'changed': old_section != new_section}
            refs.append({'topic': topic[:6], 'from_revision': TOPICS[topic][0], 'to_revision': TOPICS[topic][1], 'label': label, 'path': relative, 'anchor': anchor, 'baseline_section_sha256': digest(old_section), 'current_section_sha256': digest(new_section), 'section_changed': old_section != new_section})
        if not refs:
            continue
        entries.append({'id': heading[1].split(' · ')[0], 'title': heading[1], 'anchor': github_anchor(heading[1]), 'path': path.relative_to(ROOT).as_posix(), 'entry_text': body, 'baseline_entry_sha256': digest(body), 'references': refs})

record = {'input_archive': str(archive.relative_to(ROOT)), 'input_archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'ul_object_snapshot_sha256': hashlib.sha256((OUT / 'ownerless-ul-and-objects-before.tar.gz').read_bytes()).hexdigest(), 'topic_revisions': TOPICS, 'entries': entries, 'sections': sections}
(OUT / 'ownerless-inputs.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
pf1_entries = [entry for entry in entries if any(ref['topic'] == 'PF-001' for ref in entry['references'])]
for index in range(0, len(pf1_entries), 8):
    (OUT / f'ownerless-pf001-entries-{index // 8 + 1}.md').write_text('\n'.join(entry['entry_text'] for entry in pf1_entries[index:index + 8]))
pf1_sections = [(key, value) for key, value in sections.items() if 'PF-001-' in key]
# A parent section may be long. Split chunks by whole section where possible.
chunks = []
chunk = ''
for key, value in pf1_sections:
    fragment = f'## SOURCE {key}\n\nBaseline equals current: {not value["changed"]}\n\n{value["after"]}\n\n'
    if len(chunk) + len(fragment) > 10000 and chunk:
        chunks.append(chunk)
        chunk = ''
    chunk += fragment
if chunk:
    chunks.append(chunk)
for index, chunk in enumerate(chunks, 1):
    (OUT / f'ownerless-pf001-sections-{index}.md').write_text(chunk)
(OUT / 'ownerless-pf020-entries.md').write_text('\n'.join(entry['entry_text'] for entry in entries if any(ref['topic'] == 'PF-020' for ref in entry['references'])))
print(json.dumps({'entries': len(entries), 'pf001_entries': len(pf1_entries), 'pf001_entry_chunks': (len(pf1_entries) + 7) // 8, 'pf001_sections': len(pf1_sections), 'pf001_section_chunks': len(chunks), 'sections': len(sections), 'changed_sections': [key for key, value in sections.items() if value['changed']]}, ensure_ascii=False))
