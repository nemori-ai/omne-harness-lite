### UL-login-identifier · 登录标识 · Login Identifier

> **中**：**一个[账号](#ul-account--账号--account)用来指认自己的那个对外名字**，
> **在整个部署内唯一**，**注册时定下**。它只承担「指认」这一件事：
> **它不证明来者持有这个账号**——那是凭据的事。
>
> **EN**: **The outward name by which an account is identified**, **unique across the whole
> deployment** and **fixed at registration**. It carries one duty only — identification.
> **It proves nothing about whether the bearer holds the account**; that is the credential's
> job.

- **形态**：属性
- **出处**：[PF-001 §4 账号](../../product/PF-001-identity-scope-and-agent-constraints/design.md#账号)（rev 22）
- **别混 ①**：**不是凭据。**凭据是**证明持有**的那个东西，[不以可读形式保存](../../product/PF-001-identity-scope-and-agent-constraints/design.md#账号)；登录标识是公开的名字。登录标识不可改；凭据可以在[验证当前凭据后主动更换](../../product/PF-001-identity-scope-and-agent-constraints/design.md#主动更换凭据)，不改变账号身份
- **别混 ②**：**不是规格层用来引用一个账号的那个键。**登录标识是**人输入的名字**；一个账号在契约里被什么键引用、那个键与这个名字是不是同一个值，**产品正文没说，词表也不定义它**
- **注意 ①**：**本版不可改。**[注册时定下，此后不变](../../product/PF-001-identity-scope-and-agent-constraints/design.md#账号)；[修改登录标识列在非目标里](../../product/PF-001-identity-scope-and-agent-constraints/design.md#非目标)。凭据可主动更换，不改变这一标识
- **注意 ②**：它是[账号的身份事实](scope-and-resolution.md#ul-scoped-object--范围化对象--scoped-object)，**不是范围化对象**，不参与任何一层的求值。**登录失败的反馈里读不出它存不存在**——[「标识不存在」「凭据错误」「账号未激活」三种情形的反馈完全一样](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#二分支与异常)


### UL-login-state · 登录状态 · Login State

> **中**：**一次通过鉴权的登录**，此后的交互以这个账号的身份进行。
> 每次登录产生**新的一个**，且**可被单独撤销**——退出只让被退出的那一个失效，
> 同一账号在别处的登录不受影响。**失效不可逆**：重新登录得到的是新的一个，不是旧的复活；
> 而且**失效在系统重启之后依然成立**。最长与空闲时限也会使它失效；主动更换凭据使本账号全部旧登录失效。
> 同一账号可以同时有多个有效的，**持其中任一个就能列出全部有效的那些，每一个带签发时间**。
>
> **EN**: **One authenticated login**, under which subsequent interaction is carried out as that
> account. Each login yields **a new one**, revocable **on its own** — signing out invalidates
> only that login and leaves the account's other logins untouched. **Invalidation is
> irreversible**: logging in again yields a new one rather than reviving the old, and **it still
> holds after a restart**. Absolute and idle deadlines also invalidate it; a credential change invalidates all of the account's old logins. An account may hold several valid ones at once, and **holding any one
> of them is enough to list them all, each with its issue time**.

- **形态**：对象
- **出处**：[PF-001 §4 登录状态](../../product/PF-001-identity-scope-and-agent-constraints/design.md#登录状态) · [PF-001 flows §3.2 登录状态](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#32-登录状态) · [PF-001 flows §1.2 登录](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#12-登录)（rev 22）
- **注意**：寿命与成功业务访问口径归 [PF-001 登录状态](../../product/PF-001-identity-scope-and-agent-constraints/design.md#登录状态)；恢复不能使已失效登录或已换掉凭据重新可用，重新开放条件归 [PF-017 §6.18](../../product/PF-017-governance-center-as-deployable-application/design.md#618-备份与恢复的交付目标)。
- **别混**：**不是[会话](agent-runtime-loop.md#ul-session--会话--session)。**一个回答「这次登录还算不算数」，一个是一段协作。**正文刻意不用「会话」称呼它**，英文也不写 `login session`
- **注意 ①**：登录之后的初始协作范围是**该账号的[个人组织](#ul-personal-organization--个人组织--personal-organization)**
- **注意 ②**：**正文未述它靠什么标识**，只写明彼此可分辨——重新登录是新的一个，多处登录各是一个
- **注意 ③**：**可被同账号的其他有效登录状态列出。**[持本账号任一有效登录状态者，可以列出本账号当前全部有效的登录状态，每一个带签发时间](../../product/PF-001-identity-scope-and-agent-constraints/design.md#登录状态)；**已失效的不在列表里**。独立撤销仍逐个；[主动更换凭据](../../product/PF-001-identity-scope-and-agent-constraints/design.md#主动更换凭据)成功会使全部旧登录失效
- **注意 ④**：[当前租户身份](#ul-current-tenant-identity--当前租户身份--current-tenant-identity)这项选择**挂在它身上**：它失效，那项选择随之不存在；重新登录从个人组织重新起算
- **注意 ⑤**：**属于签发它的那个[治理中心](grounding-and-isolation.md#ul-governance-center--治理中心--governance-center)**，这是它身份的一部分；换一个中心就是另一套身份（[PF-016 §4 治理中心](../../product/PF-016-cli-tui-delivery-surface/design.md#治理中心)（rev 10））


### UL-organization · 组织 · Organization

> **中**：一个**协作范围**。它可以容纳多个账号作为成员，并拥有自己的设置、权限与资产。
> 由某个账号创建，**创建者自动成为该组织的[超级管理员](#ul-super-administrator--超级管理员--super-administrator)**。
>
> **EN**: A **collaboration scope**. It can hold multiple accounts as members and
> owns its own settings, permissions and assets. It is created by an account, and
> **its creator automatically becomes its super administrator**.

- **形态**：对象
- **出处**：[PF-001 §4 组织](../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)（rev 22）
- **别混**：组织**不是**租户，而是租户的一半——另一半是账号


### UL-personal-organization · 个人组织 · Personal Organization

> **中**：**账号注册成功时自动产生的组织**，是该账号的默认协作范围。
> 它只有创建它的那一个账号作为成员，**不能邀请他人**，
> **既无上级组织、亦不能作他人的上级**。每个账号恰有一个。
>
> **EN**: **The organization created automatically when an account is registered**,
> serving as that account's default collaboration scope. It has exactly one member —
> its creator — **cannot invite others**, and **neither has nor can be a parent
> organization**. Each account has exactly one.

- **形态**：变体（父：[组织](#ul-organization--组织--organization)）
- **出处**：[PF-001 §4 个人组织](../../product/PF-001-identity-scope-and-agent-constraints/design.md#个人组织)（rev 22）
- **注意**：「不能邀请他人」是**结构性禁止**，不是一项可被调整的权限设置
- **注意**：它**永远不与别的组织同在一棵[隶属树](#ul-ancestor-chain--上级链--ancestor-chain)上**，因此永远在所有流转边界之外
- **注意**：它**唯一的消失路径**是[随一条未激活的账号记录到期被清除](../../product/PF-001-identity-scope-and-agent-constraints/design.md#未激活的账号记录不会永久占着那个名字)——它在注册第 2 步随账号记录一并建起，那条记录到期被清时它与[第一个租户](#ul-tenant--租户--tenant)一起消失。**已激活账号的个人组织不会消失**


### UL-parent-organization · 上级组织 · Parent Organization

> **中**：组织的**一项属性**，表达「团队属于公司」「公司是另一家的子公司」。
> **至多一个**，可以为空；**隶属链不得成环**；个人组织恒为空且不可作他人的上级。
> **它不进[作用域层](scope-and-resolution.md#ul-scope-layer--作用域层--scope-layer)**——
> 子组织**不自动继承**上级组织的任何东西。
>
> **EN**: **An attribute** of an organization expressing affiliation such as "this
> team belongs to that company". **At most one**, possibly none; **affiliation
> chains must not form cycles**; a personal organization always has none and can
> never be one. **It is not a scope layer** — a child organization **inherits
> nothing automatically**.

- **形态**：属性
- **出处**：[PF-001 §4 组织](../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)（rev 22）
- **别混**：**隶属 ≠ 被管辖**。东西要流过去，走[资产复制](circulation-and-entitlement.md#ul-asset-copy--资产复制--asset-copy)或[资产分享](circulation-and-entitlement.md#ul-asset-sharing--资产分享--asset-sharing)的明确动作
- **注意**：建立需**双方超级管理员各做一次动作**——一方发出一份[隶属请求](#ul-affiliation-request--隶属请求--affiliation-request)、另一方接受；**解除则任一方单方面可做**，不需要请求
- **注意**：**创建组织时它恒为空**，[不能在创建时指定](../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)——那会是一次单方面指定，而单方面指定正是被明文排除的


### UL-ancestor-chain · 上级链 · Ancestor Chain

> **中**：从一个组织顺着[上级组织](#ul-parent-organization--上级组织--parent-organization)一路往上得到的组织序列，
> **不含它自己**。两个组织**有共同上级**，指的是**把各自算进自己的上级链之后两条链有交集**，
> 也就是**它们在同一棵隶属树上（根相同）**；那棵树**就是资产流转的那个边界**。
>
> **EN**: The sequence of organizations obtained by following an organization's
> parent links upward, **excluding the organization itself**. Two organizations
> **share an ancestor** when their ancestor chains intersect **once each is included in
> its own chain** — equivalently, when they sit in **the same affiliation tree** (same
> root); that tree **is exactly the boundary** within which assets may circulate.

- **形态**：视图
- **出处**：[PF-001 §4 组织](../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)（rev 22） · [PF-003 §5.2](../../product/PF-003-asset-transfer-and-sharing/design.md#52-边界是那棵隶属树不是单个组织)（rev 6）
- **别混**：**「有共同上级」不是「两条不含自己的链有交集」。**照那种读法，[一个组织与它自己的上级会被判成没有共同上级](../../product/PF-001-identity-scope-and-agent-constraints/design.md#组织)，而它们分明在同一棵树上——团队与它所属的公司反倒成了出树。**必须先把各自算进自己的链**
- **注意**：个人组织的上级链恒为空，把它自己算进来也只有它一个，所以**任何两个个人组织都不会有共同上级**——不是把门放宽了，**是那把尺子量不到它们**


### UL-offer · 邀约 · Offer

> **中**：**要另一方点头才生效的那类东西的统称。**发出之后先悬着，**接受才算数**；
> 悬着的那一段可以被发起方**撤回**，也会**过期**——**这四样各有自己的默认时长，
> 而发出时发起者可以指定这一份的**；**它指向的那个东西不存在了，它随即自动过期**。三种收场**完全相同**：
> **什么都没建立**，要它成立只能重新发一份。**当前恰有四样**：
> [邀请](#ul-invitation--邀请--invitation)、[隶属请求](#ul-affiliation-request--隶属请求--affiliation-request)、
> [复制通知](circulation-and-entitlement.md#ul-copy-notice--复制通知--copy-notice)、[分享邀请](circulation-and-entitlement.md#ul-sharing-invitation--分享邀请--sharing-invitation)。
>
> **EN**: The collective name for **things that take effect only once the other side says yes**.
> Once issued it hangs pending, and **acceptance is what makes it count**; while pending it may
> be **withdrawn** by the issuer, and it **expires** — **each of the four carries its own default
> period, and the issuer may set the period for that one offer when issuing it**; it also expires
> **at once if the thing it points at ceases to exist**. All three endings are
> **identical**: **nothing has been established**, and a fresh one must be issued. There are
> **exactly four** today: an invitation, an affiliation request, a pending copy notice and a
> pending sharing invitation.

- **形态**：总称
- **出处**：[PF-001 §4 两种邀约都会过期](../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)（rev 22） · [PF-003 §6.14 待确认的复制通知与分享邀请会过期](../../product/PF-003-asset-transfer-and-sharing/design.md#614-待确认的复制通知与分享邀请会过期)（rev 6）
- **⚠️ 别混**：**这四样不是同一类东西，也不共享一套身份机制。**四样**各是一个对象**——[邀请](#ul-invitation--邀请--invitation)、[隶属请求](#ul-affiliation-request--隶属请求--affiliation-request)、
  [复制通知](circulation-and-entitlement.md#ul-copy-notice--复制通知--copy-notice)、[分享邀请](circulation-and-entitlement.md#ul-sharing-invitation--分享邀请--sharing-invitation)各有词条与条目，
  关系主体与接受后建立的东西各不相同。**这个词只用来归类，不给这四样一套共同的身份、存储或状态机**
- **注意 ①**：**它自身不会有实例**——指得到的永远是那四样里的某一份
- **注意 ②**：**过期那条规则是同一条裁决的两半**——[PF-001 这一半](../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)管邀请与隶属请求，[PF-003 那一半](../../product/PF-003-asset-transfer-and-sharing/design.md#614-待确认的复制通知与分享邀请会过期)管复制通知与分享邀请，**两处口径一致**
- **注意 ③**：**「已经接受了的」不在这个词的论域里**——接受之后立起来的东西各归各的词条：[租户](#ul-tenant--租户--tenant)、[上级组织](#ul-parent-organization--上级组织--parent-organization)属性的值、落下的那份资产、[分享关系](circulation-and-entitlement.md#ul-sharing-relationship--分享关系--sharing-relationship)；它们不会过期——[确认之后的使用权没有到期](circulation-and-entitlement.md#ul-usage-right--使用权--usage-right)，租户也不会
- **注意 ④**：**本人型的[资产复制](circulation-and-entitlement.md#ul-asset-copy--资产复制--asset-copy)与[资产分享](circulation-and-entitlement.md#ul-asset-sharing--资产分享--asset-sharing)不产生邀约**——两侧都是同一个人，发起即生效，没有要等的另一方


### UL-invitation · 邀请 · Invitation

> **中**：**一个组织的[超级管理员](#ul-super-administrator--超级管理员--super-administrator)向某个账号发出的加入邀约。**
> 它**要被邀请的那个账号接受才生效**：接受即建立成员关系，租户 (该组织, 该账号) 随之产生。
> 被接受之前它可以**被撤回**，也会**过期**——**邀请这一类有自己的默认时长，
> 而发出时发起者可以指定这一份的**；**发出它的那个组织不存在了，它随即自动过期**；
> 撤回与过期都结束本份；接收账号也可明确拒绝尚待处理的邀请，同样不产生租户。
> **[个人组织](#ul-personal-organization--个人组织--personal-organization)发不出邀请**，这是结构性禁止。
>
> **EN**: **An offer to join an organization, issued by that organization's super administrator to
> one account.** It takes effect only when **that account accepts**: acceptance establishes
> membership, and the tenant (organization, account) comes into being with it. Before acceptance
> it may be **withdrawn**, and it **expires** — **invitations carry their own default period, and
> the issuer may set the period for that one invitation when issuing it**; it also expires
> **at once if the issuing organization ceases to exist**. The recipient may also decline a pending invitation; this ends it without creating membership. A new invitation is required after withdrawal, expiry or decline.
> **A personal organization can issue none** — a structural prohibition.

- **形态**：对象
- **出处**：[PF-001 flows §1.5 邀请与加入](../../product/PF-001-identity-scope-and-agent-constraints/flows.md#15-邀请与加入) · [PF-001 §4 两种邀约都会过期](../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)（rev 22）
- **别混**：与[隶属请求](#ul-affiliation-request--隶属请求--affiliation-request)是**两种对象**，不是同一样东西的两种用法——[邀请是组织对账号发的、接受产生租户，隶属请求是组织对组织发的、接受只给上级组织属性填上值](../../product/PF-001-identity-scope-and-agent-constraints/design.md#隶属关系怎么建立与解除)。**两者共享过期与接收方可拒绝的终结规则，处理者与结果不同**
- **注意**：**正文未述它靠什么标识**。有效期正文已述：[这一类有默认时长、发出时发起者可以指定这一份的，组织不存在则自动过期](../../product/PF-001-identity-scope-and-agent-constraints/design.md#两种邀约都会过期)

- **拒绝的出处**：[PF-001 接收方可以明确拒绝待处理邀约](../../product/PF-001-identity-scope-and-agent-constraints/design.md#接收方可以明确拒绝待处理邀约)（rev 22）。此处拒绝是已有对象的动作/终结，不是新身份。

