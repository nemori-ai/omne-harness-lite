### UL-inbound-target · 投递目标 · Inbound Target

> **中**：**[连接件](capabilities-and-composition.md#ul-connector--连接件--connector)的一项[落点与身份类](capabilities-and-composition.md#ul-setting-category--设置项类别--setting-category)设置：它送进来的外部消息进哪个[会话](agent-runtime-loop.md#ul-session--会话--session)。**
> **它是连接件[两种投递方式](../../product/PF-002-assets-settings-and-permissions/design.md#两种投递方式动作主体不同)里 ①「已有的会话开口接收」那一路的配置，本版只指一个已有的会话**——走这一路送进来的都落进那一个；按对面的线程分进不同会话，本版没有。
> **连接件的事件经受理开出一个新会话是另一种方式（②）**，它的配置是触发会话的默认运行模式，不是这一项；受理怎么开那个新会话归 PF-014，新会话怎么建归 PF-015。
> 各层按持有配值，**工作区那一级配不了它**。
>
> **EN**: **A placement-and-identity setting on a connector: which session the external messages it
> brings in go to.** **It configures mode ① of the connector's two delivery modes — an existing session
> opening itself to receive — and in this version names exactly one existing session**; everything delivered
> that way lands there, and splitting the far side's threads across sessions does not exist in this version.
> **A connector event opening a new session through intake is the other mode (②)**, configured by the default
> run mode for triggered sessions, not by this entry; how intake opens that session belongs to PF-014 and how
> the session is created to PF-015. Layers assign it through their holdings; **the workspace level cannot set
> it**.

- **形态**：属性
- **出处**：[PF-002 §4 Connector](../../product/PF-002-assets-settings-and-permissions/design.md#connector) · [两种投递方式](../../product/PF-002-assets-settings-and-permissions/design.md#两种投递方式动作主体不同) ·
  [§5.2 设置项分四类](../../product/PF-002-assets-settings-and-permissions/design.md#设置项分四类资产声明每一项时必须标类别)（rev 24） ·
  [PF-014 §5.7 穷举一](../../product/PF-014-inbound-intake-and-queueing/design.md#57-穷举一什么会让队列从空变成非空)（rev 8）
- **别混 ①**：**不是[交付面](#ul-delivery-surface--交付面--delivery-surface)**（Delivery Surface）——那是人碰到这个系统的那一面，这里是连接件把外面的消息送往哪里
- **别混 ②**：**不是[连接目标](capabilities-and-composition.md#ul-connection-target--连接目标--connection-target)**——那是 MCP 接入点往外连到哪，方向相反
- **注意**：送进来的消息**受理之后怎么走**，归[入站到达](#ul-inbound-arrival--入站到达--inbound-arrival)那一套，与它无关


### UL-session-asset-registry · 会话资产注册表 · Session Asset Registry

> **中**：**一个会话里，某一类资产此刻被认得的那一批所在的那一张表**——会话认得的斜杠命令、装进来的技能、plugin 这类东西各住一张；
> 用到它们的地方**都经它取**。它的内容是某一次求值的结果：会话创建时装配填入；**人发对应的 reload，只按此刻的求值结果重填那一张**；
> ③ 型斜杠命令背后的服务不在了，系统自动刷新命令那一张；一次完整的重新装配把全部重填。
> **权限收回不等 reload，但落到哪一刻看那一类资产在不在运行里**：斜杠命令是人的入口、不在运行里，收回了**此刻起就不在命令那一张**；
> 装进运行的资产（技能这类），**已经开始的运行不变，自下一次运行起不再装入**。
>
> **EN**: **The table in which a session keeps the set of one asset category it currently recognizes** —
> the slash commands it knows, the skills and plugins loaded into it, each category in a table of its own;
> **everything that uses them reads through it**. Its content is the result of an evaluation: filled at
> session assembly; **refilled, for that one table only, from the current evaluation when the person issues
> the matching reload**; refreshed automatically for commands when the service behind a type-③ slash command
> is gone; and refilled entirely by a full re-assembly. **A withdrawn permission never waits for a reload, but
> when it lands depends on whether that category lives inside a run**: a slash command is a person's entry point
> and is not in the run, so it **leaves the command table at once**; an asset loaded into runs (a skill, say)
> **stays for the run already under way and is no longer loaded from the next run on**.

- **形态**：视图
- **出处**：[PF-002 §4 会话认得哪些命令，什么时候变](../../product/PF-002-assets-settings-and-permissions/design.md#会话认得哪些命令什么时候变) ·
  [§4「谁可以使用它」是各类资产共用的一项权限](../../product/PF-002-assets-settings-and-permissions/design.md#谁可以使用它是各类资产共用的一项权限)（rev 24） ·
  [PF-016 §5.7 人要做的事分三族](../../product/PF-016-cli-tui-delivery-surface/design.md#57-人要做的事分三族)（rev 10）
- **别混 ①**：**不是[装配清单](agent-runtime-loop.md#ul-assembly-manifest--装配清单--assembly-manifest)**——reload 重填的是注册表，不是一次完整的重新装配，**不改写正在跑的运行已经捕获的构成**
- **别混 ②**：**裸写「注册表」不作数**——设计链里的 registry 是设计对象的身份清单，另有所指
- **注意 ①**：命令那一张装的就是这个会话的[会话斜杠命令集](capabilities-and-composition.md#ul-session-slash-command-set--会话斜杠命令集--session-slash-command-set)
- **注意 ②**：**资产的增删与禁用不让它自己变**——变化发生在人自己选的那一刻（reload）；热更新对进行中的运行何时可见，正文未述（[PF-004 已知的来源问题](../../product/PF-004-agent-definition-and-assembly/decisions.md#四已知的来源问题)）
- **注意 ③**：**「收回即时」只对命令那一张成立**——技能这类装进运行的，[撤销管的是下一道准入，不是强制停止](circulation-and-entitlement.md#ul-revocation-is-not-stop--撤销不等于强制停止--revocation-is-not-a-stop)，这次运行照样用得上它


### UL-scope-layer · 作用域层 · Scope Layer

> **中**：[协作范围 context](#ul-collaboration-scope-context--协作范围-context--collaboration-scope-context) 内部
> **由身份带来的归属层级**。共四层，由低到高：
>
> | 中文 | English | 归属 |
> |---|---|---|
> | **出厂默认** | **Factory Default** | 系统 |
> | **组织级** | **Organization** | 组织 |
> | **租户级** | **Tenant** | (组织, 账号) |
> | **会话级** | **Session** | 本次协作 |
>
> **它说的是「归属」，不是「有一堆自己的字段」**：一层的设置与权限，是它持有的资产
> 各自属性的[投影](#ul-attribute-projection--属性投影--attribute-projection)。
> **合成时用哪条层序，按维度分**：**权限**就是上面这四层；
> **设置**在租户级与会话级之间**还多一格[工作区](#ul-workspace--工作区--workspace)**，共五级——
> 工作区**不是一重身份**，所以不进上面这张表。
>
> **EN**: The levels of **ownership brought by identity** inside the collaboration-scope
> context, four in all, from lowest to highest: **Factory Default**, **Organization**,
> **Tenant** and **Session**. A layer denotes **ownership, not a set of fields of its own**
> — its settings and permissions are projections of the attributes of the assets it holds.
> **Which chain applies depends on the dimension**: **permissions** resolve over exactly
> these four; **settings** resolve over five, with the **workspace** sitting between tenant
> and session. A workspace is **not an identity**, so it is not in the table above.

- **形态**：属性
- **出处**：[PF-001 §6.1 层次](../../product/PF-001-identity-scope-and-agent-constraints/design.md#61-层次)（rev 22） · [PF-002 §5.8 三条层序](../../product/PF-002-assets-settings-and-permissions/design.md#58-三条层序各答一个问题)（rev 24）
- **别混 ①**：**账号不在这四层里**——它的[求值是恒等的](#ul-scope-evaluation--作用域求值--scope-evaluation)，不占一格
- **别混 ②**：[上级组织](subjects-and-ownership.md#ul-parent-organization--上级组织--parent-organization)**不进这四层**——否则层数会随隶属链变化，且把「隶属」悄悄变成「被管辖」
- **别混 ③**：**裸写「层」不作数。**系统里到处是层
- **别混 ④**：**不是[资产归属](../../product/PF-002-assets-settings-and-permissions/design.md#58-三条层序各答一个问题)那条层序**——那条答「这份资产是谁的、谁替换得了谁」，是 official < 组织 < 租户 < 工作区
- **注意**：**每一格由哪重身份充当**，归[作用域层身份](#ul-scope-layer-identity--作用域层身份--scope-layer-identity)
- **弃用**：~~「账号层」~~


### UL-scope-layer-identity · 作用域层身份 · Scope Layer Identity

> **中**：**[作用域层](#ul-scope-layer--作用域层--scope-layer)的一格由哪重身份充当。**
> 那四层是**身份带来的**四层，每一格对应一重归属：
>
> | 层 | 由谁充当 |
> |---|---|
> | **出厂默认** | **系统。没有一个身份对象充当它** |
> | **组织级** | [组织](subjects-and-ownership.md#ul-organization--组织--organization) |
> | **租户级** | [租户](subjects-and-ownership.md#ul-tenant--租户--tenant)，即 (组织, 账号) |
> | **会话级** | 本次协作，也就是那个[会话](agent-runtime-loop.md#ul-session--会话--session) |
>
> **EN**: **Which identity occupies a given scope layer.** The four layers are the ones
> **brought by identity**, each answering to one: the **factory-default** layer answers to the
> system and **is occupied by no identity object at all**; the **organization** layer to an
> organization; the **tenant** layer to a tenant, that is (organization, account); and the
> **session** layer to this collaboration, which is to say that session.

- **形态**：属性
- **出处**：[PF-001 §6.1 层次](../../product/PF-001-identity-scope-and-agent-constraints/design.md#61-层次)（rev 22） · [PF-002 §5.8 它不因此多一重身份](../../product/PF-002-assets-settings-and-permissions/design.md#它不因此多一重身份)（rev 24）
- **别混 ①**：**不是[作用域层](#ul-scope-layer--作用域层--scope-layer)本身**——层是那一格，层身份是**占着那一格的那个对象**
- **别混 ②**：**[工作区](#ul-workspace--工作区--workspace)不在其列。**它[不是一重身份](../../product/PF-002-assets-settings-and-permissions/design.md#它不因此多一重身份)，只在**设置**与**资产归属**两条层序上各占一格；它**挂在租户下**
- **别混 ③**：**[账号](subjects-and-ownership.md#ul-account--账号--account)不充当任何一格**——它的[求值是恒等的](#ul-scope-evaluation--作用域求值--scope-evaluation)，早已完成，也不接受任何配置
- **⚠️ 注意**：**出厂默认那一格没有身份对象。**读成「每一层都有一个身份主体」，就会给系统那一格**编一个出来**；它的内容是 official 资产与它们声明的默认值，[任何层不得清空](../../product/PF-001-identity-scope-and-agent-constraints/design.md#61-层次)


### UL-workspace · 工作区 · Workspace

> **中**：带有自身身份和治理归属、跨会话持续的完整资源聚合包。它有一个治理所有者租户，也可以通过[租户—工作区关系](subjects-and-ownership.md#ul-tenant-workspace-relation--租户工作区关系--tenantworkspace-relation)授权其他租户参与。
> 它可以聚合文件、代码、数据、知识和自定义资产，访问它的 agent 类型可以不同；它不绑定一个固定目标，
> 也不是会话、agent、本地目录或执行环境边界。工作区可以有多个[工作区地址](#ul-workspace-address--工作区地址--workspace-address)，
> 并在部署节点上被装载为多个[工作区实例](#ul-workspace-instance--工作区实例--workspace-instance)。
> 工作区实例中的资产进入 PF-002 定义的工作区资产层：设置和资产可以按层求值，权限、落点与身份类及治理类例外
> 不从工作区放宽。

> **EN**: An identity-bearing, governed, persistent resource aggregate that spans sessions. It has one tenant with governance ownership and may authorize other tenants to participate. It may contain files, code, data, knowledge, and custom assets; it has no fixed goal and is neither a session, agent, local directory, nor execution boundary. A workspace may have multiple addresses and multiple materialized instances. Assets from its instance enter the PF-002 workspace asset layer, while permissions and placement/identity governance cannot be widened from the workspace.

- **形态**：对象
- **出处**：[PF-020](../../product/PF-020-workspace/design.md)（rev 21） · [PF-002 工作区资产层](../../product/PF-002-assets-settings-and-permissions/design.md#工作区)（rev 24）
- **别混**：地址和实例是它的访问与装载关系，不是另一个工作区；目录只是一个可能的地址/本地承载。
- **资产层规则**：工作区提供的自定义资产仍遵循 PF-002 的设置覆盖、同标识替换、权限过滤和禁用规则。
- **内容来源**：实例下的[共享目录](#ul-workspace-shared-directory--工作区共享目录--workspace-shared-directory)与[本地目录](#ul-workspace-local-directory--工作区本地目录--workspace-local-directory)是同一工作区层的两个来源，不是两份工作区。组织的[参与限制](#ul-workspace-participation-restriction--工作区参与限制--workspace-participation-restriction)与工作区访问授权分别成立。


### UL-capability-identifier · 能力标识 · Capability Identifier

> **中**：判定两个[范围化对象](#ul-scoped-object--范围化对象--scoped-object)是否
> **「实质上同一性质」**的标识，从而决定它们**能否互相覆盖**。
> **它的构成按资产类别定：类别 ＋ name。**
> 资产声明的依赖与引用**指向能力标识，不指向某个具体资产**——
> 所以发生覆盖之后，**依赖自动指向当前生效的那一个**。
> **[模型档案](capabilities-and-composition.md#ul-model-profile--模型档案--model-profile)不是资产，但以路由名充当能力标识**：「用哪个模型」记的是路由名，同名的几条在范围链上按层取最具体的一条。
>
> **EN**: The identifier deciding whether two scoped objects are **"the same thing in
> substance"**, and therefore whether one **may override** the other. **It is made up of the
> asset's kind plus its name**, per kind. An asset's declared dependencies and references
> **point at capability identifiers, never at a specific asset** — so after an override, **a
> dependency resolves automatically to whichever asset is now in effect**. **A model profile is
> not an asset, but its routing name serves as its capability identifier**: "which model" records
> a routing name, and among same-named profiles the most specific one on the scope chain wins.

- **形态**：属性
- **出处**：[PF-001 §4 范围化对象](../../product/PF-001-identity-scope-and-agent-constraints/design.md#范围化对象) · [§6.3](../../product/PF-001-identity-scope-and-agent-constraints/design.md#63-依赖与组合)（rev 22） · [PF-002 §4 身份是「类别 ＋ name」](../../product/PF-002-assets-settings-and-permissions/design.md#身份是类别--name其余归实现)（rev 24） · [PF-013 §4 档案的身份](../../product/PF-013-model-profiles-and-invocation/design.md#档案的身份所在范围加路由名)（rev 13）
- **注意**：**同一层可以有好几份同标识的资产，但一层对一个能力标识至多持有一份**——替代发生在持有上，复制进来不自动顶掉原来持有的那份

## 怎么算


### UL-two-pass-resolution · 两轮求值 · Two-Pass Resolution

> **中**：求值分两轮，**作用对象不同**：第一轮作用在**资产**上（这个能力标识下生效的是哪个资产），
> 第二轮作用在**资产的属性项**上（这个资产的某项设置或权限取什么值）。
>
> **EN**: Evaluation runs in two passes over **different objects**: the first over
> **assets** (which asset is in effect under this capability identifier), the second
> over **an asset's attribute entries** (what value a given setting or permission
> takes).

- **形态**：规则
- **出处**：[PF-001 §6.2 两轮合成](../../product/PF-001-identity-scope-and-agent-constraints/design.md#两轮合成作用对象不同)（rev 22） · [PF-002 §5.6](../../product/PF-002-assets-settings-and-permissions/design.md#56-四步资产求值--组装--投影--层级计算)（rev 24）
- **别混**：混为一谈就会得出「**改一项设置等于换一个资产**」这种结论——而实际上租户改默认模型时，用的还是**组织共享的那一个**资产
- **注意 ①**：第一轮内部有三小步，次序写死：**先按[禁用](circulation-and-entitlement.md#ul-asset-disable--资产禁用--asset-disable)滤，
  再按[「谁可以使用它」](circulation-and-entitlement.md#ul-usable-by--谁可以使用它--usable-by)滤（official 那一份不参与），最后同标识取最具体的一份**；
  被前两步滤掉的持有在替换次序上视为不存在，标识退回下一层
- **注意 ②**：**唯一会改组合的那项设置——[Plugin](capabilities-and-composition.md#ul-plugin--插件--plugin) 的「启用哪些成员」——在组装展开到它时就地求值**，其余属性项照常在第二轮


### UL-immutable-marker · 不可覆盖标记 · Immutable Marker

> **中**：一层给出某个值时可以附加的标记，表示这个值**不可再被上层覆盖**。
> 不加即「**默认**这样」，加了即「**必须**这样」。**一个标记同时管三处**：
> 设置的字段值、权限的取值、资产的替换。
>
> **EN**: A marker a layer may attach to a value it supplies, meaning the value
> **cannot be overridden by any higher layer**. Without it the layer says
> "**by default** this"; with it, "**it must be** this". **One marker covers three
> cases**: a setting's field value, a permission's value, and an asset substitution.

- **形态**：属性
- **出处**：[PF-001 §6.2 默认与强制](../../product/PF-001-identity-scope-and-agent-constraints/design.md#默认与强制immutable)（rev 22） · [PF-002 §5.4](../../product/PF-002-assets-settings-and-permissions/design.md#54-默认与强制一个机制三处适用)（rev 24）
- **注意 ①**：对权限而言，`immutable(v)` 就是把允许集合**收窄到单元素** `{v}`——**强制是收窄的特例**；权限上**带它的配值是界、不带的只是挑选**，唯独配成「禁止」的不带也是界
- **注意 ③**：锁资产替换时**不问被锁的是 official 还是自定义**——组织或租户在自己那层把某份 official 的持有标上它，
  下面就换不掉；[工作区](#ul-workspace--工作区--workspace)那一级**配不了它**
- **注意 ②**：[禁用](circulation-and-entitlement.md#ul-asset-disable--资产禁用--asset-disable)的析取语义
  **等价于「布尔设置 ＋ 真即 immutable」**——**不是第四处，也不是另一套机制**
- **注意 ③**：**[工作区](#ul-workspace--工作区--workspace)那一级同样压不动锁住的项**——
  它在设置这一维虽然[压过租户](../../product/PF-002-assets-settings-and-permissions/design.md#58-三条层序各答一个问题)，
  覆盖也只发生在**没被锁死**的项上

