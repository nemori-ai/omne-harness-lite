"""Apply audited source revisions after the two explicit external-repository rulings."""
import ast
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / '.meta_harness/tooling/src'))
from design_validation import github_anchor

data = json.loads((OUT / 'ownerless-inputs.json').read_text())
prior = json.loads((OUT / 'review.json').read_text())
prior_inputs = json.loads((OUT / 'inputs.json').read_text())
# Recover the previously written individual judgments without executing the old
# mutating script or replacing its evidence.
prior_dicts = {}
for node in ast.parse((OUT / 'apply_reviewed.py').read_text()).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id in ('judgments', 'object_judgments'):
        prior_dicts[node.targets[0].id] = ast.literal_eval(node.value)

pf1 = {
 'UL-asset': '八类资产仍为独立组装对象；设置与权限为其属性，工作区 ownerless 例外不扩展资产类别。',
 'UL-setting': '设置为资产属性，定形状、层配值、覆盖求值不变；参与者不获得其他租户配值。',
 'UL-permission': '行动权限的界/挑与不可放宽语义不变；外仓登记不授权底层写入。',
 'UL-mcp': 'MCP 接入点是资产，外部提供动作不各立顶层资产；提供者可用性及版本边界不变。',
 'UL-connector': '唯一向内的消息接入资产及组装定义扩展不变；无数据读取面或管理面。',
 'UL-plugin': '分发组合单元的成员/依赖治理不变，不与 Cordis plugin 混同。',
 'UL-agent-definition': '静态组装定义与 runtime/会话分离，多份定义可并存；引用不转移所有权。',
 'UL-definition-ownership': '此处是资产定义所有权，不是工作区治理 owner；拥有、获权、选用互不蕴含，定义不改。',
 'UL-usage-right': '使用权不转移资产定义所有权，也不证明安装、激活或动作授权。',
 'UL-version-selection': '消费者实际版本选择与定义所有权/使用权独立；本轮不补造未版本化附注。',
 'UL-revocation-is-not-stop': '成员失权、登录到期等作用下一道尚未通过的准入；已开始调用仍归独立运行控制。',
 'UL-asset-holding': '持有与定义所有权分开，移除配值消失、禁用仍保留；外仓参与例外不重写持有定义。',
 'UL-asset-origin': 'official/customized 来源仍为层次体现，自报来源不可信且不能转换行动权限。',
 'UL-official-asset': 'official 是出厂最小必需，无需使用授权、不能禁用；同能力替代不清空下界。',
 'UL-customized-asset': '组织或租户来源的定制资产按拥有/获权治理，替代 official 不授予行动权限。',
 'UL-call-account': '隔离仍要求成本逐条归发起租户；未知费用与后补规则归 PF013，不新增预算或额度。',
 'UL-session-base': '会话准入需要当前范围有效，撤销与强停分开；PF001 附注未版本化，保持原样。',
 'UL-scope-layer': '四层是身份形成的权限层，设置有工作区额外来源；工作区参与关系不新增作用域身份。',
 'UL-scope-layer-identity': '组织/租户/会话提供层身份，工作区挂租户指消费者求值而非唯一所有权，层定义不改。',
 'UL-scoped-object': '归某身份层并参与求值的对象抽象不变，不把所有工作区资源视为租户所有。',
 'UL-capability-identifier': '能力身份仍用于跨层等性质判定，不代替具体资产或工作区逻辑身份。',
 'UL-scope-evaluation': '沿层求生效资产/值的过程不变，资源参与权限与资产求值不合并。',
 'UL-scope-composition-semantics': '设置覆盖、权限收窄、资产组合及同标识覆盖不变；禁用的析取另行表达。',
 'UL-two-pass-resolution': '第一轮择资产、第二轮求其属性不变；设置变动不构成换资产。',
 'UL-immutable-marker': '一个强制标记覆盖设置、权限取值及资产替换；权限 immutable 为单元素界。',
 'UL-attribute-projection': '一层设置权限仍是持有属性的视图，最小读写单位仍为身份层/资产/项的值。',
 'UL-permission-bound': '各层锁下允许集合交集，禁止锁不锁均为界；没有组织界时租户挑自动不是放宽。',
 'UL-permission-pick': '界内挑选按具体程度确定，不把未锁默认当上层界，不改变 PF002 的合法取值规则。',
 'UL-runtime-context': '个人与协作范围两轴正交，PF015 的数据块定义不因 PF001 工作区窄例外改变。',
 'UL-collaboration-scope-context': '组织/租户承载的身份与治理情形仍独立于个人偏好轴。',
 'UL-personal-context': '账号承载的个人偏好不参与四层合成，切组织不改变个人偏好。',
 'UL-account': '自然人全局身份、标识鉴权聚合三作用、个人 context 及不跨账号关联均不变。',
 'UL-login-identifier': '部署内唯一且本版不可改，指认不证明持有；未激活记录清除后释放名字。',
 'UL-login-state': '独立计时的有限寿命登录及退出/撤销/到期/主动更换失效规则不变，无重启续期。',
 'UL-organization': '协作范围及独立资产治理、邀请与隶属规则不变；外仓无 owner 不产生新组织。',
 'UL-personal-organization': '每账号唯一个人组织、不可邀请及不参与隶属规则不变。',
 'UL-parent-organization': '至多一上级、无环、个人组织不参与、建立两方同意与任一方解除不变。',
 'UL-ancestor-chain': '上级链本身不含自己，判共同上级时计入双方自身；不产生资产自动继承。',
 'UL-offer': '邀请与隶属请求是两种对象，共享时限/撤回/拒绝规则不并为一个对象。',
 'UL-invitation': '组织发账号、接受产生租户、独立过期时长及明确拒绝终结分支不变。',
 'UL-affiliation-request': '组织发组织、接受只改变上级属性、不产生租户；发起方消失后处理仍未述。',
 'UL-tenant': '组织/账号二元身份不含角色，退出再加入回来同一个；PF001 所有权条件只限受租户所有权约束对象。',
 'UL-membership-standing': '成员资格只有效/无效，目标不可用是无法判定的失败，不新增第三值。',
 'UL-current-tenant-identity': '登录上的当前选择在动作创建时捕获；切组织不漂移已建会话归属。',
 'UL-tenant-role': '组织内可变属性，两类角色且每租户一角色；变更影响后续准入不改身份。',
 'UL-super-administrator': '组织的最高治理角色只在该组织生效，末位保护不提供平台或成员私域权限。',
}
pf1_objects = {
 'UL-account': '宿主无、身份格式未述；注册未激活/激活与到期连带个人空间清除不变，已激活无终止路径。',
 'UL-login-state': '宿主仍为账号，独立登录/失效且不复活；主动更换及旧备份恢复不得使失效登录重新有效。',
 'UL-organization': '无宿主、精确身份未述；创建一次提交带首位超管/租户，团队无终结、个人仅未激活到期连带清除。',
 'UL-invitation': '宿主仍为发出组织、身份未述；接受产生租户，撤回/拒绝/过期不产生，组织消失分支本版无触发源。',
 'UL-affiliation-request': '宿主仍无法判发起/接收方、身份未述；接受改变上级属性，拒绝/撤回/过期不建立隶属，既有未裁保留。',
 'UL-tenant': '组织/账号稳定身份、角色不入身份；退出私有部分不可达不删，再加入复用；未激活连带清除范围不变。',
 'UL-asset': '资产作者租户与定义所有者分别记录，租户提升组织只改所有者不改持有；具体资产身份及删除后处理仍未述。',
 '使用成本明细': '逐条成本归租户的出处不变；此待裁项没有在本轮获得明细对象定义，不以外仓参与裁决闭合。',
}
pf20 = {
 'UL-workspace': '窄例外明确 Host 有治理 owner、登记外仓无 Omne owner 全为参与者；资源聚合/身份/地址/实例与 PF002 资产层其余边界不变。',
 'UL-workspace-instance': '跨租户共用的部署节点装载及本地目录显式接入不变；独立会话寿命、中心销毁不清本地、精确身份/状态仍未定。',
 'UL-workspace-address': '地址与身份/凭据分离，多地址及提供者类型不变；地址不确定治理归属。',
 'UL-workspace-category': '资源治理类别与地址提供者分轴，原生/外部/未来组合分类不变，未推定其他外部类型 owner 策略。',
 'UL-workspace-management-type': '资源持久保存/版本/同步模型，Host 创建时选择、首版 Git 不变；创建后转换仍未定义。',
 'UL-git-workspace': 'Workspace 的 Git 特化、Host 首版 Git、沿用逻辑身份不变；Git branch/commit 不成为身份。',
 'UL-workspace-address-provider': '地址访问的宿主/外部系统类型不变，不是工作区所有者或授权。',
 'UL-workspace-shared-directory': '实例 .omne 为共享资产来源，与 local 同结构；原共享同步范围不变且同步完成/失败仍待细化。',
 'UL-workspace-local-directory': '实例本地来源而非租户私有，local 可只配共享设置/完整实现替换不混配等规则不变，不进入共享同步。',
 'UL-workspace-participation-restriction': '默认关闭/两范围/无豁免仍成立；用户新裁定启用时外仓不给 workspace 身份及来源，只读改走普通目录原权限，不删身份关系实例、不热重判。',
 'UL-tenant-workspace-relation': 'owner 仅限 Host，外仓首次及后来接入均 participant；解除删除、中心 Host 销毁删除关联关系仍成立；组织限制不删除关系。',
 'UL-workspace-super-administrator': '创建者授予/撤回的超管与唯一 owner 保护仅限 Host；外仓首登不获超管授权或移除/销毁特权。',
}
pf20_objects = {
 'UL-tenant-workspace-relation': '关联租户/工作区及精确身份未述不变；owner/创建者超管治理删除保护仅 Host，外仓 participant 可自己退出无首登特权；限制仅影响装配不删关系。',
 'UL-workspace': '纠正治理归属被当作寿命宿主：寿命宿主正文未述，Host owner 和外仓参与者均不据此成为寿命宿主；Host 销毁沿旧规则，外仓终结规则不猜；组织限制不销毁身份。',
 'UL-workspace-instance': '部署节点装载/本地首次接入、多租户共用、会话结束不卸载不变；精确身份及状态规则未述保留，不将外仓参与关系推为实例宿主。',
}

def block(source, title):
    headings = list(re.finditer(r'^###\s+(.+?)\s*$', source, re.M))
    for i, match in enumerate(headings):
        if match[1] == title:
            end = headings[i+1].start() if i+1 < len(headings) else len(source)
            return match.start(), end, source[match.start():end]
    raise ValueError(title)

def sha(value):
    return hashlib.sha256(value.encode()).hexdigest()

def normalize_revisions(value):
    return re.sub(r'（(?:(PF-\d+) )?rev \d+）', '（revision）', value)

results = []
changed_paths = set()
revision_total = 0
for entry in data['entries']:
    kind = 'pending' if entry['path'].endswith('/pending.md') else 'domain_object' if '/domain_objects/' in entry['path'] else 'term'
    topics = sorted({ref['topic'] for ref in entry['references']})
    reasons = []
    for topic in topics:
        if topic == 'PF-001':
            reasons.append((pf1 if kind == 'term' else pf1_objects)[entry['id']])
        elif topic == 'PF-020':
            reasons.append((pf20 if kind == 'term' else pf20_objects)[entry['id']])
        else:
            if entry['id'] == 'UL-workspace':
                reasons.append('PF002 工作区完整章节已重读：Host owner/外仓全参与者与启用限制时装配排除同步 PF020；求值仍按会话租户进行，过滤、两来源及 reload 不变。')
            else:
                reasons.append(prior_dicts['judgments' if kind == 'term' else 'object_judgments'][entry['id']])
                for ref in entry['references']:
                    if ref['topic'] == 'PF-002':
                        key = f"{ref['path']}#{ref['anchor']}"
                        assert prior_inputs['sections'][key]['after'] == data['sections'][key]['after'], key
    path = ROOT / entry['path']
    source = path.read_text()
    start, end, before_revs = block(source, entry['title'])
    edits = []
    for match in re.finditer(r'（(?:(PF-\d+) )?rev (\d+)）', before_revs):
        if match[1]:
            topic = match[1]
        else:
            links = list(re.finditer(r'\[[^\]]+\]\(([^)]+)\)', before_revs[:match.start()]))
            topic = next((key[:6] for key in data['topic_revisions'] if links and key in links[-1][1]), None)
        expected = next((values for key, values in data['topic_revisions'].items() if key[:6] == topic), None)
        if expected is None or int(match[2]) != expected[0]:
            continue
        assert topic in topics, (entry['id'], topic)
        updated = match[0][:match.start(2)-match.start()] + str(expected[1]) + match[0][match.end(2)-match.start():]
        edits.append((match.start(), match.end(), updated, topic))
    after = before_revs
    for edit_start, edit_end, updated, _ in reversed(edits):
        after = after[:edit_start] + updated + after[edit_end:]
    if edits:
        path.write_text(source[:start] + after + source[end:])
        changed_paths.add(entry['path'])
        revision_total += len(edits)
    original = entry['entry_text']
    semantic_change = normalize_revisions(original) != normalize_revisions(before_revs)
    expected_changes = {'UL-workspace','UL-tenant-workspace-relation','UL-workspace-super-administrator','UL-workspace-participation-restriction'}
    assert not semantic_change or entry['id'] in expected_changes, entry['id']
    if semantic_change:
        changed_paths.add(entry['path'])
    unknowns = [line for line in original.splitlines() if re.search(r'未裁|未定|未述|待确认|尚未|待定义|待裁', line)]
    results.append({
        'id': entry['id'], 'kind': kind, 'path': entry['path'], 'entry_anchor': entry['anchor'],
        'references': entry['references'], 'baseline_entry_sha256': entry['baseline_entry_sha256'],
        'current_entry_sha256': sha(after), 'judgment': ' '.join(reasons),
        'definition_or_object_skeleton_changed': semantic_change,
        'scope': '仅 Host 治理归属/角色与外仓无 owner、组织限制装配边界；不推定技术采用。' if semantic_change else '引用章节及本条范围未变，仅接续真实版本化出处。',
        'revision_fields_updated': len(edits), 'revision_updates_by_topic': {topic: sum(edit[3] == topic for edit in edits) for topic in topics},
        'known_unknowns_from_input': unknowns,
        'known_unknowns_after_review': [line for line in after.splitlines() if re.search(r'未裁|未定|未述|待确认|尚未|待定义|待裁', line)],
        'unresolved': '外仓治理 owner 与组织限制适用已由用户明确闭合；寿命宿主、外仓终结、精确身份等未述不补默认。' if semantic_change else '原有未裁/未述保持；没有根据本轮规则追加默认或接受技术投影。',
        'prior_pf002_audit': {'path': str((OUT / 'review.json').relative_to(ROOT)), 'sha256': hashlib.sha256((OUT / 'review.json').read_bytes()).hexdigest(), 'reuse': '同章节同哈希已逐条读过，当前再比对；工作区变化章节另行全文重读。'} if 'PF-002' in topics else None,
    })

record = {
 'format': 1, 'topic_revisions': data['topic_revisions'],
 'scope': 'PF001/23、PF002/26、PF020/22 两条用户明确新裁决的逐条出处复核及最小 UL/对象 scope 校正；不改变冻结规格、技术投影或实现采用。',
 'product_baseline_archive': data['input_archive'], 'product_baseline_archive_sha256': data['input_archive_sha256'],
 'ul_object_snapshot': str((OUT / 'ownerless-ul-and-objects-before.tar.gz').relative_to(ROOT)),
 'ul_object_snapshot_sha256': data['ul_object_snapshot_sha256'],
 'preserved_prior_review_sha256': hashlib.sha256((OUT / 'review.json').read_bytes()).hexdigest(),
 'source_read_method': '逐条读取现行 term/object/pending 与实际引用章节；PF00140章节均全文重读；PF020完整正文与变化diff全文重读；PF002除工作区变化全文重读，其余与先前逐条阅读的同文本/同哈希审计对照。',
 'sections_compared': len(data['sections']), 'referenced_sections_changed': sum(section['changed'] for section in data['sections'].values()),
 'entries_read': len(results), 'entries_updated': sum(bool(e['revision_fields_updated'] or e['definition_or_object_skeleton_changed']) for e in results),
 'scope_entries_changed': sum(e['definition_or_object_skeleton_changed'] for e in results),
 'revision_fields_updated': revision_total, 'entries': results,
 'known_remaining_unknowns': ['工作区的寿命宿主，外部工作区的终结规则；不能从治理 owner/参与者推出。', '工作区及实例精确标识和状态转换、并发协议。', '租户—工作区关系精确标识与唯一性及租户端终止处理。', '隶属请求发起方消失时处理与寿命宿主。', '既有使用成本明细对象定义待裁。'],
 'closed_explicit_rulings': ['外部仓库登记无 Omne 治理 owner，全为 participant；Host 治理 owner/超管规则不变。', '启用组织参与限制时外仓不作为受限租户 workspace 认定、附着或加载来源；普通 Files/Shell及底层权限不改、不销毁全局身份关系实例、不热重判原会话。'],
 'changed_paths': sorted(changed_paths),
}
(OUT / 'ownerless-ruling-recheck.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key:record[key] for key in ('entries_read','entries_updated','sections_compared','referenced_sections_changed','scope_entries_changed','revision_fields_updated','changed_paths')}, ensure_ascii=False))
