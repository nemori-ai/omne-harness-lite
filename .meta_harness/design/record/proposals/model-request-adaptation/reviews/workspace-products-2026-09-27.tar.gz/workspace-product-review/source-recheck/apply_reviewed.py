"""Apply only the individually read and judged PF-002 source references."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
data = json.loads((OUT / 'inputs.json').read_text())

# These judgments were written after reading each entry and all its PF-002
# sections, including overlapping source sections; they are not inferred from
# the mechanical equality result.
judgments = {
    'UL-intervention-power': '三档干预力仍是拓展件权限；共享实例不改变收窄、无放宽档及之前/之后的适用范围。',
    'UL-extension-unavailability-policy': '不可用处置仍为作者声明，不是设置或权限；工作区观察档不能因声明否决增加权力。',
    'UL-extension-point-pass': '同位置多件顺序仍由装配清单给出；PF-002 附注出处已核对，PF-012 的一次经过定义未变。',
    'UL-agent-assembly': '求值先于组装，定义版本与当时作用域结果产生清单；共享/local 候选选择仍落在求值内部。',
    'UL-setting': '资产定形状、持有层配值、覆盖求值仍成立；工作区偏好覆盖不获得权限或凭据，替换后设置仍随资产。',
    'UL-setting-category': '四类设置及工作区过滤例外未变；共享/local 不新增层，不绕过落点身份和治理类过滤。',
    'UL-permission': '权限界取交集、未锁挑选、禁止即界及同标识替换后界保留未变；工作区共享不授予放宽权限。',
    'UL-skill': '指引及资源是可复用方法，读取不等于执行脚本；工作区来源改变不改变其资产变体身份。',
    'UL-tool': '调用动作以类别/name 识别，多命令占一槽且子命令不独立持有；同源共享不改变顶层资产分类。',
    'UL-mcp': '接入点资产与外部动作区分、尝试开始时动作清单重算不变；工作区文件 reload 不替代 MCP 可用性刷新。',
    'UL-connection-target': '连接目标是 MCP 的落点身份设置而非身份；工作区不能给其他实现配该值，规则未变。',
    'UL-connector': '外部消息接入件的两种投递、租户鉴权和接收会话捕获身份未变；D-6 的投递选择待裁保留。',
    'UL-connector-event-type': '类型名/说明/消息形状仍为定义声明，非连接件身份；目录外拒绝和厚信封规则未变。',
    'UL-event-subscription': '目录子集是持有侧偏好，只在组织/租户求值，工作区/会话无值，agent 不自行订阅。',
    'UL-loop-extension': '拓展件仍为资产变体和 opt-in 服务，多件按装配清单顺序；工作区 hook 观察权限及不可用声明规则未变。',
    'UL-slash-command': '人的入口三类绑定与保留前缀规则未变，绑定不成为设置；共享工作区不扩展命令执行资格。',
    'UL-command-parameter-declaration': '命令参数说明属于命令正文而非设置，声明解析失败不发送；三种绑定仍用一条规则。',
    'UL-plugin': '资产打包单元的成员仍随包治理，无独立顶层生命周期，Cordis plugin 的技术装载单元仍另指。',
    'UL-agent-definition': '定义与运行实例分离，只有定义组合全部八类；工作区共享不就地改写已捕获的运行构成。',
    'UL-asset-version': '发布内容不可变，消费方版本选用与资产版本分离；PF-002 flows 的钉版/追随规则未变，PF-003 独立版本线依据保留。',
    'UL-asset-composition': '引用能力标识、拒绝展开不完的环、不转移所有权仍成立；现行 §5.1 的 PM 推导待确认标记继续保留。',
    'UL-session-slash-command-set': '命令集是会话可用入口视图，增删/禁用等 reload，收回即时、放宽等 reload；工作区文件变化不自动刷新。',
    'UL-mcp-credential': '租户持有上的一份凭据，静态/OAuth 同一设置，组织不持有、工作区不能取；共享实例不复制其他租户秘密。',
    'UL-version-selection': 'PF-002 flows 附注仍支持钉版/追随关系；该条无 PF-002 rev24 出处，不为其补造版本化出处。',
    'UL-asset-holding': '范围与资产持有关系仍是属性，移除失去配值、禁用保留，一层同能力至多一份；存储身份和工作区自定义件待述仍保留。',
    'UL-usable-by': '共用权限、自己含义、禁用/使用资格先过滤再替换不变；运行内撤销与人命令即时撤销分别保留。',
    'UL-asset-removal': '收回持有及删除配值的过程未变，agent 侧不可见；共享来源不重定义移除为实例销毁。',
    'UL-asset-disable': '持有上布尔设置、层间析取、工作区只禁自己来源仍成立；实例内 local 显式 false 合并与层间禁用析取各自独立。',
    'UL-tool-definition': '工具数据定义与动作/执行区分，参数说明与多命令呈现规则未变；来源共享不改其形态或治理定义。',
    'UL-foreground-time-limit': '工具偏好设置的前台计时、等待排除、转后台或中断未变；工作区仍只能提供允许的偏好。',
    'UL-tool-concurrency-limit': '同会话同工具前后台合计的排队上限未变；共用实例不把不同租户会话合并为一个计数域。',
    'UL-target-environment': '工具落点身份要求由组织/租户配值，工作区不能改别的实现落点；不满足不可用且不降级，规则未变。',
    'UL-inbound-target': '连接件 ① 路的一个已有会话目标仍为落点身份设置，② 路配置另属触发模式；工作区无投递目标值。',
    'UL-session-asset-registry': '会话每类求值视图、创建/reload/③失败刷新时刻不变；不重写正在运行捕获构成，既有热更新时刻未述保留。',
    'UL-scope-layer': '权限四身份层、设置另有工作区一级、资产归属另序未变；工作区有逻辑身份不成为第五个作用域身份。',
    'UL-scope-layer-identity': '四个作用域层的身份充当者未变；工作区挂在租户下按现行 PF-002 指会话求值而非独占实例。',
    'UL-workspace': '逻辑身份、治理所有者与授权参与关系仍由 PF-020 rev21 定义；PF-002 仅承接资产层，共享实例不暴露租户层私有内容，不代裁首次登记所有者。',
    'UL-capability-identifier': '类别/name 标识替换身份而非具体资产，各层至多持有一份未变；工作区两个来源最终仍择一个有效候选。',
    'UL-two-pass-resolution': '第一轮资产、第二轮属性求值不变；候选过滤和 local 优先属于第一轮，Plugin 成员就地求值例外未改。',
    'UL-immutable-marker': '默认/强制同机制管设置、权限、替换未变；工作区压不动上层锁，也不能自行配 immutable。',
    'UL-attribute-assignment': '持有上的项值、可锁、持有移除即消失、禁用保留未变；工作区来源的配值不因共享升格为另一租户配值。',
    'UL-attribute-projection': '一层设置/权限仍是持有属性投影而非另存的对象，最小读写单位是属性配值。',
    'UL-permission-bound': '锁下允许集合取交集、禁止即界、界随能力身份替换仍成立；共享/local 新来源不绕过界。',
    'UL-permission-pick': '未锁值在界内从具体层选，界外不生效、无有效选取最近且平手取严规则未变。',
}
object_judgments = {
    'UL-workspace': 'PF-002 工作区资产层依据未变，逻辑身份/地址/实例区分和跨会话保留仍成立。宿主、生灭的 PF-020 rev21 依据未升级；没有从此次 PF-002 复核推导外仓首次登记所有者或新销毁条件。',
    'UL-asset': 'PF-002 的八类资产、类别/name 能力身份及发布不可变规则未变；具体资产身份和删除后规则仍为正文未述，其他 PF-001 生灭依据未改。',
    'UL-asset-version': 'PF-002 发布不可变流程未变，宿主仍为资产，PF-003 独立版本线与复制接收侧依据未改，版本终结未述继续保留。',
}

results = []
changed_paths = set()
revision_edits = 0
for entry in data['entries']:
    is_object = '/domain_objects/' in entry['path']
    reason = (object_judgments if is_object else judgments)[entry['id']]
    before = entry['entry_text']
    replacements = []
    for match in re.finditer(r'（(?:(PF-002) )?rev 24）', before):
        preceding = before[:match.start()]
        links = list(re.finditer(r'\[[^\]]+\]\(([^)]+)\)', preceding))
        if not match[1]:
            assert links and 'PF-002-assets-settings-and-permissions' in links[-1][1], (entry['id'], match[0])
        replacements.append((match.start(), match.end(), match[0].replace('24', '25')))
    after = before
    for start, end, value in reversed(replacements):
        after = after[:start] + value + after[end:]
    path = ROOT / entry['path']
    source = path.read_text()
    assert source.count(before) == 1, entry['id']
    if replacements:
        path.write_text(source.replace(before, after, 1))
        changed_paths.add(entry['path'])
        revision_edits += len(replacements)
    results.append({
        'id': entry['id'],
        'kind': 'domain_object' if is_object else 'term',
        'path': entry['path'],
        'entry_anchor': re.sub(r'[^a-z0-9\u4e00-\u9fff -]', '', entry['title'].lower()).replace(' ', '-'),
        'references': entry['references'],
        'baseline_entry_sha256': entry['baseline_entry_sha256'],
        'current_entry_sha256': hashlib.sha256(after.encode()).hexdigest(),
        'judgment': reason,
        'definition_or_object_skeleton_changed': False,
        'revision_fields_updated': len(replacements),
        'unresolved_policy_preserved': True,
    })

record = {
    'format': 1,
    'baseline_commit': data['baseline'],
    'topic': data['topic'],
    'from_revision': 24,
    'to_revision': 25,
    'scope': '逐条复核 PF-002 出处；不接受技术投影、不更新冻结规格，不替 PF-020 首次登记所有者补默认。',
    'sections_compared': len(data['sections']),
    'referenced_sections_changed': sum(section['changed'] for section in data['sections'].values()),
    'entries': results,
    'pending_entries_referencing_pf002': 0,
    'changed_paths': sorted(changed_paths),
    'revision_fields_updated': revision_edits,
}
(OUT / 'review.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'entries_read': len(results), 'entries_updated': sum(bool(entry['revision_fields_updated']) for entry in results), 'revision_fields_updated': revision_edits, 'changed_paths': sorted(changed_paths)}, ensure_ascii=False))
