# RT4：既有 runtime 提供者的精确消费增补

用户目标保持完整 model request runtime 纵线。此任务只把已接受RT4变化投影到既有 runtime 节点，供独立评审与采用后施工；不是另立模型抽象、运行时、进程平台、资产或Agent Loop。用户要求spec／realization先于实现。本作者不接受自己成果。

## 执行位置、写权与输入

首先 cd `/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-b1-runtime-projection`，核branch `panqiwei/model-request-runtime-b1-runtime-projection`／HEAD `eb2ae377483074012f7269c79a81bc2d250b7f41`。你不独自在仓库，不撤销他人修改。全部写入用本spoke绝对路径。

唯一受维护可写文件 `.meta_harness/design/realization/packages/model/model-request-runtime/v4-design.md`，任务产物仅本spoke `tmp/model-request-runtime/b1-runtime-projection/**`。不改四件套／旧v3-design／spec／registry／产品／词表／对象／实现源码或锁文件，不接受、不提交、不付费、不push。独立构建本spoke工具环境，结构检查使用本spoke自己的.venv及源，formal=skip不算执行。

精确输入从本HEAD及registry读并列hash：

- D086接受RT4 73条／27资源、13个九项操作；contract SHA `4a31cb8bc98ae5bbb55a28c671ff84a8f86520747de7dd07c180787183651689`。17精确依赖沿registry，AR3不擅改AR4。consumer-impact／examples／S68～73和相邻S6/S17/S27/S32/S33/S43/S49/S72修订是核心输入。
- D083接受SL3，contract SHA `f327f1289e1d6c539dd959e8862b382869e3d303cf984b6a773fdd6a00e4bd26`；四参数及顺序、THIS0、unknown、完整前缀／密集追补、消费者迁移。
- D084日志v3-design rev2 SHA `f8561eed58597fbb972d474b14648f74f74cafae3d1125f7813a45a4c241b351`，D085恢复v3-recovery-design rev2 SHA `ea205862968dbe54889d7ba4b80ffcb33e04318c5ba8a82fb09367c1bbd324ae`。processOwnership归日志open宿主，本runtime不直接掌管进程身份／kill；已采用设计不等于真实IO完成。
- D076及既有runtime v3-design（SHA `31a46a46ad67bb6d1dd383cbc6a08a7a89d3354aa261d9db54ab8f7ae7d2ae99`）、原节点README/verification/bindings，重点L2～5/L7和Q1～4；既有宿主、引用、观察、credential/current input及停止责任不另起定义。
- D081选择及late-coordination三候选、既有RAF2与run-attempt-facts-derived的Run缺口、JSONL原表示／存储／恢复前提、MS4/MR4/CA2精确Schema，D082公共定义投影与当前公开函数引用责任只读。

原有限模型与403文件运行归档只证限定安全性质，不证明StopOld、IO、读取权限、公平进展或新版全部操作。不得拿它关闭实际门。

## 本节点增补必须表达的验收清单

1. 所有13操作保留；列出受影响调用/记录/写方矩阵，明确每一个append第四condition及原fence，普通记录与noRun支保持已决定的unconditional语义，不把tailEquals泛化为每笔业务新政策。
2. withRun每个响应提交方（普通失败、取消、interrupt、host撤除、reconcile、settleReply、调用者persisted消息+response批）共享同一性质：合法同次完整前缀或受拥有密集追补→解释Run及原attempt→稳定原业务批→unfenced+tailEquals→同一`entries.jsonl`比较并整批确认。共同物理对象必须具名，不能用SQL事务/内存mutex/晚到bool/另读tail替代。
3. tailChanged只证明本次0：权威追补、重算late、原身份/原绑定/参数/账不变；unknown不是未提交/新身份资格，也不能由后次确定拒绝关闭旧unknown。原opened未知门保持更强，不以有响应恢复路径绕过首内容隔离。
4. “本实例pending”与可能已耐久事实分开；selectModel未知不保M1且当前selection不认回该命令；release/settle/read/reconcile沿原重复返回与权威认回，不加命令键、自动重放、恰一次、回滚、新phase/failure/API。
5. 消费者有界争用策略为具名可配置可替换输入，按已接受S71～72说明触发点、预算、进展前提和耗尽后ownership；不填默认数/固定TTL/隐藏恢复调度。owner持有与close触发不保证成功，真实旧写者停止、恢复实际可调用并被调用、许可预算内真实提交机会不可省略。
6. 全部实际旧fenced/unfenced写方须停准入、真实静止或确认物理退出、旧provider完整close最后放锁；新owner取得独占和权威恢复后开闸。provider.close不是物理死亡，未能停止的任务仍可见被拥有，不以abort/Promise/timeout伪称资源释放。
7. 公共独立invokeModel保持无日志/租户service依赖，不重复包装LLM类；沿现有闭包、Cordis插件/service/fiber与宿主投影。新行为属于runtime/consumer，日志保持业务不透明三操作。必要技术端口需写字段域/失败/所有权/权限/关闭责任；未有精确依据不填默认。
8. G28～31生产Run认法、共同codec/全批认回/全部旧写者、完整合法读取与权限、多值headers保持原语义owner。可识别的投影/装配缺口明确受阻消费者及可验条件；不能在此补造Run终结事件、业务键规则、读取特权、headers数据政策或新跨owner原子承诺。若必须改变规格则报告具体clauses/反例，停该依赖部分，其他可表达段继续。
9. 验证义务逐条由接受变化推出：真实尾插桩两种先后、全批与消息竞争、unknown已提交/未提交/晚提交、旧writer真正停、原opened门、预算耗尽责任和所有权/取消/日志IO/query失效。每项说明positive/negative能失败的证据及实际未执行；既有13ops/真实模型/T-SC-G/README双方公开例和旧原义务不删，不写占位binding。

## 施工顺序、交付和停止

先冻结输入／登记已知假设未知，读受影响对象与已有归属；逐新条款和全部写方对照后写完整候选增补，按既有Cordis投影、公开面、存储、load/unload、失败、观测、consumer impact、verification与gaps结构输出。原未受影响方案只引用，不复制重写整份旧设计。

交回候选全hash／输入manifest及无漂移结果、精确diff、链接与结构检查实际argv/cwd/exit/raw输出、明确新增binding0/运行0和未闭合责任。仅候选存在不授予源码实现；交回后停止写，root安排architecture/spec独立review和精确技术采用。缺规格或归属时不自由选政策，报告并保持能继续的既有投影工作。
