# MR5 core公开接收增量：提供者投影构建简报

2026-09-27，root窄技术构建输入。目标是 MR5→core实际公开完整接收的可审阅 realization候选，属于本条model-request-runtime G31 必需传播，不开新package/能力/platform。

执行库主检出 /data/qiwei/repos/omne-harness-lite、HUB panqiwei/model-request-runtime@35be212b8f4239a2a833d8809026f77a9a202dfc；fresh origin/main仍edee5bb7，HUB落后0。新增sibling spoke model-request-runtime-p2-mr5-core-projection，branch同panqiwei，必须现场verify HEAD/common-dir/tracked初始状态；root会应用 MR5/RT5 已冻结完整39候选patch并提供原字节简报。候选正文仍未正式接受，绝不可写源码或冒充已验收。整个主线仍有独立RT5表达评审，若发生规范语义修订需停依赖段请root提供重新冻结输入。

唯一受维护写面 .meta_harness/design/realization/packages/core/model-response/v5-design.md。原README/design/bindings/verification、product/terms/objects/spec/registry/source全部只读，root后续负责导航、记录、正式采用。tmp/model-request-runtime/p2-mr5-core-projection仅自己的输入快照/sha/检查/交接。你不是唯一参与者，不覆盖或回退他人改动。不写AGENTS或插件/角色定义。

正式前身为既有core model-response纯模块，D062/D065节点接受及后来MR4根消费的实际记录；本次MR5精确candidate给出同map string或ordered string[]。MR5 contract SHA c4cba40c4cbe9bf0c725cb47d0587d9672fb058a456ef14925dcce638eba065e/schema acfd0652805dcecc3e97b34a39375eda9042044fc42fe64b0dc83d1af18ec8d7/examples2f66ca0cdc0065101494e8d03f47a731984179bc28043333e38d12151d0c645d。38条仅S20/S26/S27增量，其余35原字节；7规范依赖与MR4相同。完整原实例58+新增19=77；不新增shape/category/role/业务失败。

RT5 contract SHA21c3ef25ae703c7230b709f5a445bdd8daad9d9a808784c8824b2f98878a733e提供消费背景：S58同次rawHeaders交到S54再S17完整响应，不把头当首token/内容/诊断。root header-handoff rev1 SHA96749d7d17e05558525b85294d478d5f0119416fbc9f5a7eb8e2a83174277f01；独立选择评审无阻断，MR5单包表达评审无阻断，RT5全文另审，均不代替provider接受或真实IO。

主线公共采用账本：本候选为MR5提供显式 ./v5 和 ./schema/v5 入口；当前包根 . 与 ./schema仍精确MR4，./v3/schema/v3等现存采用不改。未来RT5/runtime/codec新consumer须显式import v5，不能借推荐版自动升级。保留现行精确采用是现存消费者责任，不承诺旧已退役五成员adapter兼容、不加类型形状fallback。本包metadata/files依既有真实结构设计，不预先宣称现有exports已提供v5。

仍用既有 TypeScript 纯模块、core无损JSON/ExactDecimal、实际ajv8.20 Draft2020；无Cordis、fiber/service、存储、模型网络、credentials、Clock/time真实性或diagnostic事件。Core只检查值/完整Schema与原S27优先，返回原judge的ok/rejected，不承担取头、脱敏/凭据留存、physical samecommit或来源真实性，不因此修其他core节点。old毫秒原功能及v4/v3 judges/readme examples不改写为已经验新版本。

要求设计完成如下内容：
1. 四层状态准确，前身/目标范围/精确候选及旧正式采用分开；记录已读机制不声称双盲。不新增terms/objects；RawHeaders仅既有值类型的技术别名候选。
2. clause-to-public投影：MR5完整类型、validate/schemaId/SCHEMA_DEF_NAMES/SchemaValidation/SchemaDefName和judgeModelResponse，以真正src/exports/原judge控制次序为事实背景。当前完整接收返回{ok:true}不返回ownedModelResponse；不要投影不存在的capture方法，不用断言把未知值当 owned。
3. string/string[]原形/有序/重复/空串/空数组/空map与缺席区别，禁止join/取首/删值/stringify/头名新归一化；非法多值数组及其他value拒绝。S27旧outcome_unknown/dispatch_zero/cause_unknown优先及跨成员malformed保持，新数组不能掩盖原reply/ending拒绝。值数保持无损。
4. 表达真正实现拆分：从既有模块复用成熟片段，v5完整接收独立校验冻结MR5原Schema；如果共享helper抽取会改变v4行为，说明protected边界和验证义务，不无限复制状态逻辑。给至少三个实质公开/采用候选比较（显式子入口保旧消费、整体根升级并显式传播旧consumers、另开provider包），主线本次选择第一条，写反方和改票条件，不重新擅选。
5. 七规范依赖精确，$refs通过公开Schema/已有副本解析；MR-1五组断言副本仅按已采用注解排除口径，不改冻结原件、不删const/enum内用户数据。没有新增循环/动态注册/端口配置。Schema真实发布文件和构建发布/typedeclarations责任具体。
6. storage requirements明确0；load/unload 0效应，模块静态Schema编译和解析的资源不当runtime可替换插件。无新增运行依赖/时间服务/HTTP线序获取要求。
7. 消费者传播只覆盖core新入口→RT5/runtime/transport/codec新explicit采用，旧consumer不自动改。codec mrr/1历史/新格式裁定留共同owner，本node不能通过core支持新数组暗升级其payload语义。生产G6/G28-31/TL-G1分别留owner，不写已闭。
8. 具体可失败验收：所有MR5完整77实例和原MR4拒数组区别、旧58实例/现有包回归、与独立Schema validator的完整口径/原拒绝优先、mutable输入无改/无getter/toJSON额外调用的已有边界、两个fresh闭合公开pack根与v5/v3分离实际导入、双语literal重要操作实跑、真编译array-loss/reject-priority/control负控。raw源事实采得/脱敏/append-reopen归真实owner，core不能由JSON保真宣称已验。
9. 新bindings 0，直到实际可失败证据运行；verification义务名明确可引用并带触发反例；本稿不修改现有bindings规范/已接受契约。

必要输入限定：MR5三资源与nav验证义务、RT5 S17/S54/S58/S59/S64和consumer-impact、header proposal与rootbrief；model-response节点AGENTS父区、README/design/bindings/verification、真正pkg exports/src/schema/test关键接收/拒绝、core dependency公开入口与相应Schema；D070/D076等实际旧精确采用按导航获取。root将39候选及本brief保护hash，作者自己冻结实际必要输入/本源观察，不hash无关全仓。

完成后停止写入，交candidate精确SHA/差分、necessary-input sha与原字节snapshot、链接/格式/内树检查的actual raw/PID/wait（需要Python用本树ownvenv，未准备不得借HUB/main环境）、HANDOFF和归档全成员回读。无需Node install/build/test、不得网络/付费/凭据/形式执行、提交/merge/接受。工具准备root负责；没有候选全量源码运行就只能记录未验证。必需spec歧义、public ledger冲突、只靠源码假设的新保证必须停依赖处具体报告；不默认补齐。
