# RT4 revision 3：交定向复审的候选修订

- Spoke：`/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-b1-runtime-spec`，branch `panqiwei/model-request-runtime-b1-runtime-spec`，HEAD `976534bf17190bbfdaf9e3b87c5abbc2aa70b552`。
- 包：`.meta_harness/design/spec/capabilities/model-request-runtime/v4/`，73 条、13 个九项操作、27 个版本资源与 2 个入口，共 29 个输入。
- 本次改 5 份文档：contract、examples、consumer-impact、topic README、topic verification；`minimal.diff` 只比较 revision 2→3，完整 RT3→RT4 diff 另附。
- contract SHA256：`4a31cb8bc98ae5bbb55a28c671ff84a8f86520747de7dd07c180787183651689`。
- 新 `../output-sha256.json` SHA256：`11ec2435be9ae52f9ccc9f32fc9a745fe7b600b8d0123fd0208a82d26c592e15`。
- 最小 diff SHA256：`9f57a3778200ff6c37d455e5aaef8e1eb140bdd0a195c1eb6ef0af862eb219ec`。
- candidate registry SHA256：`f9ac6a5ad2d8601b945cd6ce6887adfdf447aa6c40583b6d2cbc08776de9397c`，本修订未改，仍含 1 catalog、17 依赖、55 reviewed=false covers、6 正向 formal tasks；无新命名空间，实际 registry 未改。

## 修订落点与来源

1. **RT4-ER1 保留 revision 2 的窄模型修复**：Recover 的 unsafeAbsence 等式右值整体加括号。错误原文与 Prepare→Submit→LoseAck→Recover 轨迹、33 项 primed assignment 核查在 `../revision-2/`。修订 3 模型/全部 cfg/oracle 未改；24 个 formal 资源全部与 root run 2 冻结输入逐字节相同，模型 SHA `d7f25d31fa24a25560bf67d4bc9adf0ccb9b7a9f66606f9a56023f9e2e9049f5`。
2. **RT4-ER2**：S27⑧/S43/S72 区分确定本次未提交与回执未知。确定零写只约束本次，不否认其他切换；未知仍 unavailable，选中沿 S9 权威记录，读当前值不识别本次命令。未知旧 writer 未停，缺席读不关闭责任。没有命令键、恰一次、回滚、自动重放或隐藏恢复调度。
3. **相邻未知状态表达**：S6/S32⑧/S33/S49⑧/S72 明确本实例待确认责任不等于权威日志没有响应/终结；完整原批认回与原重复返回保持，不能从本地原阶段授予再发。
4. **RT4-ER3**：§八进展首行/S17 要求合法完整前缀、事实与日志可得、适用的真实停止与恢复、许可预算内可得并实际执行到的提交机会；恢复实际被调用且可执行。首次触发与 owner 留存不保证成功或未来获调度；未满足仍是未完成义务。续接行要求实际成功对账。
5. **RT4-ER4**：可编辑入口按 D076/registry 标 RT3 与 runner3 accepted；runner3 仍精确消费 RT3，不自动采用 RT4。旧冻结正文和历史记录不改。
6. `examples.md` 保留 V1～V15，补 4 组待执行规范向量（切换、放手、回复未知、条件进展），同步 §4；consumer-impact 传播同样责任，不增操作、失败、阶段或 policy 默认值。

上述最小边界由 root 依据独立架构评审授权；本起草者只沿 S9/SL3S22、原重复返回和 S71 条件进展展开表达。没有新产品裁决或词条。推导没有扩大为切换命令幂等或默认恢复调度。

## 实际检查及其限度

`checks.json` 绑定本次 argv/cwd/退出码和 stdout/stderr；candidate-check、设计 internal/formal=skip、git diff --check 均 exit 0。`candidate-check.json`：73 条/13 操作、926 个本地链接、64 个冻结资源不变、13 个继承形式资源不变；S54～67 字节不变。`changes.json` 列 5 改/24 不变及每个前后 SHA；`after/` 保全当前 29 输入。`before/` 的旧 29 输入逐 hash 对 revision 2 manifest 核实，旧 manifest、registry、handoff、diff、check 一并保全。

本修订未运行 SANY/TLC；revision 2 作者 SANY exit 0 只证明解析，独立 run 1 exit 75 不算指定负控通过。主线独立 run 2 自己绑定精确模型及旧正文；不能因本次模型不变就宣称它执行了 revision 3 正文或新增向量。表达/架构发现的闭合由同 reviewers 定向复核，起草者不自行宣布 ready/accepted。

## 报给主线与缺口

请以此 manifest 冻结定向复审输入；规范向量真实执行仍未开始，无本次新增产品问题。G28（生产 Run 终结认法：原 Run/loop owner）、G29（共同键/物理日志/实际停止：runtime、回复写者、日志 owner）、G30（完整合法读取：host/access/log 与结算者）、G31（多值 headers：原表示 owner）保持原缺口，其他继承缺口不变。没有用形式模型或 D084 提供者采用关闭这些门。

未接受、未提交、未 push、未运行付费调用；实际 registry、冻结包、产品、realization、实现代码均未修改。
