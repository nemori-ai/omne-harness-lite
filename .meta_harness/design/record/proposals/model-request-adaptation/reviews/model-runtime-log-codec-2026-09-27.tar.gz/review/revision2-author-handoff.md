# RT4 G29 rev2 targeted revision handoff

- Candidate: .meta_harness/design/realization/packages/model/model-request-runtime/v4-log-codec-design.md
- Revision: 2, candidate only, bindings 0, no implementation/adoption.
- Candidate SHA256: f537277f2610b2d98169c69d5c71fcbb3e62fd65de3364ae0ff5148603e92c27
- Unchanged manifest SHA256: 39cd81433d5a676453d724579cb7646a25471432922bccc3e0dacf24f63944f4; 226 frozen inputs, zero drift.
- Original rev1 SHA256: ab502ec8045528ab3c7c8c5c45c2e0c54b55022a3d33b79c30c9108cfc024c84. Original bytes, initial checks/argv/raw/status, input manifest, original author report retained in revision1-frozen/ (16 files). No original evidence rewritten.
- Attribution: revision2-review-attribution.md is an explicitly labelled summary of root-transmitted independent reviewer findings, not a verbatim original reviewer report or adoption.
- Exact delta: candidate-rev1-to-rev2.diff (50 lines); snapshot candidate-rev2.md. K1, P1, G29-P sections proven byte-identical in revision2-author-checks.json.

## Targeted changes

1. G29-ER1: distinguish the committed batch's own MessageId and associations from the losing uncommitted candidate's stable MessageId/occupied key. A legitimate first batch is recognized first; loser identity/occupancy alone cannot invalidate it. Candidate identity stability and collision protection remain on the subsequent write path when no legitimate original batch has been recognized. Result table and C-V6 clarify this same scope.
2. G29-ER2: share value/identity/field predicates while assigning actual positions, presence in a captured prefix, adjacency and durable Batch membership to read-back only. Write inputs remain OwnedLogEntry candidates without positions; prior dispatched/opened must already be real, but candidate response need not be present. No predicted position or candidate-as-read evidence.
3. G29-ER3: R.firstTokenAt corrected to R.timing.firstTokenAt.

## Actual checks and boundary

- Own .venv and own checker source: revision2-check-invocation.json contains actual argv/cwd/executable/prefix/jsonschema/yaml/checker hash/candidate hash. Structure raw output revision2-check-design.raw.log, actual exit 0, formal=skip. Exec handle 23476 is completed with outer exit 0, no ongoing process.
- 226 inputs unchanged, 26 relative links valid and inside design, no trailing whitespace; revision2-author-checks.json.
- git diff --no-index --check rev1 candidate: actual exit 1 (difference status), empty raw output; revision2-diff-check.raw.log/.exit. git diff --check: actual exit 0; revision2-tracked-diff-check.raw.log/.exit. No formatter dependency installed.
- Maintained change is still exactly one untracked candidate file. Specs, four files, source, registry and existing adopted projections unchanged; no IO/product tests, paid request, TLC, commit or acceptance.
- G29-P's actual all-writer/source evidence gate and prior G28/G30/G31 remain open. No scheme, public SL3 interface, product policy, error meaning or identity domain change introduced.

Candidate writing stopped for root's targeted expression re-review; this handoff is not acceptance.
