# 主线保存的表达评审归因摘要

这是root据spec-reviewer `/root/p2_narrow_projection_expression_review` 两份实际完成消息保存的忠实摘要，不冒充逐字报告/技术采用。全程只读，无产品/形式/IO执行、文件写入、binding或接受。

初审rev1 SHA ab502ec8045528ab3c7c8c5c45c2e0c54b55022a3d33b79c30c9108cfc024c84，manifest39cd81433d5a676453d724579cb7646a25471432922bccc3e0dacf24f63944f4。亲核226输入零漂移、26链接可达，九坐标accepted；RT4仍27资源/17deps/55 reviewed:false covers/6形式任务，AR3不升级。

- G29-ER1阻断：谓词5/6第103–104行“当前已指定MessageId/被别批占用”未限定哪一批，与第124行先到合法不同处置原批认回冲突。合法原批先到而败方候选另一个MessageId或其被别批占用，两种实现可分别回原确定事实或unavailable。必须明确原批身份与待写候选稳定/占用阶段，后者不能单独否定合法原批。
- G29-ER2阻断：第97–104行写前/读后共用全部谓词，却要求真实前缀内LogEntry position/相邻/Batch集合；OwnedLogEntry写前无position，首次候选也不在前缀。需区分共用值/关联与读后耐久事实，不能预测position或候选冒充读证据。
- G29-ER3非阻断：第100行R.firstTokenAt错误，正式MR4路径R.timing.firstTokenAt。

没有新增业务/架构取舍要求。G29-P已区分completeMembers/物理来源，不拿相邻/wrapper/trusted=true当证明；实际来源不能兑现是否演进日志归架构owner。全部C-V/真实竞争/停止/恢复/秘密验证和G28/30/31/一般壳/13ops/37模型仍未覆盖。

定向复审rev2 SHA f537277f2610b2d98169c69d5c71fcbb3e62fd65de3364ae0ff5148603e92c27，manifest同上。亲核226输入零漂移、冻结rev1与实际50行差分一致、K1/P1/G29-P原字节不变。

ER1/2/3全部闭合，修改邻域无新表达问题、本次无阻断/新增非阻断/新裁决。第97/103–104及结果表/CV6明确先按原批自身认回，败方候选不同或占号不能否定原批，候选稳定/占用保留后续写前；第97/99–100/103–104将真实位置/前缀存在/相邻/耐久Batch限定读后，写前无position且不冒充；第100正式首token路径已修。没执行check/tests/IO/TLC，新增C-V6场景待实跑；闭合不表示生产就绪。
