# RT4 G29 codec rev1 author handoff

- Spoke: /data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-b1-business-codec
- Branch: panqiwei/model-request-runtime-b1-business-codec
- Base: 8045697aa3c111becfda2f2e082e5ff0a885eab5
- Candidate: .meta_harness/design/realization/packages/model/model-request-runtime/v4-log-codec-design.md
- SHA256: ab502ec8045528ab3c7c8c5c45c2e0c54b55022a3d33b79c30c9108cfc024c84
- Manifest: input-manifest.json, 226 frozen inputs; SHA256 39cd81433d5a676453d724579cb7646a25471432922bccc3e0dacf24f63944f4; zero drift.
- Brief SHA256: 3286f90b34733eba6834939c544a45d037b017cee232e34cab0bbba4817f52d9.
- Delta: one new candidate file only; candidate-rev1.diff and candidate-rev1.md preserve review bytes. No existing maintained file changed.
- Structure check: own .venv/bin/python, own checker source; actual argv/cwd/module paths in check-invocation.json. check-design.exit = 0. Raw output check-design.raw.log ends PASS, gate=internal, formal=skip. No TLC, IO/product tests, network request or paid call executed.
- Author checks: 226 inputs unchanged, 26 local links exist and stay within design; no trailing whitespace. git diff --no-index --check returns 1 for a new-file difference, with empty raw output; initial author wrapper incorrectly expected zero. Corrected interpretation retained in author-checks.json. Tracked git diff --check = 0. This is an orchestration expectation correction, not a changed candidate/test.
- Catalog check: nine exact coordinates accepted; catalog-check.json records versions/receipts. Source clauses and actual exported seams in source-references.json.

## Candidate scope and review focus

K1 exact reversible keys preserve identities and canonicalize dispatch mathematical equality without Number narrowing; P1 is a model-combination-only payload wrapper. Shared pure exports stay in model-request-runtime root; exact dedupe/read keys, complete-member association, original values, reply dispositions, unknown responsibility, real consumers and ten falsifiable oracle groups are specified.

G29-P remains an explicit gate: SL3 public read has no physical batch identity. H1 single append([M,R]) and H2 split append([M]);append([R]) without intervening entries can yield identical three-operation read results. Pure full members cannot prove physical same commit. S73 all-writer provenance/one-append real implementation plus split-batch/competition evidence must be independently assessed. Unknown historical provenance or unadopted writers cannot be blessed by a boolean; if arbitrary history must be self-authenticated from reads, formal spec evolution is required. The candidate does not claim this prerequisite is already established or that G29 is closed.

Other gates remain G28 real Run semantics, G30 full-read authority, G31 headers, historical representation migration/actual stop and original complete runtime/37-model acceptance. No new binding; no implementation, adoption, commit or source changes. Existing four files and v3/v4 accepted projections untouched. Author stops writing candidate after this handoff for independent architecture/expression review.
