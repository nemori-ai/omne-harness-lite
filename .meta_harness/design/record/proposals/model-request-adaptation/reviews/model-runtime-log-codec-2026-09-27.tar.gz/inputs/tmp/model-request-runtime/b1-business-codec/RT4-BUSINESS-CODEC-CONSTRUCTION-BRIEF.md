# RT4 G29：共同模型日志键和整批认回的窄投影简报

完整目标仍是 model-request-runtime 纵线。下一项只把 RT4 S-70 已要求、G29 明确留给共同 owner 的生产表示固定成可评审实现投影；不重新决定 late、不建立一般 SessionEntry/Run/资产平台。本 brief 是施工输入，不是采用；只有独立评审及 root 精确采用之后才能给实现者生产依据。

## 角色、写入边界和基线

realization-drafter 使用 root 新建 spoke `model-request-runtime-b1-business-codec`，先证明 cwd/branch，基线 HUB8045697aa3c111becfda2f2e082e5ff0a885eab5，remote main edee5bb7 已包含。唯一受维护可写路径 `.meta_harness/design/realization/packages/model/model-request-runtime/v4-log-codec-design.md`，以及该 spoke 自己的 `tmp/model-request-runtime/b1-business-codec/**`。原四件套/v3/v4/D087/spec/product/词条/对象/registry/source/locks全只读，不改候选以外的导航，不接受、不提交、不付费、不读凭据。你不是唯一参与者，不回退别人。

需完整输入/接受依据/明确 node-plan；任何必须新增规范义务、产品语义、身份值域限制或通用能力时，保全准确坐标并报 root，停止依赖段，不能代定。只在已明确语义内选择具体表示和实现手段。

## 权威输入和事实基准

1. D086 接受 RT4 S1～73/完整13操作，contract SHA4a31cb8bc98ae5bbb55a28c671ff84a8f86520747de7dd07c180787183651689；重点 S5/S8/S15～17/S27/S31～34/S49/S68～73，G29。
2. D087采用 v4-design rev2 SHA95a0115e89404d147ef547655e06e3c8bca86a79c16b9a9fa8b13dc56518f212；共同物理对象同session entries.jsonl、四参数矩阵、全部结算写方、完整同次前缀、unknown/opened强门与原处置不改。D076/v3-design SHA31a46a46ad67bb6d1dd383cbc6a08a7a89d3354aa261d9db54ab8f7ae7d2ae99及原design的L2/L5/L6命名责任沿原域。
3. D083 SL3 SHAf327f1289e1d6c539dd959e8862b382869e3d303cf984b6a773fdd6a00e4bd26、D084/D085；日志只处理不透明dedupeKey/readKeys/通用壳与整批JSONL，键相等不等于业务认证。当前HUB新增真实SessionLog/AppendCondition/LogEntry等公开入口，实际install/build/typecheck/165test/format/source rules均0，独立验收正在执行。这些不是G29组合证据。
4. registry精确accepted MR4、MS4、CA2、IV1、CB3及 D070/D068 原生产者发号/JSON接收采用；读取对应spec、Schema、例、core/messages/model-response/call-accounts/content-blocks提供者设计和公开src。MR4账在响应内部，不新增独立账记录；先完整judge再取得owned值。MS4切换/调用五类记录与消息表示沿既有数据契约。
5. runner3仍规范消费RT3；S19同值消息认回/异值冲突只在确实用到消息键时共同采用。外部persisted写方可以由既定model-request-acceptance真实应用实现，不以完成整个Agent Loop作为本G29前提。G28生产Run认法/G30合法全读/G31多值headers继续各自owner。

root已独立核明：现在没有已接受的完整共同业务codec/认回投影。`mrr/`旧文字只是命名责任，JSONL提交行codec不是业务codec；现有输入足以起草本技术投影，不能在代码各自拼串后追认。不得把root或reviewer的定位摘要当权威正文，关键断言须指向上述契约。

## 必须形成的具体投影

- 交付一个同节点增补页，不另开包/插件/service/fiber/数据库。公开共享pure构件由本runtime包根导出，实际runtime、外部回复、对账和必要消息消费者共同用；可替换内部技术实现但同一被采用格式必须等价。候选函数/type/config名称显式标实现面，不把存在当交付。
- 固定响应、消息、dispatched、opened、interrupt intent、call ended 的dedupe与必要readKeys准确映射、唯一范围和种类隔离。响应沿同一部署ResponseId、消息沿会话MessageId，锚点沿会话/call/dispatch，intent/ended沿会话/call；依据逐种引用，不能给intent/ended加dispatch或attempt改变唯一范围。session是否已由日志对象区分仍须明确写出映射/消费关系，不能靠函数名猜。
- 为外部有效身份保留全部既定值域：不要求UUID/固定长度/无分隔符，不做大小写或Unicode归一化；session kind/context边界不互撞。dispatch是精确正整数，不缩窄JS safe integer，不按数字lexeme把同一个值编码为不同业务键。任何规范化仅限具体编码所必需的数学表示，不改原payload数字字面/金额。说明可解码/单射理由与成本，不能用未可反驳的hash无碰撞承诺。
- 选定精确载荷承接方式：MS4五类记录和Message、MR4响应都沿已有类型/完整接收边界，在SL3 opaque payload中可无歧义识别。本项只能固定模型组合自己的表示，不泛化一般条目、寿命或种类治理；MR4 S14/G3未决范围继续标出。若读取键承担辨别，需要完整说明多键/伪造载荷的拒绝，不用“有key就是response”。
- 分别列每个既定replyDisposition/outcome要求的完整批，persisted包含指定MessageId的AssistantMessage与原ResponseId响应同批；非persisted不能凭空带消息。保留原response/账/message全部值，字段关系要从MS4/MR4/RT4逐项落到可检查规则；不只核数量、Schema、一个key、任意同键JSON。SL3读结果没有独立batchId时必须说明如何从现有日志位置/成员关系认回，不能偷加一张状态表或把别批拼作本批。
- 认回输出明确区分未见、合法完整原批、合法先到但不同处置、部分碰撞/身份不符/成员缺失/原值不可确认。RT4 S70先认回原批，S49同处置返原结果/不同合法处置alreadyEnded保持；不可认证是unavailable、不可补残批/换ID/覆盖原值。读到完整事实与关闭旧unknown写责任是不同证明，不能因codec成功说旧任务已停止。
- 普通记录键读取/构造和响应完整认回共享同一实际入口；selectModel不存在未知命令身份，不加命令键/自动重放。不要把MessageId原随机生成选择扩大为所有身份新规则，ResponseId/CallId具体发号与碰撞责任仍沿已有owner；本项只消费稳定指定身份。
- 追加保护/权限/阶段与owner仍按D087，不由pure codec授予。载荷与键的捕获/复制及无损精确比较须说明所用真实core公开入口；没有coreJsonNumber这个导出，实际为JsonNumber/LosslessNumber/jsonNumberSource、ExactDecimal等。生产授权/Run认法缺席不能靠typed字样或fixture消掉。

## 提供者结构、验证与传播

候选写清contract→具体共享构件/存储对象→可失败oracle，配对普通构造/反认回/全部实际写方采用；不注册没有运行的binding。列公开入口、层状态、存储要求、捕获的策略/资源所归owner及载荷日志的秘密界限；pure codec静态导入不IO、不读env/clock、不加载Cordis。日志不新增业务校验或接口；与readSettlementPrefix/interpretSettlementPrefix/prepareSettlementBatch/recognizeCommittedBatch/createSettlementCoordinator的精确组合关系明确。

最小消费者：runtime全部普通结算/settleReply/host close/reconcile及锚点/意图/ended读写；一个真实外部persisted写方；实际纳入装配的runner消息路径。计划外完整工具执行/ask/经过/全Agent Loop不扩。必须列同根旧写方停止、版本显式采用、同值认回/异值冲突与历史编码迁移；未正式发布生产不保留未经要求的兼容层，旧记录没有确定映射时明确受阻，不猜迁移。

待执行oracle至少覆盖：所有种类/范围/分隔字符/Unicode/等值精确数字/超大dispatch的往返及不互撞；相同业务跨两个独立消费者生成同dedupe/readkeys；真实JSONL两种胜出顺序与完整原批、原messageId/responseId/账不变；同处置认回/不同合法处置alreadyEnded；部分碰撞/伪造身份/错误call/dispatch/binding/params/缺消息/额外不合法成员不得成功；实际未知ack、旧writer迟到与停止/权威恢复；拒绝据局部key数推结算和重新发出。负控须移除种类/范围/精度/关联/全批校验时真正失败。没有本轮运行，不写已证结论。

比较本技术选择的最强反方与改票信号，置信度/资源代价明确；沿已决定共同对象，不另提不共享日志的替代。这是现有性质内的窄realization，不需要凑新三候选或重新写全域架构。如果具体采用不得不改变冻结规范承诺，报root进入对应新版本，而非在本页自由改语义。

## 完成与交接

source/input manifest精确版本与hash先保全；给root候选SHA、最小diff、全部引用/结构检查原始输出、规范→映射→oracle表与遗留门，维护候选先后修订原字节。可用自己的checkout .venv跑internal design checker formal=skip和diff check；不跑IO/TLC/模型付费、不调用别人环境。独立架构/表达review与root接受归主线，候选页本身无采用资格。
