from pathlib import Path
import datetime
import hashlib
import json
import shutil
import tarfile

HUB = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime')
SPOKE = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-b1-log-projection')
AUTHOR = SPOKE / 'tmp/model-request-runtime/b1-log-projection'
STAGE = HUB / 'tmp/model-request-runtime/b1-late-coordination/sl3-provider-review-archive'
DEST = HUB / '.meta_harness/design/record/proposals/model-request-adaptation/reviews'
DOC = 'realization/packages/session/session-log-jsonl/v3-design.md'
FINAL = 'f8561eed58597fbb972d474b14648f74f74cafae3d1125f7813a45a4c241b351'
ARCHIVE = DEST / 'session-log-jsonl-v3-2026-09-27.tar.gz'
INDEX = DEST / 'session-log-jsonl-v3-2026-09-27.json'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

assert not STAGE.exists(), 'stage exists; preserve prior attempts'
assert not ARCHIVE.exists() and not INDEX.exists(), 'record is append-only'
STAGE.mkdir(parents=True)
design = HUB / '.meta_harness/design'
assert digest((design / DOC).read_bytes()) == FINAL
assert digest((SPOKE / '.meta_harness/design' / DOC).read_bytes()) == FINAL
observed = json.loads((AUTHOR / 'inputs.json').read_text())
assert len(observed['inputs']) == 28
rows = sorted(observed['inputs'], key=lambda row: row['path'])
summary = digest(''.join(row['path'] + '\t' + row['sha256'] + '\n' for row in rows).encode())
assert summary == '6e57ee89189bc356eca20b93e4fa6ae03fb991d8cdfc46a35ed068bf8a0e9bd9'
assert digest((AUTHOR / 'inputs.json').read_bytes()) == 'dcc8d7ccde74dc52378cf80713ed9598c7c1efc958fb27af9b58f16659d6795c'
for row in rows:
    path = Path(row['path'])
    assert not path.is_absolute() and '..' not in path.parts
    original = design / path
    assert digest(original.read_bytes()) == row['sha256'], row['path']
    target = STAGE / 'inputs/design' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(original, target)
extras = [DOC,
    'realization/packages/session/session-log-jsonl/README.md',
    'realization/packages/session/session-log-jsonl/verification.md',
    'realization/packages/session/session-log-jsonl/bindings.yaml',
    'record/decisions/session-log-tail-condition-adoption/acceptance.json',
    'record/decisions/session-log-tail-condition-adoption/decision.md']
for rel in extras:
    target = STAGE / 'inputs/design' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(design / rel, target)
shutil.copytree(AUTHOR, STAGE / 'author')
assert digest((STAGE / 'author/rev1-design.md').read_bytes()) == 'c26b03b9ee84c3bd809e61cd1bf2538d819ff4734e7178100d041d9897335849'
shutil.copyfile(Path(__file__), STAGE / 'archive-sl3-provider-review.py')
write_json(STAGE / 'review/primary-summary.json', {
    'source': 'primary-agent summary of independent collaboration messages; not verbatim reviewer reports',
    'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'object': DOC, 'revision_1_sha256': 'c26b03b9ee84c3bd809e61cd1bf2538d819ff4734e7178100d041d9897335849',
    'revision_2_sha256': FINAL,
    'architecture': {'agent': '/root/b1_late_boundary_review', 'role': 'architecture-reviewer',
        'initial_blockers': [], 'final_blockers': [], 'confidence': 'medium-high',
        'verified': ['same entries.jsonl compare/whole-batch/confirm domain', 'failure priority and THIS zero write',
            'keyless/unfenced legality', 'same-read complete prefix', 'untrusted reads refused',
            'actual task stop and independent restart', 'single cleanup ordering and explicit SL2 writers migration'],
        'counterarguments': ['full scanning would remove healthy index trust', 'online recovery would improve availability',
            'shared transaction storage could simplify mechanism but would change accepted choice'],
        'delta': 'old untrusted-tail read replaced; success truncation and original fault obligations retained'},
    'expression': {'agent': '/root/p2_narrow_projection_expression_review', 'role': 'spec-reviewer',
        'initial_blockers': [{'id': 'SLJ3-ER1', 'location': 'v3-design rev1:150 and verification:29',
            'finding': 'unqualified V-5 inheritance required old-tail reads after truncation failure while new provider required unavailable'}],
        'final_blockers': [], 'resolved': ['SLJ3-ER1'],
        'delta': 'three changes only: revision and two explicit replacement paragraphs; old four files unchanged',
        'mechanical': {'links': 20, 'SL3_resources': 24, 'SL2_frozen_resources': 10, 'author_inputs': 28,
            'formal_tasks': 3, 'new_bindings': 0}},
    'not_run': ['provider source tests', 'file IO', 'process locks and restart', 'Cordis completion timing', 'TLC'],
    'remaining': ['consumer exact versions', 'common business keys and complete recognition', 'production Run interpretation',
        'full read authority', 'actual old business writers stopped', 'multi-valued header projection'],
    'acceptance_by_reviewers': False})
files = [p for p in sorted(STAGE.rglob('*')) if p.is_file()]
inventory = [{'path': str(p.relative_to(STAGE)), 'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())} for p in files]
write_json(STAGE / 'inventory.json', {'files': inventory, 'author_inputs_verified': 28, 'input_digest': summary})
files = [p for p in sorted(STAGE.rglob('*')) if p.is_file()]
with tarfile.open(ARCHIVE, 'w:gz') as archive:
    for p in files:
        archive.add(p, arcname=str(p.relative_to(STAGE)), recursive=False)
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(files)
    expected = {str(p.relative_to(STAGE)): digest(p.read_bytes()) for p in files}
    for member in members:
        assert member.isfile()
        assert digest(archive.extractfile(member).read()) == expected[member.name]
write_json(INDEX, {'archive': ARCHIVE.name, 'sha256': digest(ARCHIVE.read_bytes()), 'bytes': ARCHIVE.stat().st_size,
    'file_count': len(files), 'readback_verified': True, 'candidate': DOC, 'candidate_sha256': FINAL,
    'author_inputs_verified': 28, 'input_digest': summary,
    'review_source': 'primary summary; independent reviewers wrote no files', 'provider_execution': False,
    'inventory': inventory})
print(json.dumps({'archive': str(ARCHIVE.relative_to(HUB)), 'sha256': digest(ARCHIVE.read_bytes()),
    'files': len(files), 'input_count': 28, 'readback': True}))
