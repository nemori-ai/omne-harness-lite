# SL3 日志提供者窄增量 construction brief

基线：HUB c10bad93117c9260348e8ffdff8f8f9a358b9673，D083已接受session-log3。目标只为必要三操作提供者的新精确消费投影，使后续可按设计施工；不是实现授权或完整会话/Agent Loop设计。

## 必要输入和所有权

- registry/catalog/frozen及D083 acceptance.json；SL3全部24资源，contract f327f1289e1d6c539dd959e8862b382869e3d303cf984b6a773fdd6a00e4bd26，consumer-impact/formal范围。
- 既有session-log-jsonl/design.md D062/D065接受，保留JSONL属主文件锁、每日志队列、一行一批、datasync确认、派生索引与物理所有权/退出前提。
- v2-design.md候选rev2、原review输入及G2-1..7。其可用明确载荷无损责任进入新稿，不能假称v2已接受；G2-6头字符串投影、G2-2业务键和生产Run认法不归日志。
- D081方向、当前runtime3/runner3、messages4/response4/CB3/callaccounts2/profile3的精确版本，D076原unknown opened及真实停止义务。

唯一可写：独立spoke .meta_harness/design/realization/packages/session/session-log-jsonl/v3-design.md，及spoke tmp/model-request-runtime/b1-log-projection/**。不改既有design/v2/README/verification/bindings、spec/product/UL/objects/registry、源码/锁文件，不接受，不运行付费请求。不是唯一参与者，不覆盖他人工作。

## 必須投影的责任

1. append新增required condition在同一日志串行判定与实际整批提交域比较；精确尾/位置保真，不把比较结果挪到锁外/其它事务。不改变错误优先级；tailChanged整批零写、无tenant初始化或position分配，包括未来tail。
2. 租户/尝试壳/判重/尾都来自同一本已确认判定态；读完整前缀和tail在同一合法readSince快照。保留readByKey/readSince三操作面，无额外business callback/recover业务操作。
3. 表达合法keyless、fenced/unfenced、unconditional/tailEquals组合；日志不解释ModelResponse/Run/late。模型响应批的共同键/业务认回按consumer前提引用，不由provider猜键。
4. 一行一批/datasync/首次目录同步、已提交丢确认与可能继续提交两种unknown；进入不可信态后先停止旧物理写者/排空或独占重开，再权威扫描，拒绝新写直到恢复完。后续tailChanged不能否认旧unknown，Signal或简单Promise结束不是物理停止。
5. 同一文件/进程/跨实例属主锁、资源发布/关准入/排空/关闭逐配对；装卸超时与清理失败真实暴露，不提前放行旧writer。未来异构节点重检物理提交边界，不加分布式承诺。
6. 旧SL2实例/旧写方真实退出再采用新provider，或者显式独立装配保证无共享writer；不存在三参数默认unconditional兼容。当前RT3不能直接接新接口，应保留consumer新规格门，不以D083自动升级RT3。
7. 复用core public lossless JSON表示/编解码，捕获owned入参，对载荷无data-schema强制校验；具体provider面与插件/service/effect、公开可单取closure四问映射明确。诊断及存储资源归日志owner，敏感正文不因读取/恢复追加到工程输出。

## 验收义务（候选尚未执行）

保留旧三操作全部实际IO义务，新增condition合法/非法、futuretail、优先级、失败零写/原tail保持、keyless分支、完全业务批原子竞争、两种提交顺序与同attemptend（测试记录仅自身范围）、partial-vs-whole reads、丢确认/写者仍能提交/杀进程重开/锁交接、Cordis真实关闭等待及旧三参拒绝。语义消失时各有负控；finiteModel不是IO证明，不先填binding。README及README_ZH公开面示例是后续每包完成判据，不在这里复制社区教程。

输出完整投影、存储要求、成对load/unload、限制/gaps与具名verification表，供独立architecture及expression review。标候选/not implemented/0bindings。若需要新契约、新业务策略、新协调能力、无法继承属主文件锁/同commit，停止依赖处并报告root，不发明替代默认或扩大资产/会话产品。
