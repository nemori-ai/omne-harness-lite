# SL3 不可信重启识别：窄投影补全

任务基线 HUB `6f4f8c76703f8e3fbeb147dfa3bb378f7a80c788`。2026-09-27 重新 fetch `origin/main`，仍为 `edee5bb7d4dfaff32a25df46c4faf95fcb81f117`，落后 0；未带入 main 未提交内容。原 projection spoke 已 fast-forward 到同一 HUB。

只补已采用提供者设计的恢复实施缺口。精确输入：D083/D084、SL3全包、原 design 索引/打开/关闭路径、verification V1/V5、v3-design SLJ3-V8。SL3 contract SHA256 `f327f1289e1d6c539dd959e8862b382869e3d303cf984b6a773fdd6a00e4bd26`；D084 v3-design rev2 SHA256 `f8561eed58597fbb972d474b14648f74f74cafae3d1125f7813a45a4c241b351`。保全所有输入摘要。

开发者报告且主线亲读确认：健康打开信任结构合法索引并补读后缀；不可信截回失败后独占重启要求从权威内容全量扫描。当前公开 open({dir,policy}) 及三文件布局没有可靠信号区分两种路径。仅内存状态、缺损后缀或旧 index 不能区分；一律全扫会改变健康路径及 V1 内容错误反例。

唯一设计可写文件：spoke `.meta_harness/design/realization/packages/session/session-log-jsonl/v3-recovery-design.md`，candidate，作为已采用 rev2 的增补候选。任务证据只写 `tmp/model-request-runtime/b1-log-recovery-projection/**`。原 design/v2/v3-design、README/verification/bindings、spec、registry、decisions、product、代码、锁文件只读。不提交/推送/接受。你不是唯一执行者，不回退别人编辑。

比较显式 caller 恢复选择、provider 持久属主/不可信标记、原现成文件可靠失效等实质途径，推荐最小完整一项并给最强反方与改票条件。它们都是候选，不是主线预先裁定。只补本缺口，不重选存储或展开通用恢复平台。

必须具体覆盖：

1. 区分健康重开、不可信重启、未干净退出的可靠信号及来源；不能由 index 合法推健康，不能假定出错后另写标记必成功。
2. 新物理文件/字段的完整布局、创建/更新/同步/清除顺序、权威/派生关系、所有失败分支，以及唯一属主锁和关闭配对。逐落盘阶段 SIGKILL/IO故障给可复核后果；不加隐藏 timeout/锁等待。
3. 健康索引信任与 V1 结构合法内容漏键反例保持；不可信恢复从字节0全扫、不跳前缀，修复确认后才发布可用性。运行中 LRU 重开不得丢不可信状态/绕重启要求。
4. 保持 D084 旧物理进程实际退出/被杀且确认退出、新 owner 独占取锁前提。锁可用仅证明旧 provider 放锁，不直接证明旧进程退出。同进程关闭重开、不同实例、PID复用分别说明；无法本节点闭合则点名真实 owner/输入，不把退出偷换成 close。
5. 新公开配置（如必要）的输入/缺席/校验/迁移责任。不改三个操作、追加四参数、Run/共同业务键/headers/消费者策略。现有契约足够时只补投影；必须改语义时停止并指出具体条款。
6. 真实本地FS/多进程正负oracle：健康索引使用、健康异常退出、不可信各故障阶段、关闭/释放/同进程重开、全扫后去重/尾/租户/fence及发布前 unavailable，原负控保持。不得称已运行。

按本 spoke AGENTS、手册提供者/规格演进路径执行；本次由施工反例触发，不重新声称双盲或全量架构重做。交回 candidate hash、diff、inputs、链接/结构检查原始输出及缺口。独立 architecture/spec 复核及主线技术采用后才成为开发者输入。
