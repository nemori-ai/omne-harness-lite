# B1：session-log v3 条件追加候选施工简报

2026-09-27，主线仅授权规格起草，不授权采用或产品实现。方向依据 D-081；执行计划 revision6 的 B1，增量 wave W3。spoke 从 HUB 60c0652d 建立，origin/main@edee5bb7 落后0。

## 完整目标和边界

新增 capability.session-log v3 候选，保留既有不透明三操作与 SL2 全部未取代保证；以追加提交点尾比较保护依赖完整历史的响应构造。只改变 append 增加显式条件及其具名零写失败，补必要行为权威模型／例子／版本差异和消费者影响。完整会话产品、Run 终结表示、业务键编码、租户授权机制、日志 provider API／JSONL代码、runtime十三操作、新服务及旧frozen资源均不在本任务写范围。当前条件不是业务授权，也不证明调用者的前缀来源合法。

## 已明确的技术选择与命名账本

- baseline `omne-harness-lite-design-2026-09-15`；capability.session-log 新version3，旧v2字节不改。三个操作名 append/readByKey/readSince 保持。
- append(session, entries, fence, condition)。condition 必填封闭判别式 `unconditional` 或 `tailEquals{tail}`；tail 与原 tail 位置同一 ≥0整数域，0为空日志。缺席/畸形/extra成员均 invalidInput，不补默认。unconditional 只跳过新增尾比较，其他旧判定全部保留。
- tailEquals 的等式在同一权威提交点、同一 session 已提交完整日志上判，与整批写之间无其他追加。相等才可写；不等返回 `tailChanged{tail}`，tail 是该判定点实际尾。本次整批零写、零位置分配、零租户初始化或部分业务条目；日志不会解释payload或替调用者算late。猜出的未来尾合法但比较不等，不能作为invalidInput。
- 失败顺序保留旧 `invalidInput → tenantMismatch → attemptSuperseded → alreadyRecorded{keys}`，再新增 `tailChanged{tail}`；正确已存在判重优先于尾改变。判定不可得/写失败仍 unavailable，未确认提交，仍可能已写；不能把 unknown 回执后的新tailChanged、fence拒绝或tenant拒绝认成之前没写。
- 读的签名/返回不变。readSince(session,0) 一次结果包含从1到tail的完整稠密前缀，事实与tail来自该同次读取；只读按键结果或RAF布尔值不具备完整前缀。已有不可变完整前缀+连续追补可构成新的完整前缀，但必须身份一致、无缺号、tail来自该次合法追补。每种条件是现有追加的参数形状，不立新的领域对象/服务/持久身份。
- 表示、位置和相等保持SL2无损规则，绝不先转JS number。新增失败标记 tailChanged 是此版本明确的技术结果名，没有“其他”失败。
- 不新增线上Schema：沿SL2面为进程内能力的明确边界，线上编码归未来composition；不为凑模板制造未授权wire契约。若本地规范必须Schema先报冲突，不自行扩范围。

## 恢复、消费者和保证

带Run的响应写方须合法完整读、识别原发出attempt/真实Run终结、构造整批，再以该tail条件且结算unfenced提交。冲突先认回ResponseId/MessageId整批，存在即认回原值；不存在且读面权威/旧未决写者实际静止等前提成立时，重读新前缀、重新构造late、保留原稳定身份再尝试。严禁变成尝试栅栏挡住迟到账、改原归属、重发模型请求或重铸ResponseId。无Run调用不增加late；是否采用condition由具体消费者明示，不把新增条件全局当权限。

unknown ack 恢复沿SL2 S22/23及RT3 S17/33：先按稳定读键认回原完整业务批，不能只凭旧key缺席或新拒绝断言原批未提交；实际旧writer隔离/权威恢复读前提不能省。尾冲突已确认本次零写，与unavailable未知分清，但不消除先前未知。重试/退避/超时和争用上限属于消费者可配置策略，不在SL契约填固定数/默认TTL；无限持续追加没有无饥饿承诺。

现有SL2继续被未迁移消费者采用，新推荐不自动升级。RT3存在规范SL2依赖，下一必需候选是RT新版本或精确等价的消费修订（不得改frozen RT3），以及日志/runtime/回复provider映射；本task只列影响和精准clause表，不写它们。不声称RT3已能消费新增condition。所有响应写方正常/中断/撤除/settleReply/reconcile/独立reply提交必须进入影响表；其他Run事实及无关writer只需同一权威提交域。生产Run终结认法仍由原owner解决，独立验收driver只认自身实际记录，不能关闭完整Loop缺口。多值头G2-6仍不由SL解释。

## 产物及允许写路径

仅spoke `.meta_harness/design/spec/capabilities/session-log/v3/**`，topic非冻结 README.md/verification.md（只追加candidate入口/义务，不改旧事件/结果）；候选registry条目及formal-task条目先生成到spoke `tmp/model-request-runtime/b1-spec/registry-candidate.json`，主线整批核对后登记，避免其他owner冲突。正式registry/catalog/frozen均不可写。spoke tmp可放准确输入hash及表达检查，不能伪造review/acceptance/evidence。

每operation完整九项，S编号与自引用按新版本闭合；留旧版本clauses对应、新增/不变/消费者影响表；examples含成功/各失败/unknownack条件；verification覆盖已触发义务与未执行状态。行为模型必须表达预读与追加间可以有边界/无关writer插入，至少两个结算者同ResponseId且整个回复批竞争。SL不透明域和消费者解释模型的角色要明确，不将opaque payload表述成SL识别Run。

形式工件至少包含正配置和可反驳负控：删除比较、比较与写拆步、局部历史误当完整前缀、unknown ack误当零写。保留oldmodel五类义务的适用映射，勿把脚本360histories替代TLA。候选起草可做结构/引用检查；本次不执行昂贵/产品/付费验收，工具可用性/范围限制明示，主线再分派独立正式运行。

## 起草完成判据与停止条件

三operation全部失败闭合，新append明确condition形状/顺序/零写/unknown区别；完整前缀与重试消费义务可走通且不填产品未知；旧v2 frozen sha逐项不漂移；新规范所有链接、形式变量和断言对齐；至少三类实际writer+reply整批竞争实例；新增formal tasks只candidate且未运行；消费者影响指出RT3规范依赖必须新版本精确升级；无提供者实现/新服务/架构再选。

缺必要语义、词条治理或规范模板与本文冲突时，停依赖部分并回报具体缺口。不得自行选择新字段、新失败优先级、业务键、Run认法、重试默认或官方model事实。你不是唯一参与者，只写上述路径，不回退他人工作，提交/采用由主线负责。
