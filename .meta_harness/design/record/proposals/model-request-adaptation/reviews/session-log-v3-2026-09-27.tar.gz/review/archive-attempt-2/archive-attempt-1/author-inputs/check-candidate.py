from pathlib import Path
import hashlib,json,re,sys,copy
from urllib.parse import unquote,urldefrag,urlparse
root=Path('/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-b1-spec')
d=root/'.meta_harness/design';tmp=root/'tmp/model-request-runtime/b1-spec';v=d/'spec/capabilities/session-log/v3'
sys.path.insert(0,str(root/'.meta_harness/tooling/src'))
from design_validation import DesignValidator,github_anchor,LINK_RE,HEADING_RE
patch=json.loads((tmp/'registry-candidate.json').read_text());errors=[]
def check(value,message):
 if not value: errors.append(message)
old=json.loads((tmp/'v2-before.json').read_text()); frozen=json.loads((d/'registry/frozen.json').read_text())['files']
for path,digest in old.items():
 f=root/path; current=hashlib.sha256(f.read_bytes()).hexdigest()
 check(current==digest,'old v2 changed: '+path)
 check(current==frozen[str(f.relative_to(d))],'old v2 differs from frozen: '+path)
for path,digest in json.loads((tmp/'registry-before.json').read_text()).items():
 check(hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,'actual registry mutated: '+path)
entry=patch['catalog_append'][0]
check(entry['resources']==sorted(str(p.relative_to(d)) for p in v.rglob('*') if p.is_file()),'resource list differs')
check(entry['status']=='candidate' and entry['acceptance'] is None,'candidate status')
# Invoke existing manifest validators against IN-MEMORY additions only.
validator=DesignValidator(d,formal='skip',gate='internal')
validator._baseline(json.loads((d/'registry/baseline.json').read_text()))
validator._rebase(json.loads((d/'registry/lineage.json').read_text()))
catalog=json.loads((d/'registry/catalog.json').read_text());catalog['contracts']+=patch['catalog_append'];validator._catalog(catalog)
tasks=json.loads((d/'registry/formal-tasks.json').read_text());tasks['tasks']+=patch['formal_tasks_append'];validator._formal(tasks)
errors+=validator.errors
text=(v/'contract.md').read_text(); headings=list(re.finditer(r'^#{3,4} S-(\d+) (.*)$',text,re.M));clause={m[1]:text[m.start():headings[i+1].start() if i+1<len(headings) else len(text)] for i,m in enumerate(headings)}
check(sorted(map(int,clause))==list(range(1,38)),'S-1..S-37 not unique/complete')
for number in ['17','18','19']:
 check(all('| '+n+' |' in clause[number] for n in '①②③④⑤⑥⑦⑧⑨'),'operation lacks nine items: S-'+number)
check('append(session, entries, fence, condition)' in clause['17'],'append signature')
check('`invalidInput` → `tenantMismatch` → `attemptSuperseded` → `alreadyRecorded{keys}` → `tailChanged{tail}`' in clause['17'],'append failure precedence')
check(not list(v.rglob('*.schema.json')),'unapproved capability Schema')
check(not re.search(r'\b(inject|effect|isolate)\b',text),'mechanism word in contract')
for cover in patch['covers_append']:
 check(not cover['reviewed'],'cover claims reviewed')
 check(all(c[2:] in clause for c in cover['target']['clauses']),'bad cover clause')
 rp=d/'product'/cover['requirement']['topic']; file,frag=urldefrag(cover['requirement']['clause']);target=rp/file
 anchors={github_anchor(m[1]) for line in target.read_text().splitlines() if (m:=HEADING_RE.match(line))}
 check(github_anchor(frag) in anchors,'bad cover requirement anchor')
links=0
for file in v.rglob('*.md'):
 for m in LINK_RE.finditer(file.read_text()):
  raw=(m[1] or m[2]).strip();parsed=urlparse(raw)
  if parsed.scheme: continue
  target,frag=urldefrag(unquote(raw));f=(file.parent/target).resolve() if target else file
  links+=1;check(f.is_file(),'broken link '+str(file.relative_to(v))+': '+raw)
  if f.is_file() and frag and f.suffix=='.md':
   anchors={github_anchor(m[1]) for line in f.read_text().splitlines() if (m:=HEADING_RE.match(line))}
   check(github_anchor(frag) in anchors,'missing anchor '+raw)
configs=[]
for cfg in v.rglob('*.cfg'):
 model=v/'formal'/('SessionLog.tla' if cfg.name.startswith('SessionLog') else 'TailSettlement.tla')
 source=model.read_text(); config=cfg.read_text()
 constants=re.search(r'CONSTANTS\s+(.+?)\n\n',source,re.S)[1]
 names=set(re.findall(r'\b[A-Za-z][A-Za-z0-9_]*\b',constants))
 assigned=set(re.findall(r'^\s+([A-Za-z][A-Za-z0-9_]*)\s*=\s*',config,re.M))
 check(names==assigned,'constant mismatch '+cfg.name)
 assertions=re.search(r'INVARIANTS?\s+(.+?)(?:\nCHECK_|\Z)',config,re.S)[1].split()
 for op in assertions: check(re.search(r'^'+re.escape(op)+r'\s*==',source,re.M) is not None,'unknown assertion '+op)
 check('SPECIFICATION Spec' in config and 'Spec ==' in source,'unknown spec')
 configs.append({'path':str(cfg.relative_to(d)),'assertions':assertions})
check(all('validity-check' not in a for task in patch['formal_tasks_append'] for a in task['artifacts']),'negative registered as positive')
result={'scope':'structural checks only; no TLA parsing/model checking, IO, approval or registry mutation','errors':errors,'clauses':len(clause),'operations_with_nine_items':3,'local_links':links,'v2_frozen_files_unchanged':len(old),'candidate_resources':len(entry['resources']),'candidate_dependencies':len(entry['dependencies']),'candidate_covers':len(patch['covers_append']),'candidate_positive_tasks':len(patch['formal_tasks_append']),'configurations':configs,'formal_execution':'not_run'}
(tmp/'candidate-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='configurations'},ensure_ascii=False,indent=2))
sys.exit(bool(errors))
