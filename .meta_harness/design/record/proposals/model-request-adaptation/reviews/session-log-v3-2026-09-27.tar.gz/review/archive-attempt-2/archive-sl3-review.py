from pathlib import Path
import hashlib, json, os, shutil, tarfile, subprocess

root = Path.cwd()
spoke = root.parent / 'model-request-runtime-b1-spec'
task = root / 'tmp/model-request-runtime/b1-late-coordination'
stage = task / 'sl3-review-inputs-2'
out = root / '.meta_harness/design/record/proposals/model-request-adaptation/reviews'
assert not stage.exists()
stage.mkdir()
source = spoke / 'tmp/model-request-runtime/b1-spec'
shutil.copytree(source, stage / 'author-inputs')
shutil.copyfile(task / 'sl3-review-primary-summary.json', stage / 'primary-summary.json')
shutil.copyfile(Path(__file__), stage / 'archive-sl3-review.py')
shutil.copytree(task / 'sl3-review-inputs', stage / 'archive-attempt-1')
manifest = json.loads((source / 'output-sha256-revision-2.json').read_text())
for name, digest in manifest.items():
    p = root / name
    assert hashlib.sha256(p.read_bytes()).hexdigest() == digest, name
    target = stage / 'reviewed' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(p, target)
observations = json.loads((source / 'input-observations.json').read_text())
old = observations['files']
provenance = []
for name, digest in old.items():
    p = root / name
    value = p.read_bytes()
    origin = 'current-hub'
    if hashlib.sha256(value).hexdigest() != digest:
        value = subprocess.check_output(['git', 'show', observations['baseline_head'] + ':' + name])
        origin = 'author-observed-base-git-bytes'
    assert hashlib.sha256(value).hexdigest() == digest, name
    target = stage / 'upstream-inputs' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(value)
    provenance.append({'path': name, 'origin': origin, 'sha256': digest})
(stage / 'upstream-source-provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
# The executed models/configs are exactly the unchanged reviewed artifacts.
formal = root / 'tmp/model-request-runtime/b1-late-coordination/formal-v3-run-1/inputs'
for name, digest in manifest.items():
    if '/v3/formal/' in name:
        assert hashlib.sha256((formal / name).read_bytes()).hexdigest() == digest, name
inventory = [{'path': str(p.relative_to(stage)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size} for p in sorted(stage.rglob('*')) if p.is_file()]
archive = out / 'session-log-v3-2026-09-27.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    tar.add(stage, arcname='review')
with tarfile.open(archive, 'r:gz') as tar:
    for item in inventory:
        value = tar.extractfile('review/' + item['path']).read()
        assert len(value) == item['bytes'] and hashlib.sha256(value).hexdigest() == item['sha256'], item['path']
index = {'provenance': 'Primary-authored independent-review summary with exact input archives; not reviewer verbatim', 'files': inventory, 'upstreamInputsVerified': len(old), 'reviewedInputsVerified': len(manifest), 'formalArtifactsUnchanged': 21, 'archive': {'path': archive.name, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size}, 'readbackAllInputBytes': True}
(out / 'session-log-v3-2026-09-27.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'files': len(inventory), 'upstreamInputs': len(old), 'archive': index['archive']}))
