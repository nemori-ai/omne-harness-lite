# 主线输入归因（作者摘要，非逐字独立评审）

root已核现有MR4只判固定形状和列明关系，不比较Timing；OE format为注解，旧毫秒parser拒:60，没有已采用闰秒事实表。root要求比较两种公开责任：合法RFC3339时间点为明确前提的纯排序；或unknown完整接收和排序，外部公告事实显式依赖且缺事实不可判。brief unknown→Parsed只是拟议签名，不是已决定完整接收政策。不得加表、网络查询、新时间服务或默认接受／拒绝所有leap；runtime必须兑现真实caller前提，不能仅记局限而给非法批放行。候选提出技术建议，由主线独立评审及采用。

环境另由root执行uv sync --locked，实际exit0、CPython3.12.13、本树.venv；作者不安装依赖。
