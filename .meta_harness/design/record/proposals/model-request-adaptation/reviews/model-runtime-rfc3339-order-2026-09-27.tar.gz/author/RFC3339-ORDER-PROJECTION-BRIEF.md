# W15-T：模型时间关联所需的原core公开比较接缝

root作为model-request-runtime纵线主调度和验收者推进用户已授权实施。D088共享codec正在独立spoke实施，作者发现并正确停止一项具体接缝：现有offer-expiry毫秒Instant不能决定MR4 S17要求的全部合法RFC3339时序。此任务只为原core节点起草窄提供者增补，不扩时间/资产平台，不改产品政策、Clock存储或规范时间域。

## 位置、owner和写面

首先cd `/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-p2-rfc3339-order`，核branch `panqiwei/model-request-runtime-p2-rfc3339-order`、HEAD `d7c44a262654e1237b5134badf25ea10087467b6`、git-common-dir/clean。root独立创建自已通过集成HUB，remote origin/main重新fetch edee5bb7且落后0，主检出未提交未导入。

唯一维护写面：`.meta_harness/design/realization/packages/core/offer-expiry/rfc3339-order-design.md`；其余规范/registry/旧设计/代码/README/record只读。自有tmp/model-request-runtime/p2-rfc3339-order可写输入manifest、author checks/handoff。另有只读explorer只写独立p2-headers-consumer-audit tmp，不碰它。你不是唯一参与者，不回滚他人。无commit/push/接受/产品实现/付费/.env，不自行给协议新政策；root负责方向采用、登记、源码施工和独立验收。

## 已接受性质与真实反例

消费D088的runtime v4-log-codec-design.md rev2 SHA `f537277f2610b2d98169c69d5c71fcbb3e62fd65de3364ae0ff5148603e92c27`完整业务批关联#4；MR4 S17：sentAt≤firstTokenAt≤endedAt，时间点依据data.offer-expiry/v1 S22按时间点语义比较。当前core包采用OE2，v1/v2 Instant定义相同且允许任意长度秒小数。旧提供者设计已采用品牌化毫秒Instant，当前time.ts Math.round；它原先的毫秒公开接口/Clock/expiry义务不是本轮新增构件。

真正root public baseline probe在本tmp counterexample.mjs／counterexample-command.json、baseline.stdout／stderr：2026-09-27T00:00:00.0004Z sent与.0003Z first均得到1790467200000，compare=0；按精确RFC3339顺序应sent>first。原oracle实际wait exit1、指定AssertionError，不是loader，旧source time.ts SHA `478edcc0ab6c9ff395ace2028139cd082845f27c0645c10fc62ac379af384ed2`。这是millis投影无法充当任意合法原字符串比较的具体反例，不改旧数据证明或把所有core阶段判Fail。

权威需读：offer-expiry v1/v2 contract与Schema／registry接受、节点README/design/v2增补/已有边界记录，当前public time/schema入口；MR4 timing定义与S17、D076 runtime输入／Clock用法、D087、D088。原raw时间值与core接收/完整JSON值相等规则独立，不可把舍入同点等同原字符串全值一致。

外部语义只核官方RFC3339 §4.2/4.3/5.6/5.7（https://www.rfc-editor.org/rfc/rfc3339）；标准是已有S22依据，不新增9557扩展时间格式、IANA时区库或钟表服务。root已读RFC正文，后续若查要保全准确出处；产品/系统research不写在设计区外。合法日历、偏移、0000/9999边界、大小写T/Z、-00:00及闰秒必须明确与已有契约／Schema的关系；不得自设精度上限、截断任意小数或暗拒核心合法域。确有规范不可决定的准入问题时，给精确字段/反例/原owner需要的裁定，已明确普通域比较仍可起草。

## 候选与所需投影

至少比较三个实质路径及成本/反向检查：A runtime自持第二时间解析/比较；B 原offer-expiry纯公开RFC3339字符串精确比较入口；C 将全局Instant/Clock/持久表示改为任意精度后传播全部消费者。root的窄倾向是B，必须用性质/owner/真实代价论证，不能用空替代项凑比较。A有共享语义分叉，C影响既有毫秒Clock和大量不相关消费者；不得为了此局部接缝扩成整个时间平台。若发现B无法兑现有效性质，报告root具体原因，不自行选弱化域。

拟议公开签名可为 `compareRfc3339Instants(left:unknown,right:unknown) → Parsed<-1|0|1>`（供review的实现面技术名，不是新data对象）：接收合法RFC3339原字符串，在同一既有core包精确比较，不返回/持久化新Instant、不改payload、不读取clock。非法输入具名invalidInput，返回原因不得回显输入。当前codec只在正式采用+实际helper实现后消费，不调用候选API。

精确小数不转浮点/纳秒固定精度，不按完整原串字典序；同点不同offset/不同fraction词法须判0，真正亚毫秒差异判严格顺序。日期/时区有效性沿有效规范及公共validator，不以Date滚动修正非法日期。年月/offset字段的已定有限域允许合适技术算术，不能因避免Number一词反建数字平台。无需外部IO或全局可变缓存；资源成本按已经输入的词法长度解释，不按未知长度人为截断。

新构件和原instantFromRfc3339／compareInstants的关系须明确：原毫秒表示仍只承接已采用用途，不能在模型合法全域比较支偷用其量化结果；不造clock服务/插件/fiber/存储、无卸载资源。若需共享私有日历接收代码可在implementation plan说明，但旧函数语义/旧公开契约不能无依据改写。双语包README完成源码后必须补真实公开入口、差异和示例。

## 交付与可反驳验收义务

- 本节点同一窄增补：四层状态、精确输入/采用、properties→public function映射、纯导入/Cordis无生命周期、资源/失败/所有权、相关消费者迁移与逆检、至少三候选、remaining门。当前新增bindings0/未实现/未验，不填预期测试证据。
- 明确未来可失败oracle：.0004>.0003非法顺序；任意长小数和尾零数学同点；正负偏移同点/跨日及UTC四位年之外但合法本地四位年；0000/闰年/非法日期/无offset/非法offset；已接受闰秒域及所有前提；原字符串/payload不被规范化写回；public纯输入无clock/IO/env/Cordis。
- 编译负控至少量化回millis与原串lexcompare两类，必须指定行为AssertionError而非工具失败；以后两个独立制品/双语literal实际strict compile/run、新函数数值/资源终态和未变原接口回归。结构检查formal=skip不充实证。
- 当前仅起草候选/精确输入manifest/本树结构和links检查/最小diff/author HANDOFF，停止写入后交root。root另独立architecture/spec review后才技术采用和派实现；你不评/接受自己的稿。

必需约束或接受关系冲突时停依赖工作给root最小问题；禁止用“局限已记录”放行具体已知违反S17的样本。共享codec别的支继续，完整runtime十三操作/G28/30/31/37官方提供与P2～P6范围始终保留。
