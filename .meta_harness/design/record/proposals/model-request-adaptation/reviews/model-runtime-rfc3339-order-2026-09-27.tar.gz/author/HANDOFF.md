# W15-T RFC3339 精确排序候选交接

## 交付与冻结

- Spoke：/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime-p2-rfc3339-order
- branch：panqiwei/model-request-runtime-p2-rfc3339-order
- HEAD：d7c44a262654e1237b5134badf25ea10087467b6
- git common-dir：/data/qiwei/repos/omne-harness-lite/.git；起草前 clean。
- 唯一 maintained 候选：.meta_harness/design/realization/packages/core/offer-expiry/rfc3339-order-design.md，rev1，candidate／未实现／未验／新增bindings0。
- 候选 SHA256：249c68ea3239977131cc44be3d75dbd31474e0659355258c2606833eb2bfaab2
- input-manifest.json：77项，SHA256 a501cf6acf822f9c71adff43b55ed27d9faf76ec115d6e33ad9c8ea112f27a8d；原72项补充前无漂移，initial另存，最终77项检查后再次全部无漂移。
- 原 brief SHA256：a0cc518ffb66ba388b540344b64547670443473ec3a82185abf43d3227242456。
- candidate-rev1.md 与正文逐字相同；candidate-rev1.diff 为新文件精确差分。pre-responsibility-draft 保全整合root责任方向之前的起草字节，不冒称此前已送审。

## 候选建议与边界

比较 A runtime 自持解析器、B 原offer-expiry新增纯公开比较、C 全局Instant/Clock任意精度传播；建议B。比较R1合法时间点前提下排序与R2完整未知值接收＋外部闰秒事实认证；建议R1，Parsed参数unknown不代表公告事实已被核实。root转交方向以作者归因摘要单列root-responsibility-direction.md，不冒称独立review原话或已接受决定。

比较内核按精确UTC分钟／秒／任意长小数位排序，有限整数用Number，未将小数转浮点、millis或固定纳秒。支持合法偏移跨日/UTC年界、合法60与下一分钟不合并；不改原payload或旧millis API。未建立闰秒表、网络查询、时间服务或新的失败枚举。

TL-G1继续需要runtime/回复生产者与实际宿主的真实合法性前提和组合证据；未知历史或外部时间不能只凭helper ok认证合法批，按原S70不可确认保持unavailable。R1条件排序可独立评审，原十三操作/G28/G30/G31/G29实际组合/37模型/P2～P6未被缩减。TO-V1～V9全部待执行；两个行为负控明确为millis量化和原串lexcompare，要求指定AssertionError，不能以loader/编译失败充数。

## 实际检查

- 本树root准备的.venv；作者未安装依赖。check-invocation.json记录实际argv/cwd/sys.executable/sys.prefix、Python3.12.13、jsonschema/yaml来源与本树checker SHA。
- check_design.py --root .meta_harness/design --formal skip：实际exit0；check-design.raw.log末行为PASS，gate=internal、formal=skip。执行handle58451已结束，outer exit0，无进行中作者进程。
- author-checks.json：77输入无漂移、11条local链接存在且不越design、无尾空白、正文无任务tmp引用。
- git diff --no-index --check /dev/null candidate：实际exit1为新文件difference状态，raw输出0字节；git diff --check实际exit0。各argv/exit/raw按文件保全，不谎称no-index为exit0。
- source-references.json：权威条款与实际公开source坐标。catalog-and-baseline-check.json核三份accepted坐标、OE1/OE2 Instant相同、time.ts与主线反例源码SHA一致。
- 官方RFC3339 §4.2/4.3/5.6/5.7在线核对；rfc3339-source.json记录URL/时间/SHA，原文为来源保全，不采用RFC9557。RFC源SHA 9ab2b8864a85dca73a88f49b0927bc7bc85f596926e4fd1890905777924e700a。
- baseline.stdout/stderr及counterexample-command.json是root已运行反例的输入证据，本作者未重跑或将其标为新函数测试。

没有产品实现/测试、IO演练、TLC、付费调用、commit/push/接受；旧spec/design/registry/source/README均未改，另一个headers explorer的tmp未碰。候选已停止写入，交root独立architecture/spec review与采用。
