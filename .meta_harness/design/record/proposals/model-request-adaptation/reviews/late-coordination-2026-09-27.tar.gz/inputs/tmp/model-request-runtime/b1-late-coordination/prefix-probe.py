"""Finite design experiment only: no production log, IO, lifecycle or fairness model."""
import hashlib
import itertools
import json
from pathlib import Path


def explore(guarded: bool):
    histories = []
    for boundary in ("attempt_2", "run_end"):
        # Two response writers contend for the same ResponseId. An unrelated
        # append may change the tail. Reads precede their own write, nothing else.
        actions = ("read_A", "write_A", "read_B", "write_B", "boundary", "unrelated")
        for order in itertools.permutations(actions):
            if any(order.index("read_" + who) > order.index("write_" + who) for who in "AB"):
                continue
            log = []
            snapshots = {}
            conflicts = 0
            response = None
            violations = []
            for action in order:
                if action.startswith("read_"):
                    snapshots[action[-1]] = (len(log), "boundary" in log)
                elif action.startswith("write_"):
                    tail, late = snapshots[action[-1]]
                    if response is not None:
                        continue  # ResponseId competition rejects the whole batch.
                    if guarded and tail != len(log):
                        conflicts += 1
                        continue  # A known conditional failure is zero-write.
                    # Independent oracle: actual committed prefix, not snapshot.
                    required = "boundary" in log
                    if late != required:
                        violations.append({"step": action, "recorded_late": late, "required_late": required})
                    response = {"late": late, "writer": action[-1]}
                    log.append("response_with_message")
                else:
                    log.append(action)
            # Quiescent retry only rebuilds the still-uncommitted batch, never
            # the request or its identity. This is not a fairness proof.
            retry = response is None
            if retry:
                response = {"late": "boundary" in log, "writer": "A"}
                log.append("response_with_message")
            histories.append({"boundary": boundary, "order": order, "conflicts": conflicts,
                              "quiescent_retry": retry, "response_count": log.count("response_with_message"),
                              "violations": violations})
    return histories


def main():
    plain = explore(False)
    guarded = explore(True)
    assert len(plain) == len(guarded) == 360
    assert all(h["response_count"] == 1 for h in guarded)
    bad = [h for h in plain if h["violations"]]
    assert bad, "the unguarded negative control must violate actual-prefix late"
    assert not any(h["violations"] for h in guarded)
    report = {"status": "finite_design_experiment", "scope": "6 actions, 2 writers, 1 ResponseId, 2 boundary forms",
              "paid_requests": 0, "production_io": False, "formal_tool_run": False,
              "input_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "unguarded": {"histories": len(plain), "violations": len(bad), "examples": bad[:4]},
              "tail_condition": {"histories": len(guarded), "violations": 0,
                                 "conflicts": sum(h["conflicts"] for h in guarded),
                                 "quiescent_retries": sum(h["quiescent_retry"] for h in guarded)},
              "not_modeled": ["unavailable_or_unknown_ack", "real_run_end_recognition", "same_batch_run_end",
                              "authorization", "old_writer_stop", "crash_reopen", "unbounded_contention", "HTTP_send"]}
    target = Path(__file__).with_name("prefix-probe-result.json")
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"histories_per_mode": len(plain), "plain_violations": len(bad),
                      "conditional_violations": 0, "result": str(target)}))


if __name__ == "__main__":
    main()
