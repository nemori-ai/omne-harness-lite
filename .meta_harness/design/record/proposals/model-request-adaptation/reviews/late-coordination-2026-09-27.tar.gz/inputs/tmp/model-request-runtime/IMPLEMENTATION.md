# Model request runtime 交付计划

revision 6 · 2026-09-27 · 本次同步远程已提交产品/适用范围变更，增加条件阶段 PU；原纵线实施尚未完成。

执行工作树：`/data/qiwei/repos/omne-harness-lite/.worktrees/model-request-runtime`；分支 `panqiwei/model-request-runtime`；初始基线 `d4eaf7673bc161bf22f6682385151e080d3323ae`。已保全本地工作至 `6d0affe4`，仅 merge 重新 fetch 的 `origin/main@2844a95d12bfb347a5b7e677a18ad6d53aa8a108`，hub 同步点 `d87f2df9c5cfcae82e5367c5521b360ba8d79d99`；主检出未提交内容不带入。主线负责源码、共享边界及真实组合；独立 reviewer 只读评审，独立验收不由实施者自签。

计划及实时进度仅归本任务 `tmp/`；行为权威归 `.meta_harness/design/`。本修订输入见 [PLAN-INPUTS-rev6.json](PLAN-INPUTS-rev6.json)，原 revision5 的 [PLAN-INPUTS.json](PLAN-INPUTS.json)和评审哈希保留。同步及影响详见 [IMPACT.md](origin-main-update-2844/IMPACT.md)，实际进度与失败见 [STATUS.md](STATUS.md)，前一稿已按内容哈希保留于 [plan-history](plan-history/)。决定正文的历史编号冲突按 D-078 的行政接续处理，不能取同名的新决定替换旧采用。

## 0. 实施以已接受 spec 与 realization 为准

用户在本轮进一步明确：实现必须遵循已经完成设计的 realization 和 spec，不得完全自由发挥；只有在明确设计规格的基础上，具体实现手段、技术选项和第三方依赖可以稍微灵活。

这是一条实施硬约束：

1. **spec 约束身份、不变量、接口、结果/失败、顺序和状态转移；已接受 realization 约束提供者分解、公开构件/服务投影、Cordis 注册/依赖/作用域、存储所有权、共同提交对象及装卸/停止方式。**两者都必须遵循。只满足 spec 的结果而另造一套提供者架构，或只按 realization 接线而遗漏 spec 性质，均不能放行。
2. 正式施工前，每个产物列明本次采用的精确契约/realization 路径、修订/哈希、实施范围和对应验收义务。源码/制品交接要有“条款/投影→具体落点→实际验证”对照；文件存在、编译通过或接口名字相同不表示遵循设计。
3. 本计划只安排施工边界和先后顺序，**不能改写或裁剪已接受设计的对外承诺**。第3节限定的是本轮实际消费者和工作范围，不授权自行删操作、改变服务/插件接口、另设状态/错误、把未实现操作返回成功或默认 unavailable。提供者的完整承诺若仍未实现，就明确未完成；被消费的技术窄投影须有已接受依据。
4. 只有设计未规定且不影响既定性质/边界的内部实现细节可以由实施者选择，例如局部函数组织、辅助算法或工具库。必须满足工作区约定、相应验证和来源/许可要求。**设计已明确的技术采用不是自由选项**：官方 Cordis 4.0.4、pi 0.86.1 定向 fork、OpenRouter 统一出口、实际 SQL/JSONL 的所有权/耐久安排等，不得凭偏好更换。
5. 发现实现需要超出现有设计，先定位缺口和受影响消费者，回相应 `.meta_harness/` spec/realization owner 补设计，按对象独立评审并精确采用，然后实施依赖部分。不能先自由实现后补一份文档追认；不能以“内部细节”“替换库”掩盖语义/结构/生命周期变化。无关的已确定实现可以继续。
6. spec 与 realization、旧规范消费者与新 provider 出现冲突时，不静默选择便利说法；报告精确版本与反例，暂停该依赖接线并走已有演进/传播流程。用户本轮的新约束优先于旧施工计划中的宽泛表述，但不会自动接受尚未完成的设计。

上述约束保持。revision6 的远程增量没有修改已接受版本资源、Schema或冻结投影；不会仅因适用范围提示就判既有实现违约。用户授权本次产品稿正式化，但产品接受不自动接受技术新接口。PU 只在新工作区语义需要实际消费时执行，不阻断未受影响的主线；不改已冻结规格或以计划代替设计采用。

## 1. 交付目标和完成定义

这条纵线交付可独立调用、可由 Cordis 消费、可持久恢复的模型请求能力，所有真实模型请求经 OpenRouter。一次完整请求能从实际租户/模型选择及当前设置，经过精确适配规划、真实凭据、网络与流读取，到耐久响应、重试判定、资源停止和诊断；独立函数消费同一生产构件。

| 编号 | 必须交出的结果                                                                               | 完成证据                                                                                                          |
| ---- | -------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| D1   | 公开 `plan/send/read` 与 `invokeModel`；无需会话、数据库或 Cordis 即可独立调用               | 外部制品消费者编译/运行，受控 HTTPS 抓线，真实 OpenRouter 代表调用；服务与 public 路径使用同一规划/发送实现       |
| D2   | 公共传输/家族实现＋37 个人工维护的模型窄定义，准确映射提醒、参数、工具、推理、声明模态及缓存 | 明确的逐模型/固定 route 配置，T/SC 全门和适用逐模型 G 门；完整 binding 可认回，不由厂商名前缀自动猜策略           |
| D3   | model runtime v3 全部十三操作、耐久内容门、取消、结算、续接及恢复                            | 真实日志/SQL、并发及 kill/reopen；逐操作、逐状态/失败验收；未知提交保持隔离，不误发、不误结算                     |
| D4   | 官方贡献热更新/撤除与组织、租户声明式自定义 profile                                          | 新调用采用新 binding，旧调用固定原 lease；实际停止/排空；可信实现引用、配置历史、租户隔离、凭据轮换及认证失效传播 |
| D5   | before/after model及before_persist_message经过、默认可替换重试件与模态投影/必要转换          | 真实 runner `dispatch/replay`、完整失败主体、守卫/耐久结论/等待后复核；拒绝非法能力和不支持输入                   |
| D6   | 全路径日志/trace/metrics/独立退化查询与可重跑验收装配                                        | A-V0～A-V14，owner-only 真实权限负控、秘密扫描、sink 故障不改业务 outcome、计时/资源测量                          |
| D7   | 八家37模型在 public/service 两条生产路径的认证结果                                           | 每个完整认证对象的全部适用 G 项及原始费用/缓存/线协议证据；研究暖读不能补生产 pass                                |

总体验收完成要求 D1～D7 全部闭合且没有必经 fail/blocked、未决费用或未停止资源。实现、组件检查、代表组合、逐模型认证、独立验收和用户总体签收分别记状态；任何一个状态都不代替其余状态。

## 2. 明确不交付的内容

- 不建设完整 Agent Loop、工具执行 runtime、命令识别/派发、CLI/TUI、等待卡片及产品会话生命周期；工具协议的模型发送/解析/结果回传属于 D2，实际执行工具属于另一条纵线。
- 不交付完整资产治理、通用注册表七操作全功能、所有 plugin 成员治理、完整工作区/中心Git/同步/关系管理产品、资产分享和 MCP endpoint 探测。新版工作区来源仅在 PU 的模型消费者范围内、沿先采用后实施的条件接入；没有真实权威读面时保持 unavailable，不以删 scope 或自称授权让失败配方成功。
- 不交付完整凭据六操作服务、OAuth 用户流、中心同步/送达、任意租户代码执行沙箱及音视频能力；本地模型凭据组件按 D-075 的来源绑定范围实施。
- 不自动开放 OpenRouter 全目录，不追加第38个模型，不按“最新”滚动更换已确认 modelId。新增模型、route 或能力定义需要单独调优/认证。
- 不增加必选 LLM 抽象基类，不将目录名视为插件/进程/表边界；不迁移到 `packages/llm/`，不为这条纵线搬迁共享包。
- 本轮远程同步与计划更新本身不重做资产产品源码；未受影响主线继续按已接受设计施工、不发付费请求、不推送或发布。已有未完成通用代码和失败证据保留，不标成完成，也不把它们补全设为模型传输的前置。

本节只划本次交付范围，不撤销已接受契约。不涉及的能力有明确未交付状态；一旦模型请求的有效行为实际依赖它，就按第3节最小操作范围处理，不能用“延期”绕过必需性质。

## 3. 包归属和每项依赖的操作范围

### 3.1 这条纵线直接拥有的产物

| 位置                                     | 本轮职责                                                                                                                                                                                                  | 禁止扩展                                                                |
| ---------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------- |
| `packages/model/pi-ai-transport`         | OpenRouter 唯一发送出口、公开规划/流读取、家族策略、37窄定义、精确注册/lease；pi 0.86.1 定向 fork 的来源/许可                                                                                             | 不复制上游全模型目录，不加第二出口/隐式重试/环境凭据/TTL 回退           |
| `packages/model/model-request-runtime`   | 同一 public invoke、十三服务操作、状态/内容门/结算/恢复、默认重试贡献和运行诊断                                                                                                                           | 不接管 Agent Loop 或工具执行，不复制适配/SSE策略                        |
| `packages/model/model-profile-directory` | 十操作：registerProfile、withdrawProfile、relistProfile、updateProfile、loadManifest、bindCredential、unbindCredential、readProfile、listProfiles、resolveCredential；组织/租户声明式档案和不可变配置历史 | 不让租户提交任意可执行 adapter，不做中心/OAuth/全凭据产品               |
| `packages/model/modality-projection`     | 已接受纯判定/公开转换、可信转换件登记和 model 路径所需系统贡献                                                                                                                                            | 不发明附件字节源，不用空字节替代未接通来源；不借故障缩小已提供模型能力  |
| `apps/model-request-acceptance`          | 已接受独立于 Agent Loop 的真实装配、场景、唯一费用门、owner-only 机器证据和诊断查询/导出                                                                                                                  | 不做第二 runtime，不由 app 自造失败主体/权限/恢复事实，不冒称独立测试者 |

模型定义和家族策略放在已接受 transport 节点的实现范围；官方模型贡献可作为生命周期插件挂载，共享 transport 持稳定出口。按生命周期/权责划插件，不先机械建37个包。运行时保存精确 implementation/definition/configuration；第三方声明式档案只能引用可信已注册实现，外部贡献代码装载归系统/组织可信部署边界。

### 3.2 共享依赖只补本轮真实消费者需要的行为

表内操作名是施工调用范围，精确参数/失败/顺序以输入契约为准。既有完整实现可直接复用；本轮不把依赖的全部产品范围展开成另一条交付。

| 依赖/源码归属                                                                                  | 本轮必须实施或复用的实际操作/读面                                                                                                                                                                                                                                                                                                         | 消费者及最晚放行点                                        | 延期/边界                                                                                                                                                      |
| ---------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `packages/core` 中 profile3/messages4/response4、AD1/AE4/LC4、stream assembly 及现有 JSON/身份 | 无损读取/判定、AE4 evaluate、当前根选择、LC4 完整模型失败主体/效果判定、真实片段组装；保留已采用旧公开坐标                                                                                                                                                                                                                                | transport/public P1；source/model/runner P3～P5           | 已有组件通过可复用；不以镜像测试重复攒数量，不新建纯包装层                                                                                                     |
| `packages/assets/evaluation-input-store`                                                       | 实际 trusted publication/capture、`currentEvaluationInputs.read`；已采用 restricted fixed-root 和 `registry-history` 读取/close；STT→MF实际元组→当前OG资格→原不可变正文                                                                                                                                                                   | runtime 当前设置/资格 P3；AR历史链 P3/P5                  | 不增通用任意历史读取权；此处保持当前资格和原捕获 standing 分离                                                                                                 |
| `packages/session/session-tenancy-table`                                                       | `holdingTenant` 真实不可变归属；验收 bootstrap 的唯一受限种子入口                                                                                                                                                                                                                                                                         | P3 服务请求、历史/凭据/诊断所有跨租户边界                 | 不建设产品会话创建；只在真实 ACTIVE/confirm 后 seed，不能从传入tenant推归属                                                                                    |
| `packages/assets/assembly-manifest-store`                                                      | 六操作 readHead/append/readHistory/dependencyPresence/readEvaluation/readGiven；实际 SQL CAS、E/排列/目标表共同提交                                                                                                                                                                                                                       | AR完整 fill/报告/历史 P3，runner P5                       | 已有实现复用；不把 SQL 和 JSONL 包成一个“共同提交”                                                                                                             |
| `packages/tools/asset-registry`                                                                | **fill**：真实求值来源和六表整批共同提交；**lookup/list**：model工具定义、loop_extension链及已固定表/报告的原版本正文；**refreshAvailability**：真实会话/run/attempt 报告、实际工具依赖及适用权限，no-MCP路径也要真正计算                                                                                                                 | 初次 runtime 工具/扩展输入 P3/P4；完整失败/历史恢复 P5    | 不要求先把全部七操作做完；不提供假完整服务，不声称AR4全部通过                                                                                                  |
| 同一 AR 节点的模型相关变更                                                                     | **reload(tool/loop_extension)**：确为本轮模型输入/链更新所需的重填；按 AR4 S-51/52 认回完整 fill、固定根和原 E/O，真实 expectedHead冲突重读；**工具权限/扩展干预力不交onAssetChange**：按AR4 S-20工具动作空间不因执行权限变化改变，实际报告提供权限/可用性依据、放行阶段判执行权限，runner派发判实际power；当前资格失效仍经真实source拒绝 | P5 工具/链更新、当前权限/power判定和旧报告恢复            | 一般slash/skill/plugin成员的reload、slash的onAssetChange与通用事件分发延期；仅“设置改了无需reload”不需要做通用reload产品                                       |
| 同一 AR 节点明确延期                                                                           | markFailed 的命令服务报错链；onAssetChange（按AR4 S-28仅slash_command，不改变其余五表）、slash命令识别/派发与 reload-plugin 全成员治理                                                                                                                                                                                                    | 无本轮消费者，不排在P1～P6关键路径                        | AR服务若按现有绑定必须暴露完整面，P0/P3先确认可采用的受限技术投影；未采用前受影响接线blocked，不能造假服务或自行缩减既有公开面；完整通用服务交付仍不成为P1前置 |
| `packages/session/session-log-jsonl`                                                           | 全部三操作 append/readByKey/readSince；批原子、durable ack、tenant fence、attempt fence、ResponseId/MessageId判重，关准入/真实排空/锁交接/恢复尾                                                                                                                                                                                          | P4服务首内容/响应，P5 kill/reopen                         | messages4/response4载荷及runtime3 L要求的提供者传播先闭合；不加产品会话归档/分页                                                                               |
| `packages/session/run-attempt-facts-derived`                                                   | accepted公共读取投影，按同次真实日志 read 派生run/attempt；验收终结识别器仅识别自己真实append的载荷                                                                                                                                                                                                                                       | runtime/runner fence和reconcile P4/P5                     | 不提供恒真 canDispatchAgain 或内存“运行结束”标志，不冒称完整产品终结记录                                                                                       |
| `packages/infra/credential-custodian-local`                                                    | D-075 model-only store/read/has及sourceRef绑定投影；实际预置32字节0600钥、加密副本、同一真实AtomicStorage中的目录binding reader                                                                                                                                                                                                           | P3真实目录/凭据，P4每次send                               | 不provide假完整credentialCustodian；不自动生成/换钥，不用MCP假依赖                                                                                             |
| `packages/agent-loop/loop-extension-runner`                                                    | `dispatch/replay` 的 before_model_call/after_model_call/**before_persist_message**、固定原链/声明/allowed/power、实际model/user/reminder消息的经过、真实失败/否决结论与提醒一层注入/判重/replay、默认重试身份和实际canDispatchAgain；转换件恒末位、模型回复不得被租户件任意改原文                                                         | 最小真实model链/消息落盘 P3/P4，完整模型失败/否决/回放 P5 | action/tool/card路径延期且明确拒绝/不可用；模型链所需系统自带守卫仍不得关闭或恒真                                                                              |
| 既有account/login/organization-governance、SQLite/clock/kernel                                 | 实际登录/current membership参与、当前许可与EIS同unit；SQL公共事务；实际时刻/替换等待策略；真实Cordis生命周期                                                                                                                                                                                                                              | P3/P4实际租户请求；P1组件lease                            | 不交付完整tenancy/治理纵线；不读其私表，不跨两个storage实例冒称同unit                                                                                          |
| app拥有的观测与费用构件                                                                        | owner-only诊断JSONL/query/export/metrics、双限队列、独立退化状态；单ledger排他reservation/settlement                                                                                                                                                                                                                                      | P1付费前预算/安全输出门；P3应用入口；P5/P6全链路          | 不造通用可观测平台或租户网络诊断API；恢复只读会话日志                                                                                                          |

每个新增共享依赖工作必须填写“哪个model消费者、精确操作/条款、缺失反例、实际产物、验收门、责任/影响”；没有model消费者的工作移入延期清单。既有依赖测试失败先判断是否影响上述必要行为；不自动启动该子系统完整交付。

## 4. 精确输入和尚须处理的传播任务

[PLAN-INPUTS-rev6.json](PLAN-INPUTS-rev6.json) 锁定所列当前规划输入；旧 PLAN-INPUTS.json 只用于历史比较。契约接受以 catalog/frozen 和对应精确 adoption 为准；历史设计正文仍写 candidate/未建包时，按已发生的采用记录读层次，不以措辞覆盖接受/实际状态。

- runtime3/runner3、transport/runtime/runner/app节点按 [D-076](../../.meta_harness/design/record/decisions/model-runtime-delivery-adoption/acceptance.json)；directory/model-only来源按 [D-075](../../.meta_harness/design/record/decisions/model-credential-source-projection/adoption.json)。
- 本轮MF4/AR4及MF4投影按 [D-079](../../.meta_harness/design/record/decisions/model-original-fill-adoption/acceptance.json)；AR4/EIS历史投影按 [D-080](../../.meta_harness/design/record/decisions/model-registry-history-provider-adoption/adoption.json)。readGiven/历史正文是已接受义务，不因组件通过变成已组合。
- runtime3/runner/app原规范依赖仍精确引用MF3/AR3，不能自动替换成recommended v4。P0/P3产出旧消费者所用条款→v4未变语义/具体提供者的对照、采用范围及真实公共绑定证据；若涉及语义变化，发布新消费者版本并独立评审。该任务只阻断受影响服务接线，不阻断独立transport。
- **B1 日志传播**：P3先核SL2载荷原样/无损公开面与messages4、response4、runtime3的L-1～L-7/runner RL要求，更新必要realization/采用和消费者互指后才在P4写真实新载荷；不改冻结SL2来迁就实现。
- **B2 AR范围投影**：P0明确盘点任务；P3施工前盘点本轮runtime/runner实际调用；P3接线前形成accepted依赖面与第3节scope对应。先核已接受realization是否允许所需消费投影，不能仅按本计划自行裁剪服务。若受限公开构件/技术投影尚未获采用，先补该节点必要realization、独立评审和精确采用，再施工依赖接线；若确须契约变化则发布新版本并传播，不新增无依据领域操作或写假全量service来满足类型。
- **B3 模态投影/版本传播/来源**：P2冻结已确认offer的适用能力；P3/P5核modality已采用节点的精确CB2/MS2/MP2/LC2/runner2依赖与本轮CB3/messages4/profile3/LC4/runner3消费关系，不自动升级、丢字段或绕过旧规范。产出逐条版本/公开读面→当前consumer→技术采用/实际制品证据对照；需要新的realization或契约修订先设计、独立评审、采用再施工。具体产物还包括modality节点MP-N6的消息调用者/同次落盘投影（接已采用app A-8职责），以及MP-N7公开转换函数行为的必要设计采用；不能把candidate函数名直接当作已经明确的公开承诺。before_persist_message系统转换件的能力标识、恒末位注册/声明和真实输入来源须有采用依据，不由实现者自由命名。引用附件缺真实字节时阻断对应输入/模型认证，不能把失败临时改成not_applicable。该任务同时阻断受影响的runner消息经过，不能只留作末尾模态测试。
- **B4 形式证据**：引用已有适用的lifecycle/binding/content gate和runner S-35有限正/负工件，按精确输入/常量/范围核对。主线执行，独立reviewer检查结果对应；新输入改变相关性质才重跑。未知opened回执和真实IO由P5实际验收，不声称旧有限模型已证明。

- **B5 系统自带件身份/必需model投影**：runner3 G-3/S-17明示循环探测规范身份尚未定义。本轮after_model_call{complete_reply}等消费其必需记录/守卫的场景，先由既有owner明确规范身份及必要model投影，补对应spec/realization并独立评审/精确采用后才接线；主线负责落实输入和真实实现/场景。未闭合时仅受影响经过blocked，不能自由命名、登记恒真探测、默认为不存在或忽略系统守卫。此任务不授权交付完整循环探测/AgentLoop，独立P1不受阻。

B1～B5均有主线生产/传播责任，独立角色按对象审阅。需要设计补充时只进入受影响 `.meta_harness/` owner；它们不能成为顺便重做整个依赖的授权。其完成状态在STATUS与机器门表记录，不在本计划假填已通过。

## 5. 分阶段实施和放行条件

以下P编号是本次施工增量；应用现有S0～S8仍是原验收分组。P不重命名任何规范场景；第6节列出对应，以免组件门提前变成全应用门。阶段以可见结果结束，不按包数/测试数计算进度；不用尚未核实的日历估时承诺完成日期。

### P0 计划范围和输入冻结（当前这一轮）

输入：用户最新边界要求、现有采用/源码/失败、唯一ledger。输出：对应计划修订、输入哈希、独立计划评审、STATUS、逐依赖操作范围与B1～B5任务。revision5 的这一步已完成；revision6 追加远程同步与条件 PU 的评审，不追溯改写旧评审结论。

主线维护本任务区；reviewer只读。验收包含第0节的spec/realization实施硬约束及B2窄投影的先设计/评审/采用后施工顺序。验收：计划每项D都能定位实施者、真实输入/产物、阶段、原验收编号和失败接续；P1不存在“必须先完成通用注册表七操作”的依赖；无降级既定37模型、安全或恢复义务。阻断发现修正并复审。原 P0 暂停已由用户后续“继续推进”授权解除，P1/P2 已有实际增量；新缺口仅停依赖部分。

### P1 首个可独立运行的生产模型请求

P1.1先实现transport公开构件和同一`invokeModel`，使用现成pure core；首批窄定义选已确认OpenAI一项与Anthropic一项，分别覆盖developer/automatic和user/explicit。route、TTL/断点从真实确认配置提供，不临时猜值。消费pi0.86.1定向fork来源、许可和D-019比较边界。

输出：可从仓库外消费的制品及开发场景入口；不需DB/session/租户种子。plan不开网，send为唯一出口，read走生产parser，非法绑定/输入零HTTP，精确无损规划在plan后输入变更时不漂移；真实HTTPS任意切分、协议/带内错误、首内容前后取消/断流及socket/reader/callback全部实际结束。

P1.2在受控环境通过适用T/SC子项、来源核对、费用保护器A-V10的并发/崩溃负控及owner-only输出后，用**同一生产制品**运行两项OpenRouter public代表请求。development consumer临时入口只归本任务脚本/开发工具；`apps/`不提前建一个声称启动就绪的空壳。付费不依赖完整app bootstrap，但预算/输出等此路径适用条件必须满足；以后复用同一预算构件。

放行结果M1：能重跑一条真实public调用，保存实际body/route/流/usage/generation/ledger/outcome和实际停止事实，另一项证明显式缓存配置路径。失败保留；缓存未命中/缺事实不算已验证缓存；两项成功不代表37模型认证，也不代表runtime耐久门通过。

### P2 完整37窄定义与生产生命周期构件

输入：P1的同一传输/计划/parser已实跑；适用版本模型/原型证据。

输出：固定37清单及逐模型定义/route/能力/configuration schema、家族共用实现、参数和reminder策略；actual Cordis贡献注册/adopt/retire，runtime/direct lease固定完整旧binding，空闲再acquire、反复release、旧清理不删新版、超时remaining_active及强制取消实际结束。完成T-1～T-20/SC-1～SC-3的组件部分及外部打包消费者。

放行：未知modelId/revision/config/必需TTL缺席均零HTTP；共享构件只有M1真实代表成立后才推广到其余定义。其余35项只先就绪、离线核对，生产认证留P6；逐模型能力必须在付费矩阵前冻结，不能试失败后改offer。本阶段不得因目录/AR待实现而阻塞纯transport。模型插件数量/包数量不作为完成条件。

### PU 条件阶段：新版工作区资产传播与实现更新

触发：相关新版 spec／realization 正式接续，或本纵线开始提供 PF-020／PF-002 的新版工作区输入。本次远程只有适用范围提醒，**当前未触发立即源码迁移**。PU 可与独立 P1/P2、B1 和无工作区的既有租户源链并行准备；仅对应工作区消费者的 P3/P4/P5 放行必须等它完成，不把完整工作区产品变成模型纵线前置。

目标：已做或正在做的资产相关 core、EIS/MF/AR 及 model 服务消费，按新的精确已接受输入及投影工作，保持原冻结坐标与历史的明确解释。实际影响沿 [IMPACT.md](origin-main-update-2844/IMPACT.md)，包括根入口 AE4／AR4 的继承前提，不能只改旧 AE3。

本批产品输入新增已定边界：登记外部仓库不设 Omne 治理所有者、所有接入租户均为参与者，首登不获治理特权。组织限制启用时，在既定装配时点不给外部仓库工作区身份、不加载其来源；仍允许按普通目录沿既有工具与底层权限使用，不能承诺文件系统禁止，也不删除全局身份／关系或热重判已运行会话。PU 的新规范／权威读面必须表达此边界；主线独立无工作区模型路径不因此受阻。

分层释放：PU.1 的精确设计与采用完成后，释放相应工作区构件施工；PU.2／3 用真实来源完成后可进入工作区模型组合施工。PU.4 的全部端到端验收是该工作区支持范围的最终放行门，不是所有 P3 施工前置。未受影响的无工作区 P3～P5 可先施工和验收。

| 子增量 | 输入与必要产物 | 责任及释放条件 |
| --- | --- | --- |
| PU.0 精确基线 | 固定远程提交及新产品正式范围；旧新消费者矩阵、冻结输入、已实现证据适用性 | 主线只做范围/状态核对；没有新接受技术版本时维持现行采用，不自行改键/Schema/默认值 |
| PU.1 必要设计接续 | 对应 owner 明确工作区身份/实例/关系事实读面（含外部仓库无 Omne 治理所有者、各租户仅参与者），加载快照与双来源候选/设置/兼容启用的表示；IV/AM/AE及必要HI的新版本、Schema/规范场景/形式义务；core/EIS/MF/AR/model 的精确消费者投影和存储/历史/迁移责任 | 主线按 handbook 协调并按缺口限定；architecture-reviewer 审选择，spec-reviewer 审表达，精确采用后释放依赖施工。版本号/新package/接口不由计划预定 |
| PU.2 core 与真实输入 | 按已采用投影实施 AM/AE 必要公开形状、来源择取/求值、IV 工作区条款传播；核对 AD/LC/Skill 精确依赖；工作区权威读面及 EIS 加载/当前资格/原配方 | 主线或明确分配源码 owner；使用真实目录观察与已采用权限提供者，不把 tenant 参数、路径或普通目录当授权。Skill 包格式与账号/组织接口不因 PR 自动重做 |
| PU.3 持久历史及消费者 | 必要 MF DTO/来源证明/迁移、AR 模型相关 fill/reload/refreshAvailability/lookup/list，EIS 原工作区正文读面；模型工具、当前模型设置、reminder/retry 的已有服务入口传播 | 同一 owner 负责真实组合，不能只交各包绿测。旧记录无确定身份映射时不猜路径迁移；旧 report 回原正文或明确 unavailable，不能回当前文件 |
| PU.4 验收与接续 | 下列场景、受影响制品/README及“条款→实现→证据”表；外部资产消费者影响交其 owner | 独立验证者复核真实组合；未实现/未测/缺权威分别 fail/blocked，限定前提的旧证据保留，不追溯换坐标 |

本阶段只补本纵线实际消费的资产能力和必要公共纯值承诺；不借机交付中心 Git、完整工作区治理/关系命令、同步引擎、CLI/TUI、MCP/hook 执行或通用 AR 七操作产品。新增读入提供者及权威关系事实必须先有正式归属；缺席时仅受影响工作区场景 blocked。文件系统 OS 可读不是工作区关系授权。

验收目标在新规范采用后按精确条款执行，以下编号是本任务关口，不是新领域契约：

1. **PU-V1 身份与隔离**：两租户共用工作区/实例仍分别求值，无对方私有资产/配值/凭据；多实例及地址变更依新身份规则；关系解除后新附着不从残留目录激活来源。组织参与限制仅按产品已定的装配时点，不暗增运行期热重判。
2. **PU-V2 实际读入**：真实 `.omne`/`.omne.local`，无配置正常、坏配置阻止装配；默认目录发现、登记扩展路径、链接排除。通配符/重复识别/稳定排序/来源版本等先由新规范明确，不在脚本猜默认。
3. **PU-V3 选择与权限**：可用候选并集及 local 同能力优先；仅设置覆盖、显式 false、未配继承、完整实现替换分开；权限/落点身份/治理例外继续过滤，上层锁不被 local 绕过。兼容开关、租户逐件启用和执行权限分开；命令启用未提供时不冒称已支持。
4. **PU-V4 生效与历史**：真实文件/Git 内容变更不自动更新下次尝试/请求；显式 reload 才读取目标类。坏候选/CAS/提交失败旧表不变；旧报告历史正文、full-fill 固定根及 C16 因果一致。使用实际 `refreshAvailability`，不编造 attemptFill API。
5. **PU-V5 真实模型消费**：实际 OG/STT/EIS/MF/AR→选中 root/设置/tools/extension→模型入口；权限/当前源/依赖失败零 HTTP。提醒角色仍由同一 transport 映射；retry 保持真实 runner/power/守卫及再次 S-66 读取，旧调用 binding 固定。不可用性变化本身不自造提醒。
6. **PU-V6 迁移与交付**：实际旧事实重开/新事实写入、禁止当前文件冒充旧版本、秘密扫描及被编辑包双语 README/制品公开消费；新回归与原 AR fixture 21 失败、继承 tenancy 失败分别认回。

放行：PU.1 精确采用和所有实际受影响的 PU-V 项完成后，才声明新工作区路径可用；现有无工作区模型路径和 P1/P2 不等它。每个编辑包完成时即时补 README.md／README_ZH.md 的公开能力和重要操作示例，不延期到总收尾。

### P3 真实服务所需最小依赖和装配准备

按P3.1→P3.2推进，B1～B5先按实际消费定位/采用；只有实际消费新版工作区来源的部分增列 PU 前置，其余沿既有接受设计继续。不同稳定接口的离线工作无需等全部完成，但共享文件由主线单写或明确分配唯一 owner。

- **P3.1**：目录十操作和model-only凭据真链、预置钥/同unit绑定，实际账号/当前资格/STT/EIS，B1日志projection及真实三操作，derived事实、B2受限AR投影；沿第3节完成full fill/工具和loop lookup/list/attempt报告及B3精确版本/系统转换贡献输入，接真实MF及EIS原版本读。禁止以fake授权、DTO原E、未持有资产一律unavailable掩盖缺失成功链。
- **P3.2**：接before_model_call/after_model_call/before_persist_message三个本轮必要runner位置、模态判定/声明/恒末位系统转换贡献、runtime/public服务host与诊断/费用资源；app中实际消息调用方负责producer/manifest/环境/锚的完整输入、经过结果及同批消息/响应append。所用系统守卫保持真实，B5必需身份/投影未采用时受影响complete_reply等经过不放行；tool/card执行依赖缺席按明确分支拒绝，不造恒真工具入场。只有所有本阶段required providers及已采用前提就绪才建正式app源码和阶段入口。

输出：可重跑、无付费的真实bootstrap及至少一条实际tenant/profile/credential/current settings→工具/扩展输入→日志尝试的完整准备链。逐步守序：预检→构造/迁移保护→本阶段所有required fibers ACTIVE→guard.confirm/移除快照→真实登录/当前租户→受限seed/真实publication→目录/ref-body绑定→真实求值/full fill→真实run/attempt→runtime.selectModel。

放行：A-V0、A-V2/3/4基础组合、费用门和本机输出权限门通过；before-confirm任何失败都零seed/出版/HTTP，after-confirm事实不回滚；跨租户/错sourceRef/旧body与新ref组合拒绝；源/权限/时限缺失零HTTP。required provider列表来自该阶段实际依赖，不为绕过未实现项随意下调。

### P4 首条真实租户服务调用，然后完成runtime十三操作

P4.1消费P1/P2生产构件和P3真实准备链，完成call→plan→durable dispatched→send→durable opened→可见内容→真实before_persist_message经过→AssistantMessage＋response同批→settle/资源回收。实际app调用方依runtime3 S-17与modality2 S-20/23处理：通过后把派生表示及原消息与response一起append；转换失败/否决整条不落、不造替身，vetoed/consumed交settleReply；结论与注入提醒沿runner原规则耐久。user/model/reminder普通消息实际落盘都经过该位置，声明允许的字段才可rewrite，转换全有或全无。以P1同一代表模型跑Cordis/service生产请求，保存public/service规划/线协议/锚点/结果/费用对应；不得另造一套service发送实现。

放行结果M2：真实租户路径首次完整可运行。只证明已执行的场景；未覆盖失败/续接/恢复仍不声明runtime完成。未经相称真实代表组合的耐久/lease机制不复制到更多分支。

P4.2补全所有十三操作：`legalTargets/displayList/effectiveModel/selectModel/openCall/dispatch/dispatchAgain/interrupt/releaseCall/reconcile/readAttempts/settleReply/canDispatchAgain`；覆盖resume规划拒绝、缺凭据、当前时限更新、固定profile/params/adaptation、first-content gate、post-content不可重试、reply_pending双方结算及late规则。取消必须实际停socket/read/callback；资源释放事实不以signal.aborted代替。

放行：A-V5的完整耐久规划/门/结算和A-V7当前已实现的运行取消部分成立；每次重新取实际设置/凭据、所有零发送分支有实际网络计数。普通门失败与opened未知必须区分，未知先隔离且保持未结算；P5完成恢复前，不能发布“runtime全面验收通过”。

### P5 恢复、重试、热更新/自定义与完整观测

输入：M2及P4十三操作，精确formal证据/B1～B5、真实历史producer。工作按实际场景闭合，而非把每个共享service补成全产品：

1. 在call/dispatched/opened/response/runner结论/提醒提交前后kill/reopen；真实旧写者停止/owner交接/有效attempt fence→权威完整日志重开读→reconcile，零网络。opened回执未知不得ordinary settle/retry/隐去尾；无旧实现仍可恢复历史，显式续接拿不到原lease才拒绝。
2. 完整before/after model与before_persist_message链、默认retry和替换件；真实声明/allowed/power/失败主体、canDispatchAgain、结论耐久、等待plan.after后再复核。实际回复persisted/vetoed/consumed、模型回复否决后的提醒、一层inject、同ID异正文/不同tenant锚、转换产出与消息/response同批及失败整条不落均需实测；回放不重执行作者/转换/提醒副作用。工具执行权限按放行位置处理，本轮报告含真实依据但不执行工具、不据权限收回偷偷删模型工具表。
3. 模型相关reload、当前资格/实际power和权限报告、S-51/52固定H认回完整fill；实际AR原表/attempt报告→MF→EIS旧不可变正文，当前换版或不再持有仍能按已核历史用途成功读取原版本；跨session/run/attempt拒绝。full六类reload后的readGiven认回是原记录来源性质的验收，不等同于交付六类命令产品。
4. 官方插件/transport/runtime host撤除与依赖换代、旧调用/新调用交错；组织/租户custom范围、trusted实现引用、配置同rev异值拒绝、credential rotation/late replica；适用模态源/converter实际兑现。
5. 贯穿选择、plan、send、gate、settlement、retry、cancel、recover、plugin的因果链；慢/满/抛错/不可写sink与双限队列、双出口都失败的独立退化状态/query；重开权限负控、tenant范围、trace/metrics无秘密/正文/opaque/参数。诊断不能成为恢复真相。
6. 测量first-content网络到达→opened durable→用户可见、事务等待/持锁、两次evaluate和资源计数，保留规模/环境/数值；没有已接受数值阈值时交实测，不虚报性能合格或另设拍脑袋SLO。

放行结果M3：D3～D6完整真实行为通过，A-V0～A-V10/A-V12～A-V14全部适用项逐项闭合。不可施加真实OS反例等环境不足标blocked，不以恒假授权器补pass。前述不覆盖项按能力既定边界记not_applicable；未实现/未测不得NA。

### P6 37模型生产认证、独立验收和收尾

输入：M3完整生产路径、P2冻结37offer、唯一ledger与按请求配置测算的最坏reservation。

输出：37模型每个固定route分别形成public/service生产证据，执行transport完整原G清单＋增量及A-V11/A-V13；角色、参数、工具回传、适用推理/模态、身份/错误/流、缓存/费用均逐具体项映射，不能只给五组总pass。无法真实诱发的上游错误只能受控验证本地映射并保留上游未知，不用负控服务器冒充OpenRouter事实。

显式缓存必须证明配置TTL/断点实际发出、真实read命中，并按要提供的保留期断言安排expiry/因果对照；warm hit不证明TTL。automatic不加隐藏控制。每批先检查最坏余额、原unknown和保护器；资金不足继续无付费工作并列精确未验证cell，不降要求、不重置账本。

独立验证者在准确源码/制品/配置快照上执行真实装配，产出逐准则四态结论和证据；主线修复后受影响项重验。实现自查/应用自带场景不替代独立验收。无独立执行者时保留该项pending。

最终交付：可消费制品/开发运行命令、逐D/A-V/T/SC/G门表、完整失败/恢复/性能/权限证据、37矩阵及完整匹配器、费用对账/残余资源/未覆盖范围、当前源/输入/输出哈希及secret scan。归档actual evidence到既有record/evidence运行包；冻结规格不覆盖。技术结果交用户总体签收，不自动宣称上线或发布。

## 6. 验收分组与本次阶段的对应

权威具体场景见 [应用 verification](../../.meta_harness/design/realization/apps/model-request-acceptance/verification.md) 与 [transport verification](../../.meta_harness/design/realization/packages/model/pi-ai-transport/verification.md)；不重新定义操作/异常。新施工顺序只给出何时由谁执行。各组里组件子项与完整组合项分别记录。

| 原验收组                                                    | 本次执行阶段/验收路径                                                                                      | owner/证据                                                          |
| ----------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| A-V0 bootstrap/upgrade、A-V14本机输出                       | P1适用输出权限子项；P3正式入口前完整bootstrap/OS/query/export；P5/P6重开/归档重复                          | 主线实际app/文件/隔离OS进程；独立验证者复核，环境不足blocked        |
| A-V1纯值/真实来源、T1～20/SC1～3                            | P1公开组件初始子项；P2完整组件/lease；P3真实源组合                                                         | 主线公开制品及受控HTTPS；输入哈希、实际抓线、反例、真实停止         |
| A-V2当前来源/设置/资格、A-V3完整fill/历史                   | P3真实源/AR/MF组合；P5来源竞争及旧报告/固定H最终闭合                                                       | 主线；实际OG/EIS/STT/MF/AR公开面和真实storage，不是fixture假tuple   |
| 新工作区实际来源（PU-V1～6）                               | PU 条件阶段；只有对应新版输入的 P3～P5 消费增列前置，未受影响主线继续                                    | 新规格/投影采用后真实目录、权威关系读面及源/历史/model组合，不以旧组件测试代证 |
| A-V4目录/来源绑定、A-V13完整认证匹配                        | P3真实key/ref/body；P2/P3匹配基础设施负控；P5轮换/custom/hotupdate；P6矩阵合并重跑                         | 主线＋独立验证；完整值/上下文认回、不同scope/rev/配置和hash碰撞反例 |
| A-V5同一规划/耐久首内容/响应结算                            | P1/P2仅transport子项；P4完整service耐久链；P5unknown opened恢复                                            | 主线真实日志/HTTPS/跨写者结算，独立复核                             |
| A-V6失败runner/default retry/replay及before_persist_message | P3最小真实model链/消息经过；P4回复/response同批或真实否决settle；P5完整model失败/guard/转换/提醒/耐久/重放 | 主线真实LC4/runner/默认贡献；formal适用证据在消费者前核对           |
| A-V7实际取消/生命周期、A-V8持久恢复                         | P1/P2组件停止；P4service取消；P5全部kill/reopen/替换/unknown                                               | 主线实际子进程/HTTPS/log-owner交接；不以模拟或signal替actual事实    |
| A-V9可观测性、A-V12性能/资源                                | 从P1开始输出诊断；P3应用独立退化query；P5全部因果路径/双限/secret/sink/计时                                | 主线采集/装配所有权明确；独立验证者复跑                             |
| A-V10唯一预算ledger                                         | P1第一笔生产paid send之前完整保护器门；后续每笔/每批复用，P6独立对账                                       | 主线费用构件；已有研究ledger，不允许双账本/缺费用记零               |
| A-V11及transport逐模型所有G项                               | P1/P4代表证据只记其实际项；P6每个模型两条完整生产路径                                                      | 主线预算内实测＋独立验收；以完整匹配值认回，不能套族代表pass        |

每个实施增量结束前，主线交真实scenario run与命令，不预填未来命令已可执行。机器结果保存 `runId/scenarioId/status/reason`、实际source/contract/config、开始/结束、资源停止、证据/ledger引用；状态pass/fail/blocked/not_applicable精确分开。独立验收的四态总结果另记，不能与机器NA混用。

每个阶段放行还必须核对第0节的spec/realization→实现→证据对照；候选设计、临时mock或实现者自行选择的新投影不能入列accepted。

近期可执行检查看本仓库开发入口：按目标包运行 `pnpm --filter <实际package-name> build/typecheck/test`，消费真实打包制品；真实组合用已实现阶段scenario入口。只有新失败/新增源码/未决风险需要更广验证时才扩大；收尾执行仓库规定的required checks，并对继承三项tenancy迁移失败做精确对照，不把它们误计为本轮新增或全绿。

## 7. 唯一费用、模型认证和资源所有权

ledger唯一位置是当前执行树 `tmp/model-request-runtime/ledger.json`，上限USD100，研究分配50可配置。本修订观察170 settled、0 unsettled、USD `1.139960389500000000`，远程同步及 PU 准备不新增付费、不重置账本；观察哈希不是运行期余额，付费前重读排他账本。所有生产请求、retry/缓存expiry实验及失败请求统一预留/结算；生产transport不隐藏重试，任何paid retry再次经过同一费用入口。

完整认证匹配键按应用设计：**精确ModelProfileRef/配置来源上下文＋完整ModelAdaptationBinding＋实际provider route**。包括official/custom来源、custom完整组织/租户scope、implementation `{name,revision}`、definition `{modelId,revision}`、configuration `{revision,values}`；无档案public路径保留真实显式来源。哈希仅索引，无损JSON全值与逐码点字符串必须认回；缺全值、索引碰撞或任一值不同不能复用pass。变更公共family/parser/serializer使所有受影响记录失效；窄定义/config/route只重验实际受影响记录，影响不明保持未认证。

同一实际SQLite unit：EIS当前来源/OG参与；目录binding/CCL副本。MF物理写者持SQL E/排列/目标表/owned_ref共同提交。runtime/runner/调用者结算/提醒共享实际session JSONL批及判重/fence；SQL与JSONL按规定顺序提交，不承诺同成同败。app拥有log/credential/诊断/调度资源和真实关闭次序，P1独立消费者仅拥有自己lease/HTTP/观察器。

停止/重开按实际资源顺序：停新场景和准入→runtime/direct/runner工作实际结束与未知写者交接→registry/source/目录在途读取完成→各自服务close→文件/SQL/钥reader/diagnostic sink最后停止。不同provider按已接受load/unload对配执行，不能靠多个Cordis effect次序或解除依赖就当完成停止；持久事实不因撤除删掉。

## 8. 责任、止损和接续

主线是全部产品源码、workspace/lockfile、app装配与catalog/采用更新的唯一写入人；只读设计/plan评审角色不改源码、不签接受。若后续明确委派生产/验证任务，先给精确scope、accepted输入、可写路径、完成/停止条件，并在稳定公共边界上拆分；本计划不预设额外人手或自动全树派发。

| 触发                                        | 立即处置                                                              | 接续产物/受阻范围                                         |
| ------------------------------------------- | --------------------------------------------------------------------- | --------------------------------------------------------- |
| 新共享依赖超出第3节操作范围                 | 停止扩建，列出具体model消费者/反例；无消费者列延期                    | 操作scope差异＋下一model主链场景；不重开整个子系统        |
| 已采用公共接口/依赖投影不足或语义变动       | 仅暂停受影响接线，回对应spec/realization owner，独立适类评审/精确采用 | 新版本/消费者影响表；独立transport及其他稳定任务继续      |
| 受控网络/生命周期/耐久代表出现反例          | 不复制该共享模式，不展开37批次，保留失败并修实际构件                  | 精确重跑证据和受影响旧门失效；普通模块绿测不能放行        |
| 费用unknown、保护器失败或最坏余额不足       | 停paid sends，不将abort当退款/缺费用记零；保留限制内证据              | 对账引用或精确未测cell；无付费实现/检查继续               |
| 上游事实不可诱发、真实OS反例/模态源不可施加 | 标具体blocked，完成其它独立项；不填NA/pass                            | 环境/来源需求＋原证据＋受阻模型/场景，不擅自降offer       |
| sink失败/秘密扫描命中                       | 业务按原合同收场并记录独立退化；秘密命中停止归档和后续paid输出        | 受限失败证据、修复owner、完整重新扫描；不删除失败只留成功 |
| 中断/同步main/换代                          | 保留实际facts/失败/账本，核worktree与输入hash差异                     | STATUS下一步、仍适用产物与受影响重验；不stash，不重置账本 |

每次进度汇报至少分“public请求是否已实跑、租户service是否已实跑、耐久/恢复是否完整通过、37认证通过/未测、独立验收状态”。组件数量和测试数量仅作证据范围，不代替纵线进度。

当前继续 P1/P2 剩余符合性与完整窄定义/配置承载；P2 参数实际字节补证已按稳定边界独立安排。B1～B5按原范围接续，AR4源码保留待必要消费者复用。PU 在新工作区的实际消费者出现时释放，不因本次适用范围说明中断未受影响主线。产品正式化、技术采用、实现、实际验证和总体验收分别记状态。

本轮追加验收：外部仓库首次与后续登记均仅 participant、不因次序取得 owner／supadmin；受限组织装配不加载其 shared/local/兼容来源。普通目录会话仍可按自身租户授权调用模型，消息／tools／reminder 不得夹带被排除工作区来源；显式要求被拒工作区附着时不得伪报成功。零 HTTP 判据只适用于模型请求所需权威输入实际拒绝／不可取得的场景，不把允许的无工作区会话错误禁用。
