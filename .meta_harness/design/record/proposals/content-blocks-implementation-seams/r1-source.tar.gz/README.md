# 内容块的无损数值校验与生产者铸号

当前是 **R1 候选，未接受**。本包处理已接受映射在开包前暴露的两处具体缺口；不改变已冻结的 `data.content-blocks/v2`，不宣称模型工作闭环可实施。

- 基线：2026-09-27，HUB `c265bd03`；[D-060 M36/M44/M49](../../decisions/mainline-self-rulings-2026-09/decision.md)、[D-062](../../decisions/assets-runtimes-node-acceptance/decision.md)。
- 对象：[content-blocks](../../../realization/packages/core/content-blocks/design.md) 与 [pi-ai-transport](../../../realization/packages/model/pi-ai-transport/design.md) 的映射；前者尚无源码，后者仍受 D-019 比较门约束。
- 准入：数值校验有三个实际实现路径，铸号协调另有三个路径；均在[候选比较](alternatives.md)说明可行条件、代价与反例。
- 作者推荐：CB 专用、只供校验的数值视图；保留生产者分工并明确 pi 的确定性铸号例外。推荐不构成采用。

[设计及反向核对](design.md) · [候选与取舍](alternatives.md) · [评审与处置](review.md)。采用后才修改节点、发布决定和需求投影；本提案不是开发者的实施许可。
