"""Bounded design probe: arithmetic, currency policy, and persisted create outcome.

This is not the product BG/TG/DR implementation and does not test durability,
authorization, locks, concurrent publication, or core-journal/1 parsing.
Canonical encoding below covers only the ASCII/integer examples in this probe;
it is not a substitute for work-data's core-json/1 implementation.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


HERE = Path(__file__).resolve().parent
DOCUMENT = HERE.parents[1] / "docs/proposals/core-capabilities/implementation/governance-interfaces.md"


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def create_input(request):
    return {
        "format": "core-operation/1",
        "operationKind": "tenant.create",
        "tenantId": None,
        "principal": request["principal"],
        "target": {
            "kind": "tenant_creation",
            "tenantKind": request["tenantKind"],
            "creator": request["principal"],
        },
        "arguments": {"initialMembers": request["initialMembers"]},
        "preconditions": request["preconditions"],
        "causality": request["causality"],
    }


def recovered_lookup(request_path, outcome_path):
    request = json.loads(Path(request_path).read_text())
    outcome = json.loads(Path(outcome_path).read_text())
    same = (
        request["operation"] == outcome["operation"]
        and canonical(create_input(request)) == outcome["canonicalInput"]
    )
    print(json.dumps({
        "processId": os.getpid(),
        "status": "committed" if same else "operation_input_conflict",
        "result": outcome["result"] if same else None,
        "newIdentityAllocations": 0,
    }))


def exposure(current_cost, outstanding_floor):
    reserve = max(outstanding_floor - current_cost, 0)
    return current_cost + reserve, reserve


def admit(existing, candidate_floor, limit, unknown=False, unknown_allowed=True):
    known = sum(existing)
    if unknown and not unknown_allowed:
        return "bound_unknown"
    if known + candidate_floor > limit or (unknown and known >= limit):
        return "budget_exceeded"
    return "admitted"


def matching_budgets(source, budgets, posture_id):
    indexed = {budget["id"]: budget for budget in budgets}
    if posture_id is None:
        return "budget_posture_missing", []
    posture = indexed[posture_id]
    if posture["currency"] != source["currency"]:
        return "budget_currency_mismatch", []
    return "matched", [
        budget for budget in budgets
        if budget["scope"] in source["scopes"] and budget["currency"] == source["currency"]
    ]


def main():
    cases = []

    def check(name, actual, expected):
        assert actual == expected, (name, actual, expected)
        cases.append({"case": name, "actual": actual, "expected": expected, "passed": True})

    # The independent expected answers are the review's concrete counterexamples.
    for old_kind, new_kind in (("finite", "finite"), ("unknown", "finite"), ("unknown", "unknown"), ("finite", "unknown")):
        check(f"limit10_{old_kind}7_then_{new_kind}7", admit([7], 7, 10, unknown=new_kind == "unknown"), "budget_exceeded")
    check("partial_C3_K7", exposure(3, 7), (7, 4))
    check("partial_C3_then_Q3", admit([exposure(3, 7)[0]], 3, 10), "admitted")
    check("partial_C3_then_Q4", admit([exposure(3, 7)[0]], 4, 10), "budget_exceeded")
    check("partial_C9_K7", exposure(9, 7), (9, 0))
    check("partial_C9_then_Q1", admit([exposure(9, 7)[0]], 1, 10), "admitted")
    check("partial_C9_then_Q2", admit([exposure(9, 7)[0]], 2, 10), "budget_exceeded")
    check("unknown_zero_at_limit", admit([10], 0, 10, unknown=True), "budget_exceeded")
    check("unknown_without_exception", admit([], 7, 10, unknown=True, unknown_allowed=False), "bound_unknown")
    # A pending release contributes the conservative maximum, not a new sum or credit.
    check("pending_release_not_reused", admit([max(7, 3)], 7, 10), "budget_exceeded")
    check("durable_final_cost_releases_reserve", admit([3], 7, 10), "admitted")

    usd = {"id": "usd-tenant", "currency": "USD", "scope": "tenant", "limit": 10}
    eur = {"id": "eur-tenant", "currency": "EUR", "scope": "tenant", "limit": 10}
    eur_run = {"id": "eur-run", "currency": "EUR", "scope": "run", "limit": 2}
    source = {"currency": "EUR", "scopes": ["tenant", "run"]}
    check("EUR_source_USD_only_no_posture", matching_budgets(source, [usd], None)[0], "budget_posture_missing")
    check("EUR_source_bound_to_USD", matching_budgets(source, [usd], usd["id"])[0], "budget_currency_mismatch")
    status, selected = matching_budgets(source, [usd, eur], eur["id"])
    check("explicit_EUR_posture_matches_only_EUR", (status, [b["id"] for b in selected]), ("matched", ["eur-tenant"]))
    _, selected = matching_budgets(source, [usd, eur, eur_run], eur["id"])
    check("explicit_posture_does_not_skip_other_EUR_budget", [admit([], 3, b["limit"]) for b in selected], ["admitted", "budget_exceeded"])
    identity = {"budgetId": "budget1", "tenant": "tenant1", "scope": "tenant", "currency": "USD", "periodId": "period1"}
    for field in identity:
        changed = dict(identity, **{field: "changed"})
        check(f"changeBudget_{field}_immutable", "budget_identity_immutable" if changed != identity else "changed", "budget_identity_immutable")

    fixture = HERE / "revision-probe-fixture"
    fixture.mkdir(exist_ok=True)
    identities = []
    for kind in ("personal", "organization"):
        principal = {"kind": "user", "user": {"userId": "user1"}}
        request = {
            "operation": {"namespace": "core", "principalId": canonical(principal), "operationId": f"create-{kind}"},
            "principal": principal,
            "tenantKind": kind,
            "initialMembers": [{"userId": "user1", "role": "owner" if kind == "personal" else "super_admin"}],
            "preconditions": {},
            "causality": {},
        }
        # Stand-in for an already accepted outcome whose response did not arrive.
        # The client request deliberately has no assigned tenantId.
        outcome = {
            "format": "governance-design-probe-outcome/1",
            "operation": request["operation"],
            "canonicalInput": canonical(create_input(request)),
            "result": {"owner": "tenant", "outcome": "created", "tenantId": f"original-{kind}-tenant"},
        }
        request_path = fixture / f"{kind}-request.json"
        outcome_path = fixture / f"{kind}-outcome.json"
        request_path.write_text(canonical(request))
        outcome_path.write_text(canonical(outcome))

        def child():
            return json.loads(subprocess.check_output([sys.executable, __file__, "--recover", str(request_path), str(outcome_path)], text=True))

        recovered = child()
        check(f"{kind}_separate_process", recovered["processId"] != os.getpid(), True)
        check(f"{kind}_lost_response_lookup", (recovered["status"], recovered["result"]["tenantId"], recovered["newIdentityAllocations"]), ("committed", f"original-{kind}-tenant", 0))
        check(f"{kind}_input_has_no_assigned_id", "tenantId" in create_input(request)["target"], False)
        identities.append({"kind": kind, "parentProcessId": os.getpid(), "recoveryProcessId": recovered["processId"]})
        request["initialMembers"].append({"userId": "user2", "role": "member"})
        request_path.write_text(canonical(request))
        check(f"{kind}_same_key_changed_members", child()["status"], "operation_input_conflict")
        request["initialMembers"].pop()
        request["tenantKind"] = "organization" if kind == "personal" else "personal"
        request_path.write_text(canonical(request))
        check(f"{kind}_same_key_changed_kind", child()["status"], "operation_input_conflict")

    result = {
        "kind": "design-probe",
        "python": sys.version,
        "documentSha256": hashlib.sha256(DOCUMENT.read_bytes()).hexdigest(),
        "scriptSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "passed": len(cases),
        "cases": cases,
        "processes": identities,
        "limitations": [
            "Arithmetic and policy examples only; no product state owner, admission concurrency, or real effect.",
            "Separate-process fixture lookup demonstrates stable input/result identity, not DR durability or recovery compliance.",
            "Standard-library canonical JSON used only for ASCII/integer examples, not a core-json/1 implementation.",
            "Review and product TDD/real-provider acceptance remain pending.",
        ],
    }
    (HERE / "revision-probe-result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"passed": len(cases), "result": str(HERE / "revision-probe-result.json"), "processes": identities}, ensure_ascii=False))


if __name__ == "__main__":
    if len(sys.argv) == 4 and sys.argv[1] == "--recover":
        recovered_lookup(sys.argv[2], sys.argv[3])
    else:
        main()
