import assert from 'node:assert/strict'
import { chmod, mkdir, readFile, readdir, stat } from 'node:fs/promises'
import { join, resolve } from 'node:path'
import { createLocalDiagnostics } from '@omne-harness-lite/diagnostics'
import type { DiagnosticIdentity, DiagnosticPoint } from '@omne-harness-lite/diagnostics'

const directory = resolve('actual-output')
await mkdir(directory, { recursive: true, mode: 0o700 })
await chmod(directory, 0o700)
const result = await createLocalDiagnostics({
  instanceId: 'tarball-instance',
  sourceId: 'tarball-source',
  directory,
  level: 'debug',
  maxRecordBytes: 4_096,
  maxActiveSpans: 4,
  maxBufferBytes: 8_192,
  maxFileBytes: 32_768,
  maxDirectoryBytes: 65_536,
  maxFiles: 2,
})
if (result.status !== 'created') throw new Error(`unexpected invalid configuration: ${result.code}`)

const identity: DiagnosticIdentity = {
  tenantId: 'tenant-tarball',
  principal: { kind: 'user', user: { userId: 'user-tarball' } },
  operation: {
    namespace: 'tarball-consumer',
    principalId: 'principal-tarball',
    operationId: 'operation-tarball',
  },
  causality: {
    session: { tenantId: 'tenant-tarball', sessionId: 'session-tarball' },
  },
}
const point: DiagnosticPoint = {
  component: 'diagnostics.consumer',
  phase: 'artifact',
  code: 'artifact.real_log',
  level: 'info',
  diagnosticId: result.runtime.diagnostics.newId(),
  measures: { count: 1 },
}
const context = result.runtime.diagnostics.scope(identity)
const span = result.runtime.diagnostics.startSpan(context, {
  ...point,
  code: 'artifact.real_span',
})
result.runtime.diagnostics.log(span.context, point)
span.end({ code: 'artifact.real_span_done', outcome: 'ok' })
const closed = await result.runtime.close({ deadlineMs: 1_000 })
assert.equal(closed.status, 'closed')
assert.equal(closed.state.resource, 'released')
assert.equal(closed.state.activeSpans, 0)

const files = await readdir(directory)
assert.equal(files.length, 1)
const path = join(directory, files[0]!)
assert.equal((await stat(directory)).mode & 0o777, 0o700)
assert.equal((await stat(path)).mode & 0o777, 0o600)
const lines = (await readFile(path, 'utf8')).trim().split('\n').map(line => JSON.parse(line) as Record<string, unknown>)
assert.deepEqual(lines.map(line => line.code), [
  'diagnostic.source_started',
  'artifact.real_log',
  'artifact.real_span_done',
  'diagnostic.source_closed',
])
assert.equal(lines.find(line => line.code === 'artifact.real_log')?.tenantId, 'tenant-tarball')
assert.equal(lines.find(line => line.code === 'artifact.real_span_done')?.outcome, 'ok')
console.log(`PASS: packed default entry wrote ${lines.length} real lines and closed its source`)
