import type { OperationRef } from '@omne-harness-lite/work-data'
import type {
  CodecLimits,
  CommitEnvelope,
  PreparedCommit,
  PreparedOperation,
  RecordPreparation,
  RecordProvider,
  RecordReader,
  RecordWriter,
} from '@omne-harness-lite/records'

declare const limits: CodecLimits
declare const envelope: CommitEnvelope
declare const preparation: RecordPreparation
declare const reader: RecordReader
declare const writer: RecordWriter
declare const provider: RecordProvider
declare const operation: OperationRef

const preparedOperation: ReturnType<typeof preparation.prepareOperation> = preparation.prepareOperation(operation, {
  format: 'core-operation/1', operationKind: 'test', tenantId: null,
  principal: { kind: 'system', systemId: 'test' }, target: null, arguments: {}, preconditions: {}, causality: {},
})
void [limits, envelope, reader, writer, provider, preparedOperation]

// @ts-expect-error opaque preparation capabilities cannot be constructed by a consumer
const forgedOperation: PreparedOperation = { operation, canonicalInput: '{}' }
// @ts-expect-error opaque commit capabilities cannot be constructed by a consumer
const forgedCommit: PreparedCommit = { operation, canonicalInput: '{}', owners: [], requiredUses: [] }
void [forgedOperation, forgedCommit]
