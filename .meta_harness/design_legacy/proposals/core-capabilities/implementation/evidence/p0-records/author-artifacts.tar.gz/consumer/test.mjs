import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { canonicalJson } from '@omne-harness-lite/work-data'
import { decodeLine, encodeEnvelope } from '@omne-harness-lite/records'

const canonicalInput = '{"arguments":{"epoch":"1"},"causality":{},"format":"core-operation/1","operationKind":"writer.acquire","preconditions":{"previousEpoch":"0"},"principal":{"kind":"system","systemId":"local-host"},"target":"domain-1","tenantId":null}'
const envelope = {
  appends: [{
    expectedRevision: '0',
    records: [{ data: { epoch: '1' }, kind: 'writer.epoch', version: '1' }],
    stream: { namespace: 'core.writer', owner: 'durable-records', scope: { kind: 'system' }, streamId: 'writer-epochs' },
  }],
  canonicalInput,
  formatVersion: 'core-journal/1',
  inputDigest: createHash('sha256').update(canonicalInput, 'utf8').digest('hex'),
  inputEncoding: 'core-json/1',
  operation: { namespace: 'core.writer', operationId: 'epoch:1', principalId: canonicalJson({ kind: 'system', systemId: 'local-host' }) },
  outcome: { result: { epoch: '1' }, status: 'committed' },
  position: { commitId: 'commit-1', coordinationDomain: 'domain-1', seq: '1', writerEpoch: '1' },
  requiredUses: [],
}
const limits = { maxBytes: 4096, maxDepth: 32, maxNodes: 512, maxLineBytes: 8192, maxPayloadBytes: 4096 }
const encoded = encodeEnvelope(envelope, limits)
assert.equal(encoded.ok, true)
if (!encoded.ok) throw new Error('encode failed')
assert.equal(encoded.value.byteLength, 1294)
assert.equal(createHash('sha256').update(encoded.value).digest('hex'), '922232e653e4196bcdda9624769766eb65784c624caf2661f38051543917e63a')
const decoded = decodeLine(encoded.value, limits)
assert.equal(decoded.ok, true)
if (!decoded.ok) throw new Error('decode failed')
assert.equal(canonicalJson(decoded.value.envelope), canonicalJson(envelope))
assert.equal(Object.isFrozen(decoded.value.envelope.appends[0].records[0].data), true)

function nestedArrays(count) {
  let value = 0
  for (let index = 0; index < count; index += 1) value = [value]
  return value
}

const deepLimits = { ...limits, maxDepth: 256 }
const adjacentEnvelope = { ...envelope, outcome: { status: 'committed', result: nestedArrays(126) } }
const adjacent = encodeEnvelope(adjacentEnvelope, deepLimits)
assert.equal(adjacent.ok, true)
if (!adjacent.ok) throw new Error('adjacent boundary encode failed')
assert.equal(decodeLine(adjacent.value, deepLimits).ok, true)
const repeated = encodeEnvelope(adjacentEnvelope, deepLimits)
assert.equal(repeated.ok, true)
if (!repeated.ok) throw new Error('repeated encode failed')
assert.notEqual(adjacent.value, repeated.value)
adjacent.value[0] = 0
assert.equal(repeated.value[0], '{'.charCodeAt(0))

const rejected = encodeEnvelope({ ...envelope, outcome: { status: 'committed', result: nestedArrays(127) } }, deepLimits)
assert.equal(rejected.ok, false)
if (rejected.ok) throw new Error('over-depth payload was accepted')
assert.equal(rejected.issues[0].code, 'capacity')
assert.match(rejected.issues[0].path, /^\/payload\//)
assert.equal(Object.isFrozen(rejected), true)
assert.equal(Object.isFrozen(rejected.issues), true)
assert.equal(Object.isFrozen(rejected.issues[0]), true)
console.log('PASS: records tarball fixed G01 bytes, parser depth parity, immutable failure and owned bytes')
