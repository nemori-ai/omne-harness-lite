import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync, realpathSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, isAbsolute, join, relative } from 'node:path'
import { pathToFileURL } from 'node:url'

assert.equal(process.env.NODE_PATH, undefined)
assert.equal(process.env.NODE_OPTIONS, '--no-global-search-paths')

const consumerRoot = realpathSync('.')
const consumerRequire = createRequire(import.meta.url)
const { globalPaths } = consumerRequire('node:module')
assert.deepEqual(globalPaths, [])

function manifestFrom(name, parentRequire) {
  for (const directory of parentRequire.resolve.paths(name) ?? []) {
    const candidate = join(directory, name, 'package.json')
    if (existsSync(candidate)) return realpathSync(candidate)
  }
  assert.fail(`cannot resolve installed manifest for ${name}`)
}

function assertInsideConsumer(path) {
  const fromConsumer = relative(consumerRoot, path)
  assert.ok(
    fromConsumer !== '' &&
      fromConsumer !== '..' &&
      !fromConsumer.startsWith(`..${process.platform === 'win32' ? '\\' : '/'}`) &&
      !isAbsolute(fromConsumer),
    `dependency escaped external consumer: ${path}`,
  )
}

const rootManifest = JSON.parse(readFileSync(join(consumerRoot, 'package.json'), 'utf8'))
assert.deepEqual(Object.keys(rootManifest.dependencies), ['@omne-harness-lite/diagnostics'])

const diagnosticsManifestPath = manifestFrom('@omne-harness-lite/diagnostics', consumerRequire)
const diagnosticsManifest = JSON.parse(readFileSync(diagnosticsManifestPath, 'utf8'))
assert.equal(diagnosticsManifest.version, '0.0.0')
const diagnosticsRequire = createRequire(pathToFileURL(diagnosticsManifestPath))

const recordsManifestPath = manifestFrom('@omne-harness-lite/records', diagnosticsRequire)
const workDataManifestPath = manifestFrom('@omne-harness-lite/work-data', diagnosticsRequire)
const fsExtManifestPath = manifestFrom('fs-ext', diagnosticsRequire)
const fsExtManifest = JSON.parse(readFileSync(fsExtManifestPath, 'utf8'))
assert.equal(fsExtManifest.version, '2.1.1')
const fsExtEntry = realpathSync(diagnosticsRequire.resolve('fs-ext'))
const fsExt = diagnosticsRequire('fs-ext')
assert.equal(typeof fsExt.flock, 'function')
const addonPath = realpathSync(join(dirname(fsExtEntry), 'build', 'Release', 'fs_ext.node'))
assert.ok(
  Object.keys(diagnosticsRequire.cache).some(
    path => path.endsWith('/fs_ext.node') && realpathSync(path) === addonPath,
  ),
)
const fsExtRequire = createRequire(fsExtEntry)
const nanManifestPath = manifestFrom('nan', fsExtRequire)
const nanManifest = JSON.parse(readFileSync(nanManifestPath, 'utf8'))
assert.equal(nanManifest.version, '2.28.0')

const dependencies = {
  diagnosticsManifest: diagnosticsManifestPath,
  recordsManifest: recordsManifestPath,
  workDataManifest: workDataManifestPath,
  fsExtManifest: fsExtManifestPath,
  fsExtEntry,
  nanManifest: nanManifestPath,
  addon: addonPath,
}
for (const path of Object.values(dependencies)) assertInsideConsumer(path)

console.log(
  JSON.stringify({
    consumerRoot,
    node: process.version,
    nodeOptions: process.env.NODE_OPTIONS,
    nodePath: null,
    globalPaths,
    dependencies,
    fsExtVersion: fsExtManifest.version,
    nanVersion: nanManifest.version,
    flock: typeof fsExt.flock,
    addonSha256: createHash('sha256').update(readFileSync(addonPath)).digest('hex'),
  }),
)
