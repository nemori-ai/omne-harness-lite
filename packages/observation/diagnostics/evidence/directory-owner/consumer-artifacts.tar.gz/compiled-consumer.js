import assert from 'node:assert/strict';
import { lstat, readFile, readdir, readlink, realpath, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { createLocalDiagnosticsDirectory } from '@omne-harness-lite/diagnostics';
const consumerRoot = await realpath('.');
assert.equal(dirname(consumerRoot), await realpath(tmpdir()));
assert.equal(process.env.NODE_PATH, undefined);
assert.equal(process.env.NODE_OPTIONS, '--no-global-search-paths');
for (let ancestor = dirname(consumerRoot);; ancestor = dirname(ancestor)) {
    await assert.rejects(lstat(join(ancestor, 'node_modules')), { code: 'ENOENT' });
    if (dirname(ancestor) === ancestor)
        break;
}
const directory = resolve('actual-output');
const options = { directory, maxDirectoryBytes: 65_536, maxFiles: 2 };
const created = await createLocalDiagnosticsDirectory(options);
if (created.status !== 'created')
    throw new Error(`${created.status}: ${created.code}`);
const source = {
    instanceId: 'hub-tarball-instance',
    sourceId: 'hub-tarball-source',
    level: 'debug',
    maxRecordBytes: 4_096,
    maxActiveSpans: 4,
    maxBufferBytes: 8_192,
    maxFileBytes: 32_768,
};
const result = await created.owner.create(source);
if (result.status !== 'created')
    throw new Error(`${result.status}: ${result.code}`);
const contender = await createLocalDiagnosticsDirectory(options);
assert.equal(contender.status, 'unavailable');
if (contender.status !== 'unavailable')
    throw new Error('second directory owner was admitted');
assert.equal(contender.cleanup, null);
const identity = {
    tenantId: 'tenant-tarball',
    principal: { kind: 'user', user: { userId: 'user-tarball' } },
    causality: { session: { tenantId: 'tenant-tarball', sessionId: 'session-tarball' } },
};
const diagnostics = result.runtime.diagnostics;
const context = diagnostics.scope(identity);
const point = { component: 'diagnostics.consumer', phase: 'artifact', level: 'info' };
const span = diagnostics.startSpan(context, { ...point, code: 'artifact.real_span' });
diagnostics.log(span.context, { ...point, code: 'artifact.real_log' });
span.end({ code: 'artifact.real_span_done', outcome: 'ok' });
const sourceClosed = await result.runtime.close({ deadlineMs: 1_000 });
assert.equal(sourceClosed.status, 'closed');
assert.equal(sourceClosed.state.resource, 'released');
const ownerClosed = await created.owner.close({ deadlineMs: 1_000 });
assert.equal(ownerClosed.status, 'closed');
assert.equal(ownerClosed.state.lock, 'released');
assert.equal(ownerClosed.state.resource, 'released');
const files = await readdir(directory);
assert.equal(files.length, 2);
const lock = await stat(join(directory, '.diagnostics.lock'));
assert.equal(lock.size, 0);
assert.equal(lock.mode & 0o777, 0o600);
const sourceName = files.find(name => name.endsWith('.jsonl'));
assert.ok(sourceName);
const sourcePath = join(directory, sourceName);
assert.equal((await stat(directory)).mode & 0o777, 0o700);
assert.equal((await stat(sourcePath)).mode & 0o777, 0o600);
const lines = (await readFile(sourcePath, 'utf8'))
    .trim()
    .split('\n')
    .map(line => JSON.parse(line));
assert.deepEqual(lines.map(line => line.code), [
    'diagnostic.source_started',
    'artifact.real_log',
    'artifact.real_span_done',
    'diagnostic.source_closed',
]);
assert.equal(lines.find(line => line.code === 'artifact.real_log')?.tenantId, 'tenant-tarball');
assert.equal(lines.find(line => line.code === 'artifact.real_span_done')?.outcome, 'ok');
const reopened = await createLocalDiagnosticsDirectory(options);
if (reopened.status !== 'created')
    throw new Error(`${reopened.status}: ${reopened.code}`);
assert.equal(reopened.owner.inspect().materializedFiles, 1);
const restartedLock = await stat(join(directory, '.diagnostics.lock'));
assert.equal(restartedLock.ino, lock.ino);
assert.equal((await reopened.owner.close({ deadlineMs: 1_000 })).status, 'closed');
const outputRealpath = await realpath(directory);
const openOutputFileDescriptors = [];
for (const descriptor of await readdir('/proc/self/fd')) {
    let target;
    try {
        target = await readlink(join('/proc/self/fd', descriptor));
    }
    catch (error) {
        if (error instanceof Error && 'code' in error && error.code === 'ENOENT')
            continue;
        throw error;
    }
    if (target === outputRealpath || target.startsWith(`${outputRealpath}/`)) {
        openOutputFileDescriptors.push(`${descriptor}:${target}`);
    }
}
assert.deepEqual(openOutputFileDescriptors, []);
console.log(JSON.stringify({
    consumerRoot,
    lines: lines.length,
    lineCodes: lines.map(line => line.code),
    contender: contender.code,
    sourceClosed,
    ownerClosed,
    directoryMode: (await stat(directory)).mode & 0o777,
    sourceMode: (await stat(sourcePath)).mode & 0o777,
    lockMode: restartedLock.mode & 0o777,
    lockSize: restartedLock.size,
    stableLockInode: restartedLock.ino === lock.ino,
    retainedOnRestart: reopened.owner.inspect().materializedFiles,
    openOutputFileDescriptors,
}));
