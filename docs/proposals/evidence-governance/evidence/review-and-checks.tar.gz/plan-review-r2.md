复评对象：提交 `424fb79` 的规范与投影，以及临时计划 SHA-256 `8060959d…a29696c`。工作树相对该提交干净。已完成修订计划、验证记录和实际文件状态的只读复评；未运行任何检查或测试。

**结论**

本次修订计划范围内未发现新的依赖、并行或写权阻断问题。r1 两项问题已在计划层面闭合：

- [plan.md](</data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/tmp/evidence-governance/plan.md:24>)明确指定 architecture-reviewer、spec-reviewer 和独立普通 agent 为 W4 证据生产者，根 agent 只负责取证与修订，并规定资源不可用时 W5 不得完成。
- 环境级 `quick_validate.py` 的路径和内容哈希已写入计划及[验证记录](</data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/proposals/evidence-governance/verification.md:20>)；现有原始日志中的哈希与实际脚本一致。

新增范围也已进入依赖图和验收边界：W2 生产组织准入、性质推导和九对目录入口；W3 在稳定正文后同步五份 skills 与八对角色；EG-10/11 分别承接目录准入和需求→性质→保护→证据。九个直接子目录及同级 CLAUDE 引用均存在于 `424fb79`。

**交付前仍须闭合**

- W4/W5 尚未完成。[验证记录](</data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/proposals/evidence-governance/verification.md:30>)明确保留最终独立评审和场景推演为未完成，因此当前只能说明计划可继续，不能报告整体验收完成。
- 现有 `static-checks.log` 只保留了十次 skill 校验和八对角色生成检查。验证记录还声称执行了 `make docs-check`、TOML/YAML 基线比较、目录入口检查和 `git diff --check`，但日志中没有这些命令、退出状态或输出。W5 应补齐原始记录，或至少保存精确命令、输入基线、退出结果和可核对输出，尤其要说明配置比较排除了哪些提示字段。
- `design-r2-snapshot.json` 已过时：它仍引用已经移走的 `docs/proposals/evidence-governance/plan.md` 和 r1 计划哈希，也不匹配提交 `424fb79` 中当前提案内容。当前派发消息使本次复评对象仍然明确；永久评审记录应改为绑定 `424fb79`、临时计划哈希 `8060959d…a29696c` 和最终 W4 输入，不能继续引用该旧清单作为当前快照。
- [计划的场景](</data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/tmp/evidence-governance/plan.md:60>)已经覆盖 `write-agents-md` 要求的四类探针，并要求逐项报告心智、拥有者、无关阅读和停止点。最终验证记录还应补充该 skill 要求的交付摘要：九份 AGENTS 各自的角色、保留常驻内容及理由、转出的内容、未解决的来源冲突/归属缺口、继承链大小和探针结果。当前记录只有链长度和“待探针核对”。

正式接受仍是有意保留的上游待裁决事项；本次结论不接受治理政策，也不表示角色已由宿主加载。
