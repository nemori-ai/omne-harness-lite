已只读确认指定工作树 `/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance` 的 HEAD 为 `424fb79`，分支为 `docs/evidence-governance`。以下是任务路由判断；题设中的实验、契约和证据均作为给定前提，没有自行补充产品事实。

1. **修正失效本地链接。**理解为不改变候选身份或设计含义的导航修复，内容仍归 `docs/proposals/README.md`。需要具体失效链接、正确目标及相关锚点；性质限于引用准确、没有语义变化。普通文档维护者可以修复并执行相称链接检查，无需新提案、决定或架构评审。题面未指出具体链接，因此这里只能确定处置路径。决定性依据是“局部措辞或链接修复只展开其内容所有者与相关检查”。阅读从根、docs、proposals 局部入口，到目标 README 和验证规范的链接检查范围即停止。[docs/AGENTS.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/AGENTS.md:33)

2. **保存三人的分工、进度和调试日志。**理解为一次数据库适配器任务的施工状态，默认归 Git 忽略的 `tmp/<任务>/` 或任务系统。需要任务范围、人员与写入归属、输入版本、日志来源及必要保留要求；没有给定需要长期保存的技术选择或研究结论。任务协调者维护安排，各执行者提供事实日志，可以直接记录。不能仅因涉及数据库设计就建永久 proposal；后来若产生有长期价值的观察或取舍，再提炼到相应拥有者。决定性依据明确列出“临时施工计划、任务 DAG、分派、进度与本地日志”归 tmp。读组织准入后停止，不展开数据库架构或完整交付规划。[organization.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/organization.md:75)

3. **选择共享注册接口并保存讨论、实验。**这是影响跨包消费者及在线撤除保证的持久设计取舍，符合 proposal 准入；可复现实验的事实、配置、结果及局限归 research，并与提案互引。需要两个候选的状态表示、操作与撤除语义、允许交错、消费者观察、实验版本及导致丢条目的因果轨迹。应明确“撤除自己的贡献须保留他方合法贡献”。可以整理候选、反例和未决项；已出现的反例足以否定失败候选在相应条件下的保证，不能因此推定另一个候选全面正确。设计拥有者负责选择论证，研究执行者负责证据；形成设计稿后由 architecture-reviewer 独立审阅，接受另行记录。读 proposals/research 局部入口、准入与知识流转，再到组合性质的共享贡献例子即停止。[organization.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/organization.md:56)；[composability.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/architecture-guide/assurance/composability.md)

4. **新插件消费已有受控注册 API。**这是既有契约内的实现与使用映射，归所属包的源码、当前设计和相关验证记录。需要所消费的精确契约/API 版本、已有证据的前提与覆盖、实际作用域、调用和生命周期映射。按照题设，可以复用适用证据并推进消费实现，不要求重新证明提供者，也不为插件制造空 effect 或新提案。消费者负责自身调用条件，提供者继续拥有受控操作及表示所承诺的性质，装配负责实际依赖与作用域；实际插件符合性仍需验证。读 packages 入口和“复用既有受控操作”一项后即有门槛判断，不展开自定义共享协议证明。[composability.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/architecture-guide/assurance/composability.md:45)

5. **以新交换性保证省略租户写入冲突检查。**这是系统关键保证所依赖的机制选择；首次设计就省略控制同样触发证明要求。需要明确量化状态、租户、操作族、交错、返回值与后续行为、失败模型，以及交换性如何保证省略检查后仍满足租户隔离。该证明须经机器检查，两个实例的模型检查不能闭合此义务。候选设计、反例搜索和证明/工具研究可以继续；依赖该性质的机制接受及实施受阻。设计/性质拥有者定义命题，提供者说明强制前提，证明执行者产出工件，独立审阅者核对，计划拥有者标明受阻消费者及闭合时点。读需求推导、组合性质门槛、验证结果含义和接受边界后停止，不自行指定新证明工具。[composability.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/architecture-guide/assurance/composability.md:56)

6. **恢复契约的全称结果归属要求。**理解为“结果不得串到其他调用”的跨事件安全目标，归恢复能力契约；仅当无法归属单一能力时才落组合契约。需要合法状态、调用及必要代际身份、观察点、恢复交接、环境前提和保护位置。可表达、审阅乃至按授权接受该语义范围，同时明确尚无实现和证据；可以规划行为模型、关键性质检查及实现符合性工作。全称措辞本身不触发第 5 项的新增机器证明门槛，题设也没有依据小模型推广省略控制。但不能声称目标已经证明或产品已实现。语义由设计/契约拥有者负责，规格维护者负责表达，实施和验证责任另落实。读“不变量与安全约束”以及“契约中的全称要求是规范目标”后停止门槛扩展。[composability.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/architecture-guide/assurance/composability.md:65)

7. **连接关闭但外写结果未知，dispose 返回成功。**已知事实只有连接已关闭，外写是否提交仍未知；不足以支持整体结算或撤除完成。需要 dispose 成功的精确范围、在途请求归属、未知结果的保存与恢复政策，以及是否已经合法交接。语义归相关生命周期/外写契约，具体关闭、等待和交接归提供者设计及实现。可以记录真实未知、核对契约并调查；不能把关闭连接、调用 disposer 或成功文字当作外写未发生或已结算的证据。若成功仅指契约允许的局部资源关闭，仍须有明确的未决工作责任；题面没有这种依据，不能默认存在。后端提供者负责真实资源结果，能力负责业务接续，实际交接需对应负责人。读生命周期的完成判据、停止与外部副作用后停止，不推定具体 Cordis 行为。[lifecycle.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/architecture-guide/runtime/lifecycle.md:44)

8. **证明工具成功退出，但目标仍是输入假设。**理解为执行成功与目标证明混淆。结果归绑定精确对象的验证记录，目标命题及规范性模型归相应契约工件。需要完整命题、证明工件、公理与假设、依赖和工具版本、未消解义务、命令配置及实际输出。可以报告工具执行成功、目标未证明，并修复证明或结果判定；依赖该证明完成的消费不能放行。命题拥有者负责消解义务，工具/验证执行者负责准确判定，独立审阅者核对信任边界。验证规范明确禁止“把目标当成未验证假设”后声称已证明；读这一条即停止，无需实际运行工具。[verification.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/verification.md:50)

9. **删除独立条目改成恢复旧快照，却沿用旧证明。**这是表示与操作语义变化，签名不变不足以保持证据适用性。变更归提供者源码、当前设计和证据映射；只有承诺改变才演进语义契约。需要旧证明的命题及前提、新旧实现快照、恢复范围、允许交错和消费者观察；尤其检查 A 注册后 B 合法注册，再撤除 A 时是否抹去 B。可以开展适用性分析和修复；在没有新适用性论证前，不能把旧证明投影成当前通过，也不能假定新实现已经满足契约。提供者负责表示与清理，验证负责受影响证据，消费者/装配负责核对使用前提。读规格变更传播和共享贡献例子后停止，不无差别重做全部证据。[spec-maintenance.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/spec-maintenance.md:117)

10. **三个组件通过，但真实组合无人负责。**这是交付计划的责任和验收缺口，不是三个组件测试的再次审计。施工安排归临时计划，真实组合结果归相应验证记录，长期选择仍由提案拥有。需要实际参与版本、动作链及重要失败分支、集成环境、完成判据、负责人和执行时点。可以补齐计划并保留仍适用的组件成果；不能宣称组合通过或交付完成。派发/计划负责人必须指定组合交付负责人，组件作者承担自身测试，verification-developer 可承担明确范围的组合验证；plan-reviewer 检查安排是否闭合。读交付规划与角色分工即停止，不转为 architecture-reviewer 或 spec-reviewer 的重复审计。[delivery-planning.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/delivery-planning.md:70)

11. **宣称多租户在线更新，却未推导性质。**这是架构设计缺口，归架构候选及其设计拥有者。需要两项功能需求的确认范围与采用快照，从消费者结果导出租户授权、撤除范围与贡献保留等必要性质，并明确并发、失败、旧使用和代际交接中的保护位置、责任及证据缺口；不能从服务键反推需求已经覆盖。可以继续推导性质和完善候选；不足以宣称设计已兑现两项需求，依赖未决语义的实施暂停，独立工作继续。architecture-reviewer 负责审阅需求到性质、机制和证据的对应，设计拥有者解决问题；不由规格或计划 reviewer 代选政策。读不变量推导与角色职责后停止，不预选排空、迁移等具体政策。[invariants.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/architecture-guide/assurance/invariants.md:21)

12. **设计已要求旧代际清理保留新条目，规格只有 Schema。**这是既定行为未被充分表达，归负责该撤除行为的能力契约；字段 Schema 仍只拥有数据形状。需要可识别设计与规格快照、原条款含义、代际/条目归属、允许动作及可观察结果。可以补齐行为正文，并按具体验证问题补充行为模型或规范场景；如果规范版本已发布，必须走版本演进，不能原地改冻结工件。规格维护者负责表达，spec-reviewer 检查是否忠实完整；不需要它重新裁决“是否允许误删”。依赖该缺失表达的交接不能称为就绪，但现有设计足以支持补写。读 spec 入口、规格按性质生长和规格 reviewer 分工后停止，不要求所有模型文件齐备。[spec-maintenance.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/spec-maintenance.md:51)

13. **实现允许全租户撤除，契约只授权当前租户。**题设明确为实现不符合已接受契约，应修所属包的授权与撤除行为，并补足受影响证据及映射。需要契约精确版本、授权主体/租户作用域、实际入口和反例；应观察跨租户撤除被拒绝及他方注册被保留，不能仅断言内部检查函数被调用。可以沿契约修复；不能通过只改 docs 降低已接受保证。本场景没有挑战契约前提的新证据，不必重开架构选择。包实现负责人承担修复和自身验证；若另有跨边界组合则明确对应验证责任。读 packages 入口和“实现偏离既有契约”的处置后停止。[spec-maintenance.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/spec-maintenance.md:118)

14. **为了少写适配层而直访另一包内部注册表。**这是包公共边界及受控操作责任问题，不能仅以代码行数作判断。需要公开服务的契约、适配层承担的授权/所有权/生命周期/错误映射，以及内部直访会绕过哪些约束。可以沿公开入口实现，并在保留责任的前提下简化没有独立价值的转发代码；题设不足以授权绕过内部边界。若公开入口确实缺能力，应由提供包拥有者明确公共边界变化及消费者影响。消费者负责合规调用，提供者负责受控接口；涉及新保证或边界取舍时再展开架构设计。读 packages 入口、workspace 的公开入口规则和 engineering-taste 的边界判断后停止。[workspace.md](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/workspace.md:84)

实际入口足以作上述路由和门槛判断：组织规范拥有准入，组合性质拥有证明触发，验证规范拥有结果含义，规格维护拥有变化传播，交付规划及角色入口拥有执行和审阅责任。根、局部 AGENTS 和 skills 有摘要重复，但通过链接能辨认正文拥有者，没有遇到必须静默选边的实质冲突。

有一处措辞需要结合上下文阅读：[knowledge-flow.md:32](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/knowledge-flow.md:32) 的“保留完整讨论及证据”，单独读可能被理解为保存全量会话；其准入链接及组织规范明确限定为支持选择和必要复现的材料，因此本次没有把它解释为全量归档要求。

本次未写文件、执行测试或形式工具、调用产品服务、继续委派，也未核验题设所指的实际 API、实验或证明。未读取无关产品提案、上游 Cordis 文档或全部目录。指导文件的存在、指定修订中的治理候选以及这次任务推演，都不构成产品实现、组合正确性或证明完成的证据，也不增加任何接受状态。
