已完成固定提交 `424fb79e`（比较基线 `59139bb`）的只读复评。**r1 两项已闭合，本次扩展范围内未发现阻断问题，无新增架构修订项。**

- **证明门槛已澄清。** [composability.md:56](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/architecture-guide/assurance/composability.md:56)覆盖首次省略控制、改变复用前提及证据级别要求；第 65 行明确全称契约目标不单独触发证明关卡。
- **需求与证据责任已衔接。** [invariants.md:21](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/architecture-guide/assurance/invariants.md:21)要求从需求推导性质，核对保护位置和双向覆盖；组合指南第 85–92 行明确提供者、消费者、装配及环境责任，并排除循环互相假定。
- **知识准入与目录投影一致。** [organization.md:31](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/organization.md:31)区分九类长期知识，提案准入包含明确对象、长期价值和可接续内容；九份局部 AGENTS 与其一致，CLAUDE 均仅引用同级。临时计划仍允许按必要追溯价值保留为历史证据，没有一律禁止或自动归档。
- **接受与角色边界保持。** [knowledge-flow.md:85](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/knowledge-flow.md:85)限制必要证据未齐时的机制接受；提案继续标为 `in-review`。相关 skills 和 reviewer 源保持架构判断、规格表达、交付依赖三者分工，未增加接受权。

范围包含指定维护正文、架构指南、目录入口及相关源提示改动。未重审未变研究，未执行测试、形式工具、生成一致性或宿主行为验证；已有静态结果仅作为作者记录读取。本结论不代表接受设计或验证产品正确。
