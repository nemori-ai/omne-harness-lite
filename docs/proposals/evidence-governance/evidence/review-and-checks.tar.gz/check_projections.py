"""Read-only delivery evidence for the fixed governance revision."""
from pathlib import Path
import hashlib
import json
import subprocess
import tomllib
import yaml

BASELINE = "59139bb"
ROOT = Path.cwd()
revision = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
print(f"cwd={ROOT}; revision={revision}; baseline={BASELINE}")
codex_paths = sorted(Path(".codex/agents").glob("*.toml"))
for path in codex_paths:
    old = subprocess.check_output(["git", "show", f"{BASELINE}:{path}"], text=True)
    before, after = tomllib.loads(old), tomllib.loads(path.read_text())
    del before["developer_instructions"]
    del after["developer_instructions"]
    assert before == after, path
    print(f"PASS {path}: all TOML fields equal except developer_instructions")
    claude_path = Path(".claude/agents") / f"{path.stem}.md"
    old = subprocess.check_output(["git", "show", f"{BASELINE}:{claude_path}"], text=True)
    before = yaml.safe_load(old.split("---", 2)[1])
    after = yaml.safe_load(claude_path.read_text().split("---", 2)[1])
    assert before == after, claude_path
    print(f"PASS {claude_path}: full YAML frontmatter equal; Markdown prompt body excluded")
assert len(codex_paths) == 8, len(codex_paths)

chains = []
for directory in sorted(Path("docs").iterdir()):
    if not directory.is_dir():
        continue
    entry = directory / "AGENTS.md"
    assert entry.is_file(), entry
    assert (directory / "CLAUDE.md").read_text() == "@AGENTS.md\n", directory
    local = entry.read_text()
    chain = Path("AGENTS.md").read_text() + Path("docs/AGENTS.md").read_text() + local
    chains.append({"path": str(entry), "local_lines": len(local.splitlines()),
                   "chain_lines": len(chain.splitlines()), "chain_characters": len(chain)})
    print(f"PASS {directory}: AGENTS present; CLAUDE exact same-level reference")
assert len(chains) == 9, len(chains)
print(json.dumps(chains, ensure_ascii=False, indent=2))

paths = subprocess.check_output(["git", "diff", "--name-only", BASELINE, revision], text=True).splitlines()
snapshot = {"revision": revision, "baseline": BASELINE,
            "sha256": {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths},
            "local_plan": {"path": "tmp/evidence-governance/plan.md",
                           "sha256": hashlib.sha256(Path("tmp/evidence-governance/plan.md").read_bytes()).hexdigest()}}
Path("tmp/evidence-governance/reviewed-snapshot.json").write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n")
print("Snapshot: tmp/evidence-governance/reviewed-snapshot.json; obsolete design-r2-snapshot.json is not a current input")
