评审对象为分支 `docs/evidence-governance`、提交 `424fb79e8e9d289928c945d36177b047c0d6dde1`，比较基线 `59139bb`。设计依据为 `P-evidence-governance`，状态 `in-review`。已完整只读核对指定维护正文、架构指南、9 份目录 AGENTS、5 份 skill 源及相关角色源投影。

发现 3 项阻断性表达缺陷：

1. [spec-maintenance/SKILL.md:62](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/.agents/skills/spec-maintenance/SKILL.md:62) 写成“未完成的必要证明不能被语义接受”。这与提案 [README.md:74](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/proposals/evidence-governance/README.md:74)、[composability.md:65](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/architecture-guide/assurance/composability.md:65) 和 [knowledge-flow.md:85](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/knowledge-flow.md:85) 明确允许“接受要求或语义范围并保留未验证状态”的政策冲突。影响是规格维护者会把仅阻止具体机制消费的门槛扩大为阻止语义接受。需明确：可接受要求或语义范围并保留未证明状态；依赖必要证明的机制选择须等证据闭合。

2. [knowledge-flow.md:32](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/knowledge-flow.md:32) 的“提案和研究保留完整讨论及证据”可直接解释为全量归档，与 [organization.md:70](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/organization.md:70) 要求只保留经过整理、直接支持选择及必要复现的材料，以及 [proposals/AGENTS.md:13](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/proposals/AGENTS.md:13) 禁止保存无筛选会话全文和全部工具输出相冲突。需把“完整”限定为足以解释选择、复核观察和必要复现的材料，并显式服从持久化准入。

3. [delivery-planning.md:51](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/delivery-planning.md:51) 将禁止项写成“不得将普通脚本退出成功或 TLC/Alloy 有限检查登记为未执行的演绎证明”。字面上没有禁止把有限检查误报为“已完成”的机器检查演绎证明，无法落实提案 [README.md:44](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/proposals/evidence-governance/README.md:44) 和 [verification.md:41](/data/qiwei/repos/omne-harness-lite/.worktrees/evidence-governance/docs/maintenance/verification.md:41) 的证据类别边界。需明确有限检查不得报告为已完成的机器检查演绎证明。

除上述三项外，9 个直接子目录的职责/准入/转出投影、五个 skill 的其余导航，以及 reviewer、开发者共同契约和验证角色的职责投影，在本次范围内未发现新的阻断问题。

未覆盖范围：未读取 16 个生成输出，采用已给出的静态同步核对结果；未运行测试、形式工具或生成器；未判断业务政策、证明本身的正确性或施工计划可行性。该提案仍为候选，提交中没有新增接受决定、当前架构投影或产品规格发布；因此本评审不表示正式采用或消费者迁移已完成。
