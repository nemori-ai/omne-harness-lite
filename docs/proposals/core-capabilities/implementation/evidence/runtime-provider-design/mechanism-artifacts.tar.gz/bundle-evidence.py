from pathlib import Path
from hashlib import sha256
import json
import tarfile

source = Path(__file__).parent
target = source.parents[1] / 'docs/proposals/core-capabilities/implementation/evidence/runtime-provider-design'
files = sorted(p for p in source.rglob('*') if p.is_file() and
               (p.suffix in ('.py', '.mjs') or p.name.startswith(('source-', 'cordis-probe')) or 'sources' in p.parts))
members = []
with tarfile.open(str(target / 'mechanism-artifacts.tar.gz'), 'w:gz') as archive:
    for path in files:
        relative = str(path.relative_to(source))
        archive.add(str(path), arcname=relative)
        members.append({'path': relative, 'bytes': path.stat().st_size, 'sha256': sha256(path.read_bytes()).hexdigest()})
(target / 'manifest.json').write_text(json.dumps({'baseline': '61e732b979098f568ccd5d21d21939ff0c5036c4', 'members': members}, indent=2) + '\n')
print(json.dumps({'archive': str(target / 'mechanism-artifacts.tar.gz'), 'members': len(members)}))
