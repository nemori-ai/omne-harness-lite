from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from pathlib import Path
import json
import platform
import urllib.request

out = Path(__file__).parent
revision = 'c291e7961a515f6d7af9304e7fd1d257929aef26'
published = Path('/data/qiwei/repos/omne-harness-lite/.worktrees/dsh-core-adoption/node_modules/.pnpm/@deepseek-ai+cordis@4.0.2/node_modules/@deepseek-ai/cordis')
paths = ['docs/cordis-api/service.md', 'docs/cordis-tutorial/03-services.md',
         'docs/cordis-tutorial/02-lifecycle-and-effects.md',
         'vendor/cordis/src/fiber.ts', 'vendor/cordis/src/reflect.ts', 'vendor/cordis/src/service.ts']

def collect(path):
    url = f'https://raw.githubusercontent.com/deepseek-ai/deepseek-harness/{revision}/{path}'
    with urllib.request.urlopen(url, timeout=25) as response:
        data = response.read()
    target = out / 'sources' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    item = {'url': url, 'path': str(target.relative_to(out)), 'sha256': sha256(data).hexdigest(), 'size': len(data)}
    if path.startswith('vendor/cordis/'):
        local = published / path[len('vendor/cordis/'):]
        actual = local.read_bytes()
        item.update(published_path=str(local), published_sha256=sha256(actual).hexdigest(), equal=data == actual)
    return item

with ThreadPoolExecutor(max_workers=6) as pool:
    sources = list(pool.map(collect, paths))
manifest = {'dsh_revision': revision, 'cordis_package': json.loads((published / 'package.json').read_text()),
            'published_entry': str(published / 'lib/index.js'),
            'published_entry_sha256': sha256((published / 'lib/index.js').read_bytes()).hexdigest(),
            'python': platform.python_version(), 'sources': sources,
            'limits': 'Read-only use of an existing 4.0.2 installation. Source byte equality only covers three files; not a product test or full tarball equivalence proof.'}
(out / 'source-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(manifest, ensure_ascii=False, indent=2))
