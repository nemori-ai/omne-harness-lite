// Design mechanism probes only. No product state, journal or user resources.
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { pathToFileURL } from 'node:url'
const manifest = JSON.parse(await readFile(new URL('./source-manifest.json', import.meta.url)))
const { Context } = await import(pathToFileURL(manifest.published_entry))
// Public TS const enum is erased from JS. Values checked in pinned fiber.ts:147.
const FiberState = { PENDING: 0, LOADING: 1, ACTIVE: 2, FAILED: 3, DISPOSED: 4, UNLOADING: 5 }
let checks = 0
const report = (name, observations) => { checks++; console.log(JSON.stringify({ name, observations })) }

// Direct publication stays absent until the owner explicitly finishes recovery.
{
  const ctx = new Context()
  const recovered = Promise.withResolvers()
  let entries = 0
  const consumer = ctx.plugin({ name: 'consumer', inject: ['probeOwner'], apply() { entries++ } })
  const provider = ctx.plugin({ name: 'provider', async apply(c) {
    await recovered.promise
    c.provide('probeOwner', { generation: 'a' })
  } })
  await Promise.resolve()
  assert.equal(ctx.get('probeOwner'), undefined)
  assert.equal(entries, 0)
  recovered.resolve()
  await provider.await()
  await consumer.await()
  assert.equal(entries, 1)
  report('publish-after-recovery', { entries, provider: provider.state, consumer: consumer.state })
  await ctx.fiber.dispose()
}

// Cordis unload invalidates Fiber synchronously, before async effect cleanup.
{
  const ctx = new Context()
  const sequence = []
  let disposed = false
  const p = ctx.plugin({ name: 'owner', apply(c) {
    c.provide('probeOwner', { generation: 'a' })
    c.effect(() => () => { disposed = true; sequence.push('effect-dispose') })
  } })
  await p.await()
  ctx.on('internal/status', (fiber) => {
    // This context has exactly one mounted provider. Event arguments may be traced proxies.
    if (fiber.state === FiberState.UNLOADING) sequence.push('sync-unloading')
  })
  const completion = p.dispose()
  assert.equal(p.state, FiberState.UNLOADING)
  assert.equal(disposed, false)
  assert.deepEqual(sequence, ['sync-unloading'])
  await completion
  assert.equal(disposed, true)
  report('unload-gap', { sequence, consequence: 'effect disposer alone is too late for a synchronous admission fence' })
  await ctx.fiber.dispose()
}

// Captured ordinary values can survive dependency replacement; host fencing is required.
{
  const ctx = new Context()
  const attached = []
  let detached = 0
  const consumer = ctx.plugin({ name: 'consumer', inject: ['probeOwner'], apply(c) {
    attached.push(c.probeOwner)
    c.effect(() => () => { detached++ })
  } })
  const mount = generation => ctx.plugin({ name: `provider-${generation}`, apply(c) { c.provide('probeOwner', { generation }) } })
  const a = mount('a')
  await a.await(); await consumer.await()
  await a.dispose(); await consumer.await()
  assert.equal(consumer.state, FiberState.PENDING)
  const b = mount('b')
  await b.await(); await consumer.await()
  assert.deepEqual(attached.map(x => x.generation), ['a', 'b'])
  assert.equal(detached, 1)
  report('dependency-replacement', { attached: attached.map(x => x.generation), detached, oldReference: attached[0].generation })
  await ctx.fiber.dispose()
}
console.log(JSON.stringify({ checks, node: process.version, scope: 'Cordis mechanisms only; product lifecycle and security remain untested' }))
