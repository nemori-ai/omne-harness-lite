import assert from 'node:assert/strict';

// This isolates the proposed private claim bookkeeping. No product writer,
// real resource or durability guarantee is implemented here.
const states = new WeakMap();
const tickets = new Map();
let nextPosition = 0;
const releaseTasks = [];

function capture(owner) {
  const use = Object.freeze({ owner });
  states.set(use, { phase: 'fresh', claim: null });
  return use;
}
function release(use, reason) {
  const state = states.get(use);
  if (state.phase === 'released') return Promise.resolve({ status: 'released' });
  if (state.phase === 'releasing') return state.completion;
  if (state.claim && reason === 'not_admitted') {
    return Promise.resolve({ status: 'retained', diagnosticId: 'claimed-pin' });
  }
  const claim = state.claim;
  const completion = Promise.resolve().then(() => use.owner.release(reason)).catch(() => ({
    status: 'retained', diagnosticId: 'owner-release-failed',
  })).then(result => {
    states.set(use, result.status === 'released'
      ? { phase: 'released', claim }
      : { phase: 'retained', claim, diagnosticId: result.diagnosticId });
    return result;
  });
  states.set(use, { phase: 'releasing', claim, completion });
  return completion;
}
function submit(operation, canonicalInput, uses) {
  const existing = tickets.get(operation);
  if (existing && existing.canonicalInput !== canonicalInput) throw new Error('input-conflict');
  const input = [...uses];
  for (const use of input) {
    const state = states.get(use);
    const sameClaim = state?.phase === 'claimed' && existing &&
      state.claim.operation === operation && state.claim.canonicalInput === canonicalInput &&
      state.claim.position === existing.position;
    if (state?.phase !== 'fresh' && !sameClaim) throw new Error('invalid-use');
  }
  if (existing) {
    for (const use of input) {
      if (states.get(use).phase === 'fresh') releaseTasks.push(release(use, 'not_admitted'));
    }
    return existing;
  }
  const ticket = Object.freeze({ operation, canonicalInput, position: ++nextPosition, durability: 'pending' });
  tickets.set(operation, ticket);
  for (const use of input) {
    states.set(use, { phase: 'claimed', claim: ticket, retainInvoked: true });
  }
  for (const use of input) assert.equal(use.owner.retain(), undefined);
  return ticket;
}
function resourceOwner() {
  return {
    retained: 0, callbacks: 0, physicalReleaseAttempts: 0, released: false,
    verified: false, failRelease: false,
    retain() { this.retained++; return undefined; },
    async release(reason) {
      this.callbacks++;
      if (reason !== 'not_admitted' && !this.verified) {
        return { status: 'retained', diagnosticId: 'unknown-work' };
      }
      this.physicalReleaseAttempts++;
      if (this.failRelease) throw new Error('release failed');
      this.released = true;
      return { status: 'released' };
    },
  };
}

const originalOwner = resourceOwner();
const original = capture(originalOwner);
const ticket = submit('op-1', '{"input":1}', [original]);
assert.equal(submit('op-1', '{"input":1}', [original]), ticket);
assert.equal(ticket.durability, 'pending');
assert.equal(originalOwner.retained, 1);
assert.equal(originalOwner.callbacks, 0);
assert.throws(() => submit('op-2', '{"input":1}', [original]), /invalid-use/);
assert.equal(nextPosition, 1);
assert.equal(originalOwner.callbacks, 0);

const temporaryOwner = resourceOwner();
const temporary = capture(temporaryOwner);
assert.equal(submit('op-1', '{"input":1}', [temporary]), ticket);
assert.equal(states.get(temporary).phase, 'releasing');
assert.throws(() => submit('op-3', '{"input":1}', [temporary]), /invalid-use/);
await Promise.all(releaseTasks);
assert.equal(temporaryOwner.retained, 0);
assert.equal(temporaryOwner.physicalReleaseAttempts, 1);
assert.equal(states.get(temporary).phase, 'released');
assert.equal(states.get(original).phase, 'claimed');
assert.equal(originalOwner.callbacks, 0);
assert.throws(() => submit('op-3', '{"input":1}', [temporary]), /invalid-use/);

const refused = await release(original, 'not_admitted');
assert.equal(refused.status, 'retained');
assert.equal(states.get(original).phase, 'claimed');
assert.equal(originalOwner.callbacks, 0);
const unknown = await release(original, 'settled');
assert.equal(unknown.status, 'retained');
assert.equal(states.get(original).phase, 'retained');
assert.equal(states.get(original).claim, ticket);
assert.equal(originalOwner.physicalReleaseAttempts, 0);
assert.throws(() => submit('op-4', '{"input":1}', [original]), /invalid-use/);

originalOwner.verified = true;
originalOwner.failRelease = true;
assert.equal((await release(original, 'settled')).status, 'retained');
assert.equal(states.get(original).claim, ticket);
assert.equal(originalOwner.released, false);
originalOwner.failRelease = false;
const firstRelease = release(original, 'settled');
const sameRelease = release(original, 'settled');
assert.equal(firstRelease, sameRelease);
assert.equal((await firstRelease).status, 'released');
assert.equal(states.get(original).phase, 'released');
assert.equal(states.get(original).claim, ticket);
const previousCallbacks = originalOwner.callbacks;
assert.equal((await release(original, 'settled')).status, 'released');
assert.equal(originalOwner.callbacks, previousCallbacks);
assert.throws(() => submit('op-5', '{"input":1}', [original]), /invalid-use/);
assert.throws(() => submit('op-1', '{"input":1}', [original]), /invalid-use/);
assert.equal(tickets.get('op-1'), ticket);
assert.equal(nextPosition, 1);
console.log(JSON.stringify({
  status: 'passed',
  cases: ['same pending ticket retains once without release', 'different operation rejected before position',
    'duplicate cleans only fresh temporary pin', 'releasing and released pins reject claim',
    'claimed pin rejects not_admitted without owner call', 'unknown preserves original claim and resource',
    'release failure remains retained', 'concurrent release shares one completion',
    'released pin stays invalid while original operation remains queryable'],
  limits: 'Private-state mechanism probe with in-memory tickets and simulated resource owner; no product implementation, real cleanup or durability evidence.',
}, null, 2));
