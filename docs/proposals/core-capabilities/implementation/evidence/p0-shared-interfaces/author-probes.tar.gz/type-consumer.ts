import type {
  AdmissionHost, AdmissionCoordinator, CommitRequest, OperationInput, OperationRef,
  PreparedOperation, PreparedCommit, OwnerPublication, ExactUse, ExactUseIssuer,
  AcquisitionCleanup, AcquireResult, OperationLookup, ConflictReceipt,
} from './interfaces.js';

declare const host: AdmissionHost;
declare const coordinator: AdmissionCoordinator;
declare const operation: OperationRef;
declare const input: OperationInput;
declare const preparedOperation: PreparedOperation;
declare const request: CommitRequest;
declare const commit: PreparedCommit;
declare const issuer: ExactUseIssuer;

coordinator.prepareOperation(operation, input);
coordinator.prepare(request);
coordinator.enter(frame => coordinator.lookupPrepared(frame, preparedOperation));
coordinator.enter(frame => coordinator.submit(frame, {
  composition:'owner_change', commit, publications:[], uses:[],
})); // compile boundary only; runtime rejects missing participants.
host.createUseIssuer('tools');
issuer.capture({resourceId:'tool-1',generation:'generation-1',epoch:'epoch-1'}, {
  retainAt: () => undefined,
  release: async () => ({status:'released'}),
});

// @ts-expect-error A consumer cannot directly commit to the writer.
coordinator.commit(commit);
// @ts-expect-error A consumer cannot quarantine the underlying writer.
coordinator.quarantine('diagnostic-1');
// @ts-expect-error A consumer cannot mint arbitrary owner capabilities.
coordinator.createUseIssuer('tools');
// @ts-expect-error Promise-returning logical publication is not synchronous.
const asyncLogical: OwnerPublication['publishLogical'] = async () => undefined;
// @ts-expect-error Promise-returning durable publication is not synchronous.
const asyncDurable: OwnerPublication['publishDurable'] = async () => undefined;
// @ts-expect-error Promise-returning retainAt is not synchronous.
const asyncRetain: ExactUse['retainAt'] = async () => undefined;
// @ts-expect-error An unissued structural object cannot satisfy ExactUse.
const forgedUse: ExactUse = {binding:{owner:'tools',resourceId:'t',generation:'g',epoch:'e'},retainAt:()=>undefined,release:async()=>({status:'released'})};

function handleAcquire(result: AcquireResult): AcquisitionCleanup | undefined {
  if (result.status === 'unavailable' && result.cleanup.status === 'retained') {
    result.cleanup.owner.inspect();
    void result.cleanup.owner.retryRelease(); // compile shape only; not executed by this probe.
    return result.cleanup.owner;
  }
  return undefined;
}
function readConflict(result: OperationLookup): ConflictReceipt | undefined {
  return result.status === 'conflict' ? result.receipt : undefined;
}
void handleAcquire; void readConflict;
void asyncLogical; void asyncDurable; void asyncRetain; void forgedUse;
