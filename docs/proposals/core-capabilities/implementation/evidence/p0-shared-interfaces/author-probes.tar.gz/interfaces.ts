export type JsonValue = null | boolean | number | string | JsonObject | readonly JsonValue[];
export type JsonObject = { readonly [key: string]: JsonValue };
export type OpaqueId = string;
export type SessionRef = Readonly<{ tenantId: OpaqueId; sessionId: OpaqueId }>;
export type AgentRef = SessionRef & Readonly<{ incarnationId: OpaqueId }>;
export type UserRef = Readonly<{ userId: OpaqueId }>;
export type MembershipRef = Readonly<{ tenantId: OpaqueId; userId: OpaqueId }>;
export type DefinitionRef = Readonly<{ ownerTenantId: OpaqueId; definitionId: OpaqueId }>;
export type DefinitionVersion = Readonly<{ definition: DefinitionRef; version: OpaqueId }>;
export type RunRef = Readonly<{ session: SessionRef; runId: OpaqueId }>;
export type StepRef = Readonly<{ run: RunRef; stepId: OpaqueId }>;
export type WorkRef = Readonly<{ tenantId: OpaqueId; workId: OpaqueId }>;
export type WorkOwner = StepRef | WorkRef;
export type MediaRef = Readonly<{ tenantId: OpaqueId; mediaId: OpaqueId }>;
export type MediaMetadata = Readonly<{
  media: MediaRef; sha256: string; byteLength: number; mimeType: string; filename?: string;
}>;
export type ResourceRef = Readonly<{
  tenantId: OpaqueId; kind: string; resourceId: OpaqueId; version: OpaqueId;
}>;
export type SecretRef = Readonly<{
  kind: "secret_version"; tenantId: OpaqueId; secretId: OpaqueId; version: OpaqueId;
}>;
export type Binding = Readonly<{
  implementationId: OpaqueId; generation: OpaqueId; configurationRevision: OpaqueId;
  environment: ResourceRef; parserVersion: OpaqueId;
}>;
export type Confirmation =
  | Readonly<{ confirmation: "none" | "before_effect"; provisionalContract?: ResourceRef }>
  | Readonly<{ confirmation: "provisional"; provisionalContract: ResourceRef }>;
export type Action = Readonly<{
  tenantId: OpaqueId; callId: OpaqueId; attemptId: OpaqueId; owner: WorkOwner;
  definition: DefinitionVersion; toolKey: OpaqueId; commandKey: OpaqueId;
  declarationVersion: OpaqueId; binding: Binding; params: JsonObject;
  resources: readonly ResourceRef[]; permissions: readonly string[];
  grantorKinds: readonly string[]; impact: string;
}> & Confirmation;
export type CallRef = Readonly<{ owner: WorkOwner; callId: OpaqueId; attemptId: OpaqueId }>;
export type RequestRef = Readonly<{ tenantId: OpaqueId; requestId: OpaqueId }>;
export type Money = Readonly<{ integer: string; scale: number; currency: string }>;
export type OperationRef = Readonly<{
  namespace: OpaqueId; principalId: OpaqueId; operationId: OpaqueId;
}>;
export type Decision = Readonly<{
  request: RequestRef; contentVersion: OpaqueId; outcomeVersion: OpaqueId; actor: UserRef;
}> & (
  | Readonly<{ outcome: "answer"; answer: JsonValue }>
  | Readonly<{ outcome: "approve" | "reject"; answer?: never }>
);
export type TextBlock = Readonly<{ blockId: OpaqueId; kind: "text"; text: string }>;
export type MediaBlock = Readonly<{
  blockId: OpaqueId; kind: "image" | "audio" | "video" | "file"; media: MediaRef;
  delivery: "model_native" | "agent_attachment";
}>;
export type ToolCallBlock = Readonly<{
  blockId: OpaqueId; kind: "tool_call"; call: CallRef; action: Action;
}>;
export type ToolResultBlock = Readonly<{
  blockId: OpaqueId; kind: "tool_result"; call: CallRef;
  outcome: "succeeded" | "failed" | "denied_before_execution" |
    "cancelled_before_execution" | "interrupted" | "unknown";
  value: JsonValue;
}>;
export type DeferredReceiptBlock = Readonly<{
  blockId: OpaqueId; kind: "deferred_receipt"; call: CallRef; request: RequestRef;
  continuationId: OpaqueId; status: "pending";
}>;
export type ContentBlock = TextBlock | MediaBlock | ToolCallBlock | ToolResultBlock | DeferredReceiptBlock;
export type InputBlock = TextBlock | MediaBlock;
export type Input = Readonly<{
  session: SessionRef; inputId: OpaqueId; revision: number; content: readonly InputBlock[];
  busyBehavior: "queue" | "interrupt_then_run"; literal: boolean;
}>;
export type ProtocolVersion = Readonly<{ protocolId: string; version: string }>;
export type BackgroundDeclaration =
  | Readonly<{ mode: "unsupported" }>
  | Readonly<{
      mode: "supported"; executionOwnerProtocol: ProtocolVersion;
      requiredResources: readonly string[]; reconnectProtocol: ProtocolVersion;
      form: "independent_execution";
      automatic?: Readonly<{ thresholdMs: number; stopMarginMs: number }>;
    }>;
export type AuthorizationDeclaration = Readonly<{
  version: string; permissions: readonly string[];
  resourceResolver: Readonly<{ resolverId: string; version: string }>;
  grantorKinds: readonly string[]; impactTemplate: string;
}> & Confirmation;
export type Command = Readonly<{
  commandKey: string; inputSchema: JsonObject | boolean; outputSchema: JsonObject | boolean;
  authorization: AuthorizationDeclaration; effect: "read" | "write" | "external";
  cancellation: "supported" | "unsupported"; background: BackgroundDeclaration;
  requiredSkills: readonly DefinitionVersion[]; environmentCapabilities: readonly string[];
}>;
export type ToolDefinition = Readonly<{
  definition: DefinitionVersion; toolKey: string; commands: readonly Command[];
}>;
export interface DataTypes {
  OpaqueId: OpaqueId; SessionRef: SessionRef; AgentRef: AgentRef; UserRef: UserRef;
  MembershipRef: MembershipRef; DefinitionRef: DefinitionRef; DefinitionVersion: DefinitionVersion;
  RunRef: RunRef; StepRef: StepRef; WorkRef: WorkRef; WorkOwner: WorkOwner;
  MediaRef: MediaRef; MediaMetadata: MediaMetadata; ResourceRef: ResourceRef; SecretRef: SecretRef;
  Binding: Binding; Action: Action; CallRef: CallRef; RequestRef: RequestRef; Money: Money;
  OperationRef: OperationRef; Decision: Decision; Input: Input; ContentBlock: ContentBlock;
  AuthorizationDeclaration: AuthorizationDeclaration; Command: Command;
  ToolDefinition: ToolDefinition; BackgroundDeclaration: BackgroundDeclaration; InputBlock: InputBlock;
}
export type ValidationIssue = Readonly<{
  path: string; code: "invalid_json" | "schema" | "unsupported_number" | "capacity";
  message: string;
}>;
export type Checked<T> =
  | Readonly<{ ok: true; value: T }>
  | Readonly<{ ok: false; issues: readonly ValidationIssue[] }>;
export type JsonLimits = Readonly<{ maxBytes: number; maxDepth: number; maxNodes: number }>;
export declare function parseJson(text: string, limits: JsonLimits): Checked<JsonValue>;
export declare function copyJson(value: unknown, limits: JsonLimits): Checked<JsonValue>;
export declare function parseData<K extends keyof DataTypes>(
  type: K, value: unknown, limits: JsonLimits,
): Checked<DataTypes[K]>;
export declare function canonicalJson(value: JsonValue): string;
export declare function equalJson(a: JsonValue, b: JsonValue): boolean;

export type Counter = string; // /^(0|[1-9][0-9]*)$/; never compare lexically
export type Principal =
  | Readonly<{ kind: "user"; user: UserRef }>
  | Readonly<{ kind: "system"; systemId: OpaqueId }>;
export type StreamRef = Readonly<{
  namespace: OpaqueId; owner: OpaqueId;
  scope: Readonly<{ kind: "tenant"; tenantId: OpaqueId }> | Readonly<{ kind: "system" }>;
  streamId: OpaqueId;
}>;
export type Causality = Readonly<{
  parentOperation?: OperationRef; initiator?: Principal; session?: SessionRef; work?: WorkOwner;
  call?: CallRef; request?: RequestRef; agent?: AgentRef;
  definition?: DefinitionVersion; binding?: Binding;
}>;
export type OwnedRecord<Kind extends string = string, Version extends string = string,
  Data extends JsonValue = JsonValue> = Readonly<{
  kind: Kind; version: Version; data: Data;
}>;
export type StreamAppend = Readonly<{
  stream: StreamRef; expectedRevision: Counter; records: readonly OwnedRecord[];
}>;
export type OperationInput = Readonly<{
  format: "core-operation/1"; operationKind: string;
  tenantId: OpaqueId | null; principal: Principal; target: JsonValue;
  arguments: JsonValue; preconditions: JsonValue; causality: Causality;
}>;
export type CommitRequest = Readonly<{
  operation: PreparedOperation;
  appends: readonly StreamAppend[]; result: JsonValue; requiredUses: readonly UseRequirement[];
}>;
export type UseBinding = Readonly<{
  owner: string; resourceId: OpaqueId; generation: OpaqueId; epoch: OpaqueId;
}>;
export type UseRequirement = Readonly<{ recordOwner: string; binding: UseBinding }>;
export type Position = Readonly<{
  coordinationDomain: OpaqueId; writerEpoch: Counter; commitId: OpaqueId; seq: Counter;
}>;
export type Watermark = Readonly<{
  coordinationDomain: OpaqueId; seq: Counter; commitId: OpaqueId | null;
}>;
export type Receipt<Outcome extends RecordedOutcome = RecordedOutcome> = Readonly<{
  position: Position; operation: OperationRef; inputDigest: string; outcome: Outcome;
  streams: readonly Readonly<{ stream: StreamRef; revision: Counter }>[];
}>;
export type CommitEnvelope = Readonly<{
  formatVersion: "core-journal/1"; position: Position; operation: OperationRef;
  inputEncoding: "core-json/1"; canonicalInput: string; inputDigest: string;
  appends: readonly StreamAppend[]; outcome: RecordedOutcome;
  requiredUses: readonly UseRequirement[];
}>;
export type Rejection = Readonly<{
  code: "invalid" | "capacity" | "stale_writer" | "closed" | "wrong_domain" |
    "namespace_denied" | "invalid_owner" | "unsupported_format";
  message: string;
}>;
export type RecordConflict =
  | Readonly<{ kind: "operation_input"; operation: OperationRef }>
  | Readonly<{
      kind: "revision"; currents: readonly Readonly<{ stream: StreamRef; revision: Counter }>[];
    }>;
export type RevisionConflict = Extract<RecordConflict, { kind: "revision" }>;
export type RecordedOutcome =
  | Readonly<{ status: "committed"; result: JsonValue }>
  | Readonly<{ status: "conflict"; conflict: RevisionConflict }>;
export type CommittedReceipt = Receipt<Extract<RecordedOutcome, { status: "committed" }>>;
export type ConflictReceipt = Receipt<Extract<RecordedOutcome, { status: "conflict" }>>;
export type CommitResult =
  | Readonly<{ status: "committed"; receipt: CommittedReceipt }>
  | Readonly<{ status: "conflict"; conflict: RevisionConflict; receipt: ConflictReceipt }>
  | Readonly<{ status: "conflict"; conflict: Extract<RecordConflict, { kind: "operation_input" }>; receipt: null }>
  | Readonly<{ status: "rejected"; reason: Rejection; receipt: null }>
  | Readonly<{ status: "unavailable"; reason: string }>
  | Readonly<{ status: "unknown"; operation: OperationRef; diagnosticId: OpaqueId }>;
export type Head = Readonly<{
  watermark: Watermark; streams: readonly Readonly<{ stream: StreamRef; revision: Counter }>[];
}>;
export type ReadResult<T> =
  | Readonly<{ status: "read"; value: T }>
  | Readonly<{ status: "not_at_watermark"; available: Watermark }>
  | Readonly<{ status: "rejected"; reason: Rejection }>
  | Readonly<{ status: "unavailable"; reason: string }>;
export type OperationLookup =
  | Readonly<{ status: "committed"; receipt: CommittedReceipt; watermark: Watermark }>
  | Readonly<{ status: "conflict"; conflict: RevisionConflict; receipt: ConflictReceipt; watermark: Watermark }>
  | Readonly<{ status: "pending_durability"; position: Position; watermark: Watermark }>
  | Readonly<{ status: "not_committed"; verifiedThrough: Watermark }>
  | Readonly<{ status: "unknown"; operation: OperationRef; diagnosticId: OpaqueId }>
  | Readonly<{ status: "unavailable"; reason: string }>;
export interface RecordReader {
  readHead(streams: readonly StreamRef[]): Promise<ReadResult<Head>>;
  readRange(query: Readonly<{
    afterSeq: Counter; through: Watermark; limit: number;
  }>): Promise<ReadResult<Readonly<{
    envelopes: readonly CommitEnvelope[]; through: Watermark; nextAfterSeq: Counter; complete: boolean;
  }>>>;
  lookupOperation(operation: OperationRef): Promise<OperationLookup>;
}
declare const preparedOperationBrand: unique symbol;
export type PreparedOperation = Readonly<{
  [preparedOperationBrand]: true; operation: OperationRef; canonicalInput: string;
}>;
declare const preparedCommitBrand: unique symbol;
export type PreparedCommit = Readonly<{
  [preparedCommitBrand]: true; operation: OperationRef; canonicalInput: string;
  owners: readonly string[]; requiredUses: readonly UseRequirement[];
}>;
export type PendingCommit = Readonly<{
  status: "pending_durability"; position: Position; operation: OperationRef;
  disposition: "apply" | "record_conflict";
  completion: Promise<CommitResult>;
}>;
export type Submission = PendingCommit | CommitResult;
export interface RecordPreparation {
  prepareOperation(operation: OperationRef, input: OperationInput): Checked<PreparedOperation>;
  prepare(request: CommitRequest): Checked<PreparedCommit>;
}
export interface RecordWriter extends RecordReader, RecordPreparation {
  readonly coordinationDomain: OpaqueId;
  readonly writerEpoch: Counter;
  lookupPrepared(operation: PreparedOperation): Submission | Readonly<{ status: "not_seen" }>;
  commit(prepared: PreparedCommit): Submission;
  quarantine(diagnosticId: OpaqueId): void;
  closeWriter(): Promise<CloseResult>;
}
export type CloseResult =
  | Readonly<{ status: "closed"; watermark: Watermark }>
  | Readonly<{
      status: "blocked"; watermark: Watermark; diagnosticId: OpaqueId;
      pending: readonly OperationRef[]; lockHeld: boolean;
    }>;
export type AcquisitionCleanupState = Readonly<{
  cleanupId: OpaqueId; coordinationDomain: OpaqueId;
  phase: "retained" | "releasing" | "released";
  lock: "held" | "released" | "unknown";
  diagnosticId: OpaqueId;
}>;
export interface AcquisitionCleanup {
  readonly cleanupId: OpaqueId;
  inspect(): AcquisitionCleanupState;
  retryRelease(): Promise<AcquisitionCleanupState>;
}
export type AcquireResult =
  | Readonly<{ status: "acquired"; writer: RecordWriter; recovered: Watermark }>
  | Readonly<{ status: "busy" }>
  | Readonly<{
      status: "unavailable"; reason: string; diagnosticId: OpaqueId;
      cleanup: Readonly<{ status: "released" }> |
        Readonly<{ status: "retained"; owner: AcquisitionCleanup }>;
    }>;
export interface RecordProvider {
  readonly reader: RecordReader;
  acquireWriter(): Promise<AcquireResult>;
}
export type RecordLimits = CodecLimits & Readonly<{
  maxPendingCommits: number; maxPendingBytes: number;
}>;
export type NamespaceBinding = Readonly<{
  namespace: string; owners: readonly string[]; allowSystemScope: boolean;
}>;
export type JsonlProviderOptions = Readonly<{
  coordinationDomain: OpaqueId; directory: string;
  bindings: readonly NamespaceBinding[]; limits: RecordLimits;
}>;
// Exported by @omne-harness-lite/jsonl, not by records.
export declare function createJsonlProvider(options: JsonlProviderOptions): RecordProvider;

export type CompositionKind = "owner_change" | "input_run" | "action_execution" |
  "request_wait" | "answer_consequence" | "budget_call" | "content_media";
export type AdmissionFailure = Readonly<{
  status: "denied" | "conflict" | "unavailable"; owner: string; code: string;
}>;
declare const gateFrameBrand: unique symbol;
export type GateFrame = Readonly<{ [gateFrameBrand]: true }>;
export type OwnerPublication = Readonly<{
  owner: string;
  publishLogical: (position: Position, frame: GateFrame) => undefined;
  publishDurable: (receipt: Receipt, frame: GateFrame) => undefined;
}>;
export type ReleaseResult =
  | Readonly<{ status: "released" }>
  | Readonly<{ status: "retained"; diagnosticId: OpaqueId }>;
export type ExactUse = Readonly<{
  [exactUseBrand]: true;
  binding: UseBinding;
  retainAt: (position: Position, frame: GateFrame) => undefined;
  release: (reason: "not_admitted" | "verified_not_committed" | "settled") => Promise<ReleaseResult>;
}>;
declare const exactUseBrand: unique symbol;
export interface ExactUseIssuer {
  capture(binding: Omit<UseBinding, "owner">, callbacks: Readonly<{
    retainAt: ExactUse["retainAt"]; release: ExactUse["release"];
  }>): ExactUse;
}
// Private admission bookkeeping; not an exported data contract or resource owner.
type ExactUseClaim = Readonly<{
  operation: OperationRef; canonicalInput: string; position: Position;
}>;
type ExactUseLifecycle =
  | Readonly<{ phase: "fresh" }>
  | Readonly<{ phase: "claimed"; claim: ExactUseClaim; retainInvoked: boolean }>
  | Readonly<{ phase: "releasing"; claim: ExactUseClaim | null; completion: Promise<ReleaseResult> }>
  | Readonly<{ phase: "retained"; claim: ExactUseClaim | null; diagnosticId: OpaqueId }>
  | Readonly<{ phase: "released"; claim: ExactUseClaim | null }>;
export type PreparedAdmission = Readonly<{
  composition: CompositionKind;
  commit: PreparedCommit;
  publications: readonly OwnerPublication[];
  uses: readonly ExactUse[];
}>;
export type AdmissionCompletion = Exclude<CommitResult, { status: "committed" }> |
  Readonly<{
    status: "committed"; receipt: CommittedReceipt; publication: "ready" | "blocked";
    diagnosticId?: OpaqueId;
  }>;
export type PendingAdmission = Readonly<{
  status: "pending_durability"; position: Position; operation: OperationRef;
  disposition: "apply" | "record_conflict";
  completion: Promise<AdmissionCompletion>;
}>;
export type AdmissionResult = PendingAdmission | AdmissionCompletion | AdmissionFailure;
export type CoordinatorStatus = Readonly<{
  phase: "open" | "closing" | "quarantined" | "closed";
  logical: Watermark; durable: Watermark; diagnosticId?: OpaqueId;
}>;
export interface AdmissionCoordinator extends RecordPreparation {
  enter<T>(work: (frame: GateFrame) => T): T;
  lookupPrepared(frame: GateFrame, operation: PreparedOperation): AdmissionResult | Readonly<{ status: "not_seen" }>;
  submit(frame: GateFrame, prepared: PreparedAdmission): AdmissionResult;
  status(): CoordinatorStatus;
  close(): Promise<CloseResult>;
}
export type AdmissionHost = Readonly<{
  coordinator: AdmissionCoordinator;
  createUseIssuer: (owner: string) => ExactUseIssuer;
}>;
export declare function createAdmissionCoordinator(writer: RecordWriter): AdmissionHost;

export type JournalLine = Readonly<{
  formatVersion: "core-journal/1"; payload: string; byteLength: number; sha256: string;
}>;
export type CodecLimits = JsonLimits & Readonly<{ maxLineBytes: number; maxPayloadBytes: number }>;
export type DecodedLine = Readonly<{
  envelope: CommitEnvelope; payload: string; byteLength: number; sha256: string;
}>;
export declare function encodeEnvelope(envelope: CommitEnvelope, limits: CodecLimits): Checked<Uint8Array>;
export declare function decodeLine(completeLine: Uint8Array, limits: CodecLimits): Checked<DecodedLine>;

export interface DomainLock {
  release(): Promise<Readonly<{ status: "released" }> | Readonly<{
    status: "failed"; diagnosticId: OpaqueId;
  }>>;
}
export interface DomainLockProvider {
  tryAcquire(): Promise<Readonly<{ status: "acquired"; lock: DomainLock }> |
    Readonly<{ status: "busy" }> | Readonly<{ status: "unavailable"; reason: string }>>;
}