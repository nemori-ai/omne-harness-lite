import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

// Isolated language-mechanism probes; these are not product admission code.
const late=[];
function requireSync(callback, phase) {
  const result=callback();
  if (result !== undefined) {
    Promise.resolve(result).catch(error => late.push({phase,message:error.message}));
    throw new Error(`async-or-invalid:${phase}`);
  }
}
for(const phase of ['publishLogical','publishDurable','retainAt']) {
  assert.throws(()=>requireSync(async()=>{throw new Error('late-failure');},phase),/async-or-invalid/);
}
await new Promise(resolve=>setImmediate(resolve));
assert.deepEqual(late.map(x=>x.phase),['publishLogical','publishDurable','retainAt']);
assert.ok(late.every(x=>x.message==='late-failure'));
let calls=0;
requireSync(()=>{calls++;return undefined;},'valid');
assert.equal(calls,1);
assert.throws(()=>requireSync(()=>42,'wrong-return'),/async-or-invalid/);

function capture(meta,publications,uses) {
  const capturedPublications=Object.freeze(publications.map(p=>Object.freeze({
    owner:p.owner,publishLogical:p.publishLogical,publishDurable:p.publishDurable,
  })));
  const capturedUses=Object.freeze(uses.map(u=>Object.freeze({
    binding:Object.freeze({...u.binding}),retainAt:u.retainAt,release:u.release,
  })));
  const owners=capturedPublications.map(p=>p.owner).sort();
  assert.deepEqual(owners,meta.owners);
  assert.equal(new Set(owners).size,owners.length);
  assert.deepEqual(capturedUses.map(u=>JSON.stringify(u.binding)).sort(),
    meta.requiredUses.map(u=>JSON.stringify(u.binding)).sort());
  return {capturedPublications,capturedUses};
}
const original=()=>undefined;
const rows=[{owner:'budget',publishLogical:original,publishDurable:original},
  {owner:'tools',publishLogical:original,publishDurable:original}];
const pin={binding:{owner:'tools',resourceId:'tool',generation:'g1',epoch:'e1'},
  retainAt:original,release:async()=>({status:'released'})};
const meta={owners:['budget','tools'],requiredUses:[{recordOwner:'tools',binding:{...pin.binding}}]};
assert.throws(()=>capture(meta,rows.slice(1),[pin]));
assert.throws(()=>capture(meta,[rows[0],rows[0],rows[1]],[pin]));
assert.throws(()=>capture(meta,rows,[{...pin,binding:{...pin.binding,owner:'other'}}]));
const captured=capture(meta,rows,[pin]);
rows[0].publishDurable=()=>{throw new Error('changed');};
rows.splice(0,2); pin.binding.generation='g2'; pin.retainAt=()=>{throw new Error('changed');};
assert.equal(captured.capturedPublications.length,2);
assert.equal(captured.capturedPublications[0].publishDurable,original);
assert.equal(captured.capturedUses[0].binding.generation,'g1');
assert.equal(captured.capturedUses[0].retainAt,original);

const doc=readFileSync('../../docs/proposals/core-capabilities/implementation/shared-interfaces.md','utf8');
const lines=[...doc.matchAll(/```json\n([\s\S]*?)\n```/g)]
  .map(x=>x[1]).filter(x=>x.includes('"payload":'));
assert.equal(lines.length,2);
for(const [index,name] of ['g01.jsonl','g10.jsonl'].entries()) {
  const text=readFileSync(name,'utf8');
  assert.equal(lines[index]+'\n',text);
  const line=JSON.parse(text);
  assert.equal(Buffer.byteLength(line.payload),line.byteLength);
  assert.equal(createHash('sha256').update(line.payload).digest('hex'),line.sha256);
}
const conflict=JSON.parse(JSON.parse(readFileSync('g10.jsonl','utf8')).payload);
assert.equal(conflict.outcome.status,'conflict');
assert.equal(conflict.outcome.conflict.currents[0].revision,'2');
assert.equal(JSON.parse(conflict.canonicalInput).preconditions.expectedRevision,'3');
assert.equal(conflict.appends.length,1);
assert.equal(conflict.appends[0].stream.owner,'durable-records');
assert.deepEqual(conflict.requiredUses,[]);
console.log(JSON.stringify({
  status:'passed',synchronousCallbacks:3,lateRejectionsObserved:late.length,
  invalidParticipantScenarios:3,snapshotMutationScenarios:4,exactGoldenLines:2,
  limits:'Language-mechanism and exact fixture probes only; no product writer, durability, lifecycle or complete admission implementation.',
},null,2));
