import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import Ajv from 'ajv/dist/2020.js';
import { visit } from 'jsonc-parser';

const root = '../..';
const ari = JSON.parse(readFileSync(`${root}/spec/data/agent-runtime-identity/v1/schema.json`, 'utf8'));
const cd = JSON.parse(readFileSync(`${root}/spec/data/core-work/v1/schema.json`, 'utf8'));
const ajv = new Ajv({ strictSchema: true, strictNumbers: true, strictTypes: false,
  strictRequired: false, allowUnionTypes: true, ownProperties: true,
  coerceTypes: false, useDefaults: false, removeAdditional: false });
ajv.addSchema(ari); ajv.addSchema(cd);
let compiled = 0;
for (const schema of [ari, cd]) {
  for (const name of Object.keys(schema.$defs)) {
    assert.equal(typeof ajv.getSchema(`${schema.$id}#/$defs/${name}`), 'function');
    compiled++;
  }
}
const action = ajv.getSchema(`${cd.$id}#/$defs/OperationRef`);
assert.equal(action({namespace:'core',principalId:'u',operationId:'o'}),true);
assert.equal(action({namespace:'core',principalId:'u',operationId:'o',other:true}),false);

function seen(text) {
  const stack = [];
  let duplicates=0, errors=0;
  visit(text, {
    onObjectBegin(){stack.push(new Set());},
    onObjectProperty(name){const names=stack.at(-1); if(names.has(name))duplicates++; names.add(name);},
    onObjectEnd(){stack.pop();},
    onError(){errors++;},
  },{disallowComments:true,allowTrailingComma:false,allowEmptyContent:false});
  return {duplicates,errors};
}
assert.deepEqual(seen('{"a":1,"\\u0061":2}'), {duplicates:1, errors:0});
assert.ok(seen('{"a":1,}').errors>0);
assert.ok(seen('{/*c*/"a":1}').errors>0);
assert.ok(seen('').errors>0);
assert.deepEqual(seen('{"a":{"a":1},"b":2}'),{duplicates:0,errors:0});

function canonical(v) {
  if (Array.isArray(v)) return `[${v.map(canonical).join(',')}]`;
  if (v && typeof v === 'object') return `{${Object.keys(v).sort().map(k=>`${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;
  return JSON.stringify(v);
}
const sha = value => createHash('sha256').update(value,'utf8').digest('hex');
const principal = {kind:'system',systemId:'local-host'};
const input = {format:'core-operation/1',operationKind:'writer.acquire',tenantId:null,principal,
  target:'domain-1',arguments:{epoch:'1'},preconditions:{previousEpoch:'0'},causality:{}};
const canonicalInput = canonical(input);
const envelope={formatVersion:'core-journal/1',position:{coordinationDomain:'domain-1',writerEpoch:'1',commitId:'commit-1',seq:'1'},
  operation:{namespace:'core.writer',principalId:canonical(principal),operationId:'epoch:1'},
  inputEncoding:'core-json/1',canonicalInput,inputDigest:sha(canonicalInput),
  appends:[{stream:{namespace:'core.writer',owner:'durable-records',scope:{kind:'system'},streamId:'writer-epochs'},
    expectedRevision:'0',records:[{kind:'writer.epoch',version:'1',data:{epoch:'1'}}]}],
  outcome:{status:'committed',result:{epoch:'1'}},requiredUses:[]};
const payload=canonical(envelope);
const line=canonical({formatVersion:'core-journal/1',payload,byteLength:Buffer.byteLength(payload),sha256:sha(payload)})+'\n';
writeFileSync('g01.jsonl',line);
writeFileSync('g01-envelope.json',canonical(envelope)+'\n');
const conflictStream={namespace:'core',owner:'session',scope:{kind:'tenant',tenantId:'tenant-1'},streamId:'session-1'};
const conflict={kind:'revision',currents:[{stream:conflictStream,revision:'2'}]};
const conflictInput={format:'core-operation/1',operationKind:'session.edit',tenantId:'tenant-1',
  principal:{kind:'user',user:{userId:'user-1'}},target:{sessionId:'session-1'},
  arguments:{text:'hello'},preconditions:{expectedRevision:'3'},causality:{}};
const conflictEnvelope={formatVersion:'core-journal/1',
  position:{coordinationDomain:'domain-1',writerEpoch:'1',commitId:'commit-4',seq:'4'},
  operation:{namespace:'core',principalId:canonical(conflictInput.principal),operationId:'edit-1'},
  inputEncoding:'core-json/1',canonicalInput:canonical(conflictInput),inputDigest:sha(canonical(conflictInput)),
  appends:[{stream:{namespace:'core.records',owner:'durable-records',scope:{kind:'tenant',tenantId:'tenant-1'},streamId:'operation-outcomes'},
    expectedRevision:'0',records:[{kind:'operation.conflict',version:'1',data:conflict}]}],
  outcome:{status:'conflict',conflict},requiredUses:[]};
const conflictPayload=canonical(conflictEnvelope);
const conflictLine=canonical({formatVersion:'core-journal/1',payload:conflictPayload,byteLength:Buffer.byteLength(conflictPayload),sha256:sha(conflictPayload)})+'\n';
writeFileSync('g10.jsonl',conflictLine);
const doc=readFileSync(`${root}/docs/proposals/core-capabilities/implementation/shared-interfaces.md`,'utf8');
const snippets=[...doc.matchAll(/```ts\n([\s\S]*?)\n```/g)].map(x=>x[1]);
writeFileSync('interfaces.ts',snippets.join('\n\n'));
const map=doc.match(/export interface DataTypes \{([\s\S]*?)\n\}/)[1];
const mapped=[...map.matchAll(/\b(\w+):/g)].map(x=>x[1]);
assert.deepEqual([...new Set([...Object.keys(ari.$defs),...Object.keys(cd.$defs)])].sort(),mapped.sort());
console.log(JSON.stringify({node:process.version,ajv:'8.20.0',jsoncParser:'3.3.1',compiledSchemaDefinitions:compiled,
  distinctMappedDefinitions:mapped.length,parserAssertions:5,operationAssertions:2,
  golden:{inputDigest:sha(canonicalInput),payloadBytes:Buffer.byteLength(payload),payloadSha256:sha(payload),lineBytes:Buffer.byteLength(line),lineSha256:sha(line)},
  conflictGolden:{payloadBytes:Buffer.byteLength(conflictPayload),payloadSha256:sha(conflictPayload),lineBytes:Buffer.byteLength(conflictLine),lineSha256:sha(conflictLine)},
  scope:'schema/API probe and generated example only; no product, durability, semantic admission or arbitrary-number parser implementation'},null,2));
