from pathlib import Path
p = Path('docs/proposals/core-capabilities/implementation/session-runtime-interfaces.md')
s = p.read_text()
def replace(old, new):
    global s
    if s.count(old) != 1:
        raise SystemExit(f'expected exactly one match: {old[:100]!r}, got {s.count(old)}')
    s = s.replace(old, new)
replace('request:RequestRef|null, localPrerequisites, state:blocked|ready|claimed|settled|closed', 'request:RequestRef|null, callWork:adjudicate|consume_result|null, localPrerequisites, state:blocked|ready|claimed|settled|closed')
replace('只能由来源事实建立/转移，q1/q2 各自独立。readyAt 相同以本批记录顺序裁决', '只能由来源事实建立/转移，q1/q2 各自独立；callWork 是 SR 下一项消费责任，非 TL 调用状态，call=null 时才为 null。readyAt 相同以本批记录顺序裁决')
replace('| `call_linked` / `result_linked` |', '| `call_proposed` | `{step,call,continuationId,sourcePosition,sourceOwner,protocolVersion,presentationIndex}`；与 TL 原 proposed/冻结 Action 同批及 continuation_waiting 互指，只登记原调用和等待 step_returned 的裁决责任，不准入效果 |\n| `call_linked` / `result_linked` |')
replace('SR 核对 source 的完整调用列表与 TL 已登记 proposedCalls，保存 step_returned + 对应 checkpoint；', 'SR 核对 source 的完整调用列表与 TL 已登记 proposedCalls 及同批建立的 SR 原接续；缺任一绑定返回 unavailable(proposal_handoff_incomplete)，不交还 claim。保存 step_returned + 对应 checkpoint，await_calls 的交还按下段同批置就绪；')
replace('将正在等待其结果的 continuation 从 claimed 置 blocked。checkpoint_saved', '将正在等待其结果的 continuation 从 claimed 置 blocked；仍为 proposed 的原调用不能按“等待结果”阻塞，交还裁决 claim 时必须保留原 adjudicate 就绪责任。checkpoint_saved')
replace('''每个 proposed call 都有一条原 SR continuation：直接 allow 时由 prepareCallLink
在调用联合准入中建立（request=null，前提为原调用终态），ask 时由 prepareWait
建立并增加人类决定前提；以后准入沿用原 ID，不再建一条。prepareResult 使对应
结果接续 ready，driver claim 原 Step 后才能消费/结算。因此无 HD 的真实工具
结果同样有进展路径，不依赖模型轮询或虚构审批请求。
''', '''#### proposed 登记到裁决、结果的交接

TL-07 的 proposed 耐久登记先于当前门裁决。本部署由 TL 在登记时调用下表
prepareProposedCall：门外准备原冻结 Action、CallRef/来源及 SR 候选，同门核对
TL 来源 stamp、SR 原 new_step claim/Step/委托/AR 许可后，以一次 owner_change
提交 TL proposed 与 SR call_proposed + continuation_waiting，两 owner 各有唯一
publication。SR 只在这里为该 CallRef 分配一次 continuationId，初值为
`blocked, callWork=adjudicate, request=null`，前提是原 Step 的完整 step_returned。
此批不释放原 claim，不建 attempt/预算预留/执行许可；重复原操作认回同一绑定。
本域不接受 TL 先单独落 proposed、再靠通知补 SR；缺 SR 提供者登记不可提交。

recordStepReturn(await_calls) 核对完整列表和这些原绑定后，**同批**保存
step_returned、calls_recorded checkpoint、全部尚待裁决接续的 continuation_ready
和 driver_yielded。耐久前不得 claim 这些正向 ready，logical 交还也不放行新效果。
因此交还后有可认回的 adjudicate 工作；不能只写 waiting，再期待尚不存在的
审批/执行结果唤醒它。acquireNextStep(continuation) 取得原 Step 的新 claim 后，
才向 TL 当前门交原调用；以下裁决都消费此 claim，不修改 CallRef.owner/Action。

| TL 当前裁决 | 同一原接续及 claim 的去向 |
|---|---|
| allow | action_execution 同批保存 TL 准入/原 attempt 与 SR call_linked、continuation_waiting(callWork=consume_result)、checkpoint、driver_yielded；原接续等待该调用终态，耐久且许可仍有效才可执行 |
| ask | request_wait 同批保存原 HD 请求/TL waiting 与 SR 原接续的 request/人类决定前提、checkpoint、driver_yielded；不分配另一接续。HD approve 后同一 adjudicate 接续 ready，再取得原 Step claim 重检当前门 |
| 直接 deny | owner_change 同批保存 TL settled(denied_before_execution)、本次 AU 拒绝审计及 SR result_linked、continuation_ready(callWork=consume_result)、checkpoint、driver_yielded。无 attempt、预算预留或 HD 请求，禁止工具效果；不能把 deny 仅作为 RPC 返回丢弃 |

ask 后的拒绝也必须关联 TL 原执行前终态才可消费结果；HD 决定自身不冒充
ToolResultBlock。prepareResult 用 TL 发行的执行前终态证据接受直接 deny，不要求
不存在的 executionEpoch。原结果接续 ready 后再 claim 原 Step，并以
settleContinuation 消费/结算；q2 独立待答不阻碍此过程。unavailable/prepare_again
不是 deny，更不是结果；原 proposed/接续/持有责任保留，不能静默结算或忙重试。

恢复按同水位的 TL proposed/终态与 SR 绑定、step_returned/claim 事实重建：
已交还而未裁决保留原 adjudicate ready；deny 批已耐久则恢复原 consume_result
ready，丢通知/回执不再裁决或执行。若崩溃时旧 claim 尚在，recoverRun 在核实原
TL 状态后，用 epoch_replaced 同批封闭旧 claim，并把**同一接续**恢复为对应 ready；
只有当前身份/新 epoch/AR 许可齐备才能再 claim 原 Step。proposed 登记已耐久但
step_returned 未耐久时，仍属原 Step 的完整返回交付责任：核实原输出事实后完成
recordStepReturn，不伪造完整返回或重发调用；来源无法核实则明确 blocked。
同域 proposed 缺 SR 绑定是组成/恢复错误，不以新建空接续掩盖；强停、已关闭或
未解除的全局阻塞照常封闭继续权。所有认回沿原 CallRef/Action/continuationId，
无效果的执行前 deny 不得恢复出 attempt。
''')
replace('| TL → SR `prepareCallLink/checkCallLink` | 原 WorkOwner=StepRef、Run/epoch、CallRef、proposed 顺序、精确 Action/来源 owner stamp；核对 SR 当前 DriverClaim.step（可为续接的原 Step）/委托/AR 许可和原 CallRef.owner/Action.owner。TL action_execution 聚合 AU 判定、HD 消费（如有）、BG 预留、TL 调用与 SR link，一次 batch |', '''| TL → SR `prepareProposedCall/checkProposedCall` | `{run,epoch,claim,call,action,source,presentationIndex}`；TL 私有候选包含冻结 Action/CallRef 与 proposed 记录，source 证明来自原 Step 的受管输出。SR 检查当前 new_step claim、未完整返回的 Step、原 WorkOwner/Action.owner、顺序/去重和 TL stamp；返回原 continuationId、SR 私有记录/publication 候选。一次 owner_change 登记两 owner 原事实，保留 claim；sourcePosition 引用本批 TL proposed，不能由 driver 拼接事实 |\n| TL → SR `prepareCallLink/checkCallLink` | 原 WorkOwner=StepRef、Run/epoch、CallRef、continuationId、精确 Action/来源 owner stamp；核对 SR 当前 adjudicate DriverClaim.step（可为续接的原 Step）/委托/AR 许可和原 CallRef.owner/Action.owner。TL action_execution 聚合 AU 判定、HD 消费（如有）、BG 预留、TL 调用与 SR link/原接续转等待/yield，一次 batch；不得在此首建接续 |''')
replace('`request_wait` 同批持久 request/Action/调用 waiting 与 SR continuation_waiting/checkpoint；耐久前不展示可答请求', '`request_wait` 核对原 adjudicate claim/已登记接续，同批持久 request/Action/调用 waiting 与 SR 原 continuation_waiting/checkpoint/driver_yielded；耐久前不展示可答请求，不首建接续')
replace('| TL → SR `prepareResult/checkResult` | `{call,step,sourcePosition,executionEpoch,result:ToolResultBlock,terminalEvidence}`；结果由 TL 原权威认回，引用已耐久原事实或本批拟提交的唯一终态；SR 原绑定匹配后 result_linked，并仅使它依赖的 continuation ready，同批结果确认前不可消费。可同域联合结算；否则 TL 保留具名待交付后果直到 SR 回执 |', '| TL → SR `prepareResult/checkResult` | `{call,step,sourcePosition,result:ToolResultBlock,terminalEvidence}`；terminalEvidence 为 TL 私有事实：`before_execution {proposalRevision,terminalVersion,decisionOperation}` 或 `execution {executionOwner,executionEpoch,terminalVersion}`，分别核对未建立 attempt 的原执行前终态或原执行 owner/epoch。来源是已耐久事实或本批唯一终态；SR 核对已登记原接续后 result_linked + ready(callWork=consume_result)，若是直接 deny 则同批 yield 对应 adjudicate claim；无此 claim 的耐久结果交付不虚构 claim。确认前不可消费，不能把缺执行身份的任意 DTO 当执行前事实；分次交付由 TL 保留具名后果至 SR 回执 |')
replace('原\n执行 epoch 与当前 Run epoch 分别核验', '有实际执行时，原\n执行 epoch 与当前 Run epoch 分别核验')
replace('S14–S17 同门组合是相应开放门', 'S14–S18 同门组合是相应开放门')
replace('S01–S10 适用子场景、真实文件闭环及独立 tarball；', 'S01–S10 适用子场景、S18 的执行前拒绝恢复、真实文件闭环及独立 tarball；')
replace('local-execution 持久接纳/停止账本。最小节点前必须实现 allow、结果恢复、unknown 与迟到停止，不能只交 DTO', 'local-execution 持久接纳/停止账本。TL 与 SR 共同交付 proposed 登记、直接 deny 结果和 S18 恢复；最小节点前必须实现 allow、结果恢复、unknown 与迟到停止，不能只交 DTO')
needle = '\n这些是施工验收输入，当前均 **未执行本稿产品符合性测试**；'
replace(needle, '\n| S18 / A09/A17/TL-07 | 真实 TL proposed 与 SR 原接续联合耐久登记，driver recordStepReturn(await_calls) 交还 claim；尚无 allow/ask 时取原 adjudicate 接续并让当前门直接 deny，在 deny 批耐久后、结果消费前 kill/reopen。另在 proposed 批后/交还后/裁决 claim 后分别重启，并阻断各批 fsync、丢回执/通知 → 原 Step/CallRef.owner/Action/continuationId 不变，交还后原裁决 ready 可查；重启认回原执行前拒绝结果并串行结算，无新 Step/attempt/HD 请求、无工具效果（真实文件保持原值/不存在），旧 claim 拒绝、相同操作无第二结果。缺 proposed→SR 绑定拒绝交还/恢复，不以待工具结果永远挂住 |\n' + needle)
s += '''
### 对 a58bc7c 复核剩余 R1 的定点修订

本轮 actor `agt-032` 仅补 proposed→裁决→结果交接；R2–R4 及其已复核内容未重写。
新增 prepareProposedCall 的 TL/SR 同批登记与原接续身份，明确 recordStepReturn
交还前提/同批 ready、三路裁决消费 claim、执行前 deny 结果证据及恢复来源。
施工门增加 S18，要求原 Step/Action/CallRef 不变且实际零效果；这些仍是待执行
产品测量，没有运行产品测试、条件断言或额外上游实验。本稿仍为 proposed，
交由原 architecture-reviewer 定点复核，不自行接受。

本轮文档/范围检查日志为 `tmp/session-runtime-design/docs-check-proposed-deny.log`；
最终提交前运行 `make docs-check BASELINE=de39a86`、`git diff --check` 及允许路径检查。
'''
p.write_text(s)
