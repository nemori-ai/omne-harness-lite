from pathlib import Path
p=Path('/data/qiwei/repos/omne-harness-lite/.worktrees/dsh-session-runtime-design/docs/proposals/core-capabilities/implementation/session-runtime-interfaces.md')
s=p.read_text()
s=s.replace('| 治理施工候选 | `governance-interfaces.md@8b75f30`，从兄弟设计分支按固定 commit 读取；认证、委托、Session 资格及 subjectDefinition 对齐输入，**不是接受依据**。后续治理修订须逐项核对，不消费浮动文件 |', '| 治理施工输入 | `governance-interfaces.md@058c77c`，已由 HUB `4bf0d3c` 接受；本轮以 git show 核对其原文与接受状态，spoke 不 rebase。沿用认证/工作事实、Acquisition、AU 设置及 TG ReferenceInventory；设计示例不证明产品。records 端口/codec 已由 HUB `0e80245` 接受，真实 P1 仍待交付 |')
s=s.replace('成员依据沿治理候选的', '成员依据沿治理已接受输入的')
s=s.replace('definition:DefinitionVersion, lifecycle, title', 'definition:DefinitionVersion, acquisition:{tenantId,acquisitionId}, createdAcquisitionRevision:Counter, lifecycle, title')
s=s.replace('tenant/owner/initiator/原 DefinitionRef 不可变。', 'tenant/owner/initiator/原 DefinitionRef 及 acquisition 身份不可变。')
s=s.replace('{run, batch:Input[], definition, executionChoice, epoch:OpaqueId, phase, checkpoint, blockers, controlRevision, delegationBasis, driverBinding, outstanding}', '{run, batch:Input[], definition, acquisitionBasis, executionChoice, epoch:OpaqueId, phase, checkpoint, blockers, controlRevision, delegationBasis, driverBinding, activeClaim:DriverClaim|null, outstanding}')
s=s.replace('Step | `{step:StepRef, epoch, kind:model|auxiliary, requestBinding|null, trigger, status, proposedCalls:CallRef[], presentedOrder:CallRef[]}`', 'Step | `{step:StepRef, createdEpoch, kind:model|auxiliary, requestBinding|null, trigger, status:running|waiting|settled|failed, proposedCalls:CallRef[], presentedOrder:CallRef[]}`')
s=s.replace('| Control |', '| DriverClaim | `{claimId,run,epoch,step,continuationId:null|OpaqueId,kind:new_step|continuation}`；SR 分配的本次串行驱动事实，只一项 activeClaim。旧 Step 可在新 Run epoch 被合法续接，createdEpoch 不改；真实驱动权限还需当前私有句柄/委托和 AR 许可 |\n| Control |',1)
s=s.replace('checkpoint 使用 `inputs_taken', '''Session.acquisition 只是 TG 原 Acquisition 的身份投影，不能按 DefinitionVersion 搜索
另一条 enabled 选用代替它。create 必须显式给出该 acquisitionId，TG 核对 tenant、
selected 精确版本、enabled、权益及当时 configuration/revision，创建事件保存原关联。
Run.acquisitionBasis 保存取批时 TG 的完整不可变 Acquisition 快照；准备 stamp 包含
原 acquisitionId/revision。恢复/激活/后续准入仍查询**该身份**，removed 后同版本
重新 select 得到的新 ID 不复活旧 Session，缺失/停用则后续使用明确阻塞，历史保留。
本批未开放 Session 重选关系；需要改目标时不能偷偷重绑。同 ID 的 configure 按
下一工作边界生效，当前 Run 沿原配置快照；若变更实例必需装配则先退役/重新激活，
不能在一个 Run 逐字段吸收。TG 的当前收紧与 TL/AU 资格照常封闭新准入。

checkpoint 使用 `inputs_taken''')
s=s.replace('| `step_started` / `checkpoint_saved` | Step 完整初值 / `{run,epoch,checkpoint,sourcePositions}`；匹配当前驱动、合法位置，不能跳过未关联结果 |', '| `step_started` / `driver_claimed` / `driver_yielded` | Step 初值 / DriverClaim / `{claimId,run,epoch,checkpoint}`；新 Step 与 claim 同批，续接已有 Step 只写 claim；yield 精确封闭本 claim，不释放 Session 的 Run 占位 |\n| `step_returned` / `checkpoint_saved` / `step_settled` | `{step,claimId,source,content:TextBlock[],proposedCalls,nextIntent}` / `{run,epoch,checkpoint,sourcePositions}` / `{step,claimId,outcome,evidence}`；按下文 driver 端口核实来源/完整性/合法阶段，不能跳过未关联结果 |\n| `driver_failed` / `run_failure_requested` | `{run,epoch,claimId,step,code,sourceFacts}` / `{run,epoch,failureOperation,exactCalls,exactRequests,remaining}`；SR 的不可恢复失败/停止意图，和相关 TL/HD 封闭同批；不是任意 driver 自写 failed |')
s=s.replace('ready 的排序用 envelope Position，claimed 与本次 Step 同批', 'ready 的排序用 envelope Position，claimed 与本次 DriverClaim 同批；已有 sourceStep 不重建')
s=s.replace('这是待与治理稿共同接受的最小权限政策', '这是本稿待接受、与治理已接受消费面衔接的最小权限政策')
s=s.replace('control/activate` 逐项明确授予', 'control/activate/settings.write.confirmation_mode` 逐项明确授予')
s=s.replace('不含正文、resume、新工作或隐式代答', '不含正文、resume、设置写、新工作或隐式代答')
s=s.replace('应用的真实身份适配发行治理候选中的', '应用的真实身份适配发行治理输入中的')
settings='''Session 的设置写权与 control/read 独立求值。AU 的
`setOverride/clearOverride(scope=session(S),settingId=confirmation_mode)` 门外调用 SR
`prepareSessionFacts`，同门 `checkSessionFacts` 必须返回当前 owner 的
`settings.write.confirmation_mode`；核对真实 invocation、TG 当前成员、Session open、
原 acquisition/定义及 SR 权限 stamp，AU 再核对字段/值 Schema、作用域和自己 stream
的 expectedRevision。只由 AU 一次 owner_change 写 override/审计；SR 是只读参与者，
不复制保存模式或虚造 publication。撤权/停用先发生则该旧候选不可提交。
set 的 standard/confirm/unattended 与 clear 分开，false/null 仍拒绝；生效/来源由
AU readEffective 按已接受层次计算，变更不伪造 pending 请求的答案。紧急控制者/
普通管理员不能借控制权改模式。这里不开放 text_model；其 SR/MC 同批选择门不变。

`settingsUser` 从真实被代表的用户取得：本批用户 Session 是 Session.owner.user，
内部宿主派发/RunDelegation 保持同一用户；不是当前查询者、initiator 或工具参数。
SR 返回 AU 要求的明确 UserRef；无法核实被代表用户的 system 工作返回 unavailable，
不猜一个默认用户。Session 设置操作也不因此得到 user_definition/definition_default
写权，它们继续由 AU 的各自作用域规则判断。

'''
s=s.replace('应用的真实身份适配发行治理输入中的', settings+'应用的真实身份适配发行治理输入中的')
s=s.replace('sourceOperation,membershipBasis,allowedOperations}`', 'sourceOperation,membershipBasis,acquisitionBasis,allowedOperations}`')
s=s.replace('Step 消费委托必须匹配 `StepRef.run` 与 SR 已登记的 Step。', 'Step 消费委托必须匹配 `StepRef.run` 和当前 DriverClaim.step；续接已有 sourceStep\n时不要求它是最新创建的 Step，也不以 Step.createdEpoch 代替当前 claim.epoch。')
s=s.replace('Session 原 DefinitionVersion、open、当前资格/恢复兼容 stamp', 'Session 原 DefinitionVersion/acquisition 身份、TG 当前原选用及配置适用性、open、当前资格/恢复兼容 stamp')
s=s.replace('| create | invocation、operationId、tenant、精确 Agent DefinitionVersion/选用；', '| create | invocation、operationId、tenant、精确 Agent DefinitionVersion 与原 acquisitionId；')
s=s.replace('| acquireNextStep | 原 RunDelegation、WorkPermit、RunRef/epoch、确切 continuation 或 inputs_taken 触发；原控制/资格及本地前提满足后串行 claimed，返回已耐久 Step，不能重复驱动 |', '| acquireNextStep | 原操作、RunDelegation、WorkPermit、RunRef/epoch、expectedRunRevision、`trigger=new_step(fromCheckpoint,reason)` 或 `continuation(continuationId)`；SR 按下文取得唯一 DriverClaim，返回已耐久 `{claim,step,checkpoint}`；续接不分配新 Step |\n| driver 进展/结算 | `recordStepReturn/yieldDriver/settleContinuation/settleStep/requestRunCompletion/reportDriverFailure` 只给注册 driver/原收口宿主；输入和裁决见下节，不给 driver append 或 setState |')
s=s.replace('control/原定义 → AU', 'control/原定义/原 acquisition → AU')
s=s.replace('## TL/HD 的窄交互与独立接续', '''### Driver 向 SR 交付进展与结算

这些是 Session 的真实受信写操作。共同输入为 `{operation,claim:DriverClaim,
expectedRunRevision,expectedStepRevision,expectedCheckpoint}` 加下表具名数据；
真实 claim 必须由 SR 私有表认回、等于 activeClaim，绑定同一 Run/当前 epoch/Step、
注册 driver、RunDelegation 及 AR WorkPermit。方法返回 AdmissionResult，result 只
报告 SR 实际选择的进展/等待/终态；driver 的 nextIntent 不是状态赋值或完成证据。
门外核实原事实/准备候选，门内重检全部 stamp/控制，SR 组装一次 batch；正常进展
用 checkWork，closing 下有限收口用 checkSettlement，force_stop 后只能入隔离证据。

| driver → SR 操作 | SR 裁决、合法转移及同批记录 |
|---|---|
| `recordStepReturn` | 输入 `{source,content:TextBlock[],proposedCalls:CallRef[],nextIntent:finish_run|next_decision|await_calls}`。source 是本部署确定性 driver 的受管返回，或 MC 原请求/attempt 的可核实完整终止事实；不接受 driver 自造模型成功/ToolResult。SR 核对 source 的完整调用列表与 TL 已登记 proposedCalls，保存 step_returned + 对应 checkpoint；无工具完整成功才可作为 settleStep 的依据，partial/unknown 不能冒充成功 |
| `yieldDriver` | 输入 `{reason:await_facts|park,sourceFacts}`。SR 从已持久 call/wait/结果推导 checkpoint；有尚未结束的精确调用可保持 source Step waiting，将正在等待其结果的 continuation 从 claimed 置 blocked。checkpoint_saved + driver_yielded 同批封闭 activeClaim；有别的合法 ready 则可再取 claim，否则 Run waiting。park 另沿 epoch_parked，不能以 yield 免掉 AR 后代责任 |
| `settleContinuation` | 输入 `{continuationId,consumedFacts,nextIntent:finish_run|next_decision|await_facts}`。必须是本 claim 的原接续，其所需 HD 后果/原 call 终态已关联且未重复消费；pending/unknown 未经原 owner 明确处置不结算。continuation_settled + checkpoint_saved + driver_yielded 同批；next_decision 只记录下一决策意图，q2 未答仍保留，不顺带关闭它 |
| `settleStep` | 输入 `{step,sourceFacts,nextIntent}`，SR 检查完整 step_returned、原 proposedCalls 的可信结果/具名独立责任、该 Step 全部 continuation 已结算且无未处理依赖。step_settled + checkpoint_saved 同批；未满足则报告 waiting，不因 driver 函数 return 就 settled。它可和 settleContinuation 在同一 SR 候选批内成立，不要求先提交两次 |
| `requestRunCompletion` | 输入 `{sourceFacts}`；SR 核对全部 Step/continuation 的完成判据、没有 pending 请求/ready/在途 driver 后代，剩余责任已结算或确认独立持有。可与最后一次 Step/continuation 结算合成一个 owner_change batch，写 run_settled(completed) + driver_yielded（若仍有 claim）+ driver_released；缺任何条件只返回 waiting/blocked，不能取消请求来凑成功 |
| `reportDriverFailure` | 输入 `{code,sourceFacts}`，由原受管任务的 throw/reject 接管点调用，错误正文不入普通日志。SR 核验失败属于原 claim，保存 driver_failed，按不可恢复失败在同门封闭继续权并和 TL/HD 的精确终止片段提交 run_failure_requested；其余处置见下段。已先 cancel/force_stop 或旧 epoch 只保留迟到失败，不取代已有终止意图 |

无工具返回：recordStepReturn 后，SR 可把符合条件的 step_settled/checkpoint/
run_settled/driver_released 合为一次提交，耐久后才向调用者确认完成。工具返回后
相同算法消费 TL 真实 result_linked；driver 只能提供消费意图，不能改变结果状态。
正常 checkpoint 的迁移由具体来源约束：inputs_taken→step_prepared 随新 Step，
完整工具建议关联后→calls_recorded，等待事实→waiting，原结果关联/消费后→
results_linked，Step 全部前提满足后→step_settled；迟到通知不会绕过中间事实。

不可恢复失败使用 SR 具名终止组合：原 activeClaim/epoch 和引用清单同门封闭，
SR 的失败意图/continuation closed、HD 对仍待答请求及未应用后果的取消
(reason=run_failed)、TL 未准入调用封闭/原调用停止意图在**一个** owner_change
batch 保存。HD 已有答案与已完成接续仍保留，只关闭剩余后果；不得先 run.failed
再异步猜哪些请求需关闭。需要真实停止/隔离时 Run stopping 保留占位，按原停止
协议取证后另一批 run_settled(failed)+driver_released；无在途责任可在首批直接
安全结算。必需 TL/HD 提供者 unavailable 则不宣称联合关闭/失败终态，原 owner
保留停止意图与责任，封闭效果。driver 抛错不让 detached Promise 静默消失。

### 原 Step 的继续与下一次决策

q1/q2 来自 Step S 时，HD 答复使 q1 接续 ready；acquireNextStep 的 continuation
分支 **继续 S**，只分配新 DriverClaim，原 CallRef.owner、Action.owner 和 S 的
createdEpoch 都不改。TL/AU 的当前 Step 检查针对 `activeClaim.step == S`、当前
claim.epoch/RunDelegation 与原调用绑定，不要求 S 是最后创建的 Step。批准后
执行原 attempt，等待工具结果可 yield，再由原 TL 结果使同一接续 ready；拒绝
则消费原 denied_before_execution。两者结算后 q2 仍属于 S，不被标为完成。

若 q1 后需要下一次模型决策，SR 先保存 q1 consumed 事实/next_decision 意图并
释放 claim，再由 new_step 分支创建 S2；它不依赖 S 中独立 q2 已答，模型投影
携带 q2 deferred receipt。S 可以因 q2 未完仍为 waiting，**未结算 Step 可以多个，
可执行 DriverClaim 只有一个**。后来答 q2 仍 claim S，不将原调用改绑 S2；S2
自己的新工具建议才归 S2。普通无工具返回只产生一个新 Step；恢复/批准/结果
重放都不凭通知创建新 Step。该分工不允许 driver 把模型建议当作已执行结果。

## TL/HD 的窄交互与独立接续''')
s=s.replace('核对 SR 当前 Step/委托/AR 许可。TL action_execution', '核对 SR 当前 DriverClaim.step（可为续接的原 Step）/委托/AR 许可和原 CallRef.owner/Action.owner。TL action_execution')
s=s.replace('{run,observedEpoch,controlOperation,kind,scope,exactCalls,exactRequests}', '{run,observedEpoch,controlOperation,kind:interrupt|cancel|force_stop|driver_failure,scope,exactCalls,exactRequests}')
s=s.replace('SR 保存停止意图/阻塞，HD 关闭应关闭请求/后果', 'SR 保存停止或失败意图/阻塞，HD 关闭应关闭请求/后果')
s=s.replace('| SR → AU/TG 的只读工作面 | `prepareWorkFacts/checkWorkFacts(frame,...)` 认回 Session 原定义、owner/输入主体、Run/Step/epoch、委托当前可用性、所需对象权；返回私有当前依据，无批准、工具资源权或预算许可 |', '| SR → AU 的 Session/工作事实（实现 AU ActionFacts） | `prepareSessionFacts/checkSessionFacts` 用于无 Run 的设置/对象操作，`prepareWorkFacts/checkWorkFacts` 用于精确工作；返回 `{session,owner,subjectDefinition,acquisition:TG当前原Acquisition,settingsUser:UserRef,run?,epoch?,controlRevision,operations:明确集合}` 的私有快照/current 结果，附原 Run acquisitionBasis、当前 claim/委托 stamp；正文读、输入写、设置写、控制独立，无批准或资源许可 |\n| SR → TG 的引用清单（实现 TG ReferenceInventory） | `prepareReferences(target)/checkReferences(frame,candidate)`；由 SR 持有具名引用项/完整性和当前修订，含 Session 原定义/acquisition、Run 快照与 attachment 使用；下节固定范围/双视图与交错。缺 provider 不返回空清单 |')
s=s.replace('SR 从 ready continuation 中按耐久 readyAt、同批记录顺序串行 claim；只有当前\n运行中的一个 Step 能驱动下一动作。', 'SR 从 ready continuation 中按耐久 readyAt、同批记录顺序串行 claim；只有当前\nactiveClaim 能驱动下一动作，原 waiting Step 不阻止独立就绪接续。')
s=s.replace('## 控制、退出和恢复', '''### SR 提供给 TG 的引用清单

TG 定义 ReferenceInventory 消费协议，Session 实现它；接口依赖方向为 SR→TG，
不让 TG import SR 实现，也不把正文历史投影作为判断无引用的权威。
`prepareReferences(target)` 的 target 为精确 DefinitionRef/DefinitionVersion、
`{tenantId,acquisitionId}` 或 `{definition,draftRevision}`；门外取得 SR 私有候选，
含已接受治理形状的 `ReferenceReport={sources:[{owner,revision}],references:
[{owner,target:ResourceRef,relation,blocksDiscard}],complete}` 与原查询/范围 stamp。
`checkReferences(frame,candidate)` 同门验证原实例、查询和当前引用根，返回
ready / prepare_again / unavailable；不在门内全量扫描、调用户函数或查询存储。

| SR 引用项 | ReferenceReport 中的对应与范围 |
|---|---|
| 已创建 Session 的原 DefinitionVersion/原 acquisition | owner=session，target 为该 Session 的 ResourceRef，relation=session_definition/session_acquisition；包含仍受保留义务约束的历史，不因没有活体 Agent 丢失 |
| Run 的 acquisitionBasis/definition/driver 依据 | target 为原 Run 的 ResourceRef，relation=run_definition/run_acquisition；保留准备、等待、停止与历史工作，不能在释放 driver 时删去引用 |
| SR 当前 held/revoked/releasing attachment | target 为精确 AgentRef 对应 ResourceRef，relation=agent_attachment；释放确实完成才撤回运行引用，blocked 清理仍在；来源是 SR attachment 登记，不推测 AR 目录 |
| draft | 当前 Session 只允许已发布 DefinitionVersion，SR 不产生 draft 引用；仅在已恢复完整根且相关创建入口受此限制时返回 complete=true 的空项。未来开放 draft 引用需另行实现，缺解析器/未恢复不是空 |

ResourceRef 使用真实 tenant，kind=session/run/agent_runtime，resourceId 分别为
sessionId/core-json(RunRef)/core-json(AgentRef)，version 为该记录修订或 incarnationId；
它们只是引用报告的边界投影，不新增业务身份/访问权。以上已发布引用的
blocksDiscard=false，不使 retire/disable/remove 默认 busy；TG 保留影响/下一准入
生效边界，原 Session/历史不级联删除，不强停已准入调用。报告给 TG 受信门保留
完整关系，对外对象/计数再按 SR 当前元数据权裁剪，不借资产管理权泄漏私人对象。

SR 的引用根由本 owner 的耐久事实/待确认候选和 attachment 账目生成，属于必需的
当前条件依据；不是可落后的查询 projection。每次引用增加/变化在其原同批
publishLogical 或 attachment 注册的同一门推进 referenceRevision；来源 stamp
为 provider generation 与 referenceRevision 的规范组合（满足治理 revision 的
OpaqueId 表达）。pending 引用增加立即可见，撤回仅在对应耐久/真实释放确认后
从集合消失；恢复从完整 SR 前缀和新 attachment 表重建，再给新的来源 generation。

TG 在 discard/retire/disable/remove 末门检查该 stamp；SR create/运行绑定则检查
同一原 TG acquisition/定义的当前 stamp。若 SR 新引用先占逻辑位置，TG 旧清单
必须重准备并报告它；若 TG 先停用/移除，SR 的旧创建候选不能随后借同版本其它
acquisition 通过。没有第二把互不相关的锁或通知后补清单。provider 缺失、重建
未完/异常失联为 unavailable/complete=false，不能当无引用；只有部署已封闭
全部 SR 引用创建且证明此范围不适用时，TG 才可按其已接受规则列为不适用。

## 控制、退出和恢复''')
s=s.replace('交付 SR 的 attachment/RuntimeAccess/TG-AU 工作事实映射', '交付 SR 的 driver 进展/结算、attachment/RuntimeAccess、AU Session/工作事实及 TG ReferenceInventory；S14–S17 同门组合是相应开放门')
s=s.replace('与治理稿共同接受权限词和各声明的唯一导出归属后编译；', '沿已接受治理接口固定 SR 权限词/实际导出归属，交付 settingsUser/原 acquisition/设置写 current 与引用清单后编译；')
s=s.replace('| 原定义到 Factory/driver 的装配 |', '| SR 引用清单 | Session 作者实现 TG ReferenceInventory、所有原 Session/Run/attachment 引用、source revision 与同门检查；实际 SR 创建和 TG 退役/停用竞争通过 S17。已开放 SR 时缺提供者为 unavailable，不等 P3 再补无引用判断 |\n| 原定义到 Factory/driver 的装配 |')
s=s.replace('| S13 / A24/A30–32 |', '| S14 / A09/A17/SR-08/09 | 无工具正常返回、真实 TL 结果后的结算、q1 就绪而 q2 未答、driver throw 与终态竞争 → 原 Step/CallRef 不变，新的模型决策才新 Step；driver 进展/Step/Run 结算经同批，剩余 HD 后果在失败意图同批关闭，停止未知时保留 stopping；重放/旧 claim 不二次推进 |\n| S15 / A03/TG-05 | 同一 DefinitionVersion 下选用 a/b 配置不同，Session 原属 a；准备后 configure/disable/remove a，再同版本重选 c 并重启 → 不借 b/c，不混当前 Run 配置；原 a 被移除后后续使用阻塞，已准入/历史原关联保留 |\n| S16 / A11/A01 | owner 与仅有 emergency_control 的管理者分别 set/clear Session confirmation_mode，准备后撤权或停用；再测 false/null → 只有 owner 的独立设置权可提交，旧候选拒绝，非法值不变 clear，重启恢复 AU 原覆盖/来源，未做模型选择 |\n| S17 / A03/TG-05/PF-010.C10 | TG 先准备空引用清单，SR create/attachment 先占位；反向让 TG disable 先提交；再撤掉 SR inventory/加载缺口 → 前者 TG 重准备并报告新增引用，后者 SR 当前门拒绝；缺来源 unavailable 而非空。已存在引用不级联删除/强停，也不向无正文/元数据权的管理者泄漏内容或存在性 |\n| S13 / A24/A30–32 |')
s+='''
### 对 746ce47 独立评审的定点修订

本轮 actor `agt-028` 仅处理 R1–R4，治理输入更新为已接受 058c77c/HUB 4bf0d3c；
本稿仍为 proposed，等待原 architecture-reviewer 复核。没有修改正式 v1 或产品。

| 评审项 | 修订定位与最小测量 |
|---|---|
| R1：driver 只会取 Step、不会交付或结算 | “Driver 向 SR 交付进展与结算”“原 Step 的继续与下一次决策”，及 step/claim/失败事件；S14 覆盖无工具、真实结果、q1/q2、失败和同批关闭 |
| R2：遗失原 acquisition | Session/Run shape、其后原选用规则、attachment 和 AU 当前事实；S15 的 a/b/c 同版本与配置/重启反例 |
| R3：Session 设置写权缺失 | “当前调用者、对象权限与运行委托”的设置写/SettingsUser 段及 AU SessionFacts；S16 覆盖 owner、紧急控制者、撤权、set/clear |
| R4：缺 TG ReferenceInventory 提供者 | “SR 提供给 TG 的引用清单”、R2 施工/依赖表；S17 覆盖创建/停用顺序、真实来源缺失及披露 |

S14–S17 是实施必须测量的场景，本轮没有运行产品测试或以自写条件断言替代它们。
文档/范围检查针对最终本稿运行，日志存 `tmp/session-runtime-design/docs-check-r1-r4.log`；
具体结果随固定修订提交报告，不宣称语言记法可编译或自行认定评审通过。
'''
p.write_text(s)
