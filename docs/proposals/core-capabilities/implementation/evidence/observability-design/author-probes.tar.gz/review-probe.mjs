import assert from 'node:assert/strict';
import fs from 'node:fs';
import { mkdir, readFile } from 'node:fs/promises';
import { once } from 'node:events';
import { performance } from 'node:perf_hooks';
import pino from 'pino';
import SonicBoom from 'sonic-boom';
import { ROOT_CONTEXT, createContextKey } from '@opentelemetry/api';
import { AsyncLocalStorageContextManager } from '@opentelemetry/context-async-hooks';
const report = {node:process.version, cases:[]};
const save = (name,result) => report.cases.push({name,result});
const dir = new URL('./output-review/',import.meta.url);
await mkdir(dir,{recursive:true});
async function timeout(p,ms=1000) {let timer;try{return await Promise.race([p,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('probe timeout')),ms);})]);}finally{clearTimeout(timer);}}
async function sink(name,minLength) {
  const file=new URL(name,dir);
  const stream=new SonicBoom({dest:file.pathname,sync:false,minLength,maxLength:1048576,maxWrite:16384,append:false,mode:0o600,retryEAGAIN:()=>false});
  const errors=[];stream.on('error',e=>errors.push(e.code));await once(stream,'ready');
  return {file,stream,errors,logger:pino({base:null,timestamp:false},stream)};
}
async function close(stream) {const p=once(stream,'close');stream.end();await timeout(p);}
const originalWrite=fs.write;
let inGate=false;const starts=[];
fs.write=function(...args){starts.push({inGate,fd:args[0]});return Reflect.apply(originalWrite,fs,args);};
try {
  const bad=await sink('r1-before.jsonl',4096);
  inGate=true;bad.logger.info({seq:1,synthetic:'x'.repeat(5000)});inGate=false;
  assert.equal(starts.filter(x=>x.fd===bad.stream.fd&&x.inGate).length,1);
  await close(bad.stream);
  save('O-R1-original-threshold-counterexample',{fsWriteStartedInsideGate:true});
  for(const minLength of [4096,0]) {
    const good=await sink(`r1-after-${minLength}.jsonl`,minLength);const begin=starts.length;
    // Probe-only lexical scratch: the real consumer owns its gate and fields.
    const scratch=[];let omitted=0;const CAP=16;const value={accepted:true};let returned;
    inGate=true;
    try {for(let i=0;i<19;i++){if(scratch.length<CAP)scratch.push({seq:i+1,synthetic:'x'.repeat(400)});else omitted++;}returned=value;assert.equal(starts.length,begin);}
    finally {inGate=false;for(const point of scratch)good.logger.info(point);scratch.length=0;}
    assert.equal(returned,value);assert.equal(omitted,3);
    assert(starts.slice(begin).length>0);assert(starts.slice(begin).every(x=>!x.inGate));
    await close(good.stream);const bytes=await readFile(good.file);assert(bytes.length>4096);
    save(`O-R1-output-after-gate-minLength-${minLength}`,{fsWritesInsideGate:starts.slice(begin).filter(x=>x.inGate).length,bytes:bytes.length,omitted});
  }
} finally {inGate=false;fs.write=originalWrite;}
const low=await sink('r2-single.jsonl',0);const began=performance.now();
const written=once(low.stream,'write');low.logger.error({seq:1,code:'single-low-traffic-error'});
await timeout(written);const lowText=await readFile(low.file,'utf8');assert.equal(JSON.parse(lowText).code,'single-low-traffic-error');assert.equal(low.stream.destroyed,false);
save('O-R2-one-record-visible-without-close',{elapsedMs:Math.round((performance.now()-began)*1000)/1000,bytes:Buffer.byteLength(lowText),closed:false});
await close(low.stream);
const broken=await sink('r2-failure.jsonl',0);const health={progress:'pending',lastErrorCode:null};
broken.stream.on('error',e=>{health.progress='failed';health.lastErrorCode=e.code;});
fs.write=function(...args){if(args[0]!==broken.stream.fd)return Reflect.apply(originalWrite,fs,args);const cb=args.at(-1);queueMicrotask(()=>cb(Object.assign(new Error('synthetic-write-failure'),{code:'EIO'})));};
try {const error=once(broken.stream,'error');broken.logger.error({seq:1,code:'failure-path'});await timeout(error);assert.deepEqual(health,{progress:'failed',lastErrorCode:'EIO'});}
finally {fs.write=originalWrite;const closed=once(broken.stream,'close');broken.stream.destroy();await timeout(closed);}
save('O-R2-write-failure-visible',health);
const manager=new AsyncLocalStorageContextManager().enable();
const key=createContextKey('probe-owner');const context=ROOT_CONTEXT.setValue(key,'owner-a');
let closed=false;let bodyCalls=0;let observers=0;
function within(ctx,body){return closed?body():manager.with(ctx,body);}
function current(){return closed?null:manager.active();}
const pending=new Promise(()=>{});
Object.defineProperty(pending,'then',{get(){observers++;throw new Error('within must not inspect then');}});
for(let i=0;i<10000;i++)assert.equal(within(context,()=>{bodyCalls++;return pending;}),pending);
assert.equal(bodyCalls,10000);assert.equal(observers,0);
const marker=new Error('body-error');assert.throws(()=>within(context,()=>{throw marker;}),e=>e===marker);
const unhandled=[];const onUnhandled=e=>unhandled.push(e);process.on('unhandledRejection',onUnhandled);
try {
  const rejected=Promise.reject(marker);const observedByOwner=rejected.catch(e=>e);
  assert.equal(within(context,()=>rejected),rejected);assert.equal(await observedByOwner,marker);
  let release;const barrier=new Promise(r=>{release=r;});let ownerState='running';let lateLogs=0;let retainedNativeContext=false;
  const originalResult={from:'caller-owner'};
  const bodyPromise=within(context,async()=>{assert.equal(manager.active().getValue(key),'owner-a');await barrier;retainedNativeContext=manager.active().getValue(key)==='owner-a';assert.equal(current(),null);if(closed)lateLogs++;else throw new Error('expected diagnostics closed');ownerState='settled';return originalResult;});
  // Diagnostic shutdown is not cancellation/settlement of the caller's promise.
  closed=true;manager.disable();assert.equal(ownerState,'running');
  const closedReturn=within(context,()=>{assert.equal(manager.active(),ROOT_CONTEXT);return pending;});assert.equal(closedReturn,pending);assert.equal(observers,0);
  release();assert.equal(await bodyPromise,originalResult);assert.equal(ownerState,'settled');assert.equal(lateLogs,1);
  await new Promise(r=>setImmediate(r));await new Promise(r=>setImmediate(r));assert.deepEqual(unhandled,[]);
  save('O-R3-no-promise-bookkeeping',{stalledCalls:bodyCalls,thenObservers:observers,withinLimit:'none; no registry or observer created',unhandledRejections:unhandled.length});
  save('O-R3-close-does-not-own-body',{ownerWasRunningWhenDiagnosticsClosed:true,lateEmissionSuppressed:lateLogs,retainedNativeContext,publicCurrentAfterClose:current(),ownerState});
} finally {process.off('unhandledRejection',onUnhandled);manager.disable();}
console.log(JSON.stringify(report,null,2));
